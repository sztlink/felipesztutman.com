#!/usr/bin/env python3
# Volume 2 do dossie, Desenvolvimento do Brasil: graficos (graficos.py), HTML e PDF (Chrome headless). Todo numero do texto sai dos CSV
# do volume. Rodar de fora da pasta: cd /tmp && python3 <pacote>/relatorio/monta_relatorio.py
import csv, os, runpy, statistics, subprocess, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..'); G = os.path.join(AQUI, 'graficos')
sys.path.insert(0, AQUI)
from estilo import br, css, glifos, endereca, sumario, imprime_pdf, voz_saida, AVISO_MANDATO
runpy.run_path(os.path.join(AQUI, 'graficos.py'), run_name='graficos')

def le(arq):
  with open(os.path.join(RAIZ, arq), newline='', encoding='utf-8') as f: return list(csv.DictReader(f))
f = lambda v: float(v)

FONTES = {
  'wdi_ppc': 'Banco Mundial, World Development Indicators, NY.GDP.PCAP.PP.KD (PIB por habitante em PPC, US$ internacionais de 2021) e SP.POP.TOTL, consulta de 24/10/2026, atualização da série de 08/10/2026, CC BY 4.0. https://data.worldbank.org/indicator/NY.GDP.PCAP.PP.KD',
  'pwt': 'Feenstra, Inklaar e Timmer, Penn World Table 11.0, Groningen Growth and Development Centre, publicada em 07/10/2025, CC BY 4.0. https://doi.org/10.34894/FABVLR',
  'ibge_cn': 'IBGE, Sistema de Contas Nacionais e Contas Nacionais Trimestrais, SIDRA tabelas 1846, 5932, 2072 e 6784 (PIB, taxa de investimento, poupança e população). https://sidra.ibge.gov.br',
  'wdi_inv': 'Banco Mundial, WDI, NE.GDI.FTOT.ZS (formação bruta de capital fixo, % do PIB), NY.GDS.TOTL.ZS (poupança bruta), NY.GDP.MKTP.KD.ZG e NY.GDP.PCAP.KD.ZG, CC BY 4.0. https://data.worldbank.org',
  'wdi_in': 'Banco Mundial, WDI, IP.PAT.RESD e IP.PAT.NRES (pedidos de patente, dados da OMPI), GB.XPD.RSDV.GD.ZS e SP.POP.SCIE.RD.P6 (P&D e pesquisadores, dados do UNESCO UIS), CC BY 4.0. https://data.worldbank.org',
  'db': 'Banco Mundial, Doing Business, série histórica DB04 a DB20 com escores, e comunicado de descontinuação de 16/09/2021. https://archive.doingbusiness.org/en/data e https://www.worldbank.org/en/news/statement/2021/09/16/world-bank-group-to-discontinue-doing-business-report',
  'bready': 'Banco Mundial, Business Ready (B-READY) 2025, lista de economias e escores por pilar. https://www.worldbank.org/en/businessready',
  'hdr': 'PNUD, Human Development Report 2025, Composite indices complete time series 1990 a 2023. https://hdr.undp.org/data-center/documentation-and-downloads',
  'ibge_gini': 'IBGE, PNAD Contínua anual, SIDRA tabela 7435, índice de Gini do rendimento domiciliar per capita. https://sidra.ibge.gov.br/tabela/7435',
  'pip': 'Banco Mundial, Poverty and Inequality Platform, Gini e pobreza na linha de US$ 3,00 por dia em PPC de 2021. https://pip.worldbank.org',
  'unodc': 'UNODC, International Homicide Statistics, taxa por 100 mil habitantes. https://dataunodc.un.org/dp-intentional-homicide-victims',
  'atlas': 'Ipea e FBSP, Atlas da Violência, taxa de homicídios registrados por 100 mil habitantes (SIM, Ministério da Saúde). https://www.ipea.gov.br/atlasviolencia',
  'jmp': 'OMS e UNICEF, Joint Monitoring Programme (JMP), água e esgotamento sanitário geridos com segurança. https://washdata.org',
  'wdi_vida': 'Banco Mundial, WDI, SP.DYN.LE00.IN (expectativa de vida ao nascer, ONU WPP) e SP.DYN.IMRT.IN (mortalidade infantil, UN IGME), CC BY 4.0. https://data.worldbank.org',
  'pisa': 'OCDE, PISA 2022 Results, Volume I, tabelas de média por país e de tendência. https://www.oecd.org/pisa',
  'snis': 'Ministério das Cidades, SNIS, Diagnósticos dos Serviços de Água e Esgotos de 2010 a 2019 e 2022, e SINISA 2024 (referência 2023), quadros de níveis de atendimento. https://www.gov.br/cidades/pt-br/acesso-a-informacao/acoes-e-programas/saneamento/snis e https://www.gov.br/cidades/pt-br/acesso-a-informacao/acoes-e-programas/saneamento/sinisa',
  'bcb_bpm6': 'Banco Central, SGS 22780 e demais séries de serviços do balanço de pagamentos, e nota metodológica n. 1 sobre a adoção do BPM6 (nova codificação do Sistema Câmbio em fevereiro de 2014). https://www.bcb.gov.br/estatisticas/estatisticassetorexterno',
  'whr': 'World Happiness Report 2026, dados da Figura 2.1 e apêndice estatístico do capítulo 2 (Gallup World Poll). Citado, não republicado. https://worldhappiness.report',
  'siic': 'IBGE, Sistema de Informações e Indicadores Culturais, edições 2022 e 2024 (PNAD Contínua, CEMPRE, PIA, PAC, PAS, POF e MUNIC). https://www.ibge.gov.br/estatisticas/multidominio/cultura-recreacao-e-esporte/9388-indicadores-culturais.html',
  'unctad': 'UNCTADstat, Creative goods (US.CreativeGoodsValue, 2002 a 2024) e Creative services (US.CreativeServ_Indiv_Tot, 2010 a 2024). https://unctadstat.unctad.org',
}
ORDEM = list(FONTES)
n = lambda *ks: ''.join(f'<sup>[{i}]</sup>' for i in sorted(ORDEM.index(k) + 1 for k in ks))
lk = lambda t: t
def svg(nome):
  s = open(os.path.join(G, nome + '.svg'), encoding='utf-8').read().split('?>', 1)[-1]
  return s + (f'<div class=mand>{AVISO_MANDATO}</div>' if any(p in s for p in ('>FHC<', '>Dilma<', '>Bolsonaro<', '>Lula 3<')) else '')

# ---- dados ----
RP = {int(r['ano']): r for r in le('RP-brasil-posicao.csv')}
RU = le('RP-ultrapassagens-2002-2025.csv')
passou = [r for r in RU if r['sentido'] == 'passou o Brasil']; atras = [r for r in RU if r['sentido'].startswith('ficou')]
CRM = {r['mandato']: r for r in le('CR-brasil-mandatos.csv')}
CRP = {r['periodo']: r for r in le('CR-contabilidade-periodos.csv') if r['iso3'] == 'BRA'}
CRC = {r['iso3']: r for r in le('CR-comparadores-resumo.csv')}
fbcf = sorted((f(r['fbcf_pct_pib_media_1995_2024_wdi']), r['iso3']) for r in CRC.values() if r['fbcf_pct_pib_media_1995_2024_wdi'])
abaixo_inv = [iso for v, iso in fbcf if v < f(CRC['BRA']['fbcf_pct_pib_media_1995_2024_wdi'])]
PASSOU = {r['iso3'] for r in RU if r['sentido'] == 'passou o Brasil'}
pass_inv = [r for r in CRC.values() if r['iso3'] in PASSOU and r['fbcf_pct_pib_media_1995_2024_wdi']]
pass_sem = [i for i in sorted(PASSOU) if i in CRC and not CRC[i]['fbcf_pct_pib_media_1995_2024_wdi']]
pass_inv_mais = [r for r in pass_inv if f(r['fbcf_pct_pib_media_1995_2024_wdi']) > f(CRC['BRA']['fbcf_pct_pib_media_1995_2024_wdi'])]
IB = {int(r['ano']): r for r in le('CR-brasil-ibge-anual.csv')}
inv_ib = {a: f(r['taxa_investimento_fbcf_pct_pib']) for a, r in IB.items() if r['taxa_investimento_fbcf_pct_pib']}
pou_inv = {a: f(r['taxa_poupanca_bruta_pct_pib']) < inv_ib[a] for a, r in IB.items() if r['taxa_poupanca_bruta_pct_pib'] and a in inv_ib}
a_max = max(inv_ib, key=inv_ib.get); a_min = min(inv_ib, key=inv_ib.get); a_ult = max(inv_ib)
PN = {(r['iso3'], int(r['ano'])): r for r in le('CR-produtividade-niveis.csv')}
ph = lambda iso, a: f(PN[(iso, a)]['pib_por_hora_pct_eua'])
INP = {int(r['ano']): r for r in le('IN-brasil-posicao.csv')}
DB = {(r['serie'][:9], r['recorte'], r['edicao_db']): r for r in le('NE-doing-business.csv') if r['iso3'] == 'BRA'}
db20 = DB[('revisada ', 'nacional', '2020')]
SO = {int(r['ano']): r for r in le('SO-brasil-painel.csv')}
so = lambda a, c: f(SO[a][c])
IDHP = {int(r['ano']): r for r in le('SO-idh-posicao-brasil.csv')}
PISA = {(r['iso3'], r['edicao'], r['dominio']): f(r['media']) for r in le('SO-pisa.csv')}
BE = {int(r['ano_final_janela_3_anos']): r for r in le('BE-escada-cantril.csv') if r['iso3'] == 'BRA'}
CUI = {(r['indicador'], r['ano']): f(r['valor']) for r in le('CU2-brasil-indicadores.csv') if r['valor']}
CUE = {(r['equipamento'], int(r['ano'])): f(r['valor']) for r in le('CU2-brasil-municipios-equipamentos.csv')}
CUB = {int(r['ano']): r for r in le('CU2-unctad-brasil-posicao.csv')}
CUS = {int(r['ano']): f(r['pct_do_comercio_de_servicos']) for r in le('CU2-unctad-servicos-criativos.csv') if r['iso3'] == 'BRA' and r['fluxo'] == 'Exports'}
NOME = {'BRA': 'Brasil', 'GUY': 'Guiana', 'BLR': 'Belarus', 'MUS': 'Maurício', 'SRB': 'Sérvia', 'GEO': 'Geórgia', 'MKD': 'Macedônia do Norte',
        'CHN': 'China', 'DOM': 'República Dominicana', 'MDV': 'Maldivas', 'ALB': 'Albânia', 'THA': 'Tailândia', 'AZE': 'Azerbaijão',
        'BIH': 'Bósnia e Herzegovina', 'ARM': 'Armênia', 'PLW': 'Palau', 'SUR': 'Suriname', 'GAB': 'Gabão', 'LBY': 'Líbia',
        'GNQ': 'Guiné Equatorial', 'ARG': 'Argentina', 'CHL': 'Chile', 'COL': 'Colômbia', 'MEX': 'México', 'PER': 'Peru',
        'URY': 'Uruguai', 'IND': 'Índia', 'IDN': 'Indonésia', 'TUR': 'Turquia', 'ZAF': 'África do Sul', 'POL': 'Polônia',
        'KOR': 'Coreia do Sul', 'USA': 'EUA'}
def lista(xs):
  xs = list(xs); return ', '.join(xs[:-1]) + ' e ' + xs[-1] if len(xs) > 1 else ''.join(xs)
pib_pc_02_25 = f(CRC['BRA']['pib_pc_pct_aa_2002_2025_wdi'])
a_pico = max((a for a in RP if RP[a]['pct_do_eua']), key=lambda a: f(RP[a]['pct_do_eua']))
CRPA = {(r['iso3'], r['periodo']): r for r in le('CR-contabilidade-periodos.csv')}
# auditoria v1, E3: onde a distancia para cada comparador esta mais no capital ou mais na PTF, 1990 a 2023
dif = [(r['iso3'], f(r['contrib_capital_pp']) - f(CRP['1990-2023']['contrib_capital_pp']), f(r['ptf_residual_pp']) - f(CRP['1990-2023']['ptf_residual_pp']))
       for (i, per), r in CRPA.items() if per == '1990-2023' and i != 'BRA' and r['ptf_residual_pp'] and r['contrib_capital_pp']]
mais_cap = [i for i, dc, dp in dif if abs(dc) > abs(dp)]; mais_ptf = [i for i, dc, dp in dif if abs(dp) >= abs(dc)]
PPC = {}
for r in le('RP-pib-pc-ppc.csv'):
  if r['pib_pc_ppc_2021'] and r['ano'] in ('2002', '2025'): PPC.setdefault(r['iso3'], {})[r['ano']] = f(r['pib_pc_ppc_2021'])
painel = {k: v for k, v in PPC.items() if len(v) == 2}
cresc = sorted((((v['2025'] / v['2002']) ** (1 / 23) - 1) * 100, k) for k, v in painel.items())
med_pc = statistics.median(c for c, _ in cresc)
pos_br = len(cresc) - [k for _, k in cresc].index('BRA')
assert len(painel) == int(RP[2025]['paises_painel_fixo'])
abaixo_02 = int(RP[2002]['paises_painel_fixo']) - int(RP[2002]['posicao_painel_fixo'])
# auditoria v1, V2: os comparadores que estavam abaixo do Brasil em 2002 e nao passaram, como contraste
nao_pass = [i for i in CRC if i != 'BRA' and i in painel and painel[i]['2002'] < painel['BRA']['2002'] and i not in PASSOU and CRC[i]['fbcf_pct_pib_media_1995_2024_wdi']]
nao_pass_mais = [i for i in nao_pass if f(CRC[i]['fbcf_pct_pib_media_1995_2024_wdi']) > f(CRC['BRA']['fbcf_pct_pib_media_1995_2024_wdi'])]
# auditoria v1, V1: medianas sociais por grupo de comparadores em 2024, com o numero de paises
GRP = {r['iso3']: r['grupo'] for r in le('comparadores.csv')}
def med_grupo(arq, campo, ano, filtro=lambda r: True):
  d = {}
  for r in le(arq):
    if r['iso3'] in ('BRA',) or r['iso3'].startswith('OCDE') or str(r.get('ano', r.get('edicao'))) != str(ano) or not r[campo] or not filtro(r): continue
    d.setdefault(GRP.get(r['iso3'], ''), []).append(f(r[campo])); d.setdefault('todos', []).append(f(r[campo]))
  return {g: (statistics.median(v), len(v)) for g, v in d.items()}

# ---- tabelas ----
MAND = ['FHC', 'Lula 1', 'Lula 2', 'Dilma', 'Dilma/Temer', 'Temer', 'Bolsonaro', 'Lula 3']
lin_mand = ''.join(f"<tr><td>{m} ({CRM[m]['anos']})</td><td class=n>{br(f(CRM[m]['pib_real_pct_aa_composto']), 1)}</td><td class=n>{br(f(CRM[m]['pib_pc_pct_aa_composto']), 1)}</td>"
                   f"<td class=n>{br(f(CRM[m]['taxa_investimento_media_pct_pib']), 1) if CRM[m]['taxa_investimento_media_pct_pib'] else ''}</td>"
                   "</tr>" for m in MAND)
PER = ['1990-2000', '2000-2010', '2010-2019', '2019-2023', '1990-2023']
lin_per = ''.join(f"<tr><td>{p.replace('-', ' a ')}</td>" + ''.join(f"<td class=n>{br(f(CRP[p][c]), 2)}</td>" for c in ('pib_real_pct_aa', 'contrib_capital_pp', 'contrib_ocupados_pp', 'contrib_horas_pp', 'contrib_capital_humano_pp', 'ptf_residual_pp')) + '</tr>' for p in PER)
COMP_T = ['BRA', 'ARG', 'CHL', 'COL', 'MEX', 'CHN', 'IND', 'TUR', 'ZAF', 'POL', 'KOR', 'USA']
cel = lambda iso, c, d=1: br(f(CRC[iso][c]), d) if CRC[iso][c] else 'n/d'
lin_comp = ''.join(f"<tr><td>{NOME[i]}</td><td class=n>{cel(i, 'pib_pc_pct_aa_2002_2025_wdi')}</td><td class=n>{cel(i, 'fbcf_pct_pib_media_1995_2024_wdi')}</td><td class=n>{cel(i, 'poupanca_pct_pib_media_2015_2024_wdi')}</td>"
                   f"<td class=n>{cel(i, 'ptf_residual_pp_aa_1990_2023_pwt', 2)}</td><td class=n>{cel(i, 'pib_por_hora_pct_aa_1990_2023_pwt', 2)}</td></tr>" for i in COMP_T)
SOC = [('IDH (0 a 1)', 'idh_hdr2025', 3, 2023), ('Gini, IBGE (0 a 1)', 'gini_ibge_pnadc', 3, 2024), ('Pobreza, % abaixo de US$ 3 por dia', 'pobreza_3usd_pct', 1, 2024),
       ('Expectativa de vida, anos', 'expectativa_vida_anos', 1, 2024), ('Mortalidade infantil por mil', 'mortalidade_infantil_por_mil', 1, 2024),
       ('Homicídios por 100 mil, Atlas', 'homicidios_atlas_100mil', 1, 2024), ('Homicídios por 100 mil, UNODC', 'homicidios_unodc_100mil', 1, 2024),
       ('Esgoto gerido com segurança, %', 'esgotamento_seguro_pct', 1, 2024), ('Água gerida com segurança, %', 'agua_segura_pct', 1, 2024)]
cso = lambda a, c, d: br(so(a, c), d) if SO[a][c] else 'n/d'
ANOS_SOC = [2002, 2006, 2010, 2014, 2018, 2022]
lin_soc = ''.join(f"<tr><td>{t}</td>" + ''.join(f"<td class=n>{cso(a, c, d)}</td>" for a in ANOS_SOC) + f"<td class=n>{cso(u, c, d)} ({u})</td></tr>" for t, c, d, u in SOC)
GI = [('Gini, Banco Mundial', 'SO-desigualdade-pobreza.csv', 'gini_bm_pip_0a100', 2024, 'gini_bm_pip', 1, lambda r: True),
      ('Pobreza, % abaixo de US$ 3', 'SO-desigualdade-pobreza.csv', 'pobreza_3usd_ppc2021_pct', 2024, 'pobreza_3usd_pct', 1, lambda r: True),
      ('Homicídios por 100 mil, UNODC', 'SO-homicidios.csv', 'unodc_taxa_100mil', 2024, 'homicidios_unodc_100mil', 1, lambda r: True),
      ('Esgoto gerido com segurança, %', 'SO-saneamento.csv', 'esgotamento_seguro_pct', 2024, 'esgotamento_seguro_pct', 0, lambda r: True),
      ('Expectativa de vida, anos', 'SO-vida.csv', 'expectativa_vida_anos', 2024, 'expectativa_vida_anos', 1, lambda r: True)]
def cg(m, g, d): return f"{br(m[g][0], d)} ({m[g][1]})" if g in m else 'n/d'
lin_grp = ''.join((lambda m: f"<tr><td>{t}</td><td class=n>{br(so(a, cb), d)}</td>" + ''.join(f"<td class=n>{cg(m, g, d)}</td>" for g in ('America Latina', 'emergente grande', 'passou o Brasil 2002-2025', 'todos')) + '</tr>')(med_grupo(arq, c, a, fl)) for t, arq, c, a, cb, d, fl in GI)

# ---- texto ----
L3 = CRM['Lula 3']
sec_capa = f"""<h1>Desenvolvimento do Brasil</h1>
<div class=edicao>Volume 2 do dossiê economia-brasil · versão 1 · dados até 2025</div>
<div class=sub>Renda por habitante e quem passou o Brasil, de onde veio o crescimento, investimento, produtividade e inovação, ambiente de negócios, indicadores sociais, bem-estar declarado e cultura como desenvolvimento, de 1990 a 2025, contra 27 países de comparação. Cada número traz a fonte numerada no fim. As séries e os scripts estão no pacote de dados.</div>
<h2>Sumário</h2>
<!--SUMARIO-->"""
sec_ler = f"""<h2>Como ler este volume</h2>
<ul class=r>
<li><b>Origem.</b> O volume 1, Gastos públicos do Brasil, trata do orçamento e da dívida. Este volume responde a uma leitura dele, que pediu o horizonte longo, crescimento total e por habitante, produtividade e investimento, e os indicadores sociais básicos. As regras são as mesmas do volume 1. Investigação independente, elaborada com assistência de ferramentas de IA, sem tese eleitoral, aberta a críticas. Não é recomendação de investimento.</li>
<li><b>Comparação.</b> O Brasil aparece contra 27 países fixos em todas as seções. São seis da América Latina (Argentina, Chile, Colômbia, México, Peru e Uruguai), seis emergentes grandes (China, Índia, Indonésia, Turquia, África do Sul e Polônia), duas referências (Coreia do Sul e EUA) e 13 dos 14 países que tinham renda por habitante abaixo da brasileira em 2002 e passaram o Brasil até 2025 (o 14º, a China, está entre os emergentes). A lista está no pacote (comparadores.csv). A mediana dos comparadores só aparece nos anos com pelo menos dez países com dado.</li>
<li><b>Classes.</b> A, demonstrado, é medido ou aritmética sobre dado publicado. B, compatível sem causa, é associação estatística, estimativa de modelo ou pesquisa de opinião. C é o que não está demonstrado. A classe vai na margem ao lado de cada achado.</li>
<li><b>Governos.</b> Os nomes e as faixas de governo datam os valores e não atribuem a causa a cada governo. Crescimento e investimento dependem de preços de exportação, crédito, juros externos e decisões de anos anteriores.</li>
<li><b>Fontes.</b> Banco Mundial, Penn World Table, IBGE, PNUD, UNODC, Ipea, OMS e UNICEF, OCDE, OMPI e UNESCO, World Happiness Report e UNCTAD. Nenhum número vem de memória ou de resumo. O World Happiness Report é citado e não republicado, como pedem os seus termos.</li>
</ul>"""
sec_ess = f"""<h2>O essencial</h2>
<ul class=big>
<li><b>Renda.</b> A renda por habitante do Brasil cresceu {br(pib_pc_02_25, 2)}% ao ano de 2002 a 2025 em paridade de poder de compra, contra {br(med_pc, 2)}% na mediana de {len(cresc)} países com dado nos dois anos. O Brasil fica em {pos_br}º. Dos países que estavam abaixo do Brasil em 2002, {len(passou)} estavam acima em 2025. Em relação aos EUA, a renda brasileira foi de {br(f(RP[2002]['pct_do_eua']), 1)}% em 2002 a {br(f(RP[a_pico]['pct_do_eua']), 1)}% em {a_pico} e voltou a {br(f(RP[2025]['pct_do_eua']), 1)}% em 2025{n('wdi_ppc')}. Seção 1.</li>
<li><b>Produtividade.</b> De 1990 a 2023 o PIB cresceu {br(f(CRP['1990-2023']['pib_real_pct_aa']), 2)}% ao ano. Capital, mais trabalhadores e mais escolaridade explicam mais do que isso, e a produtividade total dos fatores tirou {br(-f(CRP['1990-2023']['ptf_residual_pp']), 2)} ponto por ano. De 2010 a 2019 tirou {br(-f(CRP['2010-2019']['ptf_residual_pp']), 2)}. O PIB por hora trabalhada caiu de {br(ph('BRA', 1990), 1)}% do americano em 1990 para {br(ph('BRA', 2023), 1)}% em 2023{n('pwt')}. Seção 2.</li>
<li><b>Investimento.</b> O Brasil investiu em média {br(f(CRC['BRA']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% do PIB de 1995 a 2024. Dos {len(fbcf) - 1} comparadores com dado, {len(abaixo_inv)} investiram menos. Pelo IBGE, a taxa de investimento foi de {br(inv_ib[a_max], 1)}% em {a_max} a {br(inv_ib[a_min], 1)}% em {a_min} e está em {br(inv_ib[a_ult], 1)}% em {a_ult}{n('wdi_inv', 'ibge_cn')}. Seção 3.</li>
<li><b>Social.</b> De 2002 a 2024 a pobreza abaixo de US$ 3 por dia caiu de {br(so(2002, 'pobreza_3usd_pct'), 1)}% para {br(so(2024, 'pobreza_3usd_pct'), 1)}%, a mortalidade infantil de {br(so(2002, 'mortalidade_infantil_por_mil'), 1)} para {br(so(2024, 'mortalidade_infantil_por_mil'), 1)} por mil e o Gini do Banco Mundial de {br(so(2002, 'gini_bm_pip'), 1)} para {br(so(2024, 'gini_bm_pip'), 1)}. Ainda assim, o Brasil segue acima da mediana dos comparadores em desigualdade, pobreza e homicídios, e abaixo em esgoto e no PISA{n('pip', 'wdi_vida', 'unodc', 'jmp', 'pisa')}. Seção 6.</li>
<li><b>Bem-estar declarado.</b> Na escada de 0 a 10 do World Happiness Report, o Brasil teve {br(f(BE[2022]['escada_media_3_anos']), 2)} ({BE[2022]['posicao']}º de {BE[2022]['paises_no_ranking']}) na média de 2020 a 2022 e subiu para {br(f(BE[2025]['escada_media_3_anos']), 2)} ({BE[2025]['posicao']}º de {BE[2025]['paises_no_ranking']}) na de 2023 a 2025. É pesquisa de opinião, classe B{n('whr')}. Seção 7.</li>
<li><b>Cultura.</b> O setor cultural ocupa {br(CUI[('ocupados_setor_cultural', '2024')] / 1000, 2)} milhões de pessoas, {br(CUI[('ocupados_setor_cultural_pct', '2024')], 1)}% dos ocupados em 2024, com informalidade de {br(CUI[('informalidade_setor_cultural', '2024')], 1)}% contra {br(CUI[('informalidade_todos_setores', '2024')], 1)}% no total. A parte dos municípios com museu subiu de {br(CUE[('Museu', 1999)], 1)}% em 1999 para {br(CUE[('Museu', 2021)], 1)}% em 2021, e a com livraria caiu de {br(CUE[('Livrarias', 1999)], 1)}% para {br(CUE[('Livrarias', 2021)], 1)}%. Os bens criativos caíram de {br(f(CUB[2002]['pct_das_exportacoes_de_mercadorias']), 2)}% para {br(f(CUB[2024]['pct_das_exportacoes_de_mercadorias']), 2)}% das exportações de mercadorias de 2002 a 2024{n('siic', 'unctad')}. Seção 8.</li>
</ul>"""

sec_1 = f"""<h1 class="parte parte-inicio" id=parte-i>Parte I. Renda, crescimento e investimento</h1>
<h2>1. Renda por habitante e quem passou o Brasil</h2>
<p class="cl cl-a">Em paridade de poder de compra, em dólares internacionais de 2021, o PIB por habitante do Brasil foi de {br(f(RP[2002]['pib_pc_brasil']), 0)} em 2002 e de {br(f(RP[2025]['pib_pc_brasil']), 0)} em 2025. Dos {RP[2002]['paises_painel_fixo']} países com dado em todos os anos, {abaixo_02} estavam abaixo do Brasil em 2002. Desses, {len(passou)} estavam acima em 2025, e {len(atras)} que estavam acima ficaram atrás ({lista(NOME.get(r['iso3'], r['pais']) for r in atras)}). O Brasil foi do {RP[2002]['posicao_painel_fixo']}º lugar para o {RP[2025]['posicao_painel_fixo']}º{n('wdi_ppc')}.</p>
<figure>{svg('g01-quem-passou')}</figure>
<p class=nota><b>Fonte.</b> Banco Mundial, WDI{n('wdi_ppc')}. <b>Leitura.</b> Painel de {RP[2002]['paises_painel_fixo']} países com dado em todos os anos de 2002 a 2025. A Guiana passa da escala. Os países que estavam abaixo e continuam abaixo não aparecem.</p>
<p class="cl cl-a">O crescimento médio do Brasil, de {br(pib_pc_02_25, 2)}% ao ano por habitante, ficou abaixo da mediana do painel ({br(med_pc, 2)}%), em {pos_br}º de {len(cresc)}. Contra os EUA, a renda por habitante brasileira subiu até {br(f(RP[a_pico]['pct_do_eua']), 1)}% da americana em {a_pico}, recuou em 2014, caiu em 2015 e 2016, anos de queda do PIB, e está em {br(f(RP[2025]['pct_do_eua']), 1)}%, perto dos {br(f(RP[2002]['pct_do_eua']), 1)}% de 2002{n('wdi_ppc')}.</p>
<figure>{svg('g02-brasil-eua')}</figure>
<p class=nota><b>Fonte.</b> Banco Mundial, WDI{n('wdi_ppc')}. <b>Leitura.</b> Razão entre os PIB por habitante em PPC. Uma razão parada quer dizer que o Brasil cresce no ritmo dos EUA, sem fechar a distância.</p>"""

sec_2 = f"""<h2>2. De onde veio o crescimento</h2>
<p>A contabilidade do crescimento separa o PIB em quanto veio de mais capital (máquinas, prédios, infraestrutura), de mais trabalho (mais pessoas ocupadas e horas), de mais escolaridade (capital humano) e de quanto sobrou, a produtividade total dos fatores (PTF). A PTF é um resíduo. Ela junta tecnologia, organização, alocação de recursos entre empresas e setores e os erros de medida do capital e do trabalho. O método e os dados são os da Penn World Table 11.0, que vai até 2023, e a conta deste volume reproduz a PTF publicada pela própria tabela{n('pwt')}.</p>
<p class="cl cl-a">De 1990 a 2023 o PIB cresceu {br(f(CRP['1990-2023']['pib_real_pct_aa']), 2)}% ao ano. O capital contribuiu com {br(f(CRP['1990-2023']['contrib_capital_pp']), 2)} ponto, mais pessoas ocupadas com {br(f(CRP['1990-2023']['contrib_ocupados_pp']), 2)}, horas por pessoa com {br(f(CRP['1990-2023']['contrib_horas_pp']), 2)}, escolaridade com {br(f(CRP['1990-2023']['contrib_capital_humano_pp']), 2)} e a PTF com {br(f(CRP['1990-2023']['ptf_residual_pp']), 2)}. A PTF ficou negativa em três dos quatro períodos, e de 2010 a 2019 tirou {br(-f(CRP['2010-2019']['ptf_residual_pp']), 2)} pontos por ano. No mesmo período, de 2010 a 2019, ela somou {br(f(CRPA[('USA', '2010-2019')]['ptf_residual_pp']), 2)} ponto por ano nos EUA e {br(f(CRPA[('KOR', '2010-2019')]['ptf_residual_pp']), 2)} na Coreia{n('pwt')}.</p>
<figure>{svg('g03-decomposicao')}</figure>
<p class=nota><b>Fonte.</b> Penn World Table 11.0{n('pwt')}. <b>Leitura.</b> Contribuição de cada fator ao crescimento médio anual do PIB real, em pontos, pela média de Törnqvist com a participação do trabalho de cada ano. O ponto branco é o PIB. Trabalho soma pessoas e horas.</p>
<table><thead><tr><th>Período</th><th class=n>PIB, % ao ano</th><th class=n>Capital</th><th class=n>Pessoas ocupadas</th><th class=n>Horas</th><th class=n>Capital humano</th><th class=n>PTF</th></tr></thead><tbody>{lin_per}</tbody></table>
<p class=nota>Médias de diferenças de logaritmo por ano, em pontos (a taxa composta do PIB de 1990 a 2023 é um pouco maior). As contribuições somam o PIB, com diferença de arredondamento{n('pwt')}.</p>
<p class="cl cl-a">Por mandato, o PIB do IBGE cresceu {br(f(CRM['FHC']['pib_real_pct_aa_composto']), 1)}% ao ano com FHC, {br(f(CRM['Lula 1']['pib_real_pct_aa_composto']), 1)}% no Lula 1, {br(f(CRM['Lula 2']['pib_real_pct_aa_composto']), 1)}% no Lula 2, {br(f(CRM['Dilma']['pib_real_pct_aa_composto']), 1)}% com Dilma, {br(f(CRM['Temer']['pib_real_pct_aa_composto']), 1)}% com Temer, {br(f(CRM['Bolsonaro']['pib_real_pct_aa_composto']), 1)}% com Bolsonaro e {br(f(L3['pib_real_pct_aa_composto']), 1)}% no Lula 3 até 2025. O ano de 2016, da troca de governo, teve {br(f(CRM['Dilma/Temer']['pib_real_pct_aa_composto']), 1)}%{n('ibge_cn')}.</p>
<table><thead><tr><th>Mandato</th><th class=n>PIB, % ao ano</th><th class=n>PIB por habitante, % ao ano</th><th class=n>Investimento, % do PIB</th></tr></thead><tbody>{lin_mand}</tbody></table>
<p class=nota><b>Fonte.</b> IBGE{n('ibge_cn')}. <b>Leitura.</b> A PTF não entra por mandato porque é pró-cíclica e, em 2020 a 2022, foi distorcida pela pandemia nos dados de trabalho. Fica só por período, na tabela acima. Média geométrica dos anos do mandato. O nome do governo data o valor. O ciclo de preços de exportação, os juros externos e a pandemia pesam em cada período, e esta tabela não os separa (classe C para qualquer leitura de causa).</p>
<p class="cl cl-a">O PIB por hora trabalhada mede o que cada hora produz. O do Brasil foi de {br(ph('BRA', 1990), 1)}% do americano em 1990 a {br(ph('BRA', 2023), 1)}% em 2023. No mesmo período, o Chile foi de {br(ph('CHL', 1990), 1)}% a {br(ph('CHL', 2023), 1)}%, a Coreia de {br(ph('KOR', 1990), 1)}% a {br(ph('KOR', 2023), 1)}% e o México de {br(ph('MEX', 1990), 1)}% a {br(ph('MEX', 2023), 1)}%{n('pwt')}.</p>
<figure>{svg('g07-produtividade-hora')}</figure>
<p class=nota><b>Fonte.</b> Penn World Table 11.0, PIB real em PPC sobre horas totais{n('pwt')}. <b>Leitura.</b> Nível relativo, não crescimento. O México tracejado para se separar do Chile, que tem a mesma cor de grupo.</p>"""

sec_3 = f"""<h2>3. Investimento e poupança</h2>
<p class="cl cl-a">Pelas Contas Nacionais, a formação bruta de capital fixo foi de {br(inv_ib[a_max], 2)}% do PIB em {a_max}, o maior valor da série, caiu a {br(inv_ib[a_min], 2)}% em {a_min} e está em {br(inv_ib[a_ult], 2)}% em {a_ult}. A poupança bruta ficou abaixo do investimento em {sum(1 for a in pou_inv if pou_inv[a])} dos {len(pou_inv)} anos com as duas séries, e a diferença corresponde em grande parte ao déficit em conta corrente{n('ibge_cn')}.</p>
<figure>{svg('g06-investimento-ibge')}</figure>
<p class=nota><b>Fonte.</b> IBGE, Contas Nacionais{n('ibge_cn')}. <b>Leitura.</b> Taxas a preços correntes. Investimento inclui o público e o privado.</p>
<p class="cl cl-a">De 1995 a 2024 o Brasil investiu em média {br(f(CRC['BRA']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% do PIB pelo Banco Mundial, contra {br(f(CRC['CHN']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% na China, {br(f(CRC['KOR']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% na Coreia, {br(f(CRC['IND']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% na Índia, {br(f(CRC['CHL']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% no Chile, {br(f(CRC['MEX']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% no México e {br(f(CRC['USA']['fbcf_pct_pib_media_1995_2024_wdi']), 1)}% nos EUA. Dos {len(fbcf) - 1} comparadores com a série, só {lista(NOME[i] for i in abaixo_inv)} investiram menos. Dos {len(pass_inv)} países que passaram o Brasil e têm a série completa, {len(pass_inv_mais)} investiram mais ({lista(NOME[i] for i in pass_sem)} têm série incompleta). Mas dos {len(nao_pass)} comparadores que estavam abaixo do Brasil em 2002 e não passaram, {len(nao_pass_mais)} também investiram mais, então investir mais não separa quem passou de quem não passou (classe C para essa relação). A poupança bruta média de 2015 a 2024 foi de {br(f(CRC['BRA']['poupanca_pct_pib_media_2015_2024_wdi']), 1)}% no Brasil e de {br(f(CRC['KOR']['poupanca_pct_pib_media_2015_2024_wdi']), 1)}% na Coreia{n('wdi_inv')}.</p>
<figure>{svg('g04-investimento')}</figure>
<p class=nota><b>Fonte.</b> Banco Mundial, WDI{n('wdi_inv')}. <b>Leitura.</b> Média simples dos anos com dado. Investir mais não garante crescer mais. Na decomposição de 1990 a 2023, a distância do Brasil está mais no capital contra {lista(NOME[i] for i in mais_cap)}, e mais na produtividade contra {lista(NOME[i] for i in mais_ptf)} (aritmética, classe A, e não explicação).</p>
<table><thead><tr><th>País</th><th class=n>PIB por habitante, % ao ano, 2002 a 2025</th><th class=n>Investimento médio, % do PIB, 1995 a 2024</th><th class=n>Poupança média, % do PIB, 2015 a 2024</th><th class=n>PTF, pontos por ano, 1990 a 2023</th><th class=n>PIB por hora, % ao ano, 1990 a 2023</th></tr></thead><tbody>{lin_comp}</tbody></table>
<p class=nota>Banco Mundial e Penn World Table{n('wdi_ppc', 'wdi_inv', 'pwt')}. n/d, sem dado na fonte. A tabela completa, com os 28 países, está no pacote (CR-comparadores-resumo.csv).</p>"""

sec_4 = f"""<h2>4. Inovação</h2>
<p class="cl cl-a">Os pedidos de patente de residentes foram {br(f(INP[2002]['patentes_residentes_por_milhao']), 1)} por milhão de habitantes em 2002 e {br(f(INP[2024]['patentes_residentes_por_milhao']), 1)} em 2024, o {INP[2024]['posicao_res_pm']}º de {INP[2024]['paises_res_pm']} países com dado. Residentes fazem {br(f(INP[2024]['participacao_residentes_pct']), 1)}% dos pedidos, e o resto vem de não residentes. O gasto em pesquisa e desenvolvimento foi de {br(f(INP[2000]['ped_pct_pib']), 2)}% do PIB em 2000 e de {br(f(INP[2023]['ped_pct_pib']), 2)}% em 2023, o {INP[2023]['posicao_ped']}º de {INP[2023]['paises_ped']}. Os pesquisadores eram {br(f(INP[2014]['pesquisadores_por_milhao']), 0)} por milhão em 2014, último ano com dado{n('wdi_in')}.</p>
<figure>{svg('g08-inovacao')}</figure>
<p class=nota><b>Fonte.</b> Banco Mundial, WDI, com dados da OMPI e do UNESCO UIS{n('wdi_in')}. <b>Leitura.</b> Pedido de patente mede atividade de registro e não qualidade nem uso. A mediana mundial muda com os países que reportam a cada ano.</p>
<p class="cl cl-a"><b>Cultura.</b> As exportações de serviços criativos (audiovisual, software, publicidade, arquitetura, pesquisa) foram {br(CUS[2024], 1)}% das exportações brasileiras de serviços em 2024, pela UNCTAD{n('unctad')}. A série só se compara de 2014 em diante, por uma quebra de método tratada na seção 8.</p>"""

sec_5 = f"""<h2>5. Ambiente de negócios</h2>
<p class="cl cl-a">No Doing Business de 2020, última edição, na série revisada pelo próprio Banco Mundial, o Brasil teve escore de {br(f(db20['escore_db17_20']), 2)} de 100, o {db20['posicao_calculada_db17_20']}º entre as {db20['economias_com_escore']} economias da planilha, posição calculada por este volume a partir dos escores revisados. O ranking oficial não está nos dados baixados. Nas edições de 2016 a 2020, com o mesmo método, o escore foi de {br(f(DB[('revisada ', 'nacional', '2016')]['escore_db17_20']), 2)} a {br(f(db20['escore_db17_20']), 2)}{n('db')}.</p>
<p>O Banco Mundial descontinuou o Doing Business em 16/09/2021, depois de uma investigação sobre irregularidades nos dados das edições de 2018 e 2020{n('db')}. O substituto, o Business Ready (B-READY), não inclui o Brasil na edição de 2025, e o país entra na de 2026{n('bready')}. Por isso este volume não tem medida de ambiente de negócios depois de 2020 e não compara a de 2020 com outra mais recente.</p>"""

med_so = lambda arq, campo, ano, filtro=lambda r: True: statistics.median(f(r[campo]) for r in le(arq) if r['iso3'] not in ('BRA', 'OCDE') and str(r.get('ano', r.get('edicao'))) == str(ano) and r[campo] and filtro(r))
sec_6 = f"""<h1 class="parte parte-inicio" id=parte-ii>Parte II. Condições de vida e cultura</h1>
<h2>6. Indicadores sociais</h2>
<p class="cl cl-a">O IDH do Brasil foi de {br(so(1990, 'idh_hdr2025'), 3)} em 1990 a {br(so(2023, 'idh_hdr2025'), 3)} em 2023. Entre os {IDHP[1990]['paises_painel_1990']} países que já tinham IDH em 1990, o Brasil era {IDHP[1990]['posicao_painel_1990']}º e é {IDHP[2023]['posicao_painel_1990']}º em 2023. Na lista inteira de {IDHP[2023]['paises_com_dado']} países, fica em {IDHP[2023]['posicao_entre_com_dado']}º, mais abaixo só porque a lista cresceu. O Gini do rendimento domiciliar por pessoa, pelo IBGE, foi de {br(so(2012, 'gini_ibge_pnadc'), 3)} em 2012 a {br(so(2024, 'gini_ibge_pnadc'), 3)} em 2024 e {br(so(2025, 'gini_ibge_pnadc'), 3)} em 2025{n('hdr', 'ibge_gini')}.</p>
<table><thead><tr><th>Indicador</th>{''.join(f'<th class=n>{a}</th>' for a in ANOS_SOC)}<th class=n>Último</th></tr></thead><tbody>{lin_soc}</tbody></table>
<p class=nota>PNUD, IBGE, Banco Mundial, Ipea, UNODC, OMS e UNICEF{n('hdr', 'ibge_gini', 'pip', 'wdi_vida', 'atlas', 'unodc', 'jmp')}. Último ano de cada mandato, de 2002 a 2022, e o último ano com dado entre parênteses. n/d, sem dado no ano.</p>
<p class="cl cl-a">Contra a mediana de todos os comparadores em 2024, o Gini do Banco Mundial é {br(so(2024, 'gini_bm_pip'), 1)} no Brasil e {br(med_so('SO-desigualdade-pobreza.csv', 'gini_bm_pip_0a100', 2024), 1)} na mediana, a pobreza abaixo de US$ 3 por dia {br(so(2024, 'pobreza_3usd_pct'), 1)}% e {br(med_so('SO-desigualdade-pobreza.csv', 'pobreza_3usd_ppc2021_pct', 2024), 1)}%, os homicídios {br(so(2024, 'homicidios_unodc_100mil'), 1)} e {br(med_so('SO-homicidios.csv', 'unodc_taxa_100mil', 2024), 1)} por 100 mil, o esgoto gerido com segurança {br(so(2024, 'esgotamento_seguro_pct'), 0)}% e {br(med_so('SO-saneamento.csv', 'esgotamento_seguro_pct', 2024), 0)}%, e a expectativa de vida {br(so(2024, 'expectativa_vida_anos'), 1)} e {br(med_so('SO-vida.csv', 'expectativa_vida_anos', 2024), 1)} anos. No PISA de 2022 o Brasil teve {br(PISA[('BRA', '2022', 'matematica')], 1)} em matemática, contra {br(PISA[('OCDE', '2022', 'matematica')], 1)} na média da OCDE{n('pip', 'unodc', 'jmp', 'wdi_vida', 'pisa')}.</p>
<table><thead><tr><th>2024</th><th class=n>Brasil</th><th class=n>América Latina</th><th class=n>Emergentes grandes</th><th class=n>Passaram o Brasil</th><th class=n>Todos os comparadores</th></tr></thead><tbody>{lin_grp}</tbody></table>
<p class=nota>Mediana de cada grupo e, entre parênteses, quantos países têm dado em 2024. Os que passaram o Brasil são na maioria do Leste Europeu e do Cáucaso, com homicídios e pobreza extrema baixos, e puxam a mediana geral. Por isso a comparação mais próxima é por grupo{n('pip', 'unodc', 'jmp', 'wdi_vida')}.</p>
<figure>{svg('g05-painel-social')}</figure>
<p class=nota><b>Fonte.</b> Banco Mundial (PIP e WDI), UNODC, OMS e UNICEF (JMP), OCDE (PISA){n('pip', 'unodc', 'jmp', 'wdi_vida', 'pisa')}. <b>Leitura.</b> Linhas finas são os comparadores, a preta é a mediana nos anos com pelo menos dez países, a azul é o Brasil. Cada painel tem escala própria. A mediana é de quem reporta no ano, e a composição muda.</p>
<p class="cl cl-a"><b>Homicídios, duas fontes.</b> O Atlas da Violência dá {br(so(2024, 'homicidios_atlas_100mil'), 2)} por 100 mil em 2024 e a UNODC {br(so(2024, 'homicidios_unodc_100mil'), 2)}. Ambas partem do sistema de mortalidade do Ministério da Saúde, com recortes diferentes. A comparação entre países usa a UNODC, e a série brasileira longa usa o Atlas{n('atlas', 'unodc')}.<!--HOMICIDIOS--></p>
<!--SANEAMENTO-->
<p class="cl cl-a"><b>Cultura.</b> Acesso a equipamento cultural também é condição de vida. Em 2021, {br(CUE[('Cinema', 2021)], 1)}% dos municípios tinham cinema e {br(CUE[('Museu', 2021)], 1)}% tinham museu (seção 8){n('siic')}.</p>"""

sec_7 = f"""<h2>7. Bem-estar declarado</h2>
<p class="cl cl-b">O World Happiness Report pergunta a cerca de mil pessoas por país e por ano onde estão numa escada de 0 a 10, entre a pior e a melhor vida possível, e publica a média de três anos. O Brasil teve {br(f(BE[2019]['escada_media_3_anos']), 3)} nos três anos de 2017 a 2019 ({BE[2019]['posicao']}º de {BE[2019]['paises_no_ranking']}), {br(f(BE[2022]['escada_media_3_anos']), 3)} de 2020 a 2022, com a pandemia ({BE[2022]['posicao']}º de {BE[2022]['paises_no_ranking']}), e {br(f(BE[2025]['escada_media_3_anos']), 3)} de 2023 a 2025 ({BE[2025]['posicao']}º de {BE[2025]['paises_no_ranking']}). Antes de 2019 o relatório não publica intervalo nem documenta o mesmo método, então os níveis de 2011 a 2018, como os {br(f(BE[2014]['escada_media_3_anos']), 2)} de 2012 a 2014, não se comparam com segurança aos de depois{n('whr')}.</p>
<figure>{svg('g09-bem-estar')}</figure>
<p class=nota><b>Fonte.</b> World Happiness Report 2026, Gallup World Poll{n('whr')}. <b>Leitura.</b> Cada barra horizontal é uma janela de três anos, e a faixa vertical cinza é o intervalo de 95% publicado, que existe desde 2019. Pontos vazados antes de 2019, sem ligação com os de depois. Sem faixas de governo, porque cada média cruza mandatos. Os fatores que o relatório usa para explicar a nota (renda, apoio social, vida saudável, liberdade, generosidade, corrupção) são associação estatística e não causa, por isso a seção é classe B.</p>"""

eq = lambda nome, a: br(CUE[(nome, a)], 1)
sec_8 = f"""<h2>8. Cultura como desenvolvimento</h2>
<p>A cultura entra em todas as análises deste dossiê. Aqui ela é tratada como parte do desenvolvimento, por trabalho, empresas, acesso e comércio exterior. Não há conta satélite da cultura no PIB brasileiro, então nenhuma medida abaixo é a parte da cultura no PIB.</p>
<p class="cl cl-a">O setor cultural ocupava {br(CUI[('ocupados_setor_cultural', '2014')] / 1000, 2)} milhões de pessoas em 2014 ({br(CUI[('ocupados_setor_cultural_pct', '2014')], 2)}% dos ocupados), {br(CUI[('ocupados_setor_cultural', '2020')] / 1000, 2)} milhões em 2020 e {br(CUI[('ocupados_setor_cultural', '2024')] / 1000, 2)} milhões em 2024 ({br(CUI[('ocupados_setor_cultural_pct', '2024')], 2)}%). A informalidade no setor foi de {br(CUI[('informalidade_setor_cultural', '2024')], 1)}% em 2024, acima dos {br(CUI[('informalidade_todos_setores', '2024')], 1)}% do total. O rendimento médio do setor ficou acima da média geral em todos os anos, {br(CUI[('rendimento_cultural_sobre_total', '2024')], 0)}% dela em 2024. Nas empresas pesquisadas pelo IBGE, os domínios culturais tinham {br(CUI[('empresas_valor_adicionado_dominios_culturais_pct', '2009')], 1)}% do valor adicionado em 2009 e {br(CUI[('empresas_valor_adicionado_dominios_culturais_pct', '2023')], 1)}% em 2023{n('siic')}.</p>
<p class="cl cl-a">Nos municípios, a parte com museu foi de {eq('Museu', 1999)}% em 1999 a {eq('Museu', 2021)}% em 2021, com teatro ou sala de espetáculo de {eq('Teatro ou sala de espetáculo', 1999)}% a {eq('Teatro ou sala de espetáculo', 2021)}%, com cinema de {eq('Cinema', 1999)}% a {eq('Cinema', 2021)}%, e com livraria caiu de {eq('Livrarias', 1999)}% a {eq('Livrarias', 2021)}%. A biblioteca pública chegou a {eq('Biblioteca pública', 2014)}% dos municípios em 2014 e estava em {eq('Biblioteca pública', 2021)}% em 2021{n('siic')}.</p>
<figure>{svg('g10-equipamentos-culturais')}</figure>
<p class=nota><b>Fonte.</b> IBGE, MUNIC, pelo Sistema de Informações e Indicadores Culturais{n('siic')}. <b>Leitura.</b> Presença do equipamento no município, sem medir tamanho, público ou qualidade. Os anos são os das pesquisas que perguntaram. Saltos de uma edição para outra, como o da biblioteca pública de 2014 para 2018 e o da livraria de 1999 para 2001, podem vir de mudança na pergunta do questionário, que este volume não conferiu (classe C para essas variações).</p>
<p class="cl cl-a">No comércio exterior, os bens criativos (artesanato, audiovisual, design, música gravada, publicações, artes visuais) foram {br(f(CUB[2002]['pct_das_exportacoes_de_mercadorias']), 2)}% das exportações brasileiras de mercadorias em 2002 e {br(f(CUB[2024]['pct_das_exportacoes_de_mercadorias']), 2)}% em 2024, contra mediana de {br(f(CUB[2024]['mediana_pct_das_exportacoes_comparadores']), 2)}% nos comparadores. A queda da parte não veio de queda em valor. Os bens criativos subiram de US$ {br(f(CUB[2002]['exp_bens_criativos_usd_mi']), 0)} milhões para US$ {br(f(CUB[2024]['exp_bens_criativos_usd_mi']), 0)} milhões, menos que o total exportado. Os serviços criativos foram {br(CUS[2024], 1)}% das exportações de serviços em 2024{n('unctad')}.</p>
<figure>{svg('g11-bens-criativos')}</figure>
<p class=nota><b>Fonte.</b> UNCTADstat{n('unctad')}. <b>Leitura.</b> Valores em dólares correntes. <!--QUEBRA2014--></p>"""

sec_met = f"""<h1 class=parte id=parte-iii>Parte III. Método e dados</h1>
<h2>Limites dos dados</h2>
<ul class=nota>
<li>A Penn World Table vai até 2023. O Lula 3 tem um ano de decomposição, e nenhuma leitura sobre ele sai da PTF.</li>
<li>A PTF é resíduo e carrega os erros de medida do capital, das horas e da escolaridade. A série de capital humano da PWT usa anos de estudo e retornos médios, e não mede qualidade da educação, que o PISA sugere baixa.</li>
<li>Paridade de poder de compra muda a cada rodada do Programa de Comparação Internacional. Os níveis em US$ de 2021 podem ser revistos, as ordens de grandeza e as tendências mudam menos.</li>
<li>Sete comparadores não têm decomposição na PWT. Os anos com dado variam por país e por indicador, e a mediana usa quem reporta.</li>
<li>O Doing Business acabou em 2020 e o Brasil não está no B-READY de 2025.</li>
<li>O World Happiness Report é pesquisa de opinião com amostra de cerca de mil pessoas por ano, e só é citado aqui.</li>
<li>Cultura. Não há conta satélite da cultura no PIB. A MUNIC mede presença, e não uso. A UNCTAD tem quebra de série em serviços.</li>
<li>Os nomes de governo datam os valores. Nenhuma tabela deste volume separa o efeito de cada governo do ciclo externo.</li>
</ul>
<h2>Dados e reprodução</h2>
<p>Cada frente tem uma pasta em brutos/ com o script que baixa as fontes (uma requisição por vez), a lista de downloads com URL, data e sha256, o script que monta os CSV e um LEIAME. Os CSV na raiz do pacote são as tabelas que este relatório lê, e relatorio/monta_relatorio.py refaz os gráficos, o HTML e o PDF a partir deles. As fontes tipográficas (Newsreader e Instrument Sans, licença OFL) vão no pacote.</p>
<h2>Fontes</h2>
<ol class=f>{''.join(f'<li>{FONTES[k]}</li>' for k in ORDEM)}</ol>"""

CORPO = '\n'.join([sec_capa, sec_ler, sec_ess, sec_1, sec_2, sec_3, sec_4, sec_5, sec_6, sec_7, sec_8, sec_met])
# lacunas fechadas depois (frentes SO e CU2), lidas dos CSV quando existem
HR = {int(r['ano']): r for r in le('SO-homicidios-reconciliacao.csv')}
hr = lambda a, c: f(HR[a][c])
HOM = {int(r['ano']): r for r in le('SO-homicidios.csv') if r['iso3'] == 'BRA'}
hom = lambda a, c: f(HOM[a][c])
CORPO = CORPO.replace('<!--HOMICIDIOS-->', f" A diferença é de definição. O Atlas soma as mortes por intervenção legal (CID-10 Y35), que a UNODC exclui, e cada um usa uma população. Em 2024, tirando as {br(hr(2024, 'atlas_intervencao_legal_y35'), 0)} mortes por intervenção legal, os {br(hr(2024, 'atlas_homicidios_registrados'), 0)} homicídios do Atlas viram {br(hr(2024, 'atlas_menos_intervencao_legal'), 0)}, contra {br(hr(2024, 'unodc_contagem'), 0)} na contagem da UNODC. De 2021 a 2023 as duas contagens batem exatamente{n('atlas', 'unodc')}. O Atlas também estima os homicídios ocultos entre as mortes de causa indeterminada. De 2018 para 2019 a taxa registrada caiu de {br(hom(2018, 'atlas_ipea_taxa_registrados_100mil'), 1)} para {br(hom(2019, 'atlas_ipea_taxa_registrados_100mil'), 1)}, enquanto as mortes de causa indeterminada subiram de {br(hr(2018, 'atlas_mortes_causa_indeterminada'), 0)} para {br(hr(2019, 'atlas_mortes_causa_indeterminada'), 0)} e a taxa estimada pelo Ipea caiu menos, de {br(hom(2018, 'atlas_ipea_taxa_estimados_100mil'), 1)} para {br(hom(2019, 'atlas_ipea_taxa_estimados_100mil'), 1)}. Parte da queda registrada em 2019 pode ser de classificação (a estimativa é modelo do Ipea, classe B).")
SN = {int(r['ano']): r for r in le('SO-saneamento-brasil-snis-sinisa.csv')}
QB = {r['ano']: r for r in le('CU2-servicos-brasil-quebra-2014.csv')}
sn = lambda a, c: f(SN[a][c])
CORPO = CORPO.replace('<!--SANEAMENTO-->', f"""<p class="cl cl-a"><b>Saneamento, a fonte nacional.</b> Pelo SNIS, que reúne o que os prestadores declaram, a parte da população atendida por rede de esgoto foi de {br(sn(2010, 'esgoto_atendimento_total_rede_pct'), 1)}% em 2010 a {br(sn(2022, 'esgoto_atendimento_total_rede_pct'), 1)}% em 2022, e o esgoto tratado, de {br(sn(2010, 'esgoto_tratado_referido_agua_consumida_pct'), 1)}% a {br(sn(2022, 'esgoto_tratado_referido_agua_consumida_pct'), 1)}% da água consumida. O SINISA, que substituiu o SNIS, dá {br(sn(2023, 'esgoto_atendimento_total_rede_pct'), 1)}% de rede de esgoto em 2023, mas a alta sobre 2022 vem de outro denominador, e as duas séries não se emendam. O esgoto gerido com segurança do JMP, usado na comparação entre países, mede domicílios e inclui fossa séptica adequada, por isso é outra grandeza{n('snis', 'jmp')}.</p>""")
CORPO = CORPO.replace('<!--QUEBRA2014-->', f"A série de serviços criativos do Brasil tem uma quebra em 2014. Os dados são os do Banco Central, que adotou nova codificação do câmbio em fevereiro de 2014 para o manual BPM6. Computação, audiovisual e consultoria saltam e serviços pessoais e culturais caem no mesmo ano, com o total de serviços subindo {br(100 * (f(QB['2014']['unctad_exp_servicos_total_usd_mi']) / f(QB['2013']['unctad_exp_servicos_total_usd_mi']) - 1), 1)}%. Por isso os serviços criativos só se comparam de 2014 em diante (classe B quanto à causa){n('unctad', 'bcb_bpm6')}.")
HTML = f'''<!doctype html><html lang=pt-br><head><meta charset=utf-8><title>Desenvolvimento do Brasil</title><style>
{css(os.path.join(AQUI, 'desenvolvimento-brasil.html'))}
@page {{ @bottom-left {{ content: "Desenvolvimento do Brasil · volume 2 · versão 1"; font: 400 7pt/1 'Instrument Sans', sans-serif; color: #8a8a8a; }} }}
@page :first {{ @bottom-left {{ content: none; }} }}
</style></head><body>
{CORPO}
</body></html>'''
HTML = endereca(glifos(voz_saida(HTML)))
assert '—' not in HTML
ARQ = os.path.join(AQUI, 'desenvolvimento-brasil.html'); PDF = os.path.join(AQUI, 'desenvolvimento-brasil.pdf')
def imprime(h):
  open(ARQ, 'w', encoding='utf-8').write(h)
  imprime_pdf(ARQ, PDF)  # WeasyPrint; MOTOR_PDF=chrome volta ao Chrome
import fitz
IGN = ('Desenvolvimento do Brasil', 'Sumário')
imprime(HTML.replace('<!--SUMARIO-->', sumario([], HTML, IGN)))
for _ in range(3):
  toc = fitz.open(PDF).get_toc()
  imprime(HTML.replace('<!--SUMARIO-->', sumario(toc, HTML, IGN)))
  if fitz.open(PDF).get_toc() == toc: break
print(PDF)

# estilo dos graficos do volume 2 (desenvolvimento). O sistema e comum aos dois volumes, em economia-brasil/estilo/ (base.py,
# base.css, DESIGN.md). Aqui ficam so as duas familias de cor deste volume, validadas com validate_palette.js (skill dataviz).
import os, sys
_R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
for _d in (os.path.join(_R, 'estilo'), os.path.join(_R, '..', 'estilo')):  # pacote: estilo/ ao lado de relatorio/; repo: economia-brasil/estilo
  if os.path.exists(os.path.join(_d, 'base.py')): sys.path.insert(0, _d); break
from base import *  # noqa: F401,F403

# familia Entidade: um pais ou grupo, uma cor, em todos os graficos
GRUPO = {'Brasil': BRASIL, 'America Latina': OCRE, 'emergente grande': '#1baf7a', 'passou o Brasil 2002-2025': '#6250d6',
         'referencia': TINTA}
# familia Fatores do crescimento: nunca na mesma figura que a Entidade
FATOR = {'capital': TINTA, 'trabalho': CINZA_2, 'capital_humano': CINZA_3, 'ptf': OCRE}
STYLE = dict(STYLE, **{'svg.hashsalt': 'desenvolvimento-brasil'})
mpl.rcParams.update(STYLE)

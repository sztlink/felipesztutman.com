# Auditoria adversarial do volume 2, Desenvolvimento do Brasil, versão 1

Data 24/10/2026. Auditor independente, sem participação na construção. Lido o PDF inteiro (14 páginas, página a página como imagem) e o HTML, `monta_relatorio.py`, `graficos.py`, `estilo.py`, os CSV da raiz, `comparadores.csv`, `LEIAME.md` e os LEIAME e `build_*.py` das frentes. Números refeitos a partir dos CSV e, onde deu, dos brutos (`pwt110.xlsx`, JSON do WDI, `hdr25-composite-time-series.csv`). Nenhum arquivo do volume foi editado. Os scripts de conferência ficaram fora do volume, no scratchpad da sessão.

Severidade usada. Grave, muda a conclusão de um parágrafo ou é falsa. Média, induz leitura errada mas o número está certo. Baixa, forma ou precisão.

Contagem. 9 erros, 6 vieses, 6 excessos.

## Erros

**E1. IDH, a posição não caiu porque outros subiram mais rápido (grave).** Seção 6 diz "O índice subiu e a posição caiu, porque outros países subiram mais rápido", de 69º de 141 em 1990 para 84º de 193 em 2023. No painel fixo dos 141 países que já tinham IDH em 1990, refeito de `brutos/SO/fontes/hdr25-composite-time-series.csv`, o Brasil foi de 69º para 68º em 2023 (66º em 2002, 69º em 2014). A queda de 15 posições vem inteira da entrada de 52 países na base, não de ultrapassagem. É a frase causal mais forte da Parte II e é falsa, dentro de um parágrafo marcado A.
Correção. "Entre os 141 países com IDH em 1990, o Brasil era 69º e é 68º em 2023. A posição de 84º de 193 é mais baixa porque a lista cresceu." Gerar `SO-idh-posicao-brasil.csv` com coluna de painel fixo.

**E2. EUA e Coreia comparados ao período errado (média).** Seção 2. Logo depois de "de 2010 a 2019 tirou 2,04 pontos por ano", o texto diz "No mesmo período, ela somou 0,62 ponto por ano nos EUA e 0,96 na Coreia". Esses valores são de 1990 a 2023 (`ptf_residual_pp_aa_1990_2023_pwt`). De 2010 a 2019 a PTF foi 0,28 nos EUA e 0,43 na Coreia (`CR-contabilidade-periodos.csv`, conferido no `rtfpna` bruto da PWT).
Correção. Ou "De 1990 a 2023 ela somou 0,62 ponto por ano nos EUA e 0,96 na Coreia", ou "De 2010 a 2019 somou 0,28 nos EUA e 0,43 na Coreia".

**E3. Nota da figura 6 afirma o que a seção 2 não mostra, e os dados contrariam (média).** "a seção 2 mostra que a produtividade pesou mais que o capital na diferença do Brasil". A seção 2 não compara fatores entre países. Feita a conta com `CR-contabilidade-periodos.csv` (1990 a 2023, 14 comparadores com decomposição), a diferença de contribuição do capital em relação ao Brasil é maior que a diferença de PTF em 9 dos 14 (Chile 1,94 contra 0,94, Peru 1,28 contra 0,61, Turquia 2,45 contra 0,29, Índia, Indonésia, Colômbia, México, República Dominicana, Tailândia). A PTF pesa mais só contra EUA, Uruguai, Argentina, Coreia e China.
Correção. Tirar a frase, ou trocar por "Contra EUA, Coreia, China, Uruguai e Argentina a diferença está mais na PTF. Contra Chile, Peru, Turquia, Índia e Indonésia está mais no capital (classe A como aritmética, C como explicação)".

**E4. O pico da renda relativa aos EUA foi em 2013, não em 2014 (média).** Seção 1 diz "subiu até 30,4% da americana em 2014, caiu na recessão de 2015 e 2016". O máximo da série é 31,1% em 2013 (`RP-brasil-posicao.csv` e `wdi-pib-pc-ppc.json`). Em 2014 a razão já caía. A figura 2 marca 30,4% em 2014 e deixa o ponto mais alto sem rótulo. O Essencial repete 2014. A escolha do ano coincide com o fim de mandato, o que reforça o problema de neutralidade de V3.
Correção. "subiu até 31,1% da americana em 2013, recuou em 2014 e caiu na recessão de 2015 e 2016". Rotular o máximo no gráfico.

**E5. Médias da OCDE contadas como comparadores no painel do PISA (média).** Em `graficos.py`, a função `serie` só exclui `BRA`. O `SO-pisa.csv` tem as linhas `OCDE`, `OCDE-23`, `OCDE-26` e `OCDE-35`, que entram como linhas finas e na mediana da figura 8. A mediana de 2012 sai 437,4 com elas e 418,0 sem elas. A de 2022 sai 402,8 com elas e 394,5 sem. O pico da linha preta em 2012 na figura é artefato. O texto não erra porque compara com a média da OCDE (472,4), mas o gráfico sim.
Correção. Filtrar `iso3` que comece com `OCDE` em `serie` e em `med_so`.

**E6. Posição no Doing Business apresentada como se fosse a oficial (média para leitor de mercado).** "ficou em 127º de 191 economias". É a `posicao_calculada_db17_20`, ordenação feita pelo volume sobre os escores revisados. O LEIAME da frente NE diz que o ranking oficial "não está na planilha e pode diferir". O leitor de mercado conhece o número publicado em 2019 e vai ver divergência (a própria série "como publicada" dá escore 59,08 e posição calculada 125).
Correção. "ficou na 127ª posição entre as 191 economias da planilha, posição calculada por este volume a partir dos escores revisados. O ranking oficial não está nos dados baixados."

**E7. "10 dos 11 países que passaram o Brasil" contradiz os 14 da seção 1 (baixa).** O filtro usa o grupo de `comparadores.csv`, que põe a China entre os emergentes. A China passou o Brasil e investiu 39,0%. Guiana (26,7%) e Maldivas (36,9%) têm série incompleta e investiram mais nos anos com dado.
Correção. "Dos 12 que passaram o Brasil e têm a série completa, 11 investiram mais (só a Sérvia investiu menos). Guiana e Maldivas têm série incompleta."

**E8. Fontes e notas (baixa).** A fonte 21 (UNESCO UIS) está na lista e nunca é citada. As chamadas saem fora de ordem ([4][3], [12][11], [20][17], [10][14][11][13][15]). O `LEIAME.md` da raiz, que vai no pacote, diz mediana de 1,81% e o relatório 1,80% (o certo é 1,8037, portanto 1,80).
Correção. Tirar a fonte 21 ou citá-la. Ordenar as chamadas. Corrigir o LEIAME.

**E9. Rótulo da classe na margem diverge da definição (baixa).** "Como ler" define A como "medido ou aritmética". A margem imprime "A demonstrado" e "B compatível, sem causa". Os parágrafos de homicídios em duas fontes, saneamento pela fonte nacional e os dois parágrafos de cultura das seções 4 e 6 não têm classe, contra a regra do LEIAME de classe junto de cada achado.
Correção. Margem "A medido", "B associação ou opinião". Pôr classe nos parágrafos sem marca.

## Vieses

**V1. O painel de comparadores foi escolhido pelo resultado e depois usado como régua social (relevante).** 13 dos 27 comparadores entraram por terem crescido mais que o Brasil, e 10 desses 13 são do Leste Europeu e do Cáucaso (Belarus, Sérvia, Geórgia, Macedônia do Norte, Albânia, Azerbaijão, Bósnia, Armênia), com homicídio baixo, pobreza extrema perto de zero e população pequena. Nas medianas sociais eles pesam como China ou Índia. Homicídios 2024. A mediana de 2,3 por 100 mil tem 20 países, e 11 deles estão abaixo de 2,7. A mediana dos cinco latino-americanos com dado em 2024 (Argentina, Chile, Uruguai, Colômbia e México) é 11,3. O Brasil fica acima nos dois casos, então a direção da frase do Essencial se sustenta, mas a distância (18,7 contra 2,3) é efeito de composição. Para "passou o Brasil", o painel é bom. Para "o Brasil está longe da mediana", ele exagera a distância.
Correção. Mostrar a mediana por grupo (América Latina, emergentes, passaram) ou usar um painel social definido antes do resultado (faixa de renda de 2002 ou região). Dizer na seção 6 quantos e quais países compõem cada mediana de 2024 (12 no Gini e na pobreza, 20 em homicídios, 21 em esgoto, 18 no PISA sem a OCDE).

**V2. Investimento e ultrapassagem, seleção pela variável dependente (relevante).** "10 dos 11 que passaram investiram mais" só olha quem passou. Dentro do próprio painel, dos 5 comparadores que estavam abaixo do Brasil em 2002 e não passaram, 4 também investiram mais (Colômbia 20,0, Peru 21,3, Índia 30,0, Indonésia 27,9; só a África do Sul, 16,3, investiu menos). Argentina e Uruguai investiram menos que o Brasil e continuam acima. O pacote só tem FBCF dos 28 países, então o contraste com os 96 que ficaram abaixo não pode ser feito com os dados do volume. Classe B é generosa, porque não há associação estatística calculada, só contagem num grupo escolhido pelo resultado.
Correção. Trazer o contraste dos que não passaram ou cortar a frase. Rebaixar para C ("não demonstrado") enquanto não houver o grupo de controle.

**V3. Tabela 4 nomeia presidentes em anos escolhidos (neutralidade, relevante).** Colunas "2002 (FHC)", "2014 (Dilma)", "2022 (Bolsonaro)" e "Último (Lula 3)". Faltam 2006 e 2010 (Lula 1 e 2) e 2018 (Temer). 2014 é o ano anterior à recessão em quase todas as séries. Lido em sequência, o quadro sugere melhora até Dilma, piora ou estagnação em Bolsonaro e melhora em Lula 3 (pobreza 4,8, 4,9, 3,0; homicídio 30,1, 22,0, 20,0). O mesmo padrão de anos (2014, 2022, 2025) aparece no Essencial de bem-estar e no ponto rotulado da figura 2. Nenhum número está errado, mas a escolha dos cortes faz a narrativa.
Correção. Colunas sem nome de governo, em intervalo fixo (2002, 2010, 2018, último) ou em todos os fins de mandato (2002, 2006, 2010, 2014, 2018, 2022, último). Se ficar com nomes, incluir todos.

**V4. Bem-estar datado pelo fim da janela de três anos (neutralidade, relevante).** Cada ponto do World Happiness Report é a média de três anos, datada pelo último. Na figura 9, os pontos de 2023 (janela 2021 a 2023) e 2024 (2022 a 2024) caem na faixa Lula 3 e têm dois e um ano de outro governo. O ponto de 2022 (49º), o mais baixo, é a média de 2020 a 2022, com pandemia. O ponto de 2011 cai na faixa Dilma e é quase todo de Lula 2. O resultado visual é a queda inteira dentro de Temer e Bolsonaro e a recuperação inteira dentro de Lula 3. O Essencial escolhe 2014, 2022 e 2025 e escreve "voltou a 6,63", que soa como volta ao nível de 2014 (6,98), o que não ocorreu.
Correção. Tirar as faixas de governo desta figura ou desenhar cada ponto como barra horizontal de três anos. No Essencial, "subiu para 6,63 (32º de 147) nos três anos até 2025". Dar o número de países junto de cada posição (158, 137, 147).

**V5. PTF por mandato é ciclo e erro de medida com nome de governo (média).** A coluna PTF da tabela 2 põe o resíduo anual médio ao lado de cada mandato. A PTF residual é pró-cíclica (utilização de capacidade), e o próprio LEIAME da frente CR diz "ler como ordem de grandeza e sinal, não como décimo". O valor de Bolsonaro, menos 1,6, vem de 2021 (menos 4,33) e 2022 (menos 3,07), anos em que a contribuição do trabalho oscilou de menos 7,14 para mais 7,82 com a pandemia. O de Lula 3, mais 0,7, é um ano só. O de Lula 2, mais 0,8, é boom de preços de exportação. A nota com "classe C para qualquer leitura de causa" não neutraliza uma coluna que o leitor vai ler como nota de produtividade de cada governo.
Correção. Tirar a PTF da tabela por mandato e deixar a decomposição só por período (tabela 1). Se ficar, marcar em cinza os mandatos com menos de quatro anos de PWT e os anos de pandemia.

**V6. Homicídios sem a série de ocultos do próprio Atlas (média).** O volume baixou e guardou os homicídios ocultos estimados e as mortes por causa indeterminada (`SO-homicidios-reconciliacao.csv`), mas o texto não os usa. De 2018 para 2019 os registrados caem de 28,1 para 21,9 por 100 mil, enquanto as mortes de causa indeterminada sobem de 12.310 para 16.648 e a taxa estimada do Atlas cai menos, de 30,4 para 25,2. A tabela 4 compara 30,1 em 2014 com 22,0 em 2022 só pelos registrados. Sem a ressalva, a queda de 2019 parece toda real, e ela cai num governo.
Correção. Uma frase na seção 6 com a taxa estimada (classe B, modelo do Ipea) e a alta das mortes de causa indeterminada em 2019.

## Excessos

**X1. Comparação de níveis do World Happiness Report entre 2014 e 2025 (média).** O LEIAME da frente BE diz que as linhas antes de 2019 não têm intervalo nem documentação de mesmo método e manda "ler a série como sequência de rankings, não como série homogênea". O texto compara 6,983 com 6,634 e a figura liga os pontos numa linha só. A posição muda com o número de países (158, 137, 147).
Correção. Separar visualmente 2011 a 2018 de 2019 a 2025 e dizer no texto que os níveis antes de 2019 não se comparam com segurança.

**X2. Escalas verticais curtas sob faixas de governo (baixa).** Figura 2 de 20 a 34, figura 5 de 10 a 24, figura 9 de 5,6 a 7,4 numa escala de 0 a 10. Não é erro em gráfico de linha, mas, com faixas coloridas por governo, amplia variações e convida à atribuição.
Correção. Na figura 9, eixo de 5 a 8 ou anotar a amplitude. Nas demais, manter, mas pôr o aviso de mandato também no texto, não só no rodapé do gráfico.

**X3. "a diferença é financiada de fora" (baixa).** Poupança bruta menos formação bruta de capital é o saldo em conta corrente. O volume compara a poupança com a FBCF, que deixa de fora a variação de estoques. A direção vale (poupança abaixo da FBCF em 22 de 26 anos), a identidade não é exata.
Correção. "fica abaixo do investimento em 22 dos 26 anos de 2000 a 2025, e a diferença corresponde, em grande parte, ao déficit em conta corrente".

**X4. Equipamentos culturais sem ressalva de questionário (baixa).** Biblioteca pública de 97,1% dos municípios em 2014 para 87,7% em 2018 e livraria de 35,5% em 1999 para 42,7% em 2001 e 31,0% em 2005 são saltos grandes demais para fechamento físico em quatro anos. Pode ser mudança na pergunta da MUNIC. Não verifiquei, e o volume também não.
Correção. Conferir a redação da pergunta nas edições 2001, 2014 e 2018 antes de imprimir "chegou a 97,1% e estava em 88,3%". Se mudou, dizer.

**X5. Causas sem fonte nem classe (baixa).** "A Guiana passa da escala por causa do petróleo" e "caiu na recessão de 2015 e 2016" são causais e sem classe. A primeira é amplamente conhecida, mas a regra do volume pede fonte.
Correção. "A Guiana passa da escala, com a produção de petróleo iniciada em 2019 (classe C neste volume)" ou cortar a causa.

**X6. Crescimento em média de log chamado de "% ao ano" (baixa).** Os 2,24% de 1990 a 2023 e todas as contribuições são médias de diferenças de log (a taxa composta é 2,26%). A diferença é pequena, mas o volume mistura taxa composta (tabela 2, IBGE) e média de log (tabela 1, PWT) com o mesmo rótulo.
Correção. Nota da tabela 1 "pontos de log por ano, média de Törnqvist".

## Conferidos

| # | Frase ou número | No texto | Recalculado | Arquivo |
|---|---|---|---|---|
| 1 | PIB por habitante PPC do Brasil, 2002 e 2025 | 14.266 e 20.025 | 14.265,9 e 20.024,7 | `brutos/RP/fontes/wdi-pib-pc-ppc.json`, `RP-brasil-posicao.csv` |
| 2 | Crescimento por habitante do Brasil 2002 a 2025 | 1,49% | 1,485% | `RP-pib-pc-ppc.csv` |
| 3 | Mediana do painel | 1,80% | 1,804% (LEIAME diz 1,81) | `RP-pib-pc-ppc.csv` |
| 4 | Posição no crescimento | 108º de 182 | 108º de 182 | `RP-pib-pc-ppc.csv` |
| 5 | Abaixo em 2002, passaram, ficaram atrás | 110, 14, 5 | 110, 14, 5 (mesmos países) | `RP-pib-pc-ppc.csv` |
| 6 | Posição em nível | 72º para 81º | 72º e 81º | `RP-pib-pc-ppc.csv` |
| 7 | Renda em % dos EUA, 2002, 2014, 2025 | 25,7, 30,4, 26,0 | 25,7, 30,4, 26,0. Máximo 31,1 em 2013 (ver E4) | `wdi-pib-pc-ppc.json` |
| 8 | PIB 1990 a 2023, PWT | 2,24% | 2,24 (média de log) | `brutos/CR/fontes/pwt110.xlsx` |
| 9 | PTF 1990 a 2023 e 2010 a 2019 | menos 0,83 e menos 2,04 | menos 0,83 e menos 2,04 pelo `rtfpna` bruto | `pwt110.xlsx` |
| 10 | PTF EUA e Coreia | 0,62 e 0,96 | 0,62 e 0,96 em 1990 a 2023. Em 2010 a 2019, 0,28 e 0,43 (ver E2) | `pwt110.xlsx` |
| 11 | PIB por hora, % dos EUA, Brasil 1990 e 2023 | 28,6 e 23,7 | 28,6 e 23,7 | `pwt110.xlsx` |
| 12 | Chile, Coreia e México, mesmo indicador | 24,9 a 38,4, 27,2 a 64,3, 53,9 a 33,3 | iguais | `pwt110.xlsx` |
| 13 | FBCF média 1995 a 2024, Brasil, China, Coreia | 18,0, 39,0, 31,1 | 17,99, 38,98, 31,06 | `brutos/CR/fontes/wdi-NE.GDI.FTOT.ZS.json` |
| 14 | Comparadores que investiram menos | 4 de 25 | 4 (Sérvia 17,7, Uruguai 16,9, Argentina 16,6, África do Sul 16,3) | `CR-comparadores-resumo.csv` |
| 15 | Passaram e investiram mais | 10 de 11 | 10 de 11 no filtro de grupo, 11 de 12 com a China (ver E7) | `CR-comparadores-resumo.csv` |
| 16 | Taxa de investimento IBGE, máximo, mínimo, último | 20,91 (2013), 14,56 (2017), 16,84 (2025) | iguais | `CR-brasil-ibge-anual.csv` |
| 17 | PIB por mandato, FHC a Lula 3 | 2,4, 3,5, 4,6, 1,1, 1,5, 1,4, 3,0 | 2,43, 3,51, 4,61, 1,15, 1,50, 1,40, 2,97 (taxa composta) | `CR-brasil-ibge-anual.csv` |
| 18 | PTF por mandato | menos 1,0 a 0,7 | iguais (Lula 3 com 1 ano) | `CR-brasil-ibge-anual.csv` |
| 19 | Poupança abaixo do investimento "na maior parte dos anos" | sem número | 22 de 26 anos | `CR-brasil-ibge-anual.csv` |
| 20 | Pobreza, mortalidade infantil, Gini BM, 2002 e 2024 | 16,2 e 3,0, 25,6 e 12,3, 58,1 e 50,3 | iguais | `SO-brasil-painel.csv` |
| 21 | Medianas 2024 de Gini, pobreza, homicídio, esgoto, vida | 40,0, 1,1, 2,3, 63, 77,4 | 40,05 (n 12), 1,05 (n 12), 2,30 (n 20), 63,0 (n 21), 77,42 (n 27) | `SO-desigualdade-pobreza.csv`, `SO-homicidios.csv`, `SO-saneamento.csv`, `SO-vida.csv` |
| 22 | PISA 2022 matemática, Brasil e OCDE | 378,7 e 472,4 | iguais. Mediana dos comparadores sem a OCDE 394,5 (n 18) | `SO-pisa.csv` |
| 23 | IDH e posição, 1990 e 2023 | 0,641 (69º de 141), 0,786 (84º de 193) | iguais. No painel fixo de 141, 69º e 68º (ver E1) | `hdr25-composite-time-series.csv` |
| 24 | Reconciliação de homicídios 2024 | 2.644, 42.590, 39.946, 39.625 | iguais. Diferença zero em 2021, 2022 e 2023 | `SO-homicidios-reconciliacao.csv` |
| 25 | SNIS e SINISA, esgoto | 46,2 e 56,0, tratado 37,9 e 52,2, SINISA 59,7 | iguais. Queda de atendidos de 112,8 para 111,3 milhões confirma o denominador | `SO-saneamento-brasil-snis-sinisa.csv`, LEIAME SO |
| 26 | World Happiness Report | 6,983 (16º de 158), 6,125 (49º de 137), 6,634 (32º de 147) | iguais | `BE-escada-cantril.csv` |
| 27 | Setor cultural 2024 | 5,86 mi, 5,79%, informalidade 44,6 contra 40,6, rendimento 105% | 5.862 mil, 5,787%, 44,59 e 40,61, 105,1% (102 a 111% de 2014 a 2024) | `CU2-brasil-indicadores.csv` |
| 28 | Valor adicionado cultural nas empresas | 11,2% (2009) e 8,3% (2023) | 11,23 e 8,35 | `CU2-brasil-indicadores.csv` |
| 29 | MUNIC, museu, livraria, cinema, teatro, biblioteca | 15,5 a 29,6, 35,5 a 15,0, 7,2 a 9,0, 13,7 a 23,3, 97,1 e 88,3 | iguais | `CU2-brasil-municipios-equipamentos.csv` |
| 30 | Bens criativos | 1,05% a 0,40%, US$ 631 a 1.358 mi, mediana 1,65% | 1,049 e 0,403, 630,8 e 1.358,2, mediana 1,647 (27 comparadores) | `CU2-unctad-brasil-posicao.csv`, `CU2-unctad-bens-criativos.csv` |
| 31 | Serviços criativos 2024 e quebra de 2014 | 14,8%, total de serviços mais 5,0% | 14,83%, 39.497,9 sobre 37.630,6 = mais 4,96% | `CU2-unctad-servicos-criativos.csv`, `CU2-servicos-brasil-quebra-2014.csv` |
| 32 | Doing Business 2020 e 2016 | 58,24, 127º de 191, 55,23 | iguais (posição calculada, ver E6) | `NE-doing-business.csv` |
| 33 | Patentes de residentes por milhão | 19,5 (2002) e 27,1 (2024), 46º de 121 | 19,5 e 27,1 pelo bruto | `brutos/IN/fontes/wdi-patentes-residentes.json`, `wdi-populacao.json`, `IN-brasil-posicao.csv` |
| 34 | P&D e pesquisadores | 1,05% e 1,19%, 33º de 84, 903 por milhão | 1,048, 1,194, 33 de 84, 903,2 | `IN-brasil-posicao.csv` |

Voz. Nenhum travessão, dois-pontos ou ponto e vírgula no texto corrido do HTML (fora de URLs). Nenhum nome de pessoa privada e nenhuma referência interna (casa, caminhos locais, ferramentas) no HTML ou no PDF. Os autores da PWT aparecem só na citação.

## Veredito

Os números estão certos. Dos 34 conferidos, nenhum valor impresso diverge da fonte, e a contabilidade do crescimento reproduz o `rtfpna` da PWT 11.0. O problema está nas frases e nos cortes. Antes de circular, três correções são obrigatórias. E1, a explicação da queda no IDH é falsa e o painel fixo mostra estabilidade. E3, a nota da figura 6 atribui à seção 2 uma conclusão que os dados do próprio volume contrariam. V3 e V4, a tabela social e o bem-estar escolhem anos e faixas que formam uma narrativa por governo, o oposto da regra "nome de governo data o valor". E2, E4, E5, E6 e V1, V2, V5, V6 são correções de uma linha ou de um filtro e devem entrar na mesma versão. Os excessos podem ficar para a 1.1.

Com essas correções, o volume se sustenta para leitor de mercado e de política pública. Sem elas, um leitor hostil acha em minutos o IDH e a tabela 4, e isso contamina a confiança nos números, que estão certos.

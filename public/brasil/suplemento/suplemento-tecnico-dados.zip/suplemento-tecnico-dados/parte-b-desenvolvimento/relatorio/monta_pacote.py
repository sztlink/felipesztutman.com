#!/usr/bin/env python3
# Pacote de dados do volume 2 (Desenvolvimento do Brasil): CSV, scripts, LEIAMEs, downloads.tsv, PDF e o sistema visual comum.
# Sem brutos baixados. Uso: cd /tmp && python3 -P <pacote>/relatorio/monta_pacote.py  (gera relatorio/desenvolvimento-brasil-dados.zip)
import glob, os, re, sys, zipfile
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
EST = os.path.normpath(os.path.join(RAIZ, '..', 'estilo'))
# mesma guarda do volume 1: recusa o zip se sobrar nome proprio, caminho local ou servico interno (regras locais, fora do zip)
sys.path.insert(0, os.path.join(RAIZ, '..', 'gastos-publicos', 'relatorio'))
try: from limpeza_pacote import LIMPA, PROIBIDO
except ImportError: LIMPA, PROIBIDO = [], None
TEXTO = ('.md', '.py', '.sh', '.tsv', '.txt', '.csv', '.css', '.json', '.html')
LEIAME = """Desenvolvimento do Brasil, volume 2 do dossie economia-brasil, pacote de dados

- *.csv na raiz: as tabelas que o relatorio le, uma frente por prefixo (RP renda, CR crescimento, IN inovacao, NE ambiente de
  negocios, SO social, BE bem-estar, CU2 cultura). comparadores.csv tem os 28 paises e o grupo de cada um.
- brutos/<frente>/: baixa_*.py (uma requisicao por vez), build_*.py (monta os CSV), LEIAME.md e downloads.tsv (url, data e sha256 de
  cada arquivo baixado). Os brutos nao vao no pacote.
- O World Happiness Report e citado e nao republicado: os CSV BE-*.csv ficam fora. Antes de refazer o relatorio, rode
  brutos/BE/baixa_BE.py e brutos/BE/build_BE.py.
- relatorio/monta_relatorio.py: refaz graficos, HTML e PDF a partir dos CSV (precisa de matplotlib, pymupdf e WeasyPrint 70, ou google-chrome com MOTOR_PDF=chrome).
- estilo/: sistema visual comum aos dois volumes, com as fontes Newsreader e Instrument Sans (licenca OFL).
"""
out = os.path.join(AQUI, 'desenvolvimento-brasil-dados.zip'); sobras = []
def grava(z, f, nome):
  nome = 'desenvolvimento-brasil-dados/' + nome
  if not f.endswith(TEXTO): z.write(f, nome); return
  t = open(f, encoding='utf-8').read()
  for a, b in LIMPA: t = re.sub(a, b, t)
  if PROIBIDO: sobras.extend(f'{nome}: {m.group(0)!r}' for m in PROIBIDO.finditer(t))
  z.writestr(nome, t)
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
  z.writestr('desenvolvimento-brasil-dados/LEIAME.txt', LEIAME)
  for pd in ('*.csv', '*.md', 'brutos/*/*.py', 'brutos/*/*.md', 'brutos/*/downloads.tsv', 'relatorio/*.py', 'relatorio/*.md', 'relatorio/desenvolvimento-brasil.pdf'):
    for f in sorted(glob.glob(os.path.join(RAIZ, pd))):
      r = os.path.relpath(f, RAIZ)
      # fora: a prancha (estudo do sistema visual), os CSV do World Happiness Report (planilha sem licenca de republicacao, so citavel;
      # refaca com brutos/BE/baixa_BE.py e build_BE.py) e brutos/VARIOS (documento de apoio do volume 1)
      if 'prancha' in r or r.startswith('BE-') or r.startswith('brutos/VARIOS'): continue
      grava(z, f, r)
  for pd in ('base.py', 'base.css', 'DESIGN.md', 'fontes/gera_estaticas.py', 'fontes/OFL-*.txt', 'fontes/estaticas/*.ttf'):
    for f in sorted(glob.glob(os.path.join(EST, pd))): grava(z, f, 'estilo/' + os.path.relpath(f, EST))
if sobras:
  os.remove(out); sys.exit('pacote recusado:\n' + '\n'.join(sorted(set(sobras))[:60]))
print(out, round(os.path.getsize(out) / 1e6, 1), 'MB', len(zipfile.ZipFile(out).namelist()), 'arquivos')

#!/usr/bin/env python3
# Graficos do volume 2. Le so os CSV do volume (raiz), grava SVG em relatorio/graficos/.
# Rodar de fora da pasta: cd /tmp && python3 <pacote>/relatorio/graficos.py
import csv, os, statistics, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..'); G = os.path.join(AQUI, 'graficos')
os.makedirs(G, exist_ok=True); sys.path.insert(0, AQUI)
from estilo import *

def le(arq):
  with open(os.path.join(RAIZ, arq), newline='', encoding='utf-8') as f: return list(csv.DictReader(f))
num = lambda v: float(v) if v not in ('', None) else None
grupo = {r['iso3']: r['grupo'] for r in le('comparadores.csv')}
NOME = {'BRA': 'Brasil', 'GUY': 'Guiana', 'BLR': 'Belarus', 'MUS': 'Maurício', 'SRB': 'Sérvia', 'GEO': 'Geórgia', 'MKD': 'Macedônia do Norte',
        'CHN': 'China', 'DOM': 'Rep. Dominicana', 'MDV': 'Maldivas', 'ALB': 'Albânia', 'THA': 'Tailândia', 'AZE': 'Azerbaijão',
        'BIH': 'Bósnia e Herzegovina', 'ARM': 'Armênia', 'PLW': 'Palau', 'SUR': 'Suriname', 'GAB': 'Gabão', 'LBY': 'Líbia',
        'GNQ': 'Guiné Equatorial', 'ARG': 'Argentina', 'CHL': 'Chile', 'COL': 'Colômbia', 'MEX': 'México', 'PER': 'Peru',
        'URY': 'Uruguai', 'IND': 'Índia', 'IDN': 'Indonésia', 'TUR': 'Turquia', 'ZAF': 'África do Sul', 'POL': 'Polônia',
        'KOR': 'Coreia do Sul', 'USA': 'EUA'}

# 1. Quem passou o Brasil, 2002 e 2025 (halteres, um pais por linha)
u = le('RP-ultrapassagens-2002-2025.csv')
u.sort(key=lambda r: float(r['pib_pc_2025']))
fig, ax = figura(14.0, esq=ESQ_CAT, base=0.10, topo=0.93)
TETO = 36000
for i, r in enumerate(u):
  a, b = float(r['pib_pc_2002']), float(r['pib_pc_2025']); br_ = r['iso3'] == 'BRA'
  cor = BRASIL if br_ else (GRUPO['passou o Brasil 2002-2025'] if r['sentido'] == 'passou o Brasil' else CINZA_2)
  ax.plot([a, min(b, TETO)], [i, i], color=cor, lw=1.6 if br_ else 1.0, zorder=2)
  ax.scatter([a], [i], s=16, facecolor='white', edgecolor=cor, linewidth=1.0, zorder=3)
  ax.scatter([min(b, TETO)], [i], s=18, color=cor, zorder=3)
  if b > TETO: ax.text(TETO - 400, i + 0.38, f'{br(b)} em 2025, fora da escala', va='bottom', ha='right', fontsize=6.6, color=CINZA_1)
ax.set_yticks(range(len(u))); ax.set_yticklabels([NOME[r['iso3']] for r in u])
for t, r in zip(ax.get_yticklabels(), u):
  if r['iso3'] == 'BRA': t.set_color(BRASIL); t.set_fontweight('semibold')
b0, b1 = (float(next(r for r in u if r['iso3'] == 'BRA')[k]) for k in ('pib_pc_2002', 'pib_pc_2025'))
for v, t in [(b0, 'Brasil 2002'), (b1, 'Brasil 2025')]:
  ax.axvline(v, color=BRASIL, lw=0.6, ls=(0, (2, 2)), zorder=1)
  ax.text(v, 1.0, t, transform=ax.get_xaxis_transform(), ha='center', va='bottom', fontsize=6.8, color=BRASIL)
ax.set_xlim(0, TETO); ax.grid(axis='y', visible=False); ax.grid(axis='x', visible=True); ax.spines['bottom'].set_visible(False)
ax.tick_params(axis='y', length=0); eixo_br(ax, 'x')
ax.text(0, -0.06, 'US$ internacionais de 2021 por habitante, PPC. Círculo vazio 2002, cheio 2025.\nRoxo passou o Brasil, cinza ficou atrás.',
        transform=ax.transAxes, fontsize=6.8, color=CINZA_1, va='top')
salva(fig, os.path.join(G, 'g01-quem-passou.svg'))

# 2. Renda por habitante do Brasil em % da dos EUA
p = [r for r in le('RP-brasil-posicao.csv') if r['pct_do_eua']]
x = [int(r['ano']) for r in p]; y = [float(r['pct_do_eua']) for r in p]
fig, ax = figura(7.0, topo=0.82)
faixas(ax, x[0], x[-1])
ax.plot(x, y, color=BRASIL, lw=1.6)
for a in (x[0], max(x, key=lambda a_: y[x.index(a_)]), x[-1]):
  v = y[x.index(a)]; ax.scatter([a], [v], s=14, color=BRASIL, zorder=3)
  ax.text(a + (0.4 if a == x[0] else 0), v + 0.5, f'{br(v, 1)}%', ha='left' if a == x[0] else 'center', va='bottom', fontsize=7, color=TINTA)
ax.set_ylim(20, 34); ax.set_xlim(x[0] - 0.5, x[-1] + 0.5)
ax.text(0, 1.10, '% da renda por habitante dos EUA, PPC', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g02-brasil-eua.svg'))

# 3. De onde veio o crescimento do Brasil, por periodo (PWT 11.0)
c = [r for r in le('CR-contabilidade-periodos.csv') if r['iso3'] == 'BRA' and r['periodo'] in ('1990-2000', '2000-2010', '2010-2019', '2019-2023')]
comp = [('capital', 'Capital', lambda r: num(r['contrib_capital_pp'])),
        ('trabalho', 'Trabalho (pessoas e horas)', lambda r: num(r['contrib_ocupados_pp']) + num(r['contrib_horas_pp'])),
        ('capital_humano', 'Capital humano', lambda r: num(r['contrib_capital_humano_pp'])),
        ('ptf', 'Produtividade (PTF)', lambda r: num(r['ptf_residual_pp']))]
fig, ax = figura(8.0, dir=0.72)
W = 0.52
for i, r in enumerate(c):
  pos = neg = 0
  for k, nome, f in comp:
    v = f(r); base = pos if v >= 0 else neg
    ax.bar(i, v, W, bottom=base, color=FATOR[k], edgecolor='white', linewidth=1.0, zorder=2)
    if abs(v) >= 0.45 and abs(base + v / 2 - num(r['pib_real_pct_aa'])) > 0.3:
      ax.text(i, base + v / 2, br(v, 1), ha='center', va='center', fontsize=6.6, color='white' if k in ('capital', 'ptf', 'trabalho') else TINTA)
    if v >= 0: pos += v
    else: neg += v
  pib = num(r['pib_real_pct_aa'])
  ax.scatter([i], [pib], s=22, color='white', edgecolor=TINTA, linewidth=1.2, zorder=4)
  ax.text(i + W / 2 + 0.05, pib, f'PIB {br(pib, 1)}', va='center', fontsize=7, color=TINTA)
ax.axhline(0, color=TINTA, lw=0.6, zorder=3)
ax.set_xticks(range(len(c))); ax.set_xticklabels([r['periodo'].replace('-', ' a ') for r in c]); ax.tick_params(axis='x', length=0)
ax.spines['bottom'].set_visible(False); eixo_br(ax, 'y', 0); unidade(ax, 'pontos por ano'); ax.set_ylim(-2.4, 4.1)
ult = c[-1]; pos = neg = 0
for k, nome, f in comp:  # rotulo direto a direita da ultima barra
  v = f(ult); meio = (pos if v >= 0 else neg) + v / 2
  ax.text(len(c) - 1 + W / 2 + 0.75, meio, nome, va='center', fontsize=7, color=TINTA)
  if v >= 0: pos += v
  else: neg += v
salva(fig, os.path.join(G, 'g03-decomposicao.svg'))

# 4. Investimento medio 1995-2024, pontos ordenados
r4 = sorted((r for r in le('CR-comparadores-resumo.csv') if r['fbcf_pct_pib_media_1995_2024_wdi']), key=lambda r: float(r['fbcf_pct_pib_media_1995_2024_wdi']))
fig, ax = figura(12.5, esq=ESQ_CAT, base=0.05, topo=0.95)
for i, r in enumerate(r4):
  v = float(r['fbcf_pct_pib_media_1995_2024_wdi']); cor = GRUPO.get(r['grupo'], CINZA_2); br_ = r['iso3'] == 'BRA'
  ax.plot([0, v], [i, i], color=GRADE, lw=0.8, zorder=1)
  ax.scatter([v], [i], s=30 if br_ else 18, color=cor, zorder=3)
  ax.text(v + 0.6, i, br(v, 1), va='center', fontsize=6.8, color=TINTA, fontweight='semibold' if br_ else 'normal')
ax.set_yticks(range(len(r4))); ax.set_yticklabels([NOME[r['iso3']] for r in r4]); ax.tick_params(axis='y', length=0)
for t, r in zip(ax.get_yticklabels(), r4):
  if r['iso3'] == 'BRA': t.set_color(BRASIL); t.set_fontweight('semibold')
ax.grid(axis='y', visible=False); ax.grid(axis='x', visible=True); ax.spines['bottom'].set_visible(False); ax.set_xlim(0, 44)
leg = [('Brasil', 'Brasil'), ('America Latina', 'América Latina'), ('emergente grande', 'Emergentes grandes'),
       ('passou o Brasil 2002-2025', 'Passaram o Brasil'), ('referencia', 'Referência')]
for j, (k, t) in enumerate(leg):
  ax.scatter([31], [5.5 - j * 1.1], s=18, color=GRUPO[k], clip_on=False); ax.text(32, 5.5 - j * 1.1, t, va='center', fontsize=7)
ax.text(0, 1.01, 'formação bruta de capital fixo, % do PIB, média de 1995 a 2024', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g04-investimento.svg'))

# 5. Painel social, Brasil contra a mediana dos comparadores
def serie(arq, campo, filtro=lambda r: True):
  d = {}
  for r in le(arq):
    if r['iso3'].startswith('OCDE'): continue  # medias da OCDE nao sao comparadores (auditoria v1, E5)
    if filtro(r) and r.get(campo) not in ('', None): d.setdefault(r['iso3'], {})[int(r['ano'] if 'ano' in r else r['edicao'])] = float(r[campo])
  return d
paineis = [
  ('Desigualdade, Gini (0 a 100)', serie('SO-desigualdade-pobreza.csv', 'gini_bm_pip_0a100'), 0),
  ('Pobreza, % abaixo de US$ 3 por dia', serie('SO-desigualdade-pobreza.csv', 'pobreza_3usd_ppc2021_pct'), 0),
  ('Homicídios por 100 mil (UNODC)', serie('SO-homicidios.csv', 'unodc_taxa_100mil'), 0),
  ('Expectativa de vida, anos', serie('SO-vida.csv', 'expectativa_vida_anos'), 0),
  ('Esgoto gerido com segurança, %', serie('SO-saneamento.csv', 'esgotamento_seguro_pct'), 0),
  ('PISA matemática, média', serie('SO-pisa.csv', 'media', lambda r: r['dominio'] == 'matematica'), 0),
]
fig = plt.figure(figsize=(LARG, 12.5 * CM))
for k, (tit, d, _) in enumerate(paineis):
  col, lin = k % 3, k // 3
  ax = fig.add_axes([0.06 + col * 0.33, 0.53 - lin * 0.46, 0.26, 0.32])
  anos = sorted({a for s in d.values() for a in s})
  for iso, s in d.items():
    if iso == 'BRA': continue
    xs = sorted(s); ax.plot(xs, [s[a] for a in xs], color=CINZA_3, lw=0.5, zorder=1, alpha=0.7)
  med = [(a, statistics.median(v)) for a in anos if len(v := [s[a] for i, s in d.items() if i != 'BRA' and a in s]) >= 10]
  ax.plot([a for a, _ in med], [v for _, v in med], color=TINTA, lw=1.0, zorder=2)
  b = d.get('BRA', {}); xs = sorted(b)
  ax.plot(xs, [b[a] for a in xs], color=BRASIL, lw=1.6, zorder=3, marker='o' if len(xs) < 12 else None, markersize=2.5)
  ax.set_title(tit, fontsize=7.5, pad=6); ax.tick_params(labelsize=6.8); ax.set_xlim(1990, 2025)
  ax.set_xticks([1990, 2000, 2010, 2020]); eixo_br(ax, 'y', 0)
for lx, cor, lw, t in [(0.06, BRASIL, 1.6, 'Brasil'), (0.16, TINTA, 1.0, 'mediana dos comparadores, anos com 10 países ou mais'), (0.60, CINZA_3, 0.8, 'cada comparador')]:
  fig.add_artist(plt.Line2D([lx, lx + 0.03], [0.975, 0.975], color=cor, lw=lw)); fig.text(lx + 0.037, 0.975, t, va='center', fontsize=7)
salva(fig, os.path.join(G, 'g05-painel-social.svg'))

# 6. Taxa de investimento e de poupanca, IBGE, com governos
ib = [r for r in le('CR-brasil-ibge-anual.csv') if r['taxa_investimento_fbcf_pct_pib']]
x = [int(r['ano']) for r in ib]
fig, ax = figura(7.0, topo=0.82)
faixas(ax, x[0], x[-1])
inv = [float(r['taxa_investimento_fbcf_pct_pib']) for r in ib]
pou = [(int(r['ano']), float(r['taxa_poupanca_bruta_pct_pib'])) for r in ib if r['taxa_poupanca_bruta_pct_pib']]
ax.plot(x, inv, color=BRASIL, lw=1.6); ax.plot([a for a, _ in pou], [v for _, v in pou], color=TINTA, lw=1.0)
rotulo_fim(ax, x[-1], inv[-1], f'investimento {br(inv[-1], 1)}', cor=BRASIL, peso='semibold')
rotulo_fim(ax, pou[-1][0], pou[-1][1], f'poupança {br(pou[-1][1], 1)}')
imax = max(range(len(inv)), key=lambda i: inv[i]); imin = min(range(len(inv)), key=lambda i: inv[i])
for i in (imax, imin):
  ax.scatter([x[i]], [inv[i]], s=14, color=BRASIL, zorder=3); ax.text(x[i], inv[i] + (0.5 if i == imax else -0.6), br(inv[i], 1), ha='center', va='bottom' if i == imax else 'top', fontsize=7)
ax.set_xlim(x[0] - 0.5, x[-1] + 0.5); ax.set_ylim(10, 24); eixo_br(ax, 'y')
ax.text(0, 1.10, '% do PIB, Contas Nacionais do IBGE', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g06-investimento-ibge.svg'))

# 7. PIB por hora trabalhada em % do dos EUA (PWT)
pn = {}
for r in le('CR-produtividade-niveis.csv'):
  if r['pib_por_hora_pct_eua']: pn.setdefault(r['iso3'], {})[int(r['ano'])] = float(r['pib_por_hora_pct_eua'])
fig, ax = figura(7.5, topo=0.82)
faixas(ax, 1990, 2023)
SP = (('KOR', TINTA, 1.0), ('CHL', OCRE, 1.0), ('MEX', OCRE, 1.0), ('BRA', BRASIL, 1.7))
yr = espalha([pn[i][max(pn[i])] for i, _, _ in SP], 4.5)
for (iso, cor, lw), y_ in zip(SP, yr):
  s_ = pn[iso]; xs = sorted(s_)
  ax.plot(xs, [s_[a] for a in xs], color=cor, lw=lw, ls='--' if iso == 'MEX' else '-')
  rotulo_fim(ax, xs[-1], y_, f"{NOME[iso]} {br(s_[xs[-1]], 1)}", cor=BRASIL if iso == 'BRA' else TINTA, peso='semibold' if iso == 'BRA' else 'normal')
ax.set_xlim(1989.5, 2023.5); ax.set_ylim(0, 80); eixo_br(ax, 'y')
ax.text(0, 1.10, 'PIB por hora trabalhada, % do dos EUA, PPC de 2021', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g07-produtividade-hora.svg'))

# 8. Patentes de residentes por milhao e P&D, Brasil contra a mediana mundial
ip = [r for r in le('IN-brasil-posicao.csv') if int(r['ano']) >= 1995]
fig = plt.figure(figsize=(LARG, 6.5 * CM))
for k, (campo, med, tit, d) in enumerate((('patentes_residentes_por_milhao', 'res_pm_mediana_mundial', 'Patentes de residentes por milhão de habitantes', 0),
                                          ('ped_pct_pib', 'ped_mediana_mundial', 'P&D, % do PIB', 1))):
  ax = fig.add_axes([0.20 + k * 0.42, 0.14, 0.30, 0.62])
  ax.set_title(tit, fontsize=7.5, pad=8)
  xs = [int(r['ano']) for r in ip if r[campo]]; ys = [float(r[campo]) for r in ip if r[campo]]
  xm = [int(r['ano']) for r in ip if r[med] and r[campo]]; ym = [float(r[med]) for r in ip if r[med] and r[campo]]
  ax.plot(xm, ym, color=TINTA, lw=1.0); ax.plot(xs, ys, color=BRASIL, lw=1.6)
  rotulo_fim(ax, xs[-1], ys[-1], f'Brasil {br(ys[-1], 1 if d == 0 else 2)}', cor=BRASIL, peso='semibold', dx=0.8)
  ax.set_xlim(1995, 2025); ax.set_xticks([2000, 2010, 2020]); ax.set_ylim(0, None); eixo_br(ax, 'y', d)
fig.text(0.20, 0.93, 'Azul, o Brasil. Preto, a mediana dos países com dado no ano.', fontsize=7, color=CINZA_1)
salva(fig, os.path.join(G, 'g08-inovacao.svg'))

# 9. Bem-estar declarado, escada de Cantril, media de 3 anos (WHR). Sem faixa de governo: cada media cruza mandatos (auditoria v1, V4)
be = [r for r in le('BE-escada-cantril.csv') if r['iso3'] == 'BRA']
fig, ax = figura(7.0, topo=0.84)
for r in be:
  a = int(r['ano_final_janela_3_anos']); v = float(r['escada_media_3_anos']); novo = a >= 2019
  if r['ic95_inferior']: ax.plot([a, a], [float(r['ic95_inferior']), float(r['ic95_superior'])], color=CINZA_3, lw=3.5, solid_capstyle='butt', zorder=1)
  ax.plot([a - 2.4, a + 0.4], [v, v], color=BRASIL if novo else CINZA_2, lw=1.0, alpha=0.55, zorder=2)
  ax.scatter([a], [v], s=18, facecolor=BRASIL if novo else 'white', edgecolor=BRASIL if novo else CINZA_2, linewidth=1.0, zorder=3)
  ax.text(a, v + 0.09, f"{r['posicao']}º", ha='center', va='bottom', fontsize=6.4, color=CINZA_1)
for parte in ([r for r in be if int(r['ano_final_janela_3_anos']) >= 2019],):
  ax.plot([int(r['ano_final_janela_3_anos']) for r in parte], [float(r['escada_media_3_anos']) for r in parte], color=BRASIL, lw=1.2, zorder=2)
ax.axvline(2018.5, color=CINZA_3, lw=0.6, ls=(0, (2, 2)))
ax.text(2018.6, 7.85, 'com intervalo publicado', fontsize=6.6, color=CINZA_1, va='top')
ax.set_xlim(2008, 2026); ax.set_ylim(5, 8); eixo_br(ax, 'y', 1)
ax.text(0, 1.06, 'nota média de 0 a 10, janela de três anos terminada no ano marcado, e posição no ranking', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g09-bem-estar.svg'))

# 10. Equipamentos culturais nos municipios (MUNIC)
eq = {}
for r in le('CU2-brasil-municipios-equipamentos.csv'): eq.setdefault(r['equipamento'], {})[int(r['ano'])] = float(r['valor'])
fig, ax = figura(7.5, topo=0.82)
faixas(ax, 1999, 2021)
SER = (('Biblioteca pública', 'biblioteca pública', CINZA_2), ('Livrarias', 'livraria', TINTA), ('Museu', 'museu', BRASIL),
       ('Teatro ou sala de espetáculo', 'teatro', CINZA_2), ('Cinema', 'cinema', CINZA_2))
yr = espalha([eq[nm][max(eq[nm])] for nm, _, _ in SER], 5.5)
for (nome, rot, cor), y_ in zip(SER, yr):
  s_ = eq[nome]; xs = sorted(s_)
  ax.plot(xs, [s_[a] for a in xs], color=cor, lw=1.4 if cor != CINZA_2 else 1.0, marker='o', markersize=2.5)
  rotulo_fim(ax, xs[-1], y_, f'{rot} {br(s_[xs[-1]], 0)}%', dx=0.5)
ax.set_xlim(1998.5, 2021.5); ax.set_ylim(0, 100); eixo_br(ax, 'y')
ax.text(0, 1.10, '% dos municípios com o equipamento, pesquisas MUNIC do IBGE', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g10-equipamentos-culturais.svg'))

# 11. Bens criativos, % das exportacoes de mercadorias, Brasil contra a mediana dos comparadores (UNCTAD)
uc = le('CU2-unctad-brasil-posicao.csv')
x = [int(r['ano']) for r in uc]
fig, ax = figura(6.5, topo=0.80)
faixas(ax, x[0], x[-1])
yb = [float(r['pct_das_exportacoes_de_mercadorias']) for r in uc]; ym = [float(r['mediana_pct_das_exportacoes_comparadores']) for r in uc]
ax.plot(x, ym, color=TINTA, lw=1.0); ax.plot(x, yb, color=BRASIL, lw=1.6)
rotulo_fim(ax, x[-1], yb[-1], f'Brasil {br(yb[-1], 2)}', cor=BRASIL, peso='semibold'); rotulo_fim(ax, x[-1], ym[-1], f'mediana {br(ym[-1], 2)}')
ax.set_xlim(x[0] - 0.5, x[-1] + 0.5); ax.set_ylim(0, 2.8); eixo_br(ax, 'y', 1)
ax.text(0, 1.12, 'exportações de bens criativos, % das exportações de mercadorias', transform=ax.transAxes, fontsize=7, color=CINZA_1, va='bottom')
salva(fig, os.path.join(G, 'g11-bens-criativos.svg'))
print('11 graficos')

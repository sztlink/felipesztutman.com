# Desenvolvimento do Brasil, volume 2 do dossiê

Aberto em 24/10/2026 a partir de uma leitura externa da v12.6 do dossiê fiscal (`../gastos-publicos/`). O pedido
foi entender (i) o crescimento da economia, total e por habitante, e portanto produtividade e investimento, e (ii) a evolução de
indicadores sociais básicos (IDH, Gini, PISA, saneamento, patentes, homicídios, felicidade, ambiente de negócios). Volume separado
do fiscal, com as mesmas regras.

## Regras (herdadas do volume 1)
- Número só de fonte. Todo valor sai de um arquivo baixado, com URL e sha256 em `brutos/<frente>/downloads.tsv`.
- Cultura em todas as análises.
- Nada pessoal nem da casa entra. O volume circula para fora.
- Classe de evidência A (medido), B (associação ou pesquisa de opinião), C (não demonstrado) junto de cada achado.
- Nome de governo data o valor e não atribui causa.
- Site de governo, uma requisição por vez, com pausa.
- Brutos fora do git, scripts dentro. Rodar sempre de fora da pasta (`cd /tmp && python3 -I <script>`).

## Frentes
| prefixo | tema | estado |
|---|---|---|
| RP | renda por habitante em PPC, posição do Brasil, quem passou e quem ficou atrás (Banco Mundial, WDI) | feita 24/10 |
| CR | crescimento decomposto, trabalho, capital e produtividade (Penn World Table, IBGE) e investimento (FBCF) | feita 24/10 (PWT 11.0 até 2023, IBGE até 2025) |
| SO | IDH, Gini, pobreza, PISA, saneamento, homicídios, expectativa de vida | feita 24/10; SNIS 2010-2019 e 2022 e SINISA 2023 e reconciliação Atlas x UNODC em 24/10 |
| IN | patentes e P&D (OMPI, INPI, UNESCO) | feita 24/10 (WDI, OMPI e UNESCO) |
| NE | ambiente de negócios (Doing Business até 2020, descontinuado em 2021, e B-READY) | feita 24/10 (Brasil fora do B-READY 2025, entra em 2026); Doing Business é CC BY 4.0 pela ficha do Data Catalog |
| BE | bem-estar declarado (World Happiness Report), classe B por ser pesquisa de opinião | feita 24/10 (WHR 2026; citar sim, CSV fora do pacote público sem permissão) |
| CU2 | cultura como indicador de desenvolvimento | feita 24/10 (IBGE SIIC, UNCTAD, UNESCO); quebra de 2014 nos serviços criativos documentada (BCB) |

## Relatório (versão 1, 24/10/2026)
- `relatorio/desenvolvimento-brasil.pdf` (14 páginas) e `.html`, gerados por `relatorio/monta_relatorio.py`, que roda `graficos.py`
  (11 gráficos) e lê só os CSV da raiz. Sistema visual comum ao volume 1 em `../estilo/` (DESIGN.md).
- `relatorio/monta_pacote.py` gera `relatorio/desenvolvimento-brasil-dados.zip` (CSV, scripts, LEIAMEs, downloads.tsv, PDF e estilo),
  sem os CSV BE-*.csv (World Happiness Report, só citável) e sem `brutos/VARIOS`. Teste limpo em 24/10: zip extraído em pasta vazia
  (com os BE refeitos), PDF de 14 páginas com texto igual.
- `relatorio/prancha.*` foi o estudo do sistema visual e fica fora do pacote.
- Auditoria independente em `../leituras/auditoria-desenvolvimento-v1.md`.

## Achados da frente RP (Banco Mundial, WDI, consulta de 24/10/2026, série com atualização de 08/10/2026)
- O gráfico "Countries That Overtook Brazil" confere. PIB por habitante PPC em US$ internacionais de 2021, Brasil 14.266 em 2002 e
  20.025 em 2025. Dos 110 países abaixo do Brasil em 2002 (painel de 182 com dado em todos os anos), 14 estão acima em 2025. Cinco
  que estavam acima ficaram atrás (Palau, Suriname, Gabão, Líbia, Guiné Equatorial).
- O gráfico lista só os 14 que passaram. Os outros 96 que estavam abaixo continuam abaixo.
- O Brasil cresceu 1,49% ao ano por habitante de 2002 a 2025, contra mediana de 1,80% no painel, 108º de 182.
- Em relação aos EUA, 25,7% em 2002, 30,4% em 2014 e 26,0% em 2025.

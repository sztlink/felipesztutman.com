# Frente BE, bem-estar declarado

## O que entra
- World Happiness Report 2026, planilha de dados da Figura 2.1 (`WHR26_Data_Figure_2.1.xlsx`, aba "Data for Figure 2.1 (2011–2025)"):
  escada de Cantril (0 a 10, Gallup World Poll), média de três anos, posição no ranking, limites do intervalo de confiança de 95% e
  contribuição dos seis fatores explicativos.
- Apêndice estatístico do capítulo 2 do WHR 2026 (`whr26-apendice-estatistico.pdf`), guardado como fonte de método e tamanho de amostra.
- Página Data Sharing do WHR (`whr-pagina-compartilhamento-de-dados.html`), com os termos de acesso.

## Saídas (raiz do volume)
- `BE-escada-cantril.csv`: Brasil e comparadores, por ano final da janela de três anos, escada média, IC 95%, posição e número de países
  no ranking daquele ano, com a coluna de presidente.
- `BE-brasil-fatores.csv`: Brasil, contribuição dos seis fatores e de "distopia mais resíduo" (só de 2019 em diante na planilha).

## Regra de leitura
- Classe B. Pesquisa de opinião com amostra de cerca de mil pessoas por país e ano. A Tabela 1 do apêndice dá, para o Brasil, 20 anos com
  observação entre 2005 e 2025, com 1.000 a 3.001 entrevistas por ano.
- A coluna "Year" é o último ano da janela de três anos; para 2025 o apêndice chama o ranking de "2023-2025". O ano 2013 não existe na
  planilha. As linhas anteriores a 2019 não trazem intervalo de confiança nem fatores, e a planilha não documenta se janela e método das
  edições antigas são os mesmos; ler a série como sequência de rankings, não como série homogênea.
- O número de países no ranking varia de 137 a 158; posição só junto dessa coluna.
- Diferença entre países ou anos menor que a soma das meias-larguras do IC não é distinguível.
- Os fatores são decomposição de um modelo, não medida direta; "distopia mais resíduo" é o que o modelo não explica.
- Nome de governo data o valor e não atribui causa.

## Limites e lacunas
- Série anual por país (a antiga "Data for Table 2.1") não é publicada livremente para a edição 2026; a página Data Sharing diz que só os
  dados da Figura 2.1 são de download livre e que o resto da Gallup World Poll é por pedido ou assinatura. Lacuna de série anual.
- Guiana só tem 2011 e Maldivas 2019 e 2020; Belarus e outros param em 2021.
- Licença (verificada em 24/10/2026). Nenhum arquivo do WHR traz licença aberta.
  - A página Data Sharing diz "The data we present in Figure 2.1 are available to download for free" e que o resto da Gallup World Poll é
    por pedido ou assinatura. Download livre não é licença de redistribuição.
  - O relatório (`whr26-relatorio.pdf`, página de rosto) diz "This publication may be reproduced using the following reference: Helliwell,
    J. F., Layard, R., Sachs, J. D., De Neve, J.-E., Aknin, L. B., & Wang, S. (Eds.). (2026). World Happiness Report 2026. University of
    Oxford: Wellbeing Research Centre." Isso autoriza reproduzir a publicação com a referência, e é o que cobre citar os valores do ranking.
  - A FAQ (`whr-faq.html`) não tem termos de uso. A planilha da Figura 2.1 não tem aba de licença.
  - A Gallup, dona dos dados de origem, diz na página de permissões (`gallup-permissoes.html`): "All material Gallup publishes is protected
    under copyright law and all use of Gallup's content requires Gallup's permission", pede citação com link para citar dados, e "Gallup does
    not permit its content on its websites to be continuously taken and reproduced on other non-Gallup websites, archives, research
    platforms, analytics platforms or databases". Essa página fala do conteúdo publicado pela Gallup; a planilha é publicada pelo WHR.
  - Conclusão: citar valores e gráficos próprios feitos com eles, com a referência acima e "Gallup World Poll", é permitido pelo texto do
    relatório. Republicar `BE-escada-cantril.csv` e `BE-brasil-fatores.csv` em pacote público não tem licença escrita que o autorize; não
    incluir sem pedir permissão ao WHR (pelos canais indicados na página Data Sharing). Brutos ficam fora do git.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/BE/baixa_BE.py   # baixa só o que falta em fontes/ e reescreve downloads.tsv
cd /tmp && python3 -I <pacote>/brutos/BE/build_BE.py   # lê só de fontes/ (xlsx pela biblioteca padrão) e grava BE-*.csv na raiz
```

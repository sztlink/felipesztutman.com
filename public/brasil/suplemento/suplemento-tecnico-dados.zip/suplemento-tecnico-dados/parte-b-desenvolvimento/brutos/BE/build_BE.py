#!/usr/bin/env python3
# Frente BE. Bem-estar declarado: escada de Cantril (0 a 10, Gallup World Poll) na planilha da Figura 2.1 do World Happiness Report 2026,
# media de tres anos terminando no ano da coluna Year, com posicao no ranking e intervalo de confianca de 95% (este so de 2019 em diante).
# Brasil e comparadores de comparadores.csv. Le so de fontes/ (xlsx lido com a biblioteca padrao).
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/BE/build_BE.py
import csv, os, re, zipfile, xml.etree.ElementTree as ET
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
grupo = {r['iso3']: r['grupo'] for r in csv.DictReader(open(os.path.join(SAI, 'comparadores.csv'), encoding='utf-8'))}
# Nome do pais na planilha do WHR para o codigo ISO de comparadores.csv
NOME = {'BRA': 'Brazil', 'ARG': 'Argentina', 'CHL': 'Chile', 'COL': 'Colombia', 'MEX': 'Mexico', 'PER': 'Peru', 'URY': 'Uruguay',
        'CHN': 'China', 'IND': 'India', 'IDN': 'Indonesia', 'TUR': 'Türkiye', 'ZAF': 'South Africa', 'POL': 'Poland',
        'KOR': 'Republic of Korea', 'USA': 'United States', 'GUY': 'Guyana', 'BLR': 'Belarus', 'MUS': 'Mauritius', 'SRB': 'Serbia',
        'GEO': 'Georgia', 'MKD': 'North Macedonia', 'DOM': 'Dominican Republic', 'MDV': 'Maldives', 'ALB': 'Albania', 'THA': 'Thailand',
        'AZE': 'Azerbaijan', 'BIH': 'Bosnia and Herzegovina', 'ARM': 'Armenia'}
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def primeira_aba(fonte):
  # Le a primeira aba de um .xlsx. Devolve [linhas], cada linha uma lista de valores (texto ou numero), indice = coluna.
  z = zipfile.ZipFile(fonte); ss = []
  if 'xl/sharedStrings.xml' in z.namelist():
    for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', NS): ss.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
  linhas = []
  for row in ET.fromstring(z.read('xl/worksheets/sheet1.xml')).iter('{%s}row' % NS['m']):
    L = []
    for c in row.findall('m:c', NS):
      i = 0
      for ch in re.match(r'[A-Z]+', c.get('r')).group(0): i = i * 26 + ord(ch) - 64
      t = c.get('t'); v = c.find('m:v', NS)
      if t == 's': val = ss[int(v.text)] if v is not None else None
      elif t == 'inlineStr': val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
      elif v is None or t in ('str', 'e', 'b'): val = None if v is None else v.text
      else: val = float(v.text)
      L += [None] * (i - 1 - len(L)); L.append(val)
    linhas.append(L + [None] * (13 - len(L)))
  return linhas
def presidente(a):
  for ini, fim, n in [(1990, 1992, 'Collor'), (1993, 1994, 'Itamar'), (1995, 2002, 'FHC'), (2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'),
                      (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'), (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]:
    if ini <= a <= fim: return n
  return ''
v = primeira_aba(os.path.join(F, 'whr26-dados-figura-2.1.xlsx'))
assert v[0][:6] == ['Year', 'Rank', 'Country name', 'Life evaluation (3-year average)', 'Lower whisker', 'Upper whisker'], v[0][:6]
dados = [r for r in v[1:] if isinstance(r[0], float) and r[2]]
n_ano = {}
for r in dados: n_ano[int(r[0])] = n_ano.get(int(r[0]), 0) + 1
nomes = {r[2] for r in dados}; faltam = [i for i, n in NOME.items() if n not in nomes]; assert not faltam, faltam
r3 = lambda x: round(x, 3) if isinstance(x, float) else ''
with open(os.path.join(SAI, 'BE-escada-cantril.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais_whr', 'grupo', 'ano_final_janela_3_anos', 'presidente_brasil_no_ano_final', 'escada_media_3_anos',
                                 'ic95_inferior', 'ic95_superior', 'posicao', 'paises_no_ranking'])
  por = {n: i for i, n in NOME.items()}
  for r in sorted((r for r in dados if r[2] in por), key=lambda r: (list(NOME).index(por[r[2]]), r[0])):
    a = int(r[0]); w.writerow([por[r[2]], r[2], grupo[por[r[2]]], a, presidente(a), r3(r[3]), r3(r[4]), r3(r[5]), int(r[1]), n_ano[a]])
# Contribuicoes dos seis fatores, so para o Brasil (a planilha traz de 2019 em diante)
with open(os.path.join(SAI, 'BE-brasil-fatores.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['ano_final_janela_3_anos', 'escada_media_3_anos', 'pib_pc_log', 'apoio_social', 'expectativa_vida_saudavel',
                                 'liberdade_de_escolha', 'generosidade', 'percepcao_de_corrupcao', 'distopia_mais_residuo'])
  for r in sorted((r for r in dados if r[2] == 'Brazil' and isinstance(r[6], float)), key=lambda r: r[0]): w.writerow([int(r[0])] + [r3(x) for x in r[3:4] + r[6:13]])
print(len(dados), sorted(n_ano.items()))

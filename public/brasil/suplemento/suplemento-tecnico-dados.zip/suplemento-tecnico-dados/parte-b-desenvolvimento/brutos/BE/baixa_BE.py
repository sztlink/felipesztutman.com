#!/usr/bin/env python3
# Frente BE. Baixa do World Happiness Report 2026 a planilha de dados da Figura 2.1 (medias de tres anos da escada de Cantril, Gallup
# World Poll, com intervalo de confianca de 95%), o apendice estatistico do capitulo 2 e a pagina de compartilhamento de dados (termos).
# Uma requisicao por vez, com pausa. Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/BE/baixa_BE.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'}
W = 'https://files.worldhappiness.report'
ALVOS = [
  ('whr26-dados-figura-2.1.xlsx', 'World Happiness Report 2026, dados da Figura 2.1 (escada de Cantril, media de tres anos, IC 95%, seis fatores)',
   W + '/WHR26_Data_Figure_2.1.xlsx'),
  ('whr26-apendice-estatistico.pdf', 'World Happiness Report 2026, apendice estatistico do capitulo 2', W + '/WHR26_Statistical_Appendix.pdf'),
  ('whr26-relatorio.pdf', 'World Happiness Report 2026, relatorio completo (pagina de rosto com a regra de reproducao com citacao)', W + '/WHR26.pdf'),
  ('whr-faq.html', 'World Happiness Report, FAQ (metodo, amostra, sem termos de licenca)', 'https://www.worldhappiness.report/faq/'),
  ('gallup-permissoes.html', 'Gallup, pagina Gallup Permissions (como usar e citar conteudo e dados da Gallup)',
   'https://www.gallup.com/corporate/198173/gallup-permissions.aspx'),
  ('whr-pagina-compartilhamento-de-dados.html', 'World Happiness Report, pagina Data Sharing (o que e livre, o que e por pedido ou assinatura Gallup)',
   'https://www.worldhappiness.report/data-sharing/'),
]
linhas = []
for arq, desc, url in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    open(dst, 'wb').write(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=600).read()); time.sleep(3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

# Frente CR, crescimento decomposto, produtividade e investimento

Montada em 24/10/2026. Brasil de 1990 ao último ano com dado, e os 28 países de `../../comparadores.csv`.

## O que entra
| fonte | versão | o que dá | período |
|---|---|---|---|
| Penn World Table 11.0 (GGDC, Groningen, dataverse.nl, doi:10.34894/FABVLR), CC BY 4.0 | publicada 07/10/2025, versão 2 do dataset no dataverse (10/10/2025) | PIB real a preços nacionais constantes (rgdpna), ocupados (emp), horas por ocupado (avh), capital humano (hc), serviços de capital (rkna), estoque de capital (rnna), participação do trabalho (labsh), PTF (rtfpna) | 1990 a 2023 |
| IBGE, SIDRA 1846 (contas trimestrais, valores correntes) | consulta de 24/10/2026 | PIB e FBCF correntes, somados nos 4 trimestres para a taxa de investimento anual | 1996 a 2025 |
| IBGE, SIDRA 5932 (contas trimestrais, volume) | idem | crescimento real anual do PIB e da FBCF (taxa acumulada no ano, 4º trimestre) | 1996 a 2025 |
| IBGE, SIDRA 2072 (contas econômicas trimestrais) | idem | poupança bruta e PIB, somados no ano | 2000 a 2025 |
| IBGE, SIDRA 6784 (contas nacionais anuais) | idem | crescimento real do PIB e do PIB per capita, população | 1996 a 2023 |
| Banco Mundial, WDI (NY.GDP.MKTP.KD.ZG, NY.GDP.PCAP.KD.ZG, NE.GDI.FTOT.ZS, NY.GNS.ICTR.ZS, SL.GDP.PCAP.EM.KD) | atualização de 08/10/2026 | crescimento, crescimento por habitante, FBCF % do PIB, poupança bruta % do PIB, PIB por ocupado | 1990 a 2025 |
| The Conference Board, Total Economy Database | edição de outubro de 2026 | só registrada, ver lacunas | — |

URLs e sha256 em `downloads.tsv`.

## Arquivos gerados (raiz do volume)
- `CR-contabilidade-anual.csv`: contabilidade do crescimento ano a ano, por país.
- `CR-contabilidade-periodos.csv`: médias anuais em 1990-2000, 2000-2010, 2010-2019, 2019-2023, 1990-2023, 2002-2023 e 2014-2023.
- `CR-produtividade-niveis.csv`: PIB por ocupado e por hora (PWT), horas, capital humano, PTF, capital por ocupado, % dos EUA, e PIB por ocupado do WDI.
- `CR-crescimento-investimento-anual.csv`: crescimento do PIB e do PIB por habitante, FBCF e poupança em % do PIB (WDI), e crescimento do PIB pela PWT.
- `CR-comparadores-resumo.csv`: crescimento composto 1990-2025, 2002-2025 e 2014-2025, FBCF média 1995-2024 e 2015-2024, poupança média 2015-2024, PTF e produtividade 1990-2023.
- `CR-brasil-ibge-anual.csv`: Brasil pelo IBGE, com a fonte de cada linha de crescimento, mais FBCF do WDI e a decomposição PWT.
- `CR-brasil-mandatos.csv`: médias por mandato.

Todas as tabelas anuais têm a coluna `presidente_brasil` (Collor 1990-1992, Itamar 1993-1994, FHC 1995-2002, Lula 1 2003-2006, Lula 2
2007-2010, Dilma 2011-2015, Dilma/Temer 2016, Temer 2017-2018, Bolsonaro 2019-2022, Lula 3 2023-2026). Nome de governo data o valor e
não atribui causa. O ano de crescimento t é atribuído a quem governou em t.

## Regra de leitura
- Contabilidade do crescimento no método da PWT 11.0 (Törnqvist). Em diferença de log, em pontos percentuais por ano:
  Δln PIB = (1−s)·Δln K + s·(Δln ocupados + Δln horas + Δln capital humano) + Δln PTF, com s = média de labsh em t−1 e t e K = serviços de capital (rkna).
  O resíduo calculado aqui reproduz o `rtfpna` da própria PWT 11.0 em todos os 685 pares país-ano com horas (diferença máxima 0,0 pp, conferida no build).
- A PWT 11.0 passou a incluir horas no insumo trabalho. A coluna `ptf_residual_sem_horas_pp` é a variante com trabalho = ocupados × capital humano, para comparar com estudos que não usam horas.
- Médias de período e de mandato da decomposição são médias simples das diferenças anuais de log. Crescimento por mandato (IBGE) é taxa composta anual.
- Taxa de investimento do IBGE = soma da FBCF corrente dos 4 trimestres sobre a soma do PIB corrente. Bate com o WDI até a segunda casa em 1996-2025.
- Crescimento do PIB do Brasil: SIDRA 6784 (anual) até 2023, SIDRA 5932 (trimestral, acumulado no ano) em 2024 e 2025, WDI antes de 1996. PIB per capita: 6784 até 2023, WDI em 1990-1995 e 2024-2025. A coluna `fonte_pib` diz qual.
- Níveis de produtividade em US$ de 2021 a preços nacionais constantes (rgdpna/emp). A % dos EUA é ancorada na PPC de 2021 e segue o crescimento das contas nacionais de cada país; a PWT também traz rgdpo (PPC encadeada, "output-side"), não usada aqui.

## Classe de evidência
- Crescimento, FBCF, poupança, ocupados e horas: A (medido pelas contas nacionais e pesquisas de emprego).
- Decomposição do crescimento: A como aritmética, mas o resultado depende de hipóteses. A participação do capital é 1 − labsh (estimativa da PWT da
  remuneração do trabalho no PIB), o capital é estoque construído com uma taxa de depreciação suposta
  (delta médio do Brasil 4,3% em 1990 e 4,9% em 2023 na PWT), e o capital humano vem de anos de estudo com retornos supostos. A PTF é
  resíduo: carrega erro de medida, utilização de capacidade, ciclo e qualidade de dados. Ler como ordem de grandeza e sinal, não como décimo.

## Limites e lacunas
- The Conference Board Total Economy Database (outubro de 2026) tem a mesma decomposição, mas a página registra que os dados são para
  uso pessoal e não comercial, sem "reproduction, redistribution, ... publication, ... public posting, creation of derivative works" sem
  permissão escrita. Não foi baixada nem entra nos CSV. A página foi guardada em `fontes/ted-pagina.html` só como registro da licença.
- PWT 11.0 termina em 2023. A decomposição não cobre 2024 e 2025; o mandato Lula 3 tem só 2023 na PWT.
- PWT sem horas (avh) para ALB, ARM, MUS, POL, SRB, ZAF: sem PTF com horas, só a variante sem horas e o rtfpna da PWT.
  Sem labsh ou capital humano para AZE, BIH, BLR, GEO, GUY, MDV, MKD: sem decomposição, só níveis de PIB por ocupado.
- IBGE trimestral começa em 1996 e a poupança em 2000; 1990-1995 do Brasil vem só do WDI e da PWT. A série retropolada do IBGE para antes de 1996 não foi buscada.
- SIDRA 6784 (anual definitiva) vai até 2023; 2024 e 2025 são da série trimestral e podem ser revistos.
- WDI sem FBCF para GUY 2006-2025, MDV até 2013 e vários países em 2025; as médias de FBCF usam 1995-2024 e ficam vazias onde falta ano.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/CR/baixa_CR.py
cd /tmp && python3 -I <pacote>/brutos/CR/build_CR.py
```
O download pula arquivo que já existe em `fontes/` (apagar para rebaixar) e faz uma requisição por vez com pausa de 3 s.
O build lê o xlsx da PWT só com biblioteca padrão (zipfile e xml).

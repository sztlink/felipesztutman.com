#!/usr/bin/env python3
# Frente CR. Crescimento do PIB total e por habitante, contabilidade do crescimento (trabalho, capital humano, capital, PTF),
# produtividade do trabalho e investimento (FBCF % do PIB), Brasil e comparadores. Le so de brutos/CR/fontes/.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CR/build_CR.py
import csv, json, math, os, re, zipfile, xml.etree.ElementTree as ET
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
le = lambda a: json.load(open(os.path.join(F, a), encoding='utf-8'))
COMP = [(r['iso3'], r['grupo']) for r in csv.DictReader(open(os.path.join(SAI, 'comparadores.csv'), encoding='utf-8'))]
GRUPO = dict(COMP); PAISES = [i for i, _ in COMP]

# Presidente do Brasil por ano (nome de governo data o valor, nao atribui causa)
MANDATOS = [('Collor', 1990, 1992), ('Itamar', 1993, 1994), ('FHC', 1995, 2002), ('Lula 1', 2003, 2006), ('Lula 2', 2007, 2010),
            ('Dilma', 2011, 2015), ('Dilma/Temer', 2016, 2016), ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2026)]
def presidente(a):
  for n, i, f in MANDATOS:
    if i <= a <= f: return n
  return ''
r1 = lambda x, n=2: '' if x is None else round(x, n)

# --- PWT 11.0, leitura do xlsx so com biblioteca padrao
z = zipfile.ZipFile(os.path.join(F, 'pwt110.xlsx')); N = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
ss = [''.join(t.text or '' for t in si.iter(N + 't')) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).iter(N + 'si')]
def linhas(sheet):
  for ev, el in ET.iterparse(z.open(f'xl/worksheets/{sheet}.xml')):
    if el.tag == N + 'row':
      r = {}
      for c in el.iter(N + 'c'):
        col = re.match(r'[A-Z]+', c.get('r')).group(); v = c.find(N + 'v'); t = c.get('t')
        if t == 'inlineStr': r[col] = ''.join(x.text or '' for x in c.iter(N + 't'))
        elif v is not None: r[col] = ss[int(v.text)] if t == 's' else v.text
      yield r; el.clear()
pwt, hdr, nomes = {}, None, {}
for r in linhas('sheet3'):
  if hdr is None: hdr = r; continue
  d = {hdr[k]: v for k, v in r.items()}
  if d.get('countrycode') not in GRUPO: continue
  nomes[d['countrycode']] = d['country']
  num = {}
  for k in ('rgdpna', 'pop', 'emp', 'avh', 'hc', 'rnna', 'rkna', 'rtfpna', 'labsh', 'delta'):
    try: num[k] = float(d[k])
    except (KeyError, ValueError, TypeError): num[k] = None
  pwt[(d['countrycode'], int(float(d['year'])))] = num

# --- WDI
def wdi(cod):
  s = {}
  for r in le(f'wdi-{cod}.json')[1]:
    if r['value'] is not None: s[(r['countryiso3code'], int(r['date']))] = r['value']
    nomes.setdefault(r['countryiso3code'], r['country']['value'])
  return s
W = {c: wdi(c) for c in ('NY.GDP.MKTP.KD.ZG', 'NY.GDP.PCAP.KD.ZG', 'NE.GDI.FTOT.ZS', 'NY.GNS.ICTR.ZS', 'SL.GDP.PCAP.EM.KD')}
ANO0 = 1990

# --- Contabilidade do crescimento a la PWT 11.0 (Tornqvist): dln Y = (1-s) dln K + s (dln emp + dln avh + dln hc) + dln PTF, s = labsh medio
# de t e t-1, K = servicos de capital (rkna). Este residuo reproduz o rtfpna da PWT 11.0 (conferido no fim). Variante sem horas: trabalho = emp * hc.
def dl(a, b): return 100 * math.log(b / a) if a and b else None
cont = {}
for i in PAISES:
  for a in range(ANO0 + 1, 2024):
    p0, p1 = pwt.get((i, a - 1)), pwt.get((i, a))
    if not p0 or not p1 or None in (p0['rgdpna'], p1['rgdpna'], p0['rkna'], p1['rkna'], p0['emp'], p1['emp'], p0['hc'], p1['hc'], p0['labsh'], p1['labsh']): continue
    s = (p0['labsh'] + p1['labsh']) / 2
    gy, gk, ge, gh = dl(p0['rgdpna'], p1['rgdpna']), dl(p0['rkna'], p1['rkna']), dl(p0['emp'], p1['emp']), dl(p0['hc'], p1['hc'])
    gv = dl(p0['avh'], p1['avh']) if p0['avh'] and p1['avh'] else None
    c = {'s': s, 'gy': gy, 'gpop': dl(p0['pop'], p1['pop']), 'ck': (1 - s) * gk, 'ce': s * ge, 'ch': s * gh, 'ptf_sh': gy - (1 - s) * gk - s * ge - s * gh,
         'cv': s * gv if gv is not None else None, 'gtfp_pwt': dl(p0['rtfpna'], p1['rtfpna']), 'gk_estoque': dl(p0['rnna'], p1['rnna']),
         'gyl': gy - ge, 'gyh': gy - ge - gv if gv is not None else None}
    c['ptf'] = c['ptf_sh'] - c['cv'] if gv is not None else None
    cont[(i, a)] = c

def nm(i): return nomes.get(i, i)
with open(os.path.join(SAI, 'CR-contabilidade-anual.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['iso3', 'pais', 'grupo', 'ano', 'presidente_brasil', 'pib_real_dln_pct', 'participacao_trabalho_labsh', 'contrib_capital_pp', 'contrib_ocupados_pp',
              'contrib_horas_pp', 'contrib_capital_humano_pp', 'ptf_residual_pp', 'ptf_residual_sem_horas_pp', 'ptf_pwt_rtfpna_dln_pct',
              'estoque_capital_rnna_dln_pct', 'pib_por_ocupado_dln_pct', 'pib_por_hora_dln_pct', 'populacao_dln_pct'])
  for (i, a) in sorted(cont):
    c = cont[(i, a)]
    w.writerow([i, nm(i), GRUPO[i], a, presidente(a), r1(c['gy']), r1(c['s'], 3), r1(c['ck']), r1(c['ce']), r1(c['cv']), r1(c['ch']), r1(c['ptf']), r1(c['ptf_sh']),
                r1(c['gtfp_pwt']), r1(c['gk_estoque']), r1(c['gyl']), r1(c['gyh']), r1(c['gpop'])])

# Niveis de produtividade do trabalho (PWT, US$ de 2021 a precos nacionais constantes) e insumos
with open(os.path.join(SAI, 'CR-produtividade-niveis.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['iso3', 'pais', 'grupo', 'ano', 'presidente_brasil', 'pib_por_ocupado_usd2021', 'pib_por_hora_usd2021', 'horas_por_ocupado_ano', 'ocupados_milhoes',
              'indice_capital_humano', 'ptf_rtfpna_2021_1', 'capital_por_ocupado_usd2021', 'pib_por_ocupado_pct_eua', 'pib_por_hora_pct_eua',
              'pib_por_ocupado_wdi_ppc2021'])
  for (i, a) in sorted(pwt):
    if a < ANO0: continue
    p = pwt[(i, a)]
    if not p['rgdpna'] or not p['emp']: continue
    yl = 1e6 * p['rgdpna'] / (1e6 * p['emp']); yh = yl / p['avh'] if p['avh'] else None
    u = pwt.get(('USA', a)); ul = u['rgdpna'] / u['emp'] if u and u['emp'] else None; uh = ul / u['avh'] if ul and u['avh'] else None
    w.writerow([i, nm(i), GRUPO[i], a, presidente(a), round(yl), r1(yh), p['avh'] or '', r1(p['emp'], 3), r1(p['hc'], 3), r1(p['rtfpna'], 4),
                round(p['rnna'] / p['emp']) if p['rnna'] else '', r1(100 * yl / ul, 1) if ul else '', r1(100 * yh / uh, 1) if yh and uh else '',
                round(W['SL.GDP.PCAP.EM.KD'][(i, a)]) if (i, a) in W['SL.GDP.PCAP.EM.KD'] else ''])

# Periodos (medias anuais de diferencas em log entre os niveis do ano inicial e final)
PERIODOS = [(1990, 2000), (2000, 2010), (2010, 2019), (2019, 2023), (1990, 2023), (2002, 2023), (2014, 2023)]
def media(i, a0, a1, k):
  v = [cont[(i, a)][k] for a in range(a0 + 1, a1 + 1) if (i, a) in cont and cont[(i, a)][k] is not None]
  return sum(v) / len(v) if len(v) == a1 - a0 else None
with open(os.path.join(SAI, 'CR-contabilidade-periodos.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['iso3', 'pais', 'grupo', 'periodo', 'anos', 'pib_real_pct_aa', 'contrib_capital_pp', 'contrib_ocupados_pp', 'contrib_horas_pp', 'contrib_capital_humano_pp',
              'ptf_residual_pp', 'ptf_residual_sem_horas_pp', 'pib_por_ocupado_pct_aa', 'pib_por_hora_pct_aa', 'populacao_pct_aa'])
  for i in PAISES:
    for a0, a1 in PERIODOS:
      if media(i, a0, a1, 'gy') is None: continue
      w.writerow([i, nm(i), GRUPO[i], f'{a0}-{a1}', a1 - a0] + [r1(media(i, a0, a1, k)) for k in ('gy', 'ck', 'ce', 'cv', 'ch', 'ptf', 'ptf_sh', 'gyl', 'gyh', 'gpop')])

# --- Crescimento e investimento anual, WDI (todos) mais PWT
with open(os.path.join(SAI, 'CR-crescimento-investimento-anual.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['iso3', 'pais', 'grupo', 'ano', 'presidente_brasil', 'pib_real_cresc_pct_wdi', 'pib_pc_real_cresc_pct_wdi', 'fbcf_pct_pib_wdi', 'poupanca_bruta_pct_pib_wdi',
              'pib_real_cresc_pct_pwt'])
  for i in PAISES:
    for a in range(ANO0, 2026):
      v = [W[c].get((i, a)) for c in ('NY.GDP.MKTP.KD.ZG', 'NY.GDP.PCAP.KD.ZG', 'NE.GDI.FTOT.ZS', 'NY.GNS.ICTR.ZS')]
      p0, p1 = pwt.get((i, a - 1)), pwt.get((i, a))
      gp = 100 * (p1['rgdpna'] / p0['rgdpna'] - 1) if p0 and p1 and p0['rgdpna'] and p1['rgdpna'] else None
      if all(x is None for x in v) and gp is None: continue
      w.writerow([i, nm(i), GRUPO[i], a, presidente(a)] + [r1(x) for x in v] + [r1(gp)])

# Resumo por pais: crescimento composto e investimento medio
def comp(s, i, a0, a1):
  v = [s.get((i, a)) for a in range(a0 + 1, a1 + 1)]
  if None in v: return None
  p = 1.0
  for x in v: p *= 1 + x / 100
  return 100 * (p ** (1 / len(v)) - 1)
def med(s, i, a0, a1):
  v = [s.get((i, a)) for a in range(a0, a1 + 1)]
  return None if None in v else sum(v) / len(v)
with open(os.path.join(SAI, 'CR-comparadores-resumo.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['iso3', 'pais', 'grupo', 'pib_real_pct_aa_1990_2025_wdi', 'pib_pc_pct_aa_1990_2025_wdi', 'pib_pc_pct_aa_2002_2025_wdi', 'pib_pc_pct_aa_2014_2025_wdi',
              'fbcf_pct_pib_media_1995_2024_wdi', 'fbcf_pct_pib_media_2015_2024_wdi', 'poupanca_pct_pib_media_2015_2024_wdi',
              'ptf_residual_pp_aa_1990_2023_pwt', 'pib_por_ocupado_pct_aa_1990_2023_pwt', 'pib_por_hora_pct_aa_1990_2023_pwt'])
  G, P, I, S = W['NY.GDP.MKTP.KD.ZG'], W['NY.GDP.PCAP.KD.ZG'], W['NE.GDI.FTOT.ZS'], W['NY.GNS.ICTR.ZS']
  for i in PAISES:
    w.writerow([i, nm(i), GRUPO[i], r1(comp(G, i, 1990, 2025)), r1(comp(P, i, 1990, 2025)), r1(comp(P, i, 2002, 2025)), r1(comp(P, i, 2014, 2025)),
                r1(med(I, i, 1995, 2024), 1), r1(med(I, i, 2015, 2024), 1), r1(med(S, i, 2015, 2024), 1),
                r1(media(i, 1990, 2023, 'ptf')), r1(media(i, 1990, 2023, 'gyl')), r1(media(i, 1990, 2023, 'gyh'))])

# --- Brasil pelo IBGE
def sidra(a):
  out = {}
  for v in le(a):
    for r in v['resultados']:
      cat = list(r['classificacoes'][0]['categoria'].values())[0] if r['classificacoes'] else v['variavel']
      out[(v['id'], cat)] = {k: float(x) for k, x in r['series'][0]['serie'].items() if x not in ('-', '...', 'X', '..')}
  return out
q = sidra('sidra-1846-pib-fbcf-correntes.json'); vq = sidra('sidra-5932-variacao-volume.json'); sv = sidra('sidra-2072-poupanca.json'); an = sidra('sidra-6784-pib-anual.json')
pibq, fbq = q[('585', 'PIB a preços de mercado')], q[('585', 'Formação bruta de capital fixo')]
pibs, poup = sv[('933', 'Produto Interno Bruto')], sv[('940', '(=) Poupança bruta')]
gvol, fvol = vq[('6563', 'PIB a preços de mercado')], vq[('6563', 'Formação bruta de capital fixo')]
ga, gpa, popa = an[('9810', 'PIB - variação em volume')], an[('9814', 'PIB per capita - variação em volume')], an[('93', 'População residente')]
def anual(s, a):
  v = [s.get(f'{a}0{t}') for t in range(1, 5)]
  return None if None in v else sum(v)
ibge = {}
for a in range(1990, 2026):
  pa, fa, sa, pb = anual(pibq, a), anual(fbq, a), anual(poup, a), anual(pibs, a)
  g = ga.get(str(a)); fg = '6784' if g is not None else ''
  if g is None and f'{a}04' in gvol: g, fg = gvol[f'{a}04'], '5932 (trimestral, acumulado no ano)'
  if g is None and ('BRA', a) in W['NY.GDP.MKTP.KD.ZG']: g, fg = W['NY.GDP.MKTP.KD.ZG'][('BRA', a)], 'WDI NY.GDP.MKTP.KD.ZG'
  gp = gpa.get(str(a)); fgp = '6784' if gp is not None else ''
  if gp is None and ('BRA', a) in W['NY.GDP.PCAP.KD.ZG']: gp, fgp = W['NY.GDP.PCAP.KD.ZG'][('BRA', a)], 'WDI NY.GDP.PCAP.KD.ZG'
  ibge[a] = dict(g=g, fg=fg, gp=gp, fgp=fgp, inv=100 * fa / pa if pa and fa else None, poup=100 * sa / pb if sa and pb else None,
                 fv=fvol.get(f'{a}04'), pop=popa.get(str(a)), pib=pa)
with open(os.path.join(SAI, 'CR-brasil-ibge-anual.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['ano', 'presidente', 'pib_real_cresc_pct', 'fonte_pib', 'pib_pc_real_cresc_pct', 'fonte_pib_pc', 'fbcf_volume_cresc_pct', 'taxa_investimento_fbcf_pct_pib',
              'taxa_poupanca_bruta_pct_pib', 'pib_corrente_milhoes_reais', 'populacao_mil_6784', 'fbcf_pct_pib_wdi', 'contrib_capital_pp_pwt', 'contrib_trabalho_horas_e_capital_humano_pp_pwt',
              'ptf_residual_pp_pwt', 'pib_por_ocupado_dln_pct_pwt'])
  for a in range(1990, 2026):
    b, c = ibge[a], cont.get(('BRA', a))
    w.writerow([a, presidente(a), r1(b['g'], 1), b['fg'], r1(b['gp']), b['fgp'], r1(b['fv'], 1), r1(b['inv']), r1(b['poup']), round(b['pib']) if b['pib'] else '',
                round(b['pop']) if b['pop'] else '', r1(W['NE.GDI.FTOT.ZS'].get(('BRA', a))),
                r1(c['ck']) if c else '', r1(c['ce'] + c['cv'] + c['ch']) if c and c['cv'] is not None else '', r1(c['ptf']) if c else '', r1(c['gyl']) if c else ''])

# Medias por mandato, Brasil
def mm(xs):
  xs = [x for x in xs if x is not None]
  return (sum(xs) / len(xs), len(xs)) if xs else (None, 0)
def cmp(xs):
  xs = [x for x in xs if x is not None]
  if not xs: return None
  p = 1.0
  for x in xs: p *= 1 + x / 100
  return 100 * (p ** (1 / len(xs)) - 1)
with open(os.path.join(SAI, 'CR-brasil-mandatos.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['mandato', 'anos', 'anos_com_pib', 'pib_real_pct_aa_composto', 'pib_pc_pct_aa_composto', 'fbcf_volume_pct_aa_composto', 'taxa_investimento_media_pct_pib',
              'anos_com_investimento', 'taxa_poupanca_media_pct_pib', 'anos_com_poupanca', 'contrib_capital_pp_pwt', 'contrib_ocupados_pp_pwt', 'contrib_horas_pp_pwt', 'contrib_capital_humano_pp_pwt',
              'ptf_residual_pp_pwt', 'pib_por_ocupado_pct_aa_pwt', 'anos_com_pwt'])
  for n, i0, i1 in MANDATOS:
    anos = [a for a in range(i0, i1 + 1) if a in ibge]
    inv, ni = mm([ibge[a]['inv'] for a in anos]); po, npo = mm([ibge[a]['poup'] for a in anos])
    cs = [cont[('BRA', a)] for a in anos if ('BRA', a) in cont]
    avg = lambda k: (sum(c[k] for c in cs) / len(cs)) if cs and all(c[k] is not None for c in cs) else None
    w.writerow([n, f'{i0}-{min(i1, 2025)}', sum(ibge[a]['g'] is not None for a in anos), r1(cmp([ibge[a]['g'] for a in anos])), r1(cmp([ibge[a]['gp'] for a in anos])),
                r1(cmp([ibge[a]['fv'] for a in anos])), r1(inv), ni, r1(po), npo, r1(avg('ck')), r1(avg('ce')), r1(avg('cv')), r1(avg('ch')), r1(avg('ptf')), r1(avg('gyl')), len(cs)])

# Conferencia: residuo proprio x rtfpna da PWT
dif = [abs(c['ptf'] - c['gtfp_pwt']) for c in cont.values() if c['gtfp_pwt'] is not None and c['ptf'] is not None]
print('paises sem horas na PWT', sorted({i for (i, a), c in cont.items() if c['ptf'] is None}), 'sem rtfpna', sorted({i for (i, a), c in cont.items() if c['gtfp_pwt'] is None}))
print('linhas contabilidade', len(cont), 'dif max ptf x rtfpna (pp)', round(max(dif), 4), 'media', round(sum(dif) / len(dif), 4))

#!/usr/bin/env python3
# Frente CR. Baixa a Penn World Table 11.0 (Groningen, dataverse.nl), o IBGE (SIDRA, contas nacionais trimestrais e anuais) e o
# Banco Mundial (WDI) para crescimento, contabilidade do crescimento, produtividade e investimento. Uma requisicao por vez, com pausa.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CR/baixa_CR.py
import csv, datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
PAISES = [r['iso3'] for r in csv.DictReader(open(os.path.join(AQUI, '..', '..', 'comparadores.csv'), encoding='utf-8'))]
W = 'https://api.worldbank.org/v2/country/' + ';'.join(PAISES) + '/indicator/'
S = 'https://servicodados.ibge.gov.br/api/v3/agregados/'
DV = 'https://dataverse.nl/api/'
ALVOS = [
  ('pwt110-metadados.json', 'GGDC, Penn World Table 11.0, metadados do dataset no dataverse.nl (doi:10.34894/FABVLR), lista de arquivos e versao',
   DV + 'datasets/:persistentId/?persistentId=doi:10.34894/FABVLR'),
  ('pwt110.xlsx', 'GGDC, Penn World Table 11.0 (publicada 07/10/2025, CC BY 4.0), arquivo principal pwt110.xlsx, 185 paises, 1950 a 2023',
   DV + 'access/datafile/554105'),
  ('pwt110-whatsnew.pdf', 'GGDC, Penn World Table 11.0, nota "What is new in PWT 11.0"', DV + 'access/datafile/554031'),
  ('sidra-1846-pib-fbcf-correntes.json', 'IBGE, SIDRA tabela 1846, contas nacionais trimestrais, valores a precos correntes, PIB e FBCF, Brasil, 1996T1 em diante',
   S + '1846/periodos/199601-202604/variaveis/585?localidades=N1[all]&classificacao=11255[90707,93406]'),
  ('sidra-5932-variacao-volume.json', 'IBGE, SIDRA tabela 5932, contas nacionais trimestrais, taxa acumulada ao longo do ano do indice de volume, PIB e FBCF, Brasil',
   S + '5932/periodos/199601-202604/variaveis/6563?localidades=N1[all]&classificacao=11255[90707,93406]'),
  ('sidra-2072-poupanca.json', 'IBGE, SIDRA tabela 2072, contas economicas trimestrais, PIB e poupanca bruta, Brasil, 2000T1 em diante',
   S + '2072/periodos/200001-202604/variaveis/933|940?localidades=N1[all]'),
  ('sidra-6784-pib-anual.json', 'IBGE, SIDRA tabela 6784, contas nacionais anuais, PIB e PIB per capita variacao em volume e populacao, Brasil, 1996 em diante',
   S + '6784/periodos/1996-2026/variaveis/9810|9814|93?localidades=N1[all]'),
]
for cod, desc in [('NY.GDP.MKTP.KD.ZG', 'crescimento real do PIB % ao ano'), ('NY.GDP.PCAP.KD.ZG', 'crescimento real do PIB por habitante % ao ano'),
                  ('NE.GDI.FTOT.ZS', 'formacao bruta de capital fixo % do PIB'), ('NY.GNS.ICTR.ZS', 'poupanca bruta % do PIB'),
                  ('SL.GDP.PCAP.EM.KD', 'PIB por ocupado, US$ PPC constantes de 2021')]:
  ALVOS.append((f'wdi-{cod}.json', f'Banco Mundial, WDI, {cod}, {desc}, paises de comparadores.csv, 1990 a 2025',
                W + f'{cod}?format=json&date=1990:2025&per_page=20000'))
ALVOS.append(('ted-pagina.html', 'The Conference Board, pagina da Total Economy Database (so para registrar acesso e licenca, dados nao baixados)',
              'https://www.conference-board.org/data/economydatabase/'))
linhas = []
for arq, desc, url in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    try:
      req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) dossie-desenvolvimento'})
      open(dst, 'wb').write(urllib.request.urlopen(req, timeout=300).read())
    except Exception as e:
      print('FALHOU', arq, e); time.sleep(3); continue
    time.sleep(3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

# Frente SO, indicadores sociais

Brasil de 1990 (ou do ano mais antigo da fonte) ao último ano publicado, e os países de `../../comparadores.csv`.
Consulta de 24/10/2026. URLs, datas e sha256 de cada arquivo estão em `downloads.tsv`.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/SO/baixa_SO.py   # baixa só o que falta em fontes/, uma requisição por vez, pausa de 3 s (8 s em ipea, ibge e gov.br)
cd /tmp && python3 -I <pacote>/brutos/SO/build_SO.py   # lê só de fontes/ e grava os SO-*.csv na raiz do volume
```
O `build_SO.py` traz um leitor de xlsx só com a biblioteca padrão, porque `python3 -I` não enxerga o openpyxl instalado no usuário.
Ele lê o valor que a planilha guardou em cache em cada célula.
Para os PDF do SNIS e do SINISA o build usa o pymupdf do site-packages do usuário, acrescentado no fim do `sys.path`.

## O que entra
| CSV | conteúdo | fonte |
|---|---|---|
| `SO-idh.csv` | IDH, expectativa de vida, anos esperados e média de anos de escola, RNB por habitante PPC 2021, IDH ajustado à desigualdade, 1990-2023 | UNDP, HDR 2025, arquivo composto (`HDR25_Composite_indices_complete_time_series.csv`) |
| `SO-idh-posicao-brasil.csv` | posição do Brasil no IDH por ano, entre os países com valor naquele ano | idem, só países (sem códigos ZZ de agregado) |
| `SO-desigualdade-pobreza.csv` | Gini do Banco Mundial (PIP, 0 a 100), Gini do IBGE para o Brasil (0 a 1), pobreza a US$ 3,00 PPC 2021 por dia | WDI SI.POV.GINI e SI.POV.DDAY (atualização 08/10/2026), IBGE SIDRA tabela 7435 |
| `SO-vida.csv` | expectativa de vida ao nascer e mortalidade infantil por mil nascidos vivos | WDI SP.DYN.LE00.IN e SP.DYN.IMRT.IN |
| `SO-homicidios.csv` | taxa por 100 mil pela UNODC (com a fonte nacional que a UNODC declara), pelo WDI, e para o Brasil pelo Atlas da Violência (registrados, número, estimados) | UNODC CTS (arquivo de 2026-07), WDI VC.IHR.PSRC.P5, Ipea Atlas da Violência séries 20, 328 e 368 |
| `SO-pisa.csv` | média e erro-padrão por edição em matemática (2003-2022), leitura (2000-2022) e ciências (2006-2022), com alerta da OCDE | OCDE, PISA 2022 Results Volume I, Annex B1, tabelas I.B1.5.4, 5.5 e 5.6 (stat.link wh9d4z) |
| `SO-saneamento.csv` | % da população com esgotamento e com água geridos com segurança | WDI SH.STA.SMSS.ZS e SH.H2O.SMDW.ZS (fonte JMP) |
| `SO-saneamento-brasil-jmp.csv` | Brasil total, urbano e rural, água segura, básica, encanada, esgotamento seguro, básico, rede, fossa séptica, esgoto tratado, defecação a céu aberto | OMS/UNICEF JMP, arquivo do país (aba Estimates) |
| `SO-homicidios-reconciliacao.csv` | Brasil, Atlas (registrados, intervenção legal, registrados sem intervenção legal), contagem e taxa da UNODC, diferença, população implícita em cada taxa, mortes por causa indeterminada e homicídios ocultos estimados | Ipea séries 20, 328, 77, 78 e 365, UNODC CTS |
| `SO-saneamento-brasil-snis-sinisa.csv` | Brasil, atendimento total e urbano com rede de água e de esgoto, esgoto tratado referido à água consumida e ao esgoto coletado, ao lado das medidas do JMP | SNIS (Diagnósticos de Água e Esgotos, anos de referência 2010-2019 e 2022), SINISA 2024 (ano de referência 2023), JMP |
| `SO-brasil-painel.csv` | um ano por linha com os indicadores principais do Brasil | todos acima |

Toda tabela traz `presidente_brasil` pelo ano (Collor 1990-92, Itamar 1993-94, FHC 1995-2002, Lula 1 2003-06, Lula 2 2007-10, Dilma 2011-15,
Dilma/Temer 2016, Temer 2017-18, Bolsonaro 2019-22, Lula 3 2023-26). O nome do governo data o valor, não atribui causa. No PISA, o ano é o da aplicação.

## Regras de leitura
- IDH só da edição 2025 do relatório. O UNDP recalcula a série inteira a cada edição, então valor de relatório antigo não se compara com este arquivo.
- Dois Gini do Brasil, que não se misturam. O do IBGE (PNAD Contínua anual, rendimento domiciliar per capita, a partir de 2012) é a série oficial
  nacional. O do Banco Mundial (PIP) é o que permite comparar países, com microdados harmonizados pelo PIP e escala de 0 a 100.
- Homicídios, três medidas diferentes.
  - Atlas da Violência, série 20 "taxa de homicídios registrados", base SIM (Ministério da Saúde, declarações de óbito). O metadado da série 20 (`ipea-serie-20-meta.json`,
    campo Descricao) diz: "Para o período de 1979 a 1995 considera os códigos CIDs 9: E960-E978 (Homicídios e lesões provocadas
    intencionalmente outras pessoas) e E990-E999 (Intervenções legais). Considera os códigos CIDs 10: X85-Y09 (agressão) e Y35
    (intervenção legal). Óbitos por residência." A população vem do IBGE (Contagem e estimativas para o TCU). O Brasil é a região
    1076 da abrangência "países" (1000 + código M49 076). Conferido que o número nacional (série 328) bate com a soma das cinco regiões em todos os anos.
  - Série 368 "homicídios estimados" soma aos registrados os homicídios ocultos estimados no estudo "Mapa dos homicídios ocultos no Brasil" (Ipea,
    repositorio.ipea.gov.br/handle/11058/14016), 2013-2023. É estimativa de modelo, não registro.
  - UNODC CTS. Para o Brasil a UNODC declara DATASUS como fonte. O anexo metodológico da UNODC (`unodc-metodologia-homicidios-2019.pdf`, p. iii)
    diz que na fonte de saúde pública "Deaths coded with ICD codes X85-Y09 (injuries inflicted by another person with intent to injure or
    kill), and ICD code Y87.1 (sequelae of assault), generally correspond to the definition of intentional homicide", e que a população de
    referência é o World Population Prospects da ONU. O metadado do ODS 16.1.1 (`onu-ods-metadado-16-1-1.pdf`, versão de 2024-07-29) repete
    a correspondência X85-Y09 e Y87.1 e define homicídio intencional pela ICCS 0101, "Unlawful death inflicted upon a person with the intent
    to cause death or serious injury". A intervenção legal (Y35) fica fora.
  - Reconciliação [A, conta sobre os arquivos] em `SO-homicidios-reconciliacao.csv`. O Atlas soma a intervenção legal (série 77) e a UNODC
    não. Atlas menos intervenção legal bate exatamente com a contagem da UNODC em 2021, 2022 e 2023 (45.562, 44.367 e 43.443). De 2003 a
    2020 a UNODC fica de 15 a 66 óbitos acima, ordem de grandeza compatível com a Y87.1 que ela inclui e o Atlas não lista, mas a contagem
    de Y87.1 não foi baixada [C]. Em 2024 a UNODC fica 321 abaixo (39.625 contra 39.946); a causa não está nos arquivos (o dado de 2024 do
    SIM pode estar em versão diferente nas duas fontes) [C].
    Decomposição de 2024, em pontos por 100 mil: Atlas 20,03; sem intervenção legal (2.644 óbitos), 18,79; com a contagem da UNODC na
    população do Atlas, 18,64; com a população implícita da UNODC (212,0 milhões contra 212,6 milhões do IBGE), 18,69. A intervenção legal
    explica 1,24 dos 1,34 ponto de diferença.
  - Homicídios ocultos (série 365) e mortes violentas por causa indeterminada (série 78) vão no mesmo arquivo para leitura. Os ocultos são
    estimativa de modelo do Ipea a partir das mortes por causa indeterminada, não registro [B]. Nenhuma das duas entra na conta da UNODC. O WDI repete a UNODC com defasagem de edição (2023, 19,28 no WDI contra 20,58 no
    arquivo UNODC de 2026-07). Para comparar países, usar a coluna `unodc_taxa_100mil`.
- PISA. Os valores saem das tabelas de tendência do relatório de 2022, que a OCDE recalcula para tornar as edições comparáveis. Por isso a média do
  Brasil em 2012 nesta tabela (388,5) difere da EdStats do Banco Mundial (391,5); usar só esta. "OECD average" muda de composição; para série longa
  usar `OCDE-23` (média de composição fixa de 23 países da OCDE, conforme o relatório). Azerbaijão é só Baku. Alerta `*` = padrão amostral não atendido (EUA, por exemplo).
- Saneamento. O WDI e o arquivo do JMP coincidem para o Brasil (diferença máxima 0,0 ponto). O arquivo do JMP estende as linhas até 2030 repetindo a
  última estimativa; o build corta no último ano publicado no WDI (2024). Valores 100,0 e 0,0 aparecem no arquivo como estão.

- Saneamento pelo SNIS e pelo SINISA (`SO-saneamento-brasil-snis-sinisa.csv`) [A, dado declarado pelos prestadores].
  - SNIS, um valor por ano tirado do Diagnóstico daquele ano de referência (quadro "Níveis de atendimento com água e esgotos ...",
    linha Brasil; em 2022, das frases do Diagnóstico Temático Visão Geral). Cada valor é o publicado na edição do próprio ano; se
    edições posteriores revisaram algum ano, isso não foi conferido.
  - Fórmulas (glossário SNIS 2022 e fichas SINISA 2024): IN055 = população total atendida com água (AG001) sobre a população residente dos
    municípios com abastecimento de água; IN056 = população total atendida com esgotamento (ES001) sobre a população residente dos
    municípios atendidos com água ("Índice de atendimento total de esgoto referido aos municípios atendidos com água"); IN046 = esgoto
    tratado sobre a água consumida; IN016 = esgoto tratado sobre o coletado. No SINISA, IAG0001 e IES0001 = população urbana mais rural
    atendida com rede sobre a "população total residente" (DFE0001), IES2003 corresponde ao IN046 e IES2004 ao IN016, segundo as próprias fichas.
  - SNIS e SINISA não se emendam. O relatório do SINISA diz que "a principal diferença que o SINISA traz em relação ao SNIS é a divisão do
    Módulo Água e Esgoto", que passou a coletar urbano e rural separados e que só cerca de 40% dos campos do esgoto são similares ao SNIS.
    As populações implícitas mostram a quebra: SNIS 2022 esgoto, 112,8 milhões atendidos a 56,0%, ou 201,4 milhões no denominador; SINISA
    2023 esgoto, 111,3 milhões a 59,7%, ou 186,4 milhões. Na água os dois denominadores ficam em 201,5 e 201,7 milhões. O salto de 56,0%
    para 59,7% no esgoto é sobretudo de denominador, não de atendimento (o número de atendidos cai de 112,8 para 111,3 milhões) [A, conta].
  - Diferença de conceito com o JMP. O JMP mede pessoas em domicílio (censos e pesquisas domiciliares, com modelo) e o SNIS/SINISA mede o
    que o prestador declara. Ligação à rede de esgoto no JMP fica 9 a 15 pontos acima do índice nacional (55,6% contra 46,2% em 2010, 71,2% contra 56,0% em 2022, 72,5% contra 59,7% no SINISA 2023). "Esgotamento
    gerido com segurança" do JMP (54,1% em 2023) exige o esgoto tratado ou a fossa esvaziada e tratada, e não é a mesma coisa que esgoto
    tratado sobre água consumida (IN046/IES2003, 49,4% em 2023), que é razão de volumes.
  - Números-chave: atendimento total com rede de esgoto (IN056) 46,2% em 2010 (Lula 2), 54,1% em 2019 (Bolsonaro), 56,0% em 2022;
    esgoto tratado referido à água consumida (IN046) 37,9% em 2010, 49,1% em 2019, 52,2% em 2022; água (IN055) 81,1% em 2010 e 84,9% em
    2022. O nome do governo data o valor e não atribui causa.

## Limites e lacunas
- SNIS ano de referência 2020 e 2021 ficaram fora. O Diagnóstico de 2020 (Visão Geral SNIS 2021) devolve página HTML pelo endereço do gov.br
  e o espelho em `snis.gov.br` falha no certificado; o de 2021 não foi achado. A série histórica do SNIS (`app4.cidades.gov.br/serieHistorica`)
  responde mas monta a consulta em várias chamadas JavaScript; não foi usada para não multiplicar requisições a site de governo.
  SNIS antes de 2010 não foi baixado. O SINISA com ano de referência 2024 não estava publicado na página de resultados em 24/10/2026.
- O arquivo `snis-diagnostico-ae-2022.pdf` e os dois relatórios do SINISA foram baixados com curl na mesma URL (o urllib cortou o arquivo
  de 25 MB); o `baixa_SO.py` tenta de novo três vezes e recusa resposta HTML no lugar de PDF.
- PISA só cobre os países que fizeram o PISA 2022. Comparadores sem PISA 2022 nesta tabela: China, Índia, África do Sul, Guiana, Belarus, Maurício,
  Maldivas, Bósnia e Armênia (Belarus e Bósnia aplicaram em 2018, Maurício no PISA 2009+, fora das tabelas de tendência de 2022).
- Gini e pobreza do PIP têm buracos. Para o Brasil não há valor em 1991, 1994, 2000 e 2010. O Gini do IBGE só começa em 2012 (PNAD Contínua);
  a série da PNAD anual antiga não foi baixada.
- O IDH vai até 2023 (último ano do HDR 2025). O site do UNDP não publicou relatório de 2026 até a consulta.
- Pobreza do PIP usa a linha de US$ 3,00 PPC 2021, a linha internacional vigente no WDI de 08/10/2026. Não comparar com números antigos a US$ 1,90 ou 2,15.

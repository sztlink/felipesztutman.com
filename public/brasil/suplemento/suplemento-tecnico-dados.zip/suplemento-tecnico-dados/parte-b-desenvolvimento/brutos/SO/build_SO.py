#!/usr/bin/env python3
# Frente SO. Indicadores sociais do Brasil e dos paises de comparadores.csv, lidos so dos arquivos em brutos/SO/fontes/.
# Grava SO-*.csv na raiz do volume. Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/SO/build_SO.py
import collections, csv, json, os, re, zipfile, xml.etree.ElementTree as ET
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
le = lambda a: json.load(open(os.path.join(F, a), encoding='utf-8'))
COMP = [(r['iso3'], r['grupo']) for r in csv.DictReader(open(os.path.join(SAI, 'comparadores.csv'), encoding='utf-8'))]
GRUPO = dict(COMP); ISO = [i for i, _ in COMP]

def presidente(a):
  for ini, fim, n in [(1990, 1992, 'Collor'), (1993, 1994, 'Itamar'), (1995, 2002, 'FHC'), (2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'),
                      (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'), (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]:
    if ini <= a <= fim: return n
  return ''

def grava(nome, cab, linhas):
  with open(os.path.join(SAI, nome), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(cab); w.writerows(linhas)
  print(nome, len(linhas))

r1 = lambda v, d=1: '' if v in (None, '') else round(float(v), d)

# Leitor minimo de xlsx so com a biblioteca padrao (python -I nao enxerga pacotes do usuario). Le o valor gravado em cache de cada celula.
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main', 'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def xlsx(arq, folhas):
  z = zipfile.ZipFile(os.path.join(F, arq)); ss = []
  if 'xl/sharedStrings.xml' in z.namelist():
    for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', NS): ss.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
  rel = {r.get('Id'): r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  out = {}
  for s in ET.fromstring(z.read('xl/workbook.xml')).find('m:sheets', NS):
    if s.get('name') not in folhas: continue
    alvo = rel[s.get('{%s}id' % NS['r'])].lstrip('/'); alvo = alvo if alvo.startswith('xl/') else 'xl/' + alvo
    lin = {}
    for c in ET.fromstring(z.read(alvo)).iter('{%s}c' % NS['m']):
      ref = c.get('r'); col = re.match(r'[A-Z]+', ref).group(); n = 0
      for ch in col: n = n * 26 + ord(ch) - 64
      v = c.find('m:v', NS); t = c.get('t')
      if t == 'inlineStr': val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
      elif v is None: continue
      elif t == 's': val = ss[int(v.text)]
      elif t in ('str', 'e', 'b'): val = v.text
      else:
        try: val = float(v.text)
        except ValueError: val = v.text
      lin.setdefault(int(ref[len(col):]), {})[n - 1] = val
    out[s.get('name')] = [[lin[l].get(i) for i in range(max(lin[l]) + 1)] for l in sorted(lin)]
  return out

# WDI
def wdi(cod):
  s, nomes = {}, {}
  for r in le('wdi-' + cod.lower().replace('.', '-') + '.json')[1]:
    nomes[r['countryiso3code']] = r['country']['value']
    if r['value'] is not None: s[(r['countryiso3code'], int(r['date']))] = r['value']
  return s, nomes
gini_bm, NOME = wdi('SI.POV.GINI'); pob, _ = wdi('SI.POV.DDAY'); ev, _ = wdi('SP.DYN.LE00.IN'); mi, _ = wdi('SP.DYN.IMRT.IN')
hom_wdi, _ = wdi('VC.IHR.PSRC.P5'); esg, _ = wdi('SH.STA.SMSS.ZS'); agua, _ = wdi('SH.H2O.SMDW.ZS')

# 1. IDH, UNDP HDR 2025 (serie 1990-2023 recalculada nessa edicao; nao misturar com edicoes anteriores)
hdr = {r['iso3']: r for r in csv.DictReader(open(os.path.join(F, 'hdr25-composite-time-series.csv'), encoding='cp1252'))}
L = []
for i in ISO:
  h = hdr.get(i)
  if not h: continue
  for a in range(1990, 2024):
    g = lambda k: h.get(f'{k}_{a}', '')
    if g('hdi') == '' and g('le') == '': continue
    L.append([i, NOME.get(i, h['country']), GRUPO[i], a, g('hdi'), r1(g('le'), 2), r1(g('eys'), 2), r1(g('mys'), 2), r1(g('gnipc'), 0), g('ihdi'),
              h['hdi_rank_2023'] if a == 2023 else '', presidente(a)])
grava('SO-idh.csv', ['iso3', 'pais', 'grupo', 'ano', 'idh', 'expectativa_vida_anos', 'anos_esperados_escola', 'media_anos_escola',
                     'rnb_pc_ppc_2021', 'idh_ajustado_desigualdade', 'posicao_idh_2023', 'presidente_brasil'], L)
# Posicao do Brasil no IDH por ano, entre os paises (iso3 de 3 letras, sem agregados ZZ*) com valor naquele ano, na edicao 2025
L = []
paises_hdr = {k: v for k, v in hdr.items() if not k.startswith('ZZ')}
# painel fixo: so os paises que ja tinham IDH em 1990, para separar ultrapassagem de entrada de paises novos na lista (auditoria v1, E1)
fixo = {k for k, v in paises_hdr.items() if v.get('hdi_1990')}
for a in range(1990, 2024):
  vals = {k: float(v[f'hdi_{a}']) for k, v in paises_hdr.items() if v.get(f'hdi_{a}')}
  if 'BRA' not in vals: continue
  b = vals['BRA']; vf = [x for k, x in vals.items() if k in fixo]
  L.append([a, b, 1 + sum(x > b for x in vals.values()), len(vals), 1 + sum(x > b for x in vf), len(vf), presidente(a)])
grava('SO-idh-posicao-brasil.csv', ['ano', 'idh_brasil', 'posicao_entre_com_dado', 'paises_com_dado', 'posicao_painel_1990', 'paises_painel_1990', 'presidente_brasil'], L)

# 2. Desigualdade e pobreza. Gini do IBGE (PNAD Continua, 0 a 1) para o Brasil e Gini do Banco Mundial (PIP, 0 a 100) para todos
ibge = {}
for r in le('sidra-7435-gini-brasil.json')[1:]:
  if r['D2C'] == '10681' and r['V'] not in ('-', '...', 'X'): ibge[int(r['D3C'])] = float(r['V'])
L = []
for i in ISO:
  for a in range(1990, 2026):
    if (i, a) in gini_bm or (i, a) in pob or (i == 'BRA' and a in ibge):
      L.append([i, NOME[i], GRUPO[i], a, r1(gini_bm.get((i, a))), ibge.get(a, '') if i == 'BRA' else '', r1(pob.get((i, a))), presidente(a)])
grava('SO-desigualdade-pobreza.csv', ['iso3', 'pais', 'grupo', 'ano', 'gini_bm_pip_0a100', 'gini_ibge_pnadc_0a1', 'pobreza_3usd_ppc2021_pct',
                                      'presidente_brasil'], L)

# 3. Expectativa de vida e mortalidade infantil (WDI)
L = [[i, NOME[i], GRUPO[i], a, r1(ev.get((i, a)), 2), r1(mi.get((i, a))), presidente(a)]
     for i in ISO for a in range(1990, 2026) if (i, a) in ev or (i, a) in mi]
grava('SO-vida.csv', ['iso3', 'pais', 'grupo', 'ano', 'expectativa_vida_anos', 'mortalidade_infantil_por_mil', 'presidente_brasil'], L)

# 4. Homicidios. Brasil pelo Atlas da Violencia (Ipea, base SIM): regiao 1076 da abrangencia paises (codigo M49 076 + 1000).
def ipea(a, reg=1076):
  d = {}
  for r in le(a):
    if r['regiao_id'] == reg: d[int(r['periodo'][:4])] = r['valor']
  return d
tx_reg, n_reg, tx_est = ipea('ipea-serie-20-paises.json'), ipea('ipea-serie-328-paises.json'), ipea('ipea-serie-368-paises.json')
# conferencia, soma das cinco regioes (dedup por regiao e ano) contra o numero nacional
soma = collections.defaultdict(dict)
for r in le('ipea-serie-328-regioes.json'): soma[int(r['periodo'][:4])][r['regiao_id']] = r['valor']
dif = [a for a in n_reg if a in soma and len(soma[a]) == 5 and abs(sum(soma[a].values()) - n_reg[a]) > 0.5]
print('anos em que soma das regioes difere do nacional:', dif)
un = xlsx('unodc-cts-intentional-homicide.xlsx', ['data_cts_intentional_homicide'])['data_cts_intentional_homicide']
cab = un[2]; unodc, unodc_fonte = {}, {}
for row in un[3:]:
  r = dict(zip(cab, row))
  if (r['Indicator'] == 'Victims of intentional homicide' and r['Dimension'] == 'Total' and r['Category'] == 'Total' and r['Sex'] == 'Total'
      and r['Age'] == 'Total' and r['Unit of measurement'] == 'Rate per 100,000 population' and r['Iso3_code'] in GRUPO):
    unodc[(r['Iso3_code'], int(r['Year']))] = r['VALUE']; unodc_fonte[(r['Iso3_code'], int(r['Year']))] = r['Source']
L = []
for i in ISO:
  for a in range(1990, 2026):
    linha = [i, NOME[i], GRUPO[i], a, r1(unodc.get((i, a)), 2), unodc_fonte.get((i, a), ''), r1(hom_wdi.get((i, a)), 2)]
    if i == 'BRA': linha += [r1(tx_reg.get(a), 2), n_reg.get(a, ''), r1(tx_est.get(a), 2)]
    else: linha += ['', '', '']
    if any(x != '' for x in linha[4:]): L.append(linha + [presidente(a)])
grava('SO-homicidios.csv', ['iso3', 'pais', 'grupo', 'ano', 'unodc_taxa_100mil', 'unodc_fonte_nacional', 'wdi_taxa_100mil',
                            'atlas_ipea_taxa_registrados_100mil', 'atlas_ipea_homicidios_registrados', 'atlas_ipea_taxa_estimados_100mil',
                            'presidente_brasil'], L)

# 4b. Reconciliacao Atlas x UNODC para o Brasil. O metadado da serie 20 do Atlas diz que o homicidio registrado soma CID-10 X85-Y09 (agressao)
# e Y35 (intervencao legal); o anexo metodologico da UNODC e o metadado do ODS 16.1.1 tomam X85-Y09 e Y87.1, sem intervencao legal.
# Atlas menos a serie 77 (intervencao legal) contra a contagem da UNODC, e a populacao implicita em cada taxa (contagem / taxa).
cont_un = {}
for row in un[3:]:
  r = dict(zip(cab, row))
  if (r['Iso3_code'] == 'BRA' and r['Indicator'] == 'Victims of intentional homicide' and r['Dimension'] == 'Total' and r['Category'] == 'Total'
      and r['Sex'] == 'Total' and r['Age'] == 'Total' and r['Unit of measurement'] == 'Counts'):
    cont_un[int(r['Year'])] = r['VALUE']
interv, mvci, ocultos = ipea('ipea-serie-77-paises.json'), ipea('ipea-serie-78-paises.json'), ipea('ipea-serie-365-paises.json')
L = []
for a in range(1990, 2026):
  if a not in n_reg and a not in cont_un: continue
  sem = n_reg[a] - interv[a] if a in n_reg and a in interv else ''
  dif = int(cont_un[a] - sem) if sem != '' and a in cont_un else ''
  pop_at = round(n_reg[a] / tx_reg[a] * 1e5) if a in n_reg and a in tx_reg else ''
  pop_un = round(cont_un[a] / unodc[('BRA', a)] * 1e5) if a in cont_un and ('BRA', a) in unodc else ''
  L.append([a, n_reg.get(a, ''), interv.get(a, ''), sem, int(cont_un[a]) if a in cont_un else '', dif, r1(tx_reg.get(a), 2), r1(unodc.get(('BRA', a)), 2),
            pop_at, pop_un, mvci.get(a, ''), ocultos.get(a, ''), presidente(a)])
grava('SO-homicidios-reconciliacao.csv', ['ano', 'atlas_homicidios_registrados', 'atlas_intervencao_legal_y35', 'atlas_menos_intervencao_legal',
                                          'unodc_contagem', 'unodc_menos_atlas_sem_intervencao', 'atlas_taxa_100mil', 'unodc_taxa_100mil',
                                          'atlas_populacao_implicita', 'unodc_populacao_implicita', 'atlas_mortes_causa_indeterminada',
                                          'atlas_homicidios_ocultos_estimados', 'presidente_brasil'], L)

# 5. PISA, OCDE, PISA 2022 Volume I, tabelas I.B1.5.4 (matematica), I.B1.5.5 (leitura), I.B1.5.6 (ciencias). Media e erro-padrao por edicao.
PISA_NOME = {'Argentina': 'ARG', 'Chile': 'CHL', 'Colombia': 'COL', 'Mexico': 'MEX', 'Peru': 'PER', 'Uruguay': 'URY', 'Indonesia': 'IDN',
             'Türkiye': 'TUR', 'Poland': 'POL', 'Korea': 'KOR', 'United States': 'USA', 'Serbia': 'SRB', 'Georgia': 'GEO',
             'North Macedonia': 'MKD', 'Dominican Republic': 'DOM', 'Albania': 'ALB', 'Thailand': 'THA', 'Baku (Azerbaijan)': 'AZE',
             'Brazil': 'BRA', 'OECD average': 'OCDE', 'OECD average-23': 'OCDE-23', 'OECD average-26': 'OCDE-26',
             'OECD average-35': 'OCDE-35'}
tab = xlsx('pisa2022-v1-tabelas-B1-5.xlsx', ['Table I.B1.5.4', 'Table I.B1.5.5', 'Table I.B1.5.6'])
L = []
for folha, dom in [('Table I.B1.5.4', 'matematica'), ('Table I.B1.5.5', 'leitura'), ('Table I.B1.5.6', 'ciencias')]:
  t = tab[folha]; ed = t[3]; sub = t[4]
  cols = [(k, int(ed[k].split()[1])) for k in range(len(ed)) if isinstance(ed[k], str) and re.fullmatch(r'PISA \d{4}', ed[k].strip()) and sub[k] == 'Mean score']
  for row in t[5:]:
    if not row or not isinstance(row[0], str): continue
    nome = row[0].rstrip('*'); alerta = row[0][len(nome):]
    if nome not in PISA_NOME: continue
    for k, ano in cols:
      v = row[k] if k < len(row) else None
      if isinstance(v, float):
        L.append([PISA_NOME[nome], row[0], GRUPO.get(PISA_NOME[nome], 'media OCDE'), ano, dom, round(v, 1), round(row[k + 1], 1),
                  {'*': 'padrao amostral nao atendido', '**': 'ligacao fraca com a escala de leitura'}.get(alerta, ''), presidente(ano)])
grava('SO-pisa.csv', ['iso3', 'nome_ocde', 'grupo', 'edicao', 'dominio', 'media', 'erro_padrao', 'alerta_ocde', 'presidente_brasil'], L)

# 6. Saneamento. Comparadores pelo WDI (fonte JMP) e Brasil pelo arquivo do pais do JMP, total, urbano e rural.
L = [[i, NOME[i], GRUPO[i], a, r1(esg.get((i, a))), r1(agua.get((i, a))), presidente(a)]
     for i in ISO for a in range(1990, 2026) if (i, a) in esg or (i, a) in agua]
grava('SO-saneamento.csv', ['iso3', 'pais', 'grupo', 'ano', 'esgotamento_seguro_pct', 'agua_segura_pct', 'presidente_brasil'], L)
est = xlsx('jmp-bra-household.xlsx', ['Estimates'])['Estimates']; h = [re.sub(r'\s+', ' ', str(x or '')).strip() for x in est[3]]
QUER = [('Safely managed drinking water', 'agua_segura_pct'), ('At least basic (improved within 30 mins)', 'agua_ao_menos_basica_pct'),
        ('Piped', 'agua_encanada_pct'), ('Safely managed sanitation', 'esgotamento_seguro_pct'),
        ('At least basic (improved and not shared)', 'esgotamento_ao_menos_basico_pct'), ('Sewer connection', 'ligacao_rede_esgoto_pct'),
        ('Septic tanks', 'fossa_septica_pct'), ('Wastewater treated', 'esgoto_tratado_pct'), ('Open defecation', 'defecacao_ar_livre_pct')]
idx = [h.index(q) for q, _ in QUER]
# O arquivo do pais estende as linhas ate 2030 repetindo a ultima estimativa; corta no ultimo ano que o JMP publica no WDI para o Brasil.
fim_jmp = max(a for (i, a) in esg if i == 'BRA')
L = []
for row in est[4:]:
  if not row or row[0] != 'Brazil' or not isinstance(row[1], float) or row[1] > fim_jmp: continue
  a = int(row[1]); L.append([a, row[2]] + [r1(row[k]) if isinstance(row[k], float) else '' for k in idx] + [presidente(a)])
grava('SO-saneamento-brasil-jmp.csv', ['ano', 'situacao'] + [n for _, n in QUER] + ['presidente_brasil'], L)
jt = {r[0]: r for r in L if r[1] == 'Total'}
print('JMP x WDI esgoto seguro Brasil, maior diferenca:', max((abs(jt[a][5] - round(esg[('BRA', a)], 1)), a) for a in jt if ('BRA', a) in esg))

# 6b. Saneamento do Brasil pelo SNIS (Diagnosticos anuais, 2010-2019 e 2022) e pelo SINISA (ano de referencia 2023), ao lado do JMP.
# Valores lidos do texto dos PDF (quadro "Niveis de atendimento", linha Brasil; em 2022 e no SINISA, das frases e cartoes do relatorio).
# pymupdf vem do site-packages do usuario, acrescentado no fim do sys.path (python -I nao o enxerga sozinho).
import site, sys; sys.path.append(site.getusersitepackages()); import pymupdf
def pdf_txt(arq):
  p = os.path.join(F, arq)
  if arq.endswith('.zip'):
    z = zipfile.ZipFile(p); n = [m for m in z.namelist() if m.lower().endswith('.pdf')]; assert len(n) == 1, (arq, n)
    doc = pymupdf.open(stream=z.read(n[0]), filetype='pdf')
  else: doc = pymupdf.open(p)
  return '\n'.join(pg.get_text() for pg in doc)
num_br = lambda x: float(x.replace('.', '').replace(',', '.'))
SAN = {}
for a in range(2010, 2020):
  arq = [x for x in os.listdir(F) if x.startswith(f'snis-diagnostico-ae-{a}.')][0]; t = pdf_txt(arq)
  for m in re.finditer(r'N[íi]veis de atendimento com [áa]gua e esgotos', t):
    seg = t[m.start():m.start() + 3000]; b = seg.find('\nBrasil')
    if b > 0: break
  v = [num_br(x) for x in re.findall(r'\n\s*(\d{1,3},\d)\s', seg[b:b + 200])]
  assert len(v) >= 5, (a, v)
  SAN[a] = {'fonte': 'SNIS', 'arquivo': arq, 'agua_total': v[0], 'agua_urbana': v[1], 'esgoto_total': v[2], 'esgoto_urbano': v[3],
            'tratado_gerado': v[4], 'tratado_coletado': v[5] if len(v) > 5 else ''}
t = re.sub(r'\s+', ' ', pdf_txt('snis-diagnostico-ae-2022.pdf'))
g1 = lambda pad: num_br(re.search(pad, t).group(1))
SAN[2022] = {'fonte': 'SNIS', 'arquivo': 'snis-diagnostico-ae-2022.pdf',
             'agua_total': g1(r'\(IN055\) com redes públicas de abastecimento do SNIS-AE 2022 é de (\d+,\d)%'), 'agua_urbana': '',
             'esgoto_total': g1(r'As redes de esgotos atendem (\d+,\d)% da população total'), 'esgoto_urbano': '',
             'tratado_gerado': g1(r'apenas (\d+,\d)% são tratados \(IN046\)'), 'tratado_coletado': g1(r'Do esgoto coletado \(IN016\), (\d+,\d)% são tratados')}
ta = re.sub(r'\s+', ' ', pdf_txt('sinisa-2024-ref2023-abastecimento-agua.pdf')); te = re.sub(r'\s+', ' ', pdf_txt('sinisa-2024-ref2023-esgotamento-sanitario.pdf'))
g2 = lambda pad, tx: num_br(re.search(pad, tx).group(1))
SAN[2023] = {'fonte': 'SINISA', 'arquivo': 'sinisa-2024-ref2023-abastecimento-agua.pdf; sinisa-2024-ref2023-esgotamento-sanitario.pdf', 'agua_total': g2(r'IAG0001 - (\d+,\d)%', ta), 'agua_urbana': g2(r'IAG0002 - (\d+,\d)%', ta),
             'esgoto_total': g2(r'IES0001 - (\d+,\d)%', te), 'esgoto_urbano': g2(r'IES0002 - (\d+,\d)%', te),
             'tratado_gerado': g2(r'(\d+,\d)% do volume gerado de esgoto é tratado', te), 'tratado_coletado': g2(r'(\d+,\d)% do volume de esgoto coletado é tratado', te)}
L = []
for a in range(2010, 2025):
  x = SAN.get(a, {}); j = jt.get(a)
  if not x and not j: continue
  L.append([a, x.get('fonte', ''), x.get('arquivo', '')] + [x.get(k, '') for k in ('agua_total', 'agua_urbana', 'esgoto_total', 'esgoto_urbano', 'tratado_gerado', 'tratado_coletado')]
           + ([j[2], j[4], j[5], j[7], j[9]] if j else ['', '', '', '', '']) + [presidente(a)])
grava('SO-saneamento-brasil-snis-sinisa.csv', ['ano', 'fonte_nacional', 'arquivo_fonte', 'agua_atendimento_total_rede_pct', 'agua_atendimento_urbano_rede_pct',
      'esgoto_atendimento_total_rede_pct', 'esgoto_atendimento_urbano_rede_pct', 'esgoto_tratado_referido_agua_consumida_pct', 'esgoto_tratado_referido_coletado_pct',
      'jmp_agua_segura_pct', 'jmp_agua_encanada_pct', 'jmp_esgotamento_seguro_pct', 'jmp_ligacao_rede_esgoto_pct', 'jmp_esgoto_tratado_pct', 'presidente_brasil'], L)

# 7. Painel do Brasil, um ano por linha
idh_b = {a: hdr['BRA'].get(f'hdi_{a}', '') for a in range(1990, 2024)}
L = []
for a in range(1990, 2026):
  L.append([a, presidente(a), idh_b.get(a, ''), ibge.get(a, ''), r1(gini_bm.get(('BRA', a))), r1(pob.get(('BRA', a))), r1(ev.get(('BRA', a)), 2),
            r1(mi.get(('BRA', a))), r1(tx_reg.get(a), 2), r1(unodc.get(('BRA', a)), 2), r1(esg.get(('BRA', a))), r1(agua.get(('BRA', a)))])
grava('SO-brasil-painel.csv', ['ano', 'presidente_brasil', 'idh_hdr2025', 'gini_ibge_pnadc', 'gini_bm_pip', 'pobreza_3usd_pct', 'expectativa_vida_anos',
                               'mortalidade_infantil_por_mil', 'homicidios_atlas_100mil', 'homicidios_unodc_100mil', 'esgotamento_seguro_pct',
                               'agua_segura_pct'], L)

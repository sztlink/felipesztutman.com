#!/usr/bin/env python3
# Frente SO. Indicadores sociais. Baixa, uma requisicao por vez, IDH (UNDP HDR 2025), Gini do Brasil (IBGE, SIDRA 7435), homicidios do
# Brasil (Ipea, Atlas da Violencia, base SIM), homicidios internacionais (UNODC), WDI (Gini, pobreza, expectativa de vida, mortalidade
# infantil, homicidios, saneamento e agua), PISA (OCDE, anexos do PISA 2022 Volume I) e saneamento do Brasil (JMP OMS/UNICEF).
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/SO/baixa_SO.py
import csv, datetime, hashlib, http.client, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
PAC = os.path.abspath(os.path.join(AQUI, '..', '..'))
ISO = [r['iso3'] for r in csv.DictReader(open(os.path.join(PAC, 'comparadores.csv'), encoding='utf-8'))]
W = 'https://api.worldbank.org/v2/country/' + ';'.join(ISO) + '/indicator/'
WDI = [('SI.POV.GINI', 'Gini (PIP, Banco Mundial)'), ('SI.POV.DDAY', 'pobreza, % da populacao abaixo da linha internacional (PIP, US$ 3,00 PPC 2021 por dia)'),
       ('SP.DYN.LE00.IN', 'expectativa de vida ao nascer, anos'), ('SP.DYN.IMRT.IN', 'mortalidade infantil, por mil nascidos vivos'),
       ('VC.IHR.PSRC.P5', 'homicidios intencionais por 100 mil (UNODC via WDI)'),
       ('SH.STA.SMSS.ZS', 'populacao com esgotamento sanitario gerido com seguranca, % (JMP via WDI)'),
       ('SH.H2O.SMDW.ZS', 'populacao com agua potavel gerida com seguranca, % (JMP via WDI)')]
SNIS_ANT = 'https://www.gov.br/mdr/pt-br/assuntos/saneamento/snis/diagnosticos-anteriores-do-snis/agua-e-esgotos-1/'
SINISA = 'https://www.gov.br/cidades/pt-br/acesso-a-informacao/acoes-e-programas/saneamento/sinisa/resultados-sinisa/'
IPEA = 'https://www.ipea.gov.br/dados-api'; CMS = 'https://www.ipea.gov.br/cms/api'
ALVOS = [
  ('hdr25-composite-time-series.csv', 'UNDP, Human Development Report 2025, Composite indices complete time series (1990-2023), unica edicao usada',
   'https://hdr.undp.org/sites/default/files/2025_HDR/HDR25_Composite_indices_complete_time_series.csv'),
  ('hdr25-metadata.xlsx', 'UNDP, HDR 2025, metadados das colunas do arquivo composto',
   'https://hdr.undp.org/sites/default/files/2025_HDR/HDR25_Composite_indices_metadata.xlsx'),
  ('sidra-7435-gini-brasil.json', 'IBGE, SIDRA tabela 7435, PNAD Continua anual, Gini do rendimento domiciliar per capita, Brasil, 2012 em diante',
   'https://apisidra.ibge.gov.br/values/t/7435/n1/all/v/all/p/all'),
  ('ipea-serie-20-meta.json', 'Ipea, Atlas da Violencia, metadados da serie 20 (taxa de homicidios registrados)', CMS + '/series/20'),
  ('ipea-serie-20-paises.json', 'Ipea, Atlas da Violencia, serie 20, taxa de homicidios registrados por 100 mil, abrangencia paises (Brasil = regiao 1076)',
   IPEA + '/series-values/20/1'),
  ('ipea-serie-328-meta.json', 'Ipea, Atlas da Violencia, metadados da serie 328 (homicidios registrados, numero)', CMS + '/series/328'),
  ('ipea-serie-328-paises.json', 'Ipea, Atlas da Violencia, serie 328, homicidios registrados (numero), abrangencia paises', IPEA + '/series-values/328/1'),
  ('ipea-serie-328-regioes.json', 'Ipea, Atlas da Violencia, serie 328, homicidios registrados (numero), cinco regioes, para conferir a soma nacional',
   IPEA + '/series-values/328/2'),
  ('ipea-serie-368-paises.json', 'Ipea, Atlas da Violencia, serie 368, taxa de homicidios estimados (registrados mais ocultos) por 100 mil',
   IPEA + '/series-values/368/1'),
  ('ipea-serie-368-meta.json', 'Ipea, Atlas da Violencia, metadados da serie 368 (homicidios estimados)', CMS + '/series/368'),
  ('ipea-serie-77-meta.json', 'Ipea, Atlas da Violencia, metadados da serie 77 (intervencao legal, auto de resistencia, numero)', CMS + '/series/77'),
  ('ipea-serie-77-paises.json', 'Ipea, Atlas da Violencia, serie 77, mortes por intervencao legal (numero), abrangencia paises', IPEA + '/series-values/77/1'),
  ('ipea-serie-78-meta.json', 'Ipea, Atlas da Violencia, metadados da serie 78 (mortes violentas por causa indeterminada, numero)', CMS + '/series/78'),
  ('ipea-serie-78-paises.json', 'Ipea, Atlas da Violencia, serie 78, mortes violentas por causa indeterminada (numero), abrangencia paises', IPEA + '/series-values/78/1'),
  ('ipea-serie-365-meta.json', 'Ipea, Atlas da Violencia, metadados da serie 365 (homicidios ocultos, numero)', CMS + '/series/365'),
  ('ipea-serie-365-paises.json', 'Ipea, Atlas da Violencia, serie 365, homicidios ocultos estimados (numero), abrangencia paises', IPEA + '/series-values/365/1'),
  ('unodc-metodologia-homicidios-2019.pdf', 'UNODC, Homicide Statistics (2019), Methodological annex (fontes, codigos CID-10 X85-Y09 e Y87.1, populacao do WPP)',
   'https://www.unodc.org/documents/data-and-analysis/statistics/Homicide/homicide2018/Methodology.pdf'),
  ('onu-ods-metadado-16-1-1.pdf', 'ONU, metadado do indicador ODS 16.1.1 (homicidio intencional, definicao ICCS e correspondencia CID-10), versao de 2024-07-29',
   'https://unstats.un.org/sdgs/metadata/files/Metadata-16-01-01.pdf'),
  ('unodc-cts-intentional-homicide.xlsx', 'UNODC, dataUNODC, Intentional homicide (CTS), arquivo publicado em 2026-07',
   'https://data.unodc.org/sites/dataportal.unodc.org/files/2026-07/data_cts_intentional_homicide.xlsx'),
  ('pisa2022-v1-tabelas-B1-5.xlsx', 'OCDE, PISA 2022 Results Volume I, Annex B1, Tables I.B1.5.x (tendencias 2000/2003/2006 a 2022)',
   'https://stat.link/files/53f23881-en/wh9d4z.xlsx'),
  ('jmp-bra-household.xlsx', 'OMS/UNICEF JMP, arquivo do pais Brasil, domicilios (agua, esgotamento, higiene), estimativas por ano',
   'https://washdata.org/data/country/BRA/household/download'),
] + [(f'snis-diagnostico-ae-{a}.{u.rsplit(".", 1)[1]}', f'Ministerio das Cidades (antes MDR), SNIS, Diagnostico dos Servicos de Agua e Esgotos, ano de referencia {a}', u) for a, u in [
  (a, SNIS_ANT + f'{a}/Diagnostico_AE{a}{"_Retificado" if a == 2016 else ""}.zip') for a in range(2010, 2018)] + [
  (2018, SNIS_ANT + '2018/Diagnostico_AE2018.pdf'), (2019, SNIS_ANT + '2019/2-Diagnstico_SNIS_AE_2019_Republicacao_31032021.pdf'),
  (2022, 'https://www.gov.br/cidades/pt-br/acesso-a-informacao/acoes-e-programas/saneamento/snis/produtos-do-snis/diagnosticos/017_DIAGNOSTICO_TEMATICO_VISAO_GERAL_AE_SNIS_2023_defeso.pdf')]] + [
  ('sinisa-2024-ref2023-abastecimento-agua.pdf', 'Ministerio das Cidades, SINISA 2024 (ano de referencia 2023), relatorio do modulo Abastecimento de Agua', SINISA + '013_RELATORIO_SINISA_ABASTECIMENTO_DE_AGUA_2024_defeso.pdf'),
  ('sinisa-2024-ref2023-esgotamento-sanitario.pdf', 'Ministerio das Cidades, SINISA 2024 (ano de referencia 2023), relatorio do modulo Esgotamento Sanitario', SINISA + '014_RELATORIO_SINISA_ESGOTAMENTO_SANITARIO_2024_defeso.pdf'),
  ('snis-glossario-indicadores-ae-2022.pdf', 'Ministerio das Cidades, SNIS, glossario de indicadores de agua e esgotos, ano de referencia 2022 (formulas de IN055, IN056, IN046, IN016)',
   'https://www.gov.br/cidades/pt-br/acesso-a-informacao/acoes-e-programas/saneamento/snis/produtos-do-snis/diagnosticos/Glossario_Indicadores_AE2022.pdf'),
  ('sinisa-2024-indicadores-esgotamento-sanitario.pdf', 'Ministerio das Cidades, SINISA 2024, ficha dos indicadores do modulo Esgotamento Sanitario (formulas de IES0001, IES2003, IES2004)',
   'https://www.gov.br/cidades/pt-br/acesso-a-informacao/acoes-e-programas/saneamento/sinisa/arquivos/INDICADORES_SINISA_ESGOTAMENTOSANITRIO_2024_V2.pdf'),
  ('sinisa-2024-indicadores-abastecimento-agua.pdf', 'Ministerio das Cidades, SINISA 2024, ficha dos indicadores do modulo Abastecimento de Agua (formula de IAG0001)',
   SINISA + 'INDICADORES_SINISA_ABASTECIMENTO_DE_AGUA_2024_v2.pdf'),
] + [('wdi-' + c.lower().replace('.', '-') + '.json', 'Banco Mundial, WDI, ' + c + ', ' + d + ', paises de comparadores.csv, 1990 a 2025',
      W + c + '?format=json&date=1990:2025&per_page=20000') for c, d in WDI]
linhas = []
for arq, desc, url in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    dom = url.split('/')[2]
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) dossie-desenvolvimento'})
    for tentativa in range(3):  # arquivos grandes do gov.br as vezes chegam cortados (IncompleteRead)
      try: dado = urllib.request.urlopen(req, timeout=600).read(); break
      except http.client.IncompleteRead:
        if tentativa == 2: raise
        time.sleep(30)
    if arq.endswith(('.pdf', '.zip', '.xlsx')) and dado.lstrip()[:1] == b'<': raise SystemExit(f'{arq}: veio HTML, nao o arquivo')
    open(dst, 'wb').write(dado); print(arq, len(dado))
    time.sleep(8 if any(g in dom for g in ('ibge', 'ipea', 'gov.br', 'datasus', 'saude')) else 3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

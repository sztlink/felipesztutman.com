#!/usr/bin/env python3
# Frente RP. Renda por habitante em PPC (Banco Mundial), posicao do Brasil e paises que passaram o Brasil ou ficaram atras.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/RP/build_RP.py
import csv, json, os
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
le = lambda a: json.load(open(os.path.join(F, a), encoding='utf-8'))
paises = {p['id']: p for p in le('wdi-paises.json')[1] if p['region']['value'] != 'Aggregates'}
def serie(a):
  s = {}
  for r in le(a)[1]:
    if r['countryiso3code'] in paises and r['value'] is not None: s[(r['countryiso3code'], int(r['date']))] = r['value']
  return s
pib, pop = serie('wdi-pib-pc-ppc.json'), serie('wdi-populacao.json')
nome = {k: v['name'] for k, v in paises.items()}
anos = sorted({a for _, a in pib})

with open(os.path.join(SAI, 'RP-pib-pc-ppc.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais', 'ano', 'pib_pc_ppc_2021', 'populacao'])
  for (i, a) in sorted(pib): w.writerow([i, nome[i], a, round(pib[(i, a)], 1), pop.get((i, a), '')])

# Posicao do Brasil por ano, entre os paises com dado naquele ano, e entre o painel fixo com dado em todos os anos de 2002 a 2025
fixo = [i for i in paises if all((i, a) in pib for a in range(2002, 2026))]
with open(os.path.join(SAI, 'RP-brasil-posicao.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['ano', 'pib_pc_brasil', 'posicao_entre_com_dado', 'paises_com_dado', 'posicao_painel_fixo', 'paises_painel_fixo',
                                 'pct_do_eua', 'pct_da_mediana_mundial'])
  for a in anos:
    if ('BRA', a) not in pib: continue
    b = pib[('BRA', a)]; com = [v for (i, y), v in pib.items() if y == a]
    fx = [pib[(i, a)] for i in fixo] if 2002 <= a <= 2025 else []
    med = sorted(com)[len(com) // 2]
    w.writerow([a, round(b, 1), 1 + sum(v > b for v in com), len(com), (1 + sum(v > b for v in fx)) if fx else '', len(fx) if fx else '',
                round(100 * b / pib[('USA', a)], 1) if ('USA', a) in pib else '', round(100 * b / med, 1)])

# Ultrapassagens entre 2002 e 2025, no painel fixo
b0, b1 = pib[('BRA', 2002)], pib[('BRA', 2025)]
with open(os.path.join(SAI, 'RP-ultrapassagens-2002-2025.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['sentido', 'iso3', 'pais', 'regiao', 'pib_pc_2002', 'pib_pc_2025', 'variacao_pct', 'populacao_2025'])
  for sent, cond in [('passou o Brasil', lambda i: pib[(i, 2002)] < b0 and pib[(i, 2025)] > b1),
                     ('ficou atras do Brasil', lambda i: pib[(i, 2002)] > b0 and pib[(i, 2025)] < b1)]:
    for i in sorted((i for i in fixo if i != 'BRA' and cond(i)), key=lambda i: -pib[(i, 2025)]):
      w.writerow([sent, i, nome[i], paises[i]['region']['value'], round(pib[(i, 2002)], 1), round(pib[(i, 2025)], 1),
                  round(100 * (pib[(i, 2025)] / pib[(i, 2002)] - 1), 1), pop.get((i, 2025), '')])
  w.writerow(['Brasil', 'BRA', nome['BRA'], paises['BRA']['region']['value'], round(b0, 1), round(b1, 1), round(100 * (b1 / b0 - 1), 1), pop.get(('BRA', 2025), '')])
print(len(fixo), round(b0, 1), round(b1, 1))

#!/usr/bin/env python3
# Frente RP. Baixa do Banco Mundial (WDI) o PIB por habitante em PPC (US$ internacionais constantes de 2021), a populacao e a
# lista de paises (para separar paises de agregados), uma requisicao por vez.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/RP/baixa_RP.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
W = 'https://api.worldbank.org/v2'
ALVOS = [
  ('wdi-pib-pc-ppc.json', 'Banco Mundial, WDI, NY.GDP.PCAP.PP.KD, PIB por habitante PPC US$ constantes de 2021, todos os paises, 1990 a 2025',
   W + '/country/all/indicator/NY.GDP.PCAP.PP.KD?format=json&date=1990:2025&per_page=20000'),
  ('wdi-populacao.json', 'Banco Mundial, WDI, SP.POP.TOTL, populacao, todos os paises, 1990 a 2025',
   W + '/country/all/indicator/SP.POP.TOTL?format=json&date=1990:2025&per_page=20000'),
  ('wdi-paises.json', 'Banco Mundial, lista de economias com regiao e grupo de renda (agregados tem regiao "Aggregates")',
   W + '/country?format=json&per_page=400'),
]
linhas = []
for arq, desc, url in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    open(dst, 'wb').write(urllib.request.urlopen(url, timeout=120).read()); time.sleep(3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

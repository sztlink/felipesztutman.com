# Frente NE, ambiente de negócios

## O que entra
- Doing Business, Banco Mundial, planilha histórica DB04 a DB20 do arquivo do Doing Business (`db-historico-DB04-DB20.xlsx`), com duas abas:
  - `DB21 Data`, série revisada depois da revisão das irregularidades (a planilha de explicações registra a fonte de cada mudança, inclusive
    "Correction of data irregularities"). Nível nacional; cidades com código com `_`.
  - `DB20 Data`, a série como publicada no DB2020. O código ISO pode estar na linha da cidade principal (Brasil: `BRA` é São Paulo e `BRAZ`
    é o nacional); a linha nacional é achada pelo nome igual ao da aba DB21.
- `db-explicacao-mudancas.xlsx`, explicação das mudanças nos dados históricos, guardada como fonte e não lida pelo build.
- Comunicado oficial do Banco Mundial de 16/09/2021, "World Bank Group to Discontinue Doing Business Report"
  (`db-comunicado-descontinuacao-2021-09-16.html`). Diz que irregularidades nos dados do DB2018 e do DB2020 foram relatadas internamente em
  junho de 2020, que a gestão suspendeu o relatório seguinte e abriu revisões e auditorias, e que, depois de revisar o material, decidiu
  descontinuar o Doing Business e trabalhar numa nova abordagem para avaliar o clima de negócios e investimento.
- B-READY 2025 (Business Ready), base completa `B-READY_ALL_DATA_2025.zip`, aba de pilares e escore geral de cada um dos 10 temas, versão
  do arquivo de 10/12/2025, 101 economias.
- Página de economias cobertas do B-READY (`bready-economias-cobertas.html`), que lista o Brasil no grupo do B-READY 2026.

## Saídas (raiz do volume)
- `NE-doing-business.csv`: por série (revisada ou como publicada), país, recorte (nacional ou cidade) e edição, o escore geral nas três
  metodologias que a planilha traz (DB17-20, DB15, DB10-14), a posição calculada e o número de economias com escore.
- `NE-doing-business-temas.csv`: escore de cada um dos 10 temas, com a metodologia indicada no nome da coluna de origem.
- `NE-bready-2025.csv`: Brasil e comparadores, se estão na edição 2025, escores dos três pilares, posição em cada pilar entre as 101 economias
  e escore geral de cada tema.

## Regra de leitura
- Classe A para o que o indicador mede (regra escrita e caso padrão de empresa na maior cidade), mas é medida de jure com caso hipotético,
  não pesquisa com empresas reais.
- Mudança de método entre edições: o escore geral tem três metodologias (DB10-14, DB15, DB17-20; a planilha cola duas delas nas edições de
  transição, 2014 e 2015) e cada tema tem sua própria quebra em DB15, DB16 ou DB17. A página de metodologia do arquivo diz que cada expansão
  de método foi recalculada para um ano anterior e que mudanças no número de economias, de indicadores e de método afetam a comparabilidade.
  Não emendar séries de métodos diferentes.
- Economias com mais de uma cidade medida (11, entre elas o Brasil, com São Paulo e Rio de Janeiro) só têm linha nacional desde DB2014;
  antes disso o Brasil existe só como São Paulo.
- `edicao_db` é o ano da edição (coluna "DB year" da planilha), não o ano de referência dos dados; a data de corte dos dados não está nos
  arquivos baixados. A coluna de presidente data a edição.
- `posicao_calculada_*` ordena o escore entre as economias com linha nacional na planilha (191 em DB2020). O ranking oficial publicado não
  está na planilha e pode diferir.
- O B-READY não publica escore geral único nem ranking geral; a posição é por pilar.
- O Doing Business e o B-READY não são comparáveis entre si (métodos, temas e pilares diferentes).

## Limites e lacunas
- Brasil não está no B-READY 2025 (nem Argentina, Chile, China, Índia, África do Sul, Tailândia, Albânia, Belarus, Guiana, Maldivas,
  República Dominicana). A página de economias cobertas põe o Brasil no B-READY 2026, ainda não publicado em 24/10/2026 (a página de dados
  só oferece a base de 2025). Lacuna até a edição 2026 sair.
- Licença (verificada em 24/10/2026).
  - Doing Business: a ficha do conjunto no Data Catalog do Banco Mundial (`wb-catalogo-doing-business.html`, conjunto 0038564, metadado
    de 07/08/2024, que lista como recurso os "Historical Data Sets and Trends Data") diz "License : Creative Commons Attribution 4.0. This
    dataset is licensed under Creative Commons Attribution 4.0". Os termos de uso de dados (`wb-termos-de-uso-de-dados.html`) dizem "Unless
    specifically labeled otherwise, these Datasets are provided to you under a Creative Commons Attribution 4.0 International License (CC BY
    4.0)", com exceção só para dados de terceiros rotulados no metadado. O "© The World Bank Group, All Rights Reserved." é o rodapé do site
    do arquivo (`db-pagina-dados.html`), que cobre as páginas, não o conjunto de dados que tem licença própria na ficha.
    Conclusão: `NE-doing-business.csv` e `NE-doing-business-temas.csv` podem ir em pacote público, com atribuição (World Bank, Doing Business,
    Historical Data DB04-DB20, CC BY 4.0) e com aviso de que são derivados.
  - B-READY: a ficha do conjunto 0066291 (`wb-catalogo-bready.html`, metadado de 26/03/2025, recursos de 04/11/2024, ainda sem a edição
    2025) traz "Custom License" com o texto "Modified BSD3 (https://opensource.org/license/bsd-3-clause/)". O README da base de 2025 não
    traz licença. BSD-3 é licença permissiva com atribuição, então republicar `NE-bready-2025.csv` com citação é compatível com o que está
    escrito, mas o rótulo é de software e a ficha não cobre a edição 2025 [C para a edição 2025]. Recomendação: no pacote público, citar e
    apontar para a fonte; republicar o CSV só se aceitar essa leitura.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/NE/baixa_NE.py   # baixa só o que falta em fontes/ e reescreve downloads.tsv
cd /tmp && python3 -I <pacote>/brutos/NE/build_NE.py   # lê só de fontes/ (xlsx pela biblioteca padrão) e grava NE-*.csv na raiz
```

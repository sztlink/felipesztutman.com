#!/usr/bin/env python3
# Frente NE. Baixa do arquivo do Doing Business (Banco Mundial) a serie historica DB04 a DB20 e a planilha de explicacao das mudancas,
# as paginas de metodologia e de dados do arquivo, o comunicado oficial de 16/09/2021 que descontinua o relatorio, a base completa do
# B-READY 2025 a pagina de dados e a de economias cobertas do B-READY, e os termos de uso de dados do Banco Mundial. Uma requisicao por vez, com pausa.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/NE/baixa_NE.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'}
DB = 'https://archive.doingbusiness.org'
ALVOS = [
  ('db-historico-DB04-DB20.xlsx', 'Banco Mundial, Doing Business, serie historica DB04 a DB20 com escores (arquivo do Doing Business)',
   DB + '/content/dam/doingBusiness/excel/db-2021/Historical-Data--DB04-DB20-.xlsx'),
  ('db-explicacao-mudancas.xlsx', 'Banco Mundial, Doing Business, explicacao das mudancas nos dados historicos',
   DB + '/content/dam/doingBusiness/excel/db-2021/Explanations-for-Historical-Data-Changes.xlsx'),
  ('db-pagina-dados.html', 'Banco Mundial, Doing Business, pagina de dados do arquivo (cobertura 2003 a 2019, lista de arquivos)', DB + '/en/data'),
  ('db-pagina-metodologia.html', 'Banco Mundial, Doing Business, pagina de metodologia (comparabilidade entre edicoes)', DB + '/en/methodology'),
  ('db-comunicado-descontinuacao-2021-09-16.html', 'Banco Mundial, comunicado de 16/09/2021, World Bank Group to Discontinue Doing Business Report',
   'https://www.worldbank.org/en/news/statement/2021/09/16/world-bank-group-to-discontinue-doing-business-report'),
  ('bready-2025-todos-os-dados.zip', 'Banco Mundial, B-READY 2025, base completa (B-READY_ALL_DATA_2025.zip)',
   'https://www.worldbank.org/content/dam/sites/b-ready/documents/excel/B-READY_ALL_DATA_2025.zip'),
  ('bready-pagina-dados.html', 'Banco Mundial, B-READY, pagina de dados', 'https://www.worldbank.org/en/businessready/data'),
  ('bready-economias-cobertas.html', 'Banco Mundial, B-READY, economias cobertas por edicao (2024, 2025 e 2026)',
   'https://www.worldbank.org/en/businessready/about-us/covered-economies'),
  ('wb-catalogo-doing-business.html', 'Banco Mundial, Data Catalog, ficha do conjunto Doing Business (0038564), campo License: Creative Commons Attribution 4.0',
   'https://datacatalog.worldbank.org/search/dataset/0038564/doing-business'),
  ('wb-catalogo-bready.html', 'Banco Mundial, Data Catalog, ficha do conjunto Business Ready (0066291), campo License: Custom License',
   'https://datacatalog.worldbank.org/search/dataset/0066291'),
  ('wb-termos-de-uso-de-dados.html', 'Banco Mundial, termos de uso de bases de dados (licenca CC BY 4.0 com termos adicionais)',
   'https://www.worldbank.org/ext/en/legal/terms-conditions/datasets'),
]
linhas = []
for arq, desc, url in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    open(dst, 'wb').write(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=180).read()); time.sleep(3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

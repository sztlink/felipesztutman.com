#!/usr/bin/env python3
# Frente NE. Ambiente de negocios: Doing Business (Banco Mundial), edicoes DB2004 a DB2020, descontinuado em 16/09/2021, e B-READY 2025.
# Brasil e comparadores de comparadores.csv. Le so de fontes/ (xlsx lido com a biblioteca padrao, sem dependencia externa).
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/NE/build_NE.py
import csv, io, os, re, zipfile, xml.etree.ElementTree as ET
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
grupo = {r['iso3']: r['grupo'] for r in csv.DictReader(open(os.path.join(SAI, 'comparadores.csv'), encoding='utf-8'))}
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main', 'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def xlsx(fonte, abas):
  # Le as abas pedidas de um .xlsx. Devolve {aba: [linhas]}, cada linha uma lista de valores (texto ou numero), indice = coluna.
  z = zipfile.ZipFile(fonte); ss = []
  if 'xl/sharedStrings.xml' in z.namelist():
    for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', NS): ss.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
  rel = {r.get('Id'): r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  out = {}
  for sh in ET.fromstring(z.read('xl/workbook.xml')).find('m:sheets', NS):
    if sh.get('name') not in abas: continue
    alvo = rel[sh.get('{%s}id' % NS['r'])]; alvo = alvo.lstrip('/') if alvo.startswith('/') else 'xl/' + alvo
    linhas = []
    for row in ET.fromstring(z.read(alvo)).iter('{%s}row' % NS['m']):
      L = []
      for c in row.findall('m:c', NS):
        i = 0
        for ch in re.match(r'[A-Z]+', c.get('r')).group(0): i = i * 26 + ord(ch) - 64
        t = c.get('t'); v = c.find('m:v', NS)
        if t == 's': val = ss[int(v.text)] if v is not None else None
        elif t == 'inlineStr': val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
        elif v is None or t in ('str', 'e', 'b'): val = None if v is None else v.text
        else: val = float(v.text)
        L += [None] * (i - 1 - len(L)); L.append(val)
      linhas.append(L)
    out[sh.get('name')] = linhas
  return out
def presidente(a):
  for ini, fim, n in [(1990, 1992, 'Collor'), (1993, 1994, 'Itamar'), (1995, 2002, 'FHC'), (2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'),
                      (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'), (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]:
    if ini <= a <= fim: return n
  return ''
num = lambda x: isinstance(x, float)
r2 = lambda x: round(x, 2) if num(x) else ''

# Doing Business. Aba "DB21 Data" = serie revisada depois da revisao das irregularidades, nivel nacional (cidades tem codigo com "_").
# Aba "DB20 Data" = serie como publicada no DB2020; o codigo ISO pode estar na linha da cidade principal, entao a linha nacional e achada
# pelo nome igual ao da aba DB21.
db = xlsx(os.path.join(F, 'db-historico-DB04-DB20.xlsx'), {'DB21 Data', 'DB20 Data'})
def tabela(aba):
  v = db[aba]; h = v[4]; L = [r + [None] * (len(h) - len(r)) for r in v[5:] if r and r[0] and num(r[4] if len(r) > 4 else None)]
  return h, L
h21, L21 = tabela('DB21 Data'); h20, L20 = tabela('DB20 Data')
nac21 = {r[1]: r[0] for r in L21 if '_' not in r[0]}; nome21 = {v: k for k, v in nac21.items()}
def cidade(iso, r): return r[0][:3] == iso and r[1] != nome21[iso] and r[1].startswith(nome21[iso] + ' ')
# (iso3, recorte, linha); recorte = 'nacional' ou o nome da cidade. Economias com mais de uma cidade so tem linha nacional desde DB2014;
# antes disso a serie existe so para a cidade principal.
serie = {'revisada (aba DB21 Data)': (h21, [(r[0], 'nacional', r) for r in L21 if '_' not in r[0]] +
                                       [(r[0][:3], r[1], r) for r in L21 if '_' in r[0] and r[0][:3] in grupo]),
         'como publicada no DB2020 (aba DB20 Data)': (h20, [(nac21[r[1]], 'nacional', r) for r in L20 if r[1] in nac21] +
                                       [(i, r[1], r) for r in L20 for i in grupo if i in nome21 and cidade(i, r)])}
GER = [('DB17', 'Ease of doing business score (DB17-'), ('DB15', 'Ease of doing business score (DB15'), ('DB10-14', 'Ease of doing business score (DB10-14')]
with open(os.path.join(SAI, 'NE-doing-business.csv'), 'w', newline='', encoding='utf-8') as f, \
     open(os.path.join(SAI, 'NE-doing-business-temas.csv'), 'w', newline='', encoding='utf-8') as g:
  w = csv.writer(f); w.writerow(['serie', 'iso3', 'recorte', 'pais', 'grupo', 'edicao_db', 'presidente_brasil_no_ano_da_edicao', 'escore_db17_20', 'escore_db15',
                                 'escore_db10_14', 'posicao_calculada_db17_20', 'posicao_calculada_db15', 'posicao_calculada_db10_14', 'economias_com_escore'])
  wt = csv.writer(g); wt.writerow(['serie', 'iso3', 'recorte', 'pais', 'grupo', 'edicao_db', 'tema', 'metodo', 'escore'])
  for nome_s, (h, linhas) in serie.items():
    ig = [next(i for i, c in enumerate(h) if c and str(c).startswith(p)) for _, p in GER]
    temas = [(i, *re.match(r'Score-(.*?)(?: \((DB[^)]*) methodology\))?$', c).groups()) for i, c in enumerate(h)
             if c and str(c).startswith('Score-') and 'Postfiling' not in c]
    pos = {}
    for k, i in enumerate(ig):
      for ano in {r[4] for _, _, r in linhas}:
        vals = sorted(((r[i], iso) for iso, rc, r in linhas if rc == 'nacional' and r[4] == ano and num(r[i])), reverse=True)
        for p, (_, iso) in enumerate(vals): pos[(k, iso, ano)] = (p + 1, len(vals))
    for iso, rc, r in sorted(linhas, key=lambda x: (x[0], x[1] != 'nacional', x[1], -x[2][4])):
      if iso not in grupo: continue
      ano = int(r[4]); q = [pos.get((k, iso, r[4])) if rc == 'nacional' else None for k in range(3)]
      w.writerow([nome_s, iso, rc, r[1], grupo[iso], ano, presidente(ano), *(r2(r[i]) for i in ig),
                  *(x[0] if x else '' for x in q), max((x[1] for x in q if x), default='')])
      for i, tema, met in temas:
        if num(r[i]): wt.writerow([nome_s, iso, rc, r[1], grupo[iso], ano, tema, met or 'metodo unico', r2(r[i])])

# B-READY 2025, aba de pilares e escore geral de cada um dos 10 temas. O B-READY nao publica escore geral unico nem ranking.
z = zipfile.ZipFile(os.path.join(F, 'bready-2025-todos-os-dados.zip'))
ABAS = ['00_B-READY_Pillar_Score', '01_Business_Entry', '02_Business_Location', '03_Utility_Services', '04_Labor', '05_Financial_Services',
        '06_International_Trade', '07_Taxation', '08_Dispute_Resolution', '09_Market_Competition', '10_Business_Insolvency']
br = xlsx(io.BytesIO(z.read('01_B-READY-2025-PILLAR-TOPIC-SCORES.xlsx')), set(ABAS))
pil = {r[1]: r for r in br['00_B-READY_Pillar_Score'][1:] if len(r) > 4 and r[1] and num(r[2])}
temas = []
for aba in sorted(k for k in br if not k.startswith('00')):
  v = br[aba]; h = v[3]; temas.append((h[2].replace(' Overall', ''), {r[1]: r[2] for r in v[4:] if len(r) > 2 and r[1] and num(r[2])}))
def pos(d, iso): return 1 + sum(x > d[iso] for x in d.values()) if iso in d else ''
p = [{k: r[j] for k, r in pil.items()} for j in (2, 3, 4)]
with open(os.path.join(SAI, 'NE-bready-2025.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais', 'grupo', 'na_edicao_2025', 'pilar1_marco_regulatorio', 'pilar2_servicos_publicos',
                                 'pilar3_eficiencia_operacional', 'posicao_pilar1', 'posicao_pilar2', 'posicao_pilar3', 'economias',
                                 *(t for t, _ in temas)])
  for iso in grupo:
    if iso in pil:
      r = pil[iso]; w.writerow([iso, r[0], grupo[iso], 'sim', *(r2(x) for x in r[2:5]), *(pos(d, iso) for d in p), len(pil),
                                *(r2(d.get(iso)) for _, d in temas)])
    else: w.writerow([iso, '', grupo[iso], 'nao'] + [''] * (7 + len(temas)))
print(len(L21), len(L20), len(pil))

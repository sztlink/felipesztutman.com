# Frente IN, inovação

## O que entra
- Pedidos de patente de residentes (`IP.PAT.RESD`) e de não residentes (`IP.PAT.NRES`), fonte primária OMPI (WIPO Patent Report and
  Statistics Database), lidos do WDI do Banco Mundial. Divididos pela população (`SP.POP.TOTL`) para dar pedidos por milhão de habitantes.
- Gasto em P&D em % do PIB (`GB.XPD.RSDV.GD.ZS`) e pesquisadores em P&D por milhão de habitantes (`SP.POP.SCIE.RD.P6`), fonte primária
  UNESCO UIS, lidos do WDI.
- Consulta de 24/10/2026, WDI com atualização de 08/10/2026 (campo `lastupdated` dos JSON).

## Saídas (raiz do volume)
- `IN-comparadores.csv`: Brasil e os países de `comparadores.csv`, por ano, com os valores absolutos, por milhão, P&D e pesquisadores,
  e a coluna `presidente_brasil`.
- `IN-brasil-posicao.csv`: série do Brasil com a posição entre todos os países com dado no ano (1 = maior), o número de países com dado,
  a participação dos residentes no total de pedidos e a mediana mundial de P&D e de pedidos de residentes por milhão.

## Regra de leitura
- Classe A (registro administrativo de pedidos, estatística oficial de P&D).
- Pedido de patente mede depósito no escritório nacional, não concessão nem qualidade. Não residente é quem deposita no Brasil vindo de
  fora; não mede inovação brasileira.
- A posição depende de quantos países têm dado no ano (de 61 a 127 nos pedidos de residentes); comparar posição entre anos só junto da coluna
  de países com dado.
- Nome de governo data o valor e não atribui causa.

## Limites e lacunas
- Pesquisadores por milhão do Brasil para em 2014 no WDI. Lacuna de 2015 em diante nesta fonte.
- P&D do Brasil começa em 2000 no WDI.
- Pedidos de não residentes no Brasil saltam de 5.446 (1996) para 13.479 (1997). A origem do salto não foi verificada nesta frente; não
  ler como mudança de comportamento sem checar a série no INPI e na OMPI.
- Global Innovation Index: não entra. Não foi achada tabela oficial baixável da OMPI com a posição de todas as economias (o registro do
  repositório da OMPI não abriu por requisição direta). Se entrar depois, marcar como índice composto, classe B.
- Licença: os dados do WDI são CC BY 4.0 segundo a ficha do WDI no catálogo de dados do Banco Mundial (lida em 24/10/2026 por leitor web,
  a API do catálogo devolveu 429 e a ficha não foi arquivada). Indicadores de terceiros (OMPI, UNESCO) podem ter termos próprios, conforme
  os termos de uso de dados do Banco Mundial em `../NE/fontes/wb-termos-de-uso-de-dados.html`.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/IN/baixa_IN.py   # baixa só o que falta em fontes/ e reescreve downloads.tsv
cd /tmp && python3 -I <pacote>/brutos/IN/build_IN.py   # lê só de fontes/ e grava IN-*.csv na raiz do volume
```

#!/usr/bin/env python3
# Frente IN. Baixa do Banco Mundial (WDI) pedidos de patente de residentes e de nao residentes (fonte primaria OMPI), gasto em P&D em %
# do PIB e pesquisadores por milhao (fonte primaria UNESCO UIS), populacao e lista de paises, uma requisicao por vez.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/IN/baixa_IN.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
W = 'https://api.worldbank.org/v2'
def ind(cod): return W + f'/country/all/indicator/{cod}?format=json&date=1960:2025&per_page=20000'
ALVOS = [
  ('wdi-patentes-residentes.json', 'Banco Mundial, WDI, IP.PAT.RESD, pedidos de patente de residentes (OMPI, WIPO Patent Report and Statistics Database), todos os paises, 1960 a 2025', ind('IP.PAT.RESD')),
  ('wdi-patentes-nao-residentes.json', 'Banco Mundial, WDI, IP.PAT.NRES, pedidos de patente de nao residentes (OMPI), todos os paises, 1960 a 2025', ind('IP.PAT.NRES')),
  ('wdi-ped-pib.json', 'Banco Mundial, WDI, GB.XPD.RSDV.GD.ZS, gasto em pesquisa e desenvolvimento em % do PIB (UNESCO UIS), todos os paises, 1960 a 2025', ind('GB.XPD.RSDV.GD.ZS')),
  ('wdi-pesquisadores.json', 'Banco Mundial, WDI, SP.POP.SCIE.RD.P6, pesquisadores em P&D por milhao de habitantes (UNESCO UIS), todos os paises, 1960 a 2025', ind('SP.POP.SCIE.RD.P6')),
  ('wdi-populacao.json', 'Banco Mundial, WDI, SP.POP.TOTL, populacao, todos os paises, 1960 a 2025', ind('SP.POP.TOTL')),
  ('wdi-paises.json', 'Banco Mundial, lista de economias com regiao e grupo de renda (agregados tem regiao "Aggregates")', W + '/country?format=json&per_page=400'),
]
linhas = []
for arq, desc, url in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    open(dst, 'wb').write(urllib.request.urlopen(url, timeout=120).read()); time.sleep(3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

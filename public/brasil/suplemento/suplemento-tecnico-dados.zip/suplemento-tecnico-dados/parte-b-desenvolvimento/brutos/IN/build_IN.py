#!/usr/bin/env python3
# Frente IN. Inovacao: pedidos de patente de residentes e nao residentes por milhao de habitantes (OMPI via WDI), gasto em P&D em % do PIB
# e pesquisadores por milhao (UNESCO UIS via WDI). Brasil e comparadores de comparadores.csv, e a posicao do Brasil entre todos os paises.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/IN/build_IN.py
import csv, json, os
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
le = lambda a: json.load(open(os.path.join(F, a), encoding='utf-8'))
paises = {p['id']: p for p in le('wdi-paises.json')[1] if p['region']['value'] != 'Aggregates'}
nome = {k: v['name'] for k, v in paises.items()}
grupo = {r['iso3']: r['grupo'] for r in csv.DictReader(open(os.path.join(SAI, 'comparadores.csv'), encoding='utf-8'))}
def presidente(a):
  for ini, fim, n in [(1990, 1992, 'Collor'), (1993, 1994, 'Itamar'), (1995, 2002, 'FHC'), (2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'),
                      (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'), (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]:
    if ini <= a <= fim: return n
  return ''
def serie(a):
  s = {}
  for r in le(a)[1]:
    if r['countryiso3code'] in paises and r['value'] is not None: s[(r['countryiso3code'], int(r['date']))] = r['value']
  return s
res, nres, ped, pesq, pop = (serie(a) for a in ['wdi-patentes-residentes.json', 'wdi-patentes-nao-residentes.json', 'wdi-ped-pib.json',
                                                'wdi-pesquisadores.json', 'wdi-populacao.json'])
pm = lambda s: {k: 1e6 * v / pop[k] for k, v in s.items() if pop.get(k)}
res_pm, nres_pm = pm(res), pm(nres)
r1 = lambda x, n=1: '' if x is None else round(x, n)

# Serie por pais e ano, Brasil e comparadores
chaves = sorted({k for s in (res, nres, ped, pesq) for k in s if k[0] in grupo})
with open(os.path.join(SAI, 'IN-comparadores.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais', 'grupo', 'ano', 'presidente_brasil', 'patentes_residentes', 'patentes_nao_residentes',
                                 'populacao', 'patentes_residentes_por_milhao', 'patentes_nao_residentes_por_milhao', 'ped_pct_pib',
                                 'pesquisadores_por_milhao'])
  for k in chaves:
    w.writerow([k[0], nome[k[0]], grupo[k[0]], k[1], presidente(k[1]), res.get(k, ''), nres.get(k, ''), pop.get(k, ''), r1(res_pm.get(k)),
                r1(nres_pm.get(k)), r1(ped.get(k), 3), r1(pesq.get(k))])

# Posicao do Brasil por ano entre todos os paises com dado naquele ano (1 = maior)
def pos(s, a):
  if ('BRA', a) not in s: return '', ''
  com = [v for (i, y), v in s.items() if y == a]; return 1 + sum(v > s[('BRA', a)] for v in com), len(com)
anos = sorted({a for (i, a) in list(res) + list(ped) + list(pesq) if i == 'BRA'})
with open(os.path.join(SAI, 'IN-brasil-posicao.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['ano', 'presidente_brasil', 'patentes_residentes', 'patentes_residentes_por_milhao', 'posicao_res_pm', 'paises_res_pm',
                                 'patentes_nao_residentes', 'participacao_residentes_pct', 'ped_pct_pib', 'posicao_ped', 'paises_ped',
                                 'pesquisadores_por_milhao', 'posicao_pesq', 'paises_pesq', 'ped_mediana_mundial', 'res_pm_mediana_mundial'])
  med = lambda s, a: (lambda v: v[len(v) // 2] if v else '')(sorted(x for (i, y), x in s.items() if y == a))
  for a in anos:
    k = ('BRA', a); tot = (res.get(k) or 0) + (nres.get(k) or 0)
    w.writerow([a, presidente(a), res.get(k, ''), r1(res_pm.get(k)), *pos(res_pm, a), nres.get(k, ''),
                r1(100 * res[k] / tot) if k in res and k in nres and tot else '', r1(ped.get(k), 3), *pos(ped, a), r1(pesq.get(k)), *pos(pesq, a),
                r1(med(ped, a) or None, 3), r1(med(res_pm, a) or None)])
print(len(chaves), len(anos))

# Frente CU2, cultura como indicador de desenvolvimento

Consulta de 24/10/2026. A pergunta é cultura como dimensão do desenvolvimento (trabalho, empresas, consumo das famílias,
equipamentos, comércio exterior), não gasto público com cultura, que está no volume 1 (frentes C, CU, CV).

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/CU2/baixa_CU2.py   # baixa o que falta em fontes/, reescreve downloads.tsv
cd /tmp && python3 -I <pacote>/brutos/CU2/build_CU2.py   # lê só fontes/, grava CU2-*.csv na raiz do volume (cerca de 90 s)
```
O build usa openpyxl, xlrd e py7zr do site-packages do usuário (`pip install --user py7zr`, instalado em 24/10/2026). O arquivo de
bens criativos da UNCTAD é um 7z de 335 MB com um CSV de 4,1 GB. O build o lê em fluxo e não grava o CSV no disco.
IBGE com pausa de 8 s entre requisições, BCB com 5 s, UNCTAD, UIS e Banco Mundial com 3 s. Uma requisição por vez.

## Fontes e edições
- IBGE, Sistema de Informações e Indicadores Culturais (SIIC), FTP `Indicadores_Sociais/Sistema_de_Informacoes_e_Indicadores_Culturais/`.
  A edição mais recente é a **2024** (índice de tabelas de 09/03/2026). Dela vêm ocupação (PNAD Contínua 2014-2024), empresas
  (2013 e 2019-2023) e comércio exterior (2014-2024). A edição 2024 **não traz** as tabelas de gastos das famílias (5) nem de
  equipamentos (8). Por isso a POF vem das edições 2007-2010 (publicada em 2013), 2018 e 2020, e a MUNIC vem da edição 2022.
- UNCTADstat, bens criativos (`US.CreativeGoodsValue`, 2002-2024) e serviços criativos (`US.CreativeServ_Indiv_Tot`, 2010-2024).
- UNESCO UIS, API pública, emprego cultural e ocupações culturais (2010-2016, a partir de microdados do ILOSTAT, quadro FCS 2009) e
  número de cinemas (1995-2017). Atualização da UIS de fevereiro de 2026.
- Banco Mundial, WDI, população, só para cinemas por milhão de habitantes.

## Arquivos
| arquivo | conteúdo |
|---|---|
| `CU2-brasil-indicadores.csv` | Brasil em formato longo (indicador, ano, presidente, valor, unidade, fonte, nota): ocupação, informalidade e rendimento no setor cultural, empresas culturais, POF, comércio exterior |
| `CU2-brasil-municipios-equipamentos.csv` | % de municípios com cada equipamento (MUNIC 1999-2021) e % da população que mora em município com museu, teatro, cinema e rádio (2021, total, brancos, pretos ou pardos) |
| `CU2-unctad-bens-criativos.csv` | comparadores e mundo, exportação e importação de bens criativos, US$ correntes, % do mundo e % do comércio de mercadorias. Para o Brasil também os grupos de produto |
| `CU2-unctad-brasil-posicao.csv` | posição do Brasil entre as economias individuais, em valor e em % das exportações de mercadorias, e mediana dos comparadores |
| `CU2-unctad-servicos-criativos.csv` | comparadores, serviços criativos, US$ correntes e % do comércio de serviços |
| `CU2-servicos-brasil-quebra-2014.csv` | Brasil, 2005-2025, exportações de serviços por categoria EBOPS 2010 (UNCTADstat), total de serviços criativos da UNCTAD e as séries mensais do BCB (SGS, somadas no ano) das mesmas categorias, com o regime dos dados |
| `CU2-uis-emprego-cultural.csv` | todos os países da base UIS, emprego cultural e ocupações culturais, % dos ocupados |
| `CU2-uis-cinemas.csv` | comparadores, cinemas e cinemas por milhão de habitantes |

## Achados (classe de evidência entre colchetes)
- **Trabalho [A].** Ocupados no setor cultural (PNAD Contínua, 14 anos ou mais), 5,20 milhões (5,68% dos ocupados) em 2014 (Dilma),
  4,75 milhões (5,57%) em 2020 (Bolsonaro) e 5,86 milhões (5,79%) em 2024 (Lula 3). A fatia fica entre 5,5% e 5,8% em toda a série.
  O número absoluto cai em 2020-2021 e volta a subir a partir de 2022.
- **Informalidade [A].** No setor cultural, 37,8% em 2014 contra 38,8% no total dos ocupados. De 2015 em diante o setor cultural
  fica sempre acima do total. Em 2024, 44,6% contra 40,6%.
- **Rendimento [A].** O rendimento médio do setor cultural fica acima da média de todos os setores em todos os anos, de 102% (2018,
  2021) a 111% (2023). Em 2024, 105% (R$ 3.266 contra R$ 3.108).
- **Empresas [A].** Na classificação por domínios culturais, o valor adicionado das empresas culturais cai de 11,2% do total das
  empresas pesquisadas (PIA, PAC e PAS) em 2009 (Lula 2) para 8,0% em 2021-2022 (Bolsonaro) e 8,3% em 2023 (Lula 3). As atividades
  culturais centrais caem de 3,8% (2009) para 2,6% (2021) e voltam a 3,0% (2023). O pessoal ocupado fica estável (6,0% em 2009 e
  5,8% em 2023). Valor adicionado caindo com emprego estável significa valor adicionado por pessoa caindo em relação ao resto das
  empresas pesquisadas. Isso é uma conta, não uma causa.
  O denominador é o universo das três pesquisas estruturais, não o PIB. O IBGE não publica participação no PIB nessas tabelas.
- **Famílias [A, com ressalva].** A cultura é 8,6% da despesa de consumo na POF 2008-2009 e 7,5% na POF 2017-2018 (edição 2018).
  A edição 2020 recalcula a POF 2017-2018 com outra cesta, R$ 291,18 por família por mês, ou 7,07% da despesa de consumo.
  Cada edição usa sua cesta, então os números não formam série. As famílias mais pobres gastam proporcionalmente menos com
  cultura (5,9% contra 7,9% das mais ricas em 2017-2018, 6,0% contra 9,7% em 2008-2009). Por região, em 2017-2018, R$ 187,91 por mês
  no Nordeste e R$ 355,24 no Sudeste, R$ 119,58 no rural e R$ 318,59 no urbano.
- **Equipamentos [A].** Municípios com museu, 15,5% (1999) e 29,6% (2021). Com teatro, 13,7% e 23,3%. Com cinema, 7,2% e 9,0%. Com
  livraria, 35,5% e 15,0%. Com biblioteca pública, 97,1% em 2014 e 88,3% em 2021. Ponto de Cultura, 22,6% (2014) e 36,1% (2021).
  Em 2021, 57,5% da população mora em município com cinema, 62,2% dos brancos e 53,7% dos pretos ou pardos.
- **Comércio de bens culturais, IBGE [A].** Bens culturais (seleção NCM do IBGE) são 1,46% das importações e 0,22% das exportações
  de bens em 2024. As exportações cobrem 19% das importações (máximo de 29% em 2016, mínimo de 13% em 2014).
- **Bens criativos, UNCTAD [A].** Exportações brasileiras de bens criativos, 1,05% das exportações de mercadorias em 2002 (FHC),
  0,49% em 2010 (Lula 2), 0,39% em 2022-2023 e 0,40% em 2024. A participação no mundo cai de 0,31% (2002) para 0,19% (2024). Por % das
  exportações, o Brasil fica em 82º de 157 economias em 2002 e em 99º de 162 em 2023. A mediana dos outros comparadores fica entre
  1,1% e 2,4%. Em valor o Brasil fica entre o 32º e o 41º lugar.
- **Serviços criativos, UNCTAD [A, com ressalva].** 4,5% das exportações de serviços do Brasil em 2010, 8,0% em 2014 e 14,8% em
  2024 (US$ 7,19 bilhões). Em 2024, abaixo de Índia (27,3%), EUA (25,5%), Polônia (18,4%), China (16,2%) e Coreia (15,6%), acima de
  Colômbia (7,2%) e Uruguai (8,7%). O salto de 2013 (4,6%) para 2014 (8,0%) é quebra de série na fonte brasileira, não crescimento (ver Quebras e cuidados); a série só se lê de 2014 em diante.
  Segundo a própria UNCTAD, o grupo de serviços criativos é puxado por software e P&D. É uma medida de economia criativa ampla,
  não de cultura em sentido estrito.
- **Emprego cultural comparável, UIS [B como comparação].** O Brasil não está no indicador "emprego cultural" da UIS. Está só em
  "ocupações culturais", 4,35% dos ocupados em 2013, ao lado de Chile 4,32% (2013), México 4,44% (2014), Turquia 4,57% (2014),
  Coreia 6,75% (2014), Peru 3,96% (2013), Uruguai 1,37% (2013) e África do Sul 2,51% (2014). Em emprego cultural, México 9,95% e
  Coreia 8,10% (2015). O conceito do IBGE (5,8% em 2024) é de outra fonte e não é harmonizado com a UIS. Não comparar diretamente.
- **Cinemas, UIS [A].** 3,82 cinemas por milhão de habitantes no Brasil em 2017 (782 cinemas), contra 6,61 no México, 3,50 no Chile,
  5,42 na Argentina, 12,93 na Polônia e 17,60 nos EUA. Isso conta cinemas, não salas nem telas.

## Quebras e cuidados
- PNAD anual (2007-2012, 10 anos ou mais, edição 2007-2010) e PNAD Contínua (2014-2024, 14 anos ou mais) não se emendam. A antiga
  vai de 4,64% (2007) para 3,85% (2012), com degrau entre 2009 e 2011 (4,66% e 3,98%), causa não investigada.
- Empresas, classificação antiga (AIC+ACC+ASC, 12,4% do VA em 2007 e 10,1% em 2017) e classificação por domínios (edições 2020 em
  diante) não se emendam. Na série por domínios vale para cada ano a edição mais recente que o traz. As edições revisam números,
  por exemplo 2019 vale 9,79% na edição 2020 e 9,49% na 2024. Sem dado por domínios para 2010, 2012 e 2014-2016.
- Rendimento do setor cultural, a base de preços do valor "real" não está escrita na tabela 6.6. Por isso o CSV usa a razão
  setor cultural sobre total, que não depende da base.
- UNCTAD 2024 tem só 131 economias com dado de bens criativos, contra 162 a 178 nos anos anteriores. A posição de 2024 não se
  compara com a dos anos anteriores. Argentina e México não estão no arquivo de serviços criativos. Chile tem só importação, Tailândia e
  Maldivas aparecem sem valor de exportação na maior parte dos anos.
- Valores da UNCTAD vêm marcados como "Estimated" quando a própria UNCTAD estima. A marca vai na coluna `nota_unctad`.

- Quebra de 2014 nos serviços do Brasil [A, nos arquivos da UNCTAD e do BCB; a causa é documental, ver abaixo].
  - Os números da UNCTAD para o Brasil são os do BCB. Telecomunicação, computação e informação: UNCTAD 707,88 e 1.446,45 milhões de US$
    em 2013 e 2014; SGS 22780, somado no ano, 708,0 e 1.446,5. Audiovisual: 0,47 e 265,41 contra SGS 22792 0,4 e 265,2. O salto está na
    fonte brasileira.
  - O salto é de reclassificação, não de volume. De 2013 para 2014 o total de serviços exportados sobe 5% (37.631 para 39.498 milhões),
    mas computação vai de 394 para 947, audiovisual de 0,5 para 265, consultoria profissional e gerencial (que contém publicidade e
    pesquisa de mercado) de 1.264 para 4.117, enquanto "outros serviços pessoais, culturais e recreativos" cai de 2.745 para 415,
    financeiros de 2.743 para 1.176 e governo de 1.668 para 919. Manufatura sobre insumos de terceiros e construção saem de zero em 2010-2013
    para 17,6 e 288,3. Os anos de 2010 a 2013 têm um terceiro regime: serviços pessoais, culturais e recreativos (SK, SGS 22789) fica
    entre 2.358 e 2.957 (contra 80 e 86 em 2009 e 2008) e o audiovisual quase zera (0,1 a 2,0 contra 25 a 26 em 2008-2009).
  - A causa documentada. A nota metodológica n. 1 do BCB sobre o BPM6 (novembro de 2014, `bcb-nota-metodologica-1-bpm6-2014-11.pdf`) diz
    que o balanço de pagamentos brasileiro é compilado a partir dos registros do Sistema Câmbio e que "Em fevereiro de 2014 entrou em vigor
    nova codificação para o Sistema Câmbio, desenhada para simplificar e racionalizar o conjunto de informações requeridas e, ao mesmo
    tempo, atender necessidades estatísticas impostas pela publicação do BPM6". As FAQ do BCB (`bcb-faq-bpm5-bpm6.pdf`) dizem que "A partir
    de abril de 2015, o Banco Central do Brasil (BCB) passará a publicar as estatísticas de Balanço de Pagamentos (BP) e Posição
    Internacional de Investimento (PII) em conformidade com a sexta edição" e listam a passagem dos serviços de manufatura e de manutenção
    e reparo de bens para serviços. As séries SGS em BPM6 começam em 1995, então os anos anteriores a 2014 são conversão de dados
    coletados com a codificação antiga. Que a nova codificação seja a causa do degrau nas categorias é inferência a partir da data e do
    padrão [B]; o BCB não publica, nos arquivos baixados, uma nota que quantifique a quebra por categoria.
  - A UNCTAD avisa que a base é experimental. O relatório técnico do Creative Economy Outlook 2024 (`unctad-creative-economy-outlook-2024-tecnico.pdf`)
    diz que os dados de serviços criativos usam a base anual UNCTAD-OMC "complemented with adjustments and estimates representing over 70 per
    cent of records, making the dataset experimental", e lista as dez categorias EBOPS usadas (SH2, SH3, SH4, SI21, SI3, SJ1, SJ22, SJ311,
    SK1, SK23). O Brasil não publica SI21, SJ22, SJ311 nem SK23 no detalhe (só SI2, SJ2, SJ31 e SK2), então a UNCTAD estima a parte criativa.
  - Uso: série de serviços criativos do Brasil só de 2014 em diante. 4,5% (2010) contra 14,8% (2024) não é crescimento medido.

## Lacunas
- Participação da cultura no PIB, as tabelas do SIIC dão valor adicionado sobre o universo PIA+PAC+PAS, não sobre o PIB. Não há
  conta satélite da cultura publicada pelo IBGE nesta consulta.
- POF 2002-2003, a edição 2007-2010 do SIIC traz só a POF 2008-2009. A POF 2002-2003 não foi procurada em edições mais antigas.
- MUNIC depois de 2021, a edição 2024 do SIIC não traz a tabela de equipamentos.
- Emprego cultural internacional em série, a UIS cobre só 2010-2016, com um ou dois anos por país, e o Brasil fica de fora do
  indicador principal. ILOSTAT não foi consultado à parte. Sem série internacional comparável para o Brasil.
- A tabela 1 do SIIC 2024 (CEMPRE, empresas formais) foi baixada e não entrou no build.
- UNESCO UIS de comércio de bens culturais (série antiga 2004-2013) não foi baixada. A UNCTAD cobre o tema com série mais longa.

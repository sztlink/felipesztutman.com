#!/usr/bin/env python3
# Frente CU2. Cultura como indicador de desenvolvimento. Baixa o Sistema de Informacoes e Indicadores Culturais (SIIC) do IBGE
# e as series internacionais comparaveis, uma requisicao por vez, com pausa (IBGE com pausa maior).
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CU2/baixa_CU2.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
S = 'https://ftp.ibge.gov.br/Indicadores_Sociais/Sistema_de_Informacoes_e_Indicadores_Culturais/'
U = 'https://unctadstat-api.unctad.org/bulkdownload/'
B = 'https://www.bcb.gov.br/'
I = 'https://api.uis.unesco.org/api/public/data/indicators?indicator='
ALVOS = [
  ('siic2024-indice.pdf', 'IBGE, SIIC edicao 2024, indice de tabelas (versao de 09/03/2026)', S + '2024/indice_de_tabelas_2024_20260309.pdf', 8),
  ('siic2024-1-atividades-formais.xlsx', 'IBGE, SIIC 2024, tabelas 1, atividades culturais formalmente constituidas (CEMPRE)',
   S + '2024/xlsx/1_atividades_formalmente_constituidas.xlsx', 8),
  ('siic2024-2-pesquisas-estruturais.xlsx', 'IBGE, SIIC 2024, tabelas 2, pesquisas estruturais em empresas (PIA, PAC, PAS), valor adicionado e receita',
   S + '2024/xlsx/2_pesquisas_estruturais_em_empresas.xlsx', 8),
  ('siic2024-6-ocupacao.zip', 'IBGE, SIIC 2024, tabelas 6, ocupacao no setor cultural (PNAD Continua)', S + '2024/xlsx/6_ocupacao_no_setor_cultural.zip', 8),
  ('siic2024-10-comercio-exterior.zip', 'IBGE, SIIC 2024, tabelas 10, comercio exterior de bens e servicos culturais',
   S + '2024/xlsx/10_comercio_exterior_de_bens_e_servicos_culturais.zip', 8),
  ('siic2022-5-gastos-familias.xlsx', 'IBGE, SIIC 2022, tabelas 5, gastos das familias com cultura (POF)', S + '2022/xlsx/5_gastos_das_familias.xlsx', 8),
  ('siic2022-8-equipamentos.zip', 'IBGE, SIIC 2022, tabelas 8, acesso a equipamentos culturais (MUNIC) e Lei Aldir Blanc',
   S + '2022/xlsx/8_acesso_a_equipamentos_e_Lei_Aldir_Blanc.zip', 8),
  ('siic2020-5-gastos-familias.xlsx', 'IBGE, SIIC 2020, tabelas 5, gastos das familias com cultura (POF 2017-2018)', S + '2020/xlsx/5_gastos_das_familias.xlsx', 8),
  ('siic2020-2-pesquisas-estruturais.xlsx', 'IBGE, SIIC 2020, tabelas 2, pesquisas estruturais em empresas (versao de 31/10/2023), para alongar a serie',
   S + '2020/xlsx/2_pesquisas_estruturais_em_empresas_20231031.xlsx', 8),
  ('siic2022-2-pesquisas-estruturais.xlsx', 'IBGE, SIIC 2022, tabelas 2, pesquisas estruturais em empresas, para alongar a serie',
   S + '2022/xlsx/2_pesquisas_estruturais_em_empresas.xlsx', 8),
  ('siic2018-2-pesquisas-estruturais.zip', 'IBGE, SIIC 2018 (serie 2007-2018), tabelas 2, pesquisas estruturais economicas',
   S + '2018/xlsx/2_Pesquisas_estruturais_economicas_xlsx.zip', 8),
  ('siic2018-5-gastos-familias.zip', 'IBGE, SIIC 2018 (serie 2007-2018), tabelas 5, gastos das familias (POF 2002-2003 e 2008-2009)',
   S + '2018/xlsx/5_Gastos_das_familias_xlsx.zip', 8),
  ('siic2018-8-equipamentos.zip', 'IBGE, SIIC 2018 (serie 2007-2018), tabelas 8, acesso a equipamentos culturais e meios de comunicacao (MUNIC)',
   S + '2018/xlsx/8_Acesso_a_equipamentos_culturais_e_meios_de_comunicacao_xlsx.zip', 8),
  ('siic2010-tabelas-xls.zip', 'IBGE, SIIC 2007-2010 (edicao de 2013), todas as tabelas de resultados em xls, inclui POF 2002-2003 e 2008-2009',
   S + '2010/tabelas_de_resultados/tabelas_xls.zip', 8),
  ('unctad-creative-goods-value.7z', 'UNCTADstat, US.CreativeGoodsValue, comercio de bens criativos, US$ correntes, por economia, parceiro e grupo de produto, 2002 em diante (arquivo 7z com CSV)',
   U + 'US.CreativeGoodsValue/US_CreativeGoodsValue', 3),
  ('unctad-creative-services.7z', 'UNCTADstat, US.CreativeServ_Indiv_Tot, comercio de servicos criativos, total, US$ correntes e % do comercio de servicos, 2010 em diante (7z com CSV)',
   U + 'US.CreativeServ_Indiv_Tot/US_CreativeServ_Indiv_Tot', 3),
  ('uis-emprego-cultural.json', 'UNESCO UIS, CE.RA.CULOCC1.1.O.CULIND1.1.OV.ILOSTAT.1, percentual de pessoas em emprego cultural (FCS 2009, a partir de microdados do ILOSTAT)',
   I + 'CE.RA.CULOCC1.1.O.CULIND1.1.OV.ILOSTAT.1&indicatorMetadata=true', 3),
  ('uis-ocupacoes-culturais.json', 'UNESCO UIS, CE.RA.CULOCC1.1.OV.ILOSTAT.1, percentual de pessoas em ocupacoes culturais',
   I + 'CE.RA.CULOCC1.1.OV.ILOSTAT.1&indicatorMetadata=true', 3),
  ('uis-cinemas.json', 'UNESCO UIS, 220174, numero total de cinemas (salas cobertas), 1995 a 2017', I + '220174&indicatorMetadata=true', 3),
  ('unctad-trade-services-categorias.7z', 'UNCTADstat, US.TradeServCatTotal, comercio de servicos por categoria EBOPS 2010 (BPM6), todas as economias, 2005 em diante (7z com CSV), para decompor o salto de 2014 dos servicos criativos do Brasil',
   U + 'US.TradeServCatTotal/US_TradeServCatTotal', 3),
  ('unctad-creative-economy-outlook-2024-tecnico.pdf', 'UNCTAD, Creative Economy Outlook 2024, Technical and statistical report (lista das categorias EBOPS dos servicos criativos, tabela 2, e aviso de base experimental)',
   'https://digitallibrary.un.org/record/4061670/files/1416030-EN.pdf', 3),
  ('bcb-nota-metodologica-1-bpm6-2014-11.pdf', 'Banco Central do Brasil, nota metodologica n. 1 da adocao do BPM6 (novembro de 2014), registra a nova codificacao do Sistema Cambio em fevereiro de 2014',
   B + 'ftp/infecon/nm1bpm6p.pdf', 5),
  ('bcb-faq-bpm5-bpm6.pdf', 'Banco Central do Brasil, perguntas frequentes sobre a conversao de BPM5 para BPM6 (publicacao em BPM6 a partir de abril de 2015)',
   B + 'ftp/infecon/faqbpm6p.pdf', 5),
] + [(f'bcb-sgs-{c}.json', f'Banco Central do Brasil, SGS {c}, {d}, mensal, US$ milhoes, BPM6', f'https://api.bcb.gov.br/dados/serie/bcdata.sgs.{c}/dados?formato=json', 5)
     for c, d in [('22720', 'servicos, receita'), ('22780', 'telecomunicacao, computacao e informacoes, receita'),
                  ('22789', 'servicos culturais, pessoais e recreativos, receita'), ('22792', 'servicos audiovisuais e relacionados, receita'),
                  ('22795', 'servicos de saude, educacao e outros culturais, pessoais e recreativos, receita')]] + [
  ('wdi-populacao.json', 'Banco Mundial, WDI, SP.POP.TOTL, populacao, todos os paises, 1995 a 2025 (para cinemas por milhao de habitantes)',
   'https://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL?format=json&date=1995:2025&per_page=20000', 3),
]
linhas = []
for arq, desc, url, pausa in ALVOS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) dossie-desenvolvimento'})
    open(dst, 'wb').write(urllib.request.urlopen(req, timeout=900).read()); print('baixou', arq, flush=True); time.sleep(pausa)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, f'fontes/{arq}', url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

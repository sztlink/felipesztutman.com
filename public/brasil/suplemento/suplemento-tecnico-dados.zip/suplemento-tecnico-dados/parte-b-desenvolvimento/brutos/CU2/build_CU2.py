#!/usr/bin/env python3
# Frente CU2. Cultura como indicador de desenvolvimento. Le so os arquivos de brutos/CU2/fontes (ver downloads.tsv) e grava
# CU2-*.csv na raiz do volume. Nenhum numero digitado, so rotulos e codigos de linha/coluna das tabelas.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CU2/build_CU2.py
# openpyxl, xlrd e py7zr vem do site-packages do usuario, acrescentado no fim do sys.path.
import csv, io, json, os, site, sys, zipfile
sys.path.append(site.getusersitepackages())
import openpyxl, xlrd, py7zr
from py7zr.io import Py7zIO, WriterFactory
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); SAI = os.path.abspath(os.path.join(AQUI, '..', '..'))
fp = lambda a: os.path.join(F, a)

def presidente(ano):
  # ano inteiro ou periodo 'AAAA-AAAA' (POF): usa o ano final do periodo de coleta e marca os dois quando mudam
  if isinstance(ano, str) and '-' in ano:
    a, b = (presidente(int(x)) for x in ano.split('-'))
    return a if a == b else f'{a}/{b}'
  ano = int(ano)
  for i, f, n in [(1997, 2002, 'FHC'), (2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'), (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'),
                  (2017, 2018, 'Temer'), (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]:
    if i <= ano <= f: return n
  return ''

def xlsx(arq, membro=None):
  if membro is None: return openpyxl.load_workbook(fp(arq), read_only=True, data_only=True)
  z = zipfile.ZipFile(fp(arq)); n = [m for m in z.namelist() if m.startswith(membro)]
  assert len(n) == 1, (arq, membro, n)
  if n[0].endswith('.xls'): return xlrd.open_workbook(file_contents=z.read(n[0]))
  return openpyxl.load_workbook(io.BytesIO(z.read(n[0])), read_only=True, data_only=True)
linhas = lambda ws: [list(r) for r in ws.iter_rows(values_only=True)]
def acha(rows, rotulo, col=0):
  for r in rows:
    if isinstance(r[col], str) and r[col].strip() == rotulo: return r
  raise KeyError(rotulo)

B = []  # indicadores do Brasil, formato longo
def add(ind, ano, valor, unidade, fonte, nota=''):
  B.append([ind, ano, presidente(ano), round(valor, 4) if isinstance(valor, float) else valor, unidade, fonte, nota])

# 1. Ocupacao no setor cultural, PNAD Continua (14 anos ou mais), SIIC 2024, tabelas 6.1a, 6.4 e 6.6, 2014-2024
OC = 'siic2024-6-ocupacao.zip'
wb = xlsx(OC, 'Tabela 6.1a')
for ws in wb.worksheets:
  if 'CV' in ws.title: continue
  r = linhas(ws); assert 'setor cultural' in str(r[2][13]), r[2][13]; t = acha(r, 'Total'); a = int(ws.title)
  add('ocupados_total', a, t[1], 'mil pessoas', 'IBGE SIIC 2024, tab. 6.1a (PNAD Continua)')
  add('ocupados_setor_cultural', a, t[13], 'mil pessoas', 'IBGE SIIC 2024, tab. 6.1a (PNAD Continua)', f'CV classe {t[14]}')
  add('ocupados_setor_cultural_pct', a, 100 * t[13] / t[1], '% dos ocupados', 'calculado de IBGE SIIC 2024, tab. 6.1a')
wb = xlsx(OC, 'Tabela 6.4')
for ws in wb.worksheets:
  if 'CV' in ws.title: continue
  r = linhas(ws); assert r[6][11] == 'Informal' and r[6][5] == 'Informal', r[6]; t = acha(r, 'Brasil'); a = int(ws.title)
  add('informalidade_todos_setores', a, t[5], '% dos ocupados', 'IBGE SIIC 2024, tab. 6.4')
  add('informalidade_setor_cultural', a, t[11], '% dos ocupados no setor cultural', 'IBGE SIIC 2024, tab. 6.4', f'CV classe {t[12]}')
wb = xlsx(OC, 'Tabela 6.6')
for ws in wb.worksheets:
  if 'CV' in ws.title: continue
  r = linhas(ws); assert r[3][15] == 'Setor cultural' and r[4][15] == 'Total', (r[3][15], r[4][15]); t = acha(r, 'Brasil'); a = int(ws.title)
  add('rendimento_medio_todos_setores', a, t[1], 'R$ (real, base da edicao)', 'IBGE SIIC 2024, tab. 6.6')
  add('rendimento_medio_setor_cultural', a, t[15], 'R$ (real, base da edicao)', 'IBGE SIIC 2024, tab. 6.6', f'CV classe {t[16]}')
  add('rendimento_cultural_sobre_total', a, 100 * t[15] / t[1], '% (setor cultural / todos)', 'calculado de IBGE SIIC 2024, tab. 6.6')

# 1b. Serie antiga, PNAD anual (10 anos ou mais), SIIC 2007-2010 (edicao de 2013), tabela 35. Nao emenda com a PNAD Continua.
sh = xlsx('siic2010-tabelas-xls.zip', 'xls/tab35.xls').sheet_by_index(0)
anos = [int(x) for x in sh.row_values(6)[1:6]]; br = sh.row_values(7); assert br[0].strip() == 'Brasil'
for i, a in enumerate(anos):
  add('ocupados_setor_cultural_pnad_antiga', a, br[6 + i], 'mil pessoas', 'IBGE SIIC 2007-2010, tab. 35 (PNAD anual, 10 anos ou mais)')
  add('ocupados_setor_cultural_pct_pnad_antiga', a, 100 * br[6 + i] / br[1 + i], '% dos ocupados', 'calculado de IBGE SIIC 2007-2010, tab. 35',
      'PNAD anual, nao comparavel com a PNAD Continua')

# 2. Empresas culturais nas pesquisas estruturais (PIA, PAC, PAS). Classificacao nova por dominios (edicoes 2020, 2022, 2024):
# para cada ano vale a edicao mais recente que o traz. Classificacao antiga AIC+ACC+ASC (SIIC 2007-2010 e edicao 2018) fica separada.
def estrut(arq, tab, rot_cult):
  ws = xlsx(arq)[tab]; r = linhas(ws); anos = r[3]; tot = acha(r, 'Total geral (*)'); cu = acha(r, rot_cult)
  return {int(anos[j]): (tot[j], cu[j], cu[j + 1]) for j in range(1, len(anos), 2) if anos[j] is not None}
dom = {}
for ed in ['2020', '2022', '2024']:
  arq = f'siic{ed}-2-pesquisas-estruturais.xlsx'
  for tab, ind in [('2.8', 'valor_adicionado'), ('2.2', 'pessoal_ocupado')]:
    for rot, sub in [('Total dos domínios culturais', 'dominios_culturais'), ('Total das atividades culturais centrais', 'atividades_centrais')]:
      for a, v in estrut(arq, tab, rot).items(): dom[(ind, sub, a)] = (v, ed)
for (ind, sub, a), ((tot, cu, cv), ed) in sorted(dom.items(), key=lambda k: (k[0][0], k[0][1], k[0][2])):
  add(f'empresas_{ind}_{sub}_pct', a, 100 * cu / tot, '% do total das empresas pesquisadas (PIA+PAC+PAS)',
      f'calculado de IBGE SIIC {ed}, tab. {"2.8" if ind == "valor_adicionado" else "2.2"}', f'classificacao por dominios; CV classe {cv}')
sh = xlsx('siic2010-tabelas-xls.zip', 'xls/tab10.xls').sheet_by_index(0)
assert sh.row_values(5)[9] == 2007.0 and 'Valor adicionado' in sh.row_values(3)[9]
tot, cu = sh.row_values(6), sh.row_values(7); assert 'Atividades culturais' in cu[0]
for j in range(4):
  add('empresas_valor_adicionado_classif_antiga_pct', int(sh.row_values(5)[9 + j]), 100 * cu[9 + j] / tot[9 + j], '% do total (IT+CO+SE)',
      'calculado de IBGE SIIC 2007-2010, tab. 10', 'classificacao antiga AIC+ACC+ASC')
ws = xlsx('siic2018-2-pesquisas-estruturais.zip', 'Tabelas 2.1 a 2.8')['2.8']; r = linhas(ws)
tot, cu = acha(r, 'Total geral (IT+CO+SE)'), acha(r, 'Atividades culturais (AIC+ACC+ASC)')
for j in range(1, len(r[3]), 2):
  if r[3][j] is None: continue
  a = int(r[3][j])
  if a == 2007: continue  # 2007 ja vem da edicao 2007-2010; a edicao 2018 o republica revisado, registrado so na nota abaixo
  add('empresas_valor_adicionado_classif_antiga_pct', a, 100 * cu[j] / tot[j], '% do total (IT+CO+SE)', 'calculado de IBGE SIIC 2018, tab. 2.8',
      'classificacao antiga AIC+ACC+ASC')
add('empresas_valor_adicionado_classif_antiga_pct_2007_revisto', 2007, 100 * cu[1] / tot[1], '% do total (IT+CO+SE)', 'calculado de IBGE SIIC 2018, tab. 2.8',
    '2007 como republicado na edicao 2018')

# 3. Despesa das familias com cultura (POF). Cada edicao usa sua cesta de "cultura"; os tres numeros nao formam serie.
sh = xlsx('siic2010-tabelas-xls.zip', 'xls/tab19.xls').sheet_by_index(0)
cul = [sh.row_values(i) for i in range(sh.nrows) if str(sh.row_values(i)[0]).strip() == 'Cultura'][0]
add('familias_cultura_pct_despesa_consumo', '2008-2009', cul[1], '% da despesa de consumo', 'IBGE SIIC 2007-2010, tab. 19 (POF 2008-2009)',
    f'mais pobres {cul[2]} / mais ricos {cul[7]} (faixas extremas de renda da tabela)')
ws = xlsx('siic2018-5-gastos-familias.zip', 'Tabelas 5.1 a 5.8')['5.2']; r = linhas(ws); c = acha(r, 'Cultura')
add('familias_cultura_pct_despesa_consumo', '2017-2018', c[1], '% da despesa de consumo', 'IBGE SIIC 2018, tab. 5.2 (POF 2017-2018)',
    f'mais pobres {c[3]} / mais ricos {c[15]} (faixas extremas de renda da tabela)')
ws = xlsx('siic2020-5-gastos-familias.xlsx')['5.1']; r = linhas(ws); assert r[1][1] == 'Despesa de consumo total' and r[1][3] == 'Despesa com Cultura'
b = acha(r, 'Brasil')
add('familias_cultura_reais_mes', '2017-2018', b[3], 'R$ por familia por mes', 'IBGE SIIC 2020, tab. 5.1 (POF 2017-2018)')
add('familias_cultura_pct_despesa_consumo_ed2020', '2017-2018', 100 * b[3] / b[1], '% da despesa de consumo', 'calculado de IBGE SIIC 2020, tab. 5.1',
    'cesta de cultura da edicao 2020, diferente da edicao 2018')
for rot in ['Urbano', 'Rural', 'Norte', 'Nordeste', 'Sudeste', 'Sul', 'Centro-Oeste']:
  x = acha(r, rot); add(f'familias_cultura_reais_mes_{rot.lower()}', '2017-2018', x[3], 'R$ por familia por mes', 'IBGE SIIC 2020, tab. 5.1')

# 4. Comercio exterior de bens culturais (NCM selecionada) e servicos audiovisuais (BCB), SIIC 2024, tabelas 10.1 e 10.4
wb = xlsx('siic2024-10-comercio-exterior.zip', 'Tabela 10.1')
for ws in wb.worksheets:
  if not ws.title.isdigit(): continue
  r = linhas(ws); t = acha(r, 'Total'); a = int(ws.title); assert r[2][2] == 'Importação' and r[2][5] == 'Exportação'
  add('bens_culturais_importacao', a, t[3], 'R$ milhoes FOB', 'IBGE SIIC 2024, tab. 10.1')
  add('bens_culturais_exportacao', a, t[6], 'R$ milhoes FOB', 'IBGE SIIC 2024, tab. 10.1')
  add('bens_culturais_pct_importacoes', a, t[4], '% das importacoes de bens', 'IBGE SIIC 2024, tab. 10.1')
  add('bens_culturais_pct_exportacoes', a, t[7], '% das exportacoes de bens', 'IBGE SIIC 2024, tab. 10.1')
  add('bens_culturais_cobertura_exp_sobre_imp', a, 100 * t[6] / t[3], '% (exportacao / importacao)', 'calculado de IBGE SIIC 2024, tab. 10.1')
wb = xlsx('siic2024-10-comercio-exterior.zip', 'Tabela 10.4')
for ws in wb.worksheets:
  if not ws.title.isdigit(): continue
  r = [x for x in linhas(ws) if x and x[0]]; a = int(ws.title)
  i = [k for k, x in enumerate(r) if str(x[0]).startswith('Serviços audiovisuais')][0]
  rec, desp = r[i + 2], r[i + 3]; assert 'Receitas' in rec[0] and 'Despesas' in desp[0]
  add('servicos_audiovisuais_receita', a, rec[1], 'R$ milhoes', 'IBGE SIIC 2024, tab. 10.4 (BCB, balanco de pagamentos)')
  add('servicos_audiovisuais_despesa', a, desp[1], 'R$ milhoes', 'IBGE SIIC 2024, tab. 10.4 (BCB, balanco de pagamentos)')

# 5. Equipamentos culturais nos municipios (MUNIC 1999-2021), SIIC 2022, tabela 8.7, e residentes em municipio com equipamento (8.1-8.4)
M = []
ws = xlsx('siic2022-8-equipamentos.zip', 'Tabela 8.7')['Tab 8.7']; r = linhas(ws); anos = r[2]
for x in r[3:]:
  if not x[0] or str(x[0]).startswith(('Fonte', '(1)')): continue
  for j in range(1, len(anos)):
    if anos[j] is None or j >= len(x) or not isinstance(x[j], (int, float)): continue
    M.append([x[0].strip(), int(anos[j]), presidente(int(anos[j])), round(x[j], 2), '% dos municipios', 'IBGE SIIC 2022, tab. 8.7 (MUNIC)'])
for tab, eq in [('Tabela 8.1 ', 'museu'), ('Tabela 8.2 ', 'teatro ou sala de espetaculo'), ('Tabela 8.3 ', 'cinema'), ('Tabela 8.4 ', 'radio AM ou FM local')]:
  sh = xlsx('siic2022-8-equipamentos.zip', tab).sheet_by_name('2021')
  h = sh.row_values(5); assert h[8] == 'Branca' and h[10] == 'Preta ou parda', h
  br = [sh.row_values(i) for i in range(sh.nrows) if sh.row_values(i)[0] == 'Brasil'][0]
  for j, g in [(2, 'total'), (8, 'brancos'), (10, 'pretos ou pardos')]:
    M.append([f'Residentes em municipio com {eq}, {g}', 2021, presidente(2021), round(br[j], 2), '% da populacao', f'IBGE SIIC 2022, {tab.strip().lower()} (MUNIC 2021 e PNAD Continua)'])
with open(os.path.join(SAI, 'CU2-brasil-municipios-equipamentos.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['equipamento', 'ano', 'presidente', 'valor', 'unidade', 'fonte']); w.writerows(M)

with open(os.path.join(SAI, 'CU2-brasil-indicadores.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['indicador', 'ano', 'presidente', 'valor', 'unidade', 'fonte', 'nota']); w.writerows(B)

# 6. Internacional. Comparadores do volume.
comp = {}
for r in csv.DictReader(open(os.path.join(SAI, 'comparadores.csv'), encoding='utf-8')): comp[r['iso3']] = r['grupo']
pop = {}
for r in json.load(open(fp('wdi-populacao.json'), encoding='utf-8'))[1]:
  if r['value'] is not None: pop[(r['countryiso3code'], int(r['date']))] = r['value']
nomes = {r['countryiso3code']: r['country']['value'] for r in json.load(open(fp('wdi-populacao.json'), encoding='utf-8'))[1]}

# 6a. UNESCO UIS, emprego cultural e ocupacoes culturais (2010-2016) e cinemas (1995-2017)
with open(os.path.join(SAI, 'CU2-uis-emprego-cultural.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['indicador', 'iso3', 'pais', 'grupo', 'ano', 'presidente_brasil', 'valor_pct_ocupados'])
  for arq, ind in [('uis-emprego-cultural.json', 'emprego cultural (setor cultural + ocupacoes culturais fora dele)'),
                   ('uis-ocupacoes-culturais.json', 'ocupacoes culturais')]:
    for x in sorted(json.load(open(fp(arq), encoding='utf-8'))['records'], key=lambda x: (x['geoUnit'], x['year'])):
      w.writerow([ind, x['geoUnit'], nomes.get(x['geoUnit'], ''), comp.get(x['geoUnit'], 'fora dos comparadores'), x['year'], presidente(x['year']), round(x['value'], 2)])
with open(os.path.join(SAI, 'CU2-uis-cinemas.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais', 'grupo', 'ano', 'presidente_brasil', 'cinemas', 'populacao', 'cinemas_por_milhao_hab'])
  for x in sorted(json.load(open(fp('uis-cinemas.json'), encoding='utf-8'))['records'], key=lambda x: (x['geoUnit'], x['year'])):
    if x['geoUnit'] not in comp: continue
    p = pop.get((x['geoUnit'], x['year']))
    w.writerow([x['geoUnit'], nomes.get(x['geoUnit'], ''), comp[x['geoUnit']], x['year'], presidente(x['year']), x['value'], p or '',
                round(1e6 * x['value'] / p, 2) if p else ''])

# 6b. UNCTADstat, comercio de bens criativos (CSV de 4 GB dentro do 7z, lido em fluxo, sem gravar no disco) e de servicos criativos
ROT = {'Brazil': 'BRA', 'Argentina': 'ARG', 'Chile': 'CHL', 'Colombia': 'COL', 'Mexico': 'MEX', 'Peru': 'PER', 'Uruguay': 'URY', 'China': 'CHN',
       'India': 'IND', 'Indonesia': 'IDN', 'Turkiye': 'TUR', 'South Africa': 'ZAF', 'Poland': 'POL', 'Republic of Korea': 'KOR',
       'United States': 'USA', 'United States of America': 'USA', 'Guyana': 'GUY', 'Belarus': 'BLR', 'Mauritius': 'MUS', 'Serbia': 'SRB',
       'Georgia': 'GEO', 'North Macedonia': 'MKD', 'Dominican Republic': 'DOM', 'Maldives': 'MDV', 'Albania': 'ALB', 'Thailand': 'THA',
       'Azerbaijan': 'AZE', 'Bosnia and Herzegovina': 'BIH', 'Armenia': 'ARM', 'World': 'WLD'}
GRUPOS = {'CER000', 'CER010', 'CER020', 'CER030', 'CER040', 'CER050', 'CER060', 'CER070'}
class Filtro(Py7zIO):
  def __init__(s): s.resto = b''; s.cab = None; s.rows = []; s.n = 0
  def write(s, b):
    d = s.resto + b; ls = d.split(b'\n'); s.resto = ls.pop()
    for l in ls:
      if s.cab is None: s.cab = next(csv.reader([l.decode('utf-8')])); continue
      p = l.split(b',', 8)  # Year,Economy,"Label",Partner,"Label",Flow,"Label",Product,...
      if len(p) < 9 or b'"' in p[2] and not p[2].endswith(b'"'): p = None
      if p is None:
        x = next(csv.reader([l.decode('utf-8')]))
        if x[3] == '0000' and x[7] == 'CER000': s.rows.append(x)
        continue
      if p[3] != b'0000': continue
      prod = p[7].decode()
      if prod == 'CER000' or (prod in GRUPOS and p[1] == b'076'): s.rows.append(next(csv.reader([l.decode('utf-8')])))
    s.n += len(b); return len(b)
  def read(s, n=None): return b''
  def seek(s, o, w=0): return 0
  def flush(s): pass
  def size(s): return s.n
class Fab(WriterFactory):
  def create(s, nome): s.f = Filtro(); return s.f
fab = Fab()
with py7zr.SevenZipFile(fp('unctad-creative-goods-value.7z')) as z: z.extractall(factory=fab)
cab, G = fab.f.cab, fab.f.rows
ix = {k: cab.index(k) for k in ['Year', 'Economy', 'Economy Label', 'Flow Label', 'Product', 'Product Label', 'US$ at current prices in millions',
                                  'Percentage of total world', 'Percentage of total merchandise trade', 'US$ at current prices in millions Footnote']}
num = lambda v: float(v) if v not in ('', None) else None
# economias individuais: codigo M49 numerico de 3 digitos; agregados da UNCTAD tem codigo de 4 digitos
paises_g = [x for x in G if x[ix['Product']] == 'CER000' and len(x[ix['Economy']]) == 3]
with open(os.path.join(SAI, 'CU2-unctad-bens-criativos.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais_unctad', 'grupo', 'ano', 'presidente_brasil', 'fluxo', 'produto', 'usd_milhoes_correntes', 'pct_do_mundo',
                                 'pct_do_comercio_de_mercadorias', 'nota_unctad'])
  for x in sorted(G, key=lambda x: (x[ix['Economy Label']], x[ix['Product']], x[ix['Flow Label']], int(x[ix['Year']]))):
    iso = ROT.get(x[ix['Economy Label']])
    if not iso: continue
    w.writerow([iso, x[ix['Economy Label']], comp.get(iso, 'agregado mundial' if iso == 'WLD' else ''), int(x[ix['Year']]), presidente(int(x[ix['Year']])),
                x[ix['Flow Label']], x[ix['Product Label']], x[ix['US$ at current prices in millions']], x[ix['Percentage of total world']],
                x[ix['Percentage of total merchandise trade']], x[ix['US$ at current prices in millions Footnote']]])
# posicao do Brasil entre as economias individuais, exportacao de todos os bens criativos
with open(os.path.join(SAI, 'CU2-unctad-brasil-posicao.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['ano', 'presidente_brasil', 'exp_bens_criativos_usd_mi', 'posicao_em_valor', 'economias_com_dado', 'pct_do_mundo',
                                 'pct_das_exportacoes_de_mercadorias', 'posicao_em_pct_das_exportacoes', 'economias_com_pct',
                                 'mediana_pct_das_exportacoes_comparadores'])
  for a in sorted({int(x[ix['Year']]) for x in paises_g}):
    ex = [x for x in paises_g if int(x[ix['Year']]) == a and x[ix['Flow Label']] == 'Exports' and num(x[ix['US$ at current prices in millions']]) is not None]
    br = [x for x in ex if x[ix['Economy']] == '076']
    if not br: continue
    br = br[0]; v = num(br[ix['US$ at current prices in millions']]); s = num(br[ix['Percentage of total merchandise trade']])
    com_pct = [num(x[ix['Percentage of total merchandise trade']]) for x in ex if num(x[ix['Percentage of total merchandise trade']]) is not None]
    cp = sorted(num(x[ix['Percentage of total merchandise trade']]) for x in ex if ROT.get(x[ix['Economy Label']]) in comp
                and ROT.get(x[ix['Economy Label']]) != 'BRA' and num(x[ix['Percentage of total merchandise trade']]) is not None)
    w.writerow([a, presidente(a), v, 1 + sum(num(x[ix['US$ at current prices in millions']]) > v for x in ex), len(ex), br[ix['Percentage of total world']], s,
                (1 + sum(p > s for p in com_pct)) if s is not None else '', len(com_pct), round(cp[len(cp) // 2], 3) if cp else ''])
# servicos criativos
with py7zr.SevenZipFile(fp('unctad-creative-services.7z')) as z:
  class Mem(Py7zIO):
    def __init__(s): s.b = io.BytesIO()
    def write(s, b): return s.b.write(b)
    def read(s, n=None): return b''
    def seek(s, o, w=0): return 0
    def flush(s): pass
    def size(s): return s.b.tell()
  class FM(WriterFactory):
    def create(s, nome): s.m = Mem(); return s.m
  fm = FM(); z.extractall(factory=fm)
S = list(csv.DictReader(io.StringIO(fm.m.b.getvalue().decode('utf-8'))))
with open(os.path.join(SAI, 'CU2-unctad-servicos-criativos.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['iso3', 'pais_unctad', 'grupo', 'ano', 'presidente_brasil', 'fluxo', 'usd_milhoes_correntes', 'pct_do_comercio_de_servicos', 'nota_unctad'])
  for x in sorted(S, key=lambda x: (x['Economy Label'], x['Flow Label'], int(x['Year']))):
    iso = ROT.get(x['Economy Label'])
    if not iso: continue
    w.writerow([iso, x['Economy Label'], comp.get(iso, 'agregado mundial' if iso == 'WLD' else ''), int(x['Year']), presidente(int(x['Year'])), x['Flow Label'],
                x['US$ at current prices in millions'], x['Percentage of total trade in services'],
                x['US$ at current prices in millions Missing value'] or x['US$ at current prices in millions Footnote']])
faltam = sorted(set(comp) - {ROT[k] for k in {x[ix['Economy Label']] for x in paises_g} if k in ROT})
print(len(B), len(M), len(G), len(S), 'comparadores sem bens criativos na UNCTAD:', faltam)

# 7. Quebra de 2014 nos servicos do Brasil. Exportacoes por categoria EBOPS 2010 (UNCTADstat US.TradeServCatTotal) ao lado das series
# mensais do BCB (SGS, somadas no ano) e do total de servicos criativos da UNCTAD. Mostra que o salto de 2013 para 2014 esta nas
# categorias do proprio BCB, que trocou a codificacao do Sistema Cambio em fevereiro de 2014 (nota metodologica n. 1 do BPM6).
with py7zr.SevenZipFile(fp('unctad-trade-services-categorias.7z')) as z:
  fm2 = FM(); z.extractall(factory=fm2)
CAT = [('S', 'servicos_total'), ('SA', 'manufatura_insumos_de_terceiros'), ('SE', 'construcao'), ('SG', 'financeiros'),
       ('SH', 'propriedade_intelectual'), ('SI', 'telecom_computacao_informacao'), ('SI2', 'computacao'), ('SI3', 'informacao'), ('SJ1', 'pesquisa_e_desenvolvimento'),
       ('SJ2', 'consultoria_profissional_e_gerencial'), ('SJ31', 'arquitetura_engenharia_cientificos'), ('SK', 'pessoais_culturais_recreativos'), ('SK1', 'audiovisual'),
       ('SK2', 'outros_pessoais_culturais_recreativos'), ('SL', 'governo')]
TS = {}
for x in csv.DictReader(io.StringIO(fm2.m.b.getvalue().decode('utf-8'))):
  if x['Economy Label'] == 'Brazil' and x['Flow Label'] == 'Exports' and x['Category'] in dict(CAT):
    TS[(x['Category'], int(x['Year']))] = x['Millions of US$ at current prices']
def sgs(c):
  s = {}
  for r in json.load(open(fp(f'bcb-sgs-{c}.json'), encoding='utf-8')):
    a = int(r['data'][-4:]); s[a] = s.get(a, 0.0) + float(r['valor'])
  return s
SG = {c: sgs(c) for c in ('22720', '22780', '22789', '22792', '22795')}
CRI = {int(x['Year']): x['US$ at current prices in millions'] for x in S if x['Economy Label'] == 'Brazil' and x['Flow Label'] == 'Exports'}
regime = lambda a: 'ate 2009' if a <= 2009 else ('2010-2013' if a <= 2013 else 'BPM6 com codificacao do Sistema Cambio de fev/2014')
anos = sorted({a for _, a in TS})
with open(os.path.join(SAI, 'CU2-servicos-brasil-quebra-2014.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['ano', 'presidente_brasil', 'regime_dos_dados'] + ['unctad_exp_' + n + '_usd_mi' for _, n in CAT] +
             ['unctad_exp_servicos_criativos_usd_mi', 'bcb_sgs22720_servicos_receita_usd_mi', 'bcb_sgs22780_telecom_computacao_informacao_receita_usd_mi',
              'bcb_sgs22789_culturais_pessoais_recreativos_receita_usd_mi', 'bcb_sgs22792_audiovisuais_receita_usd_mi',
              'bcb_sgs22795_saude_educacao_outros_culturais_receita_usd_mi'])
  for a in anos:
    w.writerow([a, presidente(a), regime(a)] + [TS.get((c, a), '') for c, _ in CAT] + [CRI.get(a, '')] +
               [round(SG[c][a], 1) if a in SG[c] else '' for c in ('22720', '22780', '22789', '22792', '22795')])
print('quebra 2014, anos:', anos[0], anos[-1])

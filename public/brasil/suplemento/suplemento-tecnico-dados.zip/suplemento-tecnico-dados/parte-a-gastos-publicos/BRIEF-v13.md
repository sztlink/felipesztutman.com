# BRIEF v13, expectativas contra resultados (frente FB)

Protocolo fixado em 20/10/2026, antes de baixar os dados e de calcular qualquer erro. O commit deste arquivo vem antes do commit
dos dados.

## Pergunta
Com que precisão as expectativas de mercado formadas em outubro anteciparam o ano seguinte e o outro, e como se comportaram nos
anos de eleição presidencial em relação aos demais anos. A pergunta é sobre erro de previsão. Ela não mede qual governo causou
qual resultado, nem o que os investidores lembram ou preferem.

## Amostra e datas
- Anos de origem de 2000 a 2024. Em cada ano t, a data de origem é a última data com estatística do Focus (Olinda,
  ExpectativasMercadoAnuais, baseCalculo 0) até o sábado anterior ao primeiro domingo de outubro de t. Nos anos de eleição, esse
  domingo é o do primeiro turno (2002, 2006, 2010, 2014, 2018, 2022). A regra é a mesma em todos os anos.
- Horizontes h1 (ano t+1) e h2 (ano t+2). O último ano realizado é 2025.

## Variáveis, expectativa e realizado
- IPCA do ano, mediana do Focus, contra o IPCA de dezembro a dezembro (IBGE, SIDRA 1737, número-índice).
- PIB, crescimento real, mediana do Focus, contra a taxa acumulada no ano até o 4º trimestre da série atual do IBGE (SIDRA 5932).
  O IBGE revisa o PIB, e a comparação usa a série de hoje, não a primeira divulgação.
- Selic de fim de ano, mediana do Focus, contra a meta da Selic em 31/12 (BCB, SGS 432).
- Câmbio de fim de ano, mediana do Focus, contra a PTAX de venda do último dia útil do ano (BCB, SGS 1).
- Resultado primário do setor público consolidado, % do PIB, mediana do Focus, contra o primário acumulado em 12 meses em
  dezembro (BCB, SGS 5793, NFSP sem desvalorização cambial, com o sinal trocado para superávit positivo). A identidade da série é
  conferida contra a Tabela 2 das estatísticas fiscais do BCB de set/2026 para 2024 e 2025.
- Erro = realizado menos esperado, em pontos percentuais (em R$ por dólar no câmbio).

## Leitura fixada antes do cálculo
- Para cada variável e horizonte, a distribuição dos erros nos 25 anos de origem (mediana do erro, mediana do erro absoluto,
  percentis 10 e 90).
- Os seis anos de eleição aparecem como casos dentro dessa distribuição, com a posição do erro absoluto de cada um (posição
  entre os anos da amostra). Com seis casos não há teste de significância, e nenhum resultado é lido como diferença estatística.
- Parte B, curva de juros, desde 2008 (dados do pacote, W-curva-mensal.csv). Taxa prefixada de 1 ano do Tesouro Direto na média
  de setembro de cada ano contra a Selic média realizada nos 12 meses seguintes (outubro de t a setembro de t+1). O Tesouro Direto
  fica alguns pontos-base abaixo da curva de mercado, o que é declarado e não corrigido.

## O que fica fora
- Atribuição de resultado a governo, preferência de investidor e motivação de voto.
- Qualquer escolha de data ou variável depois de ver os erros. Se um dado faltar, o caso sai e a saída é registrada.

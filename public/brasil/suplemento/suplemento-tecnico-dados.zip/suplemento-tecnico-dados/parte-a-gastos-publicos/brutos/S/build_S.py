#!/usr/bin/env python3
# Cenarios condicionais da divida bruta (DBGG, criterio Bacen) de 2026 a 2030. Nao e previsao: cada cenario troca uma premissa
# e mostra o que ela exige. Identidade: d_t = d_{t-1} (1 + i_t) / (1 + g_t) - p_t, sem ajustes entre fluxo e estoque.
# Juro implicito i_t montado por indexador com os pesos de dez/2025 e calibrado para reproduzir o de 2025:
#   Selic e compromissadas pagam a Selic media do ano; prefixados e indexados a precos sao repreciados pela fracao do estoque
#   que vence em cada ano (perfil de vencimentos de dez/2025, RMD anexo 3.2, via brutos/W), da media de 2025 ate a taxa de
#   mercado de 10 anos do ultimo mes publicado; o resto (cambio) fica constante.
# g_t = (1 + PIB real) (1 + IPCA + ajuste de deflator) - 1.
# Entradas: J-dbgg-fatores.csv, J-dbgg-composicao.csv, O-custo-divida-indexador.csv, K-primario-recorrente.csv,
# N-juro-real-mensal.csv, N-juro-real-anual.csv, E-renuncias-e-subsidios.csv, Focus de 09/10/2026 (json do BCB) e PLDO 2027
# Anexo IV.2 (pdf: Tabela 1, grade macro; Tabela 3, primario projetado do Governo Central; Tabela 4, DBGG), em brutos/S/.
import csv, json, os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..', '..')
le = lambda f: list(csv.DictReader(open(os.path.join(RAIZ, f), newline='', encoding='utf-8')))
num = lambda v: float(v.replace('.', '').replace(',', '.')) if ',' in v else float(v)
JF = {(r['serie'], int(r['ano'])): float(r['valor_rs_mi']) for r in le('J-dbgg-fatores.csv') if r['valor_rs_mi']}
JC = {(r['serie'], int(r['ano'])): float(r['valor_pct_pib']) for r in le('J-dbgg-composicao.csv') if r['valor_pct_pib']}
OI = {(r['indexador'], int(r['ano'])): r for r in le('O-custo-divida-indexador.csv')}
PRIM = {int(r['ano']): float(r['primario_cheio_pct_pib']) for r in le('K-primario-recorrente.csv')}
NA = {int(r['ano']): r for r in le('N-juro-real-anual.csv')}
NML = le('N-juro-real-mensal.csv')
NM = {r['mes']: float(r['selic_meta_media_mes']) for r in NML if r['selic_meta_media_mes']}
ult = [r for r in NML if r['prefixado_10a'] and r['juro_real_10a']][-1]  # dado mais recente (pode ser mes parcial; ver dias_uteis_td)
pre10, real10, mes_mkt = float(ult['prefixado_10a']), float(ult['juro_real_10a']), ult['mes']
REN = next(r for r in le('E-renuncias-e-subsidios.csv') if r['ano'] == '2024' and r['subcategoria'] == 'Subsidios tributarios (renuncias)')
REN_PIB, REN_RS = float(REN['pct_pib']), float(REN['valor_brl']) / 1e9
D25 = next(float(r['pct_pib']) for r in le('D-rtn-despesa-primaria.csv') if r['ano'] == '2025' and r['categoria'] == '4. DESPESA TOTAL' and r['subcategoria'] == 'total')
PIB25 = next(float(r['pib_rs_mi']) for r in le('K-primario-recorrente.csv') if r['ano'] == '2025') / 1000
OBS = next(r for r in le('I-divida-bruta-anual.csv') if r['nota'].startswith('ultimo mes publicado'))
VV = le('V-reforma-consumo.csv')
fundo = lambda nm, a: next(float(r['valor']) for r in VV if r['item'].startswith(nm) and r['ano'] == str(a))
IPCA_I = {r['D3C']: float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json')))[1:]}
import html as _h
lc = re.sub(r'\s+', ' ', _h.unescape(re.sub(r'<[^>]+>', ' ', open(os.path.join(AQUI, 'planalto-lcp-200-2023.htm'), encoding='latin-1', errors='ignore').read())))
m = re.search(r'não será inferior a ([\d,]+)% a\.a\. \(seis décimos por cento ao ano\) nem superior a ([\d,]+)%', lc)
PISO, TETO = num(m.group(1)), num(m.group(2))

FO = {}
for r in json.load(open(os.path.join(AQUI, 'bcb-focus-olinda-anuais-out2026.json')))['value']:
  if r['Data'] == '2026-10-09' and r['baseCalculo'] == 0 and r['IndicadorDetalhe'] is None:
    FO.setdefault((r['Indicador'], int(r['DataReferencia'])), r['Mediana'])
sys.path.insert(0, os.path.expanduser('~/.local/lib/pdftools'))
import fitz
tx = re.sub(r'\s+', ' ', ' '.join(p.get_text() for p in fitz.open(os.path.join(AQUI, 'pldo2027-anexo-iv-02-metas-fiscais.pdf'))))
m = re.search(r'superávit primário de ([\d,]+)% do PIB\. Para 2028, a meta fiscal é de ([\d,]+)% do PIB; para 2029, ([\d,]+)% do PIB e; em 2030, ([\d,]+)% do PIB', tx)
META = {a: num(v) for a, v in zip((2027, 2028, 2029, 2030), m.groups())}
m = re.search(r'superávit primário, em percentual do PIB, de ([\d,]+)% em 2027, ([\d,]+)% em 2028, ([\d,]+)% em 2029 e ([\d,]+)% em 2030', tx)
PROJ = {a: num(v) for a, v in zip((2027, 2028, 2029, 2030), m.groups())}  # Tabela 3, Governo Central, antes das exclusoes da meta
g1 = tx[tx.index('Tabela 1: Grade de Parâmetros Macroeconômicos 2026 – 2030 Parâmetros'):]
linha = lambda rot: dict(zip(range(2025, 2031), [num(v) for v in re.search(re.escape(rot) + r' ((?:-?[\d.,]+ ){6})', g1).group(1).split()]))
G_PIB, G_IPCA, G_SEL = linha('PIB nominal (R$ bilhões)'), linha('IPCA acumulado (%)'), linha('Taxa Over - SELIC Acum ano (%)')
fx = re.sub(r'\s+', ' ', ' '.join(p.get_text() for p in fitz.open(os.path.join(AQUI, 'bcb-focus-R20261009.pdf'))))
g = re.findall(r'(-?\d+,\d+) (-?\d+,\d+) (-?\d+,\d+) [▲▼]?\(\d+\) \d+(?: -?\d+,\d+ \d+)?', fx[fx.index('Resultado primário (% do PIB)'):fx.index('Resultado nominal (% do PIB)')])
FPRIM = dict(zip(range(2026, 2030), [num(x[2]) for x in g]))  # coluna Hoje do Focus; setor publico consolidado
t4 = tx[tx.index('Tabela 4: Projeções de Variáveis Fiscais'):]
PLDO_DBGG = dict(zip(range(2027, 2031), [num(v) for v in re.search(r'Dívida Bruta do Governo Geral ((?:[\d,]+ ){4})', t4).group(1).split()]))
PLDO_SPNF = dict(zip(range(2027, 2031), [num(v) for v in re.search(r'Resultado Primário do Setor Público Não-Financeiro ((?:-?[\d,]+ ){4})', t4).group(1).split()]))  # mesmo perimetro do Focus

d0 = JC[('dbgg_total', 2025)]
i25 = JF[('dbgg_fat_juros_nominais', 2025)] / JF[('dbgg_fat_saldo', 2024)]
comp = JC[('dbgg_compromissadas_bcb', 2025)] / d0
pe = lambda ix: float(OI[(ix, 2025)]['pct_estoque_dez']) / 100
cu = lambda ix: float(OI[(ix, 2025)]['custo_medio_12m_pct'])
w_s = comp + (1 - comp) * pe('selic_flutuante'); w_f = (1 - comp) * pe('prefixado'); w_p = (1 - comp) * pe('indice_precos')
s25, ipca25 = float(NA[2025]['selic_meta_media']), float(NA[2025]['ipca'])
cf25 = cu('prefixado'); rr25 = 100 * ((1 + cu('indice_precos') / 100) / (1 + ipca25 / 100) - 1)
nom = lambda pi, rr: 100 * ((1 + pi / 100) * (1 + rr / 100) - 1)
K_CAL = 100 * i25 - (w_s * s25 + w_f * cf25 + w_p * nom(ipca25, rr25))  # cambio e residuo, constante
obs = [NM[f'2026-{j:02d}'] for j in range(1, 13) if f'2026-{j:02d}' in NM]
s_focus = {2026: (sum(obs) + (12 - len(obs)) * FO[('Selic', 2026)]) / 12}
for a in range(2027, 2031): s_focus[a] = (FO[('Selic', a - 1)] + FO[('Selic', a)]) / 2  # media do fim do ano anterior e do fim do ano
macro_focus = lambda a: (s_focus[a], FO[('IPCA', a)], (1 + FO[('PIB Total', a)] / 100) * (1 + FO[('IPCA', a)] / 100) - 1)
macro_pldo = lambda a: (G_SEL[a], G_IPCA[a], G_PIB[a] / G_PIB[a - 1] - 1)
p25 = PRIM[2025]
virg = lambda v, n: f'{v:.{n}f}'.replace('.', ',')
PV = {r['indexador']: r for r in csv.DictReader(open(os.path.join(RAIZ, 'brutos', 'W', 'perfil_vencimentos_dez2025.csv'), encoding='utf-8'))}
FX = ['ate 1 ano', '1 a 2 anos', '2 a 3 anos', '3 a 4 anos', '4 a 5 anos', 'acima de 5 anos']
def frac(ix, k):  # fracao media do estoque de dez/2025 ja repreciada no ano k (k=1 em 2026), vencimentos uniformes dentro do ano
  b = [float(PV[ix][c]) for c in FX]
  return sum(b[:k - 1]) + b[k - 1] / 2 if k <= 5 else sum(b[:5])

def roda(nome, prim, ds, desc, macro, defl, ds_m=None, dg=0.0, dm_fun=None, so_pre=False):
  # so_pre: o canal fiscal (dm_fun) entra so no prefixado (juro nominal), nao na taxa real das NTN-B
  # ds: choque na Selic; ds_m: choque nas taxas de mercado (None = igual a ds, curva inteira); dg: crescimento real extra;
  # dm_fun(a): choque nas taxas de mercado ano a ano (canal fiscal), soma-se a ds_m
  ds_m = ds if ds_m is None else ds_m
  d, out = d0, []
  S0 = d0 / 100 * PIB25; Sprev, pibn = S0, PIB25  # estoque nominal: a emissao liquida nova sai a taxa de mercado
  for a in range(2026, 2031):
    s, pi, g = macro(a)
    dd, dm = (ds, ds_m) if a >= 2027 else (0.0, 0.0)
    dmf = dm_fun(a) if dm_fun else 0.0
    dm_r = dm + (0.0 if so_pre else dmf); dm += dmf
    s += dd
    dga = dg(a) if callable(dg) else dg
    if a >= 2027: g = (1 + g) * (1 + defl / 100) * (1 + dga / 100) - 1
    ka = a - 2025
    phi = lambda ix: 1 - (1 - frac(ix, ka)) * S0 / Sprev  # fracao a taxa nova: vencimentos rolados e emissao liquida acumulada
    cf = cf25 + phi('prefixado (DPMFi)') * (pre10 + dm - cf25); rr = rr25 + phi('indice de precos (DPMFi)') * (real10 + dm_r - rr25)
    i = (K_CAL + w_s * s + w_f * cf + w_p * nom(pi, rr)) / 100
    jur = d * i / (1 + g); p = prim(a); dp = d
    d = d * (1 + i) / (1 + g) - p
    pibn *= 1 + g; Sprev = d / 100 * pibn
    out.append(dict(cenario=nome, ano=a, selic_media=round(s, 2), ipca=round(pi, 2), juro_implicito=round(100 * i, 2), cresc_nominal=round(100 * g, 2),
                    primario_pct_pib=round(p, 2), juros_pct_pib=round(jur, 2), divida_pct_pib=round(d, 2),
                    primario_estabiliza=round(100 * (i - g) / (1 + g) * dp / 100, 2), descricao=desc))
  return out

pj = lambda a: PROJ.get(a, p25)
forte = lambda a: pj(a) + (REN_PIB / 5 if a >= 2028 else REN_PIB / 10 if a == 2027 else 0)
def real_pib(a):  # PIB real acumulado de 2026 ate a, pelo Focus
  f = 1.0
  for x in range(2027, a + 1): f *= 1 + FO[('PIB Total', x)] / 100
  return f
desp = lambda a: pj(a) + (D25 * ((1 + TETO / 100) ** (a - 2026) - (1 + PISO / 100) ** (a - 2026)) / real_pib(a) if a >= 2027 else 0)
CEN = [
  ('1. Inércia', lambda a: p25, 0.0, f'primário de 2025 ({virg(p25, 1)}% do PIB) em todos os anos; macro do Focus', macro_focus, 0.0),
  ('1b. Focus inteiro', lambda a: FPRIM.get(a, FPRIM[2029]) if a >= 2027 else p25, 0.0, 'primário, Selic, IPCA e PIB do Focus (primário do setor público consolidado; 2030 igual a 2029)', macro_focus, 0.0),
  ('2. Primário do PLDO', pj, 0.0, 'primário que o PLDO 2027 projeta para o Governo Central, antes das exclusões da meta; macro do Focus', macro_focus, 0.0),
  ('2b. O mesmo, deflator maior', pj, 0.0, 'como o 2, com o deflator do PIB 1 ponto acima do IPCA desde 2027', macro_focus, 1.0),
  ('3. PLDO e prêmio menor', pj, -1.5, 'como o 2, com Selic e taxas de mercado 1,5 ponto abaixo desde 2027', macro_focus, 0.0),
  ('4. Ajuste pela receita', forte, -1.5, f'como o 3, mais receita igual a 1/5 dos gastos tributários de 2024 ({virg(REN_PIB / 5, 2)}% do PIB por ano, metade em 2027)', macro_focus, 0.0),
  ('4b. Ajuste pela despesa', desp, -1.5, f'como o 3, com a despesa primária crescendo {virg(PISO, 1)}% real ao ano desde 2027, o piso do arcabouço, em vez de {virg(TETO, 1)}%, o teto', macro_focus, 0.0),
  ('5. Estresse', lambda a: p25, 2.0, 'primário de 2025; Selic e taxas de mercado 2 pontos acima do Focus desde 2027', macro_focus, 0.0),
  ('6. Grade do PLDO', pj, 0.0, 'primário, Selic, IPCA e PIB nominal da grade do PLDO 2027 (março/2026)', macro_pldo, 0.0),
]
linhas = [l for c in CEN for l in roda(*c)]
# sensibilidade a data da ancora de mercado: o ultimo mes completo no lugar do dado mais recente
parc = [r for r in NML if r['prefixado_10a'] and r['juro_real_10a'] and r['mes'] != r['consulta'][:7]][-1]  # referencia: ultimo mes completo
_p, _r = pre10, real10
pre10, real10 = float(parc['prefixado_10a']), float(parc['juro_real_10a'])
anc_alt = roda('alt', lambda a: PROJ.get(a, p25), 0.0, '', macro_focus, 0.0)[-1]['divida_pct_pib']
pre10, real10 = _p, _r
L = {(l['cenario'], l['ano']): l for l in linhas}
def pib_nom(c, a):
  v = PIB25
  for x in range(2026, a + 1): v *= 1 + L[(c, x)]['cresc_nominal'] / 100
  return v
c4 = '4. Ajuste pela receita'
ren_rs = {a: REN_PIB / 5 / 100 * pib_nom(c4, a) for a in (2028, 2030)}
ipca_f = IPCA_I['202512'] / IPCA_I['202312']
for a in range(2026, 2031): ipca_f *= 1 + FO[('IPCA', a)] / 100
fundos30 = (fundo('Fundo de Compensacao de Beneficios Fiscais do ICMS: aporte', 2030) + fundo('Fundo Nacional de Desenvolvimento Regional: aporte', 2030)) * ipca_f / pib_nom('2. Primário do PLDO', 2030) * 100
c4b = '4b. Ajuste pela despesa'
FONTE = ('BCB Focus 09/10/2026 (Olinda, ExpectativasMercadoAnuais); PLDO 2027 Anexo IV.2 p. 4, 6, 16 e 17; BCB estatisticas fiscais (J-dbgg-*); '
         'RMD ago/2026 (O-custo-divida-indexador); Tesouro Direto (N-juro-real-mensal); RTN (K-primario-recorrente); OSU 2024 (E-renuncias-e-subsidios)')
nota = (f'd_2025={d0}; i_2025={round(100 * i25, 2)}; peso_selic={round(w_s, 3)}; peso_prefixado={round(w_f, 3)}; peso_precos={round(w_p, 3)}; '
        f'custo_prefixado_2025={round(cf25, 2)}; juro_real_precos_2025={round(rr25, 2)}; prefixado_10a_mercado={pre10}; juro_real_10a_mercado={real10}; mes_mercado={mes_mkt}; dias_mes_mercado={ult["dias_uteis_td"]}; '
        f'ancora_alt_mes={parc["mes"]}; ancora_alt_pre10={parc["prefixado_10a"]}; ancora_alt_real10={parc["juro_real_10a"]}; ancora_alt_divida_2030_cenario2={anc_alt}; pldo_dbgg_2029={PLDO_DBGG[2029]}; pldo_dbgg_2030={PLDO_DBGG[2030]}; pldo_selic_2030={G_SEL[2030]}; pldo_cresc_nominal_2030={round(100 * (G_PIB[2030] / G_PIB[2029] - 1), 2)}; '
        f'ren_rs_2028={round(ren_rs[2028], 1)}; ren_rs_2030={round(ren_rs[2030], 1)}; desp_2025_pct_pib={D25}; piso={PISO}; teto={TETO}; desp_extra_2030={round(L[(c4b, 2030)]["primario_pct_pib"] - PROJ[2030], 2)}; fundos_2030_pct_pib={round(fundos30, 2)}; obs_mes={OBS["rotulo"]}; obs_dbgg={OBS["dbgg_pct_pib"]}; focus_primario={"/".join(str(v) for v in FPRIM.values())}; meta_2030={META[2030]}; proj_2030={PROJ[2030]}; ren_2024_pct_pib={REN_PIB}; ren_2024_rs_bi={round(REN_RS, 1)}; sem ajustes fluxo-estoque; primario do Governo Central contra divida do governo geral')
with open(os.path.join(RAIZ, 'S-cenarios-divida.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.DictWriter(f, fieldnames=list(linhas[0]) + ['fonte', 'nota'])
  w.writeheader()
  for l in linhas: w.writerow({**l, 'fonte': FONTE, 'nota': nota})
# Canal fiscal (frente Y): pb de juro longo nominal por 1 ponto do PIB de primario esperado acima do que o Focus espera,
# so nas taxas de mercado (prefixado e NTN-B novos), Selic do Focus mantida; metade do efeito no ano, pleno a partir do seguinte.
ly = open(os.path.join(RAIZ, 'brutos', 'Y', 'LEIAME.md'), encoding='utf-8').read()
FAIXA = {nv: float(re.search(r'\| ' + nv + r' \| (\d+) \|', ly).group(1)) for nv in ('Baixo', 'Central', 'Alto')}
# Harmonizacao (auditoria 5): o primario esperado do canal e o do setor publico consolidado nos dois lados (PLDO Tabela 4 e Focus),
# no horizonte comum 2027-2029, como mudanca da expectativa de medio prazo anunciada no inicio de 2027 (Y05 usa projecao de 4 anos).
# As medidas extras dos cenarios 4 e 4b sao da Uniao e entram 1:1 no consolidado.
HZ = range(2027, 2030)
d_base = sum(PLDO_SPNF[a] for a in HZ) / len(HZ) - sum(FPRIM[a] for a in HZ) / len(HZ)
def canal(prim, beta):
  dx = d_base + sum(prim(a) - pj(a) for a in HZ) / len(HZ)
  return lambda a: -beta / 100 * dx * (0.5 if a == 2027 else 1.0) if a >= 2027 else 0.0
canal_l = []
for cb, prim in (('2. Primário do PLDO', pj), ('4. Ajuste pela receita', forte), ('4b. Ajuste pela despesa', desp)):
  for nv, beta in FAIXA.items():
    for sp, rot in ((False, ''), (True, ' | so prefixados')):
      for l in roda(f'{cb} | canal fiscal {nv.lower()} ({int(beta)} pb){rot}', prim, 0.0, '', macro_focus, 0.0, ds_m=0.0, dm_fun=canal(prim, beta), so_pre=sp):
        l['choque_mercado_pp'] = round(canal(prim, beta)(l['ano']), 3); l['primario_esperado_focus'] = FPRIM.get(l['ano'], ''); l['primario_spnf_pldo'] = PLDO_SPNF.get(l['ano'], ''); l['delta_expectativa_medio_prazo'] = round(d_base + sum(prim(a) - pj(a) for a in HZ) / len(HZ), 3); l['canal_em'] = 'prefixados' if sp else 'prefixados e taxa real das NTN-B'; canal_l.append(l)
with open(os.path.join(RAIZ, 'S-canal-fiscal.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.DictWriter(f, fieldnames=[k for k in canal_l[0] if k != 'descricao'] + ['nota'])
  w.writeheader()
  for l in canal_l: w.writerow({**{k: v for k, v in l.items() if k != 'descricao'}, 'nota': f'ILUSTRATIVO. Faixa de sensibilidade da frente Y (brutos/Y/LEIAME.md): {FAIXA}; delta = media 2027-2029 do primario do setor publico consolidado do PLDO (Tabela 4) menos a do Focus, mais a media das medidas extras do cenario; mudanca de expectativa de medio prazo no inicio de 2027; efeito so nas taxas de mercado, Selic do Focus; metade em 2027 e pleno desde 2028'})
print('canal', [(l['cenario'][:40], l['divida_pct_pib'], l['choque_mercado_pp']) for l in canal_l if l['ano'] == 2030])
# Multiplicador fiscal (frente Y): o ajuste extra de cada ano reduz o crescimento real nesse ano em m vezes o ajuste
# (impulso fiscal); faixa da literatura para o Brasil. Sem estabilizadores automaticos (a receita menor nao volta ao primario).
mm = re.search(r'Faixa do multiplicador de consolidação para o Brasil: ([\d,]+) a ([\d,]+)', ly)
MULT = (num(mm.group(1)), (num(mm.group(1)) + num(mm.group(2))) / 2, num(mm.group(2)))
mult_l = []
for cb, prim in (('4. Ajuste pela receita', forte), ('4b. Ajuste pela despesa', desp)):
  ext = lambda a, prim=prim: prim(a) - pj(a) if a >= 2027 else 0.0
  for m in MULT:
    for l in roda(f'{cb} | multiplicador {virg(m, 1)}', prim, -1.5, '', macro_focus, 0.0, dg=lambda a, m=m, ext=ext: -m * (ext(a) - ext(a - 1))):
      l['multiplicador'] = m; mult_l.append(l)
with open(os.path.join(RAIZ, 'S-multiplicador.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.DictWriter(f, fieldnames=[k for k in mult_l[0] if k != 'descricao'] + ['nota'])
  w.writeheader()
  for l in mult_l: w.writerow({**{k: v for k, v in l.items() if k != 'descricao'}, 'nota': f'ILUSTRATIVO. Cenarios 4 e 4b (taxas 1,5 ponto menores) com o crescimento real reduzido no ano em m vezes o ajuste extra daquele ano; faixa do multiplicador da frente Y (brutos/Y/LEIAME.md): {MULT}; sem estabilizadores automaticos'})
print('mult', [(l['cenario'][-30:], l['divida_pct_pib']) for l in mult_l if l['ano'] == 2030])
# Propagacao de incerteza (S2, BRIEF-v11): Monte Carlo sobre faixas ja documentadas, sem a premissa exogena de taxas menores
# (o canal fiscal e o unico canal de taxa); semente fixa para reproduzir.
import random
rng = random.Random(20261019)
anc = sorted([(float(ult['prefixado_10a']), float(ult['juro_real_10a'])), (float(parc['prefixado_10a']), float(parc['juro_real_10a']))])
N_MC = 2000
mc_l = []
for cb, prim, usa_mult in (('2. Primário do PLDO', pj, False), ('4. Ajuste pela receita', forte, True), ('4b. Ajuste pela despesa', desp, True)):
  ext = lambda a, prim=prim: prim(a) - pj(a) if a >= 2027 else 0.0
  for sorteio in range(N_MC):
    beta = rng.triangular(FAIXA['Baixo'], FAIXA['Alto'], FAIXA['Central'])
    m = rng.uniform(MULT[0], MULT[2]) if usa_mult else 0.0
    defl = rng.uniform(-1.0, 1.0)
    w = rng.random()
    pre10, real10 = anc[0][0] + w * (anc[1][0] - anc[0][0]), anc[0][1] + w * (anc[1][1] - anc[0][1])
    traj = roda('mc', prim, 0.0, '', macro_focus, defl, ds_m=0.0, dg=lambda a, m=m, ext=ext: -m * (ext(a) - ext(a - 1)), dm_fun=canal(prim, beta))
    mc_l.append((cb, sorteio, beta, m, defl, w, [l['divida_pct_pib'] for l in traj], [l['juros_pct_pib'] for l in traj]))
pre10, real10 = float(ult['prefixado_10a']), float(ult['juro_real_10a'])
def pct(xs, q):
  xs = sorted(xs); i = q / 100 * (len(xs) - 1); lo = int(i); return xs[lo] + (xs[min(lo + 1, len(xs) - 1)] - xs[lo]) * (i - lo)
with open(os.path.join(RAIZ, 'S-montecarlo.csv'), 'w', newline='', encoding='utf-8') as f:
  w_ = csv.writer(f)
  w_.writerow(['cenario', 'ano', 'variavel', 'p5', 'p25', 'p50', 'p75', 'p95', 'prob_divida_subindo_2030', 'n_sorteios', 'nota'])
  for cb in dict.fromkeys(x[0] for x in mc_l):
    L = [x for x in mc_l if x[0] == cb]
    sub = sum(1 for x in L if x[6][4] > x[6][3]) / len(L)
    for j, a in enumerate(range(2026, 2031)):
      for var, idx in (('divida_pct_pib', 6), ('juros_pct_pib', 7)):
        v = [x[idx][j] for x in L]
        w_.writerow([cb, a, var] + [round(pct(v, q), 2) for q in (5, 25, 50, 75, 95)] + [round(sub, 3) if a == 2030 and var == 'divida_pct_pib' else '', len(L),
                    f'canal fiscal triangular {FAIXA["Baixo"]}-{FAIXA["Central"]}-{FAIXA["Alto"]} pb so nas taxas de mercado; multiplicador uniforme {MULT[0]}-{MULT[2]} nos ajustes 4 e 4b; deflator uniforme IPCA -1 a +1 ponto; ancora de mercado uniforme entre {parc["mes"]} e {ult["mes"]}; Selic do Focus; sem a premissa de taxas 1,5 ponto menores; semente 20261019'])
print('mc', [(cb, [x for x in open(os.path.join(RAIZ, 'S-montecarlo.csv')).read().split(chr(10)) if x.startswith(cb) and ',2030,divida' in x][0][-200:-150]) for cb in ('2.', '4.', '4b.')])
# Sensibilidade: reducoes de 0,5 a 3 pontos desde 2027 sobre o cenario 2, separando Selic, curva inteira e premio (so mercado)
base = {l['ano']: l for l in roda('base', pj, 0.0, '', macro_focus, 0.0)}
sens = []
for tipo, f in (('selic', lambda x: (x, 0.0)), ('curva', lambda x: (x, x)), ('premio', lambda x: (0.0, x))):
  for x in (0.5, 1.0, 1.5, 2.0, 3.0):
    a_s, a_m = f(-x)
    alt = {l['ano']: l for l in roda('alt', pj, a_s, '', macro_focus, 0.0, ds_m=a_m)}
    pibn, acum = PIB25, 0.0
    for a in range(2026, 2031):
      pibn *= 1 + base[a]['cresc_nominal'] / 100
      eco = (base[a]['juros_pct_pib'] - alt[a]['juros_pct_pib']) / 100 * pibn
      if a >= 2027: acum += eco
      if a == 2027: eco1, eco1p = eco, base[a]['juros_pct_pib'] - alt[a]['juros_pct_pib']
    sens.append(dict(choque=tipo, reducao_pp=x, economia_2027_rs_bi=round(eco1, 1), economia_2027_pct_pib=round(eco1p, 2),
                     economia_acum_2027_2030_rs_bi=round(acum, 1), juros_2030_pct_pib_base=base[2030]['juros_pct_pib'], juros_2030_pct_pib=alt[2030]['juros_pct_pib'],
                     divida_2030_base=base[2030]['divida_pct_pib'], divida_2030=alt[2030]['divida_pct_pib'], reducao_divida_2030_pp=round(base[2030]['divida_pct_pib'] - alt[2030]['divida_pct_pib'], 2),
                     custo_implicito_2030=alt[2030]['juro_implicito'], custo_implicito_2030_base=base[2030]['juro_implicito']))
for dg in (-1.0, 1.0):
  alt = {l['ano']: l for l in roda('alt', pj, 0.0, '', macro_focus, 0.0, dg=dg)}
  sens.append(dict(choque='crescimento real', reducao_pp=dg, economia_2027_rs_bi='', economia_2027_pct_pib='', economia_acum_2027_2030_rs_bi='',
                   juros_2030_pct_pib_base=base[2030]['juros_pct_pib'], juros_2030_pct_pib=alt[2030]['juros_pct_pib'], divida_2030_base=base[2030]['divida_pct_pib'],
                   divida_2030=alt[2030]['divida_pct_pib'], reducao_divida_2030_pp=round(base[2030]['divida_pct_pib'] - alt[2030]['divida_pct_pib'], 2),
                   custo_implicito_2030=alt[2030]['juro_implicito'], custo_implicito_2030_base=base[2030]['juro_implicito']))
with open(os.path.join(RAIZ, 'S-sensibilidade-juros.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.DictWriter(f, fieldnames=list(sens[0]) + ['nota'])
  w.writeheader()
  for l in sens: w.writerow({**l, 'nota': 'base = cenario 2 (primario do PLDO, macro do Focus); reducao desde 2027; selic = so a Selic, mercado parado; curva = Selic e taxas de mercado; premio = so taxas de mercado (prefixado e NTN-B de 10 anos), Selic parada; repreficacao pelo perfil de vencimentos de dez/2025; economia em R$ correntes sobre o PIB nominal do cenario base; crescimento real = pontos a mais por ano desde 2027'})
print('sens', [(l['choque'], l['reducao_pp'], l['economia_2027_rs_bi'], l['economia_acum_2027_2030_rs_bi'], l['reducao_divida_2030_pp']) for l in sens])
print('S ok', [(l['cenario'], l['divida_pct_pib'], l['primario_pct_pib'], l['primario_estabiliza']) for l in linhas if l['ano'] == 2030], 'PLDO', PLDO_DBGG)

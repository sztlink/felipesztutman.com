#!/usr/bin/env python3
# Frente FL, desmatamento. Baixa os arquivos do painel PRODES do INPE (TerraBrasilis), uma requisicao por vez com pausa, e
# registra cada arquivo em downloads.tsv. Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/FL/baixa_FL.py
import datetime, hashlib, json, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
B = 'https://terrabrasilis.dpi.inpe.br/app/prodes/dashboard/deforestation/files/'
ITENS = [
  ('prodes_amazonia_legal_rates2026.json', 'INPE, PRODES Amazonia Legal, taxas anuais de desmatamento por UF (km2), 1988 a 2026', B + 'rates2026.json?v=3.5.10'),
  ('prodes_amazonia_legal_loinames.json', 'INPE, PRODES Amazonia Legal, nomes das areas (UF, unidades de conservacao)', B + 'config/loinames/prodes_legal_amazon.json?v=3.5.10'),
  ('prodes_cerrado_incrementos.json', 'INPE, PRODES Cerrado, incrementos anuais de desmatamento (km2), acumulado ate 2000 e 2000 a 2026', B + 'data/prodes_cerrado.json?v=3.5.10'),
  ('prodes_cerrado_loinames.json', 'INPE, PRODES Cerrado, nomes das areas', B + 'config/loinames/prodes_cerrado.json?v=3.5.10'),
  ('prodes_last_update_date.json', 'INPE, PRODES, data da ultima atualizacao do painel', B + 'last_update_date.json?v=3.5.10'),
]
linhas = []
for arq, desc, url in ITENS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    b = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=120).read(); json.loads(b)
    open(dst, 'wb').write(b); time.sleep(3)
  h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, 'fontes/' + arq, url, h]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n')
print(len(linhas), 'arquivos')

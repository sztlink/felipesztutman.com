# Frente FL, desmatamento

Feita em 20/10/2026 para a v12.5, a pedido do autor de comparar agro e desmatamento entre os candidatos também pelos governos
anteriores, e não só pelas propostas.

## O que entra
- `FL-desmatamento.csv`. Desmatamento por ano PRODES de 2000 a 2026, em km², na Amazônia Legal (taxa anual oficial) e no Cerrado
  (incremento anual), com o presidente de cada ano.
- `FL-desmatamento-por-mandato.csv`. Média anual por mandato, o ano anterior ao mandato e o último ano do mandato na Amazônia.

## Regras
- Soma das UFs. Nos arquivos do painel, cada área tem `loi` (1 é UF) e cada valor tem `type` (1 é desmatamento). A soma confere com
  as taxas oficiais publicadas (21.050 km² em 1988, 27.772 em 2004, 13.038 em 2021).
- O ano PRODES t vai de agosto de t-1 a julho de t e conta para quem governou de janeiro a julho de t. O de 2019 tem cinco meses de
  Temer, e o de 2023, cinco meses de Bolsonaro.
- O Cerrado é bienal de 2000 a 2012 (2000-2002, 2002-2004 e assim por diante). O valor do biênio é dividido igualmente entre os dois
  anos e marcado na coluna `cerrado_bienal_dividido`.
- FHC entra só com 2000 a 2002, a janela comum com a frente FN.

## Limites
O PRODES mede corte raso e não mede degradação nem regeneração. O dado de 2026 é o do painel de 16/10/2026 e pode ser revisado.
Mandato data o valor e não atribui causa. O desmatamento responde também a preço de commodity, câmbio, clima, crédito e fiscalização
estadual.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/FL/baixa_FL.py
cd /tmp && python3 -I <pacote>/brutos/FL/build_FL.py
```

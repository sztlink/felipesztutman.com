#!/usr/bin/env python3
# Frente FL, desmatamento por ano e por mandato. PRODES do INPE, Amazonia Legal (taxa anual oficial, km2) e Cerrado (incremento
# anual, km2; bienal de 2000 a 2012, dividido igualmente entre os dois anos e marcado). O ano PRODES t vai de agosto de t-1 a julho de
# t e conta para quem governou de janeiro a julho de t. Serie de 2000 a 2026, a mesma janela da frente FN. Mandato data o valor, nao
# atribui causa.
# Rodar: cd /tmp && python3 -I <pacote>/brutos/FL/build_FL.py   (fontes baixadas por baixa_FL.py)
import csv, json, os
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes')
MANDS = [('FHC', 2000, 2002), ('Lula 1', 2003, 2006), ('Lula 2', 2007, 2010), ('Dilma', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016),
         ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2026)]
mand = lambda a: next(m for m, i, f in MANDS if i <= a <= f)
def soma(arq):
  # soma das UFs (loi 1), classe 1 (desmatamento), por periodo (ano inicial, ano final)
  d = json.load(open(os.path.join(F, arq), encoding='utf-8'))
  return {(p['startDate']['year'], p['endDate']['year']): sum(a['area'] for ft in p['features'] if ft['loi'] == 1 for a in ft['areas'] if a['type'] == 1) for p in d['periods']}
AM = {f: v for (i, f), v in soma('prodes_amazonia_legal_rates2026.json').items()}
CE, BI = {}, set()
for (i, f), v in soma('prodes_cerrado_incrementos.json').items():
  if i < 2000: continue
  for a in range(i + 1, f + 1): CE[a] = v / (f - i)
  if f - i > 1: BI.update(range(i + 1, f + 1))
ATU = json.load(open(os.path.join(F, 'prodes_last_update_date.json'), encoding='utf-8'))['last_date']
lin = [[a, mand(a), round(AM[a]), round(CE[a]) if a in CE else '', 1 if a in BI else 0] for a in range(2000, max(AM) + 1)]
with open(os.path.join(RAIZ, 'FL-desmatamento.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['ano_prodes', 'presidente', 'amazonia_legal_km2', 'cerrado_km2', 'cerrado_bienal_dividido']); w.writerows(lin)
rnd = lambda x: int(x + 0.5)  # meio para cima (o round do Python vai ao par)
res = []
for m, i, f in MANDS:
  an = [r for r in lin if i <= r[0] <= f]; ce = [r[3] for r in an if r[3] != '']
  res.append([m, f'{an[0][0]}-{an[-1][0]}', len(an), rnd(sum(r[2] for r in an) / len(an)), rnd(sum(ce) / len(ce)) if ce else '', len(ce),
              AM[i - 1] if i - 1 in AM else '', AM[an[-1][0]]])
with open(os.path.join(RAIZ, 'FL-desmatamento-por-mandato.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n')
  w.writerow(['presidente', 'anos_prodes', 'n_anos', 'amazonia_media_km2_ano', 'cerrado_media_km2_ano', 'n_anos_cerrado', 'amazonia_ano_anterior_km2', 'amazonia_ultimo_ano_km2'])
  w.writerows(res)
print('FL-desmatamento.csv', len(lin), 'FL-desmatamento-por-mandato.csv', len(res), 'painel atualizado em', ATU)

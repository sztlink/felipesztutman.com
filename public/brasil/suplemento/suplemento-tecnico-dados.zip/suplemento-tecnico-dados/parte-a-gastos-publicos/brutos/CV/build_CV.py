#!/usr/bin/env python3
# Frente CV, cultura e governo, 2009 a 2025. Le os atos oficiais (DOU e Planalto, conferidos por trecho literal), os relatorios do
# painel Salic Comparar, a busca de projetos por tema no nome, a execucao das transferencias da cultura por lei no SIOP, a funcao
# Cultura por acao no SIOP (frente FN), o Google Trends e a API da Camara, e escreve os CSV CV-* na raiz. Mandato data o valor, nao
# atribui causa. Rodar: cd /tmp && python3 -I <pacote>/brutos/CV/build_CV.py   (fontes de baixa_CV.py e baixa_navegador.js)
import csv, html, json, os, re
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes'); S = os.path.join(F, 'salic')
pres = lambda a: {2015: 'Dilma', 2016: 'D/T', 2017: 'Temer', 2018: 'Temer'}.get(a) or ('FHC' if a <= 2002 else 'Lula 1' if a <= 2006 else 'Lula 2' if a <= 2010 else 'Dilma' if a <= 2014 else 'Bolsonaro' if a <= 2022 else 'Lula 3')
def grava(nome, cab, linhas):
  with open(os.path.join(RAIZ, nome), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f, lineterminator='\n'); w.writerow(cab); w.writerows(linhas)
  print(nome, len(linhas))
def texto(arq):
  b = open(os.path.join(F, arq), 'rb').read()
  try: s = b.decode('utf-8')
  except UnicodeDecodeError: s = b.decode('latin-1')
  s = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', s)
  return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s)))
URL = {r['arquivo']: r['url'] for r in csv.DictReader(open(os.path.join(AQUI, 'downloads.tsv'), encoding='utf-8'), delimiter='\t')}

# ---------- atos oficiais: cada trecho e conferido contra o texto baixado ----------
ATOS = [
  ('2018-12-31', 'Lei 13.502/2017, art. 21', 'planalto_l13502.htm', 'IV - da Cultura', 'O Ministerio da Cultura esta entre os ministerios em 2018.'),
  ('2019-01-01', 'MP 870/2019, art. 19', 'planalto_mpv870.htm', 'Os Ministérios são os seguintes: I - da Agricultura, Pecuária e Abastecimento; II - da Cidadania;', 'A lista de ministerios de 2019 nao tem o da Cultura.'),
  ('2019-01-01', 'MP 870/2019, art. 23, I', 'planalto_mpv870.htm', 'Constitui área de competência do Ministério da Cidadania: I - política nacional de desenvolvimento social;', 'Desenvolvimento social vai ao Ministerio da Cidadania.'),
  ('2019-01-01', 'MP 870/2019, art. 23, XIV', 'planalto_mpv870.htm', 'XIV - política nacional de cultura; XV - proteção do patrimônio histórico e cultural;', 'Cultura vai ao Ministerio da Cidadania.'),
  ('2019-01-01', 'MP 870/2019, art. 23, XX', 'planalto_mpv870.htm', 'XX - política nacional de desenvolvimento da prática dos esportes;', 'Esporte vai ao Ministerio da Cidadania.'),
  ('2019-06-18', 'Lei 13.844/2019, art. 23', 'planalto_l13844.htm', 'XIV - política nacional de cultura;', 'A politica nacional de cultura passa ao Ministerio da Cidadania.'),
  ('2021-07-27', 'MP 1.058/2021 e Lei 14.261/2021, na Lei 13.844, art. 34', 'planalto_l13844.htm', 'IX - política nacional de cultura; (Incluído pela Medida Provisória nº 1.058, de 2021)', 'A politica nacional de cultura passa ao Ministerio do Turismo.'),
  ('2023-01-01', 'MP 1.154/2023, art. 17', 'planalto_mpv1154.htm', 'III - Ministério da Cultura;', 'O Ministerio da Cultura volta a lista de ministerios.'),
  ('2016-05-12', 'MP 726/2016, art. 1, IV', 'planalto_mpv726.htm', 'Ficam extintos: I - a Secretaria de Portos da Presidência da República; II - a Secretaria de Aviação Civil da Presidência da República; III - a Controladoria-Geral da União; IV - o Ministério da Cultura;', 'O Ministerio da Cultura e extinto e a cultura vai ao Ministerio da Educacao e Cultura.'),
  ('2016-05-23', 'MP 728/2016', 'planalto_mpv728.htm', 'IV - Ministério da Cultura: a) política nacional de cultura;', 'O Ministerio da Cultura e recriado onze dias depois.'),
  ('2019-11-06', 'Decreto 10.107/2019, art. 1', 'planalto_d10107.htm', 'Ficam transferidos do Ministério da Cidadania para o Ministério do Turismo: I - a Secretaria Especial de Cultura;', 'A Secretaria Especial de Cultura passa ao Ministerio do Turismo.'),
  ('2019-08-21', 'Portaria Ministerio da Cidadania 1.576/2019, art. 2', 'dou_portaria_1576_2019_mcidadania.html', 'Após a recomposição do CGFSA, fica determinada a revisão dos critérios e diretrizes para a aplicação dos recursos do FSA, bem como que sejam avaliados os critérios de apresentação de propostas de projetos, os parâmetros de julgamento e os limites de valor de apoio para cada linha de ação', 'Revisao dos criterios do FSA depois da recomposicao do comite.'),
  ('2022-08-26', 'MP 1.135/2022, art. 3 (Lei 14.148, art. 6)', 'planalto_mpv1135.htm', 'Fica a União autorizada a destinar, no exercício de 2023, o valor global máximo de R$ 2.500.000.000,00 (dois bilhões e quinhentos milhões de reais) aos beneficiários do Perse', 'A mesma MP faz o mesmo com o Perse, programa do setor de eventos.'),
  ('2024-11-22', 'MP 1.274/2024, art. 1 (Lei 14.399, art. 6)', 'planalto_mpv1274.htm', 'A partir de 2023, a União entregará aos Estados, ao Distrito Federal e aos Municípios o valor total de R$ 15.000.000.000,00 (quinze bilhões de reais)', 'Os R$ 3 bi por ano viram um valor total de R$ 15 bi a partir de 2023.'),
  ('2024-11-22', 'MP 1.274/2024', 'planalto_mpv1274.htm', 'Vigência encerrada', 'A MP perdeu a vigencia.'),
  ('2019-04-24', 'IN Ministerio da Cidadania 2/2019, art. 4, I, d', 'dou_in_2_2019_mcidadania.html', 'o valor homologado para captação por projeto fica limitado em R$ 1.000.000,00 (um milhão de reais)', 'Teto por projeto na Lei Rouanet, R$ 1 milhao, com excecoes.'),
  ('2019-04-24', 'IN Ministerio da Cidadania 2/2019, art. 12', 'dou_in_2_2019_mcidadania.html', 'R$ 45.000,00 (quarenta e cinco mil reais) para artista ou modelo solo', 'Cache por apresentacao de artista solo, R$ 45 mil.'),
  ('2019-08-21', 'Portaria Ministerio da Cidadania 1.576/2019, art. 1', 'dou_portaria_1576_2019_mcidadania.html', 'Ficam suspensos, pelo prazo de 180 (cento e oitenta) dias, prorrogável por igual período, os termos do Edital de Chamamento para TVs Públicas, com recursos públicos do Fundo Setorial do Audiovisual - FSA, lançado em 13 de março de 2018, em razão da necessidade de recompor os membros do Comitê Gestor do Fundo Setorial do Audiovisual - CGFSA', 'Suspensao do edital do FSA para TVs publicas, com o motivo que a portaria declara.'),
  ('2020-06-29', 'Lei 14.017/2020 (Lei Aldir Blanc)', 'planalto_l14017.htm', 'Faço saber que o Congresso Nacional decreta e eu sanciono a seguinte Lei', 'Lei do Congresso, sancionada com vetos parciais (a pagina remete a Mensagem de veto).'),
  ('2022-07-08', 'LC 195/2022 (Lei Paulo Gustavo)', 'planalto_lcp195.htm', 'Vide Mensagem de Veto Total nº178, de 2022', 'Veto total do presidente.'),
  ('2022-07-08', 'LC 195/2022 (Lei Paulo Gustavo)', 'planalto_lcp195.htm', 'Faço saber que o Congresso Nacional decreta e eu promulgo, nos termos do parágrafo 5º do art. 66 da Constituição Federal', 'Promulgada depois de o Congresso derrubar o veto.'),
  ('2022-07-08', 'LC 195/2022, art. 3, redacao original', 'planalto_lcp195.htm', 'Art. 3º A União entregará aos Estados, ao Distrito Federal e aos Municípios R$ 3.862.000.000,00', 'Obrigacao de entregar R$ 3,862 bi.'),
  ('2022-07-08', 'Lei 14.399/2022 (Politica Nacional Aldir Blanc)', 'planalto_l14399.htm', 'Vide Mensagem de Veto Total nº 212, de 2022', 'Veto total do presidente.'),
  ('2022-07-08', 'Lei 14.399/2022 (Politica Nacional Aldir Blanc)', 'planalto_l14399.htm', 'Faço saber que o Congresso Nacional decreta e eu promulgo, nos termos do parágrafo 5º do art. 66 da Constituição Federal', 'Promulgada depois de o Congresso derrubar o veto.'),
  ('2022-07-08', 'Lei 14.399/2022, art. 6, redacao original', 'planalto_l14399.htm', 'Art. 6º A União entregará aos Estados, ao Distrito Federal e aos Municípios, a cada ano, em parcela única, o valor correspondente a R$ 3.000.000.000,00 (três bilhões de reais), no primeiro exercício subsequente ao da entrada em vigor desta Lei e nos 4 (quatro) anos seguintes', 'Obrigacao de entregar R$ 3 bi por ano, de 2023 a 2027.'),
  ('2022-08-26', 'MP 1.135/2022, art. 1 (LC 195, art. 3)', 'planalto_mpv1135.htm', 'Fica a União autorizada a destinar, no exercício de 2023, aos Estados, ao Distrito Federal e aos Municípios, o montante máximo de R$ 3.862.000.000,00', 'A obrigacao vira autorizacao, com valor maximo, e passa a 2023.'),
  ('2022-08-26', 'MP 1.135/2022, art. 2 (Lei 14.399, art. 6)', 'planalto_mpv1135.htm', 'Fica a União autorizada a destinar aos Estados, ao Distrito Federal e aos Municípios, a cada ano, os seguintes valores máximos', 'A obrigacao vira autorizacao, com valores maximos a partir de 2024.'),
  ('2022-08-26', 'MP 1.135/2022', 'planalto_mpv1135.htm', '(Vigência encerrada)', 'A MP perdeu a vigencia.'),
  ('2022-02-08', 'IN Secult/MTur 1/2022, art. 5', 'dou_in_1_2022_secult.html', 'O valor homologado por projeto de Tipicidade Normal (Anexo I) fica limitado em R$ 500.000,00', 'Teto por projeto comum, R$ 500 mil.'),
  ('2022-02-08', 'IN Secult/MTur 1/2022, art. 17', 'dou_in_1_2022_secult.html', 'até R$ 3.000,00 (três mil reais), por apresentação, para artista ou modelo solo', 'Cache por apresentacao de artista solo, R$ 3 mil.'),
  ('2023-04-11', 'IN MinC 1/2023, art. 7, par. 1', 'dou_in_1_2023_minc.html', 'O valor aprovado para captação por projeto fica limitado em R$ 1.000.000,00 (um milhão de reais)', 'Teto por projeto, R$ 1 milhao, com excecoes.'),
  ('2023-04-11', 'IN MinC 1/2023, art. 14', 'dou_in_1_2023_minc.html', 'R$ 25.000,00 (vinte e cinco mil reais) por apresentação, para artista, solista e modelo', 'Cache por apresentacao de artista solo, R$ 25 mil.'),
]
lin = []
for data, ato, arq, trecho, leitura in ATOS:
  assert trecho in texto(arq), (ato, trecho[:60])
  lin.append([data, pres(int(data[:4])), ato, trecho, leitura, URL['fontes/' + arq]])
grava('CV-atos.csv', ['data', 'presidente', 'ato', 'trecho', 'leitura', 'fonte_url'], sorted(lin))

# ---------- numero de ministerios em cada lei de organizacao (incisos numerados do artigo que lista os ministerios) ----------
def ministerios(arq, ini, fim):
  t = texto(arq); i = t.index(ini); j = t.index(fim, i); seg = t[i:j]
  seg = re.sub(r'\((?:Incluído|Redação dada|Revogado|Vide)[^)]*\)', '', seg)
  # cada inciso numerado (I, II, ..., XXIII), sem os acrescidos depois (IX-A, III-A), que a regex de inciso puro nao pega
  itens = re.findall(r'(?<![A-Z-])([IVXL]+) - ', seg)
  return len(dict.fromkeys(itens)), 'Cultura' in seg
MIN = [('fim de 2018 (Temer)', 'Lei 13.502/2017, art. 21, com a Segurança Pública incluída pela Lei 13.690/2018', 'planalto_l13502.htm', 'Os Ministérios são os seguintes:', 'Art. 22.'),
       ('2019 (Bolsonaro)', 'MP 870/2019, art. 19', 'planalto_mpv870.htm', 'Os Ministérios são os seguintes:', 'Ministros de Estado'),
       ('2023 (Lula 3)', 'MP 1.154/2023, art. 17', 'planalto_mpv1154.htm', 'Os Ministérios são os seguintes:', 'Art. 18.')]
lin = []
for quando, ato, arq, ini, fim in MIN:
  n, cult = ministerios(arq, ini, fim); lin.append([quando, ato, n, 'sim' if cult else 'nao', URL['fontes/' + arq]])
assert [r[2] for r in lin] == [23, 16, 31], lin  # incisos numerados, com a Controladoria-Geral da Uniao nas tres listas
grava('CV-ministerios.csv', ['quando', 'ato', 'ministerios', 'tem_ministerio_da_cultura', 'fonte_url'], lin)

# ---------- painel Salic Comparar, por ano ----------
num = lambda s: float(s.replace('.', '').replace(',', '.'))
st = lambda a: open(os.path.join(S, a + '.txt'), encoding='utf-8').read()
cnic = {int(num(m.group(1))): (int(num(m.group(2))), num(m.group(3))) for m in re.finditer(r'(?m)^(2\.0\d\d)\t([\d.]+)\t([\d.,]+)$', st('grid_Avaliacao_Cnic_Ano'))}
tr = re.sub(r'\s+', ' ', st('grid_Qtde_Proposta_Transformada_Por_Ano_Area'))
anos_tr = [int(num(a)) for a in re.findall(r'(2\.0\d\d)', tr.split('Total')[0])]
novos = dict(zip(anos_tr, [int(num(x)) for x in re.search(r'Total Geral ([\d. ]+)', tr).group(1).split()]))
tempo = {int(m.group(1)): (int(m.group(2)), int(m.group(5))) for m in re.finditer(r'(?m)^\s*(20\d\d)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$', re.sub(r'[\t ]+', ' ', st('grid_TempoMedio_Da_Admissibilidade_Ate_Publicacao')))}
capt = {}
for m in re.finditer(r'(?m)^\s*\d+\s+(\d{4})\s+(.+)$', re.sub(r'[\t ]+', ' ', st('grid_Captacao_Por_TipoDeApoio_Ano'))):
  capt[int(m.group(1))] = num(m.group(2).split()[-1])
IPCA = {int(r['D3C'][:4]): float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:] if r['D3C'].endswith('12')}
# temas no nome do projeto. O ano do projeto sao os dois primeiros digitos do Pronac. Os filtros tiram falsos positivos da busca
# por radical (Dragao, Rio Negro, o sobrenome Negrao, Afrodite, e na auditoria de 20/10/2026 Cisne Negro, Ouro Negro, Buraco Negro,
# Ovelha Negra, Rosa Negra, pedra negra e negra tirania, e na auditoria manual de 20/10/2026, audita_temas.py, Agulhas Negras, rubro-negro,
# Vale Negro e abelhas indigenas). O captado e o do projeto, pelo ano do Pronac, em R$ correntes
import importlib.util
_sp = importlib.util.spec_from_file_location('_regras', os.path.join(AQUI, 'regras_temas.py')); _R = importlib.util.module_from_spec(_sp); _sp.loader.exec_module(_R)
TEMAS = _R.TEMAS  # regras em regras_temas.py
tema, tres = {}, {}
for k, termos, rx in TEMAS:
  rows = {}
  for t in termos:
    d = json.load(open(os.path.join(S, f'projetos_nome_{t}.json'), encoding='utf-8'))
    assert d['total_informado'] == len(d['linhas']), t
    for r in d['linhas']:
      if re.search(rx, r[1], re.I): rows[r[0]] = r
  ic, ia = d['cabecalho'].index('Vl Captado'), d['cabecalho'].index('Vl Aprovado')
  for p_, r in rows.items():
    y = 2000 + int(p_[:2]); tema[(k, y)] = tema.get((k, y), 0) + 1
    tema[(k, y, 'cap')] = tema.get((k, y, 'cap'), 0) + num(r[ic] or '0')
    tema[(k, y, 'n_aprov')] = tema.get((k, y, 'n_aprov'), 0) + (num(r[ia] or '0') > 0)
    tema[(k, y, 'n_capt')] = tema.get((k, y, 'n_capt'), 0) + (num(r[ic] or '0') > 0)
    if k in ('lgbt', 'negra_quilombola', 'indigena'): tres.setdefault(p_, (y, num(r[ic] or '0')))  # sem dupla contagem entre temas
ANOS = range(2009, 2026)
lin = []
for a in ANOS:
  row = [a, pres(a), novos[a], cnic.get(a, ('', ''))[0], round(cnic[a][1] / 1e9, 3) if a in cnic else '', tempo[a][0], tempo[a][1], round(capt[a] / 1e9, 3), round(capt[a] * IPCA[2025] / IPCA[a] / 1e9, 3)]
  for k, _, _ in TEMAS: row += [tema.get((k, a), 0), round(100 * tema.get((k, a), 0) / novos[a], 3), round(tema.get((k, a, 'cap'), 0) / 1e6, 3), tema.get((k, a, 'n_aprov'), 0), tema.get((k, a, 'n_capt'), 0)]
  row.append(round(sum(c for y_, c in tres.values() if y_ == a) / 1e6, 3))
  lin.append(row)
cab = ['ano', 'presidente', 'projetos_novos', 'cnic_projetos_avaliados', 'cnic_valor_aprovado_rs_bi', 'dias_admissibilidade', 'dias_admissibilidade_a_publicacao', 'rouanet_captado_rs_bi', 'rouanet_captado_rs_bi_2025']
for k, _, _ in TEMAS: cab += [f'projetos_{k}', f'pct_{k}', f'captado_{k}_rs_mi', f'com_aprovado_{k}', f'com_captado_{k}']
cab.append('captado_tres_temas_sem_dupla_rs_mi')
grava('CV-salic-por-ano.csv', cab, lin)

# ---------- transferencias da cultura por lei (SIOP), dotacao, empenhado e liquidado no ano ----------
lin = []
for y in range(2020, 2026):
  for r in csv.DictReader(open(os.path.join(F, f'siop_transferencias_cultura_{y}.csv'), encoding='utf-8')):
    if r['fl'] != 'Encargos Especiais': continue
    lei = 'Lei Aldir Blanc (14.017/2020)' if 'Covid' in r['al'] else 'Lei Paulo Gustavo (LC 195/2022)' if '195' in r['al'] else 'Politica Nacional Aldir Blanc (14.399/2022)'
    lin.append([y, pres(y), lei, r['al'], round(float(r['dotacao_atual']) / 1e9, 3), round(float(r['empenhado']) / 1e9, 3), round(float(r['liquidado']) / 1e9, 3), URL[f'fontes/siop_transferencias_cultura_{y}.csv']])
grava('CV-transferencias-cultura.csv', ['ano', 'presidente', 'lei', 'acao', 'dotacao_rs_bi', 'empenhado_rs_bi', 'liquidado_rs_bi', 'fonte'], lin)

# ---------- estrutura: funcao Cultura por acao (frente FN) contra a despesa primaria (frente D) ----------
FN = os.path.join(RAIZ, 'brutos', 'FN', 'fontes')
DP = {int(r['ano']): float(r['valor_brl']) for r in csv.DictReader(open(os.path.join(RAIZ, 'D-rtn-despesa-primaria.csv'), encoding='utf-8')) if r['estagio'] == 'RTN pago' and r['categoria'].startswith('4. DESPESA TOTAL') and r['subcategoria'] == 'total'}
ESTR = r'^(Ativos Civis da União|Pessoal Ativo da União|Pagamento de Pessoal Ativo da União|Administração da Unidade)$'  # pessoal ativo (o rotulo muda em 2018 e 2019) e administracao
lin = []
for y in range(2015, 2026):
  tot = estr = fsa = 0
  for r in csv.DictReader(open(os.path.join(FN, f'siop_acoes_cultura_funcao_{y}.csv'), encoding='utf-8')):
    v = float(r['liquidado'])
    if r['gnd'].endswith('/5'): fsa += v; continue
    tot += v
    if re.match(ESTR, r['al'].strip()): estr += v
  d = lambda v: round(v * IPCA[2025] / IPCA[y] / 1e9, 3)
  lin.append([y, pres(y), d(tot), d(estr), d(fsa), round(100 * tot / DP[y], 4) if y in DP else '', round(100 * estr / DP[y], 4) if y in DP else ''])
grava('CV-estrutura-cultura.csv', ['ano', 'presidente', 'funcao_cultura_sem_inversoes_rs_bi_2025', 'pessoal_ativo_e_administracao_rs_bi_2025', 'inversoes_fsa_rs_bi_2025', 'funcao_pct_despesa_primaria', 'estrutura_pct_despesa_primaria'], lin)

# ---------- atencao publica: Google Trends (media anual do indice) e proposicoes na Camara ----------
T = json.load(open(os.path.join(F, 'trends.json'), encoding='utf-8'))
tl = json.loads(T['resposta']['corpo'].split('\n', 1)[1])['default']['timelineData']
import datetime
soma = {}
for p_ in tl:
  y = datetime.datetime.fromtimestamp(int(p_['time']), datetime.timezone.utc).year
  s_ = soma.setdefault(y, [0] * len(T['termos']) + [0])
  for i, v in enumerate(p_['value']): s_[i] += v
  s_[-1] += 1
C = json.load(open(os.path.join(F, 'camara_proposicoes_por_termo.json'), encoding='utf-8'))['contagens']
lin = []
for y in range(2004, 2026):
  s_ = soma[y]; lin.append([y, pres(y)] + [round(s_[i] / s_[-1], 2) for i in range(len(T['termos']))] + [C[f'{t}|{y}'] for t in ('Rouanet', 'Plano Safra', 'Zona Franca')])
grava('CV-atencao.csv', ['ano', 'presidente'] + ['trends_' + re.sub(r'\W+', '_', t.lower()).strip('_') for t in T['termos']] + ['camara_rouanet', 'camara_plano_safra', 'camara_zona_franca'], lin)

#!/usr/bin/env python3
# Frente CV, auditoria manual da classificacao dos temas no nome do projeto (auditoria externa de 20/10/2026).
# Falsos positivos. Amostra estratificada por tema e governo, ate 12 titulos por estrato, sorteio com semente fixa, tirada da
# classificacao anterior aos filtros novos. Cada titulo foi lido e marcado sim, nao ou indeterminado em
# auditoria_temas_falsos_positivos.tsv. Os quatro padroes de falso positivo achados viraram filtro em build_CV.py.
# Falsos negativos. Busca de sinonimos que o radical nao pega (TERMOS_FN em baixa_navegador.js). Os projetos achados so por sinonimo
# (com o filtro de palavra do termo, porque a busca do painel e por trecho) foram lidos, todos quando o termo tem ate 40 e uma amostra
# de 40 quando tem mais (semente 'fn-<termo>-20261020'), e marcados em auditoria_temas_falsos_negativos.tsv.
# Os arquivos de decisao guardam o Pronac e nao o titulo, que se recupera em fontes/salic.
# Saida, CV-temas-auditoria.csv na raiz. Rodar: cd /tmp && python3 -P <pacote>/brutos/CV/audita_temas.py
import csv, json, os, random, re
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); S = os.path.join(AQUI, 'fontes', 'salic')
import importlib.util
_sp = importlib.util.spec_from_file_location('_regras', os.path.join(AQUI, 'regras_temas.py')); R = importlib.util.module_from_spec(_sp); _sp.loader.exec_module(R)
PER = [('Lula 2', 2009, 2010), ('Dilma', 2011, 2015), ('Temer', 2016, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2025)]
per = lambda y: next((n for n, a, b in PER if a <= y <= b), None)
ano = lambda p: 2000 + int(p[:2])
le_tsv = lambda f: list(csv.DictReader(open(os.path.join(AQUI, f), encoding='utf-8'), delimiter='\t'))
novos = {int(r['ano']): int(r['projetos_novos']) for r in csv.DictReader(open(os.path.join(RAIZ, 'CV-salic-por-ano.csv'), encoding='utf-8'))}

def classe(termos, rx):
  rows = {}
  for t in termos:
    for r in json.load(open(os.path.join(S, f'projetos_nome_{t}.json'), encoding='utf-8'))['linhas']:
      if re.search(rx, r[1], re.I): rows[r[0]] = r[1]
  return rows

FP = le_tsv('auditoria_temas_falsos_positivos.tsv'); FN = le_tsv('auditoria_temas_falsos_negativos.tsv')
# o sorteio se refaz: semente '<tema>-<governo>-20261020', ate 12 por estrato, sobre a classificacao da v12.5
for k, termos, _ in R.TEMAS:
  if k not in R.TEMAS_V125: continue
  v125 = classe(termos, R.TEMAS_V125[k])
  for n_, a, b in PER:
    ps = sorted(p for p in v125 if a <= ano(p) <= b)
    am = sorted(random.Random(f'{k}-{n_}-20261020').sample(ps, min(12, len(ps))))
    assert am == sorted(r['pronac'] for r in FP if r['tema'] == k and r['estrato'] == n_), (k, n_)
lin = []
for k, termos, rx in [x for x in R.TEMAS if x[0] in R.SINONIMOS]:
  atual = classe(termos, rx)
  # projetos achados so por sinonimo, de 2009 a 2025, uma vez cada (no primeiro termo da lista), com o filtro de palavra do termo
  sin, vistos = {}, set()
  for t, inc, exc in R.SINONIMOS[k]:
    ps = {r[0]: r[1] for r in json.load(open(os.path.join(S, f'projetos_nome_{t}.json'), encoding='utf-8'))['linhas']
          if r[0] not in atual and r[0] not in vistos and 2009 <= ano(r[0]) <= 2025 and re.search(inc, r[1], re.I) and not (exc and re.search(exc, r[1], re.I))}
    vistos |= set(ps); sin[t] = sorted(ps)
    am = sin[t] if len(ps) <= 40 else sorted(random.Random(f'fn-{t}-20261020').sample(sin[t], 40))
    assert am == sorted(r['pronac'] for r in FN if r['tema'] == k and r['termo'] == t), (k, t)
  for n, a, b in PER:
    fp = [r for r in FP if r['tema'] == k and r['estrato'] == n]
    c = {d: sum(r['decisao'] == d for r in fp) for d in ('sim', 'nao', 'indeterminado')}
    classif = sum(per(ano(p)) == n for p in atual)
    # falsos negativos estimados: projetos do termo no periodo vezes a fracao com tema na amostra do termo (sim, e sim mais indeterminado)
    lidos = sim_l = 0; est_min = est_max = 0.0
    for t, _, _ in R.SINONIMOS[k]:
      dec = [r for r in FN if r['tema'] == k and r['termo'] == t]
      if not dec: continue
      no_per = sum(per(ano(p)) == n for p in sin[t])
      lidos += sum(per(ano(r['pronac'])) == n for r in dec); sim_l += sum(per(ano(r['pronac'])) == n and r['decisao'] == 'sim' for r in dec)
      est_min += no_per * sum(r['decisao'] == 'sim' for r in dec) / len(dec)
      est_max += no_per * sum(r['decisao'] != 'nao' for r in dec) / len(dec)
    nv = sum(novos[y] for y in range(a, b + 1))
    lin.append([k, n, f'{a}-{b}', nv, classif, round(100 * classif / nv, 3), len(fp), c['sim'], c['nao'], c['indeterminado'],
                round(100 * c['sim'] / len(fp), 1) if fp else '', round(100 * (c['sim'] + c['indeterminado']) / len(fp), 1) if fp else '',
                lidos, sim_l, round(est_min, 1), round(est_max, 1), round(100 * (classif + est_min) / nv, 3), round(100 * (classif + est_max) / nv, 3)])
with open(os.path.join(RAIZ, 'CV-temas-auditoria.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n')
  w.writerow(['tema', 'presidente', 'anos', 'projetos_novos', 'classificados', 'pct_classificados', 'amostra_lida', 'amostra_sim', 'amostra_nao',
              'amostra_indeterminado', 'precisao_v125_min_pct', 'precisao_v125_max_pct', 'sinonimos_lidos', 'sinonimos_lidos_com_tema',
              'falsos_negativos_estimados_min', 'falsos_negativos_estimados_max', 'pct_com_falsos_negativos_min', 'pct_com_falsos_negativos_max'])
  w.writerows(lin)
print('CV-temas-auditoria.csv', len(lin))

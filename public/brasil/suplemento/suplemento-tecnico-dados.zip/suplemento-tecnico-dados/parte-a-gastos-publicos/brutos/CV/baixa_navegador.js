// Frente CV. Relatorios do painel Salic Comparar (MinC) e serie do Google Trends, que so abrem em navegador.
// Uso: xvfb-run -a node baixa_navegador.js   (precisa de playwright-core e de um Chromium; caminhos por PLAYWRIGHT_CORE e CHROME)
// Uma pagina por vez, com pausa. Salva em fontes/salic/ e fontes/trends.json; depois rode baixa_CV.py para registrar os hashes.
const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const fs = require('fs'), path = require('path');
const F = path.join(__dirname, 'fontes'), S = path.join(F, 'salic');
const BASE = 'https://aplicacoes.cultura.gov.br/comparar/';
const RELATORIOS = ['grid_Avaliacao_Cnic_Ano', 'grid_Qtde_Proposta_Transformada_Por_Ano_Area', 'grid_TempoMedio_Da_Admissibilidade_Ate_Publicacao', 'grid_Captacao_Por_TipoDeApoio_Ano'];
// busca "Nome do Projeto contem <termo>" na lista de projetos do incentivo fiscal federal
const TERMOS = ['LGBT', 'Queer', 'Drag', 'Afro', 'Negr', 'Quilomb', 'Indígen', 'Indigen', 'Decolon', 'Descolon', 'Gospel', 'Orquestra'];
// sinonimos que a busca por radical nao pega, so para a auditoria de falsos negativos (audita_temas.py), fora das series
const TERMOS_FN = ['Candombl', 'Terreiro', 'Orixá', 'Orixa', 'Umbanda', 'Maracatu', 'Jongo', 'Preta', 'Preto',
  'Aldeia', 'Guarani', 'Originári', 'Originari', 'Tupi', 'Yanomami', 'Xingu', 'Kayap', 'Patax', 'Xavante', 'Krenak',
  'Gay', 'Lésbic', 'Lesbic', 'Travesti', 'Transgên', 'Transgen', 'Bissex', 'Homossex', 'Orgulho'];
const pausa = ms => new Promise(r => setTimeout(r, ms));
// o ScriptCase as vezes navega depois do networkidle: repete a leitura quando o contexto da pagina e destruido
const le = async (p, f, a) => { for (let i = 0; ; i++) { try { return await p.evaluate(f, a); } catch (e) { if (i > 5 || !/context was destroyed|navigation/.test(e.message)) throw e; await p.waitForLoadState('networkidle', { timeout: 180000 }).catch(() => {}); await pausa(4000); } } };
(async () => {
  fs.mkdirSync(S, { recursive: true });
  const b = await chromium.launch({ headless: false, executablePath: process.env.CHROME });
  const p = await (await b.newContext({ locale: 'pt-BR', viewport: { width: 1600, height: 1200 } })).newPage();
  await p.goto(BASE + 'salicnet/', { waitUntil: 'networkidle', timeout: 120000 });
  for (const a of RELATORIOS) {
    if (fs.existsSync(path.join(S, a + '.txt'))) continue;
    await p.goto(BASE + a + '/', { waitUntil: 'networkidle', timeout: 180000 }); await pausa(4000);
    fs.writeFileSync(path.join(S, a + '.txt'), await p.evaluate(() => document.body.innerText)); console.log('ok', a); await pausa(3000);
  }
  for (const t of [...TERMOS, ...TERMOS_FN]) {
    const dst = path.join(S, `projetos_nome_${t}.json`);
    if (fs.existsSync(dst)) continue;
    await p.goto(BASE + 'grid_Projetos_Mecenato/', { waitUntil: 'networkidle', timeout: 180000 });
    await p.evaluate(t => { document.F1.tmp_nmprojeto.value = t; document.F1.bprocessa.value = 'pesq'; nm_submit_form(); }, t);
    await p.waitForLoadState('networkidle', { timeout: 180000 }); await pausa(4000);
    const tot = +(await le(p, () => (document.body.innerText.match(/\[1 a \d+ de (\d+)\]/) || [])[1] || '0'));
    if (tot > 15) {
      await p.evaluate(n => { document.getElementById('quant_linhas_f0_bot').value = n; nm_gp_submit_ajax('muda_qt_linhas', n); }, String(tot + 10));
      await p.waitForLoadState('networkidle', { timeout: 300000 }); await pausa(8000);
    }
    const cab = await le(p, () => [...document.querySelectorAll('tr')].map(tr => [...tr.children].map(td => td.innerText.trim())).find(c => c[0] === 'Pronac') || []);
    const rows = await le(p, () => [...document.querySelectorAll('tr')].map(tr => [...tr.children].map(td => td.innerText.trim())).filter(c => c.length >= 10 && /^\d{6,7}$/.test(c[0])));
    // a coluna Proponente (indice 2) sai: e nome de pessoa ou empresa, e o dossie nao guarda dado pessoal de terceiros
    const uniq = Object.values(Object.fromEntries(rows.map(r => [r[0], r.filter((_, i) => i !== 2)])));
    if (uniq.length !== tot) throw new Error(`${t}: ${uniq.length} linhas de ${tot}`);
    fs.writeFileSync(dst, JSON.stringify({ termo: t, campo: 'Nome do Projeto, contem', total_informado: tot, cabecalho: cab.filter((_, i) => i !== 2), linhas: uniq }));
    console.log('ok', t, tot); await pausa(4000);
  }
  // Google Trends, Brasil, jan/2004 a set/2026, cinco termos no mesmo pedido (indice relativo de 0 a 100)
  const TR = path.join(F, 'trends.json');
  if (!fs.existsSync(TR)) {
    let ml = null;
    p.on('response', async r => { if (/widgetdata\/multiline/.test(r.url())) { try { ml = { url: r.url(), corpo: await r.text() }; } catch (e) {} } });
    await p.goto('https://trends.google.com/trends/', { waitUntil: 'networkidle', timeout: 120000 }); await pausa(4000);
    const TERMOS_TR = ['Lei Rouanet', 'Plano Safra', 'Zona Franca de Manaus', 'Fundo Partidário', 'Fundo Eleitoral'];
    const q = TERMOS_TR.map(encodeURIComponent).join(',');
    await p.goto(`https://trends.google.com/trends/explore?date=2004-01-01%202026-09-30&geo=BR&q=${q}&hl=pt-BR`, { waitUntil: 'networkidle', timeout: 180000 }); await pausa(15000);
    if (!ml) throw new Error('Trends sem resposta');
    fs.writeFileSync(TR, JSON.stringify({ termos: TERMOS_TR, geo: 'BR', periodo: '2004-01-01 2026-09-30', pagina: `https://trends.google.com/trends/explore?date=2004-01-01%202026-09-30&geo=BR&q=${q}`, consultado: new Date().toISOString().slice(0, 10), resposta: ml }));
    console.log('ok trends');
  }
  await b.close();
})();

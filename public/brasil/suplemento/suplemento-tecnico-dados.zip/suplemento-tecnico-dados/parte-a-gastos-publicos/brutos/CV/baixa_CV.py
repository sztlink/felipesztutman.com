#!/usr/bin/env python3
# Frente CV, cultura e governo. Baixa os atos oficiais (DOU e Planalto) sobre o Ministerio da Cultura, a Lei Rouanet e as leis de
# fomento de 2020 a 2023, uma requisicao por vez com pausa, e registra cada arquivo em downloads.tsv. Os relatorios do painel Salic
# Comparar vem de baixa_navegador.js (o painel so abre em navegador). Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CV/baixa_CV.py
import datetime, hashlib, os, re, subprocess, time, urllib.parse
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
D, P = 'https://www.in.gov.br/web/dou/-/', 'https://www.planalto.gov.br/ccivil_03/'
ITENS = [
  ('dou_in_2_2019_mcidadania.html', 'DOU 24/04/2019, Instrucao Normativa n 2 de 23/04/2019, Ministerio da Cidadania, regras do Pronac (Lei Rouanet)', D + 'instru%C3%87%C3%83o-normativa-n%C2%BA-2-de-23-de-abril-de-2019-84797797'),
  ('dou_portaria_1576_2019_mcidadania.html', 'DOU 21/08/2019, Portaria n 1.576 de 20/08/2019, Ministerio da Cidadania, suspensao de chamamento do FSA', D + 'portaria-n-1.576-de-20-de-agosto-de-2019-211680778'),
  ('dou_in_1_2022_secult.html', 'DOU 08/02/2022, Instrucao Normativa Secult/MTur n 1 de 04/02/2022, regras do Pronac (Lei Rouanet)', D + 'instrucao-normativa-secult/mtur-n-1-de-4-de-fevereiro-de-2022-378650380'),
  ('dou_in_1_2023_minc.html', 'DOU 11/04/2023, Instrucao Normativa MinC n 1 de 10/04/2023, regras do Pronac (Lei Rouanet)', D + 'instrucao-normativa-minc-n-1-de-10-de-abril-de-2023-476028057'),
  ('planalto_l13502.htm', 'Lei 13.502/2017, organizacao da Presidencia e dos Ministerios em 2017 e 2018', P + '_ato2015-2018/2017/lei/l13502.htm'),
  ('planalto_mpv870.htm', 'MP 870 de 01/01/2019, organizacao da Presidencia e dos Ministerios', P + '_ato2019-2022/2019/mpv/mpv870.htm'),
  ('planalto_l13844.htm', 'Lei 13.844/2019, conversao da MP 870', P + '_ato2019-2022/2019/lei/l13844.htm'),
  ('planalto_mpv1154.htm', 'MP 1.154 de 01/01/2023, organizacao da Presidencia e dos Ministerios', P + '_ato2023-2026/2023/mpv/mpv1154.htm'),
  ('planalto_l14600.htm', 'Lei 14.600/2023, conversao da MP 1.154', P + '_ato2023-2026/2023/lei/l14600.htm'),
  ('planalto_l14017.htm', 'Lei 14.017/2020, Lei Aldir Blanc, acoes emergenciais para o setor cultural', P + '_ato2019-2022/2020/lei/l14017.htm'),
  ('planalto_lcp195.htm', 'Lei Complementar 195/2022, Lei Paulo Gustavo', P + 'leis/lcp/lcp195.htm'),
  ('planalto_l14399.htm', 'Lei 14.399/2022, Politica Nacional Aldir Blanc de Fomento a Cultura', P + '_ato2019-2022/2022/lei/l14399.htm'),
  ('planalto_mpv1135.htm', 'MP 1.135/2022, altera prazos da LC 195 e da Lei 14.399', P + '_ato2019-2022/2022/mpv/mpv1135.htm'),
  ('planalto_d10107.htm', 'Decreto 10.107/2019, transfere a Secretaria Especial da Cultura ao Ministerio do Turismo', P + '_ato2019-2022/2019/decreto/D10107.htm'),
  ('planalto_mpv1274.htm', 'MP 1.274/2024, altera a Lei 14.399 (Politica Nacional Aldir Blanc)', P + '_ato2023-2026/2024/mpv/mpv1274.htm'),
  ('planalto_mpv726.htm', 'MP 726/2016, organizacao da Presidencia e dos Ministerios (maio de 2016)', P + '_ato2015-2018/2016/mpv/mpv726.htm'),
  ('planalto_mpv728.htm', 'MP 728/2016, recria o Ministerio da Cultura', P + '_ato2015-2018/2016/mpv/mpv728.htm'),
]
linhas = []
for arq, desc, url in ITENS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    r = subprocess.run(['curl', '-s', '-L', '-m', '120', '-A', UA, '-o', dst, '-w', '%{http_code}', url], capture_output=True, text=True)
    if r.stdout != '200' or os.path.getsize(dst) < 2000: os.remove(dst); raise SystemExit(f'falhou {arq} {r.stdout}')
    time.sleep(6)
  h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, 'fontes/' + arq, url, h])); print('ok', arq)
# execucao das transferencias da cultura por lei (Aldir Blanc 2020, Paulo Gustavo, Politica Nacional Aldir Blanc) no SIOP, 2020 a 2025
Q = """PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?fl ?al (SUM(?atu) AS ?dotacao_atual) (SUM(?emp) AS ?empenhado) (SUM(?liq) AS ?liquidado) (SUM(?pag) AS ?pago)
FROM <http://orcamento.dados.gov.br/%d/>
WHERE { ?s a loa:ItemDespesa ; loa:temFuncao ?f ; loa:temAcao ?a ; loa:valorLeiMaisCredito ?atu ; loa:valorEmpenhado ?emp ; loa:valorLiquidado ?liq ; loa:valorPago ?pag . ?f rdfs:label ?fl . ?a rdfs:label ?al . FILTER(REGEX(?al, 'Setor Cultural|Aldir Blanc|Lei Complementar nº 195', 'i')) }
GROUP BY ?fl ?al"""
for y in range(2020, 2026):
  arq = f'siop_transferencias_cultura_{y}.csv'; dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    r = subprocess.run(['curl', '-s', '-m', '900', 'https://www1.siop.planejamento.gov.br/sparql/', '--data-urlencode', 'query=' + Q % y, '-H', 'Accept: text/csv', '-o', dst, '-w', '%{http_code}'], capture_output=True, text=True)
    if r.stdout != '200': os.remove(dst); raise SystemExit(f'falhou {arq}')
    time.sleep(6)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), f'SIOP, acoes de transferencia da cultura por lei, dotacao, empenhado, liquidado e pago, {y}', 'fontes/' + arq, f'https://www1.siop.planejamento.gov.br/sparql/ (grafo http://orcamento.dados.gov.br/{y}/, consulta neste script)', hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
# Camara dos Deputados, proposicoes por ano de apresentacao que tem o termo na ementa ou na indexacao (X-Total-Count da API)
import json
CAM = os.path.join(F, 'camara_proposicoes_por_termo.json')
if not os.path.exists(CAM):
  cont = {}
  for termo in ('Rouanet', '8.313', 'Plano Safra', 'Zona Franca'):
    for y in range(2003, 2026):
      u = 'https://dadosabertos.camara.leg.br/api/v2/proposicoes?' + urllib.parse.urlencode({'keywords': termo, 'ano': y, 'itens': 1})
      r = subprocess.run(['curl', '-s', '-m', '60', '-D', '-', '-o', '/dev/null', '-H', 'Accept: application/json', u], capture_output=True, text=True).stdout
      m = re.search(r'x-total-count: *(\d+)', r, re.I)
      if not m: raise SystemExit(f'falhou camara {termo} {y}')
      cont[f'{termo}|{y}'] = int(m.group(1)); time.sleep(2)
  json.dump({'consulta': 'https://dadosabertos.camara.leg.br/api/v2/proposicoes?keywords=<termo>&ano=<ano>', 'consultado': datetime.date.today().isoformat(), 'contagens': cont}, open(CAM, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(CAM)).strftime('%Y-%m-%d'), 'Camara dos Deputados, API de dados abertos, proposicoes por ano com o termo, de 2003 a 2025', 'fontes/camara_proposicoes_por_termo.json', 'https://dadosabertos.camara.leg.br/api/v2/proposicoes?keywords=<termo>&ano=<ano>', hashlib.sha256(open(CAM, 'rb').read()).hexdigest()]))
salic = os.path.join(F, 'salic')
if os.path.isdir(salic):
  for a in sorted(os.listdir(salic)):
    p = os.path.join(salic, a)
    linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime('%Y-%m-%d'), 'MinC, painel Salic Comparar, ' + a.rsplit('.', 1)[0], 'fontes/salic/' + a, 'https://aplicacoes.cultura.gov.br/comparar/ (baixa_navegador.js)', hashlib.sha256(open(p, 'rb').read()).hexdigest()]))
TR = os.path.join(F, 'trends.json')
if os.path.exists(TR):
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(TR)).strftime('%Y-%m-%d'), 'Google Trends, Brasil, 2004 a 2026, Lei Rouanet, Plano Safra, Zona Franca de Manaus, Fundo Partidario, Fundo Eleitoral (baixa_navegador.js)', 'fontes/trends.json', 'https://trends.google.com/trends/explore?date=2004-01-01%202026-09-30&geo=BR', hashlib.sha256(open(TR, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n')
print(len(linhas), 'arquivos')

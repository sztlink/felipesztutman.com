# Frente CV, cultura e governo

Feita em 20/10/2026 para a v12.5, para testar com dados a leitura do autor sobre a cultura na disputa de 2026. A leitura tinha seis
partes: o peso financeiro da cultura, o peso dela no debate público, o tratamento da Lei Rouanet e dos artistas de 2019 a 2022, os
temas dos projetos, a ausência do Ministério da Cultura no plano do PL e a economia de extinguir um ministério. Só entra no dossiê
o que um dado ou um documento oficial mede. Intenção, motivo de decisão e efeito sobre o eleitor ficam fora.

## O que entra
- `CV-atos.csv`. Atos oficiais com o trecho literal conferido contra o texto baixado: lista de ministérios de 2018, 2019 e 2023,
  destino da política de cultura em 2019 e 2021, tetos e cachês da Lei Rouanet em 2019, 2022 e 2023, a portaria que suspendeu o
  edital do FSA para TVs públicas em 2019, a Lei Aldir Blanc, os vetos totais e a promulgação da Lei Paulo Gustavo e da Política
  Nacional Aldir Blanc, e a MP 1.135/2022.
- `CV-ministerios.csv`. Número de ministérios em cada lei de organização e presença do da Cultura.
- `CV-salic-por-ano.csv`. Painel Salic Comparar, de 2009 a 2025: projetos novos (propostas transformadas em projeto), projetos
  avaliados pela CNIC, dias de admissibilidade e até a publicação, captação em R$ correntes e de 2025, e projetos novos com temas no
  nome (LGBT, negra e quilombola, indígena, decolonial, gospel como controle), com a parte do total e o valor captado.
- `CV-transferencias-cultura.csv`. Dotação, empenhado e liquidado das transferências da cultura por lei no SIOP, de 2020 a 2025.
- `CV-estrutura-cultura.csv`. Função Cultura sem inversões, pessoal ativo e administração, FSA, e a parte da despesa primária.
- `CV-atencao.csv`. Google Trends (média anual do índice de quatro termos no mesmo pedido) e proposições na Câmara por termo.
- `CV-temas-auditoria.csv`. Auditoria manual da classificação dos temas por governo, com a precisão na amostra lida e os falsos
  negativos estimados pelos sinônimos (audita_temas.py).

## Regras
- A busca de temas usa o campo Nome do Projeto, com radicais (LGBT, Queer, Drag, Afro, Negr, Quilomb, Indígen, Decolon, Gospel).
  Filtros tiram falsos positivos (Dragão, mandrágora, Rio Negro, o sobrenome Negrão, Afrodite, e desde a auditoria manual Agulhas
  Negras, rubro-negro, Vale Negro e abelhas indígenas). O ano é o dos dois primeiros dígitos do Pronac. As regras ficam em
  regras_temas.py.
- Auditoria manual (audita_temas.py). Falsos positivos por amostra de até 12 títulos por tema e governo, sorteada com semente fixa
  sobre a classificação da v12.5 e lida título a título (auditoria_temas_falsos_positivos.tsv). Falsos negativos por sinônimos que o
  radical não pega, buscados no mesmo painel (candomblé, terreiro, orixá, umbanda, maracatu, jongo, preta e preto, aldeia, guarani,
  povos originários, nomes de povos, gay, lésbica, travesti, transgênero, bissexual, homossexual, orgulho), com os projetos achados
  só por sinônimo lidos (auditoria_temas_falsos_negativos.tsv). Os arquivos de decisão trazem o Pronac e não o título.
- A coluna de proponente sai dos arquivos baixados, porque é nome de pessoa ou empresa.
- O relatório "Enviadas" do painel tem título interno de propostas não enviadas, é ambíguo e não entra.
- O vínculo entre a Portaria 1.576/2019 e algum tema do edital aparece em imprensa e em ação do Ministério Público Federal, mas não
  em documento primário baixado. A liminar da 11ª Vara Federal do Rio de Janeiro, achada em 24/10/2026
  (desenvolvimento/brutos/VARIOS), entrou no anexo T1 na v13.1 com a motivação como alegação do MPF.
- A Lei Paulo Gustavo foi empenhada em 2022 e paga como restos a pagar, que o SIOP do ano não mostra.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/CV/baixa_CV.py
PLAYWRIGHT_CORE=<playwright-core> CHROME=<chromium> xvfb-run -a node <pacote>/brutos/CV/baixa_navegador.js
cd /tmp && python3 -I <pacote>/brutos/CV/baixa_CV.py   (de novo, para registrar os hashes do navegador)
cd /tmp && python3 -I <pacote>/brutos/CV/build_CV.py
cd /tmp && python3 -I <pacote>/brutos/CV/audita_temas.py
```

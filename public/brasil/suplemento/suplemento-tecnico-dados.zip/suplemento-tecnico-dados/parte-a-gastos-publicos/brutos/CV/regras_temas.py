# Regras dos temas no nome do projeto (frente CV), usadas por build_CV.py e audita_temas.py.
# TEMAS, termos buscados no painel Salic por radical e regex que tira falsos positivos.
TEMAS = [('lgbt', ['LGBT', 'Queer', 'Drag'], r'lgbt|queer|\bdrags?\b|drag queen|drag king'),
         ('negra_quilombola', ['Afro', 'Negr', 'Quilomb'], r'(?<!rio )(?<!cisne )(?<!ouro )(?<!buraco )(?<!ovelha )(?<!rosa )(?<!pedra )(?<!agulhas )(?<!vale )(?<!rubro-)(?<!rubro )\bnegr[oa]s?\b(?! tirania)|negritude|afro(?!dit)|quilomb'),
         ('indigena', ['Indígen', 'Indigen'], r'(?<!abelhas )ind[ií]gen'),
         ('decolonial', ['Decolon', 'Descolon'], r'decolon|descolon'),
         ('gospel_controle', ['Gospel'], r'gospel'),
         ('orquestra_controle', ['Orquestra'], r'orquestra')]
# regex da v12.5, antes dos filtros da auditoria manual, so para refazer o sorteio da amostra de falsos positivos
TEMAS_V125 = {'lgbt': r'lgbt|queer|\bdrags?\b|drag queen|drag king',
              'negra_quilombola': r'(?<!rio )(?<!cisne )(?<!ouro )(?<!buraco )(?<!ovelha )(?<!rosa )(?<!pedra )\bnegr[oa]s?\b(?! tirania)|negritude|afro(?!dit)|quilomb',
              'indigena': r'ind[ií]gen'}
# sinonimos que o radical nao pega, buscados so para estimar falsos negativos (TERMOS_FN em baixa_navegador.js). A busca do painel e por
# trecho do nome (Preta acha Interpreta, Gay acha Gaya), entao cada termo leva uma regex de palavra e, quando ha, uma de exclusao
# objetiva (nome de cidade, o Aquifero Guarani). O resto se decide na leitura
SINONIMOS = {
  'negra_quilombola': [('Candombl', r'candombl', None), ('Terreiro', r'terreiro', None), ('Orixá', r'orix', None), ('Orixa', r'orix', None),
                       ('Umbanda', r'umbanda', None), ('Maracatu', r'maracatu', None), ('Jongo', r'\bjongos?\b', None),
                       ('Preta', r'\bpretas?\b|pretagon', None), ('Preto', r'\bpretos?\b', r'ouro preto|rio preto|ribeir[aã]o preto')],
  'indigena': [('Aldeia', r'aldeia', r's[aã]o pedro da aldeia'), ('Guarani', r'guaran[ií]', r'aq[uü][ií]fero'), ('Originári', r'originári', None),
               ('Originari', r'originari', None), ('Tupi', r'\btupis?\b|tupinamb|tupiniquim|tupi-guarani|tupi guarani', None),
               ('Yanomami', r'yanomami', None), ('Xingu', r'\bxingu', None), ('Kayap', r'kayap', None), ('Patax', r'patax', None),
               ('Xavante', r'\bxavante', None), ('Krenak', r'krenak', None)],
  'lgbt': [('Gay', r'\bgays?\b|dialogay|day gay', None), ('Lésbic', r'lésbic', None), ('Lesbic', r'lesbic', None), ('Travesti', r'travesti', None),
           ('Transgên', r'transgên', None), ('Transgen', r'transgen', None), ('Bissex', r'bissex', None), ('Homossex', r'homossex', None),
           ('Orgulho', r'orgulho', None)]}

# Frente P: quem financia o Estado, quem recebe os beneficios

Levantamento de 18/10/2026. So fonte primaria oficial (IBGE, RFB, STN, Ministerio da Previdencia, Ministerio da Defesa via PLDO). Nada exigiu login.

Regenerar, de fora desta pasta:

    python3 -I brutos/P/build_P.py

O script e idempotente (rodado duas vezes, os quatro CSV saem iguais byte a byte) e grava na raiz `gastos-publicos/`:

| CSV | conteudo |
|---|---|
| `P-desigualdade-pobreza.csv` | Gini do rendimento domiciliar per capita 2012 a 2025, com e sem programas sociais (2012 a 2024); pobreza abaixo de US$ 2,15, 3,65 e 6,85 PPC 2017 e abaixo de R$ 218, com e sem programas; pessoas abaixo das linhas |
| `P-irpf-faixas.csv` | IRPF por faixa de rendimento total em salarios minimos, anos-calendario 2007 a 2024: declarantes, rendimento tributavel, exclusivo, isento, total, imposto devido, aliquota efetiva, participacoes, lucros e dividendos (2022 a 2024) |
| `P-previdencia-regimes.csv` | RGPS: beneficios, valor e valor medio em dezembro, 2006 a 2025; RPPS civil da Uniao: segurados e provento medio por poder, bases 07/2013 a 12/2024; despesa, receita e resultado do RREO 2007 a 2024; militares: quantidades 2020 a 2024 e provento medio (mai/2025) |
| `P-carga-por-base.csv` | RFB, receita tributaria por base de incidencia 2002 a 2024 (R$, % do PIB, % do total); STN, carga do governo geral por especie GFSM 2014, 2010 a 2025 |

Colunas de todos: `serie, ano, presidente, recorte, valor, unidade, fonte_url, pagina_ou_tabela, nota`. Valor vazio com nota "nao encontrado" quando nao ha fonte. Toda linha derivada (soma, razao, media ponderada) comeca a nota com "derivado:" e diz a conta.

Presidente pelo ano (mesma regra da frente L): 2016 = "Dilma/Temer". No IRPF o ano e o ano-calendario (renda de 2024 declarada em 2025).

## Fontes (URL e data em `downloads.tsv`)

| pasta | fonte |
|---|---|
| `ibge-sis2025/` | IBGE, Sintese de Indicadores Sociais 2025, tabelas de distribuicao de renda (zip xls): 2.13 Gini, 2.14 Gini sem programas, 2.18 pobreza, 2.20 pobreza sem programas, 2.22 linhas em reais. Cada tabela tem uma aba por ano 2012 a 2024 e uma aba de CV |
| `ibge-sidra/` | SIDRA 7435 (Gini do rendimento domiciliar per capita) e 7453 (Gini do rendimento do trabalho), 2012 a 2025, API |
| `rfb-irpf/` | RFB, Grandes Numeros DIRPF, edicoes 2008 a 2025 (anos-calendario 2007 a 2024), e o PDF de metadados da edicao 2025 |
| `prev/beps122025.pdf` | Boletim Estatistico da Previdencia Social dez/2025, quadro 14. Copia de `brutos/G/` (baixado em 17/10); em 18/10 a URL respondeu NotFound ao curl |
| `prev/2-uniao.zip` | AEPS 2024, suplemento RPPS, pasta "2. Uniao" (numero de segurados e remuneracao media civil, militares, resultado financeiro do RREO) |
| `prev/pldo2027-anexo-iv-11-*.pdf`, `-iv-12-*.pdf` | PLDO 2027, avaliacoes atuariais do RPPS da Uniao e do sistema de protecao dos militares. Copias de `brutos/G/` |
| `rfb-ctb/` | RFB, Carga Tributaria no Brasil 2024 (planilha e PDF). Copia de `brutos/L/rfb/` |
| `tesouro-ctb/` | STN, Estimativa da Carga Tributaria Bruta do Governo Geral 2025. Copia de `brutos/L/tesouro/` |

## Leitura e cuidados

**Desigualdade.** SIS e SIDRA coincidem nos anos comuns (2012 a 2024). 2020 e 2021 usam o acumulado de quintas visitas, os demais anos, primeiras visitas (nota de cada linha). "Sem programas sociais" e exercicio contabil do IBGE: tira a renda declarada de Bolsa Familia, BPC, auxilio emergencial e outros, sem simular comportamento. A SIS usa as linhas PPC 2017 do Banco Mundial (US$ 2,15, 3,65 e 6,85), nao as PPC 2021.

**IRPF.** Tres formatos de planilha, lidos pelo script:
- edicoes 2008 a 2021: Tabela 9 agregada por faixa, R$ milhoes, com linha Total (o script confere a soma das faixas);
- edicao 2022: Tab8 por formulario, UF e faixa, R$ milhoes, somada no script;
- edicoes 2023 a 2025: Tab8 em colunas tecnicas, R$, somada e convertida para R$ milhoes. Algumas celulas vem com "x" (sigilo); entram como zero (0 a 3 por edicao, a nota diz quantas).

Faixas: ate o ano-calendario 2013 sao 11 faixas (ate "mais de 160 SM"); de 2014 em diante, 17 (ate "mais de 320 SM"). `recorte = publicada: ...` traz a faixa como saiu; `harmonizada: ...` soma as faixas novas nos limites antigos para comparar anos.

Imposto: "Imposto Devido Total" (devido menos incentivos, mais RRA) quando a edicao o publica (2019 em diante); antes, "Imposto Devido". A aliquota efetiva e imposto devido / (tributavel + exclusivo + isento). O IR retido de forma definitiva sobre a renda de tributacao exclusiva (13o, aplicacoes financeiras, PLR, JCP) nao aparece como imposto devido, entao a razao subestima o IR total pago por quem tem muita renda exclusiva. Lucros e dividendos isentos ja pagaram IRPJ e CSLL na empresa, que esta tabela nao mostra.

Comparacao no tempo tem limites: a faixa e em salario minimo do proprio ano (o SM real subiu), o limite de obrigatoriedade de declarar mudou, e o numero de declarantes saltou em 2021 e 2022 (31,6 para 40,6 milhoes).

**Previdencia.** RGPS conta beneficios, nao pessoas, e o valor do quadro 14 e o do mes de dezembro, sem 13o. RPPS civil: medias de remuneracao do cadastro do anexo atuarial de cada PLDO, por poder; a media de todos os poderes e ponderada pelos quantitativos da mesma base. A base muda de julho (2013 a 2017) para dezembro (2018 em diante). Despesa por beneficiario = despesa do ano no RREO / pessoas da base, inclui 13o. No RREO, ate 2016 inatividade e pensoes militares repetem o mesmo numero (agregado); nao somar.

**Carga.** RFB (metodologia nova da edicao 2024, sem FGTS e Sistema S) separa renda, folha, propriedade, bens e servicos e transacoes financeiras. A STN segue o GFSM 2014: as contribuicoes sociais ficam separadas, e a CPMF e o IOF entram em bens e servicos; por isso os percentuais por base nao coincidem entre as duas.

## Nao encontrado

- Pobreza por linha e Gini sem programas para 2025 (a SIS com dados de 2025 sai na edicao 2026; o SIDRA so tem o Gini observado).
- Pobreza nas linhas PPC 2021 (US$ 3,00 e 8,30): a SIS 2025 nao publica.
- Grandes Numeros DIRPF do ano-calendario 2025 (sai em 2026/2027).
- IRPF antes de 2007 no mesmo formato.
- Provento medio do RPPS civil na base jul/2025 (PLDO 2027): as tabelas 3 a 6 do Anexo IV.11 sao imagens; nao transcritas.
- Provento medio de militares antes da base mai/2025, e quantidades de militares antes de 2020 nesta fonte.
- Carga por base de 2025 pela RFB (so a estimativa STN).

#!/usr/bin/env python3
"""Frente P: quem financia o Estado e quem recebe os beneficios.

Le apenas arquivos ja baixados em brutos/P/* e grava, na raiz gastos-publicos/:
  P-desigualdade-pobreza.csv   (IBGE SIS 2025 e SIDRA 7435/7453)
  P-irpf-faixas.csv            (RFB, Grandes Numeros DIRPF, AC 2007 a 2024)
  P-previdencia-regimes.csv    (BEPS dez/2025, AEPS 2024 RPPS Uniao, PLDO 2027 Anexo IV.12)
  P-carga-por-base.csv         (RFB Carga Tributaria no Brasil 2024, STN CTB 2025)
Idempotente: reescreve as quatro saidas a cada execucao. Nenhum numero digitado a mao;
os valores derivados (somas, razoes, medias ponderadas) dizem na nota como foram feitos.

Rodar de fora das pastas de dados:  python3 -I brutos/P/build_P.py
Dependencias: openpyxl (em ~/.local/lib/python3.12/site-packages), xlrd (cache do uv ou
XLRD_PATH) e pymupdf (~/.local/lib/pdftools). O script acrescenta esses caminhos.
"""
import csv
import glob
import json
import os
import re
import sys
import warnings
import zipfile
from collections import defaultdict, OrderedDict

warnings.filterwarnings('ignore')
HOME = os.path.expanduser('~')
for p in [os.environ.get('XLRD_PATH', ''),
          os.path.join(HOME, '.local/lib/python3.12/site-packages'),
          os.path.join(HOME, '.local/lib/pdftools')] + \
        [os.path.dirname(x) for x in glob.glob(os.path.join(HOME, '.cache/uv/archive-v0/*/xlrd'))]:
    if p and os.path.isdir(p) and p not in sys.path:
        sys.path.append(p)
import openpyxl  # noqa: E402
import xlrd  # noqa: E402
import pymupdf  # noqa: E402

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
P = lambda *a: os.path.join(AQUI, *a)

COLS = ['serie', 'ano', 'presidente', 'recorte', 'valor', 'unidade',
        'fonte_url', 'pagina_ou_tabela', 'nota']

# ---------------------------------------------------------------- utilidades

URL = {}
with open(P('downloads.tsv'), encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        URL[r['arquivo']] = r['url']


def url(arq):
    return URL[arq]


def presidente(a):
    a = int(a)
    if 1997 <= a <= 2002: return 'FHC'
    if 2003 <= a <= 2006: return 'Lula 1'
    if 2007 <= a <= 2010: return 'Lula 2'
    if 2011 <= a <= 2015: return 'Dilma'
    if a == 2016: return 'Dilma/Temer'
    if 2017 <= a <= 2018: return 'Temer'
    if 2019 <= a <= 2022: return 'Bolsonaro'
    if 2023 <= a <= 2026: return 'Lula 3'
    return ''


def num(x):
    """Numero de celula ou de texto pt-BR ('1.234,56')."""
    if x is None: return None
    if isinstance(x, (int, float)): return float(x)
    s = str(x).strip().replace('R$', '').strip()
    if s in ('', '-', '–', '..', '...', 'X', 'x'): return None
    if ',' in s or re.fullmatch(r'-?\d{1,3}(\.\d{3})+', s): s = s.replace('.', '').replace(',', '.')
    try: return float(s)
    except ValueError: return None


def fmt(v, nd=6):
    if v is None: return ''
    v = round(float(v), nd)
    return ('%d' % v) if v == int(v) and abs(v) > 1e3 else repr(v)


class Saida:
    def __init__(self, nome):
        self.nome = nome
        self.linhas = []

    def add(self, serie, ano, valor, unidade, fonte_url, pag, nota='', recorte='', nd=6):
        self.linhas.append(OrderedDict(
            serie=serie, ano=ano, presidente=presidente(ano) if str(ano).isdigit() else '',
            recorte=recorte, valor=fmt(valor, nd), unidade=unidade, fonte_url=fonte_url,
            pagina_ou_tabela=pag, nota=(nota if valor is not None else ('nao encontrado. ' + nota).strip())))

    def grava(self):
        with open(os.path.join(RAIZ, self.nome), 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=COLS)
            w.writeheader()
            for r in self.linhas:
                w.writerow(r)
        print('gravado', self.nome, len(self.linhas), 'linhas')


# ============================================================ 1. desigualdade
def parte_desigualdade():
    S = Saida('P-desigualdade-pobreza.csv')
    zip_arq = 'ibge-sis2025/2_Distribuicao_Renda_xls.zip'
    U = url(zip_arq)
    z = zipfile.ZipFile(P(zip_arq))

    def abre(prefixo):
        nome = [n for n in z.namelist() if n.startswith('Tabela ' + prefixo + ' ')][0]
        return xlrd.open_workbook(file_contents=z.read(nome)), nome

    def linha_brasil(sh):
        for r in range(sh.nrows):
            if str(sh.cell_value(r, 0)).strip() == 'Brasil':
                return r
        raise SystemExit('sem linha Brasil em ' + sh.name)

    def notas(sh):
        t = []
        for r in range(sh.nrows):
            v = str(sh.cell_value(r, 0)).strip()
            if v.startswith(('Fonte', 'Notas', '(1)', '(2)', 'Exclusive', 'Rendimentos', 'Programas', 'Exerc')):
                t.append(v)
        return ' '.join(t)

    # Gini com e sem programas sociais
    g = {}
    for tab, serie in (('2.13', 'gini_rdpc'), ('2.14', 'gini_rdpc_sem_programas_sociais')):
        wb, nome = abre(tab)
        for sh in wb.sheets():
            if not re.fullmatch(r'\d{4}', sh.name): continue
            ano = int(sh.name)
            r = linha_brasil(sh)
            v = num(sh.cell_value(r, 1))
            cv = num(wb.sheet_by_name(sh.name + ' (CV)').cell_value(linha_brasil(wb.sheet_by_name(sh.name + ' (CV)')), 1))
            g[(serie, ano)] = v
            S.add(serie, ano, v, 'indice 0 a 1', U, '%s, aba %s, linha Brasil' % (nome, sh.name),
                  'IBGE SIS 2025, PNAD Continua; CV %.2f%%. %s' % (cv, notas(sh)),
                  recorte='Brasil')
    for ano in sorted({a for (_, a) in g}):
        a, b = g.get(('gini_rdpc', ano)), g.get(('gini_rdpc_sem_programas_sociais', ano))
        if a is not None and b is not None:
            S.add('gini_reducao_pelos_programas_sociais', ano, b - a, 'pontos do indice', U,
                  'Tabelas 2.13 e 2.14, aba %d' % ano,
                  'derivado: Gini sem programas (2.14) menos Gini observado (2.13). O exercicio do IBGE retira a renda declarada de programas sociais (Bolsa Familia, BPC, auxilio emergencial e outros) sem simular mudanca de comportamento',
                  recorte='Brasil')

    # Pobreza por linhas internacionais, com e sem programas
    pob = {}
    for tab, suf in (('2.18', ''), ('2.20', '_sem_programas_sociais')):
        wb, nome = abre(tab)
        for sh in wb.sheets():
            if not re.fullmatch(r'\d{4}', sh.name): continue
            ano = int(sh.name)
            shcv = wb.sheet_by_name(sh.name + ' (CV)')
            r = linha_brasil(sh)
            rcv = linha_brasil(shcv)
            # cabecalho com as linhas de pobreza
            hdr = None
            for rr in range(r):
                if any('Menos de US$' in str(c) for c in sh.row_values(rr)):
                    hdr = rr
            total = num(sh.cell_value(r, 1))
            for j, c in enumerate(sh.row_values(hdr)):
                m = re.search(r'Menos de US\$ ([\d,]+) PPC (\d{4})', str(c))
                if not m: continue
                linha = m.group(1).replace(',', '.')
                v = num(sh.cell_value(r, j))
                cv = num(shcv.cell_value(rcv, j))
                serie = 'pobreza_us%s_ppc%s%s' % (linha.replace('.', '_'), m.group(2), suf)
                pob[(serie, ano)] = (v, total)
                S.add(serie, ano, v, '% das pessoas', U, '%s, aba %s, linha Brasil, coluna "%s"' % (nome, sh.name, str(c).strip()),
                      'rendimento domiciliar per capita abaixo de US$ %s PPC 2017 por dia; CV %s%%. %s' % (m.group(1), fmt(cv, 2), notas(sh)),
                      recorte='Brasil')
                if v is not None and total is not None:
                    S.add(serie.replace('pobreza_', 'pessoas_abaixo_'), ano, v * total / 100, 'mil pessoas', U,
                          '%s, aba %s, linha Brasil' % (nome, sh.name),
                          'derivado: proporcao vezes total de pessoas da mesma tabela (%s mil)' % fmt(total, 0), recorte='Brasil')
    for (serie, ano), (v, tot) in sorted(pob.items()):
        if serie.endswith('_sem_programas_sociais'): continue
        sem = pob.get((serie + '_sem_programas_sociais', ano))
        if sem and v is not None and sem[0] is not None:
            S.add(serie + '_reducao_pelos_programas', ano, sem[0] - v, 'pontos percentuais', U,
                  'Tabelas 2.18 e 2.20, aba %d' % ano,
                  'derivado: proporcao sem programas sociais (2.20) menos proporcao observada (2.18)', recorte='Brasil')

    # Linha nacional de R$ 218 (2.22)
    wb, nome = abre('2.22')
    for sh in wb.sheets():
        if not re.fullmatch(r'\d{4}', sh.name): continue
        ano = int(sh.name)
        r = linha_brasil(sh)
        for rr in range(r):
            for j, c in enumerate(sh.row_values(rr)):
                if re.match(r'At[eé] R\$ ?\d+', str(c).strip()):
                    v = num(sh.cell_value(r, j))
                    S.add('pobreza_ate_rs218_rdpc', ano, v, '% das pessoas', U,
                          '%s, aba %s, linha Brasil, coluna "%s"' % (nome, sh.name, str(c).strip()),
                          'linha nacional de R$ 218 mensais por pessoa, em reais medios de 2024 (valor de qualificacao do Bolsa Familia em 2024). ' + notas(sh),
                          recorte='Brasil')

    # SIDRA 7435 e 7453 (inclui 2025)
    for t, serie in (('7435', 'gini_rdpc_sidra'), ('7453', 'gini_rendimento_trabalho_sidra')):
        arq = 'ibge-sidra/sidra-%s-brasil.json' % t
        d = json.load(open(P(arq), encoding='utf-8'))[1:]
        vars_ = sorted({x['D2C'] for x in d})
        principal = [x for x in d if 'Gini' in x['D2N'] and 'Coeficiente' not in x['D2N']]
        cvs = {x['D3N']: x['V'] for x in d if 'Coeficiente' in x['D2N']}
        for x in principal:
            ano = int(x['D3N'])
            S.add(serie, ano, num(x['V'].replace('.', ',')) if x['V'] not in ('-', '...', '..') else None,
                  'indice 0 a 1', url(arq), 'SIDRA tabela %s, variavel %s' % (t, x['D2C']),
                  '%s; PNAD Continua anual, primeira visita; CV %s%%; publicado com 3 casas' % (x['D2N'], cvs.get(x['D3N'], '?')),
                  recorte='Brasil')
    for ano in (2025,):
        for serie in ('pobreza_us2_15_ppc2017', 'pobreza_us6_85_ppc2017', 'gini_rdpc_sem_programas_sociais'):
            S.add(serie, ano, None, '', U, 'SIS 2025 vai ate 2024',
                  'a SIS com dados de 2025 (edicao 2026) ainda nao foi publicada; o SIDRA nao publica proporcao abaixo de linha de pobreza nem o exercicio sem programas', recorte='Brasil')
    S.grava()


# ============================================================ 2. IRPF
def faixa_norm(s):
    """Rotulo da faixa (salarios minimos mensais) -> (limite inferior, rotulo padrao)."""
    t = str(s).lower().replace('salários mín.', '').replace('salário mín.', '').replace('salarios', '').strip()
    t = t.replace('de ', '').strip()
    fr = lambda x: {'1/2': 0.5}.get(x, None) if '/' in x else float(x)
    m = re.search(r'([\d/]+)\s*a\s*([\d/]+)', t)
    if m: return fr(m.group(1)), '%s a %s' % (m.group(1), m.group(2))
    m = re.match(r'^at[eé]\s*([\d/]+)', t)
    if m: return 0.0, 'ate %s' % m.group(1)
    m = re.match(r'^(>|mais)\s*(de\s*)?([\d/]+)', t)
    if m: return fr(m.group(3)), 'mais de %s' % m.group(3)
    return None, None


# faixas harmonizadas: as de 2007 a 2016 (ate 160+) valem para todos os anos
HARM = [(0, 'ate 1/2'), (0.5, '1/2 a 1'), (1, '1 a 2'), (2, '2 a 3'), (3, '3 a 5'), (5, '5 a 10'),
        (10, '10 a 20'), (20, '20 a 40'), (40, '40 a 80'), (80, '80 a 160'), (160, 'mais de 160')]


def harm(lo):
    out = HARM[0][1]
    for b, nome in HARM:
        if lo >= b: out = nome
    return out


def ano_calendario(wb):
    for ws in wb.worksheets[:3]:
        for r in ws.iter_rows(values_only=True, max_row=12):
            for c in r:
                m = re.search(r'ANO[- ]CALEND[ÁA]RIO (\d{4})', str(c or ''), re.I)
                if m: return int(m.group(1))
    return None


def le_irpf(arq):
    """Devolve (ano_calendario, aba, unidade_origem, {faixa: dict}, total_publicado, colunas_usadas)."""
    wb = openpyxl.load_workbook(P(arq), read_only=True, data_only=True)
    ac = ano_calendario(wb)
    # formato C (2023+): Tab8 em colunas snake_case, R$
    if 'Tab8' in wb.sheetnames:
        ws = wb['Tab8']
        rows = list(ws.iter_rows(values_only=True))
        # formato C: cabecalho em snake_case na linha 1
        if rows[1] and rows[1][0] == 'tipo_formulario':
            h = {c: j for j, c in enumerate(rows[1])}
            fx = [c for c in rows[1] if str(c).startswith('faixa_')][0]
            cols = OrderedDict(declarantes='qtde_contribuintes', rend_tributavel='rendimento_tributavel_total',
                               rend_exclusiva='rend_sujeitos_a_tribut_exclusiva', rend_isentos='rend_isentos_e_nao_tributaveis',
                               imposto_devido='imposto_devido_total', isentos_lucros_dividendos='rend_isentos_lucros_dividendos',
                               isentos_socio_simples='rend_isentos_socio_me_simples')
            agg = defaultdict(lambda: defaultdict(float))
            nx = 0
            for r in rows[2:]:
                if not r or r[h[fx]] is None: continue
                k = r[h[fx]]
                for nome, c in cols.items():
                    if c in h:
                        v = num(r[h[c]])
                        if v is None and r[h[c]] not in (None, ''): nx += 1
                        agg[k][nome] += v or 0.0
            for k in agg:
                for nome in agg[k]:
                    if nome != 'declarantes': agg[k][nome] /= 1e6
            return ac, 'Tab8', 'R$ (convertido para R$ milhoes); %d celulas com "x" (sigilo fiscal, recortes por UF com poucos declarantes) nas colunas usadas, contadas como zero' % nx, agg, None, cols
        # formato B (2022): cabecalho legivel com tipo de formulario e UF, R$ milhoes
        for i, r in enumerate(rows[:12]):
            if r and any(str(c or '').strip() == 'Tipo de Formulário' for c in r):
                hdr = [str(c or '').strip() for c in r]
                break
        j = {n: hdr.index(n) for n in hdr if n}
        jfx = [k for n, k in j.items() if n.startswith('Faixa')][0]
        cols = OrderedDict(declarantes='Qtde Declarantes', rend_tributavel='Rendim. Tribut. Total',
                           rend_exclusiva='Rendim. Tribut. Exclus.', rend_isentos='Rendim. Isentos',
                           imposto_devido='Imposto Devido Total')
        agg = defaultdict(lambda: defaultdict(float))
        for r in rows[i + 2:]:
            if not r or r[jfx] is None or num(r[j['Qtde Declarantes']]) is None: continue
            for nome, c in cols.items():
                agg[r[jfx]][nome] += num(r[j[c]]) or 0.0
        return ac, 'Tab8', 'R$ milhoes', agg, None, cols
    # formato A (2008 a 2021): tabela 9 agregada, R$ milhoes
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        tit = [c for r in rows[:15] for c in r if isinstance(c, str) and re.search(r'Tabela 9 - Resumo.*Rendimentos Totais', c)]
        if not tit: continue
        achou = [i for i, r in enumerate(rows[:20]) if any(isinstance(c, str) and c.strip().startswith('Faixa') for c in r)]
        if not achou: continue  # aba de indice cita o titulo, mas nao tem a tabela
        i = achou[0]
        top = [str(c or '').strip() for c in rows[i]]
        sub = [str(c or '').strip() for c in rows[i + 1]]
        nomes = [t or s for t, s in zip(top, sub)]
        nomes2 = [(t + ' | ' + s) for t, s in zip(top, sub)]

        def col(*alts, onde=nomes):
            for a in alts:
                for k, n in enumerate(onde):
                    if n == a: return k
            return None
        jfx = [k for k, n in enumerate(top) if n.startswith('Faixa')][0]
        c_imp = col('Imposto Devido Total', 'Imposto Total')
        imp_nome = 'Imposto Devido Total' if c_imp is not None else 'Imposto Devido'
        if c_imp is None: c_imp = col('Imposto Devido')
        cmap = OrderedDict(declarantes=col('Qtde Declarantes'),
                           rend_tributavel=col('Rendim. Tribut.', 'Tributáveis', onde=[s or t for t, s in zip(top, sub)]),
                           rend_exclusiva=col('Rendim. Tribut. Exclus.', 'Tributação Exclusiva', onde=[s or t for t, s in zip(top, sub)]),
                           rend_isentos=col('Rendim. Isentos', 'Isentos', onde=[s or t for t, s in zip(top, sub)]),
                           imposto_devido=c_imp)
        if cmap['rend_exclusiva'] is None:
            cmap['rend_exclusiva'] = [k for k, s in enumerate(sub) if s.startswith('Tributação Exclusi')][0]
        assert all(v is not None for v in cmap.values()), (arq, cmap)
        agg, total = OrderedDict(), None
        for r in rows[i + 2:]:
            if len(r) <= jfx or r[jfx] is None: continue
            lab = str(r[jfx]).strip()
            if num(r[cmap['declarantes']]) is None: continue
            d = {n: num(r[k]) or 0.0 for n, k in cmap.items()}
            if lab.lower().startswith('total'):
                total = d
                break
            agg[lab] = d
        un = 'R$ milhoes' if any('milh' in str(c).lower() for rr in rows[:14] for c in rr if c) else '?'
        cols = OrderedDict((n, (top[k] + (' / ' + sub[k] if sub[k] and sub[k] != top[k] else ''))) for n, k in cmap.items())
        cols['imposto_devido'] = imp_nome
        return ac, ws.title, un, agg, total, cols
    raise SystemExit('sem tabela de faixa de rendimento total em ' + arq)


def parte_irpf():
    S = Saida('P-irpf-faixas.csv')
    arqs = sorted(glob.glob(P('rfb-irpf', '*.xlsx')))
    arqs = [a for a in arqs if 'rendimento-sm' not in a]
    vistos = set()
    for a in arqs:
        rel = os.path.relpath(a, AQUI)
        ac, aba, un, agg, total, cols = le_irpf(rel)
        assert ac and ac not in vistos, (rel, ac)
        vistos.add(ac)
        U = url(rel)
        exerc = ac + 1
        pag = '%s, aba %s (Grandes Numeros DIRPF %d, ano-calendario %d)' % (os.path.basename(rel), aba, exerc, ac)
        colnota = '; '.join('%s = "%s"' % (k, v) for k, v in cols.items())
        base_nota = ('faixa de rendimentos totais (tributaveis + tributacao exclusiva + isentos) em salarios minimos mensais; '
                     'unidade de origem %s; colunas: %s' % (un, colnota))
        lin = []
        for lab, d in agg.items():
            lo, nome = faixa_norm(lab)
            assert nome, (rel, lab)
            lin.append((lo, nome, lab, d))
        lin.sort(key=lambda x: x[0])
        tot = defaultdict(float)
        for _, _, _, d in lin:
            for k, v in d.items(): tot[k] += v
        if total:  # confere soma das faixas contra o total publicado
            for k in ('declarantes', 'imposto_devido', 'rend_tributavel'):
                if abs(tot[k] - total[k]) > max(1.0, 1e-4 * abs(total[k])):
                    print('AVISO soma das faixas difere do total', ac, k, tot[k], total[k])

        def emite(recorte, d, rot_pub, extra=''):
            rt = d['rend_tributavel'] + d['rend_exclusiva'] + d['rend_isentos']
            nota = base_nota + ('; faixa publicada "%s"' % rot_pub if rot_pub else '') + extra
            S.add('declarantes', ac, d['declarantes'], 'declaracoes', U, pag, nota, recorte, nd=0)
            S.add('rendimento_tributavel', ac, d['rend_tributavel'], 'R$ milhoes correntes', U, pag, nota, recorte, nd=3)
            S.add('rendimento_tributacao_exclusiva', ac, d['rend_exclusiva'], 'R$ milhoes correntes', U, pag, nota, recorte, nd=3)
            S.add('rendimento_isento', ac, d['rend_isentos'], 'R$ milhoes correntes', U, pag, nota, recorte, nd=3)
            S.add('rendimento_total', ac, rt, 'R$ milhoes correntes', U, pag, 'derivado: soma das tres colunas de rendimento. ' + nota, recorte, nd=3)
            S.add('imposto_devido', ac, d['imposto_devido'], 'R$ milhoes correntes', U, pag, nota, recorte, nd=3)
            S.add('aliquota_efetiva_sobre_rendimento_total', ac, 100 * d['imposto_devido'] / rt if rt else None, '%', U, pag,
                  'derivado: imposto devido / rendimento total. O imposto devido da declaracao nao inclui o IR retido de forma definitiva sobre a tributacao exclusiva (13o, aplicacoes, PLR, JCP), entao a razao subestima o IR total pago pelos que tem muita renda exclusiva. ' + nota, recorte, nd=3)
            S.add('pct_isento_no_rendimento_total', ac, 100 * d['rend_isentos'] / rt if rt else None, '%', U, pag, 'derivado: rendimento isento / rendimento total. ' + nota, recorte, nd=3)
            S.add('pct_dos_declarantes', ac, 100 * d['declarantes'] / tot['declarantes'], '%', U, pag, 'derivado: participacao no total de declarantes do ano', recorte, nd=3)
            S.add('pct_do_rendimento_total', ac, 100 * rt / (tot['rend_tributavel'] + tot['rend_exclusiva'] + tot['rend_isentos']), '%', U, pag, 'derivado: participacao no rendimento total declarado no ano', recorte, nd=3)
            S.add('pct_do_imposto_devido', ac, 100 * d['imposto_devido'] / tot['imposto_devido'], '%', U, pag, 'derivado: participacao no imposto devido do ano', recorte, nd=3)
            if 'isentos_lucros_dividendos' in d:
                S.add('isento_lucros_dividendos', ac, d['isentos_lucros_dividendos'], 'R$ milhoes correntes', U, pag, nota, recorte, nd=3)
                S.add('isento_socio_simples', ac, d.get('isentos_socio_simples'), 'R$ milhoes correntes', U, pag, nota, recorte, nd=3)

        for lo, nome, lab, d in lin:
            emite('publicada: ' + nome, d, lab)
        # harmonizadas
        hz = OrderedDict((n, defaultdict(float)) for _, n in HARM)
        comp = defaultdict(list)
        for lo, nome, lab, d in lin:
            h = harm(lo)
            comp[h].append(nome)
            for k, v in d.items(): hz[h][k] += v
        for n, d in hz.items():
            if not comp[n]: continue
            emite('harmonizada: ' + n, d, None, '; faixa harmonizada (limites de 2007 a 2016) = soma de: ' + ' + '.join(comp[n]))
        emite('Total', tot, None, '; soma de todas as faixas' + ('; confere com a linha Total publicada' if total else ''))
    S.grava()


# ============================================================ 3. previdencia
def parte_previdencia():
    S = Saida('P-previdencia-regimes.csv')
    # 3a. RGPS: BEPS dez/2025, quadro 14
    arq = 'prev/beps122025.pdf'
    U = url(arq)
    d = pymupdf.open(P(arq))
    pg = [i for i, p in enumerate(d) if 'EVOLUÇÃO DOS BENEFÍCIOS EMITIDOS PELO INSS POR GRANDES GRUPOS DE ESPÉCIE' in p.get_text() and i > 0][0]
    words = d[pg].get_text('words')
    linhas = defaultdict(list)
    for w in words:
        linhas[round(w[1])].append((w[0], w[4]))
    seq = [' '.join(t for _, t in sorted(linhas[y])) for y in sorted(linhas)]
    # junta rotulo de mes isolado (ex. "Novembro(1)") com a linha numerica seguinte
    ano = None
    dez = {}
    tot_ano = {}
    for i, s in enumerate(seq):
        m = re.match(r'^(\d{4}) (.*)$', s)
        if m and not re.match(r'^\d{4}$', s):
            ano, s = int(m.group(1)), m.group(2)
        nums = re.findall(r'-?[\d.]+,\d+|-?\d{1,3}(?:\.\d{3})+|\b\d+\b', s)
        if s.startswith('Dezembro') and len(nums) >= 12:
            dez[ano] = [num(x) for x in nums[:12]]
        if s.startswith(('Total', 'Subtotal')) and ano:
            vals = [num(x) for x in re.findall(r'\d{1,3}(?:\.\d{3})+', s)]
            if len(vals) == 4: tot_ano[ano] = vals
    pag = 'BEPS vol. 30 n. 12 (dez/2025), quadro 14, pagina %d do PDF' % (pg + 1)
    nb = 'beneficios emitidos pelo INSS em dezembro de cada ano (estoque). RGPS = previdenciarios e acidentarios; Assistencial = BPC/LOAS e RMV; BLE = encargos previdenciarios da Uniao. Valores nominais do mes, sem 13o'
    for a in sorted(dez):
        q_t, q_r, q_a, q_b, v_t, v_r, v_a, v_b, m_t, m_r, m_a, m_b = dez[a]
        for reg, q, v, m in (('RGPS (INSS)', q_r, v_r, m_r), ('Assistencial (BPC/LOAS e RMV)', q_a, v_a, m_a), ('INSS total', q_t, v_t, m_t)):
            S.add('beneficios_emitidos_dez', a, q, 'beneficios', U, pag, nb, reg, nd=0)
            S.add('valor_emitido_dez', a, v, 'R$ correntes no mes', U, pag, nb, reg, nd=2)
            S.add('valor_medio_beneficio_dez', a, m, 'R$ correntes por mes', U, pag, nb, reg, nd=2)
    for a, (vt, vr, va, vb) in sorted(tot_ano.items()):
        S.add('valor_emitido_ano', a, vr, 'R$ correntes no ano', U, pag, 'soma dos 12 meses do ano, inclui o abono anual (13o) pago em abril e maio. RGPS', 'RGPS (INSS)', nd=0)
        q = dez.get(a, [None] * 2)[1]
        if q:
            S.add('valor_anual_por_beneficio', a, vr / q, 'R$ correntes por ano', U, pag,
                  'derivado: valor emitido no ano (inclui 13o) / beneficios RGPS emitidos em dezembro. Conta beneficio, nao pessoa: em dez/2024 havia 30,2 milhoes de pessoas com beneficio RGPS ou EPU para 34,4 milhoes de beneficios (AEPS 2024, 26.4, ver G-beneficiarios)', 'RGPS (INSS)', nd=2)

    # 3b. RPPS civil da Uniao: AEPS 2024, suplemento RPPS (2-uniao.zip)
    zarq = 'prev/2-uniao.zip'
    Uz = url(zarq)
    z = zipfile.ZipFile(P(zarq))

    def wbz(pedaco):
        nome = [n for n in z.namelist() if pedaco in n][0]
        import io
        return openpyxl.load_workbook(io.BytesIO(z.read(nome)), read_only=True, data_only=True), nome.split('/')[-1]

    def blocos(wb):
        """{(ano_avaliacao, base): {grupo: [valores por coluna]}}, com cabecalho de poderes."""
        out = OrderedDict()
        rows = list(wb.worksheets[0].iter_rows(values_only=True))
        cur = None
        for i, r in enumerate(rows):
            c0 = str(r[0] or '')
            m = re.match(r'AVALIA[ÇC][ÃA]O ATUARIAL (\d{4})', c0)
            if m:
                poderes = [str(c).strip() for c in r[1:] if c]
                base = str(rows[i + 1][0]).replace('BASE DE DADOS', '').strip()
                cur = (int(m.group(1)), base)
                out[cur] = {'_poderes': poderes}
                continue
            if cur and c0.strip() in ('SERVIDORES', 'APOSENTADOS', 'PENSIONISTAS'):
                out[cur][c0.strip()] = [num(x) for x in r[1:]]
        return out
    wq, nq = wbz('NÚMERO DE SEGURADOS - UNIÃO - CIVIL')
    wr, nr = wbz('REMUNERAÇÃO MÉDIA - UNIÃO - CIVIL')
    Q, R = blocos(wq), blocos(wr)
    for key in Q:
        aval, base = key
        mm, aa = base.split('/')
        ano_b = int(aa)
        q = Q[key]
        pod = q['_poderes']  # EXECUTIVO.. TOTAL, 3 colunas (M, F, TOTAL) cada
        idx_tot = lambda k: 3 * k + 2
        pagq = '%s (AEPS 2024, suplemento RPPS), bloco "Avaliacao atuarial %d, base de dados %s"' % (nq, aval, base)
        nota_q = 'RPPS civil da Uniao, todos os Poderes e MPU; quantitativos da base cadastral do anexo de avaliacao atuarial do PLDO %d; pessoas' % aval
        for grupo in ('APOSENTADOS', 'PENSIONISTAS', 'SERVIDORES'):
            S.add('segurados_rpps_civil_uniao', ano_b, q[grupo][idx_tot(pod.index('TOTAL'))], 'pessoas', Uz, pagq, nota_q + ' (base %s)' % base, grupo.lower(), nd=0)
        if key not in R: continue
        r = R[key]
        pagr = '%s (AEPS 2024, suplemento RPPS), bloco "Avaliacao atuarial %d, base de dados %s"' % (nr, aval, base)
        for grupo in ('APOSENTADOS', 'PENSIONISTAS'):
            soma_q = soma_v = 0.0
            ok = True
            for k, poder in enumerate(r['_poderes']):
                m_ = r[grupo][idx_tot(k)]
                n_ = q[grupo][idx_tot(pod.index(poder))]
                S.add('provento_medio_rpps_civil_uniao', ano_b, m_, 'R$ correntes por mes', Uz, pagr,
                      'remuneracao media (provento ou pensao) da base cadastral do PLDO %d, base %s, poder %s' % (aval, base, poder.lower()),
                      '%s: %s' % (grupo.lower(), poder.lower()), nd=2)
                if m_ is None or n_ is None: ok = False
                else:
                    soma_q += n_; soma_v += n_ * m_
            S.add('provento_medio_rpps_civil_uniao', ano_b, soma_v / soma_q if ok and soma_q else None, 'R$ correntes por mes', Uz,
                  pagr + ' e ' + pagq,
                  'derivado: media dos quatro poderes ponderada pelo numero de %s de cada poder (mesma base %s). Media de remuneracao do cadastro, sem 13o' % (grupo.lower(), base),
                  '%s: todos os poderes' % grupo.lower(), nd=2)

    # despesa do RREO (resultado financeiro) e despesa media por beneficiario
    wf, nf = wbz('RESULTADO FINANCEIRO - UNIÃO')
    rows = list(wf.worksheets[0].iter_rows(values_only=True))
    anos = [int(x) for x in rows[3] if isinstance(x, (int, float)) or (isinstance(x, str) and x.isdigit())]
    j0 = [k for k, x in enumerate(rows[3]) if x is not None][0]
    grupo = None
    desp = {}
    for r in rows[4:]:
        if r[0]: grupo = str(r[0]).replace('\n', ' ').strip()
        if str(r[1] or '').strip() in ('DESPESA', 'RECEITA', 'RESULTADO') and grupo:
            desp.setdefault(grupo, {})[str(r[1]).strip()] = {a: num(r[j0 + k]) for k, a in enumerate(anos)}
    nota_f = [str(r[0]) for r in rows if r[0] and str(r[0]).startswith(('Fonte', 'Nota'))]
    pagf = '%s (AEPS 2024, suplemento RPPS), linha DESPESA' % nf
    rotg = {'RPPS DOS SERVIDORES CIVIS': 'RPPS civil Uniao', 'INATIVIDADE MILITARES': 'militares inativos', 'PENSÕES MILITARES': 'pensoes militares'}
    for g, porlinha in desp.items():
        if g not in rotg: continue
        for linha, serie in (('DESPESA', 'despesa_beneficios_ano'), ('RECEITA', 'receita_contribuicoes_ano'), ('RESULTADO', 'resultado_financeiro_ano')):
            for a, v in porlinha[linha].items():
                extra = ''
                if v is None and linha == 'RESULTADO' and porlinha['RECEITA'].get(a) is not None and porlinha['DESPESA'].get(a) is not None:
                    v = porlinha['RECEITA'][a] - porlinha['DESPESA'][a]
                    extra = 'derivado: celula de resultado vazia na planilha, calculado como receita menos despesa. '
                S.add(serie, a, v / 1e6 if v is not None else None, 'R$ milhoes correntes', Uz, pagf.replace('linha DESPESA', 'linha ' + linha) + ', grupo ' + g,
                      extra + 'RREO, resultado financeiro do RPPS da Uniao (receita de contribuicoes menos despesa com beneficios; negativo = coberto pelo Tesouro). ' + ' '.join(nota_f) +
                      (' Ate 2016 as linhas de inatividade e pensoes militares repetem o mesmo valor (agregado), nao somar' if 'MILITAR' in g and a <= 2016 else ''),
                      rotg[g], nd=3)

    # militares: quantidades AEPS (2020 a 2024)
    wm, nm = wbz('NÚMERO DE SEGURADOS - UNIÃO - MILITARES')
    rows = list(wm.worksheets[0].iter_rows(values_only=True))
    bloco = None
    mil = defaultdict(dict)
    hdr = None
    for r in rows:
        c0 = str(r[0] or '').strip()
        if c0 in ('MILITARES ATIVOS DE CARREIRA', 'MILITARES ATIVOS TEMPORÁRIOS', 'MILITARES INTATIVOS', 'PENSIONISTAS'):
            bloco = c0
        elif c0 == 'Força':
            hdr = [int(x) for x in r[1:] if x]
        elif c0 == 'Total' and bloco:
            for k, a in enumerate(hdr):
                mil[bloco][a] = num(r[1 + k])
    rot = {'MILITARES INTATIVOS': 'militares inativos', 'PENSIONISTAS': 'pensionistas militares',
           'MILITARES ATIVOS DE CARREIRA': 'militares ativos de carreira', 'MILITARES ATIVOS TEMPORÁRIOS': 'militares ativos temporarios'}
    for b, ser in mil.items():
        for a, v in sorted(ser.items()):
            S.add('segurados_militares_uniao', a, v, 'pessoas', Uz, '%s (AEPS 2024, suplemento RPPS), bloco "%s", linha Total' % (nm, b),
                  'Forcas Armadas, fonte Ministerio da Defesa; o rotulo "INTATIVOS" esta assim na planilha', rot[b], nd=0)

    # despesa media anual por beneficiario (derivado)
    def get(serie, rec, a):
        for l in S.linhas:
            if l['serie'] == serie and l['recorte'] == rec and l['ano'] == a and l['valor'] != '':
                return float(l['valor'])
        return None
    for a in range(2013, 2025):
        d_ = get('despesa_beneficios_ano', 'RPPS civil Uniao', a)
        qa, qp = get('segurados_rpps_civil_uniao', 'aposentados', a), get('segurados_rpps_civil_uniao', 'pensionistas', a)
        if d_ and qa and qp:
            S.add('despesa_anual_por_beneficiario', a, d_ * 1e6 / (qa + qp), 'R$ correntes por ano', Uz, pagf + ' e ' + nq,
                  'derivado: despesa do RPPS civil no ano (RREO) / (aposentados + pensionistas da base cadastral do mesmo ano). Pessoas, inclui 13o', 'RPPS civil Uniao', nd=2)
        r_ = get('resultado_financeiro_ano', 'RPPS civil Uniao', a)
        if r_ is not None and qa and qp:
            S.add('resultado_anual_por_beneficiario', a, r_ * 1e6 / (qa + qp), 'R$ correntes por ano', Uz, pagf.replace('linha DESPESA', 'linha RESULTADO') + ' e ' + nq,
                  'derivado: resultado financeiro do RPPS civil (RREO; negativo = parte paga pelo Tesouro alem das contribuicoes de servidores e da contribuicao patronal da Uniao registrada como receita) / (aposentados + pensionistas)', 'RPPS civil Uniao', nd=2)
    for a in range(2020, 2025):
        di, dp = get('despesa_beneficios_ano', 'militares inativos', a), get('despesa_beneficios_ano', 'pensoes militares', a)
        qi, qp = mil['MILITARES INTATIVOS'].get(a), mil['PENSIONISTAS'].get(a)
        if di and dp and qi and qp:
            S.add('despesa_anual_por_beneficiario', a, (di + dp) * 1e6 / (qi + qp), 'R$ correntes por ano', Uz, pagf + ' e ' + nm,
                  'derivado: (despesa com inativos + pensoes militares no ano, RREO) / (inativos + pensionistas em dezembro, Ministerio da Defesa). Pessoas, inclui 13o', 'militares (inativos e pensionistas)', nd=2)
            S.add('despesa_anual_por_beneficiario', a, di * 1e6 / qi, 'R$ correntes por ano', Uz, pagf + ' e ' + nm,
                  'derivado: despesa com inativos militares (RREO) / inativos em dezembro', 'militares inativos', nd=2)
            S.add('despesa_anual_por_beneficiario', a, dp * 1e6 / qp, 'R$ correntes por ano', Uz, pagf + ' e ' + nm,
                  'derivado: despesa com pensoes militares (RREO) / pensionistas em dezembro', 'pensionistas militares', nd=2)
            ri, rp = get('resultado_financeiro_ano', 'militares inativos', a), get('resultado_financeiro_ano', 'pensoes militares', a)
            if ri is not None and rp is not None:
                S.add('resultado_anual_por_beneficiario', a, (ri + rp) * 1e6 / (qi + qp), 'R$ correntes por ano', Uz, pagf.replace('linha DESPESA', 'linha RESULTADO') + ' e ' + nm,
                      'derivado: resultado financeiro (inativos + pensoes militares, RREO; inativos nao tem contribuicao) / (inativos + pensionistas)', 'militares (inativos e pensionistas)', nd=2)

    # 3c. militares: provento medio, PLDO 2027 anexo IV.12 (base mai/2025)
    arq = 'prev/pldo2027-anexo-iv-12-militares.pdf'
    Um = url(arq)
    d = pymupdf.open(P(arq))
    txt, pgm = None, None
    for i, p in enumerate(d):
        t = p.get_text()
        if '3.1.2 Remunerações Médias' in t and 'Militares Inativos' in t and 'R$' in t:
            txt, pgm = t, i
    tq = '\n'.join(p.get_text() for p in d[max(0, pgm - 1):pgm + 1])
    num_br = lambda s: [num(x) for x in re.findall(r'\d{1,3}(?:\.\d{3})*,\d{2}', s)]
    int_br = lambda s: [num(x) for x in re.findall(r'(?<![\d,])\d{1,3}(?:\.\d{3})+(?![\d,])', s)]
    rem = txt.split('3.1.2 Remunerações Médias')[1]
    mi = num_br(rem.split('B) Militares Inativos')[1].split('C) Pensionistas')[0])
    mb = num_br(rem.split('d) Pensionistas Beneficiários')[1].split('4. BASES LEGAIS')[0])
    mt = num_br(rem.split('C) Pensionistas Tronco')[1].split('d) Pensionistas')[0])
    qt = tq.split('3.1.2 Remunerações Médias')[0]
    qi = int_br(qt.split('b) Militares Inativos')[1].split('c) Pensionistas')[0])
    qb = int_br(qt.split('d) Pensionistas Beneficiários')[1])
    qtr = int_br(qt.split('c) Pensionistas Tronco')[1].split('d) Pensionistas')[0])
    pagm = 'PLDO 2027, Anexo IV.12 (avaliacao atuarial do SPSMFA), item 3.1, paginas %d e %d do PDF' % (pgm, pgm + 1)
    nm_ = 'Forcas Armadas, dados correntes de maio de 2025 (item 3 do anexo); remuneracao media mensal, sem 13o'
    S.add('provento_medio_militares', 2025, mi[0], 'R$ correntes por mes', Um, pagm, nm_, 'inativos: oficiais', nd=2)
    S.add('provento_medio_militares', 2025, mi[1], 'R$ correntes por mes', Um, pagm, nm_, 'inativos: pracas', nd=2)
    S.add('segurados_militares_uniao', 2025, qi[2], 'pessoas', Um, pagm, nm_ + '; oficiais %s, pracas %s' % (fmt(qi[0], 0), fmt(qi[1], 0)), 'militares inativos (PLDO 2027)', nd=0)
    S.add('provento_medio_militares', 2025, (mi[0] * qi[0] + mi[1] * qi[1]) / (qi[0] + qi[1]), 'R$ correntes por mes', Um, pagm,
          'derivado: media de oficiais e pracas ponderada pelas quantidades do mesmo anexo. ' + nm_, 'inativos: todos', nd=2)
    S.add('provento_medio_militares', 2025, mb[0], 'R$ correntes por mes', Um, pagm, nm_ + '; pensionistas beneficiarios (pessoas que recebem)', 'pensionistas: de oficiais', nd=2)
    S.add('provento_medio_militares', 2025, mb[1], 'R$ correntes por mes', Um, pagm, nm_ + '; pensionistas beneficiarios (pessoas que recebem)', 'pensionistas: de pracas', nd=2)
    S.add('segurados_militares_uniao', 2025, qb[2], 'pessoas', Um, pagm, nm_ + '; beneficiarios de oficiais %s, de pracas %s; pensoes-tronco (instituidores) %s' % (fmt(qb[0], 0), fmt(qb[1], 0), fmt(qtr[2], 0)), 'pensionistas militares (PLDO 2027)', nd=0)
    S.add('provento_medio_militares', 2025, (mb[0] * qb[0] + mb[1] * qb[1]) / (qb[0] + qb[1]), 'R$ correntes por mes', Um, pagm,
          'derivado: media ponderada pelos beneficiarios do mesmo anexo. ' + nm_, 'pensionistas: todos', nd=2)
    S.add('provento_medio_militares', 2025, (mt[0] * qtr[0] + mt[1] * qtr[1]) / (qtr[0] + qtr[1]), 'R$ correntes por mes', Um, pagm,
          'derivado: valor medio por pensao-tronco (instituidor), ponderado. Uma pensao-tronco pode ser dividida entre varios beneficiarios. ' + nm_, 'pensoes-tronco: todas', nd=2)
    # RPPS civil 2025 (PLDO 2027): so ha medias por poder em imagem; nao transcrito
    S.add('provento_medio_rpps_civil_uniao', 2025, None, 'R$ correntes por mes', url('prev/pldo2027-anexo-iv-11-rpps-uniao.pdf'),
          'PLDO 2027, Anexo IV.11, tabelas 3 a 6', 'as medias por poder da base jul/2025 estao em imagem no PDF e nao entraram aqui; a serie do AEPS vai ate a base dez/2024', 'aposentados: todos os poderes')
    S.grava()


# ============================================================ 4. carga por base
def parte_carga():
    S = Saida('P-carga-por-base.csv')
    arq = 'rfb-ctb/tabelas-ctb-2024.xlsx'
    U = url(arq)
    wb = openpyxl.load_workbook(P(arq), read_only=True, data_only=True)
    for aba, un, mult in (('INC02A', 'R$ milhoes correntes', 1), ('INC02B', '% do PIB', 100), ('INC02C', '% da receita tributaria total', 100)):
        rows = list(wb[aba].iter_rows(values_only=True))
        tit = ' '.join(str(c) for r in rows[:3] for c in r if c)
        h = [i for i, r in enumerate(rows) if r and any(str(c).strip() == 'Cód.' for c in r)][0]
        jc = [j for j, c in enumerate(rows[h]) if str(c).strip() == 'Cód.'][0]
        jn = [j for j, c in enumerate(rows[h]) if str(c).strip() == 'Tipo de Base'][0]
        anos = {k: int(x) for k, x in enumerate(rows[h]) if isinstance(x, (int, float)) or (isinstance(x, str) and re.fullmatch(r'\d{4}', x.strip()))}
        for r in rows[h + 1:]:
            c = r[jc] if r[jc] is not None else r[jc + 1]
            if c is None or not re.fullmatch(r'\d+', str(c).strip()) or r[jn] is None: continue
            cod = int(str(c).strip())
            nome = str(r[jn]).strip()
            nivel = 'base' if cod % 1000 == 0 else ('sub-base' if cod % 100 == 0 else 'detalhe')
            for k, a in anos.items():
                v = num(r[k])
                S.add('rfb_receita_por_base', a, v * mult if v is not None else None, un, U,
                      'Carga Tributaria no Brasil 2024, planilha %s, aba %s, codigo %d' % (os.path.basename(arq), aba, cod),
                      'RFB, metodologia nova (edicao 2024, sem FGTS e Sistema S), %s; nivel %s. %s' % (tit[:120], nivel, 'Codigo 0 = total da receita tributaria' if cod == 0 else ''),
                      '%d %s' % (cod, nome), nd=6 if mult == 100 else 3)
    # STN, governo geral por especie (GFSM 2014), 2010 a 2025
    arq = 'tesouro-ctb/base-ctb-gg-2025.xlsx'
    U = url(arq)
    wb = openpyxl.load_workbook(P(arq), read_only=True, data_only=True)
    r1 = list(wb['Tabela 1'].iter_rows(values_only=True))
    h1 = [i for i, r in enumerate(r1) if r and str(r[0]).strip().startswith('Esfera')][0]
    anos = {k: int(x) for k, x in enumerate(r1[h1]) if str(x).strip().isdigit()}
    pib = [r for r in r1 if r and str(r[0]).strip() == 'PIB'][0]
    PIB = {a: num(pib[k]) for k, a in anos.items()}
    rows = list(wb['Tabela 6'].iter_rows(values_only=True))
    h = [i for i, r in enumerate(rows) if r and str(r[0]).strip() == 'Código'][0]
    anos6 = {k: int(x) for k, x in enumerate(rows[h]) if str(x).strip().isdigit()}
    ctb = {}
    for r in rows[h + 1:]:
        if r[0] is None: continue
        cod = str(r[0]).strip()
        if cod.count('.') > 0: continue  # so as especies agregadas (1, 11, 111, ..., 12)
        nome = str(r[1]).strip()
        for k, a in anos6.items():
            v = num(r[k])
            if cod == '1': ctb[a] = v
            S.add('stn_ctb_gg_por_especie', a, v, 'R$ milhoes correntes', U, 'Estimativa CTB GG 2025, aba Tabela 6, codigo %s' % cod,
                  'STN, governo geral, classificacao GFSM 2014 (impostos sobre renda, folha, propriedade, bens e servicos e comercio exterior; contribuicoes sociais a parte). Estimativa, nao dado oficial', '%s %s' % (cod, nome), nd=3)
            if v is not None and PIB.get(a):
                S.add('stn_ctb_gg_por_especie', a, 100 * v / PIB[a], '% do PIB', U, 'Estimativa CTB GG 2025, abas Tabela 6 e Tabela 1 (PIB)',
                      'derivado: valor / PIB da propria planilha', '%s %s' % (cod, nome), nd=6)
    for l in list(S.linhas):
        if l['serie'] == 'stn_ctb_gg_por_especie' and l['unidade'] == 'R$ milhoes correntes' and l['valor'] != '':
            a = l['ano']
            S.add('stn_ctb_gg_por_especie', a, 100 * float(l['valor']) / ctb[a], '% da carga total', U, l['pagina_ou_tabela'],
                  'derivado: valor / carga tributaria bruta total (codigo 1) do mesmo ano', l['recorte'], nd=6)
    S.add('rfb_receita_por_base', 2025, None, '% da receita tributaria total', 'https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/estudos/carga-tributaria',
          'Carga Tributaria no Brasil', 'a edicao com dados de 2025 ainda nao foi publicada pela RFB; para 2025 ha so a estimativa da STN (serie stn_ctb_gg_por_especie)', '0 Total da Receita Tributaria')
    S.grava()


if __name__ == '__main__':
    parte_desigualdade()
    parte_irpf()
    parte_previdencia()
    parte_carga()

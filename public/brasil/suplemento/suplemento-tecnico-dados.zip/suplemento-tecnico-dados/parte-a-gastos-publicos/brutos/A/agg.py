import csv,sys,collections
f=sys.argv[1]; key=sys.argv[2].split(',')
filt=sys.argv[3] if len(sys.argv)>3 else None
cols=["ORÇAMENTO INICIAL (R$)","ORÇAMENTO ATUALIZADO (R$)","ORÇAMENTO EMPENHADO (R$)","ORÇAMENTO REALIZADO (R$)"]
agg=collections.defaultdict(lambda:[0.0]*4)
for r in csv.DictReader(open(f,encoding='latin1'),delimiter=';'):
    if filt:
        k,v=filt.split('=')
        if r[k]!=v: continue
    kk=tuple(r[c] for c in key)
    for i,c in enumerate(cols): agg[kk][i]+=float(r[c].replace('.','').replace(',','.'))
tot=[sum(v[i] for v in agg.values()) for i in range(4)]
for kk,v in sorted(agg.items(),key=lambda x:-x[1][3]):
    print(' | '.join(kk)[:110].ljust(110), ' '.join(f"{x/1e9:10.1f}" for x in v))
print('TOTAL', ' '.join(f"{x/1e9:10.1f}" for x in tot))

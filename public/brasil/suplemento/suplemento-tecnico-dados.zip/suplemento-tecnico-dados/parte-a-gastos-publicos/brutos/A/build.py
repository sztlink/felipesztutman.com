import json,csv,os,re,sys
RAIZ=os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
B=os.path.join(RAIZ,'brutos','A','')
OUT=os.path.join(RAIZ,'A-uniao-por-funcao.csv')
F='Legislativa,Judiciária,Essencial à Justiça,Administração,Defesa Nacional,Segurança Pública,Relações Exteriores,Assistência Social,Previdência Social,Saúde,Trabalho,Educação,Cultura,Direitos da Cidadania,Urbanismo,Habitação,Saneamento,Gestão Ambiental,Ciência e Tecnologia,Agricultura,Organização Agrária,Indústria,Comércio e Serviços,Comunicações,Energia,Transporte,Desporto e Lazer,Encargos Especiais,Reserva de Contingência'.split(',')
ENC={'Refinanciamento da Dívida Interna':'841 Refinanciamento da Dívida Interna','Refinanciamento da Dívida Externa':'842 Refinanciamento da Dívida Externa',
'Serviço da Dívida Interna':'843 Serviço da Dívida Interna (juros e amortização sem rolagem)','Serviço da Dívida Externa':'844 Serviço da Dívida Externa (juros e amortização sem rolagem)',
'Transferências':'845 Outras Transferências (FPE, FPM, royalties e demais repartições constitucionais e legais)','Outros Encargos Especiais':'846 Outros Encargos Especiais','Transferências para a Educação Básica':'847 Transferências para a Educação Básica (complementação da União ao Fundeb)','FU28 - Demais Subfunções':'Demais subfunções'}
# PIB em R$ milhoes
p6784={r['D3C']:float(r['V']) for r in json.load(open(B+'sidra-6784.json'))[1:]}
q={r['D3C']:float(r['V']) for r in json.load(open(B+'sidra-1846.json'))[1:]}
PIB={}; PIBSRC={}
for y in range(2019,2026):
    if str(y) in p6784: PIB[y]=p6784[str(y)]*1e6; PIBSRC[y]='SIDRA 6784 (anual)'
    else: PIB[y]=sum(v for k,v in q.items() if k.startswith(str(y)))*1e6; PIBSRC[y]='SIDRA 1846 (soma dos 4 trimestres, preliminar)'
PIB26=sum(q[k] for k in ('202503','202504','202601','202602'))*1e6
def url(y,p,a): return f'https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio={y}&nr_periodo={p}&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%20{a}&id_ente=1'
rows=[]
def br(x): return f'{x/1e9:.1f}'.replace('.',',')
def emit(ano,est,cat,sub,val,base,pib,u,dt,nota):
    rows.append(dict(frente='A',ano=ano,estagio=est,categoria=cat,subcategoria=sub,valor_brl=f'{val:.2f}',
      pct_total=f'{100*val/base:.3f}' if base else '',pct_pib=f'{100*val/pib:.3f}' if pib else '',fonte_url=u,data_fonte=dt,nota=nota))
summary={}
for y,p,cols in [(y,6,[('liquidado','DESPESAS LIQUIDADAS ATÉ')]) for y in range(2019,2026)]+[(2026,4,[('dotacao_inicial','DOTAÇÃO INICIAL'),('dotacao_atualizada','DOTAÇÃO ATUALIZADA'),('liquidado_jan_ago','DESPESAS LIQUIDADAS ATÉ')])]:
    a1=json.load(open(B+f'rreo-{y}-{p}-a01.json'))['items']; a2=json.load(open(B+f'rreo-{y}-{p}-a02.json'))['items']
    u2=url(y,p,'02'); u1=url(y,p,'01')
    for est,col in cols:
        def g1(pat,exact=True):
            v=[i['valor'] for i in a1 if i['coluna'].startswith(col) and (i['conta']==pat if exact else re.search(pat,i['conta']))]
            return v[0] if v else 0.0
        IX=g1('DESPESAS (EXCETO INTRA-ORÇAMENTÁRIAS) (IX)')
        XII=g1(r'REFINANCIAMENTO \(XII\)',False)
        # interno/externo do refinanciamento: primeiros itens apos XII
        idx=[k for k,i in enumerate(a1) if i['coluna'].startswith(col)]
        seq=[a1[k] for k in idx]; pos=[k for k,i in enumerate(seq) if re.search(r'REFINANCIAMENTO \(XII\)',i['conta'])]
        RI=RE=0.0
        if pos:
            for i in seq[pos[0]+1:]:
                if i['conta']=='Amortização da Dívida Interna': RI=i['valor']
                if i['conta']=='Amortização da Dívida Externa': RE=i['valor']; break
        JUR=g1('JUROS E ENCARGOS DA DÍVIDA'); AMO=g1('AMORTIZAÇÃO DA DÍVIDA')
        ex=[i for i in a2 if i['rotulo'].startswith('Total das Despesas Exceto') and i['coluna'].startswith(col)]
        fun={}; subs={}; cur=None
        for i in ex:
            c=i['conta']
            if c in F: cur=c; fun[c]=i['valor']; subs[c]=[]
            elif c.startswith('DESPESAS (INTRA') or c.startswith('TOTAL') or c.startswith('DESPESAS (EXCETO'): cur=None
            elif cur: subs[cur].append((c,i['valor']))
        totA2=[i['valor'] for i in ex if i['conta'].startswith('DESPESAS (EXCETO')][0]
        refin_in_a2=sum(v for c,v in subs.get('Encargos Especiais',[]) if c.startswith('Refinanciamento'))
        # residual de refinanciamento no A2 fora de 841/842 (caso 2022)
        resid=0.0; inA2=totA2-IX>1e9
        if inA2: resid=(totA2-IX)-refin_in_a2
        base=IX; basec=IX+XII
        pib=PIB.get(y) if y<2026 else (PIB26 if est.startswith('dotacao') else None)
        dt=f'{y}-12-31' if y<2026 else ('2026-08-31' if est.startswith('liq') else '2026 (LOA, posicao do RREO jul-ago)')
        pn='' if y<2026 else (' PIB usado no pct_pib = soma dos 4 trimestres 2025T3 a 2026T2 (SIDRA 1846), aproximacao.' if est.startswith('dotacao') else ' Execucao parcial jan-ago, pct_pib nao calculado.')
        emit(y,est,'TOTAL','sem refinanciamento da dívida',IX,base,pib,u1,dt,f'RREO Anexo 1 linha IX, despesas exceto intra-orcamentarias, OFSS, todos os Poderes. Base do pct_total das linhas de funcao. % do total com refinanciamento: {100*IX/basec:.1f}.'+pn)
        emit(y,est,'TOTAL','com refinanciamento da dívida',IX+XII,basec,pib,u1,dt,f'Calculo: linha IX + linha XII (Amortizacao da divida / refinanciamento = {br(XII)} bi) do RREO Anexo 1. Base do pct_total das linhas marcadas com refinanciamento.'+pn)
        enc_sem=None
        for c in F:
            if c not in fun: continue
            v=fun[c]; nota=''
            name=c[0]+c[1:].lower() if c!='Encargos Especiais' else 'Encargos especiais'
            if c=='Reserva de Contingência':
                if est.startswith('liq') and abs(v)<1: continue
                name='Reserva de contingência'
            if c=='Encargos Especiais':
                if inA2:
                    v=v-refin_in_a2-resid; nota=f'Calculo: no RREO deste ano o refinanciamento ({br(refin_in_a2+resid)} bi) veio dentro da funcao no Anexo 2 e foi retirado aqui para manter a linha sem rolagem. '
                enc_sem=v
                nota+=f'Sem refinanciamento da divida. Com refinanciamento = {br(v+XII)} bi ({100*(v+XII)/basec:.1f}% do total com refinanciamento).'
            else:
                nota=f'% do total com refinanciamento: {100*v/basec:.2f}.'
            emit(y,est,name,'',v,base,pib,u2,dt,nota+pn)
            for sc,sv in subs[c]:
                if c=='Encargos Especiais':
                    if sc.startswith('Refinanciamento'):
                        if inA2 or abs(sv)<1e6: continue
                        emit(y,est,name,ENC[sc]+' (parcela dentro do total sem rolagem)',sv,base,pib,u2,dt,'Valor que o RREO Anexo 2 classifica na subfuncao de refinanciamento mas dentro do total sem rolagem (linha IX). Nao confundir com a rolagem da linha XII.'+pn); continue
                    nm=ENC.get(sc,sc); nt=''
                    if sc=='Serviço da Dívida Interna' and resid>1e6:
                        sv=sv-resid; nt=f'Calculo: retirados {br(resid)} bi de refinanciamento lancados nesta subfuncao no Anexo 2 (diferenca entre Anexo 2 e Anexo 1 linha XII). '
                    emit(y,est,name,nm,sv,base,pib,u2,dt,nt+f'Subfuncao de Encargos especiais. % do total com refinanciamento: {100*sv/basec:.2f}.'+pn)
                else:
                    emit(y,est,name,sc.replace(f'FU{F.index(c)+1:02d} - ',''),sv,base,pib,u2,dt,'Subfuncao conforme RREO Anexo 2 (subfuncoes menores agregadas pelo proprio Tesouro em Demais subfuncoes).'+pn)
        emit(y,est,'Encargos especiais','com refinanciamento da dívida',enc_sem+XII,basec,pib,u1,dt,'Calculo: Encargos especiais sem refinanciamento + linha XII do Anexo 1. pct_total sobre o total com refinanciamento. E este o numero dos graficos de metade do orcamento para a divida.'+pn)
        emit(y,est,'Encargos especiais','841 Refinanciamento da Dívida Interna (rolagem)',RI,basec,pib,u1,dt,'RREO Anexo 1, linha XII, amortizacao da divida interna paga com emissao de novos titulos. pct_total sobre o total com refinanciamento.'+pn)
        emit(y,est,'Encargos especiais','842 Refinanciamento da Dívida Externa (rolagem)',RE,basec,pib,u1,dt,'RREO Anexo 1, linha XII, parte externa. pct_total sobre o total com refinanciamento.'+pn)
        emit(y,est,'Referência: natureza da despesa','Juros e encargos da dívida (GND 2, todas as funções)',JUR,base,pib,u1,dt,'RREO Anexo 1. Nao somar com as funcoes, e recorte por natureza. Mede o custo de juros pago pelo orcamento.'+pn)
        emit(y,est,'Referência: natureza da despesa','Amortização da dívida sem refinanciamento (GND 6, todas as funções)',AMO,base,pib,u1,dt,'RREO Anexo 1. Amortizacao paga com recurso que nao e emissao de titulo de refinanciamento. Nao somar com as funcoes.'+pn)
        summary[(y,est)]=dict(IX=IX,XII=XII,enc=enc_sem,JUR=JUR,AMO=AMO,fun={k:fun[k] for k in fun},pib=pib)
with open(OUT,'w',newline='') as f:
    w=csv.DictWriter(f,fieldnames='frente,ano,estagio,categoria,subcategoria,valor_brl,pct_total,pct_pib,fonte_url,data_fonte,nota'.split(','))
    w.writeheader(); w.writerows(rows)
print(len(rows)); print({y:(PIB[y],PIBSRC[y]) for y in PIB}, PIB26)

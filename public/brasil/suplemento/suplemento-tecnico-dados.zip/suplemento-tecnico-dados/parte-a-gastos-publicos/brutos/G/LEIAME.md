# Frente G: beneficiados por bloco de gasto

Dois levantamentos de 17/10/2026, fonte primaria em cada linha:
- `G-beneficiarios-previdencia.csv`: INSS, BPC, Bolsa Familia, servidores ativos e inativos, seguro-desemprego e abono (BEPS, AEPS, PLDO 2027 anexos IV.11, IV.12, IV.14, MDS MI Social).
- `G-beneficiarios-servicos.csv`: saude (IBGE menos ANS), educacao (INEP), repasses (IBGE), juros (Tesouro Direto, Previc), precatorios (CJF RPV), justica (CNJ), prisoes (Senappen).

`build_absoluto.py` junta os dois em `G-beneficiarios.csv` (raiz) e leva a linha marcada "principal" para as colunas beneficiados e rs_por_beneficiado_ano dos ABSOLUTO. Nao divide por cabeca em juros (Tesouro Direto e piso) nem em linha parcial.

# Frente N: juro real longo, inflacao implicita, Selic meta e custo medio da DPF.
# Gera, na raiz gastos-publicos/:
#   N-juro-real-mensal.csv, N-juro-real-anual.csv, N-eventos-fiscais.csv
# e, dentro de brutos/N/: selic_copom.csv, medias_mandato.csv, diario_td.csv
# Brutos (baixados uma vez por baixa_N.sh, ver LEIAME.md):
#   td/precotaxatesourodireto.csv   Tesouro Transparente, Taxas dos Titulos Ofertados pelo TD
#   bcb/historicotaxasjuros.json    BCB, historico das metas Selic por reuniao do Copom
#   ibge/sidra_1737_v2266.json      IBGE SIDRA 1737, IPCA numero-indice
#   rmd/anexo/Anexo RMD_Agosto_26.xlsx  Tesouro, RMD ago/2026, anexos 4.2 e 4.3
#   eventos/*                        Planalto, Camara (dados abertos e Agencia), Senado
# Rodar de fora da pasta dos dados, com um python que tenha openpyxl:
#   cd /tmp && python3 /caminho/brutos/N/build_N.py
import csv, json, os, datetime as dt
from collections import defaultdict, Counter
import openpyxl

H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(H, '..', '..'))

URL_TD = ('https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/'
          'resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv')
URL_COPOM = 'https://www.bcb.gov.br/api/servico/sitebcb/historicotaxasjuros'
URL_COPOM_PAG = 'https://www.bcb.gov.br/controleinflacao/historicotaxasjuros'
URL_IPCA = 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'
URL_RMD = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322'
URL_RMD_PAG = 'https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8'
CONSULTA = '2026-10-18'

INICIO = dt.date(2008, 1, 1)

NTNB = 'Tesouro IPCA+ com Juros Semestrais'   # NTN-B
NTNBP = 'Tesouro IPCA+'                       # NTN-B Principal
NTNF = 'Tesouro Prefixado com Juros Semestrais'  # NTN-F
LTN = 'Tesouro Prefixado'                     # LTN
SIGLA = {NTNB: 'NTN-B', NTNBP: 'NTN-B Principal', NTNF: 'NTN-F', LTN: 'LTN'}


def presidente(d):
    if d <= dt.date(2010, 12, 31):
        return 'Lula 2'
    if d <= dt.date(2016, 5, 12):
        return 'Dilma'
    if d <= dt.date(2018, 12, 31):
        return 'Temer'
    if d <= dt.date(2022, 12, 31):
        return 'Bolsonaro'
    return 'Lula 3'


def pdate(s):
    d, m, y = s.split('/')
    return dt.date(int(y), int(m), int(d))


def num(s):
    s = (s or '').strip().replace('.', '').replace(',', '.') if s and ',' in s else (s or '').strip()
    try:
        return float(s)
    except ValueError:
        return None


def fisher(pre, real):
    return ((1 + pre / 100) / (1 + real / 100) - 1) * 100


def r(x, n=4):
    return '' if x is None else round(x, n)


def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


# ---------------------------------------------------------------- 1. Tesouro Direto (streaming)
dia = defaultdict(dict)   # data -> {(tipo, venc): taxa_compra}
dups = 0
with open(os.path.join(H, 'td', 'precotaxatesourodireto.csv'), encoding='utf-8-sig', newline='') as f:
    rd = csv.reader(f, delimiter=';')
    head = next(rd)
    assert head[:5] == ['Tipo Titulo', 'Data Vencimento', 'Data Base', 'Taxa Compra Manha', 'Taxa Venda Manha'], head
    for row in rd:
        tipo = row[0]
        if tipo not in SIGLA:
            continue
        base = pdate(row[2])
        if base < INICIO:
            continue
        venc = pdate(row[1])
        if venc <= base:
            continue
        tx = num(row[3])
        if not num(row[5]) and not num(row[6]):
            continue           # PU de compra e de venda zerados: registro sem preco (ex.: NTN-F 2021 em jan-mar/2010 com taxa 0,06)
        if tx is None or tx == 0:
            tx = num(row[4])   # taxa de compra zerada (titulo fora de oferta): usa a de venda (registrado em LEIAME)
        if tx is None or tx == 0:
            continue           # taxas reais negativas de NTN-B curtas sao validas e ficam
        k = (tipo, venc)
        if k in dia[base]:
            dups += 1
        dia[base][k] = tx


def anos(base, venc):
    return (venc - base).days / 365.25


def mais_longo(t, tipos):
    c = [(v, tp, x) for (tp, v), x in t.items() if tp in tipos]
    if not c:
        return None
    # vencimento mais longo; empate prefere o titulo com cupom (primeiro da lista)
    c.sort(key=lambda z: (z[0], -tipos.index(z[1])))
    return c[-1]


def mais_proximo(t, tipos, alvo):
    c = [(abs((v - alvo).days), v, tp, x) for (tp, v), x in t.items() if tp in tipos]
    if not c:
        return None
    c.sort(key=lambda z: (z[0], tipos.index(z[2])))
    return c[0][1:]


def interp(t, tipos, alvo, tol=730):
    """Taxa no vencimento alvo por interpolacao linear (em dias) entre os dois titulos vizinhos dos tipos dados.
    Sem vizinho dos dois lados, usa o titulo mais proximo se estiver a ate tol dias. Devolve (taxa, descricao)."""
    nos = sorted((v, x, tp) for (tp, v), x in t.items() if tp in tipos)
    if not nos:
        return None
    ab = [n for n in nos if n[0] <= alvo]
    ac = [n for n in nos if n[0] >= alvo]
    if ab and ac:
        a, b = ab[-1], ac[0]
        if a[0] == b[0]:
            return a[1], '%s %s' % (SIGLA[a[2]], a[0])
        w = (alvo - a[0]).days / (b[0] - a[0]).days
        return a[1] + w * (b[1] - a[1]), 'interp %s %s / %s %s' % (SIGLA[a[2]], a[0], SIGLA[b[2]], b[0])
    n = ab[-1] if ab else ac[0]
    if abs((n[0] - alvo).days) <= tol:
        return n[1], 'mais proximo %s %s' % (SIGLA[n[2]], n[0])
    return None


DIAS = sorted(dia)
diario = []
for d in DIAS:
    t = dia[d]
    o = {'data': d}
    b = mais_longo(t, [NTNB, NTNBP])
    p = mais_longo(t, [NTNF, LTN])
    if b:
        o['real_longo'], o['venc_b'], o['tipo_b'] = b[2], b[0], SIGLA[b[1]]
    if p:
        o['pre_longo'], o['venc_p'], o['tipo_p'] = p[2], p[0], SIGLA[p[1]]
        # par IPCA+ no mesmo vencimento do prefixado longo: interpolacao na curva NTN-B da mesma familia de cupom,
        # e na curva NTN-B inteira se a familia nao cobrir
        fam = [NTNB] if p[1] == NTNF else [NTNBP]
        q = interp(t, fam, p[0]) or interp(t, [NTNB, NTNBP], p[0])
        if q is not None:
            o['par_b_tx'], o['par_b'] = q
            o['impl'] = fisher(p[2], q[0])
    # 10 anos constantes: curva NTN-B (cupom) e curva NTN-F interpoladas em data + 10 anos
    alvo = d + dt.timedelta(days=round(3652.5))
    b10 = interp(t, [NTNB], alvo, tol=1096)
    f10 = interp(t, [NTNF], alvo, tol=1096)
    if b10:
        o['real_10'], o['venc_b10'] = b10
    if f10:
        o['pre_10'], o['venc_f10'] = f10
    if b10 and f10:
        o['impl_10'] = fisher(f10[0], b10[0])
    diario.append(o)

# ---------------------------------------------------------------- 3. Selic meta por reuniao
cop = json.load(open(os.path.join(H, 'bcb', 'historicotaxasjuros.json'), encoding='utf-8'))['conteudo']
vig = []
for c in cop:
    ini = dt.date.fromisoformat(c['DataInicioVigencia'][:10])
    fim = dt.date.fromisoformat(c['DataFimVigencia'][:10]) if c['DataFimVigencia'] else None
    vig.append((ini, fim, c['MetaSelic'], c))
vig.sort(key=lambda z: z[0])


def selic(d):
    v = None
    for ini, fim, m, _ in vig:
        if ini <= d and (fim is None or d <= fim):
            v = m
    return v


with open(os.path.join(H, 'selic_copom.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['reuniao', 'data_reuniao', 'extraordinaria', 'meta_selic_pct_aa', 'inicio_vigencia', 'fim_vigencia',
                'vies', 'selic_efetiva_anualizada_vigencia', 'presidente', 'fonte_url', 'consulta'])
    for ini, fim, m, c in sorted(vig, key=lambda z: z[3]['NumeroReuniaoCopom']):
        dr = dt.date.fromisoformat(c['DataReuniaoCopom'][:10])
        if dr < INICIO:
            continue
        w.writerow([int(c['NumeroReuniaoCopom']), dr, c['ReuniaoExtraordinaria'], m, ini, fim or '', c['Vies'],
                    c['TaxaSelicEfetivaAnualizada'] if c['TaxaSelicEfetivaAnualizada'] is not None else '',
                    presidente(dr), URL_COPOM, CONSULTA])

for o in diario:
    o['selic'] = selic(o['data'])

with open(os.path.join(H, 'diario_td.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['data', 'juro_real_longo', 'tipo_ntnb', 'vencimento_ntnb', 'prefixado_longo', 'tipo_pre',
                'vencimento_pre', 'ntnb_par_no_vencimento_pre', 'ntnb_par_taxa', 'inflacao_implicita',
                'juro_real_10a', 'nos_ntnb_10a', 'prefixado_10a', 'nos_ntnf_10a',
                'inflacao_implicita_10a', 'selic_meta', 'presidente'])
    for o in diario:
        g = o.get
        w.writerow([o['data'], r(g('real_longo')), g('tipo_b', ''), g('venc_b', ''), r(g('pre_longo')),
                    g('tipo_p', ''), g('venc_p', ''), g('par_b', ''), r(g('par_b_tx')),
                    r(g('impl')), r(g('real_10')), g('venc_b10', ''), r(g('pre_10')), g('venc_f10', ''),
                    r(g('impl_10')), r(g('selic')), presidente(o['data'])])

# ---------------------------------------------------------------- mensal
por_mes = defaultdict(list)
for o in diario:
    por_mes[(o['data'].year, o['data'].month)].append(o)
ULT = DIAS[-1]


def moda(xs):
    xs = [x for x in xs if x]
    return Counter(xs).most_common(1)[0][0] if xs else ''


def fim_mes(y, m):
    n = dt.date(y + (m == 12), m % 12 + 1, 1) - dt.timedelta(days=1)
    return min(n, dt.date.fromisoformat(CONSULTA))


FONTE_M = URL_TD + ' ; ' + URL_COPOM
with open(os.path.join(ROOT, 'N-juro-real-mensal.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['mes', 'juro_real_longo', 'vencimento_ntnb', 'tipo_ntnb', 'prefixado_longo', 'vencimento_pre',
                'tipo_pre', 'inflacao_implicita', 'juro_real_10a', 'nos_ntnb_10a_mais_frequente', 'prefixado_10a',
                'nos_ntnf_10a_mais_frequente', 'inflacao_implicita_10a', 'selic_meta_fim_mes', 'selic_meta_media_mes',
                'dias_uteis_td', 'presidente', 'fonte_url', 'consulta', 'nota'])
    for (y, m) in sorted(por_mes):
        L = por_mes[(y, m)]
        mid = dt.date(y, m, 15)
        nota = 'medias simples das taxas de compra (manha) dos dias com dado; vencimento = o mais frequente no mes'
        if (y, m) == (ULT.year, ULT.month):
            nota += '; mes parcial, dados ate %s' % ULT
        if (y, m) == (2016, 5):
            nota += '; mes de troca de governo (Dilma ate 12/05), presidente pelo dia 15'
        w.writerow(['%04d-%02d' % (y, m), r(mean([o.get('real_longo') for o in L])), moda([o.get('venc_b') for o in L]),
                    moda([o.get('tipo_b') for o in L]), r(mean([o.get('pre_longo') for o in L])),
                    moda([o.get('venc_p') for o in L]), moda([o.get('tipo_p') for o in L]),
                    r(mean([o.get('impl') for o in L])), r(mean([o.get('real_10') for o in L])),
                    moda([o.get('venc_b10') for o in L]), r(mean([o.get('pre_10') for o in L])),
                    moda([o.get('venc_f10') for o in L]), r(mean([o.get('impl_10') for o in L])),
                    selic(fim_mes(y, m)), r(mean([o['selic'] for o in L])), len(L), presidente(mid), FONTE_M,
                    CONSULTA, nota])

# ---------------------------------------------------------------- 2. custo medio DPF (RMD anexos 4.2 e 4.3) e IPCA
wb = openpyxl.load_workbook(os.path.join(H, 'rmd', 'anexo', 'Anexo RMD_Agosto_26.xlsx'), read_only=True, data_only=True)
MESES = {'Jan': 1, 'Fev': 2, 'Mar': 3, 'Abr': 4, 'Mai': 5, 'Jun': 6, 'Jul': 7, 'Ago': 8, 'Set': 9, 'Out': 10,
         'Nov': 11, 'Dez': 12}


def ym(s):
    a, b = s.strip().split('/')
    return (2000 + int(b), MESES[a])


rows = list(wb['4.2'].iter_rows(values_only=True))
hdr = rows[4]
lin = {(rw[0] or '').strip(): rw for rw in rows if rw and isinstance(rw[0], str)}
cm_dpf = {}
for j, h in enumerate(hdr):
    if isinstance(h, str) and '/' in h:
        v = lin['DPF'][j]
        if isinstance(v, (int, float)):
            cm_dpf[ym(h)] = v
rows = list(wb['4.3'].iter_rows(values_only=True))
h4, h5 = rows[4], rows[5]
lin3 = {(rw[0] or '').strip(): rw for rw in rows if rw and isinstance(rw[0], str)}
cme = {}
for j, h in enumerate(h5):          # metodologia antiga: dez/10 a dez/20, uma coluna por mes
    if isinstance(h, str) and '/' in h:
        v = lin3['DPMFi'][j]
        if isinstance(v, (int, float)):
            cme[ym(h)] = (v, 'antiga')
for j, h in enumerate(h4):          # metodologia nova (jan/21+): trincas Taxa media / Var. indexador / CME
    if isinstance(h, str) and '/' in h:
        assert (h5[j + 2] or '').strip() == 'CME', (h, h5[j + 2])
        v = lin3['DPMFi'][j + 2]
        if isinstance(v, (int, float)):
            cme[ym(h)] = (v, 'nova')

ip = {}
for x in json.load(open(os.path.join(H, 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:]:
    try:
        ip[(int(x['D3C'][:4]), int(x['D3C'][4:]))] = float(x['V'])
    except ValueError:
        pass


def ipca12(y, m):
    a, b = ip.get((y, m)), ip.get((y - 1, m))
    return (a / b - 1) * 100 if a and b else None


ult_rmd = max(cm_dpf)
anual = []
for y in range(2008, ULT.year + 1):
    L = [o for o in diario if o['data'].year == y]
    mref = (y, 12) if (y, 12) in cm_dpf else (ult_rmd if ult_rmd[0] == y else None)
    c = cm_dpf.get(mref) if mref else None
    e = cme.get(mref) if mref else None
    i = ipca12(*mref) if mref else None
    pres = Counter(presidente(o['data']) for o in L).most_common()
    nota = []
    if y == 2016:
        nota.append('ano dividido: Dilma ate 12/05, Temer depois; tratar em separado nas medias por mandato')
    if mref and mref != (y, 12):
        nota.append('custo e IPCA em 12 meses ate %02d/%d (ultimo RMD); medias TD ate %s' % (mref[1], y, ULT))
    if e is None:
        nota.append('custo de emissoes: anexo 4.3 do RMD so comeca em dez/2010')
    elif e[1] == 'nova':
        nota.append('custo de emissoes pela metodologia nova do Tesouro (jan/2021+, CME), quebra de serie')
    anual.append({
        'ano': y, 'real_longo': mean([o.get('real_longo') for o in L]), 'pre_longo': mean([o.get('pre_longo') for o in L]),
        'impl': mean([o.get('impl') for o in L]), 'real_10': mean([o.get('real_10') for o in L]),
        'pre_10': mean([o.get('pre_10') for o in L]), 'impl_10': mean([o.get('impl_10') for o in L]),
        'selic_media': mean([o['selic'] for o in L]), 'selic_fim': selic(fim_mes(y, 12)),
        'custo': c, 'cme': e[0] if e else None, 'ipca': i,
        'jri': ((1 + c / 100) / (1 + i / 100) - 1) * 100 if c is not None and i is not None else None,
        'jri_e': ((1 + e[0] / 100) / (1 + i / 100) - 1) * 100 if e and i is not None else None,
        'mref': '%02d/%d' % (mref[1], mref[0]) if mref else '',
        'pres': ' / '.join('%s (%d dias TD)' % p for p in pres), 'nota': '; '.join(nota)})

FONTE_A = ' ; '.join([URL_TD, URL_COPOM, URL_RMD + ' (RMD ago/2026, anexos 4.2 e 4.3, pagina ' + URL_RMD_PAG + ')', URL_IPCA])
with open(os.path.join(ROOT, 'N-juro-real-anual.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['ano', 'juro_real_longo_media', 'prefixado_longo_media', 'inflacao_implicita_media',
                'juro_real_10a_media', 'prefixado_10a_media', 'inflacao_implicita_10a_media', 'selic_meta_media',
                'selic_meta_fim_ano', 'custo_medio_dpf', 'custo_medio_emissoes_dpmfi', 'ipca', 'juro_real_implicito_dpf',
                'juro_real_implicito_emissoes', 'mes_referencia_custo_ipca', 'presidente', 'fontes', 'consulta', 'nota'])
    for a in anual:
        w.writerow([a['ano'], r(a['real_longo']), r(a['pre_longo']), r(a['impl']), r(a['real_10']), r(a['pre_10']),
                    r(a['impl_10']), r(a['selic_media']), a['selic_fim'], r(a['custo']), r(a['cme']), r(a['ipca']),
                    r(a['jri']), r(a['jri_e']), a['mref'], a['pres'], FONTE_A, CONSULTA, a['nota']])

# ---------------------------------------------------------------- medias por mandato
MAND = ['Lula 2', 'Dilma', 'Temer', 'Bolsonaro', 'Lula 3']
ANOS_M = {'Lula 2': [2008, 2009, 2010], 'Dilma': [2011, 2012, 2013, 2014, 2015], 'Temer': [2017, 2018],
          'Bolsonaro': [2019, 2020, 2021, 2022], 'Lula 3': list(range(2023, ULT.year + 1)), '2016 (misto)': [2016]}
with open(os.path.join(H, 'medias_mandato.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['mandato', 'periodo_td', 'juro_real_longo', 'inflacao_implicita', 'juro_real_10a',
                'inflacao_implicita_10a', 'selic_meta_media_dias_td', 'anos_dpf', 'custo_medio_dpf_media',
                'ipca_media', 'juro_real_implicito_dpf_media', 'juro_real_implicito_emissoes_media', 'nota'])
    for m in MAND + ['2016 (misto)']:
        if m == '2016 (misto)':
            L = []
        else:
            L = [o for o in diario if presidente(o['data']) == m]
        A = [a for a in anual if a['ano'] in ANOS_M[m]]
        per = '%s a %s' % (L[0]['data'], L[-1]['data']) if L else ''
        w.writerow([m, per, r(mean([o.get('real_longo') for o in L]), 2), r(mean([o.get('impl') for o in L]), 2),
                    r(mean([o.get('real_10') for o in L]), 2), r(mean([o.get('impl_10') for o in L]), 2),
                    r(mean([o['selic'] for o in L]), 2), ','.join(str(a['ano']) for a in A),
                    r(mean([a['custo'] for a in A]), 2), r(mean([a['ipca'] for a in A]), 2),
                    r(mean([a['jri'] for a in A]), 2), r(mean([a['jri_e'] for a in A]), 2),
                    'TD: media dos dias uteis pela data exata do mandato; DPF: media simples dos anos listados'
                    + ('; Lula 2 so a partir de jan/2008; emissoes so 2010 (anexo 4.3 comeca dez/2010)' if m == 'Lula 2' else '')
                    + ('; 2026 = 12m ate ' + anual[-1]['mref'] if m == 'Lula 3' else '')
                    + ('; 2016 fica fora dos mandatos na DPF; nos dados TD cada dia vai para o presidente da data'
                       if m == '2016 (misto)' else '')])

# ---------------------------------------------------------------- 4. eventos fiscais
EV = [
    ('2016-06-15', 'PEC 241/2016 (teto de gastos) apresentada pelo Executivo na Camara',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2088351'),
    ('2016-10-10', 'Camara aprova PEC 241/2016 em primeiro turno',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2088351/tramitacoes'),
    ('2016-12-15', 'Promulgacao da EC 95/2016 (teto de gastos)',
     'https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc95.htm'),
    ('2019-07-10', 'Camara aprova PEC 6/2019 (Previdencia) em primeiro turno',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2192459/tramitacoes'),
    ('2019-08-06', 'Camara aprova PEC 6/2019 em segundo turno',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2192459/tramitacoes'),
    ('2019-11-12', 'Promulgacao da EC 103/2019 (reforma da Previdencia)',
     'https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc103.htm'),
    ('2022-12-21', 'Promulgacao da EC 126/2022 (PEC da transicao)',
     'https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc126.htm'),
    ('2023-03-30', 'Anuncio do novo arcabouco fiscal pelo ministro da Fazenda',
     'https://www.camara.leg.br/noticias/949751-governo-anuncia-proposta-de-novo-arcabouco-fiscal-que-sera-enviada-ao-congresso/'),
    ('2023-04-18', 'PLP 93/2023 (arcabouco) apresentado pelo Executivo na Camara',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2357053'),
    ('2023-05-23', 'Camara aprova substitutivo ao PLP 93/2023',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2357053/tramitacoes'),
    ('2023-08-30', 'Sancao da LC 200/2023 (arcabouco fiscal)',
     'https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp200.htm'),
    ('2024-11-27', 'Pacote de corte de gastos anunciado em pronunciamento do ministro da Fazenda (noite)',
     'https://www12.senado.leg.br/noticias/materias/2024/11/28/camara-e-senado-devem-votar-corte-de-gastos-antes-do-recesso-diz-pacheco'),
    ('2024-12-17', 'Camara aprova substitutivo ao PLP 210/2024 (pacote fiscal)',
     'https://dadosabertos.camara.leg.br/api/v2/proposicoes/2473389/tramitacoes'),
]
# referencia: distribuicao da variacao t-5 -> t+5 em todos os dias da amostra (para julgar se o evento destoa)
def janela(i, k):
    if i - 5 < 0 or i + 5 >= len(diario):
        return None
    a, b = diario[i - 5].get(k), diario[i + 5].get(k)
    return (b - a) * 100 if a is not None and b is not None else None


def pct(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * len(xs)))]


REF = {}
for k in ('real_10', 'impl_10', 'real_longo'):
    v = [abs(x) for x in (janela(i, k) for i in range(len(diario))) if x is not None]
    REF[k] = (pct(v, 0.5), pct(v, 0.9))

with open(os.path.join(ROOT, 'N-eventos-fiscais.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['data', 'evento', 'presidente', 'fonte_url_evento', 'dia_td_evento', 'dia_td_antes', 'dia_td_depois',
                'juro_real_10a_antes', 'juro_real_10a_depois', 'var_juro_real_10a_pb',
                'inflacao_implicita_10a_antes', 'inflacao_implicita_10a_depois', 'var_inflacao_implicita_10a_pb',
                'prefixado_10a_antes', 'prefixado_10a_depois', 'var_prefixado_10a_pb',
                'titulo_ntnb_longo', 'juro_real_longo_antes', 'juro_real_longo_depois', 'var_juro_real_longo_pb',
                'ref_mediana_abs_var_10d_juro_real_10a_pb', 'ref_p90_abs_var_10d_juro_real_10a_pb',
                'ref_mediana_abs_var_10d_infl_impl_10a_pb', 'ref_p90_abs_var_10d_infl_impl_10a_pb',
                'selic_meta_antes', 'selic_meta_depois', 'fonte_taxas', 'consulta', 'nota'])
    for ds, ev, url in EV:
        d0 = dt.date.fromisoformat(ds)
        t0 = next(x for x in DIAS if x >= d0)
        i0 = DIAS.index(t0)
        da, dd = DIAS[i0 - 5], DIAS[i0 + 5] if i0 + 5 < len(DIAS) else None
        oa, od = diario[i0 - 5], diario[i0 + 5] if dd else {}
        # longo: o titulo NTN-B mais longo na data do evento, lido no mesmo papel nas duas pontas
        o0 = diario[i0]
        vl = o0.get('venc_b')
        tl = NTNB if o0.get('tipo_b') == 'NTN-B' else NTNBP
        rl_a, rl_d = dia[da].get((tl, vl)), dia[dd].get((tl, vl)) if dd else None

        def pb(a, b):
            return round((b - a) * 100, 1) if a is not None and b is not None else ''
        g = lambda o, k: o.get(k)
        w.writerow([ds, ev, presidente(d0), url, t0, da, dd or '',
                    r(g(oa, 'real_10')), r(g(od, 'real_10')), pb(g(oa, 'real_10'), g(od, 'real_10')),
                    r(g(oa, 'impl_10')), r(g(od, 'impl_10')), pb(g(oa, 'impl_10'), g(od, 'impl_10')),
                    r(g(oa, 'pre_10')), r(g(od, 'pre_10')), pb(g(oa, 'pre_10'), g(od, 'pre_10')),
                    '%s %s' % (SIGLA[tl], vl), r(rl_a), r(rl_d), pb(rl_a, rl_d),
                    round(REF['real_10'][0], 1), round(REF['real_10'][1], 1),
                    round(REF['impl_10'][0], 1), round(REF['impl_10'][1], 1),
                    selic(da), selic(dd) if dd else '', URL_TD, CONSULTA,
                    'antes = 5o dia com cotacao TD antes do dia do evento; depois = 5o dia depois; 10a = vertice constante'
                    ' de 10 anos por interpolacao linear nas curvas NTN-B (cupom) e NTN-F; inflacao implicita = Fisher;'
                    ' ref = variacao absoluta t-5 a t+5 em todos os dias 2008-2026 (mediana e percentil 90); pb = pontos-base'])

print('dias TD', len(DIAS), DIAS[0], DIAS[-1], 'duplicatas', dups)
print('RMD 4.2 ultimo', ult_rmd, 'IPCA ultimo', max(ip))

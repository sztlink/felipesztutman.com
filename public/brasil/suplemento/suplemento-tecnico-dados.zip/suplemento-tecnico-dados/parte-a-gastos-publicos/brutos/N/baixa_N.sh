#!/bin/bash
# Baixa os brutos da frente N (rodar uma vez; build_N.py trabalha offline sobre eles).
set -e
cd "$(dirname "$0")"
mkdir -p td rmd/anexo bcb ibge eventos
curl -sL -o td/precotaxatesourodireto.csv "https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv"
curl -sL -o ckan_td_search.json "https://www.tesourotransparente.gov.br/ckan/api/3/action/package_search?q=taxas%20tesouro%20direto&rows=5"
curl -sL -o rmd/anexo_rmd_2026_08.zip "https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322"
curl -sL -o rmd/pagina_rmd.html "https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8"
unzip -o -q rmd/anexo_rmd_2026_08.zip -d rmd/anexo
curl -sL -A "Mozilla/5.0" -o bcb/historicotaxasjuros.json "https://www.bcb.gov.br/api/servico/sitebcb/historicotaxasjuros"
curl -sL -o ibge/sidra_1737_v2266.json "https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json"
cd eventos
for p in "emc95 constituicao/emendas/emc/emc95.htm" "emc103 constituicao/emendas/emc/emc103.htm" "emc126 constituicao/emendas/emc/emc126.htm" "lcp200 leis/lcp/lcp200.htm"; do
  set -- $p; curl -sL -A "Mozilla/5.0" -o $1.htm "https://www.planalto.gov.br/ccivil_03/$2"; done
for id in 2088351 2192459 2341862 2357053 2473389 2474283; do
  curl -sL -H "Accept: application/json" -o camara_prop_$id.json "https://dadosabertos.camara.leg.br/api/v2/proposicoes/$id"
  curl -sL -H "Accept: application/json" -o camara_tram_$id.json "https://dadosabertos.camara.leg.br/api/v2/proposicoes/$id/tramitacoes"; done
curl -sL -A "Mozilla/5.0" -o camara_noticia_949751.html "https://www.camara.leg.br/noticias/949751-governo-anuncia-proposta-de-novo-arcabouco-fiscal-que-sera-enviada-ao-congresso/"
curl -sL -A "Mozilla/5.0" -o senado_pacote_2024_11_28.html "https://www12.senado.leg.br/noticias/materias/2024/11/28/camara-e-senado-devem-votar-corte-de-gastos-antes-do-recesso-diz-pacheco"
date -Iseconds > consulta.txt

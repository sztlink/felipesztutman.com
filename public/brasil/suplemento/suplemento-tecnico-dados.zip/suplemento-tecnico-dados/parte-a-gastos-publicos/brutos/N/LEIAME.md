# Frente N: juro real longo, inflação implícita, Selic e custo da dívida

Pergunta: separar com dado duas leituras, "o juro alto é causa externa da alta da dívida" e "o juro alto é o preço da credibilidade fiscal".

Consulta de todas as fontes: 18/10/2026. Nenhum número digitado à mão. Tudo sai dos arquivos desta pasta.

## Como rodar

```
./baixa_N.sh                       # baixa os brutos (uma vez)
cd /tmp && python3 gastos-publicos-brasil-dados/brutos/N/build_N.py
```

Precisa de `openpyxl` (está no site-packages do usuário, por isso não dá para usar `-I`; rodar de fora da pasta dos dados). O script é idempotente: duas rodadas seguidas dão o mesmo md5.

## Saídas

| arquivo | conteúdo |
|---|---|
| `../../N-juro-real-mensal.csv` | média mensal de 2008-01 a 2026-10 (out/2026 vai só até 15/10) |
| `../../N-juro-real-anual.csv` | médias anuais do TD, Selic, custo médio da DPF e das emissões, IPCA, juro real implícito |
| `../../N-eventos-fiscais.csv` | 13 eventos, variação de t-5 a t+5 dias com cotação |
| `diario_td.csv` | série diária que alimenta tudo (4690 dias) |
| `selic_copom.csv` | meta Selic por reunião do Copom desde jan/2008 |
| `medias_mandato.csv` | médias por mandato |

## Fontes

| bruto | URL |
|---|---|
| `td/precotaxatesourodireto.csv` | Tesouro Transparente, "Taxas dos Títulos Ofertados pelo Tesouro Direto", https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv (recurso atualizado em 16/10/2026, último dia útil no arquivo 15/10/2026) |
| `bcb/historicotaxasjuros.json` | BCB, o JSON que alimenta a página https://www.bcb.gov.br/controleinflacao/historicotaxasjuros : https://www.bcb.gov.br/api/servico/sitebcb/historicotaxasjuros (289 reuniões, última a 281ª, 16/09/2026) |
| `ibge/sidra_1737_v2266.json` | IBGE SIDRA tabela 1737, variável 2266 (número-índice), https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json (último mês set/2026) |
| `rmd/anexo/Anexo RMD_Agosto_26.xlsx` | Tesouro, Relatório Mensal da Dívida ago/2026, anexo https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322 (página https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8). Anexo 4.2 = custo médio da DPF acumulado 12 meses (dez/2005 a ago/2026); anexo 4.3 = custo médio das emissões em oferta pública da DPMFi, 12 meses (dez/2010 a ago/2026) |
| `eventos/emc95.htm`, `emc103.htm`, `emc126.htm`, `lcp200.htm` | Planalto, textos das normas com data |
| `eventos/camara_prop_*.json`, `camara_tram_*.json` | Câmara, dados abertos (data de apresentação e tramitação de PEC 241/2016, PEC 6/2019, PEC 32/2022, PLP 93/2023, PLP 210/2024, PEC 45/2024) |
| `eventos/camara_noticia_949751.html` | Agência Câmara, 30/03/2023, anúncio do arcabouço "nesta quinta-feira (30)" |
| `eventos/senado_pacote_2024_11_28.html` | Agência Senado, 28/11/2024, pacote "anunciado na noite de quarta-feira (27)" em pronunciamento |

As páginas da Fazenda e do Planalto no gov.br (notícias de 30/03/2023 e de nov/2024) devolveram "Conteúdo Restrito" ou captcha a curl e a fetch. Por isso as datas de anúncio vêm da Agência Câmara e da Agência Senado, que são fontes oficiais do Legislativo.

## Método

- **Taxa usada:** "Taxa Compra Manhã" do TD (a taxa que o investidor recebe ao comprar). Quando a taxa de compra vem 0,00 (título fora de oferta, ex.: NTN-F em 2010), o script usa a taxa de venda. Taxas reais negativas de NTN-B curtas, como em 2015 e 2019, são válidas e ficam na série. Elas não alteram o vértice longo nem o de 10 anos.
- **NTN-B longa:** o vencimento mais longo entre Tesouro IPCA+ com Juros Semestrais (NTN-B) e Tesouro IPCA+ (NTN-B Principal) na data. Educa+ e Renda+ ficam de fora. Em empate de vencimento, vale a NTN-B com cupom.
- **Prefixado longo:** o vencimento mais longo entre LTN e NTN-F.
- **Inflação implícita (longa):** Fisher, (1+pré)/(1+real)-1, com o prefixado longo contra a taxa NTN-B interpolada linearmente (em dias) no mesmo vencimento. Usa a mesma família de cupom (NTN-F contra NTN-B, LTN contra NTN-B Principal) e cai para a curva NTN-B inteira se a família não cobrir. Sem vizinho dos dois lados, usa o título mais próximo até 2 anos.
- **10 anos constantes:** vértice data+10 anos, por interpolação linear nas curvas NTN-B (cupom) e NTN-F. Sem cobertura, usa o título mais próximo até 3 anos (ex.: 2019, quando não havia NTN-F além de 2029). A coluna `nos_*` diz quais títulos entraram. É a medida usada nos eventos, porque o "mais longo" troca de papel com o tempo.
- **Médias:** a mensal é a média simples dos dias com cotação, e a anual também. As médias por mandato são calculadas sobre os dias e pela data exata (Dilma até 12/05/2016).
- **Selic meta no fim do mês:** a meta vigente no último dia do mês, pelas datas de vigência do BCB. Out/2026 é tomado em 18/10/2026.
- **Custo médio da DPF:** o valor de dezembro do anexo 4.2 (acumulado em 12 meses). Inclui a variação cambial da DPFe. Para 2026, ago/2026.
- **Custo das emissões:** o valor de dezembro do anexo 4.3, DPMFi. De dez/2010 a dez/2020 usa a metodologia antiga. De jan/2021 em diante usa a coluna CME da metodologia nova, o que é quebra de série, anotada na linha.
- **IPCA:** dez/dez pelo número-índice. Para 2026, 12 meses até ago/2026, para casar com o custo.
- **Juro real implícito:** (1+custo)/(1+IPCA)-1, para o estoque (DPF) e para as emissões.
- **2016:** fica separado nas médias por mandato da DPF, porque o ano é dividido. Nos dados TD, cada dia vai para quem governava na data.
- **Eventos:** t0 é o dia do evento, ou o próximo dia com cotação. "Antes" é a 5ª cotação anterior e "depois" a 5ª posterior. A variação está em pontos-base. Para julgar se um evento destoa, as colunas `ref_*` dão a variação absoluta t-5 a t+5 em todos os dias de 2008 a 2026: no juro real 10a, mediana 12,5 pb e percentil 90 de 36 pb; na inflação implícita 10a, mediana 14,3 pb e percentil 90 de 41,9 pb. A janela de 10 dias pega tudo o que aconteceu no período, não só o evento. Exemplos: Copom, exterior, e em 12/2024 a própria tramitação do pacote.

## Lacunas

- **Custo médio das emissões de 2008 e 2009:** vazio. O anexo 4.3 do RMD só começa em dez/2010, e o Relatório Anual da Dívida não foi baixado para esses anos.
- **Votação no Senado da PEC 6/2019 (22/10/2019) e da PEC 241 = PEC 55/2016 no Senado:** sem fonte baixada, ficaram fora. Na Câmara entraram o 1º turno da PEC 6/2019 e o 2º turno da PEC 241.
- **Notícias da Fazenda e do Planalto no gov.br:** bloqueadas, substituídas pelas agências do Legislativo (ver Fontes).
- **TD antes de 2008:** existe no arquivo (desde 2004/2005), mas está fora do recorte pedido.

Correcao 18/10/2026: registros com PU de compra e de venda zerados sao descartados. Em jan a mar/2010 a NTN-F 2021
aparecia com taxa de venda 0,06 e preco zero, o que derrubava o prefixado de 10 anos para 3% e a inflacao implicita para -3,2%.

#!/usr/bin/env python3
# Media mensal 2008 a 2025 dos beneficiados de INSS, BPC e Bolsa Familia, para trocar o denominador
# "dezembro" por "media dos 12 meses do ano" no custo por beneficiado da Frente H.
# Entradas (baixadas, listadas em mensal/downloads.tsv):
#   mensal/prev-beps122025_final.xls  BEPS dez/2025, quadro 14 (beneficios emitidos por grandes grupos, mes a mes 2008-2025)
#   mensal/misocial/misocial-stats-AAAAMM.json  MI Social (SAGI/MDS), soma nacional dos campos municipais por mes (Solr stats)
# Saida: H-beneficiarios-media-mensal.csv. Idempotente: so le os baixados e reescreve o CSV.
# Rodar com: python3 -I build_media_mensal.py   (xlrd vem do site-packages do usuario, acrescentado no fim do sys.path)
import csv, json, os, site, statistics, sys

sys.path.append(site.getusersitepackages())
import xlrd

AQUI = os.path.dirname(os.path.abspath(__file__))
MENSAL = os.path.join(AQUI, 'mensal')
ANOS = range(2008, 2026)
BEPS_URL = ('https://www.gov.br/previdencia/pt-br/assuntos/previdencia-social/Dados-estatisticos-previdencia-social-e-inss/'
            'boletins-da-previdencia-social/2025/beps122025_final.xls')
MIS_URL = 'https://aplicacoes.mds.gov.br/sagi/servicos/misocial?q=*:*&fq=anomes_s:{AAAAMM}&rows=0&wt=json&stats=true&stats.field=<campo>'
MESES = ['janeiro', 'fevereiro', 'marco', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']

def norm(s):
  s = str(s).strip().lower()
  for a, b in (('ç', 'c'), ('ã', 'a'), ('á', 'a'), ('é', 'e'), ('í', 'i'), ('ó', 'o'), ('ú', 'u')):
    s = s.replace(a, b)
  return s

# ---------- BEPS quadro 14: col 4 total, col 5 RGPS (previdenciarios urbanos+rurais, inclui acidentarios), col 6 Assistencial (BPC/LOAS + RMV)
wb = xlrd.open_workbook(os.path.join(MENSAL, 'prev-beps122025_final.xls'))
q = wb.sheet_by_name('14')
assert 'EMITIDOS' in str(q.cell_value(2, 2)).upper() and 'GRANDES GRUPOS' in str(q.cell_value(2, 2)).upper()
assert norm(q.cell_value(6, 5)) == 'rgps' and norm(q.cell_value(6, 6)) == 'assistencial'
beps = {}  # (ano, mes) -> (rgps, assistencial)
ano = None
for r in range(7, q.nrows):
  c0, c1 = q.cell_value(r, 0), norm(q.cell_value(r, 1))
  if isinstance(c0, float) or (isinstance(c0, str) and c0.strip().isdigit()):
    ano = int(float(c0))
  mes = next((i + 1 for i, m in enumerate(MESES) if c1.startswith(m)), None)
  if mes is None or ano is None or not isinstance(q.cell_value(r, 5), float):
    continue
  v = (int(q.cell_value(r, 5)), int(q.cell_value(r, 6)))
  # a linha-cabecalho de 2008 a 2011 repete dezembro antes de janeiro; tem de bater com o dezembro do bloco
  assert beps.get((ano, mes), v) == v, (ano, mes, beps[(ano, mes)], v)
  beps[(ano, mes)] = v

# BEPS dez/2020 quadro 15: Antecipacao do BPC (Lei 13.982/2020) dentro do grupo Assistencial
q15 = xlrd.open_workbook(os.path.join(MENSAL, 'prev-beps122020-final.xls')).sheet_by_name('15')
ANTEC_DEZ2020 = next(int(q15.cell_value(r, 4)) for r in range(q15.nrows) if norm(q15.cell_value(r, 0)).startswith('antecipacao do bpc'))

# ---------- MI Social: soma nacional por mes
def mis(am):
  with open(os.path.join(MENSAL, 'misocial', f'misocial-stats-{am}.json'), encoding='utf-8') as f:
    st = json.load(f)['stats']['stats_fields']
  return {k: int(v['sum']) for k, v in st.items() if v and v.get('count')}

def bf_mes(a, m):
  """familias pagas no mes pela folha do PBF/Auxilio Brasil; devolve (valor ou None, regra)"""
  s = mis(f'{a}{m:02d}')
  if s.get('qtd_total_fam_benef_pbf_ae_aer_todos_i', 0) > 0:
    # abr a dez/2020: familias do PBF pagas pelo proprio PBF, sem Auxilio Emergencial nem residual (o AE saiu por credito extraordinario)
    return s.get('qtd_familias_benef_do_pbf_sem_ae_aer_i'), 'sem_ae_aer'
  if (a, m) == (2021, 4):
    # 1a parcela do AE 2021 para familias do PBF paga em abril; liberacoes do mes (14,5 mi) contam o AE, como abril/2020 (14,2 mi contra 0,7 mi pagas pelo PBF)
    return None, 'descartado_ae2021'
  if s.get('qtd_liberacoes_pbf_i', 0) > 0:
    return s['qtd_liberacoes_pbf_i'], 'liberacoes'
  if s.get('pab_qtd_fam_benef_i', 0) > 0 and not s.get('qtd_familias_beneficiarias_bolsa_familia_i'):
    return s['pab_qtd_fam_benef_i'], 'auxilio_brasil_beneficiarias'
  return None, 'sem_dado'

def bf_rol(a, m):
  s = mis(f'{a}{m:02d}')
  return s.get('qtd_familias_beneficiarias_bolsa_familia_i') or s.get('pab_qtd_fam_benef_i')

def media(vals):
  v = [x for x in vals if x]
  return (round(statistics.fmean(v)), len(v)) if v else ('', 0)

rows = []
for a in ANOS:
  meses = range(1, 13)
  for serie, idx, nota in (
      ('inss', 0, 'beneficios previdenciarios do RGPS emitidos (urbanos + rurais, inclui acidentarios), BEPS dez/2025 quadro 14 coluna RGPS, mes a mes'),
      ('bpc', 1, 'beneficios assistenciais emitidos (BPC/LOAS idoso + pessoa com deficiencia + RMV), BEPS dez/2025 quadro 14 coluna Assistencial, mes a mes; '
                 'mesmo conceito da serie dezembro (BPC+RMV, linha RTN 2.3.5)')):
    vals = [beps.get((a, m), (None, None))[idx] for m in meses]
    mm, n = media(vals)
    extra = ''
    if serie == 'bpc':
      bpc_so, nb = media([mis(f'{a}{m:02d}').get('bpc_ben_i') for m in meses])
      extra = f'. Sem RMV (so idoso+PcD), MI Social bpc_ben_i: media {bpc_so} ({nb} meses)'
      if a in (2020, 2021):
        extra += (f'. ATENCAO: de abr/2020 a 2021 o grupo Assistencial inclui a Antecipacao do BPC (Lei 13.982/2020), {ANTEC_DEZ2020} em dez/2020 '
                  '(BEPS dez/2020 quadro 15, mensal/prev-beps122020-final.xls); a serie dezembro atual (AEPS tabela 1.10) nao a inclui')
    rows.append([serie, a, mm, n, beps.get((a, 12), (None, None))[idx] or '', BEPS_URL, nota + extra])

  regras = [bf_mes(a, m) for m in meses]
  mm, n = media([v for v, _ in regras])
  dez = regras[11][0] or ''
  rol, nr = media([bf_rol(a, m) for m in meses])
  faltam = [MESES[i][:3] for i, (v, _) in enumerate(regras) if not v]
  usadas = sorted({r for v, r in regras if v})
  nota = (f'familias com pagamento no mes pela folha do Bolsa Familia/Auxilio Brasil, soma municipal do MI Social (SAGI/MDS); campos: {", ".join(usadas)}'
          + (f'; meses sem dado: {", ".join(faltam)}' if faltam else '')
          + f'. Rol de familias beneficiarias (inclui bloqueadas), media {rol} ({nr} meses)')
  if a == 2020:
    lib, nl = media([mis(f'2020{m:02d}').get('qtd_liberacoes_pbf_i') for m in meses])
    nota += (f'. 2020: jan a mar liberacoes do PBF; abr a dez qtd_familias_benef_do_pbf_sem_ae_aer_i (familias pagas pelo proprio PBF, sem AE nem AE residual), '
             f'porque o AE (credito extraordinario, fora da linha RTN do PBF) substituiu o PBF para quem recebia mais no AE. '
             f'O campo de liberacoes do PBF em 2020 oscila entre 0,7 mi e 14 mi (conta o AE em abr, jul, set, out, dez); media dele tal como vem: {lib} ({nl} meses). '
             f'O dezembro da serie atual ({mis("202012")["qtd_liberacoes_pbf_i"]}) e esse campo de liberacoes, entao conta familias pagas pelo AE residual')
  if a == 2021:
    nota += ('. 2021: jan a out PBF liberacoes (mai a out ja sem as familias pagas pelo AE 2021, que substituiu o PBF para quem recebia mais nele); '
             f'abr descartado porque as liberacoes do mes ({mis("202104")["qtd_liberacoes_pbf_i"]}) incluem a 1a parcela do AE 2021; nov e dez Auxilio Brasil, familias beneficiarias '
             '(o MI Social nao traz pagas do AB), mesmo conceito do dezembro da serie atual')
  if a == 2022 or a == 2023:
    nota += ('. Auxilio Brasil (nov/2021 a fev/2023): familias beneficiarias (pab_qtd_fam_benef_i), o MI Social nao traz familias pagas; '
             'beneficiarias ficam 1% a 2% acima das pagas nos anos PBF recentes')
  rows.append(['bolsa_familia', a, mm, n, dez, MIS_URL, nota])

with open(os.path.join(AQUI, 'H-beneficiarios-media-mensal.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['serie', 'ano', 'media_mensal', 'meses_com_dado', 'valor_dez', 'fonte_url', 'nota'])
  w.writerows(rows)

# conferencia contra a serie dezembro atual (INSS da serie atual + acidentarios, como faz build_historico.py)
import re
atual = {}
with open(os.path.join(AQUI, 'H-beneficiarios-historico-previdencia.csv'), newline='', encoding='utf-8') as f:
  for r in csv.DictReader(f):
    if r['serie'] in ('inss', 'bpc', 'bolsa_familia') and r['beneficiarios'].strip():
      v = int(r['beneficiarios'])
      if r['serie'] == 'inss':
        v += int(re.search(r'sem acidentarios \((\d+)\)', r['nota']).group(1))
      atual[(r['serie'], int(r['ano']))] = v
print(f'{"serie":14} ano  media       dez_mesma_fonte dez_serie_atual  media/dez-1')
for s, a, mm, n, dez, _, _ in rows:
  print(f'{s:14} {a} {mm:>11} {dez:>11} {atual.get((s, a), ""):>15}  {(mm / dez - 1) * 100 if dez else 0:+6.2f}%  ({n} meses)')

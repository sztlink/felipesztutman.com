#!/usr/bin/env python3
# Serie historica 2008 a 2025: gasto da Uniao por bloco (RTN tab 2.5, valor pago, R$ correntes),
# juros nominais apropriados (BCB, competencia), deflacionados pelo IPCA para R$ de 2025, por habitante e por beneficiado.
# Entradas: brutos/D/seriehistoricaago26.xlsx e os CSVs H-beneficiarios-historico-*.csv dos agentes.
import csv, glob, json, os, openpyxl

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.join(AQUI, '..', '..')
ANOS = list(range(2008, 2026))
RTN_URL = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'

wb = openpyxl.load_workbook(os.path.join(RAIZ, 'brutos', 'D', 'seriehistoricaago26.xlsx'), read_only=True, data_only=True)
linhas = list(wb['2.5'].iter_rows(values_only=True))
cab = linhas[4]
col = {int(c): i for i, c in enumerate(cab) if isinstance(c, (int, float)) or (isinstance(c, str) and c.isdigit())}

def L(codigo):
  # linha da tabela 2.5 pelo codigo inicial (ex.: '2.4.1.3 '), R$ bi por ano
  for r in linhas[5:]:
    if r[0] and str(r[0]).strip().startswith(codigo.strip() + ' ') or (r[0] and str(r[0]).strip() == codigo.strip()):
      return {a: float(r[col[a]] or 0) / 1000 for a in ANOS}
  raise KeyError(codigo)

def soma(*partes):
  return {a: sum(s * p[a] for s, p in partes) for a in ANOS}

P = lambda c: (1, L(c))
M = lambda c: (-1, L(c))
BLOCOS = [
  ('inss', 'Aposentadorias e pensoes do INSS', soma(P('2.1'))),
  ('repasses', 'Repasses a estados e municipios', soma(P('1.'))),
  # creditos extraordinarios (2.3.7 = memorando m.) voltam para a area: Bolsa Familia, saude e educacao; o resto fica em demais obrigatorias
  ('saude', 'Saude (sem pessoal)', soma(P('2.4.1.3'), P('2.4.2.1'), P('m.1.3'), P('m.2.1'))),
  ('servidores_ativos', 'Servidores e militares na ativa', soma(P('2.2'), M('2.2.3'), M('2.2.4'))),
  ('servidores_inativos', 'Aposentados e pensionistas da Uniao', soma(P('2.2.3'), P('2.2.4'))),
  ('bolsa_familia', 'Bolsa Familia', soma(P('2.4.1.2'), P('m.1.2'))),
  ('bpc', 'BPC', soma(P('2.3.5'))),
  ('maquina', 'Resto da maquina e investimentos do Executivo', soma(P('2.4.2'), M('2.4.2.1'), M('2.4.2.2'))),
  ('demais_obrigatorias', 'Demais despesas obrigatorias', soma(P('2.3'), M('2.3.1'), M('2.3.5'), M('2.3.10'), M('2.3.14'), P('2.4.1.1'), P('2.4.1.5'),
                                                                M('m.1.2'), M('m.1.3'), M('m.2.1'), M('m.1.4'), M('m.2.2'))),
  ('educacao', 'Educacao (sem pessoal)', soma(P('2.4.1.4'), P('2.4.2.2'), P('2.3.10'), P('m.1.4'), P('m.2.2'))),
  ('seguro_desemprego_abono', 'Seguro-desemprego e abono', soma(P('2.3.1'))),
  ('precatorios', 'Precatorios fora de beneficios e pessoal', soma(P('2.3.14'))),
]

def grava(nome, cab, rows):
  with open(os.path.join(RAIZ, nome), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(cab); w.writerows(rows)

rows = [[k, nome, a, round(v[a], 4), 'RTN tab 2.5 valor pago', RTN_URL] for k, nome, v in BLOCOS for a in ANOS]
grava('H-gasto-uniao-historico.csv', ['bloco_id', 'bloco', 'ano', 'valor_rs_bi_correntes', 'regua', 'fonte'], rows)
print('blocos ok', {k: round(v[2025], 1) for k, _, v in BLOCOS})

# --- series dos agentes (H-beneficiarios-historico-*.csv)
S = {}
for arq in glob.glob(os.path.join(AQUI, 'H-beneficiarios-historico-*.csv')):
  with open(arq, newline='', encoding='utf-8') as f:
    for r in csv.DictReader(f):
      if r['beneficiarios'].strip():
        S.setdefault(r['serie'], {})[int(r['ano'])] = float(r['beneficiarios'])
# matriculas 2025: basica 2025 + superior federal 2024 (Censo Superior 2025 ainda nao saiu), igual ao ponto G
if 2025 not in S['matriculas_educacao']:
  S['matriculas_educacao'][2025] = S['basica_publica'][2025] + S['superior_federal'][2024]

# INSS: o RTN "Beneficios Previdenciarios" inclui os acidentarios; o agente contou sem eles e deixou o numero na nota
import re
with open(os.path.join(AQUI, 'H-beneficiarios-historico-previdencia.csv'), newline='', encoding='utf-8') as f:
  for r in csv.DictReader(f):
    if r['serie'] == 'inss' and r['beneficiarios'].strip():
      S['inss'][int(r['ano'])] += int(re.search(r'sem acidentarios \((\d+)\)', r['nota']).group(1))
# INSS, BPC e Bolsa Familia: o denominador passa a ser a media dos 12 meses (H-beneficiarios-media-mensal.csv); o mes de referencia fica em *_dez
with open(os.path.join(AQUI, 'H-beneficiarios-media-mensal.csv'), newline='', encoding='utf-8') as f:
  for r in csv.DictReader(f):
    S[r['serie'] + '_dez'] = S.get(r['serie'] + '_dez', {}); S[r['serie'] + '_dez'][int(r['ano'])] = S[r['serie']].get(int(r['ano']))
    S[r['serie']][int(r['ano'])] = float(r['media_mensal'])
IPCA = S['ipca_indice_dez']
POP = S['populacao']
real = lambda v, a: v * IPCA[2025] / IPCA[a]  # R$ de dez/2025 pelo IPCA dez a dez (fluxo do ano, aproximacao)

BLOCOS.insert(1, ('juros', 'Juros da divida, nominais apropriados (BCB, Governo Federal)', {a: S['juros_gf'][a] / 1000 for a in ANOS}))
DENOM = {'inss': 'inss', 'bpc': 'bpc', 'bolsa_familia': 'bolsa_familia', 'seguro_desemprego_abono': 'seguro_desemprego_abono',
         'servidores_ativos': 'servidores_ativos', 'servidores_inativos': 'servidores_inativos',
         'saude': 'sus_dependentes', 'educacao': 'matriculas_educacao'}
UNID = {'inss': 'por beneficio', 'bpc': 'por beneficio', 'bolsa_familia': 'por familia', 'seguro_desemprego_abono': 'por beneficio',
        'servidores_ativos': 'por pessoa', 'servidores_inativos': 'por pessoa', 'saude': 'por pessoa so SUS', 'educacao': 'por matricula'}

longo = []
for k, nome, v in BLOCOS:
  for a in ANOS:
    vr = real(v[a], a)
    hab = vr * 1e9 / POP[a]
    d = S.get(DENOM.get(k, ''), {}).get(a)
    longo.append([k, nome, a, round(v[a], 2), round(vr, 2), round(hab), int(d) if d else '', round(vr * 1e9 / d) if d else ''])
grava('H-por-cabeca-historico.csv', ['bloco_id', 'bloco', 'ano', 'valor_rs_bi_correntes', 'valor_rs_bi_2025', 'rs_2025_por_habitante',
                                     'beneficiados', 'rs_2025_por_beneficiado'], longo)

# presidente por ano civil; 2016 e o ano da troca (Dilma afastada em 12/05, Temer depois)
PRES = [(2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'), (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'), (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]
pres = lambda a: next(n for i, f, n in PRES if i <= a <= f)
def largo(nome, idx, ids, rotulo):
  cab = ['ano', 'ano_presidente'] + [rotulo(k) for k in ids]
  rows = [[a, f'{a} {pres(a)}'] + [next(l[idx] for l in longo if l[0] == k and l[2] == a) for k in ids] for a in ANOS]
  grava(nome, cab, rows)

ROT = {k: n for k, n, _ in BLOCOS}
CURTO = {'inss': 'INSS', 'juros': 'Juros', 'repasses': 'Repasses a estados e municipios', 'saude': 'Saude', 'servidores_ativos': 'Servidores ativos',
         'servidores_inativos': 'Aposentados da Uniao', 'bolsa_familia': 'Bolsa Familia', 'bpc': 'BPC', 'maquina': 'Resto da maquina',
         'demais_obrigatorias': 'Demais obrigatorias', 'educacao': 'Educacao', 'seguro_desemprego_abono': 'Seguro-desemprego e abono',
         'precatorios': 'Precatorios'}
todos = [k for k, _, _ in BLOCOS]
largo('H-largo-rs-bi-2025.csv', 4, todos, lambda k: CURTO[k])
largo('H-largo-por-habitante.csv', 5, todos, lambda k: CURTO[k])
largo('H-largo-por-beneficiado.csv', 7, list(DENOM), lambda k: f'{CURTO[k]} ({UNID[k]})')
print('historico ok')

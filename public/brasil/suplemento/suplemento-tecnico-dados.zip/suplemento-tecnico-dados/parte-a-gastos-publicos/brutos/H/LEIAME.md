# Frente H: historico 2008 a 2025, por habitante e por beneficiado

- Gasto: RTN tab 2.5 (valor pago), mesmas formulas dos blocos do ABSOLUTO-uniao-2025; juros: BCB NFSP, Governo Federal, competencia.
- Deflator: IPCA dezembro a dezembro (SIDRA 1737), R$ de dez/2025. Populacao: IBGE projecao revisao 2024 (ajustada ao Censo 2022).
- Beneficiados: `H-beneficiarios-historico-previdencia.csv` (INSS sem acidentarios, BPC+RMV, Bolsa Familia liberadas, seguro-desemprego+abono do anexo FAT dos PLDOs) e `H-beneficiarios-historico-servicos.csv` (servidores BEP 2008-2014 e PLDO 2020-2025, SUS = populacao menos ANS, matriculas INEP).
- Quebras: servidores vazios 2015 a 2019 e dois conceitos (BEP conta pensao por instituidor); Bolsa Familia 2020 sem Auxilio Emergencial e 2021-2022 com beneficiarias em vez de liberadas; matricula 2025 usa superior federal de 2024; "Demais obrigatorias" 2020 e a pandemia.
- `build_historico.py` gera H-gasto-uniao-historico.csv, H-por-cabeca-historico.csv e os tres H-largo-*.csv (abas com grafico).
- Achado: a SGS 4616 e o setor publico consolidado; os R$ 867,7 bi de 2025 (Governo Federal) estavam certos, so o rotulo da fonte estava errado e foi corrigido.

## Denominador por media mensal (18/10/2026)

- `H-beneficiarios-media-mensal.csv`: media dos 12 meses de cada ano, 2008 a 2025, para INSS, BPC e Bolsa Familia, com o dezembro da mesma fonte ao lado (`valor_dez`). Gerado por `build_media_mensal.py` (rodar com `python3 -I`, idempotente, so le `mensal/`).
- INSS e BPC: BEPS dez/2025 quadro 14 (beneficios emitidos por grandes grupos, mes a mes desde 2008). Coluna RGPS = previdenciarios urbanos e rurais com acidentarios (o que `build_historico.py` usa); coluna Assistencial = BPC/LOAS + RMV, mesmo conceito da serie dezembro. Dezembros batem com a serie atual, menos BPC 2020 e 2021: o BEPS inclui a Antecipacao do BPC (112.511 em dez/2020, quadro 15 do BEPS dez/2020) e o AEPS nao.
- Bolsa Familia: MI Social (SAGI/MDS), soma nacional dos campos municipais por mes via Solr stats (`mensal/misocial/`). Familias pagas (`qtd_liberacoes_pbf_i`); Auxilio Brasil (nov/2021 a fev/2023) so tem beneficiarias (`pab_qtd_fam_benef_i`); abr a dez/2020 usa `qtd_familias_benef_do_pbf_sem_ae_aer_i` (pagas pelo PBF, sem Auxilio Emergencial), porque o campo de liberacoes conta o AE em metade dos meses.
- Lacunas Bolsa Familia: 2010 com 8 meses (jan, fev, abr, mai zerados na fonte), 2011 com 10 (mar, abr sem campo), 2014 com 11 (ago), 2021 com 11 (abr descartado, liberacoes incluem a 1a parcela do AE 2021).
- Quebra que muda conclusao: o dezembro de 2020 da serie atual (14,27 mi, liberacoes) conta familias pagas pelo AE residual; na regra "pagas pelo PBF" dez/2020 da 1,90 mi e a media do ano 4,11 mi. Em 2021 a media (9,10 mi) fica 37% abaixo do dezembro (Auxilio Brasil, 14,52 mi).
- `mensal/downloads.tsv`: url, arquivo e data de consulta de cada baixado. Leitura do XLS pede `xlrd` (instalado no site-packages do usuario).

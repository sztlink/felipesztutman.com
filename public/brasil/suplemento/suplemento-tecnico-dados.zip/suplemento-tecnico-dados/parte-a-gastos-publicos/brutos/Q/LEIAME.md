# Frente Q: resultados de educação e saúde, 2008 a 2025

Pergunta da auditoria: relacionar a despesa (frentes C e H) a resultados. Esta frente só reúne os resultados, com ano e presidente. Ela não estima efeito do gasto.

Consulta de todas as fontes: 18/10/2026. Nenhum número digitado à mão. Todos os valores saem dos arquivos desta pasta, e `downloads.tsv` lista url, arquivo e data de cada um.

## Como rodar

```
cd /tmp && python3 -I gastos-publicos-brasil-dados/brutos/Q/build_Q.py
```

Só usa a biblioteca padrão (tem leitor de xlsx próprio), por isso roda com `-I`. É idempotente: duas rodadas seguidas dão o mesmo md5.

## Saídas (raiz `gastos-publicos/`)

Colunas: `indicador, recorte, ano, ano_presidente, valor, unidade, fonte, fonte_url, arquivo_bruto, pagina_ou_tabela, nota`. Valor vazio significa não encontrado ou não aplicável, e a nota diz qual dos dois.

| arquivo | conteúdo |
|---|---|
| `Q-educacao.csv` | Ideb, nota Saeb padronizada (N), rendimento (P) e proficiência média do Saeb em matemática e português, por etapa e rede, de 2009 a 2025. PISA Brasil de 2009 a 2025. Analfabetismo 15+ |
| `Q-saude.csv` | Esperança de vida e TMI do IBGE (revisão 2024), tábuas 2022 a 2024, TMI direta e razão de mortalidade materna bruta (SIM/SINASC), cobertura vacinal PNI (TabNet até 2022, painel InfoMS de 2023 a 2025), WUENIC |
| `Q-internacional.csv` | Brasil, México, Chile, Colômbia, Argentina, Indonésia e OCDE: PISA (três médias OCDE), esperança de vida, TMI, gasto em saúde e em educação em % do PIB |

## Fontes

| bruto | origem |
|---|---|
| `inep/divulgacao_brasil_ideb_2025.zip` (+ xlsx extraído) | INEP, Ideb resultados Brasil 2005 a 2025. O certificado de download.inep.gov.br vem com a cadeia incompleta, por isso o download usou `curl -k` |
| `inep/nota_informativa_ideb_2025.pdf` (+ .txt) | INEP, nota informativa do Ideb 2025 (metodologia de 2007 mantida, comparável) |
| `inep/pisa_2022_brazil_prt.pdf`, `apresentacao_pisa_2022_brazil.pdf` | INEP/OCDE, nota do país 2022 (só referência, o build não lê) |
| `ocde/pisa2025_statlink_mrq53f.xlsx` | OCDE, PISA 2025 Results Vol. I, Annex B1 cap. 2, tabelas I.B1.2a.36 a 38 (médias por ciclo, de 2006 a 2025). O link StatLink saiu da página do anexo arquivada no Internet Archive (oecd.org devolve 403), e o xlsx baixou direto de stat.link |
| `ocde/pisa2022_statlink_*.xlsx`, `ocde/*wayback*.html` | edição 2022 e páginas do anexo, para conferência |
| `ibge/sidra_1187.json`, `sidra_7113.json`, `sidra_9543.json` | SIDRA: alfabetização 15+ PNAD 2004 a 2015 (IDS), analfabetismo 15+ PNAD Contínua 2016 a 2025, alfabetização 15+ do Censo 2022 |
| `ibge/projecoes_2024_tab4_indicadores.xlsx` + relatório metodológico | IBGE, Projeções da População revisão 2024, indicadores implícitos de 2000 a 2070 |
| `ibge/tabua_2022..2024/ambos_os_sexos.xlsx` | IBGE, tábuas completas de mortalidade publicadas |
| `datasus/*.html` | TabNet. SIM (óbitos maternos e infantis), SINASC (nascidos vivos) e PNI (cobertura). As consultas POST estão descritas em `downloads.tsv`, e os parâmetros do PNI estão em `pni_cobertura_brasil_2008_2022.html.params.txt` |
| `infoms/painel_evolucao_*.json/.png/.txt` | Painel Cobertura Vacinal Infantil (residência) do MS, aba Evolução, capturado em Chromium headless. O JSON guarda cada rótulo do gráfico com a coordenada, e o build casa o valor com o ano pelo eixo x. A tela foi salva junto. O build confere que os pontos de 2015 a 2022 batem com o TabNet e só usa 2023 a 2025 |
| `bm/wdi_*.json`, `bm/meta*_*.json` | Banco Mundial WDI, só como repasse: ONU WPP (esperança de vida), UN IGME (TMI), OMS GHED (gasto em saúde), UNESCO UIS (gasto em educação), WUENIC (vacinas) |

## Quebras e cuidados

- **Ideb/Saeb:** o INEP declara que as edições são comparáveis, inclusive a de 2025. O Ideb é N x P. Boa parte da alta de 2019 a 2025 vem de P (aprovação), e não de N. A edição de 2021 é atípica por causa da pandemia. Em 2009 os anos iniciais da rede privada só contam escolas urbanas.
- **PISA:** a "média OCDE" muda de composição entre ciclos. Para tendência, usar a OCDE-35 ou a OCDE-23. Linhas com asterisco não atenderam algum padrão amostral. Os valores passados vêm da tabela de 2025 e coincidem com os da tabela de 2022.
- **Analfabetismo:** PNAD anual até 2015 e PNAD Contínua desde 2016 são pesquisas diferentes, e há degrau entre 2015 e 2016. Faltam 2010, 2020 e 2021. O Censo 2022 dá 7,0%, contra 5,6% da PNAD Contínua no mesmo ano.
- **Esperança de vida/TMI:** a revisão 2024 refez a série inteira depois do Censo 2022. Os valores publicados nas tábuas antigas, como a de 2019, não são comparáveis e não foram lidos (formato xls). Os anos de 2000 a 2022 são estimativas e os de 2023 em diante são projeção. As tábuas de 2023 e 2024 coincidem com a projeção.
- **Mortalidade materna:** é a razão bruta do SIM/SINASC, sem o fator de correção que o MS usa na RMM oficial. Não foi encontrada série oficial corrigida em arquivo baixável. 2025 é preliminar.
- **Vacinas:** o registro mudou de agregado para nominal (de 2013 a 2019) e depois para a RNDS. Antes de 2016 as coberturas passam de 100% por causa do denominador. A Penta entrou no 2º semestre de 2012. O painel avisa que os dados de 2023 a 2025 estão sujeitos a atualização.
- **WDI:** o agregado OCDE é média ponderada nos indicadores de saúde e mediana no de educação. A série de educação da Indonésia cai de 3,6% para menos de 1% do PIB em 2019, o que indica quebra de cobertura na fonte UIS e não deve ser lido como corte. O gasto em saúde é conceito OMS/SHA e não bate com o COFOG da frente C.

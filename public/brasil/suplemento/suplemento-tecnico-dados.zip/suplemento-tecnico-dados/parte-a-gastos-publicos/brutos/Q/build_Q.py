# Frente Q: resultados de educacao e saude, 2008 a 2025, para cruzar com o gasto.
# Gera, na raiz gastos-publicos/:  Q-educacao.csv, Q-saude.csv, Q-internacional.csv
# So biblioteca padrao (leitor de xlsx proprio). Rodar de fora da pasta dos dados:
#   cd /tmp && python3 -I gastos-publicos-brasil-dados/brutos/Q/build_Q.py
# Le apenas os arquivos de brutos/Q/ listados em downloads.tsv. Idempotente.
import csv, json, os, re, zipfile, html
import xml.etree.ElementTree as ET

H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(H, '..', '..'))
CAMPOS = ['indicador', 'recorte', 'ano', 'ano_presidente', 'valor', 'unidade', 'fonte',
          'fonte_url', 'arquivo_bruto', 'pagina_ou_tabela', 'nota']


def presidente(a):
    a = int(a)
    if a <= 2002: p = 'FHC'
    elif a <= 2006: p = 'Lula 1'
    elif a <= 2010: p = 'Lula 2'
    elif a <= 2015: p = 'Dilma'
    elif a == 2016: p = 'Dilma/Temer'
    elif a <= 2018: p = 'Temer'
    elif a <= 2022: p = 'Bolsonaro'
    else: p = 'Lula 3'
    return f'{a} {p}'


def P(*a):
    return os.path.join(H, *a)


# URLs de origem (as mesmas de downloads.tsv)
U = {}
with open(P('downloads.tsv'), encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        U[r['arquivo']] = r['url'].split(' (')[0]


def url(arq):
    if arq in U: return U[arq]
    for k, v in U.items():
        if k.split('/')[0] == arq.split('/')[0] and '{' in k: return v
    raise KeyError(arq)


# ---------------- leitor xlsx (stdlib) ----------------
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}


def col2n(c):
    n = 0
    for ch in c: n = n * 26 + ord(ch) - 64
    return n - 1


def read_xlsx(path, sheets=None):
    z = zipfile.ZipFile(path)
    ss = []
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', NS):
            ss.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    rmap = {r.get('Id'): r.get('Target') for r in rels}
    out = {}
    for s in wb.find('m:sheets', NS):
        nome = s.get('name')
        if sheets and nome not in sheets: continue
        tgt = rmap[s.get('{%s}id' % NS['r'])].lstrip('/')
        if not tgt.startswith('xl/'): tgt = 'xl/' + tgt
        rows = []
        for row in ET.fromstring(z.read(tgt)).iter('{%s}row' % NS['m']):
            r = {}; last = -1
            for c in row.findall('m:c', NS):
                ref = c.get('r'); t = c.get('t'); v = c.find('m:v', NS)
                if t == 's' and v is not None: val = ss[int(v.text)]
                elif t == 'inlineStr': val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
                else: val = v.text if v is not None else None
                ci = col2n(re.match(r'[A-Z]+', ref).group()) if ref else last + 1
                r[ci] = val; last = ci
            rr = [None] * (max(r) + 1 if r else 0)
            for k, v in r.items(): rr[k] = v
            rows.append(rr)
        out[nome] = rows
    return out


def num(x):
    try: return float(x)
    except (TypeError, ValueError): return None


def fmt(v, d):
    return '' if v is None else f'{v:.{d}f}'


def linha(ind, rec, ano, valor, unid, fonte, arq, tab, nota, d=2):
    return {'indicador': ind, 'recorte': rec, 'ano': str(ano), 'ano_presidente': presidente(ano),
            'valor': fmt(valor, d) if isinstance(valor, float) else ('' if valor is None else str(valor)),
            'unidade': unid, 'fonte': fonte, 'fonte_url': url(arq), 'arquivo_bruto': 'brutos/Q/' + arq,
            'pagina_ou_tabela': tab, 'nota': nota}


EDU, SAU, INT = [], [], []

# ================= EDUCACAO =================
# --- IDEB e Saeb (INEP, divulgacao Brasil 2025) ---
ARQ_IDEB = 'inep/divulgacao_brasil_ideb_2025.zip'
X = P('inep', 'divulgacao_brasil_ideb_2025', 'divulgacao_brasil_ideb_2025.xlsx')
ideb = read_xlsx(X)
ETAPA = {'Brasil (Anos Iniciais)': 'Anos iniciais EF (5o ano)', 'Brasil (Anos Finais)': 'Anos finais EF (9o ano)',
         'Brasil (EM)': 'Ensino medio (3a serie)'}
NOTA_IDEB = ('INEP: Ideb 2025 segue a metodologia de 2007, comparavel com edicoes anteriores (nota informativa Ideb 2025); '
             'Ideb = N (nota Saeb padronizada 0 a 10) x P (indicador de rendimento, aprovacao)')
def rotulo(h, h2, h3, j):
    top = next(h[c] for c in range(j, -1, -1) if h[c])
    sub = (h2[j] if j < len(h2) and h2[j] else '') or (h3[j] if j < len(h3) and h3[j] else '')
    return (top + (' / ' + sub if sub else '')).replace('\n', ' ')


for aba, etapa in ETAPA.items():
    rows = ideb[aba]
    h, h2, h3 = rows[6], rows[7], rows[8]
    cols = {}
    for j, x in enumerate(h):
        if not isinstance(x, str): continue
        m = re.search(r'(20\d\d)', x.replace('\n', ' '))
        if not m: continue
        ano = int(m.group(1)[:4])
        if x.startswith('Taxa de Aprova'):
            k = j
            while k < len(h3) and h3[k] != 'Indicador de Rendimento (P)': k += 1
            cols[(ano, 'P')] = k
        elif x.startswith('Nota SAEB'):
            cols[(ano, 'MAT')] = j; cols[(ano, 'LP')] = j + 1; cols[(ano, 'N')] = j + 2
            assert h2[j] == 'Matemática' and h2[j + 1] == 'Língua Portuguesa' and h2[j + 2].startswith('Nota Média'), (aba, j)
        elif x.startswith('IDEB'):
            cols[(ano, 'IDEB')] = j
    for r in rows[9:]:
        if not r or r[0] != 'Brasil' or not r[1]: continue
        rede = r[1].replace(' (1)', '').strip()
        for (ano, k), j in sorted(cols.items()):
            if ano < 2008: continue
            v = num(r[j]) if j < len(r) else None
            nota = NOTA_IDEB
            if ano == 2021: nota += '; 2021: pandemia, ver nota informativa Ideb 2021 e relatorio Saeb 2021 (aprovacao e participacao atipicas)'
            if aba == 'Brasil (Anos Iniciais)' and ano == 2009 and rede == 'Privada':
                nota += '; Saeb e Ideb 2009 da rede privada so com escolas urbanas'
            spec = {'IDEB': ('IDEB', 'indice 0 a 10', 1),
                    'N': ('Saeb nota media padronizada (N)', 'indice 0 a 10', 2),
                    'P': ('Indicador de rendimento (P, aprovacao)', 'fracao 0 a 1', 3),
                    'MAT': ('Saeb proficiencia media matematica', 'pontos escala Saeb', 2),
                    'LP': ('Saeb proficiencia media lingua portuguesa', 'pontos escala Saeb', 2)}[k]
            EDU.append(linha(f'{spec[0]} - {etapa}', f'Brasil, rede {rede}', ano, v, spec[1], 'INEP, Ideb 2025 resultados Brasil',
                             ARQ_IDEB, f'divulgacao_brasil_ideb_2025.xlsx, aba "{aba}", linha Brasil {r[1]}, coluna {rotulo(h, h2, h3, j)}',
                             nota, spec[2]))

# --- PISA (OCDE, PISA 2025 Results Volume I, tabelas de tendencia) ---
ARQ_P25 = 'ocde/pisa2025_statlink_mrq53f.xlsx'
PISA_T = {'Table I.B1.2a.38': 'PISA matematica', 'Table I.B1.2a.37': 'PISA leitura', 'Table I.B1.2a.36': 'PISA ciencias'}
EMERG = {'Mexico': 'Mexico', 'Chile': 'Chile', 'Colombia': 'Colombia', 'Argentina': 'Argentina', 'Indonesia': 'Indonesia'}
OCDE_MED = {'OECD average': 'Media OCDE (paises com dado no ciclo)', 'OECD average-35': 'Media OCDE-35 (mesmos 35 paises nos ciclos)',
            'OECD average-23': 'Media OCDE-23 (mesmos 23 paises desde 2000/2003)'}
pisa = read_xlsx(P(ARQ_P25), set(PISA_T))
for aba, ind in PISA_T.items():
    rows = pisa[aba]
    hdr = rows[7]
    ycol = {int(x.split()[1]): j for j, x in enumerate(hdr) if isinstance(x, str) and re.fullmatch(r'PISA 20\d\d', x.strip())}
    for r in rows[9:]:
        if not r or not isinstance(r[0], str): continue
        nome = r[0].strip(); flag = nome.count('*'); base = nome.rstrip('*').strip()
        if base not in ('Brazil',) and base not in EMERG and base not in OCDE_MED: continue
        rec = 'Brasil' if base == 'Brazil' else EMERG.get(base) or OCDE_MED[base]
        for ano, j in sorted(ycol.items()):
            if ano < 2008: continue
            v = num(r[j])
            nota = 'escala PISA (media OCDE ~500 na escala de referencia de cada dominio)'
            if v is None: nota = 'nao disponivel na tabela ("m")'
            if flag == 1: nota += '; asterisco na tabela: algum padrao amostral do PISA nao atendido'
            if flag >= 2: nota += '; dois asteriscos: ligacao fraca com a escala internacional (ver nota da tabela)'
            if ano == 2025 and ind == 'PISA leitura': nota += '; leitura 2025: OCDE dedica anexo A1 a queda generalizada 2018-2025'
            if base == 'OECD average' and ano in (2025,): nota += '; media OCDE do ciclo muda de composicao, comparar tendencia pela OCDE-35'
            row = linha(ind, rec, ano, v, 'pontos escala PISA', 'OCDE, PISA 2025 Results (Volume I), Annex B1',
                        ARQ_P25, f'{aba} ({rows[1][0]}), linha "{nome}", coluna PISA {ano} Mean score', nota, 1)
            if rec == 'Brasil':
                EDU.append(row)
                INT.append(dict(row))
            else:
                INT.append(row)

# --- Analfabetismo 15+ (IBGE) ---
d = json.load(open(P('ibge/sidra_1187.json'), encoding='utf-8'))
anos_pnad = {}
for r in d[1:]:
    if r['D4N'] == 'Total' and r['V'] not in ('-', '...', 'X', ''):
        anos_pnad[int(r['D3N'])] = float(r['V'])
for a in range(2008, 2016):
    if a in anos_pnad:
        EDU.append(linha('Taxa de analfabetismo 15 anos ou mais', 'Brasil', a, round(100 - anos_pnad[a], 1), '% da populacao 15+',
                         'IBGE, SIDRA 1187 (Indicadores de Desenvolvimento Sustentavel, PNAD anual)', 'ibge/sidra_1187.json',
                         f'tabela 1187, variavel 2513 taxa de alfabetizacao, sexo Total; valor = 100 - {anos_pnad[a]}',
                         'derivado: 100 menos taxa de alfabetizacao; PNAD anual (encerrada em 2015), nao comparavel em nivel com PNAD Continua', 1))
    else:
        EDU.append(linha('Taxa de analfabetismo 15 anos ou mais', 'Brasil', a, None, '% da populacao 15+', 'IBGE', 'ibge/sidra_1187.json',
                         'tabela 1187', 'nao encontrado: sem PNAD no ano do Censo 2010 (Censo 2010 nao foi baixado para 15+)', 1))
d = json.load(open(P('ibge/sidra_7113.json'), encoding='utf-8'))
pc = {int(r['D3N']): float(r['V']) for r in d[1:] if r['D4N'] == 'Total' and r['D5N'] == '15 anos ou mais' and r['V'] not in ('-', '...', 'X')}
for a in range(2016, 2026):
    if a in pc:
        EDU.append(linha('Taxa de analfabetismo 15 anos ou mais', 'Brasil', a, pc[a], '% da populacao 15+',
                         'IBGE, SIDRA 7113 (PNAD Continua anual, 2a visita/educacao)', 'ibge/sidra_7113.json',
                         'tabela 7113, variavel 10267, sexo Total, grupo 15 anos ou mais', 'PNAD Continua; pesos recalibrados pelo IBGE apos Censo 2022', 1))
    else:
        EDU.append(linha('Taxa de analfabetismo 15 anos ou mais', 'Brasil', a, None, '% da populacao 15+', 'IBGE, SIDRA 7113',
                         'ibge/sidra_7113.json', 'tabela 7113', 'nao encontrado: PNAD Continua nao divulgou o modulo educacao em 2020 e 2021 (pandemia)', 1))
d = json.load(open(P('ibge/sidra_9543.json'), encoding='utf-8'))
v = float(d[1]['V'])
EDU.append(linha('Taxa de analfabetismo 15 anos ou mais (Censo)', 'Brasil', 2022, round(100 - v, 1), '% da populacao 15+',
                 'IBGE, SIDRA 9543 (Censo Demografico 2022)', 'ibge/sidra_9543.json',
                 f'tabela 9543, variavel 2513 taxa de alfabetizacao 15+, totais; valor = 100 - {v}',
                 'derivado: 100 menos alfabetizacao; Censo e PNAD Continua medem de forma diferente (autodeclaracao no domicilio em ambos, amostra vs universo)', 1))

# ================= SAUDE =================
ARQ_PROJ = 'ibge/projecoes_2024_tab4_indicadores.xlsx'
proj = read_xlsx(P(ARQ_PROJ), {'4) INDICADORES'})['4) INDICADORES']
hdr = proj[6]
ci = {k: hdr.index(k) for k in ('ANO', 'SIGLA', 'e0_T', 'e0_H', 'e0_M', 'TMI_T')}
NOTA_PROJ = ('IBGE Projecoes da Populacao revisao 2024 (ajustada ao Censo 2022): serie inteira refeita no mesmo metodo; '
             '2000 a 2022 = estimativas, 2023 em diante = projecao (relatorio metodologico, secao de metodo)')
for r in proj[7:]:
    if not r or r[ci['SIGLA']] != 'BR': continue
    a = int(r[ci['ANO']])
    if not 2008 <= a <= 2025: continue
    nota = NOTA_PROJ + ('; ano projetado' if a >= 2023 else '; ano estimado')
    for k, ind in (('e0_T', 'Esperanca de vida ao nascer'), ('e0_H', 'Esperanca de vida ao nascer - homens'), ('e0_M', 'Esperanca de vida ao nascer - mulheres')):
        SAU.append(linha(ind, 'Brasil', a, float(r[ci[k]]), 'anos', 'IBGE, Projecoes da Populacao revisao 2024, tabela 4',
                         ARQ_PROJ, f'aba "4) INDICADORES", linha BR {a}, coluna {k}', nota, 2))
    SAU.append(linha('Taxa de mortalidade infantil (IBGE, estimada)', 'Brasil', a, float(r[ci['TMI_T']]), 'obitos <1 ano por mil nascidos vivos',
                     'IBGE, Projecoes da Populacao revisao 2024, tabela 4', ARQ_PROJ, f'aba "4) INDICADORES", linha BR {a}, coluna TMI_T',
                     nota + '; corrige sub-registro de obitos e nascimentos', 2))
for a in (2022, 2023, 2024):
    arq = f'ibge/tabua_{a}/ambos_os_sexos.xlsx'
    t = read_xlsx(P(arq))
    rows = list(t.values())[0]
    r0 = [r for r in rows if r and r[0] == '0'][0]
    titulo = rows[0][0].strip()
    SAU.append(linha('Esperanca de vida ao nascer (tabua completa publicada)', 'Brasil', a, float(r0[6]), 'anos',
                     f'IBGE, Tabua Completa de Mortalidade {a}', arq, f'{titulo}, idade 0, coluna E(X)',
                     'conferencia com a serie da revisao 2024; tabuas anteriores a 2022 (formato xls) nao foram lidas', 2))
    SAU.append(linha('Probabilidade de morte 0 a 1 ano (tabua completa publicada)', 'Brasil', a, float(r0[1]), 'por mil',
                     f'IBGE, Tabua Completa de Mortalidade {a}', arq, f'{titulo}, idade 0, coluna Q(X,N) por mil',
                     'q(0) da tabua; conceito proximo, nao identico, a TMI', 2))


def tabnet(arq):
    t = open(P(arq), encoding='latin-1').read()
    return {int(a): int(v) for a, v in re.findall(r'^"(\d{4})";(\d+)', t, re.M)}, re.findall(r'Dados (?:finais|de \d{4})[^\n<]*', t)


ob_mat, notas_sim = tabnet('datasus/sim_obitos_maternos_2008_2026.html')
ob_inf, _ = tabnet('datasus/sim_obitos_infantis_2008_2026.html')
nv, notas_nv = tabnet('datasus/sinasc_nascidos_vivos_2008_2026.html')
STATUS = '; '.join(sorted(set(notas_sim)))
for a in range(2008, 2026):
    st = 'final' if a <= 2024 else 'preliminar'
    base = f'SIM/SINASC por residencia, dado {st} ({STATUS})'
    SAU.append(linha('Obitos infantis (<1 ano), contagem', 'Brasil', a, ob_inf[a], 'obitos', 'MS/SVSA, SIM via TabNet',
                     'datasus/sim_obitos_infantis_2008_2026.html', 'TabNet inf10br.def, linha Ano do Obito, Obitos p/Residenc', base))
    SAU.append(linha('Nascidos vivos, contagem', 'Brasil', a, nv[a], 'nascidos vivos', 'MS/SVSA, SINASC via TabNet',
                     'datasus/sinasc_nascidos_vivos_2008_2026.html', 'TabNet nvbr.def, linha Ano do nascimento, Nascim p/resid.mae', base))
    SAU.append(linha('Taxa de mortalidade infantil (direta SIM/SINASC)', 'Brasil', a, round(1000 * ob_inf[a] / nv[a], 2),
                     'obitos <1 ano por mil nascidos vivos', 'MS, SIM e SINASC via TabNet (calculo direto)',
                     'datasus/sim_obitos_infantis_2008_2026.html', 'obitos infantis / nascidos vivos x 1000',
                     base + '; razao direta sem correcao de sub-registro; ate 2015 fica abaixo da TMI estimada do IBGE, de 2016 em diante fica proxima ou acima (IBGE suaviza e corrige obitos e nascimentos)', 2))
    SAU.append(linha('Obitos maternos, contagem', 'Brasil', a, ob_mat[a], 'obitos', 'MS/SVSA, SIM via TabNet',
                     'datasus/sim_obitos_maternos_2008_2026.html', 'TabNet mat10br.def, linha Ano do Obito, Obitos maternos', base))
    SAU.append(linha('Razao de mortalidade materna (bruta SIM/SINASC)', 'Brasil', a, round(100000 * ob_mat[a] / nv[a], 1),
                     'obitos maternos por 100 mil nascidos vivos', 'MS, SIM e SINASC via TabNet (calculo direto)',
                     'datasus/sim_obitos_maternos_2008_2026.html', 'obitos maternos / nascidos vivos x 100000',
                     base + '; razao bruta sem fator de correcao do MS (a RMM oficial corrigida nao foi encontrada em arquivo baixavel)'
                     + ('; 2020-2021: covid-19 em gestantes e puerperas' if a in (2020, 2021) else ''), 1))

# cobertura vacinal TabNet PNI 2008-2022
t = open(P('datasus/pni_cobertura_brasil_2008_2022.html'), encoding='latin-1').read()
colsn = re.findall(r"data\.addColumn\('number','([^']+)'\)", t)
pni = {}
for ano, vals in re.findall(r'\["(\d{4})"\s*,(.*?)\]', t):
    vs = re.findall(r"\{v: ([0-9.]+) ,f: '([^']*)'\}", vals)
    pni[int(ano)] = {c: (None if f == '-' else round(float(v), 2)) for c, (v, f) in zip(colsn, vs)}
VAC = {'Penta': 'Cobertura vacinal Penta (DTP/HepB/Hib), <1 ano', 'DTP': 'Cobertura vacinal DTP (inclui combinadas), <1 ano',
       'Tríplice Viral  D1': 'Cobertura vacinal triplice viral D1, 1 ano', 'Tríplice Viral  D2': 'Cobertura vacinal triplice viral D2, 1 ano'}
NOTA_PNI = ('SI-PNI agregado ate 2012 e nominal depois; cobertura = doses / populacao alvo (SINASC), pode passar de 100%; '
            'TabNet: "nao considerar a linha TOTAL"; dados ate 2022, ultima atualizacao maio/2023')
for a in range(2008, 2023):
    for c, ind in VAC.items():
        v = pni[a][c]
        nota = NOTA_PNI
        if v is None: nota = 'vacina nao aplicada/sem registro no ano no TabNet; ' + nota
        if c == 'Penta' and a == 2012: nota += '; 2012: pentavalente introduzida no 2o semestre, cobertura do ano incompleta'
        if c == 'DTP': nota += '; serie continua de 3 doses de vacina com componente DTP (tetra ate 2012, penta depois)'
        SAU.append(linha(ind, 'Brasil', a, v, '% da populacao alvo', 'MS, SI-PNI via TabNet (cpnibr.def)',
                         'datasus/pni_cobertura_brasil_2008_2022.html', f'TabNet Imunizacoes Cobertura Brasil, Linha=Ano, coluna "{c}"', nota, 2))
# painel InfoMS 2023-2025
PAINEL = {'penta': ('Penta', 'Cobertura vacinal Penta (DTP/HepB/Hib), <1 ano'),
          'triplice_viral_d1': ('Tríplice Viral  D1', 'Cobertura vacinal triplice viral D1, 1 ano'),
          'triplice_viral_d2': ('Tríplice Viral  D2', 'Cobertura vacinal triplice viral D2, 1 ano')}
for f, (ctab, ind) in PAINEL.items():
    arq = f'infoms/painel_evolucao_{f}.json'
    d = json.load(open(P(arq), encoding='utf-8'))
    T = d['textos']
    yrs = [x for x in T if re.fullmatch(r'20\d\d', x['t'])]
    vals = [x for x in T if re.fullmatch(r'\d+,\d+%', x['t']) and x['x'] > 150 and x['y'] < 920]
    serie = {}
    for v in vals:
        y = min(yrs, key=lambda z: abs(z['x'] - v['x']))
        assert abs(y['x'] - v['x']) <= 25, (f, v, y)
        serie[int(y['t'])] = float(v['t'].rstrip('%').replace(',', '.'))
    confere = all(abs(serie[a] - pni[a][ctab]) < 0.006 for a in range(2015, 2023))
    assert confere, f
    for a in (2023, 2024, 2025):
        SAU.append(linha(ind, 'Brasil', a, serie[a], '% da populacao alvo', 'MS, Painel Cobertura Vacinal Infantil por residencia (InfoMS/RNDS)',
                         arq, f'painel InfoMS, aba Evolucao, Imunobiologico "{d["imuno"]}", ponto {a} do grafico (captura {d["capturado"][:10]})',
                         f'{d["cabecalho"]} Valores 2015-2022 do mesmo grafico conferem com o TabNet; dados sujeitos a atualizacao; leitura do rotulo do grafico, nao de planilha', 2))
# WUENIC (OMS/UNICEF) via Banco Mundial, Brasil
for code, ind in (('SH.IMM.IDPT', 'Cobertura DTP3 estimada OMS/UNICEF (WUENIC), 12-23 meses'), ('SH.IMM.MEAS', 'Cobertura sarampo 1a dose estimada OMS/UNICEF (WUENIC), 12-23 meses')):
    arq = f'bm/wdi_{code}.json'
    d = json.load(open(P(arq), encoding='utf-8'))
    for r in sorted(d[1], key=lambda r: r['date']):
        a = int(r['date'])
        if 2008 <= a <= 2025:
            SAU.append(linha(ind, 'Brasil', a, r['value'], '% das criancas', 'OMS/UNICEF WUENIC, repassado pelo Banco Mundial WDI', arq,
                             f'WDI {code}', 'estimativa internacional a partir dos relatos do pais; nao e o dado do PNI' if r['value'] is not None else 'nao encontrado no WDI', 0))

# ================= INTERNACIONAL =================
PAISES = {'BRA': 'Brasil', 'MEX': 'Mexico', 'CHL': 'Chile', 'COL': 'Colombia', 'ARG': 'Argentina', 'IDN': 'Indonesia',
          'OED': 'OCDE (membros, agregado Banco Mundial)'}
WDI = {'SP.DYN.LE00.IN': ('Esperanca de vida ao nascer', 'anos', 2),
       'SP.DYN.IMRT.IN': ('Taxa de mortalidade infantil', 'por mil nascidos vivos', 1),
       'SH.XPD.CHEX.GD.ZS': ('Gasto corrente total em saude (publico+privado)', '% do PIB', 2),
       'SH.XPD.GHED.GD.ZS': ('Gasto publico domestico em saude (governo geral)', '% do PIB', 2),
       'SE.XPD.TOTL.GD.ZS': ('Gasto publico em educacao', '% do PIB', 2)}
for code, (ind, unid, dec) in WDI.items():
    arq = f'bm/wdi_{code}.json'
    d = json.load(open(P(arq), encoding='utf-8'))
    meta = json.load(open(P(f'bm/meta2_{code}.json'), encoding='utf-8'))
    mt = {c['id']: c['value'] for c in meta['source'][0]['concept'][0]['variable'][0]['metatype']}
    org = json.load(open(P(f'bm/meta_{code}.json'), encoding='utf-8'))[1][0]['sourceOrganization'].split(',')[0]
    for r in sorted(d[1], key=lambda r: (r['countryiso3code'], r['date'])):
        a = int(r['date'])
        if not 2008 <= a <= 2025: continue
        nota = f'fonte primaria: {org}; repassado pelo WDI (atualizado {d[0]["lastupdated"]})'
        if r['countryiso3code'] == 'OED': nota += f'; agregado OCDE do Banco Mundial, metodo: {mt.get("Aggregationmethod", "?")}'
        if code == 'SP.DYN.LE00.IN': nota += '; ONU WPP, serie interpolada; difere da serie do IBGE para o Brasil'
        if code == 'SP.DYN.IMRT.IN': nota += '; estimativa UN IGME; difere da TMI do IBGE e da taxa direta do SIM'
        if r['value'] is None: nota = 'nao encontrado no WDI para o ano; ' + nota
        INT.append(linha(ind, PAISES[r['countryiso3code']], a, None if r['value'] is None else float(r['value']), unid,
                         'Banco Mundial WDI (repasse de fonte oficial)', arq, f'WDI {code}', nota, dec))

for nome, rows in (('Q-educacao.csv', EDU), ('Q-saude.csv', SAU), ('Q-internacional.csv', INT)):
    rows.sort(key=lambda r: (r['indicador'], r['recorte'], int(r['ano'])))
    with open(os.path.join(ROOT, nome), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, CAMPOS, lineterminator='\n'); w.writeheader(); w.writerows(rows)
    print(nome, len(rows))

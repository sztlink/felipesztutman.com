# Frente CU, cultura

Feita em 20/10/2026 para a v12.4, por decisão do autor de incluir a cultura em todas as análises do dossiê.

## O que entra
- `CU-cultura-uniao.csv`. Função Cultura da União de 2015 a 2025, despesas liquidadas, exceto intra-orçamentárias, do RREO do 6º
  bimestre (Anexo 2). Em R$ correntes, R$ de 2025 pelo IPCA de dezembro a dezembro (frente N), % do PIB (SIDRA 6784 e, quando faltar,
  a soma dos trimestres da SIDRA 1846 da frente N2) e R$ por habitante (projeção do IBGE, frente H), com o presidente de cada ano.
- `CU-cultura-resumo.csv`. Ministério da Cultura em 2025 (SIOP, frente B), renúncias da cultura e do audiovisual e Lei Rouanet na
  previsão de 2026 (DGT, frente E), e cultura no país inteiro em 2024 (COFOG, frente C, via RAZAO-per-capita.csv).

## Regra de leitura do RREO
A primeira linha "Cultura" na coluna (d), despesas liquidadas até o bimestre, é o bloco exceto intra-orçamentárias. Em 2015 e 2016
o Tesouro chama a coluna "Até o Bimestre (d)" e deixa o rótulo vazio. O valor de 2019 bate com o da frente A (R$ 715,7 mi).

## Limites
A série mede gasto e não resultado cultural. A função e o órgão (Ministério da Cultura) não coincidem. Renúncia não é despesa e
fica de fora da série. Antes de 2015 o RREO tem outro formato e não entra.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/CU/baixa_CU.py
cd /tmp && python3 -I <pacote>/brutos/CU/build_CU.py
```

#!/usr/bin/env python3
# Frente CU. Baixa o RREO da Uniao, Anexo 2, 6o bimestre, de 2015 a 2018 (2019 em diante vem da frente A), uma requisicao por vez.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CU/baixa_CU.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
U = 'https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio={y}&nr_periodo=6&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%2002&id_ente=1'
linhas = []
for y in range(2015, 2019):
  dst = os.path.join(F, f'rreo-{y}-6-a02.json')
  if not os.path.exists(dst):
    open(dst, 'wb').write(urllib.request.urlopen(U.format(y=y), timeout=120).read()); time.sleep(3)
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), f'Tesouro, Siconfi, RREO da Uniao, Anexo 2, 6o bimestre de {y}',
                           f'fontes/rreo-{y}-6-a02.json', U.format(y=y), hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(len(linhas))

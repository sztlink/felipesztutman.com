#!/usr/bin/env python3
# Frente CU, cultura. Serie da funcao Cultura da Uniao (RREO, Anexo 2, despesas liquidadas, exceto intra-orcamentarias) de 2015 a
# 2025, em R$ correntes, R$ de 2025 (IPCA dez a dez), % do PIB e R$ por habitante, e um resumo de 2025 com o Ministerio da Cultura,
# as renuncias da cultura e o gasto do pais inteiro, lidos das frentes A, B, C, E e H.
# Rodar: cd /tmp && python3 -I <pacote>/brutos/CU/build_CU.py   (2015 a 2018 em fontes/, baixados por baixa_CU.py; 2019 em diante em brutos/A)
import csv, json, os
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes')
U = lambda y: f'https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio={y}&nr_periodo=6&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%2002&id_ente=1'
pres = lambda a: {2015: 'Dilma', 2016: 'D/T', 2017: 'Temer', 2018: 'Temer'}.get(a) or ('Bolsonaro' if a <= 2022 else 'Lula 3')
def cultura(y):
  p = os.path.join(F, f'rreo-{y}-6-a02.json') if y < 2019 else os.path.join(RAIZ, 'brutos', 'A', f'rreo-{y}-6-a02.json')
  it = json.load(open(p, encoding='utf-8'))['items']
  # a primeira linha "Cultura" na coluna (d), despesas liquidadas ate o bimestre, e o bloco exceto intra-orcamentarias
  # (o RREO de 2015 e 2016 chama a coluna "Ate o Bimestre (d)" e nao preenche o rotulo)
  v = [i['valor'] for i in it if i['conta'] == 'Cultura' and i['coluna'] in ('DESPESAS LIQUIDADAS ATÉ O BIMESTRE (d)', 'Até o Bimestre (d)')]
  return v[0]
IPCA = {int(r['D3C'][:4]): float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:] if r['D3C'].endswith('12')}
POP = {int(r['ano']): float(r['beneficiarios']) for r in csv.DictReader(open(os.path.join(RAIZ, 'brutos', 'H', 'H-beneficiarios-historico-servicos.csv'), encoding='utf-8')) if r['serie'] == 'populacao' and r['beneficiarios']}
p6784 = {int(r['D3C']): float(r['V']) * 1e6 for r in json.load(open(os.path.join(RAIZ, 'brutos', 'A', 'sidra-6784.json'), encoding='utf-8'))[1:]}
q1846 = {r['D3C']: float(r['V']) * 1e6 for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N2', 'fontes', 'ibge', 'sidra_1846_pib_corrente.json'), encoding='utf-8'))[1:]}
pib = lambda y: p6784.get(y) or sum(v for k, v in q1846.items() if k.startswith(str(y)))
lin = []
for y in range(2015, 2026):
  v = cultura(y); real = v * IPCA[2025] / IPCA[y]
  lin.append([y, pres(y), round(v / 1e9, 3), round(real / 1e9, 3), round(100 * v / pib(y), 4), round(real / POP[y], 2), U(y)])
with open(os.path.join(RAIZ, 'CU-cultura-uniao.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['ano', 'presidente', 'liquidado_rs_bi', 'liquidado_rs_bi_2025', 'pct_pib', 'rs_2025_por_habitante', 'fonte_url']); w.writerows(lin)
print('CU-cultura-uniao.csv', len(lin))
# resumo de 2025 (e da previsao de renuncias de 2026), a partir das frentes do pacote
le = lambda n: list(csv.DictReader(open(os.path.join(RAIZ, n), encoding='utf-8')))
B = [r for r in le('B-uniao-por-orgao-e-gnd.csv') if r['ano'] == '2025' and r['categoria'] == 'ORGAO: Ministério da Cultura']
E = le('E-renuncias-e-subsidios.csv')
e = lambda ano, cat, sub: next(float(r['valor_brl']) for r in E if r['ano'] == ano and r['categoria'] == cat and r['subcategoria'] == sub)
FC = {r['subcategoria']: float(r['valor_brl']) for r in E if r['ano'] == '2026' and r['categoria'] == 'Funcao Cultura, por gasto tributario'}
fc = lambda k: FC[k]
AV_FORA = ('Programação', 'Indústria Cinematográfica e Radiodifusão', 'RECINE')
# ponte: a categoria Cultura e Audiovisual do Q X e PRONAC mais Atividade Audiovisual; o audiovisual inteiro soma tambem AV_FORA
assert abs(e('2026', 'Gasto tributario (top 25)', 'Cultura e Audiovisual') - e('2026', 'Cultura', 'Lei Rouanet (PRONAC, IRPJ+IRPF)') - fc('Atividade Audiovisual')) < 1e3
assert abs(e('2026', 'Cultura', 'Lei do Audiovisual, Recine, Condecine e correlatos') - fc('Atividade Audiovisual') - sum(fc(k) for k in AV_FORA)) < 1e3
assert abs(sum(FC.values()) - e('2026', 'Por funcao orcamentaria', 'Cultura')) < 1e3
RZ = next(r for r in le('RAZAO-per-capita.csv') if r['tabela'] == 'pais-2024' and r['bloco'] == 'Cultura')
res = [
  ['uniao_funcao_cultura_liquidado', 2025, lin[-1][2], 'RREO, funcao 13, liquidado', U(2025)],
  ['minc_dotacao_atualizada', 2025, round(float(next(r['valor_brl'] for r in B if r['estagio'] == 'dotacao_atualizada')) / 1e9, 3), 'SIOP, orgao 42000', 'B-uniao-por-orgao-e-gnd.csv'],
  ['minc_liquidado', 2025, round(float(next(r['valor_brl'] for r in B if r['estagio'] == 'liquidado')) / 1e9, 3), 'SIOP, orgao 42000', 'B-uniao-por-orgao-e-gnd.csv'],
  ['renuncia_cultura_e_audiovisual', 2026, round(e('2026', 'Gasto tributario (top 25)', 'Cultura e Audiovisual') / 1e9, 3), 'DGT, previsao PLOA 2026', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_lei_rouanet', 2026, round(e('2026', 'Cultura', 'Lei Rouanet (PRONAC, IRPJ+IRPF)') / 1e9, 3), 'DGT, previsao PLOA 2026', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_audiovisual', 2026, round(e('2026', 'Cultura', 'Lei do Audiovisual, Recine, Condecine e correlatos') / 1e9, 3), 'DGT, previsao PLOA 2026', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_atividade_audiovisual', 2026, round(fc('Atividade Audiovisual') / 1e9, 3), 'DGT, previsao PLOA 2026, Q III, a parte do audiovisual que o Q X soma em Cultura e Audiovisual', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_audiovisual_fora_da_categoria', 2026, round(sum(fc(k) for k in AV_FORA) / 1e9, 3), 'DGT, previsao PLOA 2026, Q III, Condecine (Programacao), Industria Cinematografica e Radiodifusao e RECINE, categorias proprias no Q X', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_livros', 2026, round((fc('Livros') + fc('Livros, Jornais e Periódicos')) / 1e9, 3), 'DGT, previsao PLOA 2026, Q III, Livros e Livros, Jornais e Periodicos na funcao Cultura', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_entidades_culturais', 2026, round(fc('Entidades sem Fins Lucrativos - Cultural') / 1e9, 3), 'DGT, previsao PLOA 2026, Q III', 'E-renuncias-e-subsidios.csv'],
  ['renuncia_funcao_cultura', 2026, round(e('2026', 'Por funcao orcamentaria', 'Cultura') / 1e9, 3), 'DGT, previsao PLOA 2026, todos os gastos tributarios classificados na funcao Cultura', 'E-renuncias-e-subsidios.csv'],
  ['pais_cultura_tres_esferas', 2024, float(RZ['valor_rs_bi']), 'COFOG do Tesouro, governo geral', 'RAZAO-per-capita.csv'],
  ['pais_cultura_por_habitante', 2024, float(RZ['rs_por_habitante_ano']), 'COFOG do Tesouro, governo geral', 'RAZAO-per-capita.csv'],
]
with open(os.path.join(RAIZ, 'CU-cultura-resumo.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['serie', 'ano', 'valor_rs_bi', 'nota', 'fonte']); w.writerows(res)
print('CU-cultura-resumo.csv', len(res))

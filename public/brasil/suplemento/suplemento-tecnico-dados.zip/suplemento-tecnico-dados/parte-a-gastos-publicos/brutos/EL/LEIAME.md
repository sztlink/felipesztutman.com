# Frente EL, reação de mercado aos turnos da eleição presidencial (protocolo do BRIEF-v14)

O protocolo está em `../../BRIEF-v14.md`, fixado em 24/10/2026 às 21h25, na véspera do 2º turno de 25/10/2026. Este LEIAME
registra como o build o executa, o que saiu, o que ficou de fora e os desvios. Rodado em 24/10/2026 para 2002 a 2022 e para o
1º turno de 2026. A linha do 2º turno de 2026 está vazia, com aviso, porque o pregão de 26/10/2026 ainda não existe.

## Arquivos

| arquivo | o que é |
|---|---|
| `../../EL-eventos.csv` | 14 turnos (2002 a 2026), data, fonte da data, conferência com a regra do art. 77, presidente em exercício (só data o valor) |
| `../../EL-variacoes.csv` | 168 linhas, turno x variável x janela (1 e 5 dias). Valores em t-1 e no fim da janela, variação, posição contra fins de semana comuns, desvio-padrão e mediana da referência, situação (medido, medido sem posição, excluido, pendente) |
| `../../EL-resumo.csv` | por turno, variável e janela, os turnos de 2002 a 2022 (mediana do percentil, quantos no percentil 95 ou mais, esperado por acaso) e a linha de 2026 com a posição entre os turnos do mesmo número |
| `excluidos.tsv` | casos excluídos e pendentes, com o motivo |
| `entradas.tsv` | sha256 de cada arquivo lido pelo build |
| `downloads.tsv` | data, descrição, arquivo, url e sha256 de cada bruto (escrito por `baixa_EL.py`) |

## Fontes

- Datas de 2002 a 2022, TSE, `fontes/detalhe_votacao_munzona_<ano>.zip`. O build lê só `NR_TURNO`, `DT_ELEICAO`, `DS_CARGO` e
  `CD_TIPO_ELEICAO` (eleição ordinária, cargo Presidente). Não lê voto nem candidato. As 12 datas conferem com a regra do
  primeiro e do último domingo de outubro.
- Datas de 2026, art. 77 da Constituição, `fontes/constituicao.htm` (Planalto). O build confere o trecho literal no texto.
  Quando o TSE publicar `detalhe_votacao_munzona_2026.zip`, basta pô-lo em `fontes/` e o build confere as duas datas contra ele.
- Câmbio, PTAX venda, SGS 1, diária, em três arquivos (o mais novo de 2021 em diante vale).
- Tesouro Direto, Taxa Compra Manhã. Hoje o arquivo da frente N (`../N/td/precotaxatesourodireto.csv`, até 15/10/2026). Se
  existir `fontes/td_<data>.csv`, o build usa o mais novo.
- EMBI+ Brasil, `../X/dados/ipeadata_JPM366_EMBI366.json` (Ipeadata, inativa desde 30/07/2024).

## Como o build executa o protocolo

- Prefixado de 1 ano pelo método da frente W (função `vertice`, copiada). Prefixado, juro real e implícita de 10 anos pelo método
  da frente N (função `interp`, copiada, e Fisher). Conferido contra `../N/diario_td.csv` em 13.984 pontos, diferença máxima de
  0,005 pb (arredondamento de N). Médias mensais do pré de 1 ano conferem com `W-curva-mensal.csv` até 0,00005 ponto.
- Dias com cotação. Na PTAX e no EMBI, os dias da série. No TD, todos os dias do arquivo do TD, tenha o vértice cotação ou não.
  Vértice sem cotação em t-1, t0 ou no fim da janela tira o caso. Na referência, a janela com vértice faltando é pulada.
- "Primeiro dia com cotação depois de um fim de semana" = há sábado ou domingo entre o dia anterior com cotação e ele.
- Percentil = porcentagem da referência com módulo menor que o do evento. Razão = variação dividida pelo desvio-padrão amostral.
- Posição de 2026 entre os turnos = 1 mais o número de turnos do mesmo número, de 2002 a 2022, com módulo estritamente maior.

## Casos excluídos e pendentes

- 2002, todas as variáveis do TD. O arquivo do TD começa em 31/12/2004.
- 2006, 1º turno, prefixado e implícita de 10 anos. O primeiro dia com NTN-F dentro da tolerância do vértice é 02/10/2006, depois
  do turno. No 2º turno de 2006 a variação existe, mas a referência tem 0 janelas, e a posição fica vazia.
- 2022, 2º turno, prefixado de 1 ano em 5 dias. O vértice não tem cotação em 07/11/2022 (de 02/11/2022 a 01/01/2023 os títulos
  do TD não cobrem o vencimento de 1 ano dentro da regra da frente W).
- 2026, os dois turnos, EMBI. Série descontinuada.
- 2026, 2º turno, câmbio e TD, PENDENTE. Em 24/10/2026 a PTAX vai até 23/10/2026 e o TD até 15/10/2026.

## Desvios

Os dois foram achados na primeira rodada, em 24/10/2026, e corrigidos antes de qualquer leitura. Ficam registrados porque a
primeira rodada já mostrava variações.

1. A primeira versão exigia 400 dias corridos de série antes do turno. O protocolo não pede isso. Ele só deixa a posição vazia
   com menos de 30 janelas na referência. A regra saiu, e o 1º turno de 2002 voltou a ter câmbio (a PTAX baixada começa em
   03/09/2001).
2. A primeira versão contava os dias da janela só entre os dias em que o vértice tinha cotação. No 2º turno de 2022, isso fez a
   janela de 5 dias do pré de 1 ano terminar em 04/01/2023, por cima de dois meses sem vértice. A janela passou a ser contada nos
   dias do arquivo do TD, e o caso saiu (ver acima).

## Números (variação medida, classe A, sem controles externos)

De `../../EL-variacoes.csv` e `../../EL-resumo.csv`. Câmbio em % (100 vezes o log), o resto em pb.

1º turno de 2026 (04/10/2026), de 02/10 para 05/10/2026, janela de 1 dia.

| variável | variação | percentil contra fins de semana comuns | posição entre os 1º turnos de 2002 a 2026 |
|---|---|---|---|
| câmbio (R$ 5,2238 para 4,9859) | -4,66 | 100 | 1ª de 7 |
| prefixado 1 ano | -65,8 | 100 | 1ª de 6 |
| prefixado 10 anos | -117,0 | 100 | 1ª de 5 |
| juro real 10 anos | -66,3 | 100 | 1ª de 6 |
| inflação implícita 10 anos | -43,6 | 100 | 1ª de 5 |

Na janela de 5 dias, as cinco variáveis também ficam no percentil 100, e o câmbio é o 2º maior módulo entre os 1º turnos.

Turnos de 2002 a 2022, janela de 1 dia.

- 1º turno, câmbio. Mediana do módulo da variação de 1,96%, contra 0,44% na mediana dos fins de semana comuns. Três de seis no
  percentil 95 ou mais, contra 0,3 esperado por acaso.
- 2º turno, câmbio. Mediana do módulo de 1,33%, contra 0,44%. Um de seis no percentil 95 ou mais.
- EMBI, mediana do percentil de 48 no 1º turno e de 53 no 2º, perto do meio da referência.

Leitura. A variação e a posição são descrição (classe A). Não há controle de dólar global, juro americano ou VIX, e com no
máximo seis turnos por grupo não há teste. A leitura de que a eleição causou o movimento, e de qual resultado o mercado preferia,
é classe C e fica fora.

## Como rodar depois do 2º turno

```
cd /tmp && python3 -I gastos-publicos-brasil-dados/brutos/EL/baixa_EL.py --pos   # PTAX até hoje e TD novo
cd /tmp && python3 -I gastos-publicos-brasil-dados/brutos/EL/build_EL.py
```

A janela de 1 dia precisa do pregão de 26/10/2026 no arquivo do TD e na PTAX. A de 5 dias precisa até 30/10/2026. Enquanto
faltar, a linha sai como pendente. O arquivo do TD do Tesouro Transparente pode levar alguns dias para trazer o pregão. Nada
muda no método.

Só biblioteca padrão. Duas rodadas seguidas em 24/10/2026 deram os mesmos sha256.

| arquivo | sha256 |
|---|---|
| EL-eventos.csv | 5055257fef80e4a0cb7d3d0e8c3138a8a98d91b36b4a878f219f220877b1eed2 |
| EL-variacoes.csv | 3c24674d1004bef696178e5e64cfcd0a94ffab09f1e67ecd2a78fe575b292176 |
| EL-resumo.csv | f04bd5f19cc45987dc2682c04d5c7d56e63db0ca28021f6be5d5c243b18fce2e |

# Frente EL: reacao de mercado aos turnos da eleicao presidencial, pelo protocolo do BRIEF-v14.md (fixado em 24/10/2026,
# antes do 2o turno de 25/10/2026 e antes de calcular qualquer variacao em data de eleicao).
# Gera, na raiz gastos-publicos/:
#   EL-eventos.csv     turnos de 2002 a 2026, data, fonte da data, presidente em exercicio (so data o valor)
#   EL-variacoes.csv   um por turno x variavel x janela, com a posicao contra fins de semana comuns dos 12 meses anteriores
#   EL-resumo.csv      turnos de 2002 a 2022 por turno, variavel e janela, e a posicao de 2026 entre eles
# e, dentro de brutos/EL/: excluidos.tsv, entradas.tsv (sha256 de tudo o que foi lido)
# Entradas:
#   fontes/detalhe_votacao_munzona_<ano>.zip      TSE (so turno, data e cargo)
#   fontes/constituicao.htm                       Planalto, art. 77 (datas de 2026)
#   fontes/sgs1_*.json                            PTAX venda diaria (BCB); do trecho de 2021 em diante vale o arquivo mais novo
#   fontes/td_<data>.csv se existir, senao ../N/td/precotaxatesourodireto.csv   Tesouro Direto (Tesouro Transparente)
#   ../X/dados/ipeadata_JPM366_EMBI366.json       EMBI+ Brasil (Ipeadata), inativa desde 30/07/2024
# O build nao le voto, candidato nem resultado. So biblioteca padrao.
# Rodar de fora da pasta: cd /tmp && python3 -I /caminho/brutos/EL/build_EL.py
import csv, datetime as dt, glob, hashlib, html, io, json, math, os, re, statistics, zipfile

H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(H, '..', '..'))
B = os.path.abspath(os.path.join(H, '..'))
F = os.path.join(H, 'fontes')
REL = lambda p: os.path.relpath(p, ROOT)
ENTRADAS = {}

ANOS_TSE = [2002, 2006, 2010, 2014, 2018, 2022]
JANELAS = [1, 5]
REF_INI, REF_FIM = 260, 11       # referencia: t0 entre 260 e 11 dias com cotacao antes do t0 do evento
EXCL = 5                         # janelas a 5 dias com cotacao ou menos de qualquer turno saem da referencia
MIN_REF = 30
MAX_T0 = 3                       # t0 ate 3 dias corridos depois do domingo
MAX_TM1 = 4                      # t-1 ate 4 dias corridos antes do domingo
ART77 = 'no primeiro domingo de outubro, em primeiro turno, e no último domingo de outubro, em segundo turno, se houver'
VARS = [  # nome, unidade, descricao
    ('cambio', '%', 'PTAX venda, 100 x variacao do logaritmo'),
    ('prefixado_1a', 'pb', 'TD, prefixado de 1 ano (LTN, NTN-F se a LTN nao cobrir), metodo da frente W'),
    ('prefixado_10a', 'pb', 'TD, prefixado de 10 anos (curva NTN-F), metodo da frente N'),
    ('juro_real_10a', 'pb', 'TD, juro real de 10 anos (curva NTN-B com cupom), metodo da frente N'),
    ('inflacao_implicita_10a', 'pb', 'TD, Fisher entre prefixado e juro real de 10 anos'),
    ('embi', 'pb', 'EMBI+ Brasil (JP Morgan, Ipeadata), inativa desde 30/07/2024'),
]


def abre(caminho):
    b = open(caminho, 'rb').read()
    ENTRADAS[REL(caminho)] = hashlib.sha256(b).hexdigest()
    return b


def r(x, n=4):
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return ''
    return round(float(x), n)


def escreve(caminho, linhas, campos, sep=','):
    with open(caminho, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=campos, delimiter=sep, lineterminator='\n')
        w.writeheader()
        for l in linhas:
            w.writerow({k: l.get(k, '') for k in campos})


def presidente(d):
    """presidente em exercicio na data; so data o valor, nao atribui causa"""
    if d <= dt.date(2002, 12, 31):
        return 'FHC'
    if d <= dt.date(2006, 12, 31):
        return 'Lula 1'
    if d <= dt.date(2010, 12, 31):
        return 'Lula 2'
    if d <= dt.date(2016, 5, 12):
        return 'Dilma'
    if d <= dt.date(2018, 12, 31):
        return 'Temer'
    if d <= dt.date(2022, 12, 31):
        return 'Bolsonaro'
    return 'Lula 3'


def domingos_outubro(a):
    d = dt.date(a, 10, 1)
    ds = [d + dt.timedelta(days=k) for k in range(31) if (d + dt.timedelta(days=k)).weekday() == 6]
    return ds[0], ds[-1]


def pdate(s):
    return dt.date(int(s[6:10]), int(s[3:5]), int(s[0:2]))


# ---------------------------------------------------------------- eventos
def eventos():
    ev = []
    for a in ANOS_TSE:
        arq = os.path.join(F, 'detalhe_votacao_munzona_%d.zip' % a)
        z = zipfile.ZipFile(io.BytesIO(abre(arq)))
        nome = [n for n in z.namelist() if n.endswith('_BRASIL.csv')][0]
        achados = set()
        with z.open(nome) as f:
            rd = csv.DictReader(io.TextIOWrapper(f, encoding='latin-1'), delimiter=';')
            for row in rd:
                if row['DS_CARGO'].strip().lower() == 'presidente' and row['CD_TIPO_ELEICAO'].strip() == '2':
                    achados.add((int(row['NR_TURNO']), row['DT_ELEICAO']))
        p, u = domingos_outubro(a)
        turnos = sorted(achados)
        if [t for t, _ in turnos] != [1, 2]:
            raise SystemExit('TSE %d: turnos de presidente inesperados %s' % (a, turnos))
        for t, d in turnos:
            d = pdate(d)
            regra = p if t == 1 else u
            ev.append({'ano': a, 'turno': t, 'data': d, 'fonte_data': '%s (%s, NR_TURNO e DT_ELEICAO, cargo Presidente)' % (REL(arq), nome),
                       'confere_regra_art77': 'sim' if d == regra else 'nao (regra daria %s)' % regra.isoformat()})
    # 2026 pela regra do art. 77, conferida no texto do Planalto
    arq = os.path.join(F, 'constituicao.htm')
    b = abre(arq)
    try:
        s = b.decode('utf-8')
    except UnicodeDecodeError:
        s = b.decode('cp1252')
    t = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s)))
    if ART77 not in t:
        raise SystemExit('art. 77 sem o trecho esperado')
    p, u = domingos_outubro(2026)
    for tn, d in ((1, p), (2, u)):
        ev.append({'ano': 2026, 'turno': tn, 'data': d, 'fonte_data': '%s (art. 77, "%s")' % (REL(arq), ART77),
                   'confere_regra_art77': 'sim (data definida pela regra)'})
    if (p, u) != (dt.date(2026, 10, 4), dt.date(2026, 10, 25)):
        raise SystemExit('regra do art. 77 nao da 04/10 e 25/10/2026')
    # quando o TSE publicar o arquivo de 2026 (baixar a mao para fontes/), a data da regra e conferida contra ele
    arq26 = os.path.join(F, 'detalhe_votacao_munzona_2026.zip')
    if os.path.exists(arq26):
        z = zipfile.ZipFile(io.BytesIO(abre(arq26)))
        nome = [n for n in z.namelist() if n.endswith('_BRASIL.csv')][0]
        with z.open(nome) as f:
            rd = csv.DictReader(io.TextIOWrapper(f, encoding='latin-1'), delimiter=';')
            ach = {(int(x['NR_TURNO']), pdate(x['DT_ELEICAO'])) for x in rd
                   if x['DS_CARGO'].strip().lower() == 'presidente' and x['CD_TIPO_ELEICAO'].strip() == '2'}
        for e in ev[-2:]:
            e['confere_regra_art77'] += '; TSE 2026: %s' % ('confere' if (e['turno'], e['data']) in ach else 'NAO CONFERE')
    for e in ev:
        e['presidente_em_exercicio'] = presidente(e['data'])
    return ev


# ---------------------------------------------------------------- series
def cambio():
    arqs = [os.path.join(F, 'sgs1_2001_2010.json'), os.path.join(F, 'sgs1_2011_2020.json')]
    rec = sorted(glob.glob(os.path.join(F, 'sgs1_2021_*.json')))
    arqs.append(rec[-1])
    s = {}
    for a in arqs:
        for x in json.loads(abre(a).decode('utf-8')):
            s[pdate(x['data'])] = 100.0 * math.log(float(x['valor']))
    return s, ' ; '.join(REL(a) for a in arqs)


NTNB, NTNBP, NTNF, LTN = 'Tesouro IPCA+ com Juros Semestrais', 'Tesouro IPCA+', 'Tesouro Prefixado com Juros Semestrais', 'Tesouro Prefixado'
SIGLA = {NTNB: 'NTN-B', NTNBP: 'NTN-B Principal', NTNF: 'NTN-F', LTN: 'LTN'}
MIN_DIAS = 60


def num(s):
    """copia de build_N.num"""
    s = (s or '').strip().replace('.', '').replace(',', '.') if s and ',' in s else (s or '').strip()
    try:
        return float(s)
    except ValueError:
        return None


def interp_n(t, tipos, alvo, tol):
    """copia de build_N.interp e build_W.interp_n: linear em dias; sem vizinho dos dois lados, titulo mais proximo ate tol dias"""
    nos = sorted((v, x, tp) for (tp, v), x in t.items() if tp in tipos)
    if not nos:
        return None
    ab = [n for n in nos if n[0] <= alvo]
    ac = [n for n in nos if n[0] >= alvo]
    if ab and ac:
        a, b = ab[-1], ac[0]
        if a[0] == b[0]:
            return a[1], '%s %s' % (SIGLA[a[2]], a[0])
        w = (alvo - a[0]).days / (b[0] - a[0]).days
        return a[1] + w * (b[1] - a[1]), 'interp %s %s / %s %s' % (SIGLA[a[2]], a[0], SIGLA[b[2]], b[0])
    n = ab[-1] if ab else ac[0]
    if abs((n[0] - alvo).days) <= tol:
        return n[1], 'mais proximo %s %s' % (SIGLA[n[2]], n[0])
    return None


def vertice(t, base, familias, alvo, tol):
    """copia de build_W.vertice"""
    tt = {k: v for k, v in t.items() if (k[1] - base).days >= MIN_DIAS}
    for fam in familias + [sum(familias, [])]:
        q = interp_n(tt, fam, alvo, 0)
        if q is not None and not q[1].startswith('mais proximo'):
            return q
    return interp_n(tt, sum(familias, []), alvo, tol)


def arquivo_td():
    novos = sorted(glob.glob(os.path.join(F, 'td_*.csv')))
    return novos[-1] if novos else os.path.normpath(os.path.join(B, 'N', 'td', 'precotaxatesourodireto.csv'))


def tesouro():
    arq = arquivo_td()
    txt = abre(arq).decode('utf-8-sig')
    rd = csv.reader(io.StringIO(txt), delimiter=';')
    head = next(rd)
    assert head[:5] == ['Tipo Titulo', 'Data Vencimento', 'Data Base', 'Taxa Compra Manha', 'Taxa Venda Manha'], head
    dia = {}
    for row in rd:
        tipo = row[0]
        if tipo not in SIGLA:
            continue
        base, venc = pdate(row[2]), pdate(row[1])
        if venc <= base:
            continue
        tx = num(row[3])
        if not num(row[5]) and not num(row[6]):
            continue
        if tx is None or tx == 0:
            tx = num(row[4])
        if tx is None or tx == 0:
            continue
        dia.setdefault(base, {})[(tipo, venc)] = tx
    out = {k: {} for k in ('prefixado_1a', 'prefixado_10a', 'juro_real_10a', 'inflacao_implicita_10a')}
    nos = {k: {} for k in out}
    for d in sorted(dia):
        t = dia[d]
        q = vertice(t, d, [[LTN], [NTNF]], d + dt.timedelta(days=round(365.25)), 183)
        if q:
            out['prefixado_1a'][d], nos['prefixado_1a'][d] = q[0] * 100.0, q[1]
        alvo = d + dt.timedelta(days=round(3652.5))
        b10 = interp_n(t, [NTNB], alvo, 1096)
        f10 = interp_n(t, [NTNF], alvo, 1096)
        if f10:
            out['prefixado_10a'][d], nos['prefixado_10a'][d] = f10[0] * 100.0, f10[1]
        if b10:
            out['juro_real_10a'][d], nos['juro_real_10a'][d] = b10[0] * 100.0, b10[1]
        if b10 and f10:
            out['inflacao_implicita_10a'][d] = ((1 + f10[0] / 100.0) / (1 + b10[0] / 100.0) - 1) * 1e4
            nos['inflacao_implicita_10a'][d] = '%s ; %s' % (f10[1], b10[1])
    return out, nos, REL(arq), max(dia), sorted(dia)


def embi():
    arq = os.path.normpath(os.path.join(B, 'X', 'dados', 'ipeadata_JPM366_EMBI366.json'))
    d = json.loads(abre(arq).decode('utf-8'))['value']
    return {dt.date.fromisoformat(x['VALDATA'][:10]): float(x['VALVALOR']) for x in d if x['VALVALOR'] is not None}, REL(arq)


# ---------------------------------------------------------------- medida
def depois_de_fim_de_semana(d0, d1):
    k = d0 + dt.timedelta(days=1)
    while k < d1:
        if k.weekday() >= 5:
            return True
        k += dt.timedelta(days=1)
    return False


def mede(serie, nos, ev, todos, nome, fonte, ult, cal=None):
    """cal = dias com cotacao da fonte (no TD, todos os dias do arquivo, mesmo sem o vertice); vertice ausente fica None"""
    datas = sorted(cal if cal is not None else serie)
    y = [serie.get(d) for d in datas]
    n = len(datas)

    def t0_de(dom):
        lo, hi = 0, n
        while lo < hi:
            m = (lo + hi) // 2
            if datas[m] <= dom:
                lo = m + 1
            else:
                hi = m
        return lo
    idx_ev = [t0_de(e['data']) for e in todos]
    linhas = []
    i0 = t0_de(ev['data'])
    for h in JANELAS:
        l = {'ano': ev['ano'], 'turno': ev['turno'], 'data_eleicao': ev['data'].isoformat(),
             'presidente_em_exercicio': ev['presidente_em_exercicio'], 'variavel': nome,
             'unidade': dict((a, b) for a, b, _ in VARS)[nome], 'janela_dias': h, 'arquivo_fonte': fonte,
             'ultimo_dia_na_fonte': ult.isoformat() if ult else ''}
        motivo = ''
        prim = min(serie) if serie else None
        if not datas or i0 < 1 or prim is None or prim >= ev['data']:
            motivo = 'serie sem dia com cotacao antes do turno (comeca em %s)' % (prim.isoformat() if prim else '?')
        elif i0 >= n:
            motivo = ('PENDENTE, a fonte vai ate %s e o primeiro pregao depois do turno ainda nao existe nela'
                      % datas[-1].isoformat())
            if nome == 'embi':
                motivo = 'serie descontinuada em %s, sem pregao depois do turno' % datas[-1].isoformat()
        elif (datas[i0] - ev['data']).days > MAX_T0:
            motivo = 't0 em %s, mais de %d dias corridos depois do domingo' % (datas[i0].isoformat(), MAX_T0)
        elif i0 < 1 or (ev['data'] - datas[i0 - 1]).days > MAX_TM1:
            motivo = 't-1 a mais de %d dias corridos antes do domingo' % MAX_TM1
        elif i0 + h - 1 >= n:
            motivo = 'PENDENTE, a fonte vai ate %s e a janela de %d dias precisa ate t0+%d' % (datas[-1].isoformat(), h, h - 1)
        if not motivo:
            falta = [datas[k].isoformat() for k in (i0 - 1, i0, i0 + h - 1) if y[k] is None]
            if falta:
                motivo = 'vertice sem cotacao em %s (titulos do TD nao cobrem o vencimento nesse dia)' % ', '.join(sorted(set(falta)))
        if motivo:
            l['situacao'] = 'pendente' if motivo.startswith('PENDENTE') else 'excluido'
            l['aviso'] = motivo
            linhas.append(l)
            continue
        a, b = i0 - 1, i0 + h - 1
        var = y[b] - y[a]
        l.update({'data_t_menos_1': datas[a].isoformat(), 'data_t0': datas[i0].isoformat(), 'data_fim': datas[b].isoformat(),
                  'valor_t_menos_1': r(y[a]), 'valor_fim': r(y[b]), 'variacao': r(var),
                  'nos_t_menos_1': nos.get(datas[a], '') if nos else '', 'nos_fim': nos.get(datas[b], '') if nos else ''})
        if nome == 'cambio':
            l['valor_t_menos_1'] = r(math.exp(y[a] / 100.0))
            l['valor_fim'] = r(math.exp(y[b] / 100.0))
            l['nota'] = 'valores em R$ por US$; variacao em 100 x log'
        ref = []
        for j in range(max(1, i0 - REF_INI), i0 - REF_FIM + 1):
            if j + h - 1 >= n or not depois_de_fim_de_semana(datas[j - 1], datas[j]):
                continue
            if y[j - 1] is None or y[j + h - 1] is None:
                continue
            if any(j - 1 - EXCL <= k <= j + h - 1 + EXCL for k in idx_ev):
                continue
            ref.append(y[j + h - 1] - y[j - 1])
        l['n_referencia'] = len(ref)
        if len(ref) >= MIN_REF:
            ab = [abs(x) for x in ref]
            dp = statistics.stdev(ref)
            l['percentil_abs_referencia'] = r(100.0 * sum(1 for x in ab if x < abs(var)) / len(ab), 1)
            l['dp_referencia'] = r(dp)
            l['razao_dp_referencia'] = r(var / dp if dp > 0 else None, 2)
            l['mediana_abs_referencia'] = r(statistics.median(ab))
            l['situacao'] = 'medido'
        else:
            l['situacao'] = 'medido, sem posicao'
            l['aviso'] = 'referencia com %d variacoes, menos que %d' % (len(ref), MIN_REF)
        linhas.append(l)
    return linhas


# ---------------------------------------------------------------- principal
def main():
    ev = eventos()
    fx, f_fx = cambio()
    td, td_nos, f_td, ult_td, cal_td = tesouro()
    em, f_em = embi()
    series = {'cambio': (fx, None, f_fx, max(fx), None), 'embi': (em, None, f_em, max(em), None)}
    for k in td:
        series[k] = (td[k], td_nos[k], f_td, ult_td, cal_td)
    linhas = []
    for e in ev:
        for nome, _, _ in VARS:
            s, nos, fonte, ult, cal = series[nome]
            linhas += mede(s, nos, e, ev, nome, fonte, ult, cal)
    campos = ['ano', 'turno', 'data_eleicao', 'presidente_em_exercicio', 'variavel', 'unidade', 'janela_dias', 'data_t_menos_1',
              'data_t0', 'data_fim', 'valor_t_menos_1', 'valor_fim', 'variacao', 'n_referencia', 'percentil_abs_referencia',
              'razao_dp_referencia', 'dp_referencia', 'mediana_abs_referencia', 'situacao', 'aviso', 'nos_t_menos_1', 'nos_fim',
              'nota', 'arquivo_fonte', 'ultimo_dia_na_fonte']
    escreve(os.path.join(ROOT, 'EL-variacoes.csv'), linhas, campos)
    escreve(os.path.join(ROOT, 'EL-eventos.csv'),
            [dict(e, data=e['data'].isoformat()) for e in ev],
            ['ano', 'turno', 'data', 'presidente_em_exercicio', 'confere_regra_art77', 'fonte_data'])
    escreve(os.path.join(H, 'excluidos.tsv'), [l for l in linhas if l['situacao'] in ('excluido', 'pendente')],
            ['ano', 'turno', 'variavel', 'janela_dias', 'situacao', 'aviso'], sep='\t')

    # resumo
    res = []
    for tn in (1, 2):
        for nome, uni, _ in VARS:
            for h in JANELAS:
                past = [l for l in linhas if l['turno'] == tn and l['variavel'] == nome and l['janela_dias'] == h
                        and l['ano'] < 2026 and l['situacao'].startswith('medido')]
                pc = [l['percentil_abs_referencia'] for l in past if l.get('percentil_abs_referencia', '') != '']
                g = {'tipo': 'turnos 2002 a 2022', 'turno': tn, 'variavel': nome, 'unidade': uni, 'janela_dias': h,
                     'n_eventos': len(past), 'anos': ' '.join(str(l['ano']) for l in past)}
                if past:
                    g['mediana_abs_variacao'] = r(statistics.median(abs(l['variacao']) for l in past))
                    refs = [l['mediana_abs_referencia'] for l in past if l.get('mediana_abs_referencia', '') != '']
                    g['mediana_das_medianas_abs_referencia'] = r(statistics.median(refs)) if refs else ''
                if pc:
                    g['n_com_posicao'] = len(pc)
                    g['mediana_percentil'] = r(statistics.median(pc), 1)
                    g['n_percentil_95_ou_mais'] = sum(1 for x in pc if x >= 95)
                    g['esperado_por_acaso'] = r(0.05 * len(pc), 2)
                g['nota'] = 'sem teste de significancia, no maximo seis eventos'
                res.append(g)
                l26 = [l for l in linhas if l['turno'] == tn and l['variavel'] == nome and l['janela_dias'] == h and l['ano'] == 2026][0]
                c = {'tipo': '2026', 'turno': tn, 'variavel': nome, 'unidade': uni, 'janela_dias': h, 'anos': '2026'}
                if l26['situacao'].startswith('medido'):
                    v = abs(l26['variacao'])
                    ab = [abs(l['variacao']) for l in past]
                    c.update({'variacao_2026': l26['variacao'], 'percentil_2026': l26.get('percentil_abs_referencia', ''),
                              'posicao_2026_entre_turnos': (1 + sum(1 for x in ab if x > v)) if ab else '',
                              'n_eventos': len(ab) + 1,
                              'nota': 'posicao 1 = maior modulo entre os turnos %d de 2002 a 2022 e 2026' % tn})
                else:
                    c['nota'] = l26['situacao'] + ', ' + l26.get('aviso', '')
                res.append(c)
    campos_r = ['tipo', 'turno', 'variavel', 'unidade', 'janela_dias', 'n_eventos', 'anos', 'mediana_abs_variacao',
                'mediana_das_medianas_abs_referencia', 'n_com_posicao', 'mediana_percentil', 'n_percentil_95_ou_mais',
                'esperado_por_acaso', 'variacao_2026', 'percentil_2026', 'posicao_2026_entre_turnos', 'nota']
    escreve(os.path.join(ROOT, 'EL-resumo.csv'), res, campos_r)
    escreve(os.path.join(H, 'entradas.tsv'), [{'arquivo': k, 'sha256': v} for k, v in sorted(ENTRADAS.items())],
            ['arquivo', 'sha256'], sep='\t')
    print('eventos', len(ev), 'linhas', len(linhas), 'medidas', sum(l['situacao'].startswith('medido') for l in linhas),
          'excluidas', sum(l['situacao'] == 'excluido' for l in linhas), 'pendentes', sum(l['situacao'] == 'pendente' for l in linhas))
    print('TD ate', ult_td, 'PTAX ate', max(fx))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# Frente EL, reacao de mercado aos turnos da eleicao presidencial (protocolo em BRIEF-v14.md). Baixa as datas dos turnos (TSE),
# o art. 77 da Constituicao (Planalto) e a PTAX diaria (BCB), uma requisicao por vez com pausa de 3 s, e registra cada arquivo
# em downloads.tsv (data, descricao, arquivo, url, sha256). Arquivos de outras frentes sao lidos sem copiar e so registrados.
# Uso:
#   cd /tmp && python3 -I <pacote>/brutos/EL/baixa_EL.py          baixa o que falta (PTAX ate hoje se nao houver arquivo)
#   cd /tmp && python3 -I <pacote>/brutos/EL/baixa_EL.py --pos    depois de 26/10/2026, baixa de novo a PTAX recente e o TD
import datetime, hashlib, json, os, sys, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
POS = '--pos' in sys.argv
HOJE = datetime.date.today()
SGS = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.1/dados?formato=json&dataInicial={a}&dataFinal={b}'
TSE = 'https://cdn.tse.jus.br/estatistica/sead/odsele/detalhe_votacao_munzona/detalhe_votacao_munzona_{a}.zip'
TD = ('https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/'
      'resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv')


def valida_json(b):
    json.loads(b)


def valida_zip(b):
    if b[:2] != b'PK':
        raise ValueError('nao e zip')


def valida_html(b):
    if b'Art. 77' not in b and b'Art.77' not in b:
        raise ValueError('sem Art. 77')


def valida_td(b):
    if not b[:40].lstrip(b'\xef\xbb\xbf').startswith(b'Tipo Titulo;'):
        raise ValueError('cabecalho do TD inesperado')


itens = [('constituicao.htm', 'Planalto, Constituicao Federal compilada, art. 77 (datas do 1o e do 2o turno)',
          'https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm', valida_html, False)]
for a in (2002, 2006, 2010, 2014, 2018, 2022):
    itens.append(('detalhe_votacao_munzona_%d.zip' % a, 'TSE, Portal de Dados Abertos, detalhe da apuracao por municipio e zona, %d '
                  '(so turno, data e cargo sao lidos)' % a, TSE.format(a=a), valida_zip, False))
itens.append(('sgs1_2001_2010.json', 'BCB SGS 1, dolar PTAX venda, diario, 01/09/2001 a 31/12/2010',
              SGS.format(a='01/09/2001', b='31/12/2010'), valida_json, False))
itens.append(('sgs1_2011_2020.json', 'BCB SGS 1, dolar PTAX venda, diario, 01/01/2011 a 31/12/2020',
              SGS.format(a='01/01/2011', b='31/12/2020'), valida_json, False))
recentes = sorted(x for x in os.listdir(F) if x.startswith('sgs1_2021_'))
if POS or not recentes:
    itens.append(('sgs1_2021_%s.json' % HOJE.strftime('%Y%m%d'), 'BCB SGS 1, dolar PTAX venda, diario, 01/01/2021 a %s'
                  % HOJE.strftime('%d/%m/%Y'), SGS.format(a='01/01/2021', b=HOJE.strftime('%d/%m/%Y')), valida_json, POS))
if POS:
    itens.append(('td_%s.csv' % HOJE.strftime('%Y%m%d'), 'Tesouro Transparente, Taxas dos Titulos Ofertados pelo Tesouro Direto, '
                  'baixado em %s' % HOJE.strftime('%d/%m/%Y'), TD, valida_td, True))

# registro previo (arquivos recentes baixados em rodadas anteriores continuam no inventario)
reg = {}
p_reg = os.path.join(AQUI, 'downloads.tsv')
if os.path.exists(p_reg):
    for ln in open(p_reg, encoding='utf-8').read().splitlines()[1:]:
        c = ln.split('\t')
        if len(c) == 5 and c[2].startswith('fontes/'):
            reg[c[2]] = c

for arq, desc, url, valida, forca in itens:
    dst = os.path.join(F, arq)
    if not os.path.exists(dst):   # arquivos datados pelo dia do download, entao --pos de outro dia baixa de novo
        for tent in range(3):
            try:
                b = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=300).read()
                valida(b)
                break
            except Exception as e:
                print('tentativa', tent + 1, arq, e)
                time.sleep(10)
        else:
            raise SystemExit('falhou ' + arq)
        open(dst, 'wb').write(b)
        print('baixado', arq, len(b))
        time.sleep(3)
    h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
    reg['fontes/' + arq] = [datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, 'fontes/' + arq, url, h]

OUTRAS = [
    ('../N/td/precotaxatesourodireto.csv', 'Tesouro Transparente, Taxas dos Titulos Ofertados pelo Tesouro Direto, consulta de '
     '18/10/2026 (ultimo dia 15/10/2026); lido da frente N sem copiar', TD),
    ('../X/dados/ipeadata_JPM366_EMBI366.json', 'Ipeadata, EMBI+ Risco-Brasil (JP Morgan), diario, pb, serie inativa desde '
     '30/07/2024; lido da frente X sem copiar', "http://www.ipeadata.gov.br/api/odata4/ValoresSerie(SERCODIGO='JPM366_EMBI366')"),
]
linhas = [reg[k] for k in sorted(reg) if os.path.exists(os.path.join(AQUI, k))]
for arq, desc, url in OUTRAS:
    dst = os.path.normpath(os.path.join(AQUI, arq))
    h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
    linhas.append([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, arq, url, h])
open(p_reg, 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join('\t'.join(x) for x in linhas) + '\n')
print(len(linhas), 'arquivos')

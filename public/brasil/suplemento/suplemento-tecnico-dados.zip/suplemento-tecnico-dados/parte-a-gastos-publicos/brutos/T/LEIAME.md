# Frente T: incidencia tributaria por faixa de renda

Levantamento de 19/10/2026. Regenerar, de fora desta pasta:

    python3 -I brutos/T/build_T.py

Grava `T-incidencia-tributaria.csv` na raiz `gastos-publicos/` (130 linhas, idempotente: duas rodadas saem iguais byte a byte). Colunas: `serie, faixa, ano, valor, unidade, fonte_url, pagina_ou_tabela, nota`. Cada nota diz o universo, o denominador, o que inclui e o que exclui. Linha calculada pelo script comeca a nota com "derivado:". Valor vazio com "nao encontrado" marca lacuna.

Os numeros publicados (Ipea, SPE) sao extraidos do texto dos PDFs por expressao regular. Se o texto nao bater, o script para. Os numeros da RFB saem das planilhas.

## Fontes (URL e data em `downloads.tsv`)

| pasta | fonte | tipo |
|---|---|---|
| `fazenda-rt/` | Ipea, TD 2823, "Tributacao indireta: aliquotas efetivas e incidencia sobre as familias" (Silveira, Palomo, Cornelio, Tonon, dez/2022), copia hospedada na pagina de estudos da reforma tributaria do Ministerio da Fazenda | oficial secundaria (Ipea) |
| `ipea/cc65-nota8.pdf` | Ipea, Carta de Conjuntura 65, nota 8, "Progressividade tributaria: diagnostico para uma proposta de reforma" (Gobetti, 29/10/2024) | oficial secundaria (Ipea) |
| `rfb/` | RFB, Distribuicao da Renda por Centis, AC 2023 (versao nov/2025) e AC 2024, planilha Brasil e metadados | primaria |
| `spe/` | SPE/MF, Relatorio da Distribuicao Pessoal da Renda e da Riqueza, Dados do IRPF 2023 (01/12/2025) e apresentacao; SPE/SPF/MF, Impactos da reforma do IRPF proposta no PL 1.087/2025 (jun/2025) e apresentacao | primaria |

**Os quatro PDFs da SPE sairam do ar.** Em 19/10/2026 o gov.br responde "Conteudo Restrito, e necessario autenticar" (ou 302 para login) nas quatro URLs. Os arquivos vieram do Wayback Machine (`id_`, bytes crus). O SHA-1 em base32 de cada arquivo baixado e igual ao digest que o CDX do Wayback registrou para a resposta original do gov.br, o que prova copia identica. `fonte_url` no CSV aponta o endereco oficial; `downloads.tsv` guarda as duas.

## As quatro familias de serie

1. **`pof_*`** (POF 2017-2018). Toda a populacao, decimos de renda familiar per capita, denominador renda total (monetaria + nao monetaria). Diretos = IRPF, contribuicao previdenciaria do trabalhador e outras deducoes lidas na POF, mais IPTU e IPVA. Indiretos = ICMS, IPI, PIS/Cofins, ISS etc., por aliquotas efetivas da matriz insumo-produto 2015, supondo repasse integral ao consumidor. Unica familia que soma renda, consumo e patrimonio na mesma base. Nao tem IRPJ e nao alcanca o topo.
2. **`rfb_*`** (AC 2023 e 2024). Declarantes do IRPF, centis ordenados por RB4 (renda total menos herancas). Razao imposto devido no ajuste / RB4. Nao inclui o IR retido exclusivamente na fonte, que a tabela nao traz, logo e **piso** da aliquota de IRPF. Acompanham a fatia de renda exclusiva e a fatia de lucros e dividendos (mais socio do Simples) na RB4.
3. **`spe_*`** (AC 2022 e 2023). Mesmos centis da RFB, com o IR exclusivo imputado pela SPE (15% em aplicacoes, ganho de capital, renda variavel e JCP; aliquota do estrato no 13o; tabela na PLR). E a aliquota efetiva de IRPF mais completa publicada pelo governo.
4. **`ipea_irpf_irpj_*`** (AC 2022). Declarantes, IRPF com IR exclusivo imputado + IRPJ/CSLL imputado aos dividendos recebidos (16,5% sobre lucro de Real e Presumido, 6,4% sobre Simples, cargas efetivas do Tax Gap da RFB), em tres cenarios de repasse ao socio. Unica fonte oficial achada que soma pessoa fisica e juridica por faixa.

## Resposta curta

| grupo | o que mede | ano | valor | serie |
|---|---|---|---|---|
| decimo 1 (populacao) | diretos + indiretos / renda total | 2017-2018 | 26,4% (3,0 + 23,4) | pof |
| decimos 5 e 6 (mediana) | idem | 2017-2018 | 18,9% (4,9 + 14,0) e 18,1% (5,0 + 13,1) | pof |
| decimo 10 (populacao) | idem | 2017-2018 | 19,2% (10,6 + 8,6) | pof |
| media | idem | 2017-2018 | 19,2% (8,0 + 11,2) | pof |
| pico do IRPF | IRPF com exclusivo imputado | 2023 | 12,0% no centil 93 dos declarantes | spe |
| 1% mais rico (declarantes) | IRPF so do ajuste (piso) | 2024 | 3,04% | rfb |
| 1% mais rico (declarantes) | IRPF + IRPJ/CSLL imputado | 2022 | 13,3% (repasse total) ou 10,3% (repasse de 50%) | ipea |
| 0,1% mais rico (declarantes) | IRPF so do ajuste (piso) | 2024 | 1,67% | rfb |
| 0,1% mais rico (declarantes) | IRPF + IRPJ/CSLL imputado | 2022 | 9,7% (repasse de 50%); repasse total sem numero no texto | ipea |
| 0,01% mais rico (declarantes) | IRPF com exclusivo imputado | 2023 | 4,6% (5,67% em 2022) | spe |

**Nao somar entre linhas de familias diferentes.** A POF cobre a populacao e subdeclara o topo; as bases do IRPF cobrem so declarantes (cerca de 41 milhoes) e nao tem consumo. Anos 2017-2018 contra 2022-2024. Nenhuma fonte oficial achada soma consumo + renda + patrimonio + IRPJ para o 1% ou o 0,1%.

## Ressalvas

- **POF contra IRPF.** O decimo 10 da POF mistura classe media alta e topo e nao capta a renda do topo (a propria SPE mostra que o 0,1% leva 2,5% da renda na PNAD e 11,9% no IRPF de 2022). O decimo 1 dos declarantes nao e pobre: e quem declara por ter bens, com renda declarada perto de zero.
- **Denominador.** A regressividade dos indiretos depende dele: decimo 1 paga 23,4% da renda total, 42,7% da renda monetaria, e quase o mesmo que os outros sobre a despesa de consumo (TD 2823, grafico 1). Linhas `pof_tributos_indiretos_sensibilidade_denominador`.
- **Incidencia suposta.** POF: indireto 100% no consumidor. IRPF: 100% em quem declara. IRPJ/CSLL: o Ipea testa 0%, 50% e 100% de repasse ao socio do lucro de Real e Presumido (o Simples e sempre 100%), citando estudos que poem 30% a 70% do imposto corporativo sobre trabalhadores e precos. Contribuicao patronal ao INSS nao entra em nenhuma serie.
- **IR exclusivo.** A razao da RFB e piso. A SPE imputa 15%, o que sobe o 0,01% de 0,5% a 0,9% (piso RFB) para 4,6% a 5,7%.
- **AC 2023.** A Lei 14.754/2023 fez a renda exclusiva de 2023 saltar (atualizacao de bens no exterior a 8%, fundos fechados). A SPE trocou essas colunas por valores de 2022; a serie `rfb_*` nao troca, entao para o topo prefira 2024.
- **Simulacao.** `spe_irpf_aliquota_efetiva_com_lei_15270` (8,25% a 9,14% no 0,7% do topo) e simulacao do PL original sobre a renda de 2022, nao dado observado.

## Procurado e nao achado

- Nota tecnica da SERT/MF ou da SRE/MF com incidencia atual do consumo por decimo da POF. A pagina de estudos da reforma (gov.br/fazenda/.../reforma-tributaria/estudos) hospeda o TD 2823 do Ipea, estudos do CCiF, UFMG e Banco Mundial; a nota da aliquota padrao e a apresentacao da SERT sobre cesta basica e cashback (Camara, 05/06/2024) nao trazem incidencia por decimo.
- Numero da RFB que some IRPF e IRPJ/CSLL por centil. As Notas Cetad/Coest 023/2025 (18/02/2025) e 134/2025 (10/11/2025) calcularam a aliquota efetiva de IRPJ/CSLL das empresas pagadoras de dividendos para o redutor do imposto minimo, mas publicam so impacto na arrecadacao, sem distribuicao. Lidas, nao guardadas aqui.
- Valor por centil das figuras da SPE (aliquota do 1% e do 0,1% com imputacao): so existe em grafico, o texto da apenas centil 93, 94, 0,7% e 0,01%.
- IVA dual: nenhuma fonte oficial com incidencia futura do IBS/CBS por decimo achada nesta rodada.

#!/usr/bin/env python3
"""Frente T: incidencia tributaria por faixa de renda.

Le apenas arquivos ja baixados em brutos/T/* e grava, na raiz gastos-publicos/:
  T-incidencia-tributaria.csv

Quatro familias de serie, que NAO sao somaveis entre si (bases, anos e populacoes diferentes):
  pof_*        Ipea TD 2823 (POF 2017-2018), decimos de renda familiar per capita da populacao,
               tributos diretos (renda, contribuicao previdenciaria, IPTU, IPVA) e indiretos.
  rfb_*        RFB, Distribuicao da Renda por Centis, AC 2023 e AC 2024, tabela V (ordenada por RB4):
               imposto devido no ajuste / RB4, por decimo, centil e milesimo dos declarantes.
  spe_*        SPE/MF, relatorio IRPF 2023 (AC 2023) e estudo do PL 1087/2025 (AC 2022):
               aliquota efetiva de IRPF com imputacao do imposto exclusivo na fonte.
  ipea_irpf_irpj_*  Ipea Carta de Conjuntura 65, nota 8 (Gobetti, 2024), AC 2022:
               IRPF + IRPJ/CSLL imputado aos socios, cenarios de repasse.

Nenhum numero digitado a mao: valores publicados sao extraidos do texto dos PDFs por expressao
regular (o script falha se o texto mudar); valores calculados vem das planilhas da RFB e dizem
"derivado:" na nota. Idempotente.

Rodar de fora das pastas de dados:  python3 -I brutos/T/build_T.py
Dependencias: openpyxl (~/.local/lib/python3.12/site-packages) e pymupdf (~/.local/lib/pdftools).
"""
import csv
import os
import re
import sys
import warnings

warnings.filterwarnings('ignore')
HOME = os.path.expanduser('~')
for p in [os.path.join(HOME, '.local/lib/python3.12/site-packages'),
          os.path.join(HOME, '.local/lib/pdftools')]:
    if os.path.isdir(p) and p not in sys.path:
        sys.path.append(p)
import openpyxl  # noqa: E402
import pymupdf  # noqa: E402

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
P = lambda *a: os.path.join(AQUI, *a)
SAIDA = os.path.join(RAIZ, 'T-incidencia-tributaria.csv')
COLS = ['serie', 'faixa', 'ano', 'valor', 'unidade', 'fonte_url', 'pagina_ou_tabela', 'nota']

# fonte_url = endereco oficial do documento (para os da SPE, retirados do ar, o original gov.br;
# o arquivo veio do Wayback Machine com digest identico ao servido pelo gov.br, ver LEIAME)
FONTE = {}
with open(P('downloads.tsv'), encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        FONTE[r['arquivo']] = r['url_oficial']

linhas = []


def add(serie, faixa, ano, valor, unidade, arq, onde, nota):
    if isinstance(valor, float):
        valor = f'{valor:.4f}'.rstrip('0').rstrip('.')
    linhas.append(dict(serie=serie, faixa=faixa, ano=ano, valor=valor, unidade=unidade,
                       fonte_url=FONTE[arq], pagina_ou_tabela=onde, nota=nota))


def pdf_paginas(arq):
    d = pymupdf.open(P(arq))
    return [pg.get_text() for pg in d]


def plano(t):
    t = t.replace('­', '').replace(' ', ' ')
    return re.sub(r'\s+', ' ', t)


def num(s):
    return float(s.replace('.', '').replace(',', '.')) if ',' in s else float(s)


def achar(texto, padrao, onde):
    m = re.search(padrao, texto)
    if not m:
        sys.exit(f'padrao nao encontrado em {onde}: {padrao}')
    return m


# ------------------------------------------------------------ 1. POF, Ipea TD 2823
ARQ = 'fazenda-rt/tributacao-indireta-aliquotas-efetivas-e-incidencia-sobre-as-familias.pdf'
pags = pdf_paginas(ARQ)
ip = [i for i, t in enumerate(pags) if 'GRÁFICO 3' in t and 'Impostos diretos' in t]
assert len(ip) == 1, 'grafico 3 nao localizado'
ip = ip[0]
bloco = pags[ip].split('GRÁFICO 3', 1)[1].split('Décimos de renda', 1)[0]
nums = [num(x) for x in re.findall(r'\b\d{1,2},\d\b', bloco)]
# 11 diretos (decimos 1..10 + media), 11 indiretos, depois o eixo 0,0 5,0 ...
diretos, indiretos = nums[0:11], nums[11:22]
assert nums[22] == 0.0, f'leitura do grafico 3 desalinhada: {nums[:25]}'
txt = plano(' '.join(pags[ip - 2:ip + 1]))
tot_d1 = num(achar(txt, r'10% mais pobres alcançando (\d+,\d)%', 'TD2823 p25').group(1))
tot_d10 = num(achar(txt, r'10% mais ricos os tributos representam (\d+,\d)%', 'TD2823 p25').group(1))
assert abs(diretos[0] + indiretos[0] - tot_d1) < 0.05 and abs(diretos[9] + indiretos[9] - tot_d10) < 0.05
pg3 = f'TD 2823, p. {ip + 1}, grafico 3'
BASE_POF = ('POF 2017-2018 (IBGE), decimos de renda familiar per capita de toda a populacao; '
            'denominador = renda total da familia (monetaria + nao monetaria); ')
DIR = ('inclui: tributos diretos lidos na POF como deducao da renda (IRPF, contribuicao '
       'previdenciaria do trabalhador e outras deducoes, em parte agregadas) e tributos sobre o '
       'patrimonio pagos pela familia (imoveis e automoveis: IPTU, IPVA); exclui: IRPJ/CSLL das '
       'empresas, contribuicao patronal e ITCMD, que o TD nao lista; '
       'a POF subdeclara renda no topo, entao o decimo 10 nao representa o 1% ou 0,1% mais rico')
IND = ('inclui: ICMS, IPI, PIS/Cofins, ISS e demais tributos sobre bens e servicos, por aliquotas '
       'efetivas da matriz insumo-produto 2015 (ja descontam informalidade, evasao e elisao) '
       'aplicadas a despesa monetaria de consumo; incidencia suposta: 100% no consumidor final; '
       'exclui: tributos sobre investimento e exportacao, IRPJ/CSLL, contribuicao patronal')
rot = [f'decimo {i}' for i in range(1, 11)] + ['media']
for i, r in enumerate(rot):
    add('pof_tributos_diretos_pct_renda_total', r, '2017-2018', diretos[i], '% da renda total',
        ARQ, pg3, BASE_POF + DIR + '; Ipea (fonte oficial secundaria), copia hospedada pela SERT/MF')
for i, r in enumerate(rot):
    add('pof_tributos_indiretos_pct_renda_total', r, '2017-2018', indiretos[i], '% da renda total',
        ARQ, pg3 + ' (mesmos valores no grafico 2)', BASE_POF + IND
        + '; Ipea (fonte oficial secundaria), copia hospedada pela SERT/MF')
for i, r in enumerate(rot):
    add('pof_tributos_total_pct_renda_total', r, '2017-2018', round(diretos[i] + indiretos[i], 1),
        '% da renda total', ARQ, pg3,
        'derivado: diretos + indiretos do mesmo grafico, mesma base e mesmo ano (somaveis); o texto '
        f'da p. {ip + 1} confirma {tot_d1} no decimo 1 e {tot_d10} no decimo 10; ' + BASE_POF
        + 'inclui renda, consumo e patrimonio da familia; exclui IRPJ/CSLL atribuido a socios, '
        'contribuicao patronal e ITCMD')
# sensibilidade ao denominador (texto da secao 4)
m = achar(txt := plano(' '.join(pags)), r'primeiro décimo de renda é de (\d+,\d+)% de sua renda monetária e, '
          r'para o décimo mais rico, (\d+,\d+)%.*?incidências em (\d+,\d+)% e (\d+,\d+)% da renda total',
          'TD2823 secao 4')
ipg = [i for i, t in enumerate(pags) if '42,66%' in t][0] + 1
for faixa, v, base in [('decimo 1', m.group(1), 'renda monetaria'), ('decimo 10', m.group(2), 'renda monetaria'),
                       ('decimo 1', m.group(3), 'renda total'), ('decimo 10', m.group(4), 'renda total')]:
    add('pof_tributos_indiretos_sensibilidade_denominador', faixa, '2017-2018', num(v), f'% da {base}',
        ARQ, f'TD 2823, p. {ipg}, texto', 'mesmos tributos indiretos da serie pof_tributos_indiretos, '
        f'com denominador = {base}; mostra que o grau de regressividade depende do denominador '
        '(sobre a despesa de consumo a incidencia e quase proporcional, grafico 1); ' + IND)

# ------------------------------------------------------------ 2. RFB, centis AC 2023 e AC 2024
RFB = [('rfb/centis-br-ac2023-versao-nov-2025.xlsx', '2023'), ('rfb/centis-br-ac2024.xlsx', '2024')]
for arq, ano in RFB:
    wb = openpyxl.load_workbook(P(arq), read_only=True, data_only=True)
    ws = wb['BRV']
    rows = list(ws.iter_rows(values_only=True))
    assert 'RB4' in str(rows[3][1]), 'aba BRV nao e a tabela ordenada por RB4'
    h4, h5 = rows[4], rows[5]
    col = lambda hdr, nome: [j for j, c in enumerate(hdr) if c and str(c).strip() == nome][0]
    c_cent, c_qtd = col(h4, 'Centil'), col(h4, 'Quantidade de Contribu intes')
    c_rb4, c_imp = col(h5, 'Soma de RB4 do Centil'), col(h4, 'Imposto Devido')
    c_div, c_simp = col(h5, 'Lucros e dividendos'), col(h5, 'Rendim. Sócio/Titular ME/EPP Opt SIMPLES')
    excl = [col(h5, n) for n in ['13º salário', 'Rendimentos de Aplicações Financeiras',
                                 'Ganhos de Capital na Alienação de Bens/Direitos',
                                 'Participação nos Lucros ou Resultados',
                                 'Rendimentos Recebidos Acumuladamente', 'Ganhos Líquidos em Renda Variável',
                                 'Juros sobre Capital Próprio', 'Outros']]
    dado = {}
    for r in rows[7:]:
        if isinstance(r[c_cent], (int, float)):
            dado[int(r[c_cent])] = r
    assert sorted(dado) == list(range(1, 121)), 'esperados centis 1..100, milesimos 101..110, 111..120'
    # conferencias de estrutura: 101..110 somam o centil 100; 111..120 somam o milesimo 110
    soma = lambda ks, c: sum(float(dado[k][c] or 0) for k in ks)
    assert abs(soma(range(101, 111), c_qtd) - dado[100][c_qtd]) <= 1
    assert abs(soma(range(111, 121), c_qtd) - dado[110][c_qtd]) <= 1
    assert abs(soma(range(101, 111), c_rb4) / dado[100][c_rb4] - 1) < 1e-6
    tot_q = soma(range(1, 101), c_qtd)
    grupos = [(f'decimo {d} dos declarantes', range(10 * d - 9, 10 * d + 1)) for d in range(1, 11)]
    grupos += [('1% mais rico dos declarantes (centil 100)', [100]),
               ('0,1% mais rico dos declarantes (milesimo 1000)', [110]),
               ('0,01% mais rico dos declarantes', [120])]
    onde = (f'{os.path.basename(arq)}, aba BRV (Tabela V, centis ordenados por RB4), colunas '
            '"Soma de RB4 do Centil" e "Imposto Devido"')
    for faixa, ks in grupos:
        rb4, imp = soma(ks, c_rb4), soma(ks, c_imp)
        ex = sum(soma(ks, c) for c in excl)
        dv = soma(ks, c_div) + soma(ks, c_simp)
        nota = (f'derivado: soma do Imposto Devido / soma da RB4 do grupo; {int(tot_q):,} declarantes '
                'no total'.replace(',', '.') + '; universo = declarantes do IRPF, nao a populacao '
                '(o decimo 1 dos declarantes inclui quem declara so por patrimonio, com renda perto de zero); '
                'RB4 = rendimentos tributaveis + isentos + exclusivos, menos doacoes e herancas; '
                'inclui: IRPF do ajuste anual (tabela progressiva, mais RRA); exclui: IR retido '
                'exclusivamente na fonte (13o, aplicacoes, ganho de capital, renda variavel, JCP, PLR), '
                'que a tabela nao traz, logo e piso da aliquota efetiva de IRPF; exclui IRPJ/CSLL, '
                'consumo e patrimonio')
        if ano == '2023':
            nota += ('; AC 2023 tem renda exclusiva inflada pela Lei 14.754/2023 (atualizacao de bens no '
                     'exterior a 8% e come-cotas de fundos fechados), fluxo nao recorrente que a SPE '
                     'substituiu por valores de 2022 no relatorio de 2025; no topo isso infla a RB4 e '
                     'baixa a razao, prefira AC 2024 para o topo')
        add('rfb_irpf_ajuste_pct_rb4', faixa, ano, round(100 * imp / rb4, 2) if rb4 else '',
            '% da RB4', arq, onde, nota)
        add('rfb_rendimento_exclusivo_pct_rb4', faixa, ano, round(100 * ex / rb4, 2) if rb4 else '',
            '% da RB4', arq, onde.replace('"Imposto Devido"', 'de rendimentos sujeitos a tributacao '
                                          'exclusiva/definitiva'),
            'derivado: soma dos oito rendimentos exclusivos / RB4; mostra a parte da renda cujo IR '
            'nao aparece no Imposto Devido (retido na fonte, em geral 15% a 22,5%, ou 0% a 15% em '
            'renda variavel); universo = declarantes')
        add('rfb_lucros_dividendos_simples_pct_rb4', faixa, ano, round(100 * dv / rb4, 2) if rb4 else '',
            '% da RB4', arq, onde.replace('"Imposto Devido"', '"Lucros e dividendos" e "Rendim. Sócio/'
                                          'Titular ME/EPP Opt SIMPLES"'),
            'derivado: (lucros e dividendos + rendimento isento de socio do Simples) / RB4; renda isenta '
            'na pessoa fisica, tributada (ou nao) apenas na empresa; universo = declarantes')

# ------------------------------------------------------------ 3. SPE/MF
ARQ = 'spe/relatorio-distribuicao-renda-2025.pdf'
pags = pdf_paginas(ARQ)
ipg = [i for i, t in enumerate(pags) if 'Figura 4' in t and 'centésimo 93' in t][0]
t = plano(pags[ipg])
m93 = achar(t, r'centésimo 93, que pagou (\d+,\d)%', 'SPE 2025')
m001 = achar(t, r'até atingir (\d+,\d)% referente ao 0,01% mais rico', 'SPE 2025')
achar(t, r'1% mais ricos pagaram, em 2023, alíquota efetiva muito próxima àquela paga pelos declarantes '
      r'que se situaram próximos ao centésimo 64', 'SPE 2025')
SPE = ('universo = declarantes do IRPF (DIRPF 2024), centis da RFB ordenados por RB4; '
       'aliquota = (imposto devido + IR imputado aos rendimentos exclusivos: 13o pela aliquota do '
       'estrato, 15% em aplicacoes, ganho de capital, renda variavel e JCP, tabela progressiva na PLR) '
       '/ renda bruta estimada; inclui: IRPF do ajuste e o retido na fonte imputado; exclui: IRPJ/CSLL, '
       'consumo, patrimonio e contribuicao previdenciaria')
add('spe_irpf_aliquota_efetiva', 'centil 93 dos declarantes (pico)', '2023', num(m93.group(1)), '% da renda bruta',
    ARQ, f'SPE/MF, Relatorio da Distribuicao Pessoal da Renda e da Riqueza, Dados do IRPF 2023, p. {ipg + 1}, texto da figura 4', SPE)
add('spe_irpf_aliquota_efetiva', '0,01% mais rico dos declarantes', '2023', num(m001.group(1)), '% da renda bruta',
    ARQ, f'idem, p. {ipg + 1}', SPE + '; o texto diz que o 1% mais rico pagou aliquota proxima a do '
    'centil 64, sem dar o numero; o valor por centil so existe no grafico')

ARQ = 'spe/estudo-spf-spe-pl-1087-2025-irpf.pdf'
pags = pdf_paginas(ARQ)
ipg = [i for i, t in enumerate(pags) if '8,54%' in t][0]
t = plano(pags[ipg])
mpico = achar(t, r'cresce até o centésimo 94 \(grupo com renda média mensal de R\$ ([\d.]+,\d+)\), atingindo (\d+)%', 'SPE PL1087')
m07 = achar(t, r'chegando a (\d+,\d+)% a partir dos 0,7% declarantes mais ricos', 'SPE PL1087')
m001 = achar(t, r'a (\d+,\d+)% para os 0,01% mais ricos', 'SPE PL1087')
mref = achar(plano(' '.join(pags)), r'entre (\d+,\d+)% e (\d+,\d+)%, considerando a média de rendimentos em cada milésimo', 'SPE PL1087')
SPE2 = SPE.replace('DIRPF 2024', 'DIRPF 2023') + '; mesmo metodo do relatorio de 2025, um ano antes'
onde = f'SPE/SPF/MF, Impactos da reforma do IRPF proposta no PL 1.087/2025, p. {ipg + 1}, secao 3.1'
ipg2 = [i for i, t in enumerate(pags) if '9,14%' in plano(t)][-1]
add('spe_irpf_aliquota_efetiva', 'centil 94 dos declarantes (pico)', '2022', num(mpico.group(2)), '% da renda bruta', ARQ, onde,
    SPE2 + f'; renda media mensal do centil R$ {mpico.group(1)}')
add('spe_irpf_aliquota_efetiva', '0,7% mais rico dos declarantes', '2022', num(m07.group(1)), '% da renda bruta', ARQ, onde,
    SPE2 + '; o texto diz "a partir dos 0,7%", isto e, o nivel ao entrar no grupo afetado pelo imposto minimo')
add('spe_irpf_aliquota_efetiva', '0,01% mais rico dos declarantes', '2022', num(m001.group(1)), '% da renda bruta', ARQ, onde, SPE2)
for k, faixa in [(1, 'milesimos do 0,7% mais rico, minimo'), (2, 'milesimos do 0,7% mais rico, maximo')]:
    add('spe_irpf_aliquota_efetiva_com_lei_15270', faixa, '2022 (simulado)', num(mref.group(k)), '% da renda bruta', ARQ, onde.replace(f'p. {ipg + 1}', f'p. {ipg2 + 1}'),
        SPE2 + '; simulacao do PL 1087/2025 completo (isencao ate R$ 5 mil e imposto minimo de ate 10%) sobre a renda de 2022; '
        'nao e dado observado; o texto aprovado (Lei 15.270/2025) mudou detalhes, como excluir dividendos apurados ate 2025')

# ------------------------------------------------------------ 4. Ipea, IRPF + IRPJ/CSLL imputado
ARQ = 'ipea/cc65-nota8.pdf'
pags = pdf_paginas(ARQ)
ipg = [i for i, t in enumerate(pags) if 'GRÁFICO 2' in t][0]
t = plano(pags[ipg])
mmax = achar(t, r'ponto máximo \((\d+,\d)%\) no 98º percentil.*?caindo para (\d+,\d)% no último percentil', 'CC65')
mmed = achar(t, r'o ponto máximo é atingido no 97º percentil \((\d+,\d)%\).*?a alíquota cai para (\d+,\d)% no último percentil '
             r'\(e (\d+,\d)% no milésimo mais rico', 'CC65')
mpj = achar(t, r'média pon ?derada de (\d+,\d)% de tributação sobre os lucros dos regimes de Lucro Real e Presumido', 'CC65')
msi = achar(t, r'Simples Nacional, por sua vez, adotamos uma alíquota efetiva .*?: (\d+,\d)%', 'CC65')
IPEA = ('universo = declarantes do IRPF de 2022 (tabulacoes especiais da RFB por percentil e milesimo); '
        'inclui: IRPF devido + IR retido exclusivamente na fonte (imputado) + IRPJ/CSLL imputado aos '
        f'dividendos recebidos, a {mpj.group(1)}% sobre lucros de Real e Presumido e {msi.group(1)}% '
        'sobre os do Simples (cargas efetivas do Tax Gap da RFB); exclui: consumo, patrimonio, '
        'contribuicao previdenciaria e o IRPJ de lucro retido na empresa; Ipea, fonte oficial '
        'secundaria (nota de pesquisador, nao posicao do governo)')
onde = f'Ipea, Carta de Conjuntura 65, nota 8 (Gobetti, 29/10/2024), p. {ipg + 1}, texto do grafico 2'
MAX = '; cenario maximo: 100% do IRPJ/CSLL das empresas recai sobre o socio'
MED = ('; cenario intermediario: 100% do IRPJ/CSLL do Simples e 50% do de Real/Presumido recaem '
       'sobre o socio, o resto vai a trabalhadores e precos (o autor o considera o mais realista)')
add('ipea_irpf_irpj_imputado_cenario_maximo', 'percentil 98 dos declarantes (pico)', '2022', num(mmax.group(1)), '% da renda', ARQ, onde, IPEA + MAX)
add('ipea_irpf_irpj_imputado_cenario_maximo', '1% mais rico dos declarantes (ultimo percentil)', '2022', num(mmax.group(2)), '% da renda', ARQ, onde, IPEA + MAX)
add('ipea_irpf_irpj_imputado_cenario_intermediario', 'percentil 97 dos declarantes (pico)', '2022', num(mmed.group(1)), '% da renda', ARQ, onde, IPEA + MED)
add('ipea_irpf_irpj_imputado_cenario_intermediario', '1% mais rico dos declarantes (ultimo percentil)', '2022', num(mmed.group(2)), '% da renda', ARQ, onde, IPEA + MED)
add('ipea_irpf_irpj_imputado_cenario_intermediario', '0,1% mais rico dos declarantes (milesimo do topo)', '2022', num(mmed.group(3)), '% da renda', ARQ, onde, IPEA + MED)
add('ipea_irpf_irpj_imputado_cenario_minimo', '1% e 0,1% mais ricos dos declarantes', '2022', '', '% da renda', ARQ, onde,
    'nao encontrado: o cenario minimo (so o IRPJ/CSLL do Simples recai sobre o socio) aparece apenas como curva do grafico 2, sem numero no texto')

# ------------------------------------------------------------ lacunas declaradas
add('fazenda_incidencia_consumo_por_decil', 'decimos', '', '', '', 'fazenda-rt/tributacao-indireta-aliquotas-efetivas-e-incidencia-sobre-as-familias.pdf',
    'nao encontrado',
    'nao encontrado: nenhuma nota tecnica da SERT/MF ou da SRE/MF com incidencia atual do consumo por decimo da POF; '
    'a pagina de estudos da reforma tributaria do MF hospeda o TD 2823 do Ipea (usado aqui), estudos do CCiF, UFMG e Banco Mundial, '
    'e as notas da SERT tratam da aliquota padrao e da cesta basica, nao da incidencia por decimo')
add('total_renda_consumo_patrimonio_irpj_topo', '1% e 0,1% mais ricos', '', '', '', 'ipea/cc65-nota8.pdf', 'nao encontrado',
    'nao encontrado: nenhuma fonte oficial soma consumo + renda + patrimonio + IRPJ imputado para o 1% ou 0,1% mais ricos; '
    'a POF nao alcanca esses grupos e as bases do IRPF nao trazem consumo; somar pof_* com ipea_* ou spe_* mistura populacao '
    'com declarantes, renda total da POF com renda bruta declarada e anos 2017-2018 com 2022-2023, por isso nao se soma')

with open(SAIDA, 'w', encoding='utf-8', newline='') as f:
    w = csv.DictWriter(f, fieldnames=COLS, lineterminator='\n')
    w.writeheader()
    w.writerows(linhas)
txt = open(SAIDA, encoding='utf-8').read()
assert chr(0x2014) not in txt and chr(0x2013) not in txt, 'travessao na saida'
print(f'{SAIDA}: {len(linhas)} linhas')

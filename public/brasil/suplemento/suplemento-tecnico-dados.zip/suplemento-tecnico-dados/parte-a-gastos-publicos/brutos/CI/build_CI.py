#!/usr/bin/env python3
# Frente CI, gasto publico com cultura (COFOG 708 e grupos) do Brasil contra o Canada e os paises da OCDE.
# Le so de brutos/CI/fontes/ (baixa_CI.py) e, para o Brasil, de C-governo-geral-cofog.csv (frente C, STN).
# Grava CI-cultura-internacional.csv e CI-resumo.csv na raiz de gastos-publicos/.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CI/build_CI.py
import csv, io, json, os, statistics, zipfile
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
P = lambda n: os.path.join(F, n)
ULT = 2024  # ultimo ano comum de Brasil (STN), Canada (StatCan) e da maioria da OCDE (Tabela 11)

U_T11 = 'https://sdmx.oecd.org/public/rest/data/OECD.SDD.NAD,DSD_NASEC10@DF_TABLE11,1.1/'
U_STN = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/27169'
U_SC = 'https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1010000501'
U_WB = 'https://api.worldbank.org/v2/country/all/indicator/NY.GDP.PCAP.PP.CD'

NOME = {'AUS': 'Austrália', 'AUT': 'Áustria', 'BEL': 'Bélgica', 'CAN': 'Canadá', 'CHE': 'Suíça', 'CHL': 'Chile', 'COL': 'Colômbia',
        'CRI': 'Costa Rica', 'CZE': 'Tchéquia', 'DEU': 'Alemanha', 'DNK': 'Dinamarca', 'ESP': 'Espanha', 'EST': 'Estônia', 'FIN': 'Finlândia',
        'FRA': 'França', 'GBR': 'Reino Unido', 'GRC': 'Grécia', 'HUN': 'Hungria', 'IRL': 'Irlanda', 'ISL': 'Islândia', 'ISR': 'Israel',
        'ITA': 'Itália', 'JPN': 'Japão', 'KOR': 'Coreia do Sul', 'LTU': 'Lituânia', 'LUX': 'Luxemburgo', 'LVA': 'Letônia', 'MEX': 'México',
        'NLD': 'Países Baixos', 'NOR': 'Noruega', 'NZL': 'Nova Zelândia', 'POL': 'Polônia', 'PRT': 'Portugal', 'SVK': 'Eslováquia',
        'SVN': 'Eslovênia', 'SWE': 'Suécia', 'TUR': 'Turquia', 'USA': 'Estados Unidos', 'BRA': 'Brasil', 'OCDE_MEDIANA': 'Mediana OCDE'}
SUB = {'708': '708 Lazer, cultura e religião (total)', '7081': '7081 Recreação e esporte', '7082': '7082 Serviços culturais',
       '7083': '7083 Rádio, TV e editoração', '7084': '7084 Religiosos e outros comunitários', '7085': '7085 P&D em lazer, cultura e religião',
       '7086': '7086 Lazer, cultura e religião n.e.', '7084_7086': '7084 a 7086 somados (708 menos 7081, 7082 e 7083)',
       '7082_7083': '7082 mais 7083 (cultura com rádio e TV públicas)'}
ORDEM = list(SUB)

# ---------- membros da OCDE: os 38 paises da Revenue Statistics (sem os agregados)
MEMBROS = sorted({r['REF_AREA'] for r in csv.DictReader(open(P('oecd_DF_RSOECD_membros.csv'), encoding='utf-8-sig'))} - {'OECD_REP', 'FEDOECD', 'UNIOECD'})
assert len(MEMBROS) == 38, len(MEMBROS)

# ---------- PIB por habitante em PPC (WDI)
PPC = {}
for r in json.load(open(P('wb_NY.GDP.PCAP.PP.CD.json')))[1]:
  if r['value'] is not None: PPC[(r['countryiso3code'], int(r['date']))] = r['value']

# ---------- OCDE, Tabela 11 (despesa por funcao, milhoes de moeda nacional) e Tabela 1 (PIB)
PIB = {}
for r in csv.DictReader(open(P('oecd_DF_TABLE1_B1GQ_XDC.csv'), encoding='utf-8-sig')):
  if r['OBS_VALUE'] == '': continue
  k = (r['REF_AREA'], int(r['TIME_PERIOD'])); assert r['UNIT_MULT'] == '6' and k not in PIB, k; PIB[k] = (float(r['OBS_VALUE']), r['CURRENCY'])
T11 = {}
for r in csv.DictReader(open(P('oecd_DF_TABLE11_GF08_XDC.csv'), encoding='utf-8-sig')):
  if r['OBS_VALUE'] == '': continue
  cod = '708' + r['EXPENDITURE'][4:].lstrip('0') if r['EXPENDITURE'] != 'GF08' else '708'
  k = (r['REF_AREA'], int(r['TIME_PERIOD']), cod); assert r['UNIT_MULT'] == '6' and k not in T11, k
  T11[k] = (float(r['OBS_VALUE']), r['CURRENCY'], r['OBS_STATUS'])
assert 'BRA' not in {k[0] for k in T11} and 'CAN' not in {k[0] for k in T11}

LIN = []  # (pais, ano, sub, valor_mi, moeda, pct, ppc, fonte, url, status, nota)
def poe(pais, ano, sub, v, moeda, pib, fonte, url, status, nota):
  pct = 100 * v / pib
  ppc = PPC.get((pais, ano)); ppc = pct / 100 * ppc if ppc is not None else None
  LIN.append([pais, ano, sub, v, moeda, pct, ppc, fonte, url, status, nota])

def derivados(d, pais, ano, moeda, pib, fonte, url, nota):
  # d: {sub: valor}; 7084_7086 = residuo; 7082_7083 = soma
  if all(c in d for c in ('708', '7081', '7082', '7083')):
    poe(pais, ano, '7084_7086', d['708'] - d['7081'] - d['7082'] - d['7083'], moeda, pib, fonte, url, 'calculo', 'CALCULO: 708 menos 7081, 7082 e 7083. ' + nota)
  if '7082' in d and '7083' in d:
    poe(pais, ano, '7082_7083', d['7082'] + d['7083'], moeda, pib, fonte, url, 'calculo', 'CALCULO: 7082 mais 7083. ' + nota)

N_OCDE = 'OCDE Tabela 11 (SNA 2008, governo geral S13, despesa total OTE, competencia) dividida pelo PIB da OCDE Tabela 1; PPC = % do PIB vezes PIB por habitante em PPC do WDI'
for pais in sorted({k[0] for k in T11} & set(MEMBROS)):
  for ano in sorted({k[1] for k in T11 if k[0] == pais}):
    if (pais, ano) not in PIB: continue
    pib, moeda = PIB[(pais, ano)]; d = {}
    for sub in ('708', '7081', '7082', '7083', '7084', '7085', '7086'):
      if (pais, ano, sub) in T11:
        v, m, st = T11[(pais, ano, sub)]; assert m == moeda, (pais, ano, m, moeda); d[sub] = v
        poe(pais, ano, sub, v, moeda, pib, 'OCDE', U_T11, {'A': 'normal', 'P': 'provisorio', 'E': 'estimado', 'B': 'quebra de serie'}.get(st, st), N_OCDE)
    derivados(d, pais, ano, moeda, pib, 'OCDE', U_T11, N_OCDE)

# ---------- Canada, StatCan 10-10-0005 (governo geral canadense consolidado) e 36-10-0222 (PIB)
def zcsv(zipnome, csvnome):
  z = zipfile.ZipFile(P(zipnome)); return csv.DictReader(io.TextIOWrapper(z.open(csvnome), encoding='utf-8-sig'))
PIB_CA = {int(r['REF_DATE']): float(r['VALUE']) for r in zcsv('statcan_36100222.zip', '36100222.csv')
          if r['GEO'] == 'Canada' and r['Prices'] == 'Current prices' and r['Estimates'] == 'Gross domestic product at market prices' and r['VALUE']}
MAP_CA = {'[708]': '708', '[7081]': '7081', '[7082]': '7082', '[7083]': '7083'}
CA = {}
for r in zcsv('statcan_10100005.zip', '10100005.csv'):
  c = r['Canadian Classification of Functions of Government (CCOFOG)']
  if r['GEO'] == 'Canada' and r['Public sector components'] == 'Consolidated Canadian general government' and r['VALUE']:
    for tag, sub in MAP_CA.items():
      if c.endswith(tag):
        assert r['SCALAR_FACTOR'] == 'millions'; CA.setdefault(int(r['REF_DATE']), {})[sub] = float(r['VALUE'])
    if c.endswith('[7084, 7085, 7086]'): CA.setdefault(int(r['REF_DATE']), {})['7084_7086_sc'] = float(r['VALUE'])
N_CA = ('StatCan 10-10-0005 (CCOFOG, governo geral canadense consolidado, exercicio que termina mais perto de 31/12, sem aquisicao de ativo '
        'nao financeiro e sem consumo de capital fixo, sem CPP e QPP) dividida pelo PIB a precos correntes da StatCan 36-10-0222; '
        'PPC = % do PIB vezes PIB por habitante em PPC do WDI')
for ano in sorted(CA):
  d = CA[ano]; pib = PIB_CA[ano]
  for sub in ('708', '7081', '7082', '7083'):
    poe('CAN', ano, sub, d[sub], 'CAD', pib, 'StatCan', U_SC, 'normal', N_CA)
  poe('CAN', ano, '7084_7086', d['7084_7086_sc'], 'CAD', pib, 'StatCan', U_SC, 'normal',
      'StatCan publica 7084, 7085 e 7086 numa linha so ("not elsewhere classified [7084, 7085, 7086]"). ' + N_CA)
  assert abs(d['708'] - d['7081'] - d['7082'] - d['7083'] - d['7084_7086_sc']) <= 2, ano  # arredondamento da StatCan
  poe('CAN', ano, '7082_7083', d['7082'] + d['7083'], 'CAD', pib, 'StatCan', U_SC, 'calculo', 'CALCULO: 7082 mais 7083. ' + N_CA)

# ---------- Brasil, frente C (STN, COFOG do governo geral consolidado), sem recalculo
BR = {}; BR_PCT_STN = {}
for r in csv.DictReader(open(os.path.join(RAIZ, 'C-governo-geral-cofog.csv'), encoding='utf-8')):
  if r['estagio'] != 'despesa_competencia_cofog': continue
  a = int(r['ano']); s = r['subcategoria']
  if r['categoria'] == '7 Despesa total' and s == 'Governo Geral consolidado': BR.setdefault(a, {})['total'] = (float(r['valor_brl']), float(r['pct_pib']))
  if r['categoria'].startswith('708 '):
    if s == 'Governo Geral consolidado': sub = '708'
    elif s.startswith('grupo 708') and s.endswith('| Governo Geral consolidado'): sub = s.split()[1]
    else: continue
    BR.setdefault(a, {})[sub] = float(r['valor_brl']) / 1e6; BR_PCT_STN[(a, sub)] = float(r['pct_pib'])
N_BR = ('STN, COFOG do governo geral consolidado (frente C, C-governo-geral-cofog.csv), competencia = liquidado mais RP nao processados '
        'pagos; PIB implicito da STN (despesa total sobre a % do PIB da propria STN); PPC = % do PIB vezes PIB por habitante em PPC do WDI')
for ano in sorted(BR):
  d = BR[ano]; tv, tp = d.pop('total'); pib = tv / 1e6 / (tp / 100)
  for sub in ('708', '7081', '7082', '7083', '7084', '7085', '7086'):
    poe('BRA', ano, sub, d[sub], 'BRL', pib, 'STN (frente C)', U_STN, 'normal', N_BR)
    assert abs(round(LIN[-1][5], 3) - BR_PCT_STN[(ano, sub)]) <= 0.001, (ano, sub, LIN[-1][5], BR_PCT_STN[(ano, sub)])
  derivados(d, 'BRA', ano, 'BRL', pib, 'STN (frente C)', U_STN, N_BR)

# ---------- mediana dos membros da OCDE na Tabela 11, por ano e subgrupo (composicao varia com o ano)
IDX = {(l[0], l[1], l[2]): l for l in LIN}
MED = {}
for ano in sorted({l[1] for l in LIN}):
  for sub in ORDEM:
    xs = [l for l in LIN if l[1] == ano and l[2] == sub and l[7] == 'OCDE']
    if len(xs) < 10: continue
    mp = statistics.median(l[5] for l in xs); pp = [l[6] for l in xs if l[6] is not None]
    mu = statistics.median(pp) if len(pp) >= 10 else None
    MED[(ano, sub)] = (mp, mu, len(xs), sorted(l[0] for l in xs))
    LIN.append(['OCDE_MEDIANA', ano, sub, None, '', mp, mu, 'OCDE (calculo)', U_T11, 'calculo',
                f'CALCULO: mediana simples de {len(xs)} membros da OCDE com dado na Tabela 11 neste ano ({" ".join(sorted(l[0] for l in xs))}); '
                'sem Canada, Mexico, Nova Zelandia e Turquia, que nao reportam COFOG a OCDE'])

f3 = lambda x: '' if x is None else f'{x:.3f}'
f1 = lambda x: '' if x is None else f'{x:.1f}'
LIN.sort(key=lambda l: (l[0] != 'BRA', l[0] != 'CAN', l[0] != 'OCDE_MEDIANA', l[0], l[1], ORDEM.index(l[2])))
with open(os.path.join(RAIZ, 'CI-cultura-internacional.csv'), 'w', newline='', encoding='utf-8') as fo:
  w = csv.writer(fo, lineterminator='\n')
  w.writerow(['frente', 'pais', 'pais_nome', 'ano', 'subgrupo', 'subgrupo_nome', 'valor_moeda_nacional_mi', 'moeda', 'pct_pib',
              'usd_ppc_por_habitante', 'fonte', 'fonte_url', 'status', 'nota'])
  for p, a, s, v, m, pct, ppc, fo_, u, st, n in LIN:
    w.writerow(['CI', p, NOME[p], a, s, SUB[s], '' if v is None else f'{v:.2f}', m, f3(pct), f1(ppc), fo_, u, st, n])

# ---------- resumo do ultimo ano comum
RES = []
def rank(sub, campo, extra):
  xs = [l for l in LIN if l[1] == ULT and l[2] == sub and l[7] == 'OCDE' and l[campo] is not None]
  base = xs + [IDX[(p, ULT, sub)] for p in extra if (p, ULT, sub) in IDX and IDX[(p, ULT, sub)][campo] is not None]
  base.sort(key=lambda l: -l[campo]); return base, len(xs)
for sub in ('708', '7081', '7082', '7083', '7084_7086', '7082_7083'):
  for campo, ind, fmt in ((5, 'pct_pib', f3), (6, 'usd_ppc_por_habitante', f1)):
    base, n = rank(sub, campo, ('BRA', 'CAN'))
    pos = {l[0]: i + 1 for i, l in enumerate(base)}
    br = IDX[('BRA', ULT, sub)][campo]; ca = IDX[('CAN', ULT, sub)][campo]
    xs = [l[campo] for l in base if l[0] not in ('BRA', 'CAN')]
    med = statistics.median(xs); med_ca = statistics.median(xs + [ca])
    ab = sum(1 for x in xs if x < br)
    mx = max(base, key=lambda l: l[campo]); mn = min(base, key=lambda l: l[campo])
    RES.append(['CI', ULT, sub, SUB[sub], ind, fmt(br), fmt(ca), fmt(med), fmt(med_ca), n, f'{pos["BRA"]} de {len(base)}',
                f'{pos["CAN"]} de {len(base)}', ab, f'{br / med:.2f}', f'{mx[0]} {fmt(mx[campo])}', f'{mn[0]} {fmt(mn[campo])}',
                'A: medido (fontes oficiais) e calculo; posicao 1 = maior valor; conjunto = membros da OCDE com dado na Tabela 11 em '
                f'{ULT} mais Brasil e Canada; mediana sem Canada (fonte e conceito diferentes) e com Canada ao lado'])
with open(os.path.join(RAIZ, 'CI-resumo.csv'), 'w', newline='', encoding='utf-8') as fo:
  w = csv.writer(fo, lineterminator='\n')
  w.writerow(['frente', 'ano', 'subgrupo', 'subgrupo_nome', 'indicador', 'brasil', 'canada', 'mediana_ocde', 'mediana_ocde_com_canada',
              'n_paises_ocde_tabela11', 'posicao_brasil', 'posicao_canada', 'paises_ocde_abaixo_do_brasil', 'brasil_sobre_mediana',
              'maior', 'menor', 'classe_e_nota'])
  w.writerows(RES)

# ---------- conferencias (so imprime)
g = {}
for r in csv.DictReader(open(P('oecd_DF_GOV_COFOG_YU_GF08_pctpib.csv'), encoding='utf-8-sig')):
  if r['OBS_VALUE']: g[(r['REF_AREA'], int(r['TIME_PERIOD']))] = float(r['OBS_VALUE'])
dif = sorted((abs(IDX[(p, a, '708')][5] - v), p, a) for (p, a), v in g.items() if (p, a, '708') in IDX)
print('GaaG x Tabela11/Tabela1, 708: pares', len(dif), 'dif media', round(sum(x[0] for x in dif) / len(dif), 4), 'maiores', [(p, a, round(x, 3)) for x, p, a in dif[-5:]])
print('GaaG 2024 OECD (agregado) e OECD_REP:', g.get(('OECD', ULT)), g.get(('OECD_REP', ULT)))
print('BRA na OCDE: Tabela 11', 'BRA' in {k[0] for k in T11}, '| GaaG', 'BRA' in {k[0] for k in g})
print('PIB OCDE x StatCan, Canada 2024:', PIB.get(('CAN', ULT)), PIB_CA[ULT])
for k, v in sorted(MED.items()):
  if k[0] == ULT: print('mediana', k, round(v[0], 3), v[1] and round(v[1], 1), v[2])
WBV = {}
for nome in ('wb_PA.NUS.PPP.json', 'wb_SP.POP.TOTL.json'):
  for r in json.load(open(P(nome)))[1]:
    if r['value'] is not None: WBV[(nome[3:-5], r['countryiso3code'], int(r['date']))] = r['value']
POP_CA = {int(r['REF_DATE'][:4]): float(r['VALUE']) for r in zcsv('statcan_17100009.zip', '17100009.csv')
          if r['GEO'] == 'Canada' and r['REF_DATE'].endswith('-07-01') and r['VALUE']}
for pais, sub in (('BRA', '7082'), ('CAN', '7082'), ('BRA', '708'), ('CAN', '708')):
  l = IDX[(pais, ULT, sub)]; pop = WBV[('SP.POP.TOTL', pais, ULT)]; ppp = WBV[('PA.NUS.PPP', pais, ULT)]
  print('conferencia PPC', pais, sub, 'pct x PIBpc PPC =', round(l[6], 1), '| valor / pop WDI / PPC WDI =', round(l[3] * 1e6 / pop / ppp, 1),
        '| moeda nacional por habitante (pop WDI) =', round(l[3] * 1e6 / pop, 1), '| pop StatCan 1/7 =', round(l[3] * 1e6 / POP_CA[ULT], 1) if pais == 'CAN' else '')
print(len(LIN), 'linhas;', len(RES), 'linhas de resumo')

# Frente CI, cultura internacional

Feita em 24/10/2026. Atende a pendência "seção 10 com Canadá e mais países da OCDE em cultura". Compara o gasto público com lazer,
cultura e religião (COFOG 708) e seus grupos no Brasil, no Canadá e nos membros da OCDE, em % do PIB e em USD PPC por habitante.

## O que entra

- `CI-cultura-internacional.csv` (raiz de `gastos-publicos/`). Uma linha por país, ano e subgrupo. Subgrupos 708, 7081 (recreação e
  esporte), 7082 (serviços culturais), 7083 (rádio, TV e editoração), 7084 (religiosos e comunitários), 7085, 7086, mais dois cálculos,
  `7084_7086` (708 menos 7081, 7082 e 7083) e `7082_7083` (cultura com rádio e TV públicas). Valor em milhões de moeda nacional, % do PIB
  e USD PPC por habitante. Linhas `OCDE_MEDIANA` trazem a mediana simples dos membros com dado no ano, com a lista dos países na nota.
- `CI-resumo.csv`. Último ano comum (2024). Brasil, Canadá, mediana da OCDE (sem e com o Canadá), posição do Brasil e do Canadá,
  quantos membros ficam abaixo do Brasil, razão Brasil sobre mediana, maior e menor.

## Fontes

| país | despesa | PIB | período |
|---|---|---|---|
| membros da OCDE | OCDE, Tabela 11 (DSD_NASEC10@DF_TABLE11), governo geral S13, despesa total OTE, GF08 e GF0801 a GF0806, moeda nacional | OCDE, Tabela 1 (DF_TABLE1_EXPENDITURE), B1GQ, moeda nacional, preços correntes | 1990 (FIN, KOR, USA) ou 1995 a 2024 (LUX até 2025) |
| Canadá | StatCan 10-10-0005, "Consolidated Canadian general government", CCOFOG | StatCan 36-10-0222, PIB a preços de mercado, preços correntes | 2008 a 2024 |
| Brasil | frente C, `C-governo-geral-cofog.csv` (STN, COFOG do governo geral consolidado, 2024 publicada em 12/12/2025), sem recálculo | PIB implícito da STN (despesa total em R$ sobre a % do PIB da própria STN) | 2015 a 2024 |

USD PPC por habitante = % do PIB vezes o PIB por habitante em PPC do WDI (NY.GDP.PCAP.PP.CD, USD internacionais correntes, base ICP 2021,
atualização de 08/10/2026). A mesma regra para todos os países evita converter moedas antigas (pré-euro). Conferência para 2024 pelo outro
caminho (valor sobre população WDI sobre fator de PPC WDI): Brasil 7082 dá 48,6 contra 48,8, Canadá 178,1 nos dois.

Membros da OCDE = os 38 países da Revenue Statistics (DF_RSOECD), copiada da frente L. Bulgária, Croácia, Romênia e os agregados da UE
estão na Tabela 11 mas ficam fora por não serem membros.

Os brutos do Canadá (10-10-0005, 36-10-0222 e 17-10-0009) foram baixados da StatCan em 20/10/2026. A 10-10-0005 foi rebaixada em
24/10/2026 e o zip tem o mesmo sha256 (0ef8b51b...), então o arquivo continua atual. Tudo com URL e sha256 em `downloads.tsv`.

## Números-chave, 2024 (de `CI-resumo.csv`)

| | Brasil | Canadá | mediana OCDE | posição do Brasil |
|---|---:|---:|---:|---|
| 708 total, % PIB | 0,402 | 0,804 | 1,233 (32 países) | 31 de 34 |
| 708 total, USD PPC por habitante | 89,9 | 526,3 | 746,3 | 34 de 34 |
| 7082 serviços culturais, % PIB | 0,218 | 0,272 | 0,523 (30 países) | 29 de 32 |
| 7082, USD PPC por habitante | 48,8 | 178,1 | 368,4 | 31 de 32 |
| 7082 mais 7083, % PIB | 0,232 | 0,426 | 0,680 | 31 de 32 |
| 7083 rádio, TV e editoração, % PIB | 0,014 | 0,154 | 0,157 | 30 de 32 |

Classe A (medido em fonte oficial, mais aritmética). Abaixo do Brasil em 708 % do PIB ficam EUA (0,254), Chile (0,324) e Japão (0,390).
Em 7082 % do PIB, Irlanda (0,169), Grécia (0,173) e Colômbia (0,185). Por habitante em PPC o Brasil é o último em 708 e só a Colômbia
fica abaixo em 7082 (41,6). A conta de 21/10 da economia-brasil (Canadá 0,27% e C$ 205, 179 USD PPC; Brasil 0,22%, R$ 120, 48 USD PPC;
com rádio e TV 0,43% contra 0,23%) foi refeita aqui e bate, com 178,1 em vez de 179 no Canadá (WDI revisado em 08/10).

## Conferências

- **COFOG da OCDE para o Brasil não existe.** O Brasil não aparece na Tabela 11 nem no Government at a Glance (DF_GOV_COFOG_YU), consultados
  em 24/10/2026. Não há o que comparar com a STN. O Canadá, o México, a Nova Zelândia e a Turquia também não reportam COFOG à OCDE.
- Tabela 11 sobre Tabela 1 contra a % do PIB publicada no Government at a Glance (708, 592 pares país-ano): diferença média de 0,0013
  ponto, máxima de 0,03 (Dinamarca 2024), efeito de safra diferente do PIB.
- Brasil: o % do PIB recalculado com o PIB implícito bate com o `pct_pib` da STN na terceira casa em todos os anos e grupos (assert no build).
- Canadá: 708 menos 7081, 7082 e 7083 bate com a linha "7084, 7085, 7086" da StatCan (diferença de arredondamento até 2 milhões). O PIB
  da StatCan e o da Tabela 1 da OCDE para 2024 são iguais (C$ 3.108.551 mi).
- O Government at a Glance dá 0,7% para o agregado OCDE ponderado em 2024 (os EUA pesam muito e gastam 0,254%) e 1,246% para a média
  simples (OECD_REP). A mediana calculada aqui é 1,233%.

## Limites

- **Conceitos diferentes.** OCDE é SNA 2008, despesa total do governo geral (inclui investimento). STN é competência (liquidado mais RP não
  processados pagos), governo geral consolidado. A StatCan exclui aquisição de ativo não financeiro e consumo de capital fixo, não inclui
  CPP e QPP, e o ano é o exercício que termina mais perto de 31/12 (2024 = abril de 2024 a março de 2025) contra PIB do ano civil. Como a
  StatCan deixa o investimento de fora, o Canadá provavelmente está subestimado contra a OCDE. O tamanho disso não foi medido (classe C).
  Por isso a mediana principal não inclui o Canadá, que vai ao lado.
- O Brasil registra 7084 como zero em toda a série. O Canadá não separa 7084, 7085 e 7086, por isso o subgrupo comparável é `7084_7086`.
- Chile, EUA e Coreia só publicam o total 708, sem grupos. Costa Rica para em 2022 e Coreia em 2023, então ficam fora da mediana de 2024.
  A mediana de cada ano usa os membros com dado naquele ano (28 em 1995, 33 em 2015, 32 em 2024 no total 708). Composição variável.
- Valores provisórios ou estimados da OCDE aparecem na coluna `status`.
- Mede gasto, não resultado cultural. Renúncia fiscal (Rouanet, audiovisual) não é despesa e fica fora, aqui e na COFOG de todos os países.
- Ano e nome de governo só datam o valor. A alta do Brasil em 7082 de 0,109% (2021) para 0,218% (2024) é medida (A). Atribuir a uma lei
  ou a um governo exige outra análise e não está demonstrado aqui (C).
- Eurostat gov_10a_exp não foi usado. A Tabela 11 já cobre os membros europeus com os grupos.

## Licenças (páginas em `fontes/`)

- **OCDE**: os Termos e Condições permitem extrair, baixar, copiar, adaptar, distribuir e compartilhar os dados para qualquer fim, inclusive
  comercial, com crédito à OCDE pela citação do dado ou no formato "OECD (ano), (nome do dataset), (fonte) DOI ou URL (acessado em data)".
  Ressalva de dado de terceiros. Texto escrito desde 1/7/2024 é CC BY 4.0. Página lida pela cópia do Internet Archive de 17/10/2026
  (o site responde 403 sem navegador).
- **Statistics Canada**: Open Licence, uso, reprodução, distribuição e venda livres, com o aviso "Source: Statistics Canada, nome do
  produto, data de referência. Reproduced and distributed on an 'as is' basis with the permission of Statistics Canada" e, em produto de
  valor agregado, "Adapted from Statistics Canada...". Não sugerir endosso da StatCan.
- **Banco Mundial (WDI)**: CC BY-4.0, pelo metadado da série NY.GDP.PCAP.PP.CD (o Data Catalog respondeu 429 duas vezes).
- **STN**: segue a frente C.

## Como rodar

```
cd /tmp && python3 -I <pacote>/brutos/CI/baixa_CI.py   # uma requisição por vez, pausa de 3 s, não rebaixa o que existe
cd /tmp && python3 -I <pacote>/brutos/CI/build_CI.py   # grava os dois CSV e imprime as conferências
```

Rodado duas vezes em 24/10/2026, CSV idênticos (sha256 7f7729f6... e 97503ead...).

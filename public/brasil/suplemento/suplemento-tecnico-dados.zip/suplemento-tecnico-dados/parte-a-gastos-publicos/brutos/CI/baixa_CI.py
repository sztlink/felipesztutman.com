#!/usr/bin/env python3
# Frente CI, cultura internacional. Baixa a COFOG 708 da OCDE (Tabela 11), o PIB da OCDE (Tabela 1), o PIB por habitante em PPC,
# o fator de PPC e a populacao do Banco Mundial (WDI), o indicador de Government at a Glance para a 708 e as paginas de licenca.
# Baixa as tabelas da Statistics Canada e copia (sem editar) a lista de membros da OCDE da frente L, do mesmo pacote.
# Uma requisicao por vez, pausa de 3 s. Arquivo que ja existe nao e rebaixado.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/CI/baixa_CI.py
import datetime, hashlib, os, shutil, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'}
CSV = {'Accept': 'application/vnd.sdmx.data+csv; charset=utf-8'}
SDMX = 'https://sdmx.oecd.org/public/rest/data/'
G08 = '+'.join(['GF08'] + [f'GF080{i}' for i in range(1, 7)])
# Tabela 11: FREQ.REF_AREA.SECTOR.COUNTERPART_SECTOR.ACCOUNTING_ENTRY.TRANSACTION.INSTR_ASSET.EXPENDITURE.UNIT_MEASURE.VALUATION.PRICE_BASE.TRANSFORMATION.TABLE_IDENTIFIER
K11 = '.'.join(['A', '', 'S13', '', '', 'OTE', '', G08, 'XDC', '', '', '', ''])
# Tabela 1: FREQ.REF_AREA.SECTOR.COUNTERPART_SECTOR.TRANSACTION.INSTR_ASSET.ACTIVITY.EXPENDITURE.UNIT_MEASURE.PRICE_BASE.TRANSFORMATION.TABLE_IDENTIFIER
K1 = '.'.join(['A', '', 'S1', '', 'B1GQ', '', '', '', 'XDC', 'V', 'N', ''])
WB = 'https://api.worldbank.org/v2/country/all/indicator/{i}?format=json&per_page=20000&date=1990:2025'
BAIXA = [
  ('OCDE, Annual government expenditure by function (COFOG), Tabela 11, governo geral S13, despesa total OTE, 708 e grupos 7081 a 7086, moeda nacional, todos os paises',
   'oecd_DF_TABLE11_GF08_XDC.csv', SDMX + 'OECD.SDD.NAD,DSD_NASEC10@DF_TABLE11,1.1/' + K11 + '?startPeriod=1990', CSV),
  ('OCDE, Annual GDP and components, expenditure approach, Tabela 1, PIB B1GQ, moeda nacional, precos correntes, todos os paises',
   'oecd_DF_TABLE1_B1GQ_XDC.csv', SDMX + 'OECD.SDD.NAD,DSD_NAMAIN10@DF_TABLE1_EXPENDITURE,2.0/' + K1 + '?startPeriod=1990', CSV),
  ('OCDE, Government at a Glance, public finance by function, yearly updates, 708 em % do PIB (conferencia, sem grupos)',
   'oecd_DF_GOV_COFOG_YU_GF08_pctpib.csv', SDMX + 'OECD.GOV.GIP,DSD_GOV_COFOG@DF_GOV_COFOG_YU,1.0/A..GE.PT_B1GQ.S13.GF08..?startPeriod=1990', CSV),
  ('Banco Mundial, WDI, PIB por habitante em PPC, USD internacionais correntes (NY.GDP.PCAP.PP.CD)',
   'wb_NY.GDP.PCAP.PP.CD.json', WB.format(i='NY.GDP.PCAP.PP.CD'), {}),
  ('Banco Mundial, WDI, fator de conversao de PPC do PIB, moeda local por USD internacional (PA.NUS.PPP)',
   'wb_PA.NUS.PPP.json', WB.format(i='PA.NUS.PPP'), {}),
  ('Banco Mundial, WDI, populacao total (SP.POP.TOTL)', 'wb_SP.POP.TOTL.json', WB.format(i='SP.POP.TOTL'), {}),
  ('Statistics Canada, tabela 10-10-0005, rebaixada em 24/10/2026 para conferir se o arquivo de 20/10/2026 continua atual',
   'statcan_10100005_atual.zip', 'https://www150.statcan.gc.ca/n1/tbl/csv/10100005-eng.zip', {}),
  ('Licenca OCDE, Terms and Conditions, copia do Internet Archive de 17/10/2026 (o site da OCDE responde 403 a cliente sem navegador)', 'licenca_ocde_terms.html',
   'https://web.archive.org/web/20261017163843/https://www.oecd.org/en/about/terms-conditions.html', {}),
  ('Licenca Statistics Canada, Open Licence', 'licenca_statcan_open_licence.html', 'https://www.statcan.gc.ca/en/terms-conditions/open-licence', {}),
  ('Licenca Banco Mundial, metadado da serie NY.GDP.PCAP.PP.CD no WDI (campos License_Type e License_URL; o Data Catalog respondeu 429)',
   'licenca_wb_wdi_metadado.json', 'https://api.worldbank.org/v2/sources/2/series/NY.GDP.PCAP.PP.CD/metadata?format=json', {}),
]
STATCAN = [  # baixadas em 20/10/2026; o sha256 da 10-10-0005 foi conferido de novo em 24/10/2026 (statcan_10100005_atual.zip)
  ('Statistics Canada, tabela 10-10-0005, despesa do setor publico por funcao (CCOFOG), zip', 'statcan_10100005.zip',
   'https://www150.statcan.gc.ca/n1/tbl/csv/10100005-eng.zip'),
  ('Statistics Canada, tabela 36-10-0222, PIB por provincia, zip', 'statcan_36100222.zip', 'https://www150.statcan.gc.ca/n1/tbl/csv/36100222-eng.zip'),
  ('Statistics Canada, tabela 17-10-0009, populacao trimestral, zip', 'statcan_17100009.zip', 'https://www150.statcan.gc.ca/n1/tbl/csv/17100009-eng.zip'),
]
MEMBROS = ('OCDE, Revenue Statistics (DF_RSOECD), usado so para a lista dos 38 membros; copia de brutos/L/ocde/ deste pacote',
           'oecd_DF_RSOECD_membros.csv', os.path.join(AQUI, '..', 'L', 'ocde', 'data-DSD_REV_COMP_OECD@DF_RSOECD.csv'),
           'https://sdmx.oecd.org/public/rest/data/OECD.CTP.TPS,DSD_REV_COMP_OECD@DF_RSOECD,/.TAX_REV.S13._T._T.PT_B1GQ.A?startPeriod=2010')
linhas = []
def reg(desc, nome, url, dst):
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, 'fontes/' + nome, url,
                           hashlib.sha256(open(dst, 'rb').read()).hexdigest()]))
desc, nome, src, url = MEMBROS
dst = os.path.join(F, nome)
if not os.path.exists(dst): shutil.copy2(src, dst)
reg(desc, nome, url, dst)
for desc, nome, url, h in [(d, n_, u, {}) for d, n_, u in STATCAN] + BAIXA:
  dst = os.path.join(F, nome)
  if not os.path.exists(dst):
    try:
      dado = urllib.request.urlopen(urllib.request.Request(url, headers={**UA, **h}), timeout=300).read()
      open(dst, 'wb').write(dado)
    except Exception as e:
      print('FALHOU', nome, e)
    time.sleep(3)
  if os.path.exists(dst): reg(desc, nome, url, dst)
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n')
print(len(linhas), 'arquivos em downloads.tsv')

# Frente L: receita, carga tributária, gasto tributário e rigidez

Downloads em 18/10/2026 (`DATA_DOWNLOAD.txt`). Rodar de fora das pastas de dados:
`python3 brutos/L/build_L.py`. Ele é idempotente e regrava `../../L-receita-carga.csv` e `../../L-carga-internacional.csv`.

## Fontes e arquivos

| pasta/arquivo | fonte | URL |
|---|---|---|
| `tesouro/base-ctb-gg-2025.xlsx`, `Boletim_CTB_2025.pdf` | STN, Estimativa da Carga Tributária Bruta do Governo Geral 2025, publicada em 10/04/2026 | https://www.tesourotransparente.gov.br/publicacoes/carga-tributaria-do-governo-geral/2025/114 (anexo https://thot-arquivos.tesouro.gov.br/publicacao-anexo/28024) |
| `rfb/tabelas-ctb-2024.xlsx`, `rfb/ctb-2024.pdf` | RFB, Carga Tributária no Brasil 2024 (última edição publicada) | https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/estudos/carga-tributaria |
| `rfb/grafico01-transcricao.csv` | rótulos de dado do Gráfico 01 (p. 6) do PDF da RFB 2024, 2002 a 2024, as duas metodologias. A imagem foi extraída para `rfb/ctb-2024-p6-img1.png`. O script confere a transcrição contra a Tab_01 da planilha nos 9 anos em que ela traz valor (2013, 2017 a 2024), com tolerância de 0,006 p.p. | idem |
| `rfb/carga-tributaria-no-brasil-2002.pdf`, `-2008.pdf` | edições antigas, só para contexto (não entram no CSV) | idem |
| `dgt/be-2008..2023.*` | RFB, Demonstrativo de Gastos Tributários, Bases Efetivas, cada edição | .../relatorios/renuncia/gastos-tributarios-bases-efetivas |
| `dgt/dgt-ploa-2024..2026.xlsx` | RFB, DGT Previsão PLOA | .../relatorios/renuncia/gastos-tributarios-ploa |
| `ocde/data-*.csv` | OCDE, Revenue Statistics (DF_RSOECD) e Revenue Statistics in Latin America and the Caribbean (DF_RSLAC), API SDMX, total de tributos do governo geral em % do PIB | ver `fonte_url` no CSV |
| `../D/seriehistoricaago26.xlsx` (só leitura) | RTN, série histórica, ago/2026 | https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326 |

## Conceitos (por que as cargas divergem)

- **Tesouro (STN)**: estimativa, padrão GFSM 2014 do FMI, governo geral, sem FGTS e sem Sistema S. A série começa em 2010 e vai até 2025. O próprio boletim diz que não é o dado oficial.
- **RFB, nova metodologia (edição 2024)**: dado oficial. Passou a excluir FGTS e Sistema S para se alinhar a GFSM e OCDE, e recalculou 2002 a 2024. Fica perto do Tesouro (2024: RFB 32,20 e STN 32,22). A diferença máxima entre as duas, de 2010 a 2024, é de cerca de 0,4 p.p.
- **RFB, metodologia antiga**: inclui FGTS e Sistema S. Fica em média uns 1,8 p.p. acima, segundo a própria RFB, e é o número que circulou até 2023 (2024 nesse critério: 34,12). Vai como série extra, `carga_tributaria_bruta_receita_metodo_antigo`.
- **OCDE, Brasil 2024 = 33,68**: não coincide com nenhuma das duas séries da RFB. A RFB avisa que a base da OCDE ainda carregava a metodologia anterior até 2023. Para comparar com outros países, use a coluna OCDE dos dois lados: Brasil 33,68 contra 34,06 da média OCDE e 21,72 da média da América Latina e Caribe.

## Gasto tributário

- Bases efetivas 2006 a 2023. Cada ano sai da edição em que ele é o ano-base, pelo Quadro VI ou V de consolidação por tributo, que dá o total e o % do PIB.
- 2006 e 2007 vêm do quadro 2006 a 2010 da edição 2008, só em R$. O % do PIB não foi publicado e não foi calculado aqui.
- Nas edições até 2012, o % do PIB usa o PIB anterior à revisão do IBGE de 2015, por isso fica um pouco acima do que daria com o PIB atual.
- 2024 a 2026 são **projeções** do PLOA de cada ano, porque as bases efetivas 2024 ainda não saíram. A nota de cada linha traz também a reestimativa da DGT Bases Efetivas 2023 (Quadro XXVI).
- Não existe planilha "série histórica" consolidada nas páginas da RFB. Quem quiser a série tem que montá-la edição por edição, como foi feito aqui.

## RTN

- Tabela 2.1-A, Governo Central em % do PIB: receita total (linha 1), transferências por repartição (linha 2), receita líquida (linha 3), 1997 a 2025.
- Tabela 2.5, em R$: despesa total (2), obrigatórias com controle de fluxo (2.4.1) e discricionárias do Executivo (2.4.2), 2008 a 2025.
- `despesa_obrigatoria_rs_bi` é a despesa total menos 2.4.2. Ela soma 2.1, 2.2, 2.3 e 2.4.1. `pct_obrigatoria` é essa soma dividida pela despesa total.

## Não encontrado

- Carga do Tesouro antes de 2010: a série não existe.
- Carga da RFB em base comparável antes de 2002: as edições de 1995 a 2001 existem, mas usam PIB e metodologia antigos. A edição 2002, por exemplo, dá 35,86% para 2002, contra 30,27% na série recalculada.
- Gasto tributário antes de 2006, e % do PIB de 2006 e 2007.
- Bases efetivas de 2024 e 2025 (ainda não publicadas).

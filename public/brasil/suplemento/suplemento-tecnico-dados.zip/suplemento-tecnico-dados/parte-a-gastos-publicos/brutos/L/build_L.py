#!/usr/bin/env python3
"""Frente L: receita, carga tributaria, gasto tributario e rigidez da despesa.

Le apenas arquivos ja baixados em brutos/L/* (e o RTN local em brutos/D/) e gera:
  ../../L-receita-carga.csv       (formato longo)
  ../../L-carga-internacional.csv
Idempotente: reescreve as saidas a cada execucao. Nenhum numero digitado a mao,
exceto a transcricao dos rotulos do Grafico 01 da RFB (rfb/grafico01-transcricao.csv),
que o script confere contra a Tab_01 da planilha da RFB nos anos em que ela publica valor.
Rodar de fora das pastas de dados:  python3 brutos/L/build_L.py
"""
import csv
import os
import re

import warnings
import openpyxl
warnings.filterwarnings("ignore")
import pymupdf

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
P = lambda *a: os.path.join(AQUI, *a)

U_TES_PUB = 'https://www.tesourotransparente.gov.br/publicacoes/carga-tributaria-do-governo-geral/2025/114'
U_TES_XLSX = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/28024'
U_RFB_PAG = 'https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/estudos/carga-tributaria'
U_RFB_XLSX = U_RFB_PAG + '/tabelas-carga-tributaria-no-brasil-2024/@@download/file'
U_RFB_PDF = U_RFB_PAG + '/carga-tributaria-no-brasil-2024/@@download/file'
U_DGT = 'https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/renuncia'
U_RTN = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'
U_OCDE = 'https://sdmx.oecd.org/public/rest/data/OECD.CTP.TPS,DSD_REV_COMP_OECD@DF_RSOECD,/.TAX_REV.S13._T._T.PT_B1GQ.A?startPeriod=2010'
U_LAC = 'https://sdmx.oecd.org/public/rest/data/OECD.CTP.TPS,DSD_REV_COMP_LAC@DF_RSLAC,/.TAX_REV.S13._T._T.PT_B1GQ.A?startPeriod=2010'

DATA = open(P('DATA_DOWNLOAD.txt')).read().strip()


def presidente(a):
    if 1997 <= a <= 2002: return 'FHC'
    if 2003 <= a <= 2006: return 'Lula 1'
    if 2007 <= a <= 2010: return 'Lula 2'
    if 2011 <= a <= 2015: return 'Dilma'
    if a == 2016: return 'Dilma/Temer'
    if 2017 <= a <= 2018: return 'Temer'
    if 2019 <= a <= 2022: return 'Bolsonaro'
    if 2023 <= a <= 2026: return 'Lula 3'
    return ''


linhas = []


def add(serie, ano, valor, unidade, url, nota=''):
    v = '' if valor is None else round(float(valor), 4)
    linhas.append(dict(serie=serie, ano=ano, valor=v, unidade=unidade,
                       presidente=presidente(ano), fonte_url=url, nota=nota))


def wb(path):
    return openpyxl.load_workbook(path, read_only=True, data_only=True)


# ---------- 1a. Tesouro: Estimativa da CTB do Governo Geral (boletim 2025, publicado 10/04/2026)
ws = wb(P('tesouro', 'base-ctb-gg-2025.xlsx'))['Tabela 1']
rows = list(ws.iter_rows(values_only=True))
anos = [int(x) for x in rows[3][1:] if x is not None]
gg = [r for r in rows[4:13] if r[0] == 'Governo Geral'][1]  # 2a ocorrencia = % do PIB
assert gg[1] < 1, gg
for a, v in zip(anos, gg[1:]):
    add('carga_tributaria_bruta_tesouro', a, v * 100, '% do PIB', U_TES_XLSX,
        'STN, estimativa da CTB do governo geral (central+estados+municipios), padrao GFSM 2014 do FMI; '
        'exclui FGTS e Sistema S; nao e o dado oficial (oficial = RFB). Planilha Base CTB GG.xlsx, Tabela 1')
for a in range(1997, anos[0]):
    add('carga_tributaria_bruta_tesouro', a, None, '% do PIB', U_TES_PUB,
        'nao encontrado: a serie do Tesouro comeca em %d' % anos[0])

# ---------- 1b. RFB: Carga Tributaria no Brasil 2024 (nova metodologia, sem FGTS e Sistema S)
ws = wb(P('rfb', 'tabelas-ctb-2024.xlsx'))['Tab_01']
tab01 = {}
r_anos = r_ctb = None
for r in ws.iter_rows(values_only=True):
    r = [x for x in r if x is not None]
    if r and r[0] == 'Componentes': r_anos = [int(x) for x in r[1:]]
    if r and str(r[0]).strip() == 'Carga Tributária Bruta': r_ctb = r[1:]
tab01 = {a: v * 100 for a, v in zip(r_anos, r_ctb)}
graf = {int(d['ano']): d for d in csv.DictReader(open(P('rfb', 'grafico01-transcricao.csv')))}
for a, v in tab01.items():  # transcricao confere com a planilha
    assert abs(float(graf[a]['nova_metodologia_pct_pib']) - v) < 0.006, (a, v)
for a in range(1997, 2025):
    if a in tab01:
        add('carga_tributaria_bruta_receita', a, tab01[a], '% do PIB', U_RFB_XLSX,
            'RFB, Carga Tributaria no Brasil 2024, Tab_01; nova metodologia (exclui FGTS e Sistema S, alinhada a GFSM 2014 e OCDE), serie recalculada pela RFB')
    elif a in graf:
        add('carga_tributaria_bruta_receita', a, graf[a]['nova_metodologia_pct_pib'], '% do PIB', U_RFB_PDF,
            'RFB, Carga Tributaria no Brasil 2024, Grafico 01 (p.6), rotulo de dado transcrito; nova metodologia recalculada (sem FGTS e Sistema S)')
    else:
        add('carga_tributaria_bruta_receita', a, None, '% do PIB', U_RFB_PAG,
            'nao encontrado em base comparavel: serie recalculada da RFB comeca em 2002; edicoes antigas usam PIB pre-revisao e metodologia antiga')
for a in sorted(graf):
    add('carga_tributaria_bruta_receita_metodo_antigo', a, graf[a]['metodologia_antiga_pct_pib'], '% do PIB', U_RFB_PDF,
        'RFB, Grafico 01 (p.6) da edicao 2024, linha tracejada: metodologia anterior (inclui FGTS e Sistema S); e o numero que circulou ate 2023')

# ---------- 2. Gasto tributario federal (DGT, RFB)
# bases efetivas: cada ano vem da edicao em que ele e o ano-base (Quadro VI ou V)
gt = {}
for y in range(2016, 2024):
    for r in wb(P('dgt', 'be-%d.xlsx' % y))['Q VI'].iter_rows(values_only=True):
        r = [x for x in r if x is not None]
        if r and str(r[0]).strip().upper() == 'TOTAL':
            gt[y] = (r[1], r[2], 'DGT Bases Efetivas %d, Quadro VI' % y); break
num = lambda s: float(s.replace('.', '').replace(',', '.'))
for y in range(2010, 2016):
    d = pymupdf.open(P('dgt', 'be-%d.pdf' % y))
    for p in d:
        t = p.get_text()
        if re.search(r'CONSOLIDA..O POR TIPO DE TRIBUTO', t) and '....' not in t:
            lines = {}
            for w in p.get_text('words'): lines.setdefault(round(w[1] / 3), []).append(w)
            for k in sorted(lines):
                s = ' '.join(w[4] for w in sorted(lines[k], key=lambda w: w[0]))
                m = re.match(r'^(?:TOTAL|Total) ([\d\.]+) ([\d,]+) ([\d,]+) 100,00', s)
                if m: gt[y] = (num(m.group(1)), num(m.group(2)), 'DGT Bases Efetivas %d, Quadro de consolidacao por tributo (PDF)' % y)
            if y in gt: break
for y in (2008, 2009):
    d = pymupdf.open(P('dgt', 'be-%d.pdf' % y))
    for p in d:
        m = re.search(r'([\d\.]+)\n([\d,]+)\n([\d,]+)\n100,00\nReceita Administrada', p.get_text())
        if m: gt[y] = (num(m.group(1)), num(m.group(2)), 'DGT Bases Efetivas %d, Quadro V (PDF)' % y); break
d = pymupdf.open(P('dgt', 'be-2008.pdf'))
for p in d:
    m = re.search(r'Total Gastos Tribut.rios\s+([\d\.]+)\s+([\d\.]+)', p.get_text())
    if m:
        gt[2006] = (num(m.group(1)), None, 'DGT Bases Efetivas 2008, quadro 2006 a 2010 (PDF); %PIB nao publicado no quadro')
        gt[2007] = (num(m.group(2)), None, 'DGT Bases Efetivas 2008, quadro 2006 a 2010 (PDF); %PIB nao publicado no quadro')
        break
assert set(range(2006, 2024)) <= set(gt), sorted(gt)
for y in sorted(gt):
    rs, pib, q = gt[y]
    nota = 'base efetiva; ' + q + ('; %PIB calculado pela RFB com o PIB vigente na epoca (pre-revisao IBGE 2015 ate a edicao 2012)' if y <= 2012 else '')
    url = U_DGT + '/gastos-tributarios-bases-efetivas'
    add('gasto_tributario_rs_bi', y, rs / 1e9, 'R$ bi correntes', url, nota)
    add('gasto_tributario_pct_pib', y, pib, '% do PIB', url, nota if pib is not None else nota + '; nao encontrado em % do PIB')
# projecoes PLOA (as bases efetivas 2024+ ainda nao foram publicadas)
proj_be = {}
rows = list(wb(P('dgt', 'be-2023.xlsx'))['Q XXVI'].iter_rows(values_only=True))
anos26 = [x for x in rows[5] if x is not None]
for r in rows:
    if r and r[0] == 'TOTAL':
        vals = [x for x in r[1:] if x is not None]
        proj_be = dict(zip([int(a) for a in anos26], vals))
for y in (2024, 2025, 2026):
    for r in wb(P('dgt', 'dgt-ploa-%d.xlsx' % y))['Q VI'].iter_rows(values_only=True):
        r = [x for x in r if x is not None]
        if r and str(r[0]).strip().upper() == 'TOTAL':
            nota = ('projecao PLOA %d (DGT Previsao PLOA %d, Quadro VI); reestimativa na DGT Bases Efetivas 2023 (Q XXVI): R$ %.1f bi'
                    % (y, y, proj_be[y] / 1e9))
            url = U_DGT + '/gastos-tributarios-ploa'
            add('gasto_tributario_rs_bi', y, r[1] / 1e9, 'R$ bi correntes', url, nota)
            add('gasto_tributario_pct_pib', y, r[2], '% do PIB', url, nota)
            break
for y in range(1997, 2006):
    for s, u in (('gasto_tributario_rs_bi', 'R$ bi correntes'), ('gasto_tributario_pct_pib', '% do PIB')):
        add(s, y, None, u, U_DGT, 'nao encontrado: a edicao mais antiga de bases efetivas publicada pela RFB (2008) comeca em 2006')

# ---------- 4. RTN (Tesouro), local
W = wb(os.path.join(AQUI, '..', 'D', 'seriehistoricaago26.xlsx'))
rows = list(W['2.1-A'].iter_rows(values_only=True))
anos = [int(x) for x in rows[4][1:] if x is not None]
pega = {'1. RECEITA TOTAL': 'receita_total_gc', '2. TRANSF. POR REPARTI': 'transferencias_gc', '3. RECEITA L': 'receita_liquida_gc'}
for r in rows:
    for k, s in pega.items():
        if r[0] and str(r[0]).startswith(k):
            for a, v in zip(anos, r[1:]):
                add(s, a, v * 100, '% do PIB', U_RTN,
                    'RTN serie historica ago/2026, Tabela 2.1-A, linha "%s"; Governo Central (Tesouro+BCB+RGPS), conceito caixa' % str(r[0]).strip())
rows = list(W['2.5'].iter_rows(values_only=True))
anos = [int(x) for x in rows[4][1:] if x is not None]
lin = {}
for r in rows:
    if r[0]:
        n = str(r[0]).strip()
        for k in ('2. DESPESA TOTAL', '2.4.1 Obrigat', '2.4.2 Discricion'):
            if n.startswith(k): lin[k] = r[1:1 + len(anos)]
NT = 'RTN serie historica ago/2026, Tabela 2.5 (R$ milhoes correntes). '
for i, a in enumerate(anos):
    tot, cf, disc = lin['2. DESPESA TOTAL'][i], lin['2.4.1 Obrigat'][i], lin['2.4.2 Discricion'][i]
    add('despesa_total_rs_bi', a, tot / 1e3, 'R$ bi correntes', U_RTN, NT + 'linha 2. Despesa Total')
    add('despesa_obrig_controle_fluxo_rs_bi', a, cf / 1e3, 'R$ bi correntes', U_RTN, NT + 'linha 2.4.1 Obrigatorias com Controle de Fluxo (ja contida em despesa_obrigatoria_rs_bi)')
    add('despesa_discricionaria_rs_bi', a, disc / 1e3, 'R$ bi correntes', U_RTN, NT + 'linha 2.4.2 Discricionarias do Poder Executivo')
    add('despesa_obrigatoria_rs_bi', a, (tot - disc) / 1e3, 'R$ bi correntes', U_RTN,
        NT + 'calculado: Despesa Total menos 2.4.2 (= previdencia 2.1 + pessoal 2.2 + outras obrigatorias 2.3 + obrigatorias com controle de fluxo 2.4.1)')
    add('pct_obrigatoria', a, (tot - disc) / tot * 100, '% da despesa primaria total', U_RTN, NT + 'calculado: (Total - 2.4.2) / Total')

ordem = ['carga_tributaria_bruta_tesouro', 'carga_tributaria_bruta_receita', 'carga_tributaria_bruta_receita_metodo_antigo',
         'gasto_tributario_pct_pib', 'gasto_tributario_rs_bi', 'receita_total_gc', 'transferencias_gc', 'receita_liquida_gc',
         'despesa_total_rs_bi', 'despesa_obrigatoria_rs_bi', 'despesa_obrig_controle_fluxo_rs_bi', 'despesa_discricionaria_rs_bi', 'pct_obrigatoria']
linhas.sort(key=lambda d: (ordem.index(d['serie']), d['ano']))
for d in linhas: d['nota'] = (d['nota'] + '; baixado em ' + DATA) if d['valor'] != '' or 'nao encontrado' in d['nota'] else d['nota']
with open(os.path.join(RAIZ, 'L-receita-carga.csv'), 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['serie', 'ano', 'valor', 'unidade', 'presidente', 'fonte_url', 'nota'])
    w.writeheader(); w.writerows(linhas)

# ---------- 3. Comparacao internacional (OCDE Revenue Statistics 2025 e RS LAC 2025, via SDMX)
NOMES = {'OECD_REP': 'Media OCDE', 'A9': 'Media America Latina e Caribe (RS LAC)', 'BRA': 'Brasil (OCDE/RS LAC)',
         'ARG': 'Argentina', 'CHL': 'Chile', 'COL': 'Colombia', 'MEX': 'Mexico', 'URY': 'Uruguai', 'PER': 'Peru',
         'USA': 'Estados Unidos', 'DEU': 'Alemanha', 'FRA': 'Franca', 'GBR': 'Reino Unido', 'ITA': 'Italia',
         'JPN': 'Japao', 'KOR': 'Coreia do Sul', 'CAN': 'Canada', 'ESP': 'Espanha', 'DNK': 'Dinamarca'}
out = {}
for f, url in (('data-DSD_REV_COMP_LAC@DF_RSLAC.csv', U_LAC), ('data-DSD_REV_COMP_OECD@DF_RSOECD.csv', U_OCDE)):
    for r in csv.DictReader(open(P('ocde', f))):
        a = r['REF_AREA']
        if a not in NOMES or not r['OBS_VALUE'] or (a in out and out[a][3] != url): continue
        ano = int(r['TIME_PERIOD'])
        if a not in out or ano > out[a][0]:
            out[a] = (ano, float(r['OBS_VALUE']), NOMES[a], url)
with open(os.path.join(RAIZ, 'L-carga-internacional.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['pais_ou_grupo', 'ano', 'carga_pct_pib', 'fonte_url'])
    for a in sorted(out, key=lambda a: -out[a][1]):
        ano, v, nome, url = out[a]
        w.writerow([nome, ano, round(v, 2), url])
    # referencias nacionais, mesmas fontes da serie longa
    w.writerow(['Brasil (RFB, nova metodologia)', 2024, round(tab01[2024], 2), U_RFB_XLSX])
    w.writerow(['Brasil (Tesouro, estimativa)', 2025,
                round([d for d in linhas if d['serie'] == 'carga_tributaria_bruta_tesouro' and d['ano'] == 2025][0]['valor'], 2), U_TES_XLSX])
print('ok', len(linhas), 'linhas;', len(out), 'paises/grupos')

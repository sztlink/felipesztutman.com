"""Gera ../../Y2-medidas.csv (frente Y2, dossie gastos publicos): inventario narrativo de medidas fiscais 2015-2026.

Metodo de referencia: Carriere-Swallow, David e Leigh (2018), Y15 em Y-literatura.csv. Motivacao e tamanho
lidos em documentos oficiais contemporaneos (exposicao de motivos, justificacao, notas do Executivo, IFI, RTN,
Relatorio bimestral, PLDO, Receita Federal).

Cada ficha abaixo foi escrita a mao a partir da leitura dos arquivos em fontes/<ID>/ (URL e data em
downloads.tsv). O script:
  1. le o PIB nominal anual do IBGE (SIDRA 1846, soma dos 4 trimestres) e calcula o % do PIB quando a fonte
     da o valor em R$ de um unico ano e nao da o %; o campo *_pct_origem diz se o % e da fonte ou calculado;
  2. le a planilha do RTN (aba 4.1) para os valores mensais do auxilio emergencial (M05 e M07b);
  3. confere se cada trecho de motivacao aparece literalmente no arquivo local citado;
  4. calcula razoes aprovado/anunciado e realizado/anunciado so nos pares marcados como comparaveis
     (mesmo conceito e mesmo horizonte);
  5. grava o CSV e imprime o resumo usado no LEIAME.

Convencao de sinal: valor positivo melhora o resultado primario (economia de gasto ou receita nova);
negativo piora (custo). R$ bilhoes correntes, salvo indicacao no horizonte.
Rodar: PYTHONPATH=~/.local/lib/pdftools python3 -P build_Y2.py
"""
import csv, datetime, html, json, math, os, re, statistics, sys, zipfile

AQUI = os.path.dirname(os.path.abspath(__file__))
F = os.path.join(AQUI, "fontes")
SAIDA = os.path.join(AQUI, "..", "..", "Y2-medidas.csv")

# ---------------------------------------------------------------- PIB nominal anual (IBGE, SIDRA 1846, v585)
def pib_anual():
    d = json.load(open(os.path.join(F, "ibge_sidra1846_pib_trimestral.json")))
    soma, n = {}, {}
    for r in d[1:]:
        y = int(r["D3C"][:4])
        soma[y] = soma.get(y, 0.0) + float(r["V"])
        n[y] = n.get(y, 0) + 1
    return {y: soma[y] / 1000.0 for y in soma if n[y] == 4}  # R$ bilhoes, so anos completos

PIB = pib_anual()

# ---------------------------------------------------------------- RTN, aba 4.1 (auxilio emergencial mensal, valor pago)
def auxilio_mensal():
    import openpyxl
    wb = openpyxl.load_workbook(os.path.join(F, "M07", "tesouro-rtn-serie-historica-2021-12.xlsx"),
                                data_only=True, read_only=True)
    rows = list(wb["4.1"].iter_rows(values_only=True))
    cab = rows[4]
    lin = [r for r in rows if r[0] == "Auxílio Emergencial a Pessoas em Situação de Vulnerabilidade"][0]
    out = {}
    for d, v in zip(cab[2:], lin[2:]):
        if isinstance(d, datetime.datetime):
            out[(d.year, d.month)] = (v or 0.0) / 1000.0
    return out

AUX = auxilio_mensal()
AUX_2020_ABR_JUN = sum(AUX[(2020, m)] for m in (4, 5, 6))
AUX_2021 = sum(AUX[(2021, m)] for m in range(1, 13))

# ---------------------------------------------------------------- fichas
R = []
def add(**k):
    R.append(k)

add(id="M01", medida="Ajuste de 2015 nos beneficios do FAT e da Previdencia: pensao por morte e auxilio-doenca (MP 664/2014); seguro-desemprego, abono salarial e seguro-defeso (MP 665/2014)",
    presidente="Dilma", presidente_aprovacao="Dilma", governo_proponente="Dilma",
    ato_proposta="MP 664/2014 (EMI 23/2014 MPS MF MP) e MP 665/2014 (EMI 180/2014 MF MPS MTE), DOU de 30/12/2014",
    ato_aprovado="Lei 13.135/2015 (conversao da MP 664) e Lei 13.134/2015 (conversao da MP 665)",
    data_anuncio="2014-12-29", data_aprovacao="2015-06-16",
    motivacao_classe="consolidacao",
    motivacao_trecho="Ressalta-se que estas políticas já ocupam um papel de destaque nas contas do setor público brasileiro. Sendo assim, sua sustentabilidade se tornou uma questão importante para as finanças públicas como um todo.",
    motivacao_arquivo="fontes/M01/em-mpv665.doc",
    motivacao_fonte="EMI 180/2014 (MP 665), par. 4; https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/Exm/ExmMP%20665-14.doc. Na audiencia de 09/04/2015 o ministro do Planejamento disse que as MPs 'vão ajudar no esforço fiscal' deste ano (notas taquigraficas)",
    tipo_principal="transferencias", tipo_secundario="previdencia",
    an=18.0, an_pct=0.3, an_ano=None, an_h="por ano, a partir de 2015, a precos de 2014, as duas MPs juntas",
    an_f="fontes/M01/senado-cm-mp664-665-notas-taquigraficas-2015-04-09.docx; https://legis.senado.leg.br/sdleg-getter/documento/download/cb9dbeed-b811-4d43-b74f-b08fa7d1f128; fala de Nelson Barbosa (Planejamento), 09/04/2015: 'cerca de 0,3% do PIB por ano e crescente', 'cerca de R$18 bilhões por ano'. As EMs nao trazem valor (Conorf NT 2/2015, p. 9)",
    ap=7.314, ap_pct=0.13, ap_ano=2015, ap_h="so 2015, com as leis vigentes desde marco (seguro) e junho; soma de MP 665 (6,336) e MP 664 (0,978)",
    ap_f="fontes/M01/mpog-cenario-fiscal-2015-2016-set2015.pdf; https://legis.senado.leg.br/sdleg-getter/documento/download/f0b58d41-de2f-498d-bda3-24c9e8aa1da9; slide 7 (0,11% e 0,02% do PIB, somados aqui). Desidratacao: Relatorio do 3o bim 2015, p. 18, Tabela 6 (+3.855,8 mi em abono e seguro pela conversao da MP 665)",
    re=100.4, re_pct=None, re_ano=None, re_h="2015 a 2023 acumulado, R$ de dez/2023, so a Lei 13.134 (seguro-desemprego 48,4 e abono 52,0); serie anual 3,6; 6,8; 9,1; 9,7; 12,1; 11,4; 9,2; 19,9; 18,8",
    re_f="fontes/M01/ipea-td3117-2025-lei13134.pdf; https://repositorio.ipea.gov.br/server/api/core/bitstreams/63f5417c-2f7e-4c91-b9eb-9d0fd6a2063f/content; p. 25 e Grafico 7 (economia potencial com contrafactual da Seet/MTE). Lei 13.135 sem realizado em fonte oficial",
    et=("sim", "sim", "parcial"), cmp=None,
    nota="Anunciado fora da EM (fala oficial registrada); aprovado so para 2015, ano parcial; realizado cobre so a Lei 13.134 e vem do Ipea (fundacao federal) com contrafactual do MTE. Horizontes diferentes nas tres etapas: nenhuma razao calculada. A Y15 codifica o Brasil de 2015 como consolidacao de 0,80% do PIB (0,30 receita, 0,50 gasto), pacote maior que estas MPs.")

add(id="M02", medida="Reoneracao parcial da folha de 2015 (CPRB de 1% para 2,5% e de 2% para 4,5%, regime opcional)",
    presidente="Dilma", presidente_aprovacao="Dilma", governo_proponente="Dilma",
    ato_proposta="MP 669/2015 (EM 41/2015 MF), devolvida pelo Senado em 03/03/2015; PL 863/2015 (EM 48/2015 MF), PLC 57/2015 no Senado",
    ato_aprovado="Lei 13.161/2015 (aliquotas novas desde dezembro de 2015)",
    data_anuncio="2015-02-27", data_aprovacao="2015-08-31",
    motivacao_classe="consolidacao",
    motivacao_trecho="são propostos ajustes nas alíquotas em virtude de o quadro atual apontar para a necessidade de aumento de arrecadação e corte de despesas.",
    motivacao_arquivo="fontes/M02/em-mp669.pdf",
    motivacao_fonte="EM 41/2015 MF, p. 1, par. 2; https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/Exm/ExmMP-669-15.pdf (mesmo texto na EM 48/2015 do PL 863, p. 7)",
    tipo_principal="receita", tipo_secundario="previdencia",
    an=12.84148, an_pct=None, an_ano=2016, an_h="por ano a partir de 2016 (12.841,48 mi); em 2015, 5,35 bi na MP e 3,57 bi no PL 863",
    an_f="fontes/M02/mf-nota-mp669-fev2015.html (Nota a Imprensa MF de 27/02/2015, via Wayback), itens 2 e 4; 2015: fontes/M02/em-mp669.pdf, p. 2, par. 7, e fontes/M02/pl863-inteiro-teor.pdf, p. 8, par. 7",
    ap=0.40, ap_pct=0.01, ap_ano=2015, ap_h="so 2015, um mes de vigencia; sem estimativa oficial anual da versao aprovada",
    ap_f="fontes/M02/mpog-cenario-fiscal-2015-2016-set2015.pdf; slide 7, 'Revisão da desoneração da folha de pagamento 400 / 0,01'",
    re=9.619, re_pct=None, re_ano=2016, re_h="queda da renuncia 'Folha de Salarios' de 2015 (24.149 mi) para 2016 (14.530 mi); limite superior, mistura lei, saida do regime e recessao",
    re_f="fontes/M02/rfb-analise-arrecadacao-dez2016.pdf (RFB via Wayback), p. 35; serie mensal em fontes/M02/rfb-desoneracao-folha-ate-jul2017.xlsx",
    et=("sim", "sim", "parcial"), cmp=("re", 12.84148, 9.619, "anunciado por ano a partir de 2016 contra queda observada da renuncia de 2015 para 2016 (limite superior, nao isolado)"),
    nota="Nao ha efeito isolado oficial da lei. O aprovado de 2015 (0,40) e o anunciado de 2015 (5,35) diferem tambem pela vigencia (dezembro contra junho).")

add(id="M03", medida="Teto de gastos (Novo Regime Fiscal): despesa primaria da Uniao corrigida pelo IPCA por 20 anos",
    presidente="Temer", presidente_aprovacao="Temer", governo_proponente="Temer",
    ato_proposta="PEC 241/2016 (Camara), PEC 55/2016 (Senado); EMI 83/2016 MF MPDG",
    ato_aprovado="EC 95/2016",
    data_anuncio="2016-06-15", data_aprovacao="2016-12-15",
    motivacao_classe="consolidacao",
    motivacao_trecho="Esse instrumento visa reverter, no horizonte de médio e longo prazo, o quadro de agudo desequilíbrio fiscal em que nos últimos anos foi colocado o Governo Federal.",
    motivacao_arquivo="fontes/M03/pec241-inteiro-teor.pdf",
    motivacao_fonte="EMI 83/2016, p. 4, par. 1; https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=1468431",
    tipo_principal="regra fiscal", tipo_secundario="",
    an=None, an_pct=4.0, an_pct_origem="fonte (simulacao); diferenca calculada", an_ano=None,
    an_h="nivel da despesa primaria em 2025: 16,8% do PIB com teto contra 20,8% sem teto (diferenca de 4,0 pontos calculada aqui); sem valor em R$",
    an_f="fontes/M03/mf-apresentacao-pec241-cae-2016-08-16.pdf (MF na CAE, 16/08/2016), slide 16, simulacao da SPE a partir de 2017",
    ap=None, ap_pct=None, ap_ano=None, ap_h="",
    ap_f="sem estimativa oficial da versao aprovada (o Senado nao mudou o merito). Depois, a Fazenda (dez/2018, fontes/M03/mf-spe-2018-teto-gradual-ajuste.pdf, p. 5) descreve o objetivo como reducao de 0,5 ponto do PIB por ano, 5 pontos em 10 anos (cerca de R$ 350 bi): meta de ajuste, nao efeito estimado",
    re=None, re_pct=None, re_ano=None, re_h="",
    re_f="sem fonte oficial de economia contra contrafactual. Trajetoria observada (RTN, fontes/M03/tesouro-rtn-serie-historica.xlsx, aba 2.1-A): despesa total de 19,95% do PIB (2016) para 19,52% (2019), queda de 0,43 ponto em 3 anos, contra 0,5 ponto por ano pretendido",
    et=("parcial", "nao", "nao"), cmp=None,
    nota="Regra, nao medida com valor. A trajetoria de 2016 a 2019 nao identifica o efeito do teto. A IFI so foi instalada em nov/2016.")

add(id="M04", medida="Reforma da Previdencia (idade minima, regra de calculo, pensao por cotas, aliquotas progressivas, abono)",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Bolsonaro",
    ato_proposta="PEC 6/2019, EM 29/2019 ME", ato_aprovado="EC 103/2019",
    data_anuncio="2019-02-20", data_aprovacao="2019-11-12",
    motivacao_classe="consolidacao",
    motivacao_trecho="E esse nó fiscal tem uma raiz: a despesa previdenciária.",
    motivacao_arquivo="fontes/M04/pec6-2019-inteiro-teor.pdf",
    motivacao_fonte="EM 29/2019, par. 6 (p. 43 do PDF); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=1712459",
    tipo_principal="previdencia", tipo_secundario="receita; transferencias",
    an=1072.4, an_pct=None, an_ano=None, an_h="acumulado em 10 anos (2019 a 2028); revisao do Executivo em maio de 2019: 1.236,5 (2020 a 2029, R$ de 2019)",
    an_f="fontes/M04/pec6-2019-inteiro-teor.pdf, p. 66, par. 114 (tabela da EM, total 1.072,4; 4.497,4 em 20 anos); revisao em fontes/M04/sprev-apresentacao-marinho-camara-2019-05-21.pdf, p. 14",
    ap=800.3, ap_pct=None, ap_ano=None, ap_h="acumulado em 10 anos (2020 a 2029), R$ de 2019, texto aprovado no Senado, com a CSLL de bancos (19,2)",
    ap_f="fontes/M04/sprev-apresentacao-ec103-cnps-2019-11-21.pdf (SPREV no CNPS, 21/11/2019, via Wayback), slide 7 (imagem). IFI: 630 (fontes/M04/ifi-ci03-impactos-pec6.pdf, Tabela 1)",
    re=None, re_pct=None, re_ano=None, re_h="",
    re_f="sem fonte oficial encontrada (IFI RAF 34 e NTs 35 a 58, RAF 112 de mai/2026 so qualitativo, PLDO 2021, Conof ET 35, Relatorios bimestrais de 2020)",
    et=("sim", "sim", "nao"), cmp=("ap", 1072.4, 800.3, "10 anos, EM contra texto aprovado (anos iniciais diferem em um ano)"),
    nota="Trajetoria no Congresso (Executivo/IFI): relator Camara 987/744, plenario Camara 934/723, CCJ Senado 877/682, plenario Senado 800/630. Com a base de 1.236,5 da revisao de maio, o aprovado e 65% do anunciado.")

add(id="M05", medida="Auxilio emergencial de 2020 (R$ 600, prorrogacoes e auxilio residual de R$ 300)",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Bolsonaro (anuncio de R$ 200); texto do Congresso (PL 9.236/2017)",
    ato_proposta="anuncio do ME em 18/03/2020 (R$ 200 por 3 meses); PL 9.236/2017 (substitutivo Marcelo Aro); MPs de credito 937, 956, 970, 988 e 999/2020; MP 1.000/2020",
    ato_aprovado="Lei 13.982/2020; creditos extraordinarios das MPs 937, 956, 970, 988 e 999",
    data_anuncio="2020-03-18", data_aprovacao="2020-04-02",
    motivacao_classe="resposta a pandemia",
    motivacao_trecho="medidas excepcionais de proteção social para as pessoas mais humildes afetadas com os impactos econômicos",
    motivacao_arquivo="fontes/M05/Exm-MP-937-20.pdf",
    motivacao_fonte="EM 113/2020 ME (MP 937), p. 1, par. 2; https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2020/Exm/Exm-MP-937-20.pdf",
    tipo_principal="transferencias", tipo_secundario="",
    an=-15.0, an_pct=None, an_ano=2020, an_h="3 meses de 2020; a fonte diz 'até R$ 5 bilhões por mês' durante 3 meses (soma calculada aqui)",
    an_f="fontes/M05/me-confira-medidas-covid-wayback-20200409.html (ME, bloco de 18/03/2020, via Wayback)",
    ap=-98.2, ap_pct=None, ap_ano=2020, ap_h="3 meses de R$ 600 (Lei 13.982); com prorrogacoes e auxilio residual, o ME estimou 321,8 para 2020",
    ap_f="fontes/M05/Exm-MP-937-20.pdf, p. 1, par. 1; 321,8: fontes/M05/me-impacto-fiscal-covid-2020-12-22.pdf, p. 6 e 8",
    re=-293.1054, re_pct=-4.0, re_ano=2020, re_h="2020, pagamentos de abril a dezembro (293.105,4 mi); nos tres primeiros meses (abr a jun) %.1f bi" % AUX_2020_ABR_JUN,
    re_f="fontes/M05/rtn-2020-12-apresentacao.pdf, p. 15 (tabela COVID, valor pago); 4% do PIB: fontes/M05/ifi-RAF50_MAR2021.pdf, p. 9; abr a jun: fontes/M07/tesouro-rtn-serie-historica-2021-12.xlsx, aba 4.1",
    et=("sim", "sim", "sim"),
    cmp=("re", -15.0, -AUX_2020_ABR_JUN, "3 meses: anuncio de R$ 200 contra pagos de abril a junho de 2020 (RTN mensal)"),
    cmp2=("ap", -321.8, -293.1054, "2020 inteiro: estimativa do ME (dez/2020) contra realizado"),
    nota="O Congresso triplicou o valor do beneficio (R$ 200 para R$ 600). Custo realizado em 2020 de 4% do PIB (IFI).")

add(id="M06", medida="LC 173/2020: auxilio financeiro de R$ 60 bi a estados e municipios, suspensao de dividas e congelamento de despesa com pessoal ate 2021",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Senado (PLP 39/2020, substitutivo de Davi Alcolumbre)",
    ato_proposta="PLP 39/2020 (Senado), sem EM", ato_aprovado="LC 173/2020",
    data_anuncio="2020-04-30", data_aprovacao="2020-05-27",
    motivacao_classe="resposta a pandemia",
    motivacao_trecho="entendemos que a pandemia da Covid-19 obriga a União a aliviar o caixa dos estados e municípios, seja por meio de auxílio financeiro direto, seja permitindo a suspensão de pagamento de dívidas.",
    motivacao_arquivo="fontes/M06/senado-plp39-parecer-27-2020-plen.pdf",
    motivacao_fonte="Parecer 27/2020-PLEN (relator Davi Alcolumbre), p. 27; proposta do Legislativo, sem EM",
    tipo_principal="transferencias", tipo_secundario="pessoal (congelamento nos entes)",
    an=-60.0, an_pct=None, an_ano=2020, an_h="auxilio em 4 parcelas em 2020",
    an_f="fontes/M06/senado-plp39-relatorio-2020-04-30.pdf, p. 8 ('chegamos a um valor total de R$ 60 bilhões')",
    ap=-60.15, ap_pct=None, ap_ano=2020, ap_h="auxilio em 2020; suspensao e renegociacao de dividas sem efeito primario (35,34; 13,98; 10,73); contrapartida de 98,9 bi de economia com pessoal nos entes ate 2021",
    ap_f="fontes/M06/me-impacto-fiscal-covid-2020-05-22.pdf (ME, 22/05/2020, via Wayback), slide 8 (imagem)",
    re=-60.1, re_pct=None, re_ano=2020, re_h="repassado de junho a setembro de 2020",
    re_f="fontes/M06/tesouro-boletim-entes-subnacionais-2021.pdf (STN), p. 18",
    et=("sim", "sim", "sim"), cmp=("re", -60.0, -60.1, "auxilio de 2020"),
    nota="Valores do auxilio federal. A economia do congelamento (98,9 bi nos entes, ME) nao tem realizado oficial; nao entra no primario da Uniao.")

add(id="M07a", medida="EC 109/2021, gatilhos de contencao da despesa obrigatoria (PEC Emergencial, Plano Mais Brasil)",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Bolsonaro (PEC 186/2019 do ME, apresentada pelo lider do governo)",
    ato_proposta="PEC 186/2019 (Senado), justificacao", ato_aprovado="EC 109/2021",
    data_anuncio="2019-11-05", data_aprovacao="2021-03-15",
    motivacao_classe="consolidacao",
    motivacao_trecho="a PEC apresentada tem como objetivo principal a contenção do crescimento das despesas obrigatórias para todos os níveis de governo",
    motivacao_arquivo="fontes/M07/senado-pec186-2019-texto-inicial.pdf",
    motivacao_fonte="justificacao da PEC 186/2019, p. 13 (OCR do documento oficial)",
    tipo_principal="regra fiscal", tipo_secundario="pessoal",
    an=50.0, an_pct=None, an_ano=None, an_h="ate R$ 50 bi em 10 anos, apresentados como espaco para investimento sob o teto, nao como melhora liquida do primario",
    an_f="fontes/M07/me-apresentacao-pacto-federativo-plano-mais-brasil-2019-11.pdf (ME, nov/2019, via Wayback), p. 37",
    ap=None, ap_pct=None, ap_ano=None, ap_h="",
    ap_f="sem estimativa oficial da versao aprovada; IFI RAF 50 (fontes/M07/ifi-RAF50_MAR2021.pdf, p. 39): o gatilho da Uniao (95%) nao seria acionado antes de 2025",
    re=None, re_pct=None, re_ano=None, re_h="", re_f="sem fonte oficial encontrada",
    et=("parcial", "nao", "nao"), cmp=None,
    nota="Mesma emenda que M07b; separada porque a motivacao e o sinal sao opostos.")

add(id="M07b", medida="EC 109/2021, auxilio emergencial de 2021 fora do teto, da meta e da regra de ouro",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="relator Marcio Bittar (Senado); execucao pelo Executivo (MPs 1.037, 1.038, 1.039 e 1.056)",
    ato_proposta="PEC 186/2019, complementacao de voto de 03/03/2021", ato_aprovado="EC 109/2021, art. 3; MP 1.037/2021",
    data_anuncio="2021-03-03", data_aprovacao="2021-03-15",
    motivacao_classe="resposta a pandemia",
    motivacao_trecho="o retorno do auxílio emergencial, que em 2020 mostrou-se fundamental para combater os devastadores efeitos econômicos e sociais da pandemia da covid-19.",
    motivacao_arquivo="fontes/M07/senado-pec186-parecer-21-2021-plen.pdf",
    motivacao_fonte="Parecer 21/2021-PLEN (Marcio Bittar), p. 23",
    tipo_principal="transferencias", tipo_secundario="regra fiscal",
    an=-44.0, an_pct=None, an_ano=2021, an_h="limite de 2021 proposto pelo relator; a EMI da MP 1.039 (15/03/2021) estimou 43,0 em beneficios e 0,39 de custo operacional",
    an_f="fontes/M07/senado-pec186-adendo-plenario-2021-03-03.pdf, p. 2; fontes/M07/Exm-MP-1039-21.pdf, p. 4",
    ap=-44.0, ap_pct=None, ap_ano=2021, ap_h="limite da EC 109 para 2021",
    ap_f="fontes/M07/emc109.htm, art. 3, par. 1",
    re=-AUX_2021, re_pct=None, re_ano=2021, re_h="pagos em 2021 (soma mensal, inclui 0,69 de residuo de jan a mar do auxilio de 2020)",
    re_f="fontes/M07/tesouro-rtn-serie-historica-2021-12.xlsx, aba 4.1, linha do Auxilio Emergencial, soma calculada aqui",
    et=("sim", "sim", "sim"), cmp=("re", -44.0, -AUX_2021, "2021"),
    nota="O realizado passou do limite da EC 109: a prorrogacao de 3 meses (MP 1.056, R$ 20,27 bi) foi aberta com so 7,94 bi restantes no limite (fontes/M07/Exm-MP-1056-21.pdf, p. 2).")

add(id="M08", medida="Precatorios: limite anual de pagamento de sentencas (EC 114) e mudanca da correcao do teto (EC 113)",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Bolsonaro",
    ato_proposta="PEC 23/2021, EM 206/2021 ME", ato_aprovado="EC 113/2021 (08/12) e EC 114/2021 (16/12)",
    data_anuncio="2021-08-10", data_aprovacao="2021-12-08",
    motivacao_classe="outra: abrir espaco sob o teto diante do salto das sentencas judiciais",
    motivacao_trecho="o que representa um elevado comprometimento das despesas discricionárias",
    motivacao_arquivo="fontes/M08/pec23-2021-inteiro-teor-com-EM.pdf",
    motivacao_fonte="EM 206/2021 ME, p. 6, item 2 (o item 6 fala em evitar 'um colapso financeiro e da máquina pública'); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2054008",
    tipo_principal="regra fiscal", tipo_secundario="transferencias (destino do espaco: Auxilio Brasil)",
    an=-33.5, an_pct=None, an_ano=2022, an_h="2022, espaco fiscal aberto pelo parcelamento (EM); em 22/11/2021 o ME falou em 106,1 ja com a mudanca do teto criada na Camara",
    an_f="fontes/M08/pec23-2021-inteiro-teor-com-EM.pdf, p. 8, item 15; 106,1: fontes/M08/senado-sessao-tematica-22nov2021-notas-taquigraficas.pdf, p. 4",
    ap=-113.1, ap_pct=None, ap_ano=2022, ap_h="2022, espaco usado na LOA 2022: 69,6 do recalculo do teto e 43,5 do limite de precatorios",
    ap_f="fontes/M08/ifi-raf60-jan2022.pdf, p. 29 e 30",
    re=-43.5, re_pct=None, re_ano=2022, re_h="2022, espaco efetivo do limite de precatorios; o adiado (60,18 mais 32,25 antecipados de 2024) foi pago em dez/2023 (92,4 primarios)",
    re_f="fontes/M08/ifi-raf84-jan2024.pdf, p. 13 (43,5) e p. 22 (92,4); fontes/M08/em-mp1200-2023.pdf, p. 1 e 2",
    et=("sim", "sim", "sim"), cmp=("re", -33.5, -43.5, "2022, so o componente de precatorios"),
    nota="O aprovado inclui a mudanca da correcao do teto, que nao estava na EM. A Nota Conjunta STN/PGFN de 22/09/2023 (p. 3) registra que a PEC, motivada por R$ 33,7 bi, 'abriu espaço para criar novas despesas da ordem de R$ 41 bilhões'.")

add(id="M09", medida="EC 123/2022: estado de emergencia, Auxilio Brasil de R$ 600, vale-gas, auxilios a caminhoneiros e taxistas, compensacao do ICMS do etanol",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Senado (PEC 1/2022, relator Fernando Bezerra Coelho, lider do governo)",
    ato_proposta="PEC 1/2022 (Senado), sem EM", ato_aprovado="EC 123/2022; MPs 1.130, 1.131 e 1.134/2022",
    data_anuncio="2022-06-29", data_aprovacao="2022-07-14",
    motivacao_classe="eleitoral",
    motivacao_trecho="Essas medidas têm duração prevista até o final do ano, quando a legislação eleitoral não será mais óbice para que os benefícios possam ser aprovados",
    motivacao_arquivo="fontes/M09/camara-pec15-2022-parecer-danilo-forte-ce.pdf",
    motivacao_fonte="parecer do relator na Camara (Danilo Forte), p. 13; o relator no Senado explica o estado de emergencia pela vedacao do art. 73, par. 10, da Lei 9.504/1997 (fontes/M09/pec1-2022-relatorio-fbc.pdf, p. 6 e 7). Motivacao declarada: alta dos combustiveis",
    tipo_principal="transferencias", tipo_secundario="regra fiscal",
    an=-38.75, an_pct=None, an_ano=2022, an_h="jul a dez de 2022; primeiro custo do relator (29/06/2022)",
    an_f="fontes/M09/pec1-2022-relatorio-fbc.pdf, p. 11",
    ap=-41.25, ap_pct=None, ap_ano=2022, ap_h="2022, limites do art. 5 da EC 123",
    ap_f="fontes/M09/ec123-2022-planalto.html, art. 5; fontes/M09/rardp-2022-3bim.pdf, p. 8 e 9 (41.250,0 mi)",
    re=-36.3571, re_pct=None, re_ano=2022, re_h="ago a dez de 2022 (36.357,1 mi, 88,1% do autorizado)",
    re_f="fontes/M09/ifi-raf-jan-2023.pdf, p. 27, Tabela 10; RTN dez/2022 (fontes/M09/rtn-2022-12-boletim.pdf, p. 10, nota 15): 36,3 bi",
    et=("sim", "sim", "sim"), cmp=("re", -38.75, -36.3571, "2022"), cmp2=("ap", -41.25, -36.3571, "2022, aprovado contra realizado"),
    nota="Promulgada 80 dias antes do 1o turno; IFI CI 16 registra 'a menos de 100 dias das eleições'.")

add(id="M10", medida="EC 126/2022 (PEC da Transicao): R$ 145 bi acima do teto em 2023 para o Bolsa Familia de R$ 600 e recomposicao de dotacoes",
    presidente="Bolsonaro", presidente_aprovacao="Bolsonaro", governo_proponente="Lula 3 (equipe de transicao; autoria formal do Senado, PEC 32/2022)",
    ato_proposta="minuta da transicao (16/11/2022); PEC 32/2022 (Senado), justificacao", ato_aprovado="EC 126/2022",
    data_anuncio="2022-11-16", data_aprovacao="2022-12-21",
    motivacao_classe="outra: programa do governo eleito (manter o beneficio de R$ 600), com componente anticiclico declarado para investimento",
    motivacao_trecho="O projeto de lei orçamentária para 2023 não previu o valor necessário para assegurar a renda dos mais vulneráveis",
    motivacao_arquivo="fontes/M10/pec32-2022-texto-inicial-justificacao.pdf",
    motivacao_fonte="justificacao da PEC 32/2022, p. 2; http://legis.senado.leg.br/sdleg-getter/dadosabertos/documento/247978fe-577e-45e1-b488-c2e39601055e",
    tipo_principal="transferencias", tipo_secundario="regra fiscal; investimento; custeio",
    an=-175.0, an_pct=None, an_ano=2023, an_h="por ano, 2023 a 2026 na proposta; dotacao do programa fora do teto, dos quais 70 adicionais ao PLOA",
    an_f="fontes/M10/pec32-2022-texto-inicial-justificacao.pdf, p. 2",
    ap=-145.0, ap_pct=None, ap_ano=2023, ap_h="so 2023 (mais 22,9 de investimentos do par. 6-B, ja usados em 2022)",
    ap_f="fontes/M10/ec126-2022-planalto.html, art. 3",
    re=-145.0, re_pct=None, re_ano=2023, re_h="2023, deducao efetivamente usada na apuracao da meta",
    re_f="fontes/M10/pldo2025-anexo-iv-metas-fiscais-avaliacao-2023.pdf, p. 5 a 8 (PLDO 2025, Anexo IV)",
    et=("sim", "sim", "sim"), cmp=("re", -175.0, -145.0, "2023, valor fora do teto: dotacao proposta contra deducao usada"),
    nota="O realizado e a deducao legal usada, nao o gasto adicional causado pela EC. Indicador complementar: Bolsa Familia e Auxilio Brasil pagos em 2023 somaram 166,3 bi contra 105,7 previstos no PLOA (RTN dez/2023 e IFI). Totais do aprovado divergem entre fontes (161,9 a 171,4).")

add(id="M11", medida="LC 200/2023 (Regime Fiscal Sustentavel, arcabouco): valor = meta de resultado primario do Governo Central",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3",
    ato_proposta="PLP 93/2023, EMI 52/2023 MF MPO", ato_aprovado="LC 200/2023; metas nas LDOs 2024 (Lei 14.791), 2025 (Lei 15.080) e 2026 (Lei 15.321)",
    data_anuncio="2023-03-30", data_aprovacao="2023-08-30",
    motivacao_classe="consolidacao",
    motivacao_trecho="propõe-se um novo regime fiscal que garante a sustentabilidade fiscal de médio e longo prazo (despesas crescendo menos que a receita), mas com flexibilidade para se adequar a diferentes ciclos econômicos e políticos",
    motivacao_arquivo="fontes/M11/plp93-2023-inteiro-teor.pdf",
    motivacao_fonte="EMI 52/2023, par. 13 (p. 9 a 11); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2260147",
    tipo_principal="regra fiscal", tipo_secundario="",
    an=None, an_pct=0.5, an_ano=None, an_h="meta de 2025 anunciada (0 em 2024, +0,5% em 2025, +1,0% em 2026, banda de 0,25)",
    an_f="fontes/M11/fazenda-noticia-2023-03-30-nova-regra-fiscal.html (Fazenda, 30/03/2023, via Wayback); R$: PLDO 2024 em fontes/M11/ifi-raf75_abr2023.pdf, p. 18 (+61,6 bi em 2025)",
    ap=None, ap_pct=0.0, ap_ano=None, ap_h="meta de 2025 aprovada na LDO 2025: R$ 0,00 com tolerancia de 30,97 bi; trajetoria rebaixada no PLDO 2025 (0; 0,25; 0,50; 1,00 de 2025 a 2028)",
    ap_f="fontes/M11/lei15080-2024-ldo2025-planalto.htm, art. 2; fontes/M11/pldo2025-anexo-iv2-metas-fiscais-anuais.pdf, p. 5",
    re=-61.7, re_pct=-0.48, re_ano=2025, re_h="resultado primario do Governo Central em 2025, acima da linha (antes das deducoes legais; a meta foi considerada cumprida com elas)",
    re_f="fontes/M11/rtn-dez2025.pdf, p. 7; % do PIB em fontes/M11/rtn-dez2025-serie-historica.xlsx; cumprimento: fontes/M11/pldo2027-anexo-iv1-avaliacao-metas-2025.pdf, p. 5 e 6",
    et=("sim", "sim", "sim"), cmp=None,
    nota="Regra fiscal: as etapas sao meta anunciada, meta aprovada e resultado, nao economia de uma medida; fica fora das razoes. 2024: meta 0, resultado -0,36% do PIB (RTN dez/2024). O resultado de 2025 ficou cerca de 1 ponto do PIB abaixo da meta anunciada em 2023.")

add(id="M12", medida="Tributacao federal das subvencoes de ICMS (Lei 14.789/2023)",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3",
    ato_proposta="MP 1.185/2023, EM 109/2023 MF", ato_aprovado="Lei 14.789/2023",
    data_anuncio="2023-08-30", data_aprovacao="2023-12-29",
    motivacao_classe="consolidacao",
    motivacao_trecho="os dispositivos promulgados causaram distorções tributárias, com impactos profundamente negativos para a arrecadação federal",
    motivacao_arquivo="fontes/M12/mpv1185-camara-inteiro-teor.pdf",
    motivacao_fonte="EM 109/2023, par. 7 (p. 5 e 6); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2479846",
    tipo_principal="receita", tipo_secundario="",
    an=35.3, an_pct=None, an_ano=2024, an_h="2024 (32,4 em 2025, 34,1 em 2026, 36,1 em 2027)",
    an_f="fontes/M12/mpv1185-camara-inteiro-teor.pdf, p. 7, par. 21",
    ap=25.862, ap_pct=None, ap_ano=2024, ap_h="2024, 12 meses, reestimativa do Executivo depois da Lei 14.789",
    ap_f="fontes/M12/rardp-1bim2024.pdf, p. 42 (35.348 no PLOA contra 25.862 no Relatorio)",
    re=None, re_pct=None, re_ano=None, re_h="",
    re_f="sem fonte oficial encontrada (Analises da Arrecadacao 2024 e 2025, RTN, Relatorios bimestrais, IFI RAF 77 a 116). O 2o bim 2025 (fontes/M12/rardp-2bim2025.pdf, p. 46) diz que a receita passou a ser tratada como efeito na legislacao",
    et=("sim", "sim", "nao"), cmp=("ap", 35.3, 25.862, "2024"),
    nota="IFI estimou para 2024 entre 3,5 e 7,6 bi (RAF 80, 85 e 88). Reestimativas do Executivo para o resto de 2024 cairam a cada bimestre.")

add(id="M13", medida="Tributacao de fundos exclusivos e de offshores (Lei 14.754/2023)",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3",
    ato_proposta="MP 1.184/2023 (EM 104/2023 MF) e PL 4.173/2023 (EM 105/2023 MF)", ato_aprovado="Lei 14.754/2023",
    data_anuncio="2023-08-28", data_aprovacao="2023-12-12",
    motivacao_classe="outra: isonomia tributaria e compensacao da correcao da tabela do IRPF",
    motivacao_trecho="o incremento de arrecadação decorrente das medidas propostas visa compensar a redução de receita decorrente da alteração da legislação de Imposto sobre a Renda das Pessoas Físicas",
    motivacao_arquivo="fontes/M13/mpv1184-camara-inteiro-teor.pdf",
    motivacao_fonte="EM 104/2023, par. 39 (p. 16); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2479845",
    tipo_principal="receita", tipo_secundario="",
    an=20.33, an_pct=None, an_ano=2024, an_h="2024, soma de fundos (13,28) e offshores (7,05); 2023 a 2026 somam 44,79",
    an_f="fontes/M13/mpv1184-camara-inteiro-teor.pdf, p. 16, par. 40; fontes/M13/pl4173-2023-inteiro-teor.pdf, p. 19, par. 42",
    ap=18.92, ap_pct=None, ap_ano=2024, ap_h="2024, reestimativa depois da lei: fundos 13,28 e offshores 5,64",
    ap_f="fontes/M13/rardp-1bim2024.pdf, p. 42",
    re=20.67, re_pct=None, re_ano=2024, re_h="2024, R$ de dez/2024: fundos exclusivos 13,0 e atualizacao de bens no exterior 7,67 (recolhimentos de estoque; fluxo recorrente nao isolado)",
    re_f="fontes/M13/rfb-analise-arrecadacao-dez2024.pdf, p. 4 (tabela de fatores nao recorrentes)",
    et=("sim", "sim", "sim"), cmp=("re", 20.33, 20.67, "2024"), cmp2=("ap", 20.33, 18.92, "2024"),
    nota="Em dez/2023 entraram mais 3,9 bi de fundos (anunciado para 2023: 3,21). Em 2025 o estoque ja tinha sido recolhido (RFB dez/2025).")

add(id="M14", medida="Reoneracao da folha e dos municipios, fim do Perse e limite de compensacoes (MP 1.202/2023), que terminou na transicao da Lei 14.973/2024",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3 (MP 1.202); Senado (PL 1.847/2024, acordo com o Executivo)",
    ato_proposta="MP 1.202/2023 (EM 175/2023 MF); MP 1.208/2024; PL 1.847/2024", ato_aprovado="Lei 14.973/2024; Lei 14.873/2024 (limite de compensacao); Lei 14.859/2024 (Perse)",
    data_anuncio="2023-12-28", data_aprovacao="2024-09-16",
    motivacao_classe="consolidacao",
    motivacao_trecho="A relevância da medida está demonstrada pelo seu impacto fiscal, que pode comprometer o alcance da meta fiscal",
    motivacao_arquivo="fontes/M14/mpv1202-camara-inteiro-teor.pdf",
    motivacao_fonte="EM 175/2023, par. 48 (p. 11); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2479863",
    tipo_principal="receita", tipo_secundario="previdencia",
    an=0.39, an_pct=None, an_ano=2024, an_h="2024, liquido da EM (Perse +6,01, nova desoneracao parcial -5,62); limite de compensacao sem valor na EM (24,0 em 12 meses no 1o bim 2024)",
    an_f="fontes/M14/mpv1202-camara-inteiro-teor.pdf, p. 11, par. 52; fontes/M14/rardp-1bim2024.pdf, p. 42",
    ap=-8.0, ap_pct=None, ap_ano=2024, ap_h="2024: custo de manter a desoneracao de empresas e municipios (-26,3, RFB) menos compensacoes da Lei 14.973 (+18,3); saldo calculado aqui",
    ap_f="fontes/M14/ifi-raf92_set2024.pdf, p. 8, 9 e 12",
    re=None, re_pct=None, re_ano=None, re_h="",
    re_f="sem efeito isolado oficial. Renuncia da folha (RFB): 23,2 bi em 2024 e 18,8 em 2025 (fontes/M14/rfb-analise-arrecadacao-dez2025.pdf, p. 34); compensacoes realizadas de 8,2 bi em 2024 contra 18,3 previstas (fontes/M14/rtn-dez2024.pdf, p. 5)",
    et=("sim", "sim", "parcial"), cmp=None,
    nota="A medida mudou de natureza: a reoneracao imediata virou desoneracao integral em 2024 e transicao de 2025 a 2027. O aprovado e renuncia parcialmente compensada, com sinal oposto ao anunciado.")

add(id="M15", medida="Pacote de contencao de gastos de novembro de 2024 (salario minimo no arcabouco, abono, BPC, Bolsa Familia, Fundeb, DRU, gatilhos)",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3 (PEC 45 com EM; PLP 210 e PL 4.614 pelo lider do governo)",
    ato_proposta="PEC 45/2024 (EM 146/2024 MF); PLP 210/2024; PL 4.614/2024", ato_aprovado="EC 135/2024; Lei 15.077/2024; LC 211/2024",
    data_anuncio="2024-11-27", data_aprovacao="2024-12-30",
    motivacao_classe="consolidacao",
    motivacao_trecho="para alinhar o crescimento das despesas obrigatórias aos limites da nova regra fiscal",
    motivacao_arquivo="fontes/M15/pec45-2024-inteiro-teor.pdf",
    motivacao_fonte="EM 146/2024 MF, item 7 (p. 4 e 5); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2830980",
    tipo_principal="transferencias", tipo_secundario="regra fiscal; custeio; pessoal",
    an=71.9, an_pct=None, an_ano=None, an_h="2025 e 2026 somados (30,6 e 41,3); 327 de 2025 a 2030",
    an_f="fontes/M15/fazenda-apresentacao-medidas-fortalecimento-2024-11-28.pdf (Fazenda, via Wayback), p. 21 (imagem); 71,9 tambem na coluna 'Pacote Original' de fontes/M15/fazenda-pacote-fiscal-tabelas-impacto-metodologia-v2.pdf, p. 3",
    ap=69.8, ap_pct=None, ap_ano=None, ap_h="2025 e 2026 somados, 'Pacote Final' (inclui itens fora dos tres atos, como LC 210 de emendas, 14,4; so os tres atos somam 48,4)",
    ap_f="fontes/M15/fazenda-pacote-fiscal-tabelas-impacto-metodologia-v2.pdf (Fazenda, dez/2024), p. 3",
    re=None, re_pct=None, re_ano=None, re_h="",
    re_f="sem fonte oficial de economia realizada. O PLDO 2026 (fontes/M15/pldo2026-anexo-iv-2-metas-fiscais-anuais.pdf, p. 12) so repete 'quase R$ 70 bilhões' entre 2025 e 2026; IFI RAF 101 (p. 36): pacote 'muito aquém das necessidades'",
    et=("sim", "sim", "nao"), cmp=("ap", 71.9, 69.8, "2025 e 2026"),
    nota="IFI (RAF 95, p. 24) nao incorporou o pacote; pelo modelo da IFI a regra do salario minimo economiza 6,1 bi em 2025, contra 2,2 bi da Fazenda.")

add(id="M16", medida="Reforma do IR da pessoa fisica: isencao ate R$ 5 mil e imposto minimo sobre altas rendas (Lei 15.270/2025)",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3",
    ato_proposta="PL 1.087/2025, EM 19/2025 MF", ato_aprovado="Lei 15.270/2025",
    data_anuncio="2025-03-18", data_aprovacao="2025-11-26",
    motivacao_classe="outra: redistributiva, desenhada como neutra (renuncia compensada)",
    motivacao_trecho="quanto maior o rendimento do contribuinte, menor a tributação efetiva",
    motivacao_arquivo="fontes/M16/pl1087-2025-inteiro-teor.pdf",
    motivacao_fonte="EM 19/2025 MF, item 9 (p. 11); https://www.camara.leg.br/proposicoesWeb/prop_mostrarintegra?codteor=2868788",
    tipo_principal="receita", tipo_secundario="",
    an=8.28, an_pct=None, an_ano=2026, an_h="2026, liquido: compensacao 34,12 menos renuncia 25,84 (calculado aqui); 2027 +11,46 e 2028 +9,96",
    an_f="fontes/M16/pl1087-2025-inteiro-teor.pdf, p. 14, itens 24 e 26",
    ap=-1.0, ap_pct=None, ap_ano=None, ap_h="media anual de 2026 a 2028 do texto final (IFI); o Executivo trata a lei como neutra (PLOA 2026)",
    ap_f="fontes/M16/ifi-raf105_out2025.pdf, p. 12; neutro: fontes/M16/ifi-raf107_dez2025.pdf, p. 16, Tabela 4",
    re=None, re_pct=None, re_ano=None, re_h="",
    re_f="sem realizado isolado. O 1o bim 2026 (fontes/M16/rardp-1o-bim-2026.pdf, p. 15, item 27) subiu o IR em 5,5 bi frente a LOA pela incorporacao 'dos efeitos esperados da Lei 15.270/25', o que nao mede o efeito liquido",
    et=("sim", "sim", "nao"), cmp=None,
    nota="O sinal mudou no Congresso: liquido anunciado de +8,28 em 2026; parecer da Comissao Especial +2,87; texto final cerca de -1,0 por ano (IFI). Horizontes de anunciado (2026) e aprovado (media 2026 a 2028) diferem: sem razao.")

add(id="M17a", medida="Elevacao do IOF (Decretos 12.466, 12.467 e 12.499/2025), sustada pelo Congresso e restabelecida em parte pelo STF (ADC 96)",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3",
    ato_proposta="Decretos 12.466 e 12.467/2025 (sem EM) e Decreto 12.499/2025", ato_aprovado="Decreto 12.499/2025 restabelecido pela cautelar da ADC 96 (16/07/2025), sem o risco sacado; DL 176/2025 tinha sustado os decretos",
    data_anuncio="2025-05-22", data_aprovacao="2025-07-16",
    motivacao_classe="consolidacao",
    motivacao_trecho="as alterações auxiliarão o atingimento das metas fiscais para 2025",
    motivacao_arquivo="fontes/M17/fazenda-noticia-2025-05-22-contingenciamento-iof-wayback.html",
    motivacao_fonte="noticia oficial da Fazenda de 22/05/2025 (via Wayback), par. 4; decretos nao tem EM",
    tipo_principal="receita", tipo_secundario="",
    an=20.5, an_pct=None, an_ano=2025, an_h="2025 (41 em 2026)",
    an_f="fontes/M17/fazenda-apresentacao-iof-2025-05-22.pdf (Fazenda, via Wayback), p. 12",
    ap=8.4, ap_pct=None, ap_ano=2025, ap_h="ultimos 5 meses de 2025, depois da ADC 96 (27,8 em 2026)",
    ap_f="fontes/M17/ifi-raf103_ago2025.pdf, p. 7 (dados da Receita Federal); o 3o bim 2025 reduziu o IOF em 10,17 bi pela decisao (fontes/M17/rardp-3o-bim-2025.pdf, p. 17, item 31)",
    re=13.8564, re_pct=None, re_ano=2025, re_h="2025: projecao do IOF no 5o bim (85.216,7 mi) menos a LOA (71.360,3 mi), calculado aqui; inclui revisoes de base",
    re_f="fontes/M17/rardp-5o-bim-2025.pdf, p. 14; arrecadacao de 2025: 86.477 mi, +20,54% real, 'sobretudo' pelo Decreto 12.499 (fontes/M17/rfb-analise-arrecadacao-dez-2025.pdf, p. 6)",
    et=("sim", "sim", "parcial"), cmp=("re", 20.5, 13.8564, "2025, anuncio de maio contra revisao oficial da projecao (nao isolado)"),
    nota="O aprovado (8,4) cobre so agosto a dezembro; o realizado inclui junho e a base, por isso supera o aprovado.")

add(id="M17b", medida="MP 1.303/2025 (aplicacoes financeiras, JCP, CSLL de fintechs, apostas, limite a compensacoes), alternativa a parte do aumento do IOF",
    presidente="Lula 3", presidente_aprovacao="Lula 3", governo_proponente="Lula 3",
    ato_proposta="MP 1.303/2025, EMI 41/2025 MF MGI", ato_aprovado="nenhum: a MP caducou em 08/10/2025 (Ato Declaratorio 67/2025); o limite a compensacoes foi aprovado depois na Lei 15.265/2025",
    data_anuncio="2025-06-11", data_aprovacao="",
    motivacao_classe="consolidacao",
    motivacao_trecho="O ganho de arrecadação decorrente medidas acima poderá compensar a redução de receita decorrente das alterações do Imposto sobre Operações de Crédito",
    motivacao_arquivo="fontes/M17/planalto-em-mpv1303-2025.pdf",
    motivacao_fonte="EMI 41/2025, item 45 (p. 6); https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/Exm/Exm-1303-25.pdf",
    tipo_principal="receita", tipo_secundario="",
    an=10.55, an_pct=None, an_ano=2025, an_h="2025 (20,87 em 2026, 11,94 em 2027, 9,2 em 2028); soma da tabela da EMI calculada aqui",
    an_f="fontes/M17/planalto-em-mpv1303-2025.pdf, p. 6, item 44",
    ap=0.0, ap_pct=None, ap_ano=2025, ap_h="caducou",
    ap_f="fontes/M17/planalto-adc67-mpv1303-encerramento.html; IFI: 10,6 bi a menos em 2025 (fontes/M17/ifi-raf105_out2025.pdf, p. 5)",
    re=None, re_pct=None, re_ano=2025, re_h="caducou; a receita de jun a out de 2025 nao foi isolada em fonte oficial, entao o realizado nao e medido (correcao pela auditoria v11, E2)",
    re_f="fontes/M17/planalto-adc67-mpv1303-encerramento.html",
    et=("sim", "sim", "nao"), cmp=None,
    nota="Exemplo de medida anunciada e nao aprovada. Valor realizado zero por definicao (nao medido).")

# ---------------------------------------------------------------- verificacao dos trechos
def texto_arquivo(rel):
    p = os.path.join(AQUI, rel)
    if p.endswith(".pdf"):
        import pymupdf
        return "\n".join(pg.get_text() for pg in pymupdf.open(p))
    if p.endswith((".html", ".htm")):
        raw = open(p, "rb").read()
        for enc in ("utf-8", "cp1252", "latin-1"):
            try:
                s = raw.decode(enc); break
            except UnicodeDecodeError:
                continue
        return html.unescape(re.sub(r"<[^>]+>", " ", s))
    if p.endswith(".doc"):
        raw = open(p, "rb").read()
        return raw.decode("cp1252", "ignore") + "\n" + raw.decode("utf-16le", "ignore")
    if p.endswith(".docx"):
        x = zipfile.ZipFile(p).read("word/document.xml").decode("utf-8")
        return html.unescape(re.sub(r"<[^>]+>", "", x))
    return open(p, encoding="utf-8", errors="ignore").read()

def norm(s):
    s = s.replace("­", "").replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'")
    s = re.sub(r"-\s*\n\s*", "", s)
    return re.sub(r"\s+", " ", s).strip().lower()

def confere(trecho, rel):
    bruto = texto_arquivo(rel)
    t = norm(bruto)
    q = norm(trecho)
    if q in t or q in re.sub(r"\s+", " ", re.sub(r"-\s*\n\s*", "-", bruto)).lower():
        return "sim"
    # tolera quebra de linha que some espaco ou hifenizacao do PDF
    if q.replace(" ", "") in t.replace(" ", ""):
        return "sim (ignorando espacos)"
    return "nao encontrado no arquivo"

# ---------------------------------------------------------------- saida
COLS = ["id", "medida", "presidente", "presidente_aprovacao", "governo_proponente", "ato_proposta", "ato_aprovado",
        "data_anuncio", "data_aprovacao", "motivacao_classe", "motivacao_trecho", "motivacao_arquivo",
        "motivacao_trecho_conferido", "motivacao_fonte", "tipo_principal", "tipo_secundario",
        "anunciado_rs_bi", "anunciado_pct_pib", "anunciado_pct_origem", "anunciado_horizonte", "anunciado_fonte",
        "aprovado_rs_bi", "aprovado_pct_pib", "aprovado_pct_origem", "aprovado_horizonte", "aprovado_fonte",
        "realizado_rs_bi", "realizado_pct_pib", "realizado_pct_origem", "realizado_horizonte", "realizado_fonte",
        "etapa_anunciado", "etapa_aprovado", "etapa_realizado", "etapas_medidas",
        "comparacao", "razao_aprovado_sobre_anunciado", "razao_realizado_sobre_anunciado", "nota"]

def fmt(v, nd=2):
    return "" if v is None else ("%.*f" % (nd, v))

def pct(v, p, ano, origem=None):
    if p is not None:
        return fmt(p), (origem or "fonte")
    if v is not None and ano in PIB:
        return fmt(100.0 * v / PIB[ano], 2), "calculado: R$ / PIB IBGE de %d (R$ %.1f bi)" % (ano, PIB[ano])
    return "", ("sem % na fonte; horizonte de varios anos ou ano sem PIB anual" if v is not None else "")

linhas, razoes = [], []
for r in R:
    o = {k: "" for k in COLS}
    for k in ("id", "medida", "presidente", "presidente_aprovacao", "governo_proponente", "ato_proposta",
              "ato_aprovado", "data_anuncio", "data_aprovacao", "motivacao_classe", "motivacao_trecho",
              "motivacao_arquivo", "motivacao_fonte", "tipo_principal", "tipo_secundario", "nota"):
        o[k] = r.get(k, "")
    o["motivacao_trecho_conferido"] = confere(r["motivacao_trecho"], r["motivacao_arquivo"])
    for et, pre in (("an", "anunciado"), ("ap", "aprovado"), ("re", "realizado")):
        o[pre + "_rs_bi"] = fmt(r[et], 2)
        o[pre + "_pct_pib"], o[pre + "_pct_origem"] = pct(r[et], r[et + "_pct"], r[et + "_ano"], r.get(et + "_pct_origem"))
        o[pre + "_horizonte"] = r[et + "_h"]
        o[pre + "_fonte"] = r[et + "_f"]
    o["etapa_anunciado"], o["etapa_aprovado"], o["etapa_realizado"] = r["et"]
    o["etapas_medidas"] = str(sum(1 for e in r["et"] if e == "sim"))
    comps = [c for c in (r.get("cmp"), r.get("cmp2")) if c]
    txt = []
    for tipo, a, b, desc in comps:
        q = b / a if a else float("nan")
        col = "razao_aprovado_sobre_anunciado" if tipo == "ap" and a == r["an"] else "razao_realizado_sobre_anunciado"
        if tipo == "ap" and a != r["an"]:
            txt.append("aprovado (%.1f) contra realizado (%.1f), %s: %.2f" % (a, b, desc, q))
            continue
        o[col] = fmt(q, 2)
        txt.append("%s: %.1f contra %.1f, %s" % ("aprovado/anunciado" if tipo == "ap" else "realizado/anunciado", a, b, desc))
        razoes.append((r["id"], tipo, a, b, q, r["motivacao_classe"], r["tipo_principal"]))
    o["comparacao"] = "; ".join(txt) if txt else "sem par comparavel (conceito ou horizonte diferentes)"
    linhas.append(o)

for o in linhas:
    for k, v in o.items():
        if chr(0x2014) in v:
            sys.exit("travessao em %s %s" % (o["id"], k))

with open(SAIDA, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=COLS)
    w.writeheader()
    w.writerows(linhas)

# ---------------------------------------------------------------- resumo para o LEIAME
print("medidas:", len(linhas))
print("trechos conferidos:", {o["id"]: o["motivacao_trecho_conferido"] for o in linhas})
tres = [o["id"] for o in linhas if o["etapas_medidas"] == "3"]
print("tres etapas medidas (sim/sim/sim):", len(tres), tres)
print("por motivacao:", {c: sum(1 for o in linhas if o["motivacao_classe"].split(":")[0] == c)
                          for c in sorted({o["motivacao_classe"].split(":")[0] for o in linhas})})
for tipo in ("re", "ap"):
    qs = [(i, q, a) for i, t, a, b, q, m, tp in razoes if t == tipo]
    print("razoes", tipo, [(i, round(q, 2)) for i, q, a in qs])
    if qs:
        print("  mediana", round(statistics.median(q for _, q, _ in qs), 2))
        cons = [q for i, q, a in qs if a > 0]
        exp = [q for i, q, a in qs if a < 0]
        if cons: print("  melhoras (a>0): n=%d mediana %.2f" % (len(cons), statistics.median(cons)))
        if exp: print("  pioras (a<0): n=%d mediana %.2f" % (len(exp), statistics.median(exp)))
print("auxilio abr-jun 2020: %.2f; auxilio 2021: %.2f" % (AUX_2020_ABR_JUN, AUX_2021))

# poder: erro padrao de Y15 (IC90% de 0,6 a 1,2 a 2 anos, N = 364 pais-anos na Tabela 1) escalado para o Brasil
se_y15 = (1.2 - 0.6) / (2 * 1.645)
n_y15, n_br = 364, 2024 - 2017 + 1  # anos com 2 defasagens e horizonte de 2 anos dentro de 2015-2026
se_br = se_y15 * math.sqrt(n_y15 / n_br)
print("poder: ep Y15 %.3f; N Brasil %d; ep escalado %.2f; efeito minimo detectavel (80%%, 5%% bilateral) %.1f"
      % (se_y15, n_br, se_br, 2.8 * se_br))

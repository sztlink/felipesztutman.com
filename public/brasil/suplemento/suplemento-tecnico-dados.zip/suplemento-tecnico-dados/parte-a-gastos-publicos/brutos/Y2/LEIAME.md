# Frente Y2: inventário narrativo de medidas fiscais, 2015 a 2026

Pergunta (BRIEF-v11, seção Y2): quais medidas fiscais brasileiras de 2015 a 2026 têm motivação, tamanho anunciado, tamanho aprovado e tamanho realizado documentados em fonte oficial, e essa amostra sustenta uma estimativa por projeções locais no método de Carriere-Swallow, David e Leigh (Y15)?

Feito em 19/10/2026. Produto: `../../Y2-medidas.csv`, com 19 linhas (17 medidas; a EC 109 e o pacote do IOF de 2025 aparecem em duas linhas cada, porque cada metade tem motivação ou desfecho próprio). Gerado por `build_Y2.py`. As fontes estão em `fontes/<ID>/`, com URL e data de consulta em `downloads.tsv` (376 arquivos). Rodar:

    PYTHONPATH=~/.local/lib/pdftools python3 -P build_Y2.py

## Método

Segue Y15 (p. 5 e 6 do PDF): motivação e tamanho lidos em documentos da época, como o efeito orçamentário estimado no momento da medida. A motivação vem do texto da exposição de motivos. Sem EM (proposta parlamentar ou decreto), vem da justificação, do parecer do relator ou de nota oficial, e a coluna `motivacao_fonte` diz qual foi usada. O script confere que cada trecho citado aparece literalmente no arquivo local (`motivacao_trecho_conferido`): os 19 conferem.

Fontes aceitas: EM, justificação e parecer; notas e apresentações da Fazenda, do Planejamento, da Previdência, da Receita e do Tesouro; Relatório de Avaliação de Receitas e Despesas Primárias (bimestral); RTN; PLDO; IFI; Conof e Conorf. Notícia de jornal não entra. Notícia oficial do governo serve só para datar anúncio (M01, M11, M17a) ou, sem EM, para a motivação (M17a). Uma exceção, declarada na linha: o realizado de M01 vem do Ipea (TD 3117, 2025), fundação federal, com contrafactual do Ministério do Trabalho.

Convenções:
- Valor positivo melhora o resultado primário; negativo piora. R$ bilhões correntes, salvo quando o horizonte diz outra coisa.
- `*_pct_pib`: o % da fonte quando ela dá. Senão, o script calcula R$ / PIB nominal do IBGE (SIDRA 1846, soma dos quatro trimestres) do ano do horizonte, e só quando o horizonte é um único ano com PIB anual completo (até 2025). `*_pct_origem` diz qual dos dois. Horizonte de vários anos fica sem %.
- `etapa_*`: "sim" quando há número de fonte oficial para o mesmo conceito da medida; "parcial" quando o número existe mas não isola o efeito ou cobre só parte da medida; "nao" quando não há número. `etapas_medidas` conta os "sim".
- Razões aprovado/anunciado e realizado/anunciado só são calculadas quando as duas etapas medem o mesmo conceito no mesmo horizonte. O par usado está descrito em `comparacao`.
- `presidente` é o presidente na data do anúncio; `presidente_aprovacao`, na aprovação; `governo_proponente` separa quem propôs quando difere (M10: a transição de Lula propôs, Bolsonaro estava no cargo).

Gaps de acesso, todos contornados sem trocar de fonte:
- As páginas da Fazenda e do antigo Ministério da Economia no gov.br devolvem hoje "Conteúdo Restrito". As cópias vêm do Wayback Machine (id_, o arquivo original), marcadas em `downloads.tsv`.
- O repositório bdsf do Senado pede verificação anti-robô. Alguns RAF da IFI vieram pelo Wayback.
- Três tabelas são imagem e foram lidas renderizando a página: M04 (slide 7 da SPREV, render em `fontes/M04/`), M06 (slide 8 do ME) e M15 (p. 21 da apresentação da Fazenda).

## As 19 linhas

| id | medida | presidente | motivação | anunciado | aprovado | realizado | etapas |
|---|---|---|---|---|---|---|---|
| M01 | MPs 664 e 665 (Leis 13.135 e 13.134) | Dilma | consolidação | +18,0/ano (0,3% do PIB) | +7,3 (2015) | +100,4 (2015 a 2023, só Lei 13.134, Ipea) | 2 |
| M02 | reoneração da folha (Lei 13.161) | Dilma | consolidação | +12,8/ano desde 2016 | +0,4 (2015) | até +9,6 (2016, não isolado) | 2 |
| M03 | EC 95 (teto) | Temer | consolidação | 4,0 pontos do PIB de despesa em 2025 (simulação) | sem número | sem número | 0 |
| M04 | EC 103 (Previdência) | Bolsonaro | consolidação | +1.072,4 (10 anos) | +800,3 (10 anos) | sem número | 2 |
| M05 | auxílio emergencial 2020 | Bolsonaro | pandemia | -15,0 (3 meses) | -98,2 (3 meses) | -293,1 (2020) | 3 |
| M06 | LC 173 | Bolsonaro | pandemia | -60,0 | -60,2 | -60,1 | 3 |
| M07a | EC 109, gatilhos | Bolsonaro | consolidação | +50 (10 anos, como espaço) | sem número | sem número | 0 |
| M07b | EC 109, auxílio 2021 | Bolsonaro | pandemia | -44,0 | -44,0 | -60,6 | 3 |
| M08 | EC 113 e 114 (precatórios) | Bolsonaro | outra: espaço sob o teto | -33,5 (2022) | -113,1 (2022) | -43,5 (2022) | 3 |
| M09 | EC 123 | Bolsonaro | eleitoral | -38,75 | -41,25 | -36,4 | 3 |
| M10 | EC 126 (transição) | Bolsonaro (proposta da transição de Lula) | outra: programa do eleito | -175,0 (2023) | -145,0 | -145,0 | 3 |
| M11 | LC 200 (arcabouço) | Lula 3 | consolidação | meta de 2025: +0,5% do PIB | meta de 2025: 0% | resultado de 2025: -0,48% do PIB | 3 |
| M12 | Lei 14.789 (subvenções de ICMS) | Lula 3 | consolidação | +35,3 (2024) | +25,9 (2024) | sem número | 2 |
| M13 | Lei 14.754 (fundos e offshores) | Lula 3 | outra: isonomia e compensação do IRPF | +20,3 (2024) | +18,9 | +20,7 | 3 |
| M14 | MP 1.202 e Lei 14.973 (folha, Perse) | Lula 3 | consolidação | +0,4 (2024) | -8,0 (2024) | não isolado | 2 |
| M15 | pacote de nov/2024 (EC 135, Lei 15.077, LC 211) | Lula 3 | consolidação | +71,9 (2025 e 2026) | +69,8 | sem número | 2 |
| M16 | Lei 15.270 (IR) | Lula 3 | outra: redistributiva, neutra | +8,3 (2026, líquido) | cerca de -1,0/ano (IFI) | sem número | 2 |
| M17a | IOF 2025 (Decreto 12.499) | Lula 3 | consolidação | +20,5 (2025) | +8,4 (ago a dez) | +13,9 (não isolado) | 2 |
| M17b | MP 1.303/2025 | Lula 3 | consolidação | +10,55 (2025) | 0 (caducou) | 0 | 3 |

R$ bilhões. O CSV traz horizonte, fonte, arquivo e página de cada número, e a nota de cada linha.

## Respostas

### 1. Quantas medidas têm as três etapas medidas

Nove das 19 linhas: M05, M06, M07b, M08, M09, M10, M11, M13 e M17b. Duas delas não são medida com tamanho próprio: M11 é regra fiscal, com meta e resultado no lugar de economia, e M17b vale zero porque a MP caducou. Sobram 7 com valor diferente de zero nas três etapas.

Dessas 7, seis são expansões: auxílio de 2020, LC 173, auxílio de 2021, precatórios, EC 123 e EC 126. A sétima é receita, a Lei 14.754, com motivação de isonomia e de compensação do IRPF. **Nenhuma das 11 linhas de consolidação, a categoria que entra na estimativa de Y15, tem as três etapas com valor diferente de zero em fonte oficial.** O motivo é de registro: o Tesouro acompanha o gasto executado por ação (tabela COVID do RTN, créditos extraordinários), mas nem a Receita nem a IFI publicam o efeito isolado de uma medida de receita ou de corte de despesa obrigatória depois que ela entra na base. Faltam o realizado de EC 95, EC 103, gatilhos da EC 109, subvenções, pacote de 2024 e Lei 15.270. Nas reonerações e no IOF, só há o agregado da renúncia ou da arrecadação.

### 2. Diferença típica entre anunciado e realizado

Há 10 pares com o mesmo conceito e o mesmo horizonte (coluna `razao_realizado_sobre_anunciado`):
- Razão realizado/anunciado: mediana de 0,97. A mediana esconde uma assimetria de sinal.
- Melhoras do resultado (M02, M13, M17a): mediana de 0,75. Valores: 0,75 (limite superior, não isolado), 1,02 e 0,68. A M17b (MP caducada) saiu da comparação: o realizado não é medido (correção pela auditoria v11, E2). Só a M13 tem efeito isolado (1,02).
- Pioras (M05, M06, M07b, M08, M09, M10): mediana de 1,15. Valores: 8,1, 1,00, 1,38, 1,30, 0,94 e 0,83. O caso extremo é o auxílio de 2020: R$ 15 bi anunciados para três meses e R$ 121,5 bi pagos de abril a junho, porque o Congresso triplicou o benefício.
- Em pontos do PIB do ano: a mediana do desvio absoluto é de 0,07 ponto. Em 6 dos 10 pares o realizado ficou pior para o primário do que o anunciado, por mais de 0,04 ponto. Em 2 ficou melhor (M09 e M10, expansões executadas abaixo do autorizado). Em 2 ficou igual (M06 e M13).

Do anunciado ao aprovado, nas quatro melhoras comparáveis (M04, M12, M13, M15), a razão vai de 0,73 a 0,97, com mediana de 0,84: o Congresso tira cerca de 15% da economia anunciada. Fora desse grupo, há quatro casos extremos de horizonte diferente:
- M02: 0,40 aprovado para 2015 contra 5,35 anunciado para o mesmo ano, por causa da vigência adiada.
- M14 e M16: o sinal se inverteu. Uma reoneração virou renúncia compensada, e uma reforma de IR com ganho líquido virou neutra ou com pequena perda.
- M08: o aprovado foi 3,4 vezes o anunciado, porque a mudança da correção do teto entrou na Câmara.

Leitura: com essa amostra, uma economia anunciada se realiza em cerca de 70% e um custo anunciado em cerca de 115%. A amostra é pequena, e as melhoras com realizado medido são quatro, duas delas sem efeito isolado: esses números descrevem o inventário, não são parâmetro.

### 3. Projeções locais: há poder estatístico? Não. A estimativa não foi feita.

1. **Tamanho.** Y15 estima o multiplicador em painel de 14 países com 364 observações país-ano (Tabela 1, p. 9 do PDF) e 76 choques não nulos, e chega a 0,9 com IC90% de 0,6 a 1,2. O erro padrão implícito é de 0,18. Uma série brasileira anual de 2015 a 2026, com duas defasagens e horizonte de 2 anos, deixa 8 anos utilizáveis. Escalando o erro padrão pela raiz do número de observações, o erro sobe para cerca de 1,2, e o efeito mínimo detectável (80% de poder, 5% bilateral) fica em multiplicador de 3,4, quase quatro vezes o efeito que se quer medir. A conta está no fim de `build_Y2.py`. É aproximação: ignora a variância dos choques e a dependência serial, e as duas pioram o quadro.
2. **Choques exógenos com tamanho.** Pelo critério de Y15, só entram medidas de consolidação implementadas, com o tamanho da época. São 11 linhas, mas sem valor em R$ em M03, M07a e M11, e concentradas em poucos anos (2015, 2019, 2024 e 2025). A própria Y15 tem um único choque brasileiro em 28 anos: 2015, de 0,80% do PIB (Tabela A2, p. 31 do PDF). As expansões de 2020 a 2022 respondem à pandemia ou ao calendário eleitoral. São endógenas ao ciclo pelo critério de Romer e Romer e não entram.
3. **Frequência.** Passar a trimestral ou mensal não resolve. O tamanho das medidas é anual, e os anos de choque continuam sendo os mesmos poucos.
4. **Confusão.** 2015 e 2016 (recessão e impeachment), 2020 e 2021 (pandemia) e 2024 e 2025 (pacote, IOF e Selic em alta) juntam várias medidas e choques no mesmo ano. Com um só país, não há efeito fixo de tempo para absorver isso.

Pela regra do brief ("estimativa só se houver poder estatístico; senão, o inventário é o produto"), o produto é o inventário. Ele serve de lista de datas e tamanhos para o estudo de eventos diário da frente N2, em que o poder vem do número de dias e não do número de anos. Também serve de prior para o simulador: descontar cerca de 30% das economias anunciadas e acrescentar cerca de 15% aos custos anunciados, como faixa de sensibilidade e não como parâmetro.

## BIS Working Paper 1364: existe e foi aberto

O PDF abriu em 19/10/2026 na URL indicada (HTTP 200, `application/pdf`, 70 páginas, metadado "BIS Working Paper No 1364, June 2026"). Ficou salvo em `fontes/bis-wp1364.pdf`. A ficha abaixo segue as colunas de `../../Y-literatura.csv`, com id provisório Y26. A ficha **não** foi incluída no Y-literatura.csv.

Resumo:
- **Amostra:** 12 economias, 11 avançadas e o México, com painel mensal de 2012 a 2025.
- **Método:** choque de risco fiscal identificado por restrição de sinal num BVAR diário (o soberano sobe e o corporativo mais seguro cai), usado como instrumento do juro de 5 anos em projeções locais de painel em dois estágios.
- **Magnitude:** 1 ponto de alta do juro de 5 anos por risco fiscal eleva a inflação em 1% a 1,5% em 10 meses e o juro de 10 anos em 0,5 a 1,0 ponto no primeiro ano. A produção cai a partir de 16 a 18 meses.
- **O Brasil não está na amostra principal.** Ele aparece na base de títulos de 60 países (Tabela A.1, BRA em BRL), mas não cumpre o mínimo de 84 meses de série de 5 anos para entrar no painel (p. 9, nota 5). Aparece só numa subamostra de 5 países (Brasil, Canadá, Alemanha, México e EUA), usada para medir a incerteza do choque estimado (Figura F.4, p. 65), sem coeficiente próprio.
- **Poder estatístico:** os próprios autores dizem que N = 12 "provide severely limited statistical power" para interações com a dívida (nota 24, p. 31). É o mesmo problema da resposta 3, num painel 12 vezes maior que o Brasil sozinho.

```csv
id,autores,ano,titulo,instituicao_ou_periodico,revisado_por_pares,link,arquivo_local,pais_ou_amostra,periodo,variavel_dependente,taxa_afetada,medida_fiscal,tipo_variavel_fiscal,estrategia_identificacao,magnitude,ic_ou_erro_padrao,pagina_ou_tabela,classe_evidencia,resultado,limitacoes_brasil_hoje,tema,amostra_texto,identificacao_texto,resultado_texto,limitacao_texto
Y26,Denis Gorea; Ding Xuan Ng; Fabrizio Zampolli,2026,Financial and real effects of fiscal risk,"BIS, Working Paper No 1364 (junho de 2026)",nao (working paper),https://www.bis.org/publications/working-paper-1364-financial-and-real-effects-fiscal-risk.pdf,brutos/Y2/fontes/bis-wp1364.pdf,"12 economias no painel mensal (Austria, Belgica, Canada, Suica, Alemanha, Espanha, Franca, Reino Unido, Italia, EUA, Mexico, Portugal); Mexico e o unico emergente; Brasil fora do painel principal",titulos diarios de 2010 a 2025; painel mensal de 2012 a 2025,"CPI, producao industrial, PMI composto, expectativa de inflacao de 1 ano, cambio efetivo nominal, juro de 10 anos, inclinacao 10a menos 1a, bolsa","juro nominal soberano de 5 anos (instrumentado), juro de 10 anos e inclinacao",choque de risco fiscal identificado no mercado de titulos (nao e medida fiscal nem saldo),choque identificado,"BVAR diario por pais com rendimento soberano e dos corporativos mais seguros de 5 anos e restricao de sinal (soberano sobe, corporativo seguro cai); projecoes locais em painel em dois estagios, com o choque como instrumento externo do juro de 5 anos; efeito fixo de pais; erros agrupados por pais com correcao de IV","por 1 ponto de alta do juro de 5 anos causada por risco fiscal: CPI sobe 1% a 1,5% em 10 meses e depois volta a zero; expectativa de inflacao de 1 ano sobe cerca de 0,5 ponto por cerca de 5 meses; producao industrial sobe nos 4 primeiros meses e cai depois, com queda significativa a partir de 16 a 18 meses; juro de 10 anos sobe 0,5 a 1,0 ponto no primeiro ano; cambio deprecia a partir de 6 meses; com CDS alto (p90, 127 pb) a expectativa de inflacao sobe 0,15 a 0,18 ponto a mais em 2 anos do que com CDS baixo (p10, 12 pb)","bandas de 67% (IV corrigido, agrupado por pais); bootstrap por blocos (1.000 replicacoes) nao muda sinal nem significancia","p. 9 do PDF, nota 5 (12 paises; p. impressa 7); p. 19 do PDF (resultados; p. impressa 17); Figura 3, p. 21; nota 24, p. 31; Figura 5, p. 33; Tabela A.1, p. 41 (BRA na base de titulos); Figura F.4, p. 65 (subamostra de 5 paises com o Brasil)",causal identificada (sob as restricoes de sinal do BVAR),efeito grande e estagflacionario,"o Brasil esta na base de titulos (Tabela A.1), mas nao no painel de 12 paises, que exige 84 meses de serie de 5 anos; aparece so numa subamostra de 5 paises usada para medir a incerteza do choque (Figura F.4), sem coeficiente proprio; painel de avancadas com um emergente; os autores dizem que N = 12 da poder estatistico muito limitado para interacoes com divida (nota 24); a unidade e 1 ponto de juro causado por risco fiscal, nao 1 ponto do PIB de medida, e nao se converte direto em efeito de medida brasileira",1;4,"12 economias, 11 avançadas e o México, com títulos diários de 2010 a 2025 e painel mensal de 2012 a 2025. O Brasil está na base de títulos, mas fica fora do painel.",Choque de risco fiscal identificado por restrição de sinal num BVAR diário (o soberano sobe e o corporativo mais seguro cai) e usado como instrumento do juro de 5 anos em projeções locais de painel.,"Um ponto de alta do juro de 5 anos por risco fiscal eleva a inflação em 1% a 1,5% em 10 meses e o juro de 10 anos em 0,5 a 1,0 ponto no primeiro ano, e a produção cai depois de 16 a 18 meses (p. 19 e Figura 3, p. 21 do PDF).","O Brasil não entra no painel principal e só aparece numa subamostra de robustez sem coeficiente próprio. A unidade é juro, não ponto do PIB de medida fiscal."
```

## O que não foi encontrado em fonte oficial

- Realizado de EC 95, EC 103, gatilhos da EC 109, Lei 14.789, pacote de nov/2024 e Lei 15.270, e economia efetiva do congelamento da LC 173.
- Realizado isolado da Lei 13.135 (pensão e auxílio-doença) e da Lei 13.161.
- Valor em R$ do anúncio do teto (EM e apresentações do MF de 2016) e da meta de 2023 do arcabouço, que só aparece na imprensa.
- Economia anunciada nas EMs das MPs 664 e 665: as próprias consultorias registram a omissão (Conorf NT 2/2015, p. 9). O anunciado usado vem da fala do ministro do Planejamento nas notas taquigráficas do Senado.
- Slides do Ministério da Economia de 22/11/2021 com os 106,1 bi da PEC dos Precatórios. O número vem das notas taquigráficas oficiais do Senado.
- Nota técnica da Conof sobre a MP 1.303: o site não respondeu. O PL 493/2024 também ficou sem baixar, porque a API da Câmara caiu.

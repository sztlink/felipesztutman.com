# Frente AP, apuração do 2º turno presidencial de 25/10/2026

Retratos do JSON oficial de resultados do TSE (eleição 6258, 2º turno, e 6257, 1º turno) baixados durante a apuração, de 19h25
a 20h53 de Brasília, mais o fechamento (r2326, baixado em 26/10 às 7h46), uma requisição por vez com pausa de 3 s. Uso: medir como a leitura da apuração muda com a régua (projeção
ingênua, por swing contra o 1º turno, por swing próprio de cada UF) e quando a liderança deixou de ser reversível. Ainda não é
texto do dossiê. Hipótese se mede antes de virar texto.

| Caminho | O que é |
|---|---|
| `retratos/r<HHMM>/` | (bruto, fora do git como o resto de `brutos/`, 6,9 MB só no disco) br, 27 UFs e zz (exterior) de uma rodada. Até r1947 o nome vem do `hg` do br, depois da hora local. r1953 é cópia de r1947 (o br ficou congelado entre 19:47:59 e 19:54:57) |
| `retratos/r2/` | rodada de 19h27 (só br e 10 UFs) |
| `retratos/turno1/` | 1º turno por UF, 100% apurado. Soma confere voto a voto com a totalização publicada (Lula 45,16%, Flávio 47,03%) |
| `scripts/` | `placar.py` (br), `projeta.py` (baixa e projeta), `cmp.py`, `q4.py`, `q4sp.py`, `swsp.py`, `g3m.py`, `uf6.py`, `irrev.py` (pior caso por UF, `--minpst=N`) |
| `retratos/r2326/` | Fechamento. br, 27 UFs e zz totalizados às 23h26-23h27 de 25/10, 100% das seções, Lula com `e`="s" e `st`="Eleito" |
| `vigia.log` | br a cada minuto depois das 21h01 |
| `PREVISAO-15dias-2026-10-25.md` | Previsão dada às 23h12 de 25/10, antes do primeiro pregão, com tabela para conferir em 9/11 |

Marcos lidos nos retratos: Lula à frente até 19h43; Flávio à frente de 19h46 (14,57%) a 20h22, pico de +333.291 às 20h08
(30,82%); Lula de volta às 20h24 (47,62%); 99,75% às 21h11 com Lula 51,75% (64.065.122) e Flávio 48,25% (59.723.309).

Fechamento (r2326, 100% das seções às 23h26): Lula 64.256.232 (51,79%), Flávio 59.826.041 (48,21%), diferença 4.430.191.
Às 21h11 o TSE já declarava Lula reeleito, mas o campo `e` do JSON ainda era "n".
`swing-regioes-1t-2t.csv`: votos de Lula e Flávio por região no 1º turno (retratos/turno1) e no fechamento do 2º (retratos/r2326), participação de Lula na soma dos dois e ganho líquido (ganho de Lula menos ganho de Flávio). Exterior fora.

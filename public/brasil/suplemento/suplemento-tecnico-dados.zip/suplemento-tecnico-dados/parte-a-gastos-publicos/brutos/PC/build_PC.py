#!/usr/bin/env python3
# Frente PC, poder de compra e renda por faixa. Le os arquivos de fontes/ (baixa_PC.py) e escreve os CSV PC-*.csv na raiz.
# Precisa de openpyxl (site-packages do usuario), por isso roda com -P e nao com -I: cd /tmp && python3 -P <pacote>/brutos/PC/build_PC.py
import csv, html, json, os, re
import openpyxl
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes')
SIDRA = 'https://apisidra.ibge.gov.br/values'
U = {
  'trab': f'{SIDRA}/t/6390/n1/all/v/5933/p/all e {SIDRA}/t/6392/n1/all/v/6293/p/all',
  'dom': f'{SIDRA}/t/7533/n1/all/v/10816/p/all/c1019/all',
  'inpc': f'{SIDRA}/t/1736/n1/all/v/2289/p/all',
  'ipca': f'{SIDRA}/t/1737/n1/all/v/2266/p/all',
  'sm': "http://www.ipeadata.gov.br/api/odata4/ValoresSerie(SERCODIGO='MTE12_SALMIN12'); 2026 conferido no Decreto 12.797/2025, https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/D12797.htm",
  'cesta': 'https://www.dieese.org.br/cesta/produto (Sao Paulo, total da cesta, tempo de trabalho e gasto mensal)',
  'ifr': 'https://www.ipea.gov.br/cartadeconjuntura/wp-content/uploads/2026/09/260915_inflacao-por-faixa-de-renda_tabela.xlsx',
  'pof': f'{SIDRA}/t/6715/n1/all/v/1204/p/all/c339/all/c12190/all',
}
# mandatos por mes: Dilma afastada em 12/05/2016, Temer a partir de maio de 2016
MAND = [('FHC', (1995, 1), (2002, 12)), ('Lula 1 e 2', (2003, 1), (2010, 12)), ('Dilma', (2011, 1), (2016, 4)), ('Temer', (2016, 5), (2018, 12)),
        ('Bolsonaro', (2019, 1), (2022, 12)), ('Lula 3', (2023, 1), (2026, 12))]
pres_mes = lambda a, m: next(n for n, i, f in MAND if i <= (a, m) <= f)
pres_ano = lambda a: 'D/T' if a == 2016 else pres_mes(a, 6)
ant = lambda a, m: (a - 1, 12) if m == 1 else (a, m - 1)
sidra = lambda arq: json.load(open(os.path.join(F, arq), encoding='utf-8'))[1:]
def grava(nome, cab, linhas):
  with open(os.path.join(RAIZ, nome), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f, lineterminator='\n'); w.writerow(cab); w.writerows(linhas)
  print(nome, len(linhas))
r1 = lambda x, d=1: round(x, d)

# indices de preco mensais
ym = lambda c: (int(c[:4]), int(c[4:6]))
INPC = {ym(r['D3C']): float(r['V']) for r in sidra('sidra_1736_v2289.json')}
IPCA = {ym(r['D3C']): float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:]}
ULT = max(INPC); assert max(IPCA) == ULT, (max(IPCA), ULT)
mes_txt = lambda t: f'{t[1]:02d}/{t[0]}'

# 1. renda do trabalho, PNAD Continua, trimestre movel (valor real a precos do ultimo trimestre movel publicado)
TR = {ym(r['D3C']): (r['D3N'], float(r['V'])) for r in sidra('sidra_6390_v5933.json')}
MS = {ym(r['D3C']): float(r['V']) for r in sidra('sidra_6392_v6293.json')}
assert set(TR) == set(MS)
ULT_TR = max(TR)
grava('PC-renda-trabalho.csv', ['trimestre_movel', 'mes_final', 'presidente', 'rendimento_medio_real_rs', 'massa_real_rs_mi', 'precos_de', 'fonte_url'],
      [[TR[k][0], f'{k[0]}-{k[1]:02d}', pres_mes(*k), int(TR[k][1]), int(MS[k]), TR[ULT_TR][0], U['trab']] for k in sorted(TR)])

# 2. renda domiciliar per capita real por classe de percentil, PNAD Continua anual (precos medios do ultimo ano)
DOM = {}
for r in sidra('sidra_7533_v10816.json'):
  if r['V'] not in ('-', '...', 'X'): DOM[(int(r['D3C']), r['D4N'])] = float(r['V'])
ANOS_D = sorted({a for a, _ in DOM}); ULT_D = ANOS_D[-1]
BASE40 = ['Até o P10', 'Maior que o P10 até o P20', 'Maior que o P20 até o P30', 'Maior que o P30 até o P40']
# as classes simples tem o mesmo numero de pessoas (10% cada), entao a media dos 40% mais pobres e a media simples das quatro
lin = []
for a in ANOS_D:
  for c in ['Total', 'Até o P10'] + ['40% mais pobres (media das classes ate o P40)'] + ['Maior que o P90', 'Maior que o P99']:
    v = sum(DOM[(a, k)] for k in BASE40) / 4 if c.startswith('40%') else DOM[(a, c)]
    lin.append([a, pres_ano(a), c, r1(v, 0), ULT_D, U['dom']])
grava('PC-renda-domiciliar-faixas.csv', ['ano', 'presidente', 'classe', 'rendimento_domiciliar_per_capita_real_rs', 'precos_medios_de', 'fonte_url'], lin)
DV = {(x[0], x[2]): x[3] for x in lin}; dv = lambda a, c: DV[(a, c)]

# 3. salario minimo real, deflacionado pelo INPC, em R$ do ultimo mes do INPC
SM = {}
for r in json.load(open(os.path.join(F, 'ipea_MTE12_SALMIN12.json'), encoding='utf-8'))['value']:
  a, m = int(r['VALDATA'][:4]), int(r['VALDATA'][5:7])
  if (1994, 7) <= (a, m) <= ULT: SM[(a, m)] = float(r['VALVALOR'])
dec = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', open(os.path.join(F, 'planalto_D12797_2025.htm'), 'rb').read().decode('latin-1'))))
assert 'A partir de 1º de janeiro de 2026, o valor do salário mínimo será de R$ 1.621,00' in dec and SM[(2026, 1)] == 1621.0
real = lambda k: SM[k] * INPC[ULT] / INPC[k]
lin = []
for a in range(1995, ULT[0] + 1):
  ms = [k for k in SM if k[0] == a]
  lin.append([a, pres_ano(a), len(ms), r1(sum(SM[k] for k in ms) / len(ms), 2), r1(sum(real(k) for k in ms) / len(ms), 0), mes_txt(ULT), U['sm'] + '; INPC ' + U['inpc']])
grava('PC-salario-minimo.csv', ['ano', 'presidente', 'meses', 'salario_minimo_nominal_medio_rs', 'salario_minimo_real_medio_rs', 'reais_de', 'fonte_url'], lin)

# 4. cesta basica de Sao Paulo, DIEESE: horas de trabalho com salario minimo e gasto mensal
def dieese(arq):
  t = open(os.path.join(F, arq), encoding='utf-8').read()
  c = [html.unescape(re.sub(r'<[^>]+>', '', x)).strip() for x in re.findall(r'<td[^>]*>(.*?)</td>', t, re.S)]
  return {(int(c[i][3:]), int(c[i][:2])): c[i + 1] for i in range(0, len(c), 2) if re.match(r'^\d\d-\d{4}$', c[i]) and c[i + 1]}
hm = lambda s: int(s.split('h')[0]) + int(s.split('h')[1].rstrip('m')) / 60
CT = {k: hm(v) for k, v in dieese('dieese_sp_tempo_trabalho.html').items()}
CG = {k: float(v.replace('.', '').replace(',', '.')) for k, v in dieese('dieese_sp_gasto_mensal.html').items()}
lin = []
for a in range(1995, ULT[0] + 1):
  ms = sorted(k for k in CT if k[0] == a)
  lin.append([a, pres_ano(a), len(ms), r1(sum(CT[k] for k in ms) / len(ms), 1), r1(sum(CG[k] for k in ms) / len(ms), 2), r1(100 * sum(CT[k] for k in ms) / len(ms) / 220, 1), U['cesta']])
grava('PC-cesta-sp.csv', ['ano', 'presidente', 'meses', 'horas_de_trabalho_media', 'gasto_mensal_medio_rs', 'pct_da_jornada_de_220h', 'fonte_url'], lin)

# 5. inflacao por faixa de renda, Ipea (variacao mensal por faixa)
ws = openpyxl.load_workbook(os.path.join(F, 'ipea_ifr_ago2026.xlsx'), read_only=True, data_only=True)['Mensal']
MESES = {m: i + 1 for i, m in enumerate(['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'])}
FAIXAS = None; IFR = {}; esperado = (2006, 7)
import unicodedata
sem_acento = lambda s: unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower().strip()
for row in ws.iter_rows(values_only=True):
  row = [c for c in row if c is not None]
  if row and row[0] == 'Renda muito baixa': FAIXAS = row; continue
  if not FAIXAS or len(row) < 7 or not isinstance(row[1], (int, float)): continue
  # os rotulos mudam de forma ao longo da planilha (jul/2006, Dez/2017, Out/24, e um "Óut/25" com acento por engano):
  # le em sequencia a partir de jul/2006 e confere cada rotulo contra o mes esperado
  k = row[0]
  if hasattr(k, 'year'): lido = (k.year, k.month)
  else:
    k = sem_acento(k); a = int(k[4:]); lido = (a + 2000 if a < 100 else a, MESES[k[:3]])
  assert lido == esperado, (row[0], esperado)
  IFR[esperado] = [float(x) for x in row[1:7]]
  esperado = (esperado[0] + 1, 1) if esperado[1] == 12 else (esperado[0], esperado[1] + 1)
assert FAIXAS == ['Renda muito baixa', 'Renda baixa', 'Renda média-baixa', 'Renda média', 'Renda média-alta', 'Renda alta']
# aba de acumulado em 12 meses (de jun/2007 em diante, em sequencia). Na renda alta, de 2007 a 2012, ela diverge da aba mensal
# em ate 2,7 pontos; as outras faixas batem. Os dois calculos vao para o CSV de mandatos, e o texto mostra os dois.
A12 = {}; esperado = (2007, 6)
for row in openpyxl.load_workbook(os.path.join(F, 'ipea_ifr_ago2026.xlsx'), read_only=True, data_only=True)['Acumulado 12 meses'].iter_rows(values_only=True):
  row = [c for c in row if c is not None]
  if len(row) < 7 or not isinstance(row[1], (int, float)): continue
  A12[esperado] = [float(x) for x in row[1:7]]; esperado = (esperado[0] + 1, 1) if esperado[1] == 12 else (esperado[0], esperado[1] + 1)
assert max(A12) == max(IFR), (max(A12), max(IFR))
ULT_I = max(IFR)
grava('PC-inflacao-faixa.csv', ['mes', 'presidente'] + [f.lower().replace(' ', '_').replace('é', 'e') for f in FAIXAS] + ['fonte_url'],
      [[f'{k[0]}-{k[1]:02d}', pres_mes(*k)] + [round(x, 4) for x in IFR[k]] + [U['ifr']] for k in sorted(IFR)])
nota = re.sub(r'\s+', ' ', ' '.join(__import__('subprocess').run(['pdftotext', os.path.join(F, 'ipea_ifr_ago2026_nota.pdf'), '-'], capture_output=True, text=True).stdout.split()))
lim_mb = re.search(r'1 - Renda muito baixa Menor que R\$ [\d.,]+ Menor que R\$ ([\d.,]+)', nota).group(1)
lim_alta = re.search(r'6 - Renda alta Maior que R\$ [\d.,]+ Maior que R\$ ([\d.,]+)', nota).group(1)

# 6. orcamento das familias por classe de rendimento, POF 2017-2018
POFT = ['2.1.1 Alimentação', '2.1.2 Habitação', '2.1.4 Transporte', '2.1.6 Assistência à saude', '2.1.7 Educação', '2.1.8 Recreação e cultura', '2.1 Despesas de consumo']
lin = [[r['D4N'], r['D5N'], float(r['V']), '2017-2018', U['pof']] for r in sidra('sidra_6715_v1204.json') if r['D5N'] in POFT]
grava('PC-pof-orcamento.csv', ['classe_de_rendimento_familiar', 'tipo_de_despesa', 'pct_da_despesa_total', 'periodo', 'fonte_url'], lin)

# 7. por mandato
def acum_idx(I, i, f): return 100 * (I[f] / I[ant(*i)] - 1)
def acum_ifr(j, i, f):
  p = 1.0
  for k in sorted(IFR):
    if i <= k <= f: p *= 1 + IFR[k][j] / 100
  return 100 * (p - 1)
anual = lambda tot, meses: 100 * ((1 + tot / 100) ** (12 / meses) - 1)
nmes = lambda i, f: (f[0] - i[0]) * 12 + f[1] - i[1] + 1
lin = []
for nome, i, f in MAND:
  f = min(f, ULT); per = f'{mes_txt(i)} a {mes_txt(f)}'; n_ = nmes(i, f)
  ip = acum_idx(IPCA, i, f); ic = acum_idx(INPC, i, f)
  lin.append([nome, 'IPCA acumulado', r1(ip, 1), '%', per, U['ipca']])
  lin.append([nome, 'IPCA medio ao ano', r1(anual(ip, n_), 1), '% ao ano', per, U['ipca']])
  lin.append([nome, 'INPC acumulado', r1(ic, 1), '%', per, U['inpc']])
  sr = 100 * (real(f) / real(ant(*i)) - 1)
  lin.append([nome, 'salario minimo real, variacao', r1(sr, 1), '%', f'{mes_txt(ant(*i))} a {mes_txt(f)}', U['sm']])
  ms = [k for k in CT if i <= k <= f]
  lin.append([nome, 'cesta basica de Sao Paulo, horas de trabalho com salario minimo, media do periodo', r1(sum(CT[k] for k in ms) / len(ms), 0), 'horas', per, U['cesta']])
  ii = max(i, (2007, 1)); fi = min(f, ULT_I)  # o indicador comeca em jul/2006; no governo Lula usa so o segundo mandato inteiro
  if fi > ii:
    per_i = f'{mes_txt(ii)} a {mes_txt(fi)}'
    for j in (0, 5):
      t = acum_ifr(j, ii, fi)
      lin.append([nome, f'inflacao Ipea, {FAIXAS[j].lower()}, media ao ano', r1(anual(t, nmes(ii, fi)), 2), '% ao ano', per_i, U['ifr']])
      if j == 5 and ii < (2013, 1):  # mesma conta com os anos inteiros lidos da aba de 12 meses
        p = 1.0
        for y in range(ii[0], fi[0] + 1):
          if (y, 1) >= ii and (y, 12) <= fi: p *= 1 + A12[(y, 12)][j] / 100
          else: p *= 1 + acum_ifr(j, max(ii, (y, 1)), min(fi, (y, 12))) / 100
        lin.append([nome, f'inflacao Ipea, {FAIXAS[j].lower()}, media ao ano (aba de 12 meses)', r1(anual(100 * (p - 1), nmes(ii, fi)), 2), '% ao ano', per_i, U['ifr']])
  ti = max(ant(*i), (2012, 3)); tf = min(f, ULT_TR)
  if tf > ti:
    lin.append([nome, 'renda media real do trabalho, variacao', r1(100 * (TR[tf][1] / TR[ti][1] - 1), 1), '%', f'{TR[ti][0]} a {TR[tf][0]}', U['trab']])
    lin.append([nome, 'massa real de rendimento do trabalho, variacao', r1(100 * (MS[tf] / MS[ti] - 1), 1), '%', f'{TR[ti][0]} a {TR[tf][0]}', U['trab']])
  ai = {'Dilma': 2012, 'Temer': 2015, 'Bolsonaro': 2018, 'Lula 3': 2022}.get(nome); af = {'Dilma': 2015, 'Temer': 2018, 'Bolsonaro': 2022, 'Lula 3': ULT_D}.get(nome)
  if ai:
    for c, rot in (('40% mais pobres (media das classes ate o P40)', '40% mais pobres'), ('Até o P10', '10% mais pobres'), ('Total', 'media'), ('Maior que o P90', '10% mais ricos')):
      lin.append([nome, f'renda domiciliar per capita real, {rot}, variacao', r1(100 * (dv(af, c) / dv(ai, c) - 1), 1), '%', f'{ai} a {af}', U['dom']])
grava('PC-por-mandato.csv', ['presidente', 'indicador', 'valor', 'unidade', 'periodo', 'fonte_url'], lin)
json.dump({'ult_preco': mes_txt(ULT), 'ult_trab': TR[ULT_TR][0], 'ult_dom': ULT_D, 'ult_ifr': mes_txt(ULT_I), 'lim_renda_muito_baixa': lim_mb, 'lim_renda_alta': lim_alta},
          open(os.path.join(RAIZ, 'PC-referencias.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

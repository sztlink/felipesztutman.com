#!/usr/bin/env python3
# Frente PC, poder de compra. Baixa as fontes primarias, uma requisicao por vez com pausa, e registra cada uma em downloads.tsv.
# Rodar de fora da pasta dos dados: cd /tmp && python3 -I <pacote>/brutos/PC/baixa_PC.py
import datetime, hashlib, os, time, urllib.parse, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
SIDRA = 'https://apisidra.ibge.gov.br/values'
IPEA = 'http://www.ipeadata.gov.br/api/odata4'
DIEESE = 'https://www.dieese.org.br/cesta/produto'
ITENS = [  # arquivo, descricao, url, corpo do POST (ou None)
  ('sidra_6390_v5933.json', 'IBGE PNAD Continua, tabela 6390, rendimento medio mensal real habitual de todos os trabalhos, trimestre movel',
   f'{SIDRA}/t/6390/n1/all/v/5933/p/all', None),
  ('sidra_6392_v6293.json', 'IBGE PNAD Continua, tabela 6392, massa de rendimento mensal real habitual de todos os trabalhos, trimestre movel',
   f'{SIDRA}/t/6392/n1/all/v/6293/p/all', None),
  ('sidra_7533_v10816.json', 'IBGE PNAD Continua anual, tabela 7533, rendimento medio mensal real domiciliar per capita a precos do ultimo ano, por classe de percentil',
   f'{SIDRA}/t/7533/n1/all/v/10816/p/all/c1019/all', None),
  ('sidra_1736_v2289.json', 'IBGE, tabela 1736, INPC, numero-indice mensal (dez/1993 = 100)', f'{SIDRA}/t/1736/n1/all/v/2289/p/all', None),
  ('ipea_MTE12_SALMIN12_metadados.json', 'Ipeadata, metadados da serie MTE12_SALMIN12 (salario minimo vigente)', f"{IPEA}/Metadados('MTE12_SALMIN12')", None),
  ('ipea_MTE12_SALMIN12.json', 'Ipeadata, MTE12_SALMIN12, salario minimo vigente por mes, R$ correntes', f"{IPEA}/ValoresSerie(SERCODIGO='MTE12_SALMIN12')", None),
  ('planalto_D12797_2025.htm', 'Planalto, Decreto 12.797/2025, salario minimo de 2026 (conferencia do ultimo valor da serie do Ipea)',
   'https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/D12797.htm', None),
  ('dieese_sp_tempo_trabalho.html', 'DIEESE, Pesquisa Nacional da Cesta Basica, Sao Paulo, total da cesta, tempo de trabalho com salario minimo, 01/1995 a 09/2026',
   DIEESE, 'farinha=true&cidades=8&produtos=1&tipoDado=3&dataInicial=011995&dataFinal=092026'),
  ('dieese_sp_gasto_mensal.html', 'DIEESE, Pesquisa Nacional da Cesta Basica, Sao Paulo, total da cesta, gasto mensal em R$ correntes, 01/1995 a 09/2026',
   DIEESE, 'farinha=true&cidades=8&produtos=1&tipoDado=5&dataInicial=011995&dataFinal=092026'),
  ('ipea_ifr_ago2026.xlsx', 'Ipea, Indicador Ipea de Inflacao por Faixa de Renda, planilha da nota de agosto de 2026 (variacao mensal por faixa desde jul/2006)',
   'https://www.ipea.gov.br/cartadeconjuntura/wp-content/uploads/2026/09/260915_inflacao-por-faixa-de-renda_tabela.xlsx', None),
  ('ipea_ifr_ago2026_nota.pdf', 'Ipea, Carta de Conjuntura 72, nota 13, inflacao por faixa de renda de agosto de 2026 (tabela 4 define as faixas)',
   'https://www.ipea.gov.br/cartadeconjuntura/wp-content/uploads/2026/09/260915_cc_72_nota_13_ifr_ago_26.pdf', None),
  ('sidra_6715_v1204.json', 'IBGE POF 2017-2018, tabela 6715, distribuicao da despesa monetaria e nao monetaria media mensal familiar por classe de rendimento e tipo de despesa',
   f'{SIDRA}/t/6715/n1/all/v/1204/p/all/c339/all/c12190/all', None),
]
linhas = []
for arq, desc, url, corpo in ITENS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    r = urllib.request.Request(url, data=corpo.encode() if corpo else None, headers={'User-Agent': UA, 'Referer': 'https://www.dieese.org.br/cesta/'} if corpo else {'User-Agent': UA})
    with urllib.request.urlopen(r, timeout=120) as x: dados = x.read()
    open(dst, 'wb').write(dados); time.sleep(2)
  h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
  data = datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d')
  linhas.append('\t'.join([data, desc, 'fontes/' + arq, url + (' (POST ' + corpo + ')' if corpo else ''), h]))
  print('ok', arq, h)
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n')

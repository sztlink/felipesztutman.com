# Frente PC, poder de compra e renda por faixa

Feita em 20/10/2026 para a v11.3. Origem: leitura de uma leitora leiga, que apontou que o dossiê não media o poder de compra
nem a experiência de cada faixa de renda.

## O que entra
- `PC-renda-trabalho.csv`. PNAD Contínua, rendimento médio e massa de rendimento real habitual de todos os trabalhos, por
  trimestre móvel, de jan-mar 2012 em diante (SIDRA 6390, variável 5933, e 6392, variável 6293). Valores a preços do último
  trimestre móvel publicado. Conferido em 20/10 que, no último trimestre, o nominal e o real coincidem.
- `PC-renda-domiciliar-faixas.csv`. PNAD Contínua anual, rendimento domiciliar per capita real a preços médios do último ano, por
  classe de percentil das pessoas (SIDRA 7533, variável 10816). Os 40% mais pobres são a média simples das quatro classes de 10%
  até o P40, que têm o mesmo número de pessoas.
- `PC-salario-minimo.csv`. Salário mínimo vigente por mês (Ipeadata, MTE12_SALMIN12), deflacionado pelo INPC (SIDRA 1736) para
  reais do último mês do INPC. O valor de 2026 (R$ 1.621,00) é conferido no texto do Decreto 12.797/2025, e o script para se não bater.
- `PC-cesta-sp.csv`. DIEESE, Pesquisa Nacional da Cesta Básica, São Paulo, total da cesta. Tempo de trabalho com salário mínimo
  e gasto mensal, médias do ano. A porcentagem da jornada usa as 220 horas por mês da conta do DIEESE.
- `PC-inflacao-faixa.csv`. Ipea, Indicador de Inflação por Faixa de Renda, variação mensal das seis faixas desde jul/2006.
- `PC-pof-orcamento.csv`. IBGE, POF 2017-2018, parcela de cada tipo de despesa na despesa total, por classe de rendimento (SIDRA 6715).
- `PC-por-mandato.csv`. Resumo por mandato, com período de cada número.
- `PC-referencias.json`. Últimos meses de cada série e limites das faixas do Ipea, lidos da nota técnica (tabela 4).

## Mandatos
Por mês, com Dilma até abril de 2016 e Temer a partir de maio de 2016. Variações de preço e de salário mínimo vão do mês anterior
ao início até o último mês do mandato. A renda do trabalho vai do trimestre móvel que termina no mês anterior ao início até o que
termina no último mês. A renda domiciliar é anual: Dilma 2012 a 2015, Temer 2015 a 2018 (inclui 2016), Bolsonaro 2018 a 2022,
Lula 3 2022 ao último ano. No Ipea, o governo Lula usa só 2007 a 2010, porque o indicador começa em jul/2006.

## Problemas encontrados na planilha do Ipea
- Os rótulos de mês mudam de forma (jul/2006, Dez/2017, Out/24) e há um "Óut/25" com acento por engano. O script lê em sequência
  a partir de jul/2006 e confere cada rótulo contra o mês esperado.
- Na faixa de renda alta, de 2007 a 2012, a aba de acumulado em 12 meses diverge do produto dos meses da aba mensal em até 2,7
  pontos. As outras cinco faixas batem. O gráfico usa a aba mensal, e o CSV de mandatos traz também a conta pela aba de 12 meses
  para Lula 2 e Dilma.

## POF e números de terceiros
Uma leitura externa citou habitação de 39,2% e 22,6% nas classes extremas. A tabela 6715 traz 39,0% e 22,7%, e o dossiê usa a tabela.
Alimentação (22,0% e 7,6%) bate.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/PC/baixa_PC.py      # baixa as fontes, uma requisição por vez, com pausa
cd /tmp && python3 -P <pacote>/brutos/PC/build_PC.py      # precisa de openpyxl e de pdftotext; lê também brutos/N/ibge/sidra_1737_v2266.json
```
`downloads.tsv` lista data, arquivo, URL e hash de cada fonte.

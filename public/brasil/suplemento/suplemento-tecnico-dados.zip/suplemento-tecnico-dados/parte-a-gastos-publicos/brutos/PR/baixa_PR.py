#!/usr/bin/env python3
# Frente PR. Baixa leis e tabelas do IBGE, uma requisicao por vez com pausa, e registra todas as fontes em downloads.tsv.
# Os dois planos do TSE vem de baixa_tse.js (o site exige navegador). Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/PR/baixa_PR.py
import datetime, hashlib, os, time, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
P = 'https://www.planalto.gov.br/ccivil_03/'
ITENS = [
  ('tse_proposta_pl_2026_2t.pdf', 'TSE, plano de governo de Flavio Bolsonaro (PL), 2o turno de 2026 (baixa_tse.js)', 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pl', False),
  ('tse_proposta_pt_2026_2t.pdf', 'TSE, plano de governo de Lula (PT), 2o turno de 2026 (baixa_tse.js)', 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt', False),
  ('planalto_l14663.htm', 'Lei 14.663/2023, politica de valorizacao do salario minimo', P + '_ato2023-2026/2023/lei/l14663.htm', True),
  ('planalto_L15077.htm', 'Lei 15.077/2024, art. 4o, ganho real do salario minimo de 2025 a 2030 limitado pelo arcabouco', P + '_ato2023-2026/2024/lei/l15077.htm', True),
  ('planalto_l8213cons.htm', 'Lei 8.213/1991, art. 41-A, reajuste dos beneficios do INSS pelo INPC', P + 'leis/l8213cons.htm', True),
  ('planalto_l15270.htm', 'Lei 15.270/2025, reducao do IRPF ate R$ 7.350 por mes e tributacao minima acima de R$ 600 mil por ano', P + '_ato2023-2026/2025/lei/l15270.htm', True),
  ('planalto_constituicao.htm', 'Constituicao Federal, art. 201 (piso dos beneficios) e art. 203, V (BPC de um salario minimo)', P + 'constituicao/constituicao.htm', True),
  ('sidra_5932_v6563.json', 'IBGE, Contas Nacionais Trimestrais, tabela 5932, taxa acumulada no ano', 'https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/6563/p/all/c11255/all', True),
  ('sidra_6372_v8186.json', 'IBGE, PNAD Continua, tabela 6372, media de horas habituais no trabalho principal', 'https://apisidra.ibge.gov.br/values/t/6372/n1/all/v/8186/p/all/c58/95253', True),
]
linhas = []
for arq, desc, url, baixa in ITENS:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    if not baixa: raise SystemExit(f'falta {arq}: rode baixa_tse.js')
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=120) as x: open(dst, 'wb').write(x.read())
    time.sleep(3)
  h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, 'fontes/' + arq, url, h])); print('ok', arq, h)
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n')

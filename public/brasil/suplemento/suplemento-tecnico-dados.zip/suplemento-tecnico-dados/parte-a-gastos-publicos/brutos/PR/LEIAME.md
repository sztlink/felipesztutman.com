# Frente PR, propostas para 2027 a 2030

Feita em 20/10/2026 para a v12 (seção 16). Junta o que as duas candidaturas do segundo turno de 2026 registraram no TSE como
plano de governo e a base da lei atual (PLDO 2027, Focus, IBGE, leis do salário mínimo e do INSS).

## Fontes
- Planos de governo no TSE, página "Propostas de governo dos candidatos ao cargo de Presidente da República, 2º turno". O site
  recusa requisição direta (403) e foi lido por um Chromium comum com `baixa_tse.js`. Lula (PT), 84 páginas. Flávio Bolsonaro
  (PL), "Diretrizes do Plano de Governo 2027-2030", 76 páginas.
- Leis no Planalto: 14.663/2023 (regra do salário mínimo), 15.077/2024 (art. 4º, ganho real limitado pelo arcabouço de 2025 a
  2030), 8.213/1991 (art. 41-A, reajuste dos benefícios pelo INPC), 15.270/2025 (IRPF), Constituição (arts. 201 e 203).
- IBGE: SIDRA 5932 (PIB de 2025) e 6372 (média de horas trabalhadas).
- Já no pacote: PLDO 2027, Anexo IV.2 (brutos/S), e Focus de 09/10/2026 (brutos/S).

## O que o script faz
- `PR-propostas.csv`. 52 trechos literais dos planos (24 do PT e 28 do PL desde a v12.3), com parte, tema e página. O script para se algum trecho não estiver no texto
  da página citada. A escolha dos trechos é editorial e cobre os temas econômicos dos dois planos com o mesmo recorte.
- `PR-ausencias.csv`. Matriz de 21 assuntos, cada um com as palavras dos dois planos para o mesmo tema (v12.3). Antes, 17 termos contados nos dois planos, em todas as páginas. A lista foi fixada em 20/10/2026 antes da
  contagem dos termos novos. Na v12 oito termos tinham sido contados só num plano, o que uma leitura de design feita por agente de IA apontou. A matriz
  cruzada mostrou que "meta fiscal" também não aparece no plano do PL, e não só no do PT.
- `PR-base.csv`. Grade do PLDO 2027 (PIB, IPCA, INPC, salário mínimo de 2025 a 2030), metas e projeção de primário, Focus de
  2027 a 2030, PIB de 2025 do IBGE e a média de horas. Traz também a regra do salário mínimo aplicada à macro do Focus, com o
  IPCA no lugar do INPC (o Focus não projeta o INPC), o ganho real entre 0,6% e 2,5% e o arredondamento para cima da lei.

## Limites
- Os planos são lidos como estavam no TSE em 20/10/2026. Declarações de campanha fora deles não entram.
- Os diagnósticos do passado que os planos trazem não são reproduzidos. O passado está nas seções 1 a 15.
- A tabela pública do IBGE não traz a distribuição dos ocupados por faixa de horas, só a média. O alcance da jornada de 40 horas
  fica sem número.

## Como rodar
```
cd /tmp && xvfb-run -a node <pacote>/brutos/PR/baixa_tse.js <pasta-de-perfil>   # precisa de playwright-core e de um Chromium
cd /tmp && python3 -I <pacote>/brutos/PR/baixa_PR.py
cd /tmp && PYTHONPATH=~/.local/lib/pdftools python3 -P <pacote>/brutos/PR/build_PR.py
```

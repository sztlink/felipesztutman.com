#!/usr/bin/env python3
# Frente PR, propostas 2027 a 2030. Le os planos de governo registrados no TSE (2o turno de 2026), o PLDO 2027, o Focus e o IBGE,
# e escreve PR-propostas.csv, PR-ausencias.csv, PR-cultura.csv, PR-agro-ambiente.csv e PR-base.csv na raiz. Cada citacao e conferida contra o texto da pagina citada.
# Rodar: cd /tmp && PYTHONPATH=~/.local/lib/pdftools python3 -P <pacote>/brutos/PR/build_PR.py
import csv, json, os, re, sys
sys.path.insert(0, os.environ.get('PDFTOOLS', os.path.expanduser('~/.local/lib/pdftools')))
import fitz
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes')
TSE = {'PT': ('tse_proposta_pt_2026_2t.pdf', 'Lula (PT, coligação Brasil Pronto pra Mais)', 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt'),
       'PL': ('tse_proposta_pl_2026_2t.pdf', 'Flávio Bolsonaro (PL)', 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pl')}
norm = lambda s: re.sub(r'-\s+(?=[a-záéíóúâêôãõç])', '-', re.sub(r'\s+', ' ', s)).strip()  # junta 'salário-' + 'mínimo' quebrado na linha
PAG = {k: [norm(p.get_text()) for p in fitz.open(os.path.join(F, a))] for k, (a, _, _) in TSE.items()}
def grava(nome, cab, linhas):
  with open(os.path.join(RAIZ, nome), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f, lineterminator='\n'); w.writerow(cab); w.writerows(linhas)
  print(nome, len(linhas))

# parte, tema, partido, pagina, trecho literal (conferido)
CIT = [  # a primeira citacao de cada tema e partido e a que aparece na celula do relatorio
  ('contas', 'regra fiscal', 'PT', 49, 'manteremos o novo arcabouço fiscal, que controlou o crescimento das despesas sem prejudicar as políticas sociais'),
  ('contas', 'regra fiscal', 'PL', 71, 'Apresentaremos uma reformulação nas atuais regras fiscais, com regras claras focadas na estabilização e na redução da dívida pública'),
  ('contas', 'resultado primário', 'PT', 49, 'O resultado fiscal virá, como fizemos até aqui, da retomada do crescimento econômico, do controle do aumento do gasto primário'),
  ('contas', 'resultado primário', 'PL', 71, 'entregando superávits primários e limitando o crédito subsidiado com recursos do Tesouro'),
  ('contas', 'despesa', 'PT', 49, 'investindo na melhoria da eficiência e da qualidade do gasto público'),
  ('contas', 'despesa', 'PL', 71, 'haverá uma regra clara de controle de gastos discricionários dos três Poderes da União'),
  ('contas', 'despesa', 'PL', 69, 'o corte de no mínimo 10 ministérios, a redução de cargos comissionados e de despesas administrativas'),
  ('contas', 'impostos', 'PT', 59, 'Ao regulamentar a reforma tributária, vamos, por meio do Imposto Seletivo, desestimular produtos nocivos à saúde'),
  ('contas', 'impostos', 'PT', 49, 'da promoção de justiça tributária e do combate aos privilégios e às distorções'),
  ('contas', 'impostos', 'PL', 71, 'Vamos promover a revisão e o redimensionamento da reforma tributária em curso e da majoração de impostos efetuada pelo atual governo'),
  ('contas', 'impostos', 'PL', 72, 'reduzir o IVA, hoje projetado num dos patamares mais altos do mundo'),
  ('contas', 'emendas parlamentares', 'PT', 15, 'Propomos ainda enfrentar uma grave distorção na elaboração e gestão do orçamento federal'),
  ('contas', 'emendas parlamentares', 'PL', 69, 'daremos mais transparência, controle e rastreabilidade às emendas parlamentares'),
  ('economia', 'crescimento', 'PT', 48, 'Nosso desafio é sustentar taxas robustas de crescimento'),
  ('economia', 'crescimento', 'PL', 49, 'Nossa meta é dobrar esse ritmo e alcançar um crescimento sustentado de 4% ao ano ao longo da próxima década'),
  ('economia', 'juros e inflação', 'PT', 49, 'vamos criar as condições para uma redução sustentada das taxas de juros, com inflação controlada e assegurando uma política fiscal responsável'),
  ('economia', 'juros e inflação', 'PL', 33, 'criar as condições para que os juros básicos fiquem em linha com a média internacional e para que a inflação volte ao centro da meta'),
  ('economia', 'investimento', 'PT', 48, 'vamos elevar a taxa de investimento da economia'),
  ('economia', 'investimento', 'PT', 53, 'Manteremos o ritmo nas concessões rodoviárias e intensificaremos as de ferrovias'),
  ('economia', 'investimento', 'PL', 51, 'Vamos investir R$ 900 bilhões em quatro anos em rodovias, hidrovias, portos, aeroportos e ferrovias'),
  ('economia', 'investimento', 'PL', 50, 'fundo lastreado na securitização de ativos e imóveis da União, uso intensivo de PPPs e concessões e financiamentos do BNDES'),
  ('economia', 'investimento', 'PL', 31, 'Vamos criar os Corredores Logísticos Inteligentes, com foco direto na redução do custo de transporte'),
  ('economia', 'estatais', 'PT', 67, 'A Petrobras deverá retornar ao segmento de distribuição de combustíveis'),
  ('economia', 'estatais', 'PL', 70, 'retomar o Programa Nacional de Desestatização com critério'),
  ('familia', 'salário mínimo', 'PT', 74, 'dará continuidade à política de valorização do salário mínimo'),
  ('familia', 'trabalho', 'PT', 75, 'assegurar o fim da escala 6x1 e a redução da jornada de trabalho para 40 horas, sem redução salarial'),
  ('familia', 'trabalho', 'PT', 75, 'Vamos aprimorar a legislação trabalhista, alterando regras que induzem a precarização das condições de trabalho'),
  ('familia', 'trabalho', 'PT', 74, 'Vamos continuar combatendo a pejotização espúria'),
  ('familia', 'trabalho', 'PL', 43, 'Vamos reduzir gradualmente o custo do trabalho, sem retirar direitos'),
  ('familia', 'trabalho', 'PL', 44, 'trabalho para os 18 a 24 anos em busca do primeiro emprego, com menor custo na folha'),
  ('familia', 'trabalho', 'PL', 44, 'defendemos o negociado sobre o legislado'),
  ('familia', 'previdência', 'PT', 77, 'buscar reestruturar a base de financiamento da Previdência, buscando a diversidade das fontes de custeio'),
  ('familia', 'previdência', 'PL', 72, 'Reeditaremos um pacote antifraude na Previdência, nos moldes do que fizemos em 2019'),
  ('familia', 'programas sociais', 'PT', 18, 'devemos manter, aperfeiçoar e ampliar as políticas de proteção social para quem mais necessita'),
  ('familia', 'programas sociais', 'PL', 42, 'vamos manter os programas sociais existentes, com aperfeiçoamento da gestão, correção de distorções e combate às fraudes'),
  ('familia', 'programas sociais', 'PL', 43, 'E garantiremos o retorno imediato e sem fila ao benefício após o seguro-desemprego'),
  ('familia', 'programas sociais', 'PL', 33, 'Vamos proibir o uso dos recursos dos programas sociais para apostas'),
  ('familia', 'energia e combustível', 'PT', 66, 'Continuaremos a atuar para mitigar a volatilidade dos preços internacionais, garantindo que os brasileiros não fiquem expostos a choques externos'),
  ('familia', 'energia e combustível', 'PL', 31, 'Vamos reduzir impostos sobre energia elétrica e combustíveis'),
  ('familia', 'energia e combustível', 'PL', 31, 'promover a redução gradual da CDE e das fontes incentivadas, mantida a tarifa social'),
  ('familia', 'saúde', 'PT', 36, 'O programa será mantido, 100% gratuito'),
  ('familia', 'saúde', 'PT', 37, 'Daremos continuidade à parceria com hospitais privados para assegurar, em troca de créditos financeiros ou de dívidas, a oferta de exames e cirurgias para o SUS'),
  ('familia', 'saúde', 'PL', 37, 'Vamos garantir as condições para que seja possível a correção efetiva da tabela SUS'),
  ('familia', 'saúde', 'PL', 37, 'vamos contratar serviços e exames na rede privada nos horários ociosos'),
  ('familia', 'educação', 'PT', 31, 'meta de 80% das nossas crianças alfabetizadas na idade certa'),
  ('familia', 'educação', 'PT', 32, 'Vamos dar continuidade e fortalecer o Pé-de-Meia'),
  ('familia', 'educação', 'PL', 35, 'o financiamento seguirá o orçamento por resultados, com repasses vinculados a metas de aprendizagem'),
  ('familia', 'educação', 'PL', 36, 'onde faltar vaga na rede pública, a família receberá um voucher educacional'),
  ('familia', 'moradia', 'PT', 45, 'O MCMV será mantido e ampliado no próximo mandato, para todas as faixas de renda'),
  ('familia', 'moradia', 'PL', 47, 'Vamos retomar o Casa Verde e Amarela, com meta de 2,5 milhões de residências'),
  ('familia', 'pequena empresa', 'PT', 57, 'vamos simplificar ainda mais o ambiente de negócios, ampliar o acesso das pequenas empresas às compras governamentais, assegurar tratamento tributário justo na implementação da reforma tributária'),
  ('familia', 'pequena empresa', 'PL', 45, 'vamos criar o Minha Primeira Empresa'),
  ('cultura', 'investimento e acesso', 'PT', 41, 'Vamos dar continuidade aos investimentos para consolidar e manter a rede de equipamentos culturais nos territórios'),
  ('cultura', 'investimento e acesso', 'PL', 41, 'Levaremos a arte para perto do público em todo o país, sem subordiná-la a agendas políticas'),
  ('cultura', 'fomento e leis de incentivo', 'PT', 41, 'Daremos especial atenção à consolidação dos Pontos de Cultura'),
  ('cultura', 'fomento e leis de incentivo', 'PL', 41, 'aperfeiçoaremos as leis de incentivo, corrigindo distorções e favorecendo o desenvolvimento de outros polos regionais'),
  ('cultura', 'desconcentração', 'PT', 41, 'Vamos avançar ainda mais na desconcentração regional e para todas as formas de manifestação cultural'),
  ('cultura', 'desconcentração', 'PL', 41, 'alcançaremos os artistas de grande mérito artístico, porém de pouca projeção, hoje esquecidos pelo modelo atual'),
  ('cultura', 'patrimônio', 'PT', 41, 'Vamos seguir preservando e difundindo os saberes, as memórias e os patrimônios culturais do Brasil'),
  ('cultura', 'patrimônio', 'PL', 41, 'com a preservação do nosso patrimônio histórico'),
  ('cultura', 'mercado e economia criativa', 'PT', 42, 'Seguiremos apoiando este setor estratégico, um braço da economia criativa, que gera emprego'),
  ('cultura', 'mercado e economia criativa', 'PL', 41, 'pela distinção entre cultura e entretenimento comercial'),
  ('agro', 'desmatamento', 'PT', 70, 'continuaremos trabalhando para alcançar o desmatamento líquido zero até 2030, meta que reafirmamos'),
  ('agro', 'desmatamento', 'PL', 58, 'Teremos a meta de zerar o desmatamento ilegal até 2029'),
  ('agro', 'fiscalização ambiental', 'PT', 72, 'Seguiremos fortalecendo e aprimorando as ações de fiscalização'),
  ('agro', 'fiscalização ambiental', 'PT', 72, 'Vamos expandir monitoramento satelital e uso de inteligência artificial no combate a crimes ambientais'),
  ('agro', 'fiscalização ambiental', 'PL', 58, 'Vamos fortalecer a fiscalização ambiental, com prioridade para as áreas de maior pressão de desmatamento e queimadas'),
  ('agro', 'fiscalização ambiental', 'PL', 59, 'Vamos eliminar superposições entre Ibama, Funai e ICMBio'),
  ('agro', 'fiscalização ambiental', 'PL', 59, 'exigir transparência de financiadores e de projetos das ONGs que recebem recursos internacionais'),
  ('agro', 'crédito rural e Plano Safra', 'PT', 61, 'Continuaremos fortalecendo o crédito rural, ampliando os recursos do Plano Safra e assegurando juros compatíveis com a rentabilidade da atividade agropecuária'),
  ('agro', 'crédito rural e Plano Safra', 'PT', 59, 'Vamos continuar expandindo o Plano Safra da Agricultura Familiar'),
  ('agro', 'crédito rural e Plano Safra', 'PL', 54, 'trazer ferramentas de securitização e reorganização das dívidas do setor'),
  ('agro', 'crédito rural e Plano Safra', 'PL', 55, 'articular o Plano Safra com incentivos à produção de biomassa'),
  ('agro', 'seguro rural', 'PT', 62, 'Daremos especial atenção ao fortalecimento da política de seguro rural'),
  ('agro', 'seguro rural', 'PL', 54, 'Vamos ampliar o Seguro Rural'),
  ('agro', 'terra', 'PT', 60, 'Continuaremos a avançar na política de reforma agrária, assentando as famílias acampadas'),
  ('agro', 'terra', 'PL', 54, 'promover ampla regularização e titulação do pequeno proprietário rural'),
  ('agro', 'pagamento por serviços ambientais', 'PT', 72, 'Vamos aprimorar a implementação de programas de Pagamento por Serviços Ambientais (PSA)'),
  ('agro', 'pagamento por serviços ambientais', 'PL', 55, 'ampliar o pagamento por serviços ambientais para conservação e restauração'),
  ('agro', 'financiamento climático e carbono', 'PT', 71, 'O Fundo Clima e o Eco Invest continuarão a ser instrumentos fundamentais'),
  ('agro', 'financiamento climático e carbono', 'PL', 57, 'vamos consolidar o mercado regulado de carbono com segurança jurídica'),
  ('agro', 'licenciamento ambiental', 'PL', 50, 'Se não decidir nem se manifestar dentro desse prazo, a licença deve ser concedida'),
  ('agro', 'licenciamento ambiental', 'PL', 49, 'um licenciamento ambiental ágil, moderno e com segurança jurídica'),
  ('agro', 'fertilizantes', 'PT', 63, 'seguiremos acelerando a produção nacional de fertilizantes'),
  ('agro', 'fertilizantes', 'PL', 54, 'Vamos apoiar a produção nacional de fertilizantes'),
]
lin = []
for parte, tema, pt, pg, txt in CIT:
  assert norm(txt) in PAG[pt][pg - 1], (pt, pg, txt[:60])
  lin.append([parte, tema, pt, TSE[pt][1], pg, txt, TSE[pt][0], TSE[pt][2]])
grava('PR-propostas.csv', ['parte', 'tema', 'partido', 'candidatura', 'pagina', 'trecho', 'arquivo', 'fonte_url'], lin)

# matriz de termos: a mesma lista contada nos dois planos, em todas as paginas, sem distinguir maiusculas. Na v12.2 oito termos
# vinham da v12, escolhidos por estarem ausentes num plano, e varios eram o vocabulario de um lado so. A auditoria de 20/10/2026
# apontou isso, e cada linha passou a juntar as palavras dos dois planos para o mesmo assunto. Conta palavra, nao proposta.
TERMOS = [  # cada linha junta o vocabulario dos dois planos para o mesmo assunto (revisto em 20/10/2026 depois da auditoria)
          ('contas', 'resultado primário (superávit, déficit primário, gasto primário)', r'superávit|resultado primário|déficit primário|gasto primário'),
          ('contas', 'dívida pública (dívida pública, dívida bruta, dívida/PIB)', r'dívida pública|dívida bruta|dívida/PIB|relação dívida'),
          ('contas', 'meta fiscal', r'meta fiscal|meta de resultado primário|metas fiscais'),
          ('contas', 'regra fiscal (arcabouço, regras fiscais, teto de gastos)', r'arcabouço|regras? fisca(?:l|is)|teto de gastos'),
          ('contas', 'reforma tributária', r'reforma tributária'), ('contas', 'IVA, CBS ou IBS', r'\bIVA\b|\bCBS\b|\bIBS\b'),
          ('contas', 'Imposto de Renda', r'Imposto de Renda|Imposto sobre a Renda'), ('contas', 'emendas parlamentares', r'emendas'),
          ('economia', 'crescimento', r'crescimento'), ('economia', 'juros', r'\bjuros\b'), ('economia', 'inflação', r'inflação'),
          ('economia', 'investimento', r'\binvestimento'), ('economia', 'privatização, desestatização ou concessão', r'privatiza|desestatiza|concess(?:ão|ões) (?:rodovi|ferrovi|de rodovia|de ferrovia|e permiss)|\bconcessões\b'),
          ('economia', 'estatais ou Petrobras', r'estata(?:l|is)|Petrobras'),
          ('familia', 'salário mínimo (singular, plural ou com hífen)', r'salários? mínimos?|salário-mínimo'),
          ('familia', 'transferência de renda (Bolsa Família, BPC, programas sociais, Auxílio Brasil)', r'Bolsa Família|\bBPC\b|programas? soci(?:al|ais)|Auxílio Brasil|transferência de renda'),
          ('familia', 'previdência e aposentadoria (previdência, aposentado, INSS)', r'previdên|aposentad|\bINSS\b'),
          ('familia', 'jornada de trabalho (40 horas, 6x1, jornada flexível, jornada de trabalho)', r'40 horas|6x1|jornada flexível|jornada de trabalho'),
          ('familia', 'SUS', r'\bSUS\b'), ('familia', 'moradia (moradia, habitação, casa própria, MCMV, Casa Verde e Amarela)', r'moradia|habitaç|casa própria|\bMCMV\b|Minha Casa|Casa Verde'),
          ('familia', 'pequenas empresas (pequenas empresas, pequeno negócio, MEI)', r'pequenas empresas|pequenos negócios|pequeno negócio|\bMEI\b|microempreendedor'),
          ('cultura', 'cultura e economia criativa (cultura, economia criativa, audiovisual, games, leis de incentivo, Rouanet, patrimônio, artistas)', r'\bcultur|economia criativa|audiovisual|\bgames\b|leis? de incentivo|Rouanet|patrimônios? (?:histórico|cultura)|\bartistas?\b'),
          ('cultura', 'Ministério da Cultura (Ministério da Cultura, MinC)', r'Ministério da Cultura|\bMinC\b'),
          ('agro', 'agro e crédito rural (agronegócio, agro, agropecuária, Plano Safra, crédito rural, Pronaf, agricultura familiar, produtor rural, pequeno produtor, seguro rural)', r'agroneg|\bagro\b|agropecu|Plano Safra|crédito rural|\bPronaf\b|agricultura familiar|produtor(?:es)? rura(?:l|is)|pequenos? produtor|seguro rural'),
          ('agro', 'terra (reforma agrária, regularização fundiária, titulação, assentamentos)', r'reforma agrária|regularização fundiária|titulação|assentament'),
          ('agro', 'desmatamento e queimadas', r'desmatamento|queimadas'),
          ('agro', 'fiscalização e crime ambiental (fiscalização ambiental, crimes ambientais, Ibama, ICMBio)', r'fiscalização ambiental|crimes? ambienta(?:l|is)|\bIbama\b|\bICMBio\b'),
          ('agro', 'licenciamento ambiental (licenciamento, licença ambiental)', r'licenciamento|licenças? ambienta(?:l|is)'),
          ('agro', 'clima e floresta (Amazônia, floresta, bioma, mudança do clima, carbono, Fundo Clima)', r'Amazôn|florest|\bbiomas?\b|mudanças? (?:do clima|climáticas)|carbono|Fundo Clima')]
lin = [[parte, rot, pt, TSE[pt][1], sum(len(re.findall(rx, p, re.I)) for p in PAG[pt]), len(PAG[pt]), TSE[pt][0]] for parte, rot, rx in TERMOS for pt in ('PT', 'PL')]
# espaco que cada plano da a cultura: o capitulo do PT (item 6, cultura e esporte, paginas 40 a 44) e a parte do PL (pagina 41)
def trecho(pt, ini, fim, pags):
  tx = ' '.join(PAG[pt][p - 1] for p in pags); i = tx.lower().index(ini.lower()); j = tx.lower().index(fim.lower(), i); return tx[i:j]
TT = {pt: sum(len(p.split()) for p in PAG[pt]) for pt in PAG}
CAP = {'PT': trecho('PT', '6. Ampliar o acesso à cultura e ao esporte', '7. Fortalecer o Direito à Cidade', range(40, 45)),
       'PL': trecho('PL', 'Cultura que valoriza nossas raízes', 'BRASIL QUE PROSPERA', range(41, 43))}
# mesmo criterio nos dois planos (auditoria externa de 20/10/2026): so o que trata de cultura, do titulo ao titulo seguinte, sem
# cabecalho de pagina. No PT o capitulo 6 junta cultura e esporte, e a parte de esporte comeca no intertitulo Esporte. E a frequencia
# do vocabulario da cultura (a linha da matriz) por 10 mil palavras do plano inteiro
sem_cab = lambda s: re.sub(r'\s*(?:\d+ )?P R O G R A M A D E G O V E R N O(?: \d+)?\s*', ' ', s)
SO = {'PT': sem_cab(CAP['PT'][:CAP['PT'].index(' Esporte O atual governo Lula reconstruiu')]), 'PL': sem_cab(CAP['PL'])}
RX_CU = next(rx for parte, rot, rx in TERMOS if rot.startswith('cultura e economia criativa'))
OC_CU = {pt: sum(len(re.findall(RX_CU, p, re.I)) for p in PAG[pt]) for pt in PAG}
grava('PR-cultura.csv', ['partido', 'candidatura', 'capitulo', 'palavras_do_capitulo', 'palavras_do_plano', 'pct_do_plano', 'palavras_so_cultura', 'pct_so_cultura',
                         'ocorrencias_vocabulario_cultura', 'vocabulario_cultura_por_10_mil_palavras', 'arquivo'],
      [[pt, TSE[pt][1], 'item 6, cultura e esporte, p. 40 a 44' if pt == 'PT' else 'Cultura que valoriza nossas raízes, p. 41', len(CAP[pt].split()), TT[pt], round(100 * len(CAP[pt].split()) / TT[pt], 1),
        len(SO[pt].split()), round(100 * len(SO[pt].split()) / TT[pt], 1), OC_CU[pt], round(1e4 * OC_CU[pt] / TT[pt], 1), TSE[pt][0]] for pt in ('PT', 'PL')])
# espaco que cada plano da ao agro e ao meio ambiente: itens 9 e 11 do PT, e as partes Agronegocio e Campo e Meio ambiente do PL
AMB = {'PT': [('item 9, segurança alimentar e produção agrícola, p. 58 a 63', trecho('PT', 'Segurança alimentar e produção agrícola', 'Ampliar a Segurança Energética', range(58, 64))),
              ('item 11, sustentabilidade ambiental e climática, p. 69 a 73', trecho('PT', 'Promover a Sustentabilidade Ambiental e Climática', 'Valorizar o Trabalho em suas Múltiplas Formas', range(69, 74)))],
       'PL': [('Agronegócio e Campo, p. 53 a 55', trecho('PL', 'Agronegócio e Campo', 'Minerais críticos', range(53, 56))),
              ('Meio ambiente, o ativo verde do Brasil, p. 57 a 59', trecho('PL', 'Meio ambiente: o ativo verde do Brasil', 'Turismo: uma vocação que rende', range(57, 60)))]}
# nucleo de agro e meio ambiente: o PT tira dos itens 9 e 11 os blocos de fome e alimentacao escolar, de protecao animal e de
# seguranca hidrica, que o PL trata em outros capitulos (auditoria de 20/10/2026). O PL entra inteiro.
FORA = {'PT': [('Segurança alimentar e produção agrícola', 'A agricultura familiar contou'), ('Construímos o portfólio mais robusto', 'No campo da mudança climática'),
               ('A proteção ambiental continuará caminhando ao lado da defesa dos direitos animais', 'Vamos aprimorar a implementação de programas de Pagamento'),
               ('O Novo PAC retomou os investimentos de segurança hídrica', 'Continuaremos a ampliar o investimento em políticas de prevenção')], 'PL': []}
def nucleo(pt, tx):
  for a, b in FORA[pt]:
    if a in tx: i = tx.index(a); tx = tx[:i] + tx[tx.index(b, i):]
  return tx
assert sum(len(nucleo('PT', tx).split()) for _, tx in AMB['PT']) < sum(len(tx.split()) for _, tx in AMB['PT']) - 500
grava('PR-agro-ambiente.csv', ['partido', 'candidatura', 'capitulo', 'palavras_do_capitulo', 'palavras_nucleo', 'palavras_do_plano', 'pct_do_plano', 'pct_nucleo', 'arquivo'],
      [[pt, TSE[pt][1], cap, len(tx.split()), len(nucleo(pt, tx).split()), TT[pt], round(100 * len(tx.split()) / TT[pt], 2), round(100 * len(nucleo(pt, tx).split()) / TT[pt], 2), TSE[pt][0]] for pt in ('PT', 'PL') for cap, tx in AMB[pt]])
grava('PR-ausencias.csv', ['parte', 'termo', 'partido', 'candidatura', 'ocorrencias', 'paginas', 'arquivo'], lin)

# base da lei atual e do mercado: PLDO 2027 (grade de marco/2026 e metas), Focus de 09/10/2026, IBGE
pl = norm(' '.join(p.get_text() for p in fitz.open(os.path.join(RAIZ, 'brutos', 'S', 'pldo2027-anexo-iv-02-metas-fiscais.pdf'))))
num = lambda s: float(s.replace('.', '').replace(',', '.'))
g = re.search(r'Parâmetros 2025 Projeções\* 2026 2027 2028 2029 2030 (.*?) Fonte: SPE/MF', pl).group(1)
U_PLDO = 'PLDO 2027, Anexo IV.2, metas fiscais, tabela 1 (grade de parâmetros de março de 2026) e tabela 3'
lin = []
for rot, chave in (('Valor do salário mínimo (R$ 1,00)', 'salario_minimo_rs'), ('INPC acumulado (%)', 'inpc_pct'), ('PIB real (%)', 'pib_real_pct'), ('IPCA acumulado (%)', 'ipca_pct')):
  vs = re.search(re.escape(rot) + r' ((?:-?[\d.,]+ ){5}-?[\d.,]+)', g).group(1).split()
  lin += [[chave, a, num(v), 'PLDO 2027 (grade de marco de 2026)', U_PLDO] for a, v in zip(range(2025, 2031), vs)]
m = re.search(r'superávit primário, em percentual do PIB, de ([\d,]+)% em 2027, ([\d,]+)% em 2028, ([\d,]+)% em 2029 e ([\d,]+)% em 2030', pl)
lin += [['primario_projetado_pct_pib', a, num(v), 'PLDO 2027, projecao do Governo Central antes das deducoes da meta', U_PLDO] for a, v in zip(range(2027, 2031), m.groups())]
m = re.search(r'resultado primário do Governo Central prevista respectivamente em cada ano do período de 2027 a 2030 é de ([\d,]+)%, ([\d,]+)%, ([\d,]+)% e ([\d,]+)% do PIB', pl)
lin += [['meta_primario_pct_pib', a, num(v), 'PLDO 2027, meta do Governo Central (indicativa a partir de 2028)', U_PLDO] for a, v in zip(range(2027, 2031), m.groups())]
FO = json.load(open(os.path.join(RAIZ, 'brutos', 'S', 'bcb-focus-olinda-anuais-out2026.json'), encoding='utf-8'))
FO = FO['value'] if isinstance(FO, dict) else FO
for ind, chave in (('IPCA', 'focus_ipca_pct'), ('PIB Total', 'focus_pib_pct'), ('Selic', 'focus_selic_fim_pct')):
  for r in FO:
    if r['Indicador'] == ind and r['Data'] == '2026-10-09' and r['baseCalculo'] == 0 and r['DataReferencia'] >= '2027':
      lin.append([chave, int(r['DataReferencia']), r['Mediana'], 'Focus de 09/10/2026, mediana', 'https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais'])
pib = {r['D3C']: float(r['V']) for r in json.load(open(os.path.join(F, 'sidra_5932_v6563.json'), encoding='utf-8'))[1:] if r['D4N'] == 'PIB a preços de mercado'}
lin.append(['pib_real_ibge_pct', 2025, pib['202504'], 'IBGE, Contas Nacionais Trimestrais, taxa acumulada no ano ate o 4o trimestre', 'https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/6563/p/all/c11255/all'])
hr = json.load(open(os.path.join(F, 'sidra_6372_v8186.json'), encoding='utf-8'))[1:]
lin.append(['horas_habituais_trabalho_principal', hr[-1]['D3N'], float(hr[-1]['V']), 'IBGE, PNAD Continua, media de horas habituais por semana no trabalho principal', 'https://apisidra.ibge.gov.br/values/t/6372/n1/all/v/8186/p/all/c58/95253'])
# lei: ganho real entre 2025 e 2030 limitado pelo arcabouco (Lei 15.077, art. 4o) e reajuste dos benefícios acima do piso pelo INPC (Lei 8.213, art. 41-A)
le = lambda f: re.sub(r'\s+', ' ', __import__('html').unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'(?is)<(style|script)[^>]*>.*?</\1>', ' ', open(os.path.join(F, f), 'rb').read().decode('latin-1')))))
assert 'Entre 2025 e 2030, o aumento real de que trata o § 4º do art. 3º da Lei nº 14.663' in le('planalto_L15077.htm')
assert 'com base no Índice Nacional de Preços ao Consumidor - INPC' in le('planalto_l8213cons.htm')
assert 'acumulada nos 12 (doze) meses encerrados em novembro do exercício anterior ao do reajuste' in le('planalto_l14663.htm')
cf = le('planalto_constituicao.htm'); assert 'terá valor mensal inferior ao salário mínimo' in cf and 'a garantia de um salário mínimo de benefício mensal' in cf
l15270 = le('planalto_l15270.htm'); assert 'até R$ 5.000,00 até R$ 312,89 (de modo que o imposto devido seja zero)' in l15270 and 'seja superior a R$ 600.000,00 (seiscentos mil reais) fica sujeita à tributação mínima' in l15270
# salario minimo pela lei atual com a macro do Focus (o Focus nao traz INPC, usa o IPCA do ano anterior no lugar dele). Ganho real
# do ano t = PIB real de t-2, entre 0,6% e 2,5% (Lei 15.077, art. 4o, supondo que o limite do arcabouco de cada ano nao fique abaixo
# do PIB), e arredondamento para o real inteiro acima (Lei 14.663, art. 3o, par. 6o).
import math
fo = {(r['Indicador'], int(r['DataReferencia'])): r['Mediana'] for r in FO if r['Data'] == '2026-10-09' and r['baseCalculo'] == 0}
pibr = {2025: pib['202504'], 2026: fo[('PIB Total', 2026)], 2027: fo[('PIB Total', 2027)], 2028: fo[('PIB Total', 2028)]}
sm = {2026: 1621.0}; ganho = {}
for a in range(2027, 2031):
  ganho[a] = min(max(pibr[a - 2], 0.6), 2.5)
  sm[a] = float(math.ceil(sm[a - 1] * (1 + fo[('IPCA', a - 1)] / 100) * (1 + ganho[a] / 100)))
  lin.append(['salario_minimo_lei_atual_focus_rs', a, sm[a], f'Lei 14.663 e Lei 15.077 com Focus de 09/10/2026: IPCA de {a - 1} no lugar do INPC e ganho real de {ganho[a]:.2f}% (PIB de {a - 2})', 'Focus e IBGE, ver as linhas focus_* e pib_real_ibge_pct'])
gr = lambda gs: round(100 * (math.prod(1 + g / 100 for g in gs) - 1), 1)
pldo = {int(r[1]): r[2] for r in lin if r[0] == 'pib_real_pct'}
lin.append(['ganho_real_acumulado_2027_2030_pct', 'PLDO', gr([min(max(pldo[a - 2], 0.6), 2.5) for a in range(2027, 2031)]), 'ganho real do salario minimo de 2027 a 2030 pela regra, com o PIB da grade do PLDO', U_PLDO])
lin.append(['ganho_real_acumulado_2027_2030_pct', 'Focus', gr(ganho.values()), 'ganho real do salario minimo de 2027 a 2030 pela regra, com o PIB do Focus e do IBGE', 'Focus e IBGE'])
grava('PR-base.csv', ['serie', 'ano', 'valor', 'descricao', 'fonte_url'], lin)

// Baixa os planos de governo do 2o turno de 2026 no TSE. O site recusa requisicao direta (403) e abre num Chromium comum.
// Uso: xvfb-run -a node baixa_tse.js <pasta-de-perfil-temporaria>   (precisa de playwright-core e de um Chromium; grava em fontes/)
const path = require('path'), fs = require('fs');
const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const PAGINA = 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/propostas-de-governo-dos-candidatos-ao-cargo-de-presidente-da-republica-eleicoes-2026-segundo-turno';
const ARQ = [['tse_proposta_pl_2026_2t.pdf', 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pl'],
             ['tse_proposta_pt_2026_2t.pdf', 'https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt']];
(async () => {
  const ctx = await chromium.launchPersistentContext(process.argv[2], { headless: false, executablePath: process.env.CHROME,
    args: ['--disable-blink-features=AutomationControlled'] });
  const p = ctx.pages()[0] || await ctx.newPage();
  await p.goto(PAGINA, { waitUntil: 'domcontentloaded', timeout: 90000 }); await p.waitForTimeout(4000);
  for (const [nome, u] of ARQ) {
    const r = await ctx.request.get(u, { timeout: 120000 });
    fs.writeFileSync(path.join(__dirname, 'fontes', nome), await r.body()); console.log(nome, r.status(), r.url());
    await p.waitForTimeout(3000);
  }
  await ctx.close();
})();

# Frente F: divida publica pelo custo, em R$.
# Gera ../../F-divida.csv a partir dos brutos em brutos/F/ (SGS BCB, notas fiscais BCB, RMD/RAD Tesouro)
# e reaproveita as linhas de GND 2 e GND 6 de ../../B-uniao-por-orgao-e-gnd.csv.
# Rodar com um python que tenha openpyxl:  python build_F.py
import csv, json, os, sys
import openpyxl

H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(H, '..', '..'))
OUT = os.path.join(ROOT, 'F-divida.csv')

SGS_URL = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.{}/dados?formato=json'
EF_URL = 'https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/{}_Tabelas_de_estatisticas_fiscais.xlsx'
EF_TXT = 'https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/{}_Texto_de_estatisticas_fiscais.pdf'
RMD_URL = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322'
RMD_PAGE = 'https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8'
RAD_URL = 'https://thot-arquivos.tesouro.gov.br/publicacao/53715'
D_SGS = '2026-09-30'   # nota para a imprensa de estatisticas fiscais com dado de ago/2026
D_RMD = '2026-09-28'
D_RAD = '2026-01-28'
ANOS = list(range(2019, 2026))

rows = []
def add(ano, estagio, cat, sub, v=None, pt=None, pp=None, url='', data='', nota=''):
    f = lambda x, d: '' if x is None else (('%.' + str(d) + 'f') % x)
    rows.append(['F', ano, estagio, cat, sub, f(v, 2), f(pt, 4), f(pp, 4), url, data, nota])

def sgs(code):
    d = json.load(open(os.path.join(H, 'sgs_%d.json' % code)))
    return {(int(x['data'][6:]), int(x['data'][3:5])): float(x['valor']) for x in d}

# ---------- PIB ----------
pib12 = sgs(4382)              # R$ mi, acumulado 12 meses
PIB_ANO = {a: pib12[(a, 12)] * 1e6 for a in ANOS}
PIB_JANAGO26 = 8989174.76e6    # Tabela 2 da nota BCB de 30/09/2026
PIB_12M_AGO26 = 13342452.57e6  # Tabela 3 da nota BCB de 30/09/2026

# ---------- 1. juros nominais apropriados (NFSP, competencia) ----------
ESF = [  # (sgs R$ mi mensal, sgs %PIB 12m, rotulo, nota)
    (4606, 5750, 'Governo Central (Governo Federal + BCB)', 'soma de Governo Federal (inclui INSS) e BCB'),
    (4607, 5751, 'Governo Federal (sem BCB, inclui INSS)', ''),
    (4608, 5752, 'Banco Central', 'inclui o resultado das operacoes de swap cambial e o custo liquido das compromissadas menos o rendimento das reservas'),
    (4609, 5753, 'Governos regionais (estados + municipios)', ''),
    (4610, 5754, 'Governos estaduais', ''),
    (4611, 5755, 'Governos municipais', ''),
    (4612, 5756, 'Empresas estatais (exceto Petrobras, Eletrobras e bancos)', ''),
    (4613, 5757, 'Empresas estatais federais', ''),
    (4614, 5758, 'Empresas estatais estaduais', ''),
    (4615, 5759, 'Empresas estatais municipais', ''),
    (4616, 5760, 'Setor publico consolidado (total)', ''),
]
M = {c: sgs(c) for c, _, _, _ in ESF}
P = {p: sgs(p) for _, p, _, _ in ESF}
def soma(c, meses):
    return sum(M[c][m] for m in meses) * 1e6
PER = []
for a in ANOS:
    PER.append((a, 'competencia_ano', [(a, m) for m in range(1, 13)], PIB_ANO[a], (a, 12), 'jan-dez/%d' % a))
PER.append((2026, 'competencia_acum_jan_ago', [(2026, m) for m in range(1, 9)], PIB_JANAGO26, None, 'jan-ago/2026'))
PER.append((2026, 'competencia_12m_ate_ago', [(2025, m) for m in range(9, 13)] + [(2026, m) for m in range(1, 9)], PIB_12M_AGO26, (2026, 8), '12 meses set/2025-ago/2026'))
CAT1 = 'JUROS NOMINAIS APROPRIADOS (BCB NFSP)'
checks = []
for ano, est, meses, pib, k12, rot in PER:
    tot = soma(4616, meses)
    gc, reg, est_ = soma(4606, meses), soma(4609, meses), soma(4612, meses)
    gf, bc = soma(4607, meses), soma(4608, meses)
    diff = gc + reg + est_ - tot
    checks.append((rot, tot / 1e9, gc / 1e9, diff / 1e6, (gf + bc - gc) / 1e6))
    for c, p, lab, nt in ESF:
        v = soma(c, meses)
        pp = v / pib * 100
        nota = 'FATO: soma dos meses %s da SGS %d (R$ mi, fluxo mensal, NFSP sem desvalorizacao cambial, competencia)' % (rot, c)
        if k12:
            nota += '; pct_pib oficial SGS %d = %.2f' % (p, P[p][k12])
        else:
            nota += '; pct_pib = calculo sobre PIB jan-ago/2026 da Tabela 2 da nota BCB (R$ 8.989,2 bi)'
        if c == 4616:
            nota += '; conferencia: Governo Central + regionais + estatais menos total = R$ %.1f mi' % (diff / 1e6)
        if nt:
            nota += '; ' + nt
        add(ano, est, CAT1, lab, v, v / tot * 100, pp, SGS_URL.format(c), D_SGS, nota)

# swap cambial (efeito dentro dos juros do BCB), positivo = perda que aumenta os juros
CAT_SW = 'JUROS NOMINAIS APROPRIADOS: efeito do swap cambial do BCB'
SW = [  # ano, estagio, valor R$, release, rotulo
    (2024, 'competencia_ano', 115.9e9, '202601', 'perda de R$ 115,9 bi em 2024'),
    (2025, 'competencia_ano', -105.9e9, '202601', 'ganho de R$ 105,9 bi em 2025'),
    (2025, 'competencia_mes_ago', -19.9e9, '202609', 'ganho de R$ 19,9 bi em ago/2025'),
    (2026, 'competencia_mes_ago', 9.3e9, '202609', 'perda de R$ 9,3 bi em ago/2026'),
]
for ano, est, v, rel, rot in SW:
    pib = PIB_ANO.get(ano) if est == 'competencia_ano' else None
    add(ano, est, CAT_SW, 'resultado das operacoes de swap cambial (+ perda, - ganho)', v, None,
        v / pib * 100 if pib else None, EF_TXT.format(rel), '2026-01-30' if rel == '202601' else D_SGS,
        'FATO: texto da nota para a imprensa de estatisticas fiscais do BCB (%s). Ja esta dentro dos juros do Banco Central e do total; nao somar. Sem serie SGS no catalogo CKAN; anos 2019 a 2023 nao publicados como total anual nas notas de janeiro' % rot)
for ano, v in [(2024, 115.9e9), (2025, -105.9e9)]:
    meses = [(ano, m) for m in range(1, 13)]
    for c, lab in [(4608, 'Banco Central sem swap cambial'), (4606, 'Governo Central sem swap cambial'), (4616, 'Setor publico consolidado sem swap cambial')]:
        x = soma(c, meses) - v
        add(ano, "competencia_ano", CAT_SW, lab, x, None, x / PIB_ANO[ano] * 100,
            SGS_URL.format(c), D_SGS, 'CALCULO: SGS %d anual menos o resultado do swap cambial da nota BCB de 30/01/2026' % c)

# ---------- 2. orcamento da Uniao (caixa), reaproveitado da frente B ----------
CAT2 = 'ORCAMENTO UNIAO (SIOP, frente B)'
want = {('GND: 2 Juros e Encargos da Dívida', 'total do grupo'): 'juros e encargos (GND 2)',
        ('GND: 6 Amortização/Refinanciamento da Dívida', 'total do grupo'): 'amortizacao + refinanciamento (GND 6 total)',
        ('GND: 6 Amortização/Refinanciamento da Dívida', 'refinanciamento (rolagem)'): 'refinanciamento (rolagem, GND 6 elemento 76/77)',
        ('GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)'): 'amortizacao efetiva (GND 6 menos refinanciamento)'}
for r in csv.DictReader(open(os.path.join(ROOT, 'B-uniao-por-orgao-e-gnd.csv'))):
    k = (r['categoria'], r['subcategoria'])
    if k not in want: continue
    if r['estagio'] not in ('liquidado', 'pago_exercicio') and not (r['estagio'] == 'dotacao_atualizada' and r['ano'] == '2026'):
        continue
    nota = 'FATO reaproveitado de B-uniao-por-orgao-e-gnd.csv (nao rebaixado); pct_total = fatia do gasto da Uniao sem refinanciamento, regua da frente B'
    if r['ano'] == '2026' and r['estagio'] != 'dotacao_atualizada':
        nota += '; 2026 parcial, execucao ate 16/10/2026'
    if 'amortizacao efetiva' in want[k]:
        nota += '; inclui elemento 26 (obrigacoes de politica monetaria, Tesouro x BCB)'
    add(int(r['ano']), r['estagio'], CAT2, want[k], float(r['valor_brl']),
        float(r['pct_total']) if r['pct_total'] else None, float(r['pct_pib']) if r['pct_pib'] else None,
        r['fonte_url'], r['data_fonte'], nota)

# ---------- 3. RMD (Tesouro) ----------
wb = openpyxl.load_workbook(os.path.join(H, 'rmd_2026_08', 'anexo', 'Anexo RMD_Agosto_26.xlsx'), read_only=True, data_only=True)
def sheet(n): return [list(r) for r in wb[n].iter_rows(values_only=True)]
MES = {a: 'Dez/%02d' % (a % 100) for a in ANOS}
MES[2026] = 'Ago/26'
PERS = [(a, 'estoque_fim_dez') for a in ANOS] + [(2026, 'estoque_ago')]
def pib_est(a): return pib12[(a, 12 if a < 2026 else 8)] * 1e6
def src(a): return (RMD_URL, D_RMD)
def nrad(a): return '; Dez/2025 conferido com o RAD 2025 de 28/01/2026, tabela de resultados do PAF (' + RAD_URL + ')' if a == 2025 else ''

def by_date(rows_, a):  # linhas cuja coluna 0 e data
    for r in rows_:
        c = r[0]
        if hasattr(c, 'year') and c.year == a and c.month == (12 if a < 2026 else 8):
            return r
def col_sheet(rows_):
    for i, r in enumerate(rows_):
        if sum(1 for c in r if isinstance(c, str) and c.strip() in MES.values()) >= 4:
            return i, {c.strip(): j for j, c in enumerate(r) if isinstance(c, str) and c.strip() in MES.values()}

# 2.1 estoque
s21 = sheet('2.1'); hi, cj = col_sheet(s21)
lab21 = {}
for r in s21[hi + 1:]:
    if isinstance(r[0], str) and r[0].strip() and r[0].strip() not in lab21:
        lab21[r[0].strip()] = r
CAT3 = 'DPF ESTOQUE (RMD)'
for a, est in PERS:
    j = cj[MES[a]]
    dpf = lab21['DPF EM PODER DO PÚBLICO'][j] * 1e9
    u, d = src(a)
    for k, lab in [('DPF EM PODER DO PÚBLICO', 'DPF em poder do publico (total)'), ('DPMFi', 'DPMFi (interna, titulos)'), ('DPFe ¹', 'DPFe (externa)'),
                   ('DPMFi EM PODER DO BANCO CENTRAL', 'DPMFi em poder do Banco Central (fora da DPF, lastro de compromissadas)')]:
        v = lab21[k][j] * 1e9
        add(a, est, CAT3, lab, v, v / dpf * 100 if 'BANCO' not in k else None, v / pib_est(a) * 100, u, d,
            'FATO: RMD anexo 2.1 (R$ bi), %s; pct_pib = calculo sobre PIB 12m SGS 4382%s' % (MES[a], nrad(a)))

# 2.4 composicao por indexador + quebra de indice de precos pelo 2.1
s24 = sheet('2.4')
CAT4 = 'DPF COMPOSICAO POR INDEXADOR (RMD)'
for a, est in PERS:
    r = by_date(s24, a); u, d = src(a); j = cj[MES[a]]
    tot = r[11] * 1e9
    for idx, lab in [(1, 'Prefixado'), (3, 'Indice de precos (IPCA + IGP-M)'), (5, 'Taxa flutuante (Selic, LFT)'), (7, 'Cambio'), (9, 'Demais')]:
        v = r[idx] * 1e9
        add(a, est, CAT4, lab, v, v / tot * 100, v / pib_est(a) * 100, u, d,
            'FATO: RMD anexo 2.4, %s; pct_total = participacao na DPF%s' % (MES[a], nrad(a)))
    ipca = sum((lab21[k][j] or 0) for k in ('NTN-B', 'NTN-B1')) * 1e9
    igpm = (lab21['NTN-C'][j] or 0) * 1e9
    add(a, est, CAT4, 'dos quais IPCA (NTN-B e NTN-B1, so DPMFi)', ipca, ipca / tot * 100, ipca / pib_est(a) * 100, u, d,
        'CALCULO: RMD anexo 2.1, NTN-B + NTN-B1; nao somar com a linha Indice de precos')
    add(a, est, CAT4, 'dos quais IGP-M (NTN-C, so DPMFi)', igpm, igpm / tot * 100, igpm / pib_est(a) * 100, u, d,
        'FATO: RMD anexo 2.1, NTN-C; nao somar com a linha Indice de precos')

# 3.1 vincendo em 12 meses (DPF: primeiro bloco)
s31 = sheet('3.1')
blk = s31[:next(i for i, r in enumerate(s31) if r[0] == 'DPMFi')]
CAT5 = 'DPF PERFIL E CUSTO (RMD)'
for a, est in PERS:
    r = by_date(blk, a); u, d = src(a)
    add(a, est, CAT5, 'vincendo em 12 meses (DPF)', r[1] * 1e9, r[2] * 100, r[1] * 1e9 / pib_est(a) * 100, u, d,
        'FATO: RMD anexo 3.1; pct_total = percentual da DPF que vence em 12 meses%s' % nrad(a))

def colvals(nome, labels):
    s = sheet(nome); hi, cj2 = col_sheet(s)
    out = {}
    for r in s[hi + 1:]:
        if isinstance(r[0], str) and r[0].strip() in labels and r[0].strip() not in out:
            out[r[0].strip()] = {m: r[j] for m, j in cj2.items()}
    return out
pm = colvals('3.7', ['DPF', 'DPMFi'])
cm = colvals('4.2', ['DPF', 'DPMFi', 'DPFe'])
for a, est in PERS:
    u, d = src(a); m = MES[a]
    add(a, est, CAT5, 'prazo medio do estoque DPF (anos)', None, None, None, u, d,
        'VALOR=%.2f anos. FATO: RMD anexo 3.7, %s' % (pm['DPF'][m], m))
    for k in ('DPF', 'DPMFi', 'DPFe'):
        add(a, est, CAT5, 'custo medio do estoque %s, acumulado 12 meses (%% a.a.)' % k, None, None, None, u, d,
            'VALOR=%.2f %% a.a. FATO: RMD anexo 4.2, %s; inclui variacao cambial na DPFe' % (cm[k][m], m))
s43 = sheet('4.3')
hdr = next(r for r in s43 if any(isinstance(c, str) and c.strip() == 'Ago/26' for c in r)); dp = next(r for r in s43 if isinstance(r[0], str) and r[0].strip() == 'DPMFi')
for a, est in PERS:
    m = MES[a]; u, d = src(a)
    if m not in [str(c).strip() for c in hdr if c]:
        add(a, est, CAT5, 'custo medio das emissoes em oferta publica DPMFi, 12 meses (% a.a.)', None, None, None, u, d,
            'SEM DADO: RMD anexo 4.3 so traz a metodologia nova a partir de jan/2021')
        continue
    j = [str(c).strip() if c else '' for c in hdr].index(m)
    add(a, est, CAT5, 'custo medio das emissoes em oferta publica DPMFi, 12 meses (% a.a.)', None, None, None, u, d,
        'VALOR=%.2f %% a.a. FATO: RMD anexo 4.3 (CME), %s' % (dp[j + 2], m))

# 2.7 detentores DPMFi
s27 = sheet('2.7')
CAT6 = 'DPMFi DETENTORES (RMD)'
DET = [(1, 'Instituicoes financeiras'), (3, 'Fundos de investimento'), (5, 'Previdencia'), (7, 'Nao residentes'), (9, 'Tesouro Direto (pessoas fisicas)'),
       (11, 'Governo (FAT, FGTS, fundos garantidores)'), (13, 'Seguradoras'), (15, 'Outros')]
for a, est in PERS:
    r = by_date(s27, a); u, d = src(a); tot = r[17] * 1e9
    for idx, lab in DET:
        v = r[idx] * 1e9
        nt = 'FATO: RMD anexo 2.7, %s; pct_total = participacao na DPMFi' % MES[a]
        if a >= 2025 and idx in (1, 15): nt += '; desde set/2025 cooperativas de credito sairam de Outros para Instituicoes financeiras'
        add(a, est, CAT6, lab, v, v / tot * 100, v / pib_est(a) * 100, u, d, nt)
    add(a, est, CAT6, 'Total DPMFi', tot, 100.0, tot / pib_est(a) * 100, u, d, 'FATO: RMD anexo 2.7, %s' % MES[a])

# 2.9 fatores de variacao: juros apropriados e pagamentos da DPF
s29 = sheet('2.9')
hrow = next(r for r in s29 if any(isinstance(c, str) and c.strip() == 'Ago/26' for c in r))
h29 = [str(int(c)) if isinstance(c, (int, float)) else (str(c).strip() if c is not None else '') for c in hrow]
CAT7 = 'DPF JUROS APROPRIADOS E PAGAMENTOS (RMD)'
lab29 = {}
for r in s29:
    if isinstance(r[0], str):
        lab29.setdefault(' '.join(r[0].split()), r)
L = [('I.2 - Juros Apropriados', 'juros apropriados da DPF (competencia, inclui atualizacao monetaria e cambial)'),
     ('- Juros Apropriados da DPMFi 9', 'juros apropriados da DPMFi'),
     ('- Juros Apropriados da DPFe 10', 'juros apropriados da DPFe (inclui variacao cambial)'),
     ('- Pagamentos Correntes (DPMFi) 6', 'pagamentos correntes DPMFi (principal + juros resgatados, caixa)'),
     ('I.1.1 - Emissões', 'emissoes DPF'),
     ('I.1 - Emissão/Resgate Líquido', 'emissao liquida DPF (emissoes menos resgates)')]
for a in ANOS + [2026]:
    key = str(a); j = h29.index(key)
    est = 'competencia_ano' if a < 2026 else 'competencia_acum_jan_ago'
    pib = PIB_ANO.get(a, PIB_JANAGO26)
    u, d = src(a)
    for k, lab in L:
        v = lab29[k][j] * 1e6
        if 'Pagamentos' in k: v = -v
        add(a, est, CAT7, lab, v, None, v / pib * 100, u, d,
            'FATO: RMD anexo 2.9, coluna %s%s; pct_pib = calculo' % (key if a < 2026 else 'jan-ago/2026', '; sinal invertido (no anexo resgate e negativo)' if 'Pagamentos' in k else ''))
j = h29.index('Ago/26')
v = lab29['I.2 - Juros Apropriados'][j] * 1e6
add(2026, 'competencia_mes_ago', CAT7, 'juros apropriados da DPF (competencia, inclui atualizacao monetaria e cambial)', v, None, None, RMD_URL, D_RMD, 'FATO: RMD anexo 2.9, Ago/26')

# ---------- 4. DBGG e DLSP ----------
CAT8 = 'DIVIDA BRUTA E LIQUIDA (BCB)'
S = {c: sgs(c) for c in (13761, 13762, 4478, 4513, 4468, 4503)}
for a, est in PERS:
    k = (a, 12 if a < 2026 else 8)
    for cr, cp, lab in [(13761, 13762, 'DBGG divida bruta do governo geral (metodologia 2008)'),
                        (4478, 4513, 'DLSP divida liquida do setor publico consolidado'),
                        (4468, 4503, 'DLSP do Governo Federal + BCB')]:
        add(a, est.replace('estoque', 'saldo'), CAT8, lab, S[cr][k] * 1e6, None, S[cp][k], SGS_URL.format(cr), D_SGS,
            'FATO: R$ = SGS %d (R$ mi); pct_pib = SGS %d (oficial)%s' % (cr, cp,
            '; SGS 13761 nao aparece no catalogo CKAN mas responde na API SGS (saldo em R$ mi, coerente com 13762)' if cr == 13761 else ''))

with open(OUT, 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['frente', 'ano', 'estagio', 'categoria', 'subcategoria', 'valor_brl', 'pct_total', 'pct_pib', 'fonte_url', 'data_fonte', 'nota'])
    w.writerows(rows)
print(len(rows), 'linhas ->', OUT)
for c in checks:
    print('check %-28s total %8.1f bi | GC %8.1f bi | GC+reg+est-total %.1f mi | GF+BCB-GC %.1f mi' % c)

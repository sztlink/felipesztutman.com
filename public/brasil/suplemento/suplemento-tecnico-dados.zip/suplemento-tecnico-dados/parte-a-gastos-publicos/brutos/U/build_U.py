#!/usr/bin/env python3
"""Frente U: custo liquido de cada regime de previdencia da Uniao.

Le apenas arquivos ja baixados (brutos/U/*, e so leitura em brutos/D, brutos/P e na raiz) e grava,
na raiz gastos-publicos/:
  U-previdencia-resultado.csv   receita, despesa, resultado, % do PIB, beneficiarios, contribuintes,
                                resultado por beneficiario; RGPS (urbano e rural), RPPS civil, militares
                                (inativos e pensoes), FCDF; 2008 a 2025
  U-previdencia-atuarial.csv    passivo atuarial mais recente (PLDO 2027, data focal 31/12/2025) e
                                provisoes do BGU 2025
Idempotente. Os unicos numeros que nao saem de leitura automatica sao os do demonstrativo do FCDF
republicado no RREO de dez/2025 (camada de texto do PDF ilegivel): estao em FCDF_2025_REPUBL, com
pagina, e a nota de cada linha diz que foram transcritos da imagem.

Rodar de fora da pasta:  python3 -I brutos/U/build_U.py
Dependencias: openpyxl (~/.local/lib/python3.12/site-packages) e pymupdf (~/.local/lib/pdftools).
"""
import csv
import glob
import html
import io
import json
import os
import re
import sys
import zipfile
from collections import OrderedDict

HOME = os.path.expanduser('~')
for p in (os.path.join(HOME, '.local/lib/python3.12/site-packages'), os.path.join(HOME, '.local/lib/pdftools')):
    if os.path.isdir(p) and p not in sys.path:
        sys.path.append(p)
import openpyxl  # noqa: E402
import pymupdf  # noqa: E402

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
P = lambda *a: os.path.join(AQUI, *a)

URL = {}
with open(P('downloads.tsv'), encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        URL[r['arquivo']] = r['url']
SICONFI = 'https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio={a}&nr_periodo=6&co_tipo_demonstrativo=RREO&id_ente=1'

COLS = ['regime', 'serie', 'ano', 'presidente', 'valor', 'unidade', 'fonte_url', 'pagina_ou_tabela', 'nota']


def presidente(a):
    a = int(a)
    if 1997 <= a <= 2002: return 'FHC'
    if 2003 <= a <= 2006: return 'Lula 1'
    if 2007 <= a <= 2010: return 'Lula 2'
    if 2011 <= a <= 2015: return 'Dilma'
    if a == 2016: return 'Dilma/Temer'
    if 2017 <= a <= 2018: return 'Temer'
    if 2019 <= a <= 2022: return 'Bolsonaro'
    if 2023 <= a <= 2026: return 'Lula 3'
    return ''


def num(x):
    if x is None: return None
    if isinstance(x, (int, float)): return float(x)
    s = str(x).strip()
    if s in ('', '-', '...'): return None
    s = s.replace('.', '').replace(',', '.')
    try: return float(s)
    except ValueError: return None


def fmt(v, nd):
    if v is None: return ''
    v = round(float(v), nd)
    return ('%d' % v) if v == int(v) else repr(v)


class Saida:
    def __init__(self, nome):
        self.nome, self.linhas, self.idx = nome, [], {}

    def add(self, regime, serie, ano, valor, unidade, url, pag, nota, nd=3):
        self.linhas.append(OrderedDict(regime=regime, serie=serie, ano=ano, presidente=presidente(ano) if str(ano).isdigit() else '',
                                       valor=fmt(valor, nd), unidade=unidade, fonte_url=url, pagina_ou_tabela=pag,
                                       nota=nota if valor is not None else ('nao encontrado. ' + nota).strip()))
        if valor is not None:
            self.idx[(regime, serie, ano)] = (float(valor), url, pag)

    def get(self, regime, serie, ano):
        return self.idx.get((regime, serie, ano), (None, None, None))

    def grava(self):
        with open(os.path.join(RAIZ, self.nome), 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=COLS)
            w.writeheader()
            for r in self.linhas:
                if chr(0x2014) in ''.join(str(v) for v in r.values()):
                    raise SystemExit('em dash na saida')
                w.writerow(r)
        print('gravado', self.nome, len(self.linhas), 'linhas')


ANOS = range(2008, 2026)
MI = 'R$ milhoes correntes'

# ------------------------------------------------------------------ PIB (frente K)
PIB = {}
with open(os.path.join(RAIZ, 'K-primario-recorrente.csv'), encoding='utf-8') as f:
    for r in csv.DictReader(f):
        PIB[int(r['ano'])] = float(r['pib_rs_mi'])
URL_PIB = 'K-primario-recorrente.csv (pib_rs_mi; BCB SGS 4380 e IBGE, ver brutos/K/LEIAME.md)'

# ------------------------------------------------------------------ Siconfi (RREO, 6o bimestre)
SIC = {}
for a in range(2015, 2026):
    its = []
    for fn in sorted(glob.glob(P('siconfi', 'rreo-%d-p*.json' % a))):
        its += json.load(open(fn, encoding='utf-8'))['items']
    SIC[a] = [x for x in its if str(x['anexo']).startswith('RREO-Anexo 04')]


def sic(a, cods, tipo, anexo_tem=None, ref=None):
    """Valor do RREO dez/a (ou o do ano anterior publicado no RREO dez/ref). tipo 'rec' = receita realizada,
    'emp' = despesa empenhada (no 6o bimestre o RREO fecha o resultado pela empenhada).
    Devolve (valor em R$ milhoes, descricao) ou (None, None)."""
    ref = ref or a
    if isinstance(cods, str): cods = [cods]
    for cod in cods:
        cand = []
        for x in SIC.get(ref, []):
            if x['cod_conta'] != cod: continue
            if anexo_tem and anexo_tem not in x['anexo']: continue
            c = x['coluna']
            ok = False
            if tipo == 'rec':
                ok = (re.match(r'^(RECEITAS REALIZADAS ATÉ O BIMESTRE|Até o Bimestre)\s*(/\s*%d)?\s*$' % a, c) is not None) and (str(a) in c or ref == a)
            else:
                ok = (re.match(r'^DESPESAS EMPENHADAS ATÉ O BIMESTRE\s*(/\s*%d)?\s*$' % a, c) is not None and (str(a) in c or ref == a)) or \
                     re.match(r'^Até o Bimestre\s*/\s*%d$' % a, c) is not None
            if ok and x['valor'] is not None:
                cand.append((float(x['valor']), x['anexo'], c))
        if not cand and tipo == 'emp' and ref == a:
            # Siconfi rotula a empenhada de 2024 e 2025 como "/2023" em algumas contas; aceita se for a unica coluna empenhada
            emp = [(float(x['valor']), x['anexo'], x['coluna'] + ' [rotulo do ano errado no Siconfi]') for x in SIC.get(ref, [])
                   if x['cod_conta'] == cod and (not anexo_tem or anexo_tem in x['anexo']) and x['coluna'].startswith('DESPESAS EMPENHADAS') and x['valor'] is not None]
            if len(emp) == 1: cand = emp
        if cand:
            v, anx, col = max(cand) if tipo == 'emp' else cand[0]
            desc = 'RREO dez/%d, %s, conta %s, coluna "%s"%s' % (ref, anx, cod, col, ' (maior valor entre as colunas "Ate o Bimestre": empenhada)' if tipo == 'emp' and len(cand) > 1 else '')
            return v / 1e6, desc
    return None, None


# ------------------------------------------------------------------ RTN (RGPS urbano e rural)
RTN_ARQ = os.path.join(RAIZ, 'brutos', 'D', 'seriehistoricaago26.xlsx')
URL_RTN = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'
wb = openpyxl.load_workbook(RTN_ARQ, read_only=True, data_only=True)
rows = list(wb['2.2'].iter_rows(values_only=True))
hi = [i for i, r in enumerate(rows) if r[0] == 'Discriminação'][0]
col = {int(v): j for j, v in enumerate(rows[hi]) if isinstance(v, (int, float))}


def rtn(prefixo, memo=False):
    for i, r in enumerate(rows):
        if r[0] and str(r[0]).strip().startswith(prefixo) and ((i > 164) == memo):
            return {a: float(r[col[a]] or 0) for a in col}, str(r[0]).strip()
    raise KeyError(prefixo)


# ------------------------------------------------------------------ AEPS 2024 (RREO 2008 a 2014)
ZARQ = os.path.join(RAIZ, 'brutos', 'P', 'prev', '2-uniao.zip')
URL_AEPS_RPPS = 'https://www.gov.br/previdencia/pt-br/assuntos/rpps/estatisticas-e-informacoes-dos-rpps-1/arquivos/2025/2-uniao.zip'
z = zipfile.ZipFile(ZARQ)
nf = [n for n in z.namelist() if 'RESULTADO FINANCEIRO' in n][0]
rf = list(openpyxl.load_workbook(io.BytesIO(z.read(nf)), read_only=True, data_only=True).worksheets[0].iter_rows(values_only=True))
ih = [i for i, r in enumerate(rf) if r[2] == 2007][0]
anos_aeps = [int(x) for x in rf[ih] if isinstance(x, (int, float))]
AEPS = {}
g = None
for r in rf[ih + 1:]:
    if r[0]: g = str(r[0]).replace('\n', ' ').strip()
    if r[1] in ('RECEITA', 'DESPESA', 'RESULTADO'):
        AEPS[(g, r[1])] = {a: (num(r[2 + k]) / 1e6 if num(r[2 + k]) is not None else None) for k, a in enumerate(anos_aeps)}
PAG_AEPS = 'AEPS 2024, suplemento RPPS, "%s", grupo %%s, linha %%s' % nf.split('/')[-1]

# ------------------------------------------------------------------ Contagens ja extraidas na frente P
PCSV = {}
with open(os.path.join(RAIZ, 'P-previdencia-regimes.csv'), encoding='utf-8') as f:
    for r in csv.DictReader(f):
        if r['valor']:
            PCSV[(r['serie'], r['recorte'], int(r['ano']))] = (float(r['valor']), r['fonte_url'], r['pagina_ou_tabela'] + ' (lido via P-previdencia-regimes.csv)')

S = Saida('U-previdencia-resultado.csv')

# ================================================================== RGPS
arr, l_arr = rtn('1.3 ')
arr_u, l_arru = rtn('1.3.1')
arr_r, l_arrr = rtn('1.3.2')
ben, l_ben = rtn('4.1 ')
ben_u, l_benu = rtn('4.1.1 ')
ben_r, l_benr = rtn('4.1.2 ')
comp_des, l_comp = rtn('Compensação ao RGPS', memo=True)
nota_rtn = ('RTN tab. 2.2 (serie historica ago/2026), R$ milhoes correntes, caixa. Arrecadacao liquida = arrecadacao bruta menos restituicoes e '
            'repasses a terceiros (Sistema S etc.); inclui a compensacao do Tesouro pelas desoneracoes da folha (memorando da tabela; '
            'R$ %s mi somados de 2012 a 2022, contada na clientela urbana). Beneficios inclui sentencas judiciais e precatorios. Urbano e '
            'rural pela metodologia do MPS (nota 3 da tabela)') % fmt(sum(comp_des[a] for a in range(2012, 2023)), 0)
for a in ANOS:
    for reg, rec, des, lr, ld in (('RGPS', arr, ben, l_arr, l_ben), ('RGPS urbano', arr_u, ben_u, l_arru, l_benu), ('RGPS rural', arr_r, ben_r, l_arrr, l_benr)):
        rv, dv = rec[a], des[a]
        S.add(reg, 'receita_contribuicoes', a, rv, MI, URL_RTN, 'RTN tab. 2.2, linha "%s"' % lr, nota_rtn)
        S.add(reg, 'despesa_beneficios', a, dv, MI, URL_RTN, 'RTN tab. 2.2, linha "%s"' % ld, nota_rtn)
        S.add(reg, 'resultado', a, rv - dv, MI, URL_RTN, 'RTN tab. 2.2, "%s" menos "%s"' % (lr, ld), 'derivado: receita menos despesa; negativo = deficit coberto pelo Tesouro')
        S.add(reg, 'resultado_pct_pib', a, (rv - dv) / PIB[a] * 100, '% do PIB', URL_RTN + ' | ' + URL_PIB, 'RTN tab. 2.2 e PIB da frente K', 'derivado: resultado / PIB nominal do ano', nd=3)
    S.add('RGPS', 'compensacao_desoneracao_folha', a, comp_des[a], MI, URL_RTN, 'RTN tab. 2.2, memorando, "%s"' % l_comp,
          'transferencia do Tesouro ao RGPS (Lei 12.546/2011) ja contada na receita acima; sem ela o deficit do ano seria maior por esse valor')
    # compensacao financeira entre regimes (COMPREV), RREO anexo 4 RGPS
    rc, dc = sic(a, 'ReceitasPrevidenciariasExcetoIntraOrcamentariasCompensacaoDoRPPSParaORGPSBrutas', 'rec'), sic(a, 'DespesasPrevidenciariasExcetoIntraOrcamentariasCompensacaoDoRGPSParaORPPS', 'emp')
    if a >= 2015:
        S.add('RGPS', 'comprev_recebida_dos_rpps', a, rc[0], MI, SICONFI.format(a=a), rc[1] or 'RREO anexo 4 RGPS', 'compensacao previdenciaria (Lei 9.796/1999) paga pelos RPPS ao RGPS; esta dentro da arrecadacao do RREO, nao da linha do RTN')
        S.add('RGPS', 'comprev_paga_aos_rpps', a, dc[0], MI, SICONFI.format(a=a), dc[1] or 'RREO anexo 4 RGPS', 'compensacao previdenciaria paga pelo RGPS aos RPPS (de todos os entes); esta dentro da despesa do RREO, fora dos beneficios do RTN')

# beneficios e contribuintes
for a in ANOS:
    q = PCSV.get(('beneficios_emitidos_dez', 'RGPS (INSS)', a))
    if q:
        S.add('RGPS', 'beneficiarios', a, q[0], 'beneficios emitidos em dezembro', q[1], q[2],
              'conta beneficio, nao pessoa (dez/2024: 30,2 milhoes de pessoas para 34,4 milhoes de beneficios, AEPS 2024 26.4). Previdenciarios e acidentarios, sem BPC', nd=0)
# urbano e rural, BEPS dez/2025 tabela 15
BEPS = os.path.join(RAIZ, 'brutos', 'P', 'prev', 'beps122025.pdf')
URL_BEPS = 'https://www.gov.br/previdencia/pt-br/assuntos/previdencia-social/arquivos/beps122025_final.pdf'
d = pymupdf.open(BEPS)
for i, pg in enumerate(d):
    t = pg.get_text()
    if 'BENEFÍCIOS DO RGPS' in t and 'Previdenciários' in t and 'Tempo de Contribuição' in t and 'TOTAL' in t:
        bloco = t.split('BENEFÍCIOS DO RGPS', 1)[1]
        nums = re.findall(r'\d{1,3}(?:\.\d{3})+(?![\d,])', bloco)
        tot, urb, rur = num(nums[0]), num(nums[1]), num(nums[2])
        # tabela 15 e o estoque: o total tem de bater com o quadro 14 (dezembro/2025); paginas de concessao ficam de fora
        if tot != PCSV[('beneficios_emitidos_dez', 'RGPS (INSS)', 2025)][0] or abs(urb + rur - tot) > 2:
            continue
        pag15 = 'BEPS dez/2025, tabela 15 (beneficios emitidos por clientela), linha "BENEFICIOS DO RGPS", pagina %d do PDF' % (i + 1)
        S.add('RGPS urbano', 'beneficiarios', 2025, urb, 'beneficios emitidos em dezembro', URL_BEPS, pag15, 'clientela urbana; conta beneficio', nd=0)
        S.add('RGPS rural', 'beneficiarios', 2025, rur, 'beneficios emitidos em dezembro', URL_BEPS, pag15, 'clientela rural; conta beneficio', nd=0)
        break
# contribuintes: AEPS 2024 tabela 32.1 (2022 a 2024)
t = open(P('aeps', 'aeps2024-32-1.html'), encoding='utf-8').read()
URL_321 = URL['aeps/aeps2024-32-1.html']
lin = []
for tr in re.findall(r'<tr.*?</tr>', t, flags=re.S):
    lin.append([html.unescape(re.sub(r'<[^>]+>', '', x)).strip() for x in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>', tr, flags=re.S)])
k = [i for i, c in enumerate(lin) if c and c[0] == 'BRASIL'][0]
for c in (lin[k][1:], lin[k + 1], lin[k + 2]):
    a = int(c[0])
    S.add('RGPS', 'contribuintes_ativos', a, num(c[1]), 'pessoas com ao menos uma contribuicao no ano', URL_321, 'AEPS 2024, tabela 32.1, linha BRASIL',
          'contribuintes pessoas fisicas; numero medio mensal %s. Dado de 2024 preliminar. Desde out/2022 orgaos publicos migraram para o eSocial com subdeclaracao (nota da tabela)' % c[3], nd=0)
    S.add('RGPS', 'contribuintes_medio_mensal', a, num(c[3]), 'pessoas (media mensal)', URL_321, 'AEPS 2024, tabela 32.1, linha BRASIL', 'soma dos meses com contribuicao de cada pessoa / 12', nd=0)

# ================================================================== RPPS civil, militares, FCDF
FCDF_2025_REPUBL = dict(  # R$ mil, RREO dez/2025 republicado, pagina 20 (pagina 15 do PDF), transcrito da imagem
    receita=1144579, segurados=256758, patronal=887821, despesa_emp=10419105, despesa_liq=10410381, resultado_emp=-9274526)
URL_RREO25 = 'Tesouro Nacional, RREO dez/2025 republicado (copia em brutos/D/RREO_dez2025_republ.pdf; URL de origem nao registrada na frente D)'

for a in ANOS:
    rot_c = 'RPPS civil Uniao'
    if a <= 2014:
        g_c, g_m = 'RPPS DOS SERVIDORES CIVIS', 'PENSÕES MILITARES'
        rc, dc = AEPS[(g_c, 'RECEITA')][a], AEPS[(g_c, 'DESPESA')][a]
        nc = ('RREO compilado pelo MPS (AEPS 2024). Receita inclui contribuicao dos servidores, aposentados e pensionistas e a contribuicao patronal '
              'da Uniao (intraorcamentaria), sem separacao nesta fonte. Despesa = aposentadorias e pensoes; FCDF, IPC e sentencas ficam em "Demais" (nota da planilha)')
        S.add(rot_c, 'receita_contribuicoes', a, rc, MI, URL_AEPS_RPPS, PAG_AEPS % (g_c, 'RECEITA'), nc)
        S.add(rot_c, 'despesa_beneficios', a, dc, MI, URL_AEPS_RPPS, PAG_AEPS % (g_c, 'DESPESA'), nc)
        S.add(rot_c, 'resultado', a, rc - dc, MI, URL_AEPS_RPPS, PAG_AEPS % (g_c, 'RESULTADO'), 'derivado: receita menos despesa (com a patronal da Uniao como receita)')
        rm, dm = AEPS[(g_m, 'RECEITA')][a], AEPS[(g_m, 'DESPESA')][a]
        nm = 'RREO compilado pelo MPS (AEPS 2024). Ate 2016 a planilha repete o mesmo valor em inatividade e em pensoes: e o agregado do pessoal militar (reformas + pensoes); receita = contribuicao para pensao militar'
        S.add('militares (SPSMFA)', 'receita_contribuicoes', a, rm, MI, URL_AEPS_RPPS, PAG_AEPS % (g_m, 'RECEITA'), nm)
        S.add('militares (SPSMFA)', 'despesa_beneficios', a, dm, MI, URL_AEPS_RPPS, PAG_AEPS % (g_m, 'DESPESA'), nm)
        S.add('militares (SPSMFA)', 'resultado', a, rm - dm, MI, URL_AEPS_RPPS, PAG_AEPS % (g_m, 'RESULTADO'), 'derivado: receita menos despesa')
        S.add(rot_c, 'resultado_pct_pib', a, (rc - dc) / PIB[a] * 100, '% do PIB', URL_AEPS_RPPS + ' | ' + URL_PIB, 'resultado / PIB', 'derivado', nd=3)
        S.add('militares (SPSMFA)', 'resultado_pct_pib', a, (rm - dm) / PIB[a] * 100, '% do PIB', URL_AEPS_RPPS + ' | ' + URL_PIB, 'resultado / PIB', 'derivado', nd=3)
        continue
    U_ = SICONFI.format(a=a)
    # ---- civil
    if a <= 2016:
        tot_r = sic(a, ['TotalReceitasRPPS', 'TotalReceitasRPPSPrevidenciario'], 'rec')
        mil_r = sic(a, ['ReceitaDeContribuicoesDosSeguradosPessoalMilitarBruta', 'ReceitaDeContribuicoesDosSeguradosPessoalMilitarBrutaPrevidenciario'], 'rec')
        seg_c = sic(a, ['ReceitaDeContribuicoesDosSeguradosPessoalCivilBruta', 'ReceitaDeContribuicoesDosSeguradosPessoalCivilBrutaPrevidenciario'], 'rec')
        pat_c = sic(a, ['ReceitaIntraOrcamentariaDeContribuicoesPatronaisPessoalCivilBruta', 'ReceitaIntraOrcamentariaDeContribuicoesPatronaisPessoalCivilBrutaPrevidenciario'], 'rec')
        tot_d = sic(a, ['TotalDasDespesasRPPS', 'TotalDasDespesasRPPSPrevidenciario'], 'emp')
        mil_d = sic(a, ['DespesasPrevidenciariasExcetoIntraOrcamentariasPessoalMilitar', 'DespesasPrevidenciariasExcetoIntraOrcamentariasPessoalMilitarPrevidenciario'], 'emp')
        mil_ref = sic(a, ['DespesasExcetoIntraOrcamentariasPessoalMilitarReformas', 'DespesasExcetoIntraOrcamentariasPessoalMilitarReformasPrevidenciario'], 'emp')
        mil_pen = sic(a, ['DespesasExcetoIntraOrcamentariasPessoalMilitarPensoes', 'DespesasExcetoIntraOrcamentariasPessoalMilitarPensoesPrevidenciario'], 'emp')
        rc, dc = tot_r[0] - mil_r[0], tot_d[0] - mil_d[0]
        pr = 'RREO dez/%d (Siconfi): total do RPPS menos a parcela do pessoal militar; contas %s e %s' % (a, tot_r[1].split('conta ')[1].split(',')[0], mil_r[1].split('conta ')[1].split(',')[0])
        pd_ = 'RREO dez/%d (Siconfi): total das despesas do RPPS menos pessoal militar, coluna empenhada' % a
        nc = 'derivado: o anexo de %d junta civis e militares; civil = total - militar. Despesa inclui "outras despesas previdenciarias" (onde estao FCDF, extinto IPC e sentencas)' % a
        S.add(rot_c, 'receita_contribuicoes', a, rc, MI, U_, pr, nc)
        S.add(rot_c, 'receita_segurados', a, seg_c[0], MI, U_, seg_c[1], 'contribuicao dos servidores ativos, aposentados e pensionistas civis')
        S.add(rot_c, 'receita_patronal_uniao', a, pat_c[0], MI, U_, pat_c[1], 'contribuicao patronal da Uniao, intraorcamentaria (sai do proprio Tesouro)')
        S.add(rot_c, 'despesa_beneficios', a, dc, MI, U_, pd_, nc)
        rm, dm = mil_r[0], mil_d[0]
        S.add('militares (SPSMFA)', 'receita_contribuicoes', a, rm, MI, U_, mil_r[1], 'contribuicao para a pensao militar (ativos e inativos)')
        S.add('militares (SPSMFA)', 'despesa_beneficios', a, dm, MI, U_, mil_d[1], 'reformas, reserva e pensoes militares, empenhada')
        S.add('militares inativos', 'despesa_beneficios', a, mil_ref[0], MI, U_, mil_ref[1], 'reformas e reserva remunerada')
        S.add('pensoes militares', 'despesa_beneficios', a, mil_pen[0], MI, U_, mil_pen[1], 'pensoes militares')
    else:
        rc_, dc_ = sic(a, 'TotalReceitasRPPSPrevidenciario', 'rec'), sic(a, 'TotalDasDespesasRPPSPrevidenciario', 'emp')
        seg_c = sic(a, 'ReceitaDeContribuicoesDosSeguradosPrevidenciario', 'rec')
        pat_c = sic(a, 'ReceitaDeContribuicoesPatronalPrevidenciario', 'rec')
        rc, dc = rc_[0], dc_[0]
        nc = 'RREO anexo 4, RPPS dos servidores civis. Receita inclui a patronal da Uniao. ' + (
            'Em 2017 e 2018 o demonstrativo civil incorpora o FCDF (nota da planilha AEPS); de 2019 em diante o FCDF sai em quadro proprio' if a <= 2018 else 'FCDF em quadro proprio')
        S.add(rot_c, 'receita_contribuicoes', a, rc, MI, U_, rc_[1], nc)
        S.add(rot_c, 'receita_segurados', a, seg_c[0], MI, U_, seg_c[1], 'contribuicao dos servidores ativos, aposentados e pensionistas civis')
        S.add(rot_c, 'receita_patronal_uniao', a, pat_c[0], MI, U_, pat_c[1], 'contribuicao patronal da Uniao, intraorcamentaria (sai do proprio Tesouro)')
        S.add(rot_c, 'despesa_beneficios', a, dc, MI, U_, dc_[1], nc)
        # ---- militares
        if a == 2017:
            mr = sic(a, 'TotalReceitasRPPSFinanceiro', 'rec')
            md = sic(a, 'TotalDasDespesasRPPSFinanceiro', 'emp')
            mi_ = sic(a, 'DespesasPrevidenciariasExcetoIntraOrcamentariasAposentadoriasReformasFinanceiro', 'emp')
            mp_ = sic(a, 'DespesasExcetoIntraOrcamentariasPessoalCivilPensoesRPPSFinanceiro', 'emp')
            rm, dm = mr[0], md[0]
            S.add('militares (SPSMFA)', 'receita_contribuicoes', a, rm, MI, U_, mr[1], 'contribuicao para a pensao militar')
            S.add('militares (SPSMFA)', 'despesa_beneficios', a, dm, MI, U_, md[1], 'reformas e pensoes militares, empenhada')
            S.add('militares inativos', 'despesa_beneficios', a, mi_[0], MI, U_, mi_[1], 'reformas e reserva remunerada')
            S.add('pensoes militares', 'despesa_beneficios', a, mp_[0], MI, U_, mp_[1], 'pensoes militares (a conta tem "PessoalCivil" no nome, mas esta no bloco militar)')
        else:
            mr = sic(a, 'TotalReceitasRPPSFinanceiro', 'rec')
            mp_ = sic(a, 'TotalDasDespesasRPPSFinanceiro', 'emp')
            mi_ = sic(a, 'TotalDespesas', 'emp')
            if mi_[0] is None:  # 2018: o quadro de inativos so aparece no RREO de 2019 (coluna do ano anterior)
                mi_ = sic(a, 'TotalDespesas', 'emp', ref=a + 1)
            rm, dm = mr[0], mp_[0] + mi_[0]
            S.add('militares (SPSMFA)', 'receita_contribuicoes', a, rm, MI, U_, mr[1], 'contribuicao de militares e pensionistas para a pensao militar; nao ha contribuicao patronal')
            S.add('militares (SPSMFA)', 'despesa_beneficios', a, dm, MI, U_, 'soma de %s e %s' % (mp_[1], mi_[1]), 'derivado: pensoes militares + inativos (reforma e reserva), empenhada')
            S.add('militares inativos', 'despesa_beneficios', a, mi_[0], MI, SICONFI.format(a=int(re.search(r'dez/(\d{4})', mi_[1]).group(1))), mi_[1], 'reforma e reserva remunerada; sem contribuicao do militar nem patronal (Lei 6.880/1980, art. 53-A)')
            S.add('pensoes militares', 'receita_contribuicoes', a, rm, MI, U_, mr[1], 'contribuicao para a pensao militar (10,5% + 1,5% opcional + 3% das filhas pensionistas)')
            S.add('pensoes militares', 'despesa_beneficios', a, mp_[0], MI, U_, mp_[1], 'pensoes militares, empenhada')
            S.add('pensoes militares', 'resultado', a, rm - mp_[0], MI, U_, 'receita menos despesa do quadro de pensoes', 'derivado')
        # ---- FCDF
        if a >= 2019:
            fr = sic(a, 'TotalReceitasRPPSPrevidenciarioFCDF', 'rec')
            fd = sic(a, 'TotalDasDespesasRPPSPrevidenciarioFCDF', 'emp')
            fs = sic(a, 'ReceitaDeContribuicoesDosSeguradosPrevidenciarioFCDF', 'rec')
            fp = sic(a, 'ReceitaDeContribuicoesPatronalPrevidenciarioFCDF', 'rec')
            nf_ = 'RREO anexo 4, quadro do FCDF (policias civil e militar e bombeiros do DF pagos pela Uniao). Receita inclui a patronal'
            if a == 2025:
                X = FCDF_2025_REPUBL
                pag = 'RREO dez/2025 republicado, anexo 4, demonstrativo do FCDF (4/4), pagina 20 do relatorio (15 do PDF), transcrito da imagem'
                ntx = (' Valor do demonstrativo REPUBLICADO "por atualizacao de metodologia, incluindo acoes de governo novas"; o Siconfi guarda a versao original, '
                       'com despesa empenhada de R$ %s mi (metade). Camada de texto do PDF ilegivel: numero transcrito da imagem' % fmt(fd[0], 1))
                S.add('FCDF', 'receita_contribuicoes', a, X['receita'] / 1e3, MI, URL_RREO25, pag, nf_ + '.' + ntx)
                S.add('FCDF', 'receita_segurados', a, X['segurados'] / 1e3, MI, URL_RREO25, pag, 'contribuicao dos segurados.' + ntx)
                S.add('FCDF', 'receita_patronal_uniao', a, X['patronal'] / 1e3, MI, URL_RREO25, pag, 'patronal sobre ativos e sobre inativos e pensionistas.' + ntx)
                S.add('FCDF', 'despesa_beneficios', a, X['despesa_emp'] / 1e3, MI, URL_RREO25, pag, 'empenhada.' + ntx)
            else:
                S.add('FCDF', 'receita_contribuicoes', a, fr[0], MI, U_, fr[1], nf_)
                S.add('FCDF', 'receita_segurados', a, fs[0], MI, U_, fs[1], 'contribuicao dos segurados')
                S.add('FCDF', 'receita_patronal_uniao', a, fp[0], MI, U_, fp[1], 'patronal')
                S.add('FCDF', 'despesa_beneficios', a, fd[0], MI, U_, fd[1], 'empenhada')
            r_, d_ = S.get('FCDF', 'receita_contribuicoes', a)[0], S.get('FCDF', 'despesa_beneficios', a)[0]
            S.add('FCDF', 'resultado', a, r_ - d_, MI, S.get('FCDF', 'despesa_beneficios', a)[1], 'receita menos despesa', 'derivado')
            S.add('FCDF', 'resultado_pct_pib', a, (r_ - d_) / PIB[a] * 100, '% do PIB', URL_PIB, 'resultado / PIB', 'derivado', nd=3)
    # resultados civil e militares
    S.add(rot_c, 'resultado', a, rc - dc, MI, U_, 'receita menos despesa', 'derivado: com a patronal da Uniao como receita; negativo = deficit')
    pat = S.get(rot_c, 'receita_patronal_uniao', a)[0]
    if pat is not None:
        S.add(rot_c, 'resultado_sem_patronal', a, rc - pat - dc, MI, U_, 'receita - patronal - despesa',
              'derivado: tira a contribuicao patronal da Uniao, que e transferencia intraorcamentaria (o Tesouro paga a si mesmo). E o custo liquido para o Tesouro')
        S.add(rot_c, 'resultado_sem_patronal_pct_pib', a, (rc - pat - dc) / PIB[a] * 100, '% do PIB', URL_PIB, 'resultado sem patronal / PIB', 'derivado', nd=3)
    S.add(rot_c, 'resultado_pct_pib', a, (rc - dc) / PIB[a] * 100, '% do PIB', URL_PIB, 'resultado / PIB', 'derivado', nd=3)
    S.add('militares (SPSMFA)', 'resultado', a, rm - dm, MI, U_ if a >= 2015 else URL_AEPS_RPPS, 'receita menos despesa', 'derivado: inativos + pensoes contra a contribuicao para pensao; nao ha patronal a descontar')
    S.add('militares (SPSMFA)', 'resultado_pct_pib', a, (rm - dm) / PIB[a] * 100, '% do PIB', URL_PIB, 'resultado / PIB', 'derivado', nd=3)

# ---- contagens RPPS civil, militares, FCDF
PLDO11 = os.path.join(RAIZ, 'brutos', 'P', 'prev', 'pldo2027-anexo-iv-11-rpps-uniao.pdf')
URL11 = 'https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/pldo/anexo-iv-11-avaliacao-atuarial-rpps.pdf'
PLDO12 = os.path.join(RAIZ, 'brutos', 'P', 'prev', 'pldo2027-anexo-iv-12-militares.pdf')
URL12 = 'https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/pldo/anexo-iv-12-avaliacao-atuarial-pensoes-militares-2013-volume-1.pdf'
d11 = pymupdf.open(PLDO11)
T11 = [pg.get_text() for pg in d11]
d12 = pymupdf.open(PLDO12)
T12 = [pg.get_text() for pg in d12]
iN = lambda s: num(s)
for a in ANOS:
    qa, qp, qs = (PCSV.get(('segurados_rpps_civil_uniao', g_, a)) for g_ in ('aposentados', 'pensionistas', 'servidores'))
    if qa and qp:
        S.add('RPPS civil Uniao', 'beneficiarios', a, qa[0] + qp[0], 'pessoas', qa[1], qa[2], 'derivado: aposentados %s + pensionistas %s da base cadastral do PLDO (base jul ate 2017, dez de 2018 a 2024)' % (fmt(qa[0], 0), fmt(qp[0], 0)), nd=0)
        S.add('RPPS civil Uniao', 'contribuintes_ativos', a, qs[0], 'pessoas', qs[1], qs[2], 'servidores ativos civis, todos os Poderes', nd=0)
m = re.search(r'foram considerados ([\d.]+) segurados, sendo\s+([\d.]+)\s+\([\d,]+%\)\s+servidores\s+ativos,\s+([\d.]+)\s+\([\d,]+%\)\s+aposentados\s+e\s+([\d.]+)', ' '.join(' '.join(T11).split()))
pg11 = [i for i, t in enumerate(T11) if 'foram considerados' in t and 'segurados' in t][0] + 1
S.add('RPPS civil Uniao', 'beneficiarios', 2025, iN(m.group(3)) + iN(m.group(4)), 'pessoas', URL11, 'PLDO 2027, Anexo IV.11, item 2 (texto da Tabela 2), pagina %d do PDF' % pg11,
      'derivado: aposentados %s + pensionistas %s, base cadastral jul/2025' % (m.group(3), m.group(4)), nd=0)
S.add('RPPS civil Uniao', 'contribuintes_ativos', 2025, iN(m.group(2)), 'pessoas', URL11, 'PLDO 2027, Anexo IV.11, pagina %d do PDF' % pg11, 'servidores ativos, base jul/2025', nd=0)
for a in ANOS:
    qi, qp = PCSV.get(('segurados_militares_uniao', 'militares inativos', a)), PCSV.get(('segurados_militares_uniao', 'pensionistas militares', a))
    qc, qt = PCSV.get(('segurados_militares_uniao', 'militares ativos de carreira', a)), PCSV.get(('segurados_militares_uniao', 'militares ativos temporarios', a))
    if qi and qp:
        S.add('militares (SPSMFA)', 'beneficiarios', a, qi[0] + qp[0], 'pessoas', qi[1], qi[2], 'derivado: inativos %s + pensionistas %s (Ministerio da Defesa, dezembro)' % (fmt(qi[0], 0), fmt(qp[0], 0)), nd=0)
        S.add('militares inativos', 'beneficiarios', a, qi[0], 'pessoas', qi[1], qi[2], 'Ministerio da Defesa via AEPS', nd=0)
        S.add('pensoes militares', 'beneficiarios', a, qp[0], 'pessoas', qp[1], qp[2], 'Ministerio da Defesa via AEPS', nd=0)
    if qc and qt:
        S.add('militares (SPSMFA)', 'contribuintes_ativos', a, qc[0] + qt[0], 'pessoas', qc[1], qc[2], 'derivado: ativos de carreira %s + temporarios %s; contribuem so para a pensao' % (fmt(qc[0], 0), fmt(qt[0], 0)), nd=0)
pg9 = [i for i, t in enumerate(T12) if 'a) Militares Ativos' in t and 'Praças Carreira' in t][0]
blk = T12[pg9].split('a) Militares Ativos')[1]
ati = [iN(x) for x in re.findall(r'\d{1,3}(?:\.\d{3})+', blk.split('b) Militares Inativos')[0])]
ina = [iN(x) for x in re.findall(r'\d{1,3}(?:\.\d{3})+', blk.split('b) Militares Inativos')[1].split('c) Pensionistas')[0])]
pbe = [iN(x) for x in re.findall(r'\d{1,3}(?:\.\d{3})+', blk.split('d) Pensionistas Beneficiários')[1])]
assert abs(sum(ati[:-1]) - ati[-1]) < 1 and abs(sum(ina[:-1]) - ina[-1]) < 1
pag12 = 'PLDO 2027, Anexo IV.12, item 3.1.1, pagina %d do PDF' % (pg9 + 1)
n12 = 'Forcas Armadas, dados de maio/2025 extrapolados para 31/12/2025'
S.add('militares (SPSMFA)', 'beneficiarios', 2025, ina[-1] + pbe[2], 'pessoas', URL12, pag12, 'derivado: inativos %s + pensionistas beneficiarios %s. %s' % (fmt(ina[-1], 0), fmt(pbe[2], 0), n12), nd=0)
S.add('militares inativos', 'beneficiarios', 2025, ina[-1], 'pessoas', URL12, pag12, n12, nd=0)
S.add('pensoes militares', 'beneficiarios', 2025, pbe[2], 'pessoas', URL12, pag12, 'pensionistas beneficiarios. ' + n12, nd=0)
S.add('militares (SPSMFA)', 'contribuintes_ativos', 2025, ati[-1], 'pessoas', URL12, pag12, 'militares ativos de carreira e temporarios, inclusive pracas especiais. ' + n12, nd=0)
pgx = [i for i, t in enumerate(T11) if 'totalizaram' in t and 'FCDF' in ' '.join(T11[max(0, i - 1):i + 1])][0]
mx = re.search(r'totalizaram\s+([\d.]+)\s+segurados,\s+representados\s+por\s+([\d.]+)\s+servidores/militares\s+\([\d,]+%\),\s+([\d.]+)\s+aposentados/inativos\s+\([\d,]+%\)\s+e\s+([\d.]+)\s+pensionistas', ' '.join(T11[pgx].split()))
pagx = 'PLDO 2027, Anexo IV.11, Anexo XV (policiais civis e militares do DF), pagina %d do PDF' % (pgx + 1)
S.add('FCDF', 'beneficiarios', 2025, iN(mx.group(3)) + iN(mx.group(4)), 'pessoas', URL11, pagx, 'derivado: aposentados/inativos %s + pensionistas %s; base usada na avaliacao com data focal 31/12/2025' % (mx.group(3), mx.group(4)), nd=0)
S.add('FCDF', 'contribuintes_ativos', 2025, iN(mx.group(2)), 'pessoas', URL11, pagx, 'servidores e militares ativos da PCDF, PMDF e CBMDF', nd=0)

# ---- RGPS, RPPS, militares, FCDF: resultado por beneficiario
for reg in ('RGPS', 'RGPS urbano', 'RGPS rural', 'RPPS civil Uniao', 'militares (SPSMFA)', 'FCDF'):
    for a in ANOS:
        r_, u1, p1 = S.get(reg, 'resultado', a)
        b_, u2, p2 = S.get(reg, 'beneficiarios', a)
        if r_ is None or b_ is None: continue
        S.add(reg, 'resultado_por_beneficiario', a, r_ * 1e6 / b_, 'R$ correntes por ano', '%s | %s' % (u1, u2), 'resultado do ano / beneficiarios',
              'derivado: deficit (negativo) por beneficiario. ' + ('RGPS: por beneficio emitido em dezembro, nao por pessoa' if reg.startswith('RGPS') else 'pessoas no fim do ano (RPPS: base cadastral do PLDO)'), nd=0)
        if reg == 'RPPS civil Uniao':
            rs = S.get(reg, 'resultado_sem_patronal', a)[0]
            if rs is not None:
                S.add(reg, 'resultado_sem_patronal_por_beneficiario', a, rs * 1e6 / b_, 'R$ correntes por ano', u1, 'resultado sem patronal / beneficiarios', 'derivado', nd=0)
S.grava()

# ================================================================== atuarial
A = Saida('U-previdencia-atuarial.csv')
j11 = ' '.join(' '.join(T11).split())
p18 = [i for i, t in enumerate(T11) if 'Valor Presente Atuarial (VPA) dos Benefícios Concedidos' in t][0] + 1
m = re.search(r'Benefícios Concedidos e a Conceder de R\$ ([\d.]+), enquanto o VPA das Contribuições Futuras totalizou R\$ ([\d.]+).*?déficit atuarial de R\$ ([\d.]+)', j11)
vabf, vacf, defi = (iN(x) / 1e6 for x in m.groups())
assert abs(vabf - vacf - defi) < 1
taxa = re.search(r'Foi utilizada a taxa real de juros de ([\d,]+)% ao ano', j11).group(1)
dur = re.search(r'duração do passivo do RPPS da União de ([\d,]+) anos', j11).group(1)
pg11t = [i for i, t in enumerate(T11) if 'Foi utilizada a taxa real de juros' in t][0] + 1
base = 'data focal 31/12/2025, grupo fechado (sem reposicao de servidores), metodo PUC-a, taxa real %s%% a.a. (duracao do passivo %s anos, Portaria MTP 1.467/2022), projecoes 2026 a 2100' % (taxa, dur)
pag = 'PLDO 2027, Anexo IV.11, secao 3, pagina %d do PDF; taxa na pagina %d' % (p18, pg11t)
R = 'RPPS civil Uniao'
A.add(R, 'vp_beneficios_concedidos_e_a_conceder', 2025, vabf, MI, URL11, pag, base)
A.add(R, 'vp_contribuicoes_futuras', 2025, vacf, MI, URL11, pag, base + '. Inclui contribuicao sobre salarios (servidor e patronal) e sobre beneficios')
A.add(R, 'deficit_atuarial', 2025, defi, MI, URL11, pag, base + '. Exclui o FCDF (anexo XV a parte)')
A.add(R, 'deficit_atuarial_pct_pib', 2025, defi / PIB[2025] * 100, '% do PIB 2025', URL11 + ' | ' + URL_PIB, pag, 'derivado: deficit atuarial / PIB de 2025', nd=2)
# sensibilidade e componentes (Anexo VII)
p39 = [i for i, t in enumerate(T11) if 'ANEXO VII: ANÁLISE DE SENSIBILIDADE - TAXA DE JUROS' in t][-1]
s7 = ' '.join(T11[p39].split())
nums7 = [iN(x) for x in re.findall(r'\d{1,3}(?:\.\d{3}){2,}', s7)]
# ordem: VPC (A,B,dif), sobre salarios, sobre beneficios, deficit, total, ... concedidos, apos, pens, a conceder, apos, pens, total
vpc_b, def_b, conc_a, aconc_a = nums7[1], nums7[10], nums7[15], nums7[24]
assert abs(nums7[0] / 1e6 - vacf) < 1 and abs(nums7[9] / 1e6 - defi) < 1
pg7 = 'PLDO 2027, Anexo IV.11, Anexo VII (sensibilidade a taxa de juros), pagina %d do PDF' % (p39 + 1)
A.add(R, 'vp_beneficios_concedidos', 2025, conc_a / 1e6, MI, URL11, pg7, base + '. Aposentados e pensionistas atuais')
A.add(R, 'vp_beneficios_a_conceder', 2025, aconc_a / 1e6, MI, URL11, pg7, base + '. Servidores ativos atuais')
A.add(R, 'deficit_atuarial_taxa_4_82', 2025, def_b / 1e6, MI, URL11, pg7, 'mesma avaliacao com a taxa do ano anterior (4,82% a.a.): +8,33%')
m = re.search(r'O déficit atuarial calculado para o exercício de 2025, que foi de R\$ ([\d,]+) trilhão', j11)
pg26 = [i for i, t in enumerate(T11) if 'O déficit atuarial calculado para o exercício de 2025' in t][0] + 1
A.add(R, 'deficit_atuarial_avaliacao_anterior', 2024, num(m.group(1)) * 1e6, MI, URL11, 'PLDO 2027, Anexo IV.11, pagina %d do PDF (valor arredondado no texto)' % pg26,
      'avaliacao do PLDO 2026, data focal 31/12/2024, taxa 4,82% a.a.; o texto da apenas R$ 1,56 trilhao')
# FCDF (anexo XV)
for titulo, rot in (('Resultados das Avaliações Atuariais Relativas aos Policiais Civis do DF', 'FCDF policia civil'),
                    ('Resultados das Avaliações Atuariais Relativas aos Policiais e Bombeiros Militares do DF', 'FCDF policia e bombeiros militares')):
    pgf = [i for i, t in enumerate(T11) if titulo in t and 'CONTAS DO ATIVO' in t][0]
    tf = ' '.join(T11[pgf].split())
    tx = re.findall(r'TAXA ([\d,]+)% aa', tf)
    nn = [iN(x) for x in re.findall(r'\d{1,3}(?:\.\d{3}){2,}', tf)]
    # blocos de 3 colunas (2023, 2024, 2025): VPC, s/ salarios, s/ beneficios, deficit, total, ...
    vpc25, def25, tot25 = nn[2], nn[11], nn[14]
    assert abs(vpc25 + def25 - tot25) < 2
    pf = 'PLDO 2027, Anexo IV.11, Anexo XV, pagina %d do PDF' % (pgf + 1)
    nb = 'data focal 31/12/2025, grupo fechado, taxa real %s%% a.a.; mesmas premissas do RPPS civil' % tx[2]
    A.add(rot, 'vp_beneficios_concedidos_e_a_conceder', 2025, tot25 / 1e6, MI, URL11, pf, nb)
    A.add(rot, 'vp_contribuicoes_futuras', 2025, vpc25 / 1e6, MI, URL11, pf, nb)
    A.add(rot, 'deficit_atuarial', 2025, def25 / 1e6, MI, URL11, pf, nb)
f1, f2 = A.get('FCDF policia civil', 'deficit_atuarial', 2025)[0], A.get('FCDF policia e bombeiros militares', 'deficit_atuarial', 2025)[0]
A.add('FCDF', 'deficit_atuarial', 2025, f1 + f2, MI, URL11, 'PLDO 2027, Anexo IV.11, Anexo XV', 'derivado: policia civil + policia e bombeiros militares do DF')
# militares
j12 = ' '.join(' '.join(T12).split())
pgr = [i for i, t in enumerate(T12) if '7.3 Reserva Matemática' in t and 'RESERVA MATEMÁTICA' in t][0]
tr = ' '.join(T12[pgr].split()).split('7.3 Reserva Matemática')[1]
ri = [num(x) for x in re.findall(r'R\$ ([\d.]+,\d{2})', tr)[:3]]
pgp = [i for i, t in enumerate(T12) if 'RESERVA MATEMÁTICA' in t and 'Pensões militares concedidas' in t][0]
tp = ' '.join(T12[pgp].split())
rp = [num(x) for x in re.findall(r'R\$\s+([\d.]+,\d{2})', tp)[:7]]
tx_i, tx_p = re.search(r'taxa de desconto de ([\d,]+)% para as despesas com militares inativos e de ([\d,]+)% para as despesas com pensões', j12).groups()
du_i, du_p = re.search(r'durações de ([\d,]+) anos para o passivo de militares inativos e de ([\d,]+) anos', j12).groups()
pgt = [i for i, t in enumerate(T12) if 'taxa de desconto de' in ' '.join(t.split()) and 'durações de' in ' '.join(t.split())][0] + 1
nmi = ('data focal 31/12/2025, massa fechada, metodo PUC, taxa real %s%% a.a. (duracao %s anos), horizonte = vida de todos os atuais e futuros '
       'beneficiarios; projecoes por 75 anos. Sem contribuicao: o passivo inteiro e do Tesouro' % (tx_i, du_i))
A.add('militares inativos', 'vp_beneficios_concedidos_e_a_conceder', 2025, ri[0] / 1e6, MI, URL12, 'PLDO 2027, Anexo IV.12, item 7.3, pagina %d do PDF; taxa na pagina %d' % (pgr + 1, pgt), nmi)
A.add('militares inativos', 'vp_beneficios_concedidos', 2025, ri[1] / 1e6, MI, URL12, 'PLDO 2027, Anexo IV.12, item 7.3, pagina %d do PDF' % (pgr + 1), nmi)
A.add('militares inativos', 'vp_beneficios_a_conceder', 2025, ri[2] / 1e6, MI, URL12, 'PLDO 2027, Anexo IV.12, item 7.3, pagina %d do PDF' % (pgr + 1), nmi)
A.add('militares inativos', 'deficit_atuarial', 2025, ri[0] / 1e6, MI, URL12, 'PLDO 2027, Anexo IV.12, item 7.3', 'igual ao VP dos beneficios: nao ha contribuicao. ' + nmi)
assert abs(rp[1] + rp[4] - rp[0]) < 1 and abs(rp[2] - rp[3] - rp[1]) < 1000  # a fonte erra R$ 100 em concedidas
npe = 'data focal 31/12/2025, massa fechada, PUC, taxa real %s%% a.a. (duracao %s anos)' % (tx_p, du_p)
pgp_ = 'PLDO 2027, Anexo IV.12, item 8.3, pagina %d do PDF' % (pgp + 1)
A.add('pensoes militares', 'vp_beneficios_concedidos_e_a_conceder', 2025, (rp[2] + rp[5]) / 1e6, MI, URL12, pgp_, 'derivado: despesas de pensoes concedidas + a conceder. ' + npe)
A.add('pensoes militares', 'vp_contribuicoes_futuras', 2025, (rp[3] + rp[6]) / 1e6, MI, URL12, pgp_, 'derivado: receitas de pensoes concedidas + a conceder. ' + npe)
A.add('pensoes militares', 'deficit_atuarial', 2025, rp[0] / 1e6, MI, URL12, pgp_, 'reserva matematica. ' + npe)
A.add('militares (SPSMFA)', 'deficit_atuarial', 2025, (ri[0] + rp[0]) / 1e6, MI, URL12, 'PLDO 2027, Anexo IV.12, itens 7.3 e 8.3', 'derivado: inativos + pensoes')
for reg in ('militares (SPSMFA)', 'FCDF'):
    v = A.get(reg, 'deficit_atuarial', 2025)[0]
    A.add(reg, 'deficit_atuarial_pct_pib', 2025, v / PIB[2025] * 100, '% do PIB 2025', URL_PIB, 'deficit atuarial / PIB 2025', 'derivado', nd=2)
# RGPS: so projecao, sem valor presente
D10 = pymupdf.open(P('pldo', 'pldo2027-anexo-iv-10-rgps.pdf'))
T10 = [pg.get_text() for pg in D10]
pg10 = [i for i, t in enumerate(T10) if 'a arrecadação previdenciária estimada para 2026' in t][0]
j10 = ' '.join(T10[pg10].split())
m = re.search(r'estimada para 2026 é de R\$ ([\d.]+) milhões, o que corresponde a ([\d,]+)% do PIB\. Para 2100, as estimativas apontam para uma arrecadação de R\$ ([\d.]+) milhões, ou seja, ([\d,]+)% do PIB', j10)
m2 = re.search(r'estimada em R\$ ([\d.]+) milhões \(([\d,]+)% do PIB\) em 2026.*?atingindo, em 2100, R\$ ([\d.]+) milhões \(([\d,]+)% do PIB\)', j10)
m3 = re.search(r'necessidade de financiamento do RGPS da ordem de R\$ ([\d.]+) milhões em (\d{4}) \(([\d,]+)% do PIB\), a qual deve atingir R\$ ([\d.]+) milhões \(([\d,]+)% do PIB\)', j10)
URL10 = URL['pldo/pldo2027-anexo-iv-10-rgps.pdf']
p10 = 'PLDO 2027, Anexo IV.10, secao 5 (Tabela 5.2 descrita no texto), pagina %d do PDF' % (pg10 + 1)
n10 = 'projecao, nao valor presente: o anexo do RGPS nao calcula passivo atuarial (regime de reparticao, massa aberta). Horizonte 2026 a 2100'
assert abs(iN(m2.group(1)) - iN(m.group(1)) - iN(m3.group(1))) < 1
A.add('RGPS', 'receita_projetada', 2026, iN(m.group(1)), MI, URL10, p10, n10 + '; %s%% do PIB' % m.group(2))
A.add('RGPS', 'despesa_projetada', 2026, iN(m2.group(1)), MI, URL10, p10, n10 + '; %s%% do PIB' % m2.group(2))
A.add('RGPS', 'necessidade_financiamento_projetada', 2026, iN(m3.group(1)), MI, URL10, p10,
      n10 + '; %s%% do PIB. O texto diz "em %s", mas o valor e despesa 2026 menos receita 2026' % (m3.group(3), m3.group(2)))
A.add('RGPS', 'necessidade_financiamento_projetada_pct_pib', 2026, num(m3.group(3)), '% do PIB', URL10, p10, n10, nd=2)
A.add('RGPS', 'receita_projetada_pct_pib', 2100, num(m.group(4)), '% do PIB', URL10, p10, n10, nd=2)
A.add('RGPS', 'despesa_projetada_pct_pib', 2100, num(m2.group(4)), '% do PIB', URL10, p10, n10, nd=2)
A.add('RGPS', 'necessidade_financiamento_projetada_pct_pib', 2100, num(m3.group(5)), '% do PIB', URL10, p10, n10, nd=2)
A.add('RGPS', 'vp_beneficios_menos_contribuicoes', 2025, None, MI, URL10, 'PLDO 2027, Anexo IV.10', 'o anexo nao publica valor presente do RGPS; o BGU tambem nao provisiona o RGPS')
# BGU 2025 (nota do Tesouro)
tb = open(P('bgu', 'noticia-bgu2025.html'), encoding='utf-8').read()
tb = ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'<script.*?</script>', '', tb, flags=re.S))).split())
URLB = URL['bgu/noticia-bgu2025.html']
mb = re.search(r'provisões matemáticas previdenciárias da União, que representam ([\d,]+)% do total, ou seja, aproximadamente R\$ ([\d,]+) trilhão', tb)
mb2 = re.search(r'Forças Armadas, por sua vez, somaram R\$ ([\d,]+) bilhões no encerramento do ano, representando ([\d,]+) ?% do valor total', tb)
mb3 = re.search(r'encerraram 2025 em ([\d,]+) trilhões', tb)
A.add('RPPS civil Uniao (BGU)', 'provisao_matematica_previdenciaria', 2025, num(mb.group(2)) * 1e6, MI, URLB, 'Tesouro Nacional, nota de publicacao do BGU 2025 (17/04/2026), secao Provisoes',
      'saldo contabil em 31/12/2025, %s%% das provisoes da Uniao (R$ %s tri). Reune principalmente beneficios concedidos e a conceder do RPPS; valor arredondado no texto. Difere do deficit atuarial do PLDO por abranger outros itens' % (mb.group(1), mb3.group(1)))
A.add('militares (BGU)', 'provisao_sistema_protecao_social_militares', 2025, num(mb2.group(1)) * 1e3, MI, URLB, 'Tesouro Nacional, nota de publicacao do BGU 2025, secao Provisoes',
      '%s%% das provisoes. Inclui SPSMFA (inativos), pensoes de militares, pensoes especiais e anistiados politicos militares' % mb2.group(2))
A.grava()

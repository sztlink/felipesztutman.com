#!/usr/bin/env bash
# Baixa o RREO do 6o bimestre da Uniao (id_ente=1) na API do Siconfi, todas as paginas, 2015 a 2025.
# Uso: bash brutos/U/baixa_siconfi.sh   (grava em brutos/U/siconfi/rreo-AAAA-pN.json)
set -euo pipefail
D="$(cd "$(dirname "$0")" && pwd)/siconfi"; mkdir -p "$D"
for y in $(seq 2015 2025); do
  off=0; n=0
  while :; do
    f="$D/rreo-$y-p$n.json"
    curl -s -m 120 "https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio=$y&nr_periodo=6&co_tipo_demonstrativo=RREO&id_ente=1&offset=$off" -o "$f"
    more=$(python3 -I -c "import json,sys;print(json.load(open(sys.argv[1]))['hasMore'])" "$f")
    [ "$more" = "True" ] || break
    off=$((off+5000)); n=$((n+1))
  done
done

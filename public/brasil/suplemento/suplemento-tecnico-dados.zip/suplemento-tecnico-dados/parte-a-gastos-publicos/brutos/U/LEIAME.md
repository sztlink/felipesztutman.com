# Frente U: custo liquido dos regimes de previdencia da Uniao

Levantamento de 19/10/2026. So fonte primaria oficial (STN, MPS, Ministerio da Defesa via PLDO). Nada exigiu login nem navegador.

Regenerar, de fora desta pasta:

    bash brutos/U/baixa_siconfi.sh        # opcional: rebaixa o RREO do Siconfi (2015 a 2025)
    python3 -I brutos/U/build_U.py

O script e idempotente (duas rodadas dao os mesmos dois CSV byte a byte) e grava na raiz `gastos-publicos/`:

| CSV | conteudo |
|---|---|
| `U-previdencia-resultado.csv` | por regime e ano, 2008 a 2025: receita (total, segurados, patronal da Uniao), despesa, resultado em R$ mi e % do PIB, resultado sem a patronal (RPPS civil), beneficiarios, contribuintes ativos, resultado por beneficiario; RGPS com compensacao das desoneracoes e COMPREV |
| `U-previdencia-atuarial.csv` | passivo atuarial com data focal 31/12/2025 (PLDO 2027): VP dos beneficios, VP das contribuicoes, deficit, taxa, horizonte; RGPS so projecao; provisoes do BGU 2025 |

Colunas: `regime, serie, ano, presidente, valor, unidade, fonte_url, pagina_ou_tabela, nota`. Valor vazio com nota "nao encontrado". Linha calculada diz "derivado" na nota. Presidente pelo ano (2016 = Dilma/Temer). PIB: `pib_rs_mi` de `K-primario-recorrente.csv`.

Regimes: `RGPS`, `RGPS urbano`, `RGPS rural`, `RPPS civil Uniao`, `militares (SPSMFA)` (com o detalhe `militares inativos` e `pensoes militares`), `FCDF`.

## Fontes (URL e data em `downloads.tsv`)

| arquivo | fonte | uso |
|---|---|---|
| `siconfi/rreo-AAAA-pN.json` | API do Siconfi, RREO da Uniao, 6o bimestre, 2015 a 2025 | anexo 4: RPPS civil, militares, FCDF, COMPREV do RGPS |
| `../D/seriehistoricaago26.xlsx` (so leitura) | RTN serie historica ago/2026, tab. 2.2 | RGPS total, urbano e rural, compensacao das desoneracoes |
| `../D/RREO_dez2025_republ.pdf` (so leitura) | RREO dez/2025 republicado | FCDF 2025 (ver abaixo) |
| `../P/prev/2-uniao.zip` (so leitura) | AEPS 2024, suplemento RPPS (RREO compilado pelo MPS) | RPPS civil e militares 2008 a 2014 |
| `../P/prev/beps122025.pdf` (so leitura) | BEPS dez/2025, tab. 15 | beneficios RGPS urbano e rural em dez/2025 |
| `../../P-previdencia-regimes.csv` | frente P (BEPS quadro 14, AEPS) | beneficios RGPS 2006 a 2025, segurados RPPS civil 2013 a 2024, militares 2020 a 2024 |
| `aeps/aeps2024-32-1.html` | AEPS 2024, tab. 32.1 | contribuintes do RGPS 2022 a 2024 |
| `../P/prev/pldo2027-anexo-iv-11-*.pdf` | PLDO 2027, Anexo IV.11 (RPPS da Uniao, com Anexo XV do FCDF) | passivo atuarial civil e FCDF, segurados jul/2025 |
| `../P/prev/pldo2027-anexo-iv-12-*.pdf` | PLDO 2027, Anexo IV.12 vol. 1 (militares) | reservas matematicas, quantidades mai/2025 |
| `pldo/pldo2027-anexo-iv-10-rgps.pdf` | PLDO 2027, Anexo IV.10 (RGPS) | projecao 2026 e 2100 |
| `pldo/pldo2027-anexo-v-riscos-fiscais.pdf` | PLDO 2027, Anexo V | so confere que os riscos previdenciarios remetem aos anexos IV (tab. 1) |
| `bgu/noticia-bgu2025.html` | Tesouro, nota de publicacao do BGU 2025 (17/04/2026) | provisoes em 31/12/2025 |

## Como o resultado e montado

- **RGPS**: arrecadacao liquida menos beneficios previdenciarios (RTN, caixa, inclui sentencas e precatorios). E o conceito do resultado do RGPS publicado pelo Tesouro e pelo MPS (BEPS da R$ -317,2 bi em 2025, igual). O RREO anexo 4 da numero parecido (R$ -321,0 bi empenhado em 2025) porque soma COMPREV e outras despesas.
- **RPPS civil**: RREO anexo 4, receita (servidores ativos, aposentados, pensionistas e patronal da Uniao) menos despesa empenhada (no 6o bimestre o RREO fecha pela empenhada). 2015 e 2016: o anexo juntava civis e militares; civil = total menos a parcela militar, e a despesa civil leva "outras despesas previdenciarias" (FCDF, extinto IPC, sentencas). 2008 a 2014: AEPS 2024, que so traz aposentadorias e pensoes (o resto ia para "Demais"); por isso ha um degrau de R$ 9 bi de 2014 para 2015 que nao e despesa nova.
- **Militares (SPSMFA)**: inativos (reforma e reserva) + pensoes, contra a contribuicao para pensao militar. 2018: o quadro de inativos so aparece no RREO de 2019 (coluna do ano anterior). 2008 a 2014: AEPS, que repete o mesmo valor nas duas linhas (agregado).
- **FCDF**: quadro proprio do anexo 4 desde 2019. 2015 a 2018 esta dentro do RPPS civil (2017 e 2018 explicitamente, segundo a nota da AEPS). Em 2019 a 2021 o Siconfi nao separa patronal; a receita parece so a dos segurados.

### FCDF 2025: unico numero transcrito

O RREO de dez/2025 foi republicado com o demonstrativo do FCDF refeito "por atualizacao de metodologia, incluindo acoes de governo novas que substituiram outras". A despesa empenhada passou de R$ 5,13 bi (versao original, a que esta no Siconfi) para R$ 10,42 bi (republicada; 2024 foi R$ 9,55 bi, entao a original subestimava). A camada de texto desse PDF e ilegivel (fonte sem mapa de caracteres), entao os seis numeros do quadro (pagina 20 do relatorio, 15 do PDF) foram transcritos da imagem e estao no dicionario `FCDF_2025_REPUBL` do script. Conferencia: a receita republicada (R$ 1.144.579 mil) e igual a do Siconfi.

## Ressalvas

1. **Patronal da Uniao.** A contribuicao patronal ao RPPS civil e ao FCDF e intraorcamentaria: o Tesouro paga a si mesmo. O RREO a conta como receita, o que reduz o deficit no papel. A serie `resultado_sem_patronal` tira essa receita e e o custo liquido para o Tesouro: em 2025, R$ -86,4 bi (0,68% do PIB) contra R$ -62,6 bi com a patronal. No RGPS a parte patronal e do empregador privado e entra de verdade; a patronal da Uniao sobre seus celetistas e terceirizados nao e separavel aqui. No RTN, a linha "Pessoal e encargos" ja inclui a despesa patronal e a receita intra se anula na consolidacao.
2. **Militares nao tem contribuicao patronal.** Inativos nao contribuem para nada e sao pagos inteiros pelo Tesouro (Lei 6.880/1980, art. 53-A); a pensao militar tem contribuicao dos militares, inativos e pensionistas (10,5%, mais 1,5% opcional, mais 3% das filhas vitalicias), sem patronal. O MPS e o Tesouro anotam que inatividade militar nao e despesa previdenciaria em sentido estrito (nota 2 do RREO). O salto da receita em 2020 (R$ 2,7 bi para R$ 6,7 bi) e da Lei 13.954/2019, que estendeu a contribuicao aos inativos e pensionistas e subiu a aliquota.
3. **EC 103/2019.** A reforma vale para RGPS e RPPS civil da Uniao desde nov/2019, com regras de transicao (pedagio de 50% e 100%, pontos, idade minima progressiva) que tornam o efeito gradual; aliquotas progressivas do servidor desde mar/2020, visivel na receita de segurados (R$ 13,8 bi em 2019, R$ 17,1 bi em 2022). As avaliacoes atuariais do PLDO 2027 ja incorporam as regras de transicao (Anexo IV.11 e Anexo XV). Militares tiveram reforma propria (Lei 13.954/2019).
4. **Compensacoes.** (a) COMPREV entre regimes (Lei 9.796/1999): o RGPS recebe dos RPPS e paga a eles; esta no RREO (`comprev_*`), nao na linha do RTN; em 2025 pagou R$ 6,7 bi e recebeu R$ 1,6 bi, a maior parte com estados e municipios. (b) Compensacao do Tesouro ao RGPS pelas desoneracoes da folha (2012 a 2022): esta dentro da arrecadacao do RTN e foi atribuida ao urbano; sem ela o deficit desses anos e maior pelo valor da serie `compensacao_desoneracao_folha`. (c) Os militares nao tem COMPREV (art. 201, par. 9-A, sem regulamentacao, segundo o Anexo IV.12).
5. **Urbano e rural.** A separacao do RTN e do MPS por metodologia propria. O rural arrecada pouco por desenho (contribuicao sobre a comercializacao e segurado especial), entao seu deficit e um subsidio de politica social mais do que desequilibrio atuarial.
6. **Beneficiarios.** RGPS conta beneficios emitidos em dezembro, nao pessoas (34,4 mi de beneficios para 30,2 mi de pessoas em dez/2024). RPPS civil: pessoas da base cadastral do PLDO (julho ate 2017, dezembro de 2018 a 2024, julho em 2025). Militares: dezembro (Ministerio da Defesa) e mai/2025 extrapolado (PLDO 2027). Resultado por beneficiario e o deficit do ano dividido por esse estoque.
7. **Passivo atuarial nao soma com o RGPS.** RPPS e militares sao avaliados como massa fechada, a valor presente; o RGPS e reparticao com massa aberta e o anexo so projeta fluxos ate 2100, sem VP. Taxas reais diferentes (civil 5,42%, FCDF 5,45% e 5,48%, militares 5,40% e 5,52%), todas pela ETTJ media do IPCA (Portaria MTP 1.467/2022). Com 4,82% (taxa do ano anterior) o deficit civil sobe 8,33%. O BGU (R$ 1,580 tri de provisao matematica previdenciaria, R$ 886 bi de militares) nao e igual ao PLDO: inclui outros itens e o texto do Tesouro so da valores arredondados.

## Nao encontrado

- Contribuintes do RGPS antes de 2022 e em 2025 (AEPS 2024 so tem 2022 a 2024; AEPS 2025 ainda nao saiu). Edicoes antigas do AEPS nao estao na mesma arvore do gov.br.
- Beneficios do RGPS por clientela antes de dez/2025 (o quadro historico do BEPS nao separa urbano e rural do estoque).
- Patronal do RPPS civil antes de 2015 (AEPS so da o total) e patronal do FCDF em 2019 a 2021.
- Beneficiarios e ativos do FCDF antes de 2025, e militares antes de 2020.
- Valor presente atuarial do RGPS (nao publicado).
- BGU 2025 completo (notas explicativas, tabelas de provisao por tipo): o portal Tesouro Transparente pede login ou monta a pagina em JS; ficou so a nota oficial com valores arredondados.
- URL de origem do `RREO_dez2025_republ.pdf` (copia da frente D, que nao registrou a URL).
- A Tabela 7 do Anexo IV.11 (deficit atuarial 2023 a 2025) e imagem; so o valor de 2024 (R$ 1,56 tri, arredondado) veio do texto.

# Frente S2, dívida sem queda de juros

Feita em 24/10/2026. Pedido aberto desde a v12.6 ("dívida sem supor queda de juros"), pode sair contra qualquer lado.

## Motor
`build_S2.py` não edita nem copia `brutos/S/build_S.py`. Executa o trecho de preparação dele (até a lista `CEN`, que só lê
entradas e define `roda()`) num namespace próprio, depois a lista `CEN`, e as definições do canal fiscal, do multiplicador e da
âncora alternativa, todas sem gravação (o script confere que não há `'w'` nesses trechos). O sha256 do build_S.py vai na nota do CSV
(70d71280fe3c99ee no dia). Os nove cenários existentes são refeitos e conferidos contra `S-cenarios-divida.csv` com igualdade exata.

## Cenários novos (S2-divida-sem-queda-juros.csv)
- Selic vigente: 13,75% desde 17/09/2026 (Copom 281), pelo histórico do BCB (`fontes/bcb_historicotaxasjuros_20261024.json`).
  2026 = média dos meses observados em `N-juro-real-mensal.csv` e o resto do ano em 13,75%.
- S2a. Selic parada em 13,75% de 2027 a 2030, primário do PLDO antes das exclusões, IPCA e PIB do Focus de 09/10/2026, taxas de
  mercado de 10 anos no nível de out/2026 como no cenário 2. Juro real da Selic ex ante de 9,1% (2027) a 9,9% (2029 e 2030).
- S2b. O juro real da Selic parado em 9,06% (13,75% contra o IPCA do Focus de 2027); a Selic nominal cai só com a inflação.
- S2c. Como o S2a, com o primário de 2025 (-0,5% do PIB) em todos os anos.
- Colunas novas: `selic_real_ex_ante` (Selic média contra o IPCA do ano), `juro_implicito_real` (custo implícito da DBGG contra
  o IPCA) e `dif_divida_vs_cenario2_pp`.

Resultado, DBGG de 2030: cenário 2 (Focus, que leva a Selic a 10%) 98,3% do PIB; S2a 103,7%; S2b 102,6%; S2c 108,8%; o estresse
existente (Selic 2 pontos acima do Focus, primário de 2025) 109,3%. Classe A como aritmética condicional, nunca previsão.

## Sensibilidade (S2-sensibilidade-2030.csv)
Uma alavanca por linha contra uma base só, o cenário 2 (98,31% em 2030, conferido contra o CSV publicado). Cada linha é
recalculada com `roda()` e, onde já existe número publicado, conferida contra ele (S-sensibilidade-juros, S-canal-fiscal,
S-cenarios-divida). Macro do PLDO -11,47 ponto; deflator +1 -3,93; crescimento real +1 -3,93 e -1 +4,13 (no motor as duas entram
só pelo crescimento nominal, por isso deflator +1 e crescimento +1 dão o mesmo número); Selic -1 -1,93; Selic e mercado -1 -2,87;
só mercado -1 -0,96; prêmio -1,5 (definição do cenário 3, Selic e mercado 1,5 abaixo) -4,27; ajuste pela receita sozinho -3,58;
ajuste pela despesa sozinho -3,67; âncora de mercado de set/2026 +0,92; canal fiscal central (26 pb) -0,18.
- Pulada: multiplicador de 1,2. No build_S.py ele só age sobre o ajuste extra dos cenários 4 e 4b; sobre a base do cenário 2 não
  há ajuste extra e o efeito é zero por construção. Não existe como alavanca isolada.

## Como sai
A Selic é decisão do Copom, não do Executivo. O S2 mostra quanto da trajetória de 2030 depende da queda de juros que o Focus
espera, sob qualquer governo: com o primário do PLDO, a dívida de 2030 fica 5,4 pontos do PIB acima do cenário 2 sem essa queda.
Não atribui nada a governo nem a candidato. O primário do PLDO é do Governo Central e a dívida é do governo geral, sem ajuste
fluxo-estoque, como no build_S.py.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/S2/build_S2.py
```

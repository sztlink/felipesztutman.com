#!/usr/bin/env python3
# Frente S2. Divida bruta (DBGG) de 2026 a 2030 sem queda de juros: Selic parada no nivel de hoje ate 2030.
# Usa o mesmo motor de brutos/S/build_S.py sem editar o arquivo: executa o trecho de preparacao dele (ate a lista CEN, que nao
# grava nada) num namespace proprio e chama a funcao roda() de la. O hash do build_S.py usado vai na nota do CSV.
# Cenario condicional, nao previsao. Sai contra qualquer governo: a Selic e decisao do Copom, nao do Executivo.
# Entradas: brutos/S/build_S.py e as entradas dele; brutos/S2/fontes/bcb_historicotaxasjuros_20261024.json (meta Selic vigente).
# Saida: S2-divida-sem-queda-juros.csv na raiz do dossie.
import csv, hashlib, json, os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..', '..')
BS = os.path.join(RAIZ, 'brutos', 'S', 'build_S.py')
src = open(BS, encoding='utf-8').read()
corte = src.index('\nCEN = [')
ns = {'__file__': BS, '__name__': 'motor_S'}
exec(compile(src[:corte], BS, 'exec'), ns)  # so leitura das entradas e definicao de roda(); nenhuma escrita antes deste ponto
assert "'w'" not in src[:corte], 'o trecho executado nao pode gravar arquivo'
roda, macro_focus, pj, FO, NM, p25 = ns['roda'], ns['macro_focus'], ns['pj'], ns['FO'], ns['NM'], ns['p25']
SHA_S = hashlib.sha256(src.encode('utf-8')).hexdigest()[:16]

# meta Selic vigente (BCB, historico das reunioes do Copom)
H = json.load(open(os.path.join(AQUI, 'fontes', 'bcb_historicotaxasjuros_20261024.json'), encoding='utf-8'))['conteudo']
vig = [r for r in H if r['DataFimVigencia'] is None]
assert len(vig) == 1
SEL = float(vig[0]['MetaSelic']); REUN = int(vig[0]['NumeroReuniaoCopom']); DESDE = vig[0]['DataInicioVigencia'][:10]
URL_SEL = 'https://www.bcb.gov.br/api/servico/sitebcb/historicotaxasjuros'

# 2026: meses observados (N-juro-real-mensal) e o resto do ano na meta vigente; 2027 a 2030: a meta vigente parada
obs = [NM[f'2026-{j:02d}'] for j in range(1, 13) if f'2026-{j:02d}' in NM]
s26 = (sum(obs) + (12 - len(obs)) * SEL) / 12
def macro_parada(a):
  s, pi, g = macro_focus(a)
  return (s26 if a == 2026 else SEL, pi, g)
# variante: juro real da Selic parado no nivel de hoje (Selic vigente contra o IPCA do Focus de 2027, o ano a frente)
RR = (1 + SEL / 100) / (1 + FO[('IPCA', 2027)] / 100) - 1
def macro_real_parado(a):
  s, pi, g = macro_focus(a)
  return (s26 if a == 2026 else 100 * ((1 + RR) * (1 + pi / 100) - 1), pi, g)

virg = lambda v, n: f'{v:.{n}f}'.replace('.', ',')
NOVOS = [
  ('S2a. Selic parada, primário do PLDO', pj, 0.0, f'Selic em {virg(SEL, 2)}% (meta vigente desde {DESDE}) de 2027 a 2030; primário do PLDO 2027 antes das exclusões; IPCA e PIB do Focus; taxas de mercado no nível de hoje, como no cenário 2', macro_parada, 0.0),
  ('S2b. Selic real parada, primário do PLDO', pj, 0.0, f'juro real da Selic parado em {virg(100 * RR, 2)}% (Selic vigente contra o IPCA do Focus de 2027); Selic nominal cai só com a inflação do Focus; resto como no S2a', macro_real_parado, 0.0),
  ('S2c. Selic parada, primário de 2025', lambda a: p25, 0.0, f'como o S2a, com o primário de 2025 ({virg(p25, 1)}% do PIB) em todos os anos', macro_parada, 0.0),
]
# cenarios que ja existem, refeitos pelo mesmo motor e conferidos contra S-cenarios-divida.csv
EXIST = {r['cenario'] for r in csv.DictReader(open(os.path.join(RAIZ, 'S-cenarios-divida.csv'), encoding='utf-8'))}
CSV_S = {(r['cenario'], int(r['ano'])): r for r in csv.DictReader(open(os.path.join(RAIZ, 'S-cenarios-divida.csv'), encoding='utf-8'))}
src_cen = src[corte:src.index('\nlinhas = [l for c in CEN')]
exec(compile(src_cen, BS, 'exec'), ns)
linhas = []
for c in ns['CEN']:
  for l in roda(*c):
    ref = CSV_S[(l['cenario'], l['ano'])]
    assert abs(float(ref['divida_pct_pib']) - l['divida_pct_pib']) < 1e-9, (l['cenario'], l['ano'])  # motor reproduz o CSV publicado
    linhas.append({**l, 'tipo': 'existente (S-cenarios-divida.csv)'})
for c in NOVOS:
  for l in roda(*c): linhas.append({**l, 'tipo': 'novo (S2)'})
assert {l['cenario'] for l in linhas if l['tipo'].startswith('existente')} == EXIST
for l in linhas:
  ipca = l['ipca']
  l['selic_real_ex_ante'] = round(100 * ((1 + l['selic_media'] / 100) / (1 + ipca / 100) - 1), 2)
  l['juro_implicito_real'] = round(100 * ((1 + l['juro_implicito'] / 100) / (1 + ipca / 100) - 1), 2)
B = {l['ano']: l for l in linhas if l['cenario'] == '2. Primário do PLDO'}
for l in linhas:
  l['dif_divida_vs_cenario2_pp'] = round(l['divida_pct_pib'] - B[l['ano']]['divida_pct_pib'], 2)
nota = (f'motor de brutos/S/build_S.py (sha256 {SHA_S}), sem alteração; Selic vigente {SEL}% desde {DESDE} (Copom {REUN}); 2026 = média dos meses observados '
        f'({len(obs)} meses em N-juro-real-mensal.csv) e o resto na meta vigente: {round(s26, 3)}; Focus de 09/10/2026 para IPCA e PIB; taxas de mercado de 10 anos '
        f'(prefixado {ns["pre10"]}, real {ns["real10"]}, {ns["mes_mkt"]}) mantidas em todos os cenários; selic_real_ex_ante = Selic média contra o IPCA do mesmo ano; '
        'juro_implicito_real = custo médio implícito da DBGG contra o IPCA; sem ajuste fluxo-estoque; primário do Governo Central contra dívida do governo geral; '
        'cenário condicional, não previsão; não atribui a trajetória a governo nenhum')
FONTE = f'BCB {URL_SEL} (consulta 24/10/2026); as fontes de S-cenarios-divida.csv'
cab = ['tipo', 'cenario', 'ano', 'selic_media', 'selic_real_ex_ante', 'ipca', 'juro_implicito', 'juro_implicito_real', 'cresc_nominal', 'primario_pct_pib', 'juros_pct_pib',
       'divida_pct_pib', 'dif_divida_vs_cenario2_pp', 'primario_estabiliza', 'descricao', 'fonte', 'nota']
with open(os.path.join(RAIZ, 'S2-divida-sem-queda-juros.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.DictWriter(f, fieldnames=cab); w.writeheader()
  for l in linhas: w.writerow({**{k: l[k] for k in cab if k in l}, 'fonte': FONTE, 'nota': nota})
print('S2 ok', [(l['cenario'], l['divida_pct_pib'], l['juros_pct_pib'], l['selic_media']) for l in linhas if l['ano'] == 2030])

# ---------- S2-sensibilidade-2030.csv: uma alavanca por linha contra uma base so (cenario 2) ----------
# Definicoes do canal fiscal e do multiplicador: o trecho de build_S.py entre a leitura de brutos/Y/LEIAME.md e o laco do canal
# (so leitura e definicao de funcoes), executado no mesmo namespace.
i0 = src.index("ly = open(os.path.join(RAIZ, 'brutos', 'Y', 'LEIAME.md')"); i1 = src.index('\ncanal_l = []')
assert "'w'" not in src[i0:i1]
exec(compile(src[i0:i1], BS, 'exec'), ns)
i0 = src.index("mm = re.search(r'Faixa do multiplicador"); i1 = src.index('\nmult_l = []')
exec(compile(src[i0:i1], BS, 'exec'), ns)
forte, desp, macro_pldo, canal, FAIXA, MULT = ns['forte'], ns['desp'], ns['macro_pldo'], ns['canal'], ns['FAIXA'], ns['MULT']
d30 = lambda *a, **k: roda(*a, **k)[-1]['divida_pct_pib']
BASE = d30('base', pj, 0.0, '', macro_focus, 0.0)
assert BASE == float(CSV_S[('2. Primário do PLDO', 2030)]['divida_pct_pib']), 'a base nao reproduz S-cenarios-divida.csv'
# ancora de setembro: o mesmo "ultimo mes completo" que build_S.py usa na sensibilidade da ancora
lp = next(l for l in src.splitlines() if l.startswith('parc = [r for r in NML'))  # mesma definicao de build_S.py
exec(compile(lp, BS, 'exec'), ns)
parc = ns['parc']; _p, _r = ns['pre10'], ns['real10']
ns['pre10'], ns['real10'] = float(parc['prefixado_10a']), float(parc['juro_real_10a'])
ANC = d30('alt', pj, 0.0, '', macro_focus, 0.0)
ns['pre10'], ns['real10'] = _p, _r
assert d30('base', pj, 0.0, '', macro_focus, 0.0) == BASE
cc = FAIXA['Central']
ALV = [
  ('macro do PLDO', 'Selic, IPCA e PIB nominal da grade do PLDO 2027 no lugar do Focus, primário do PLDO', d30('a', pj, 0.0, '', macro_pldo, 0.0), 'build_S.py macro_pldo (cenário 6)'),
  ('deflator +1', 'deflator do PIB 1 ponto acima do IPCA desde 2027', d30('a', pj, 0.0, '', macro_focus, 1.0), 'build_S.py cenário 2b'),
  ('crescimento real +1', 'PIB real 1 ponto acima do Focus por ano desde 2027', d30('a', pj, 0.0, '', macro_focus, 0.0, dg=1.0), 'build_S.py, S-sensibilidade-juros.csv (crescimento real)'),
  ('crescimento real -1', 'PIB real 1 ponto abaixo do Focus por ano desde 2027', d30('a', pj, 0.0, '', macro_focus, 0.0, dg=-1.0), 'build_S.py, S-sensibilidade-juros.csv (crescimento real)'),
  ('Selic -1', 'só a Selic 1 ponto abaixo do Focus desde 2027, taxas de mercado paradas', d30('a', pj, -1.0, '', macro_focus, 0.0, ds_m=0.0), 'build_S.py, S-sensibilidade-juros.csv (selic)'),
  ('Selic e mercado -1', 'Selic e taxas de mercado (prefixado e NTN-B de 10 anos) 1 ponto abaixo desde 2027', d30('a', pj, -1.0, '', macro_focus, 0.0), 'build_S.py, S-sensibilidade-juros.csv (curva)'),
  ('só mercado -1', 'só as taxas de mercado 1 ponto abaixo desde 2027, Selic do Focus', d30('a', pj, 0.0, '', macro_focus, 0.0, ds_m=-1.0), 'build_S.py, S-sensibilidade-juros.csv (premio)'),
  ('prêmio -1,5', 'Selic e taxas de mercado 1,5 ponto abaixo desde 2027, a definição do cenário 3 ("PLDO e prêmio menor")', d30('a', pj, -1.5, '', macro_focus, 0.0), 'build_S.py cenário 3'),
  ('ajuste pela receita', 'receita extra igual a 1/5 dos gastos tributários de 2024 por ano (metade em 2027), sem a queda de juros do cenário 4', d30('a', forte, 0.0, '', macro_focus, 0.0), 'build_S.py forte (primário do cenário 4)'),
  ('ajuste pela despesa', 'despesa primária crescendo o piso do arcabouço em vez do teto, sem a queda de juros do cenário 4b', d30('a', desp, 0.0, '', macro_focus, 0.0), 'build_S.py desp (primário do cenário 4b)'),
  ('âncora de mercado de setembro', f'taxas de mercado de 10 anos do último mês completo ({parc["mes"]}) no lugar do mês mais recente', ANC, 'build_S.py, ancora_alt (nota de S-cenarios-divida.csv)'),
  ('canal fiscal central', f'canal fiscal de {int(cc)} pb por ponto do PIB de primário esperado, só nas taxas de mercado, Selic do Focus', d30('a', pj, 0.0, '', macro_focus, 0.0, ds_m=0.0, dm_fun=canal(pj, cc)), 'build_S.py canal, S-canal-fiscal.csv'),
]
# conferencia contra os CSV que build_S.py ja publicou
SJ = {(r['choque'], float(r['reducao_pp'])): float(r['divida_2030']) for r in csv.DictReader(open(os.path.join(RAIZ, 'S-sensibilidade-juros.csv'), encoding='utf-8'))}
CF = {r['cenario']: float(r['divida_pct_pib']) for r in csv.DictReader(open(os.path.join(RAIZ, 'S-canal-fiscal.csv'), encoding='utf-8')) if r['ano'] == '2030'}
A = {a[0]: a[2] for a in ALV}
assert A['Selic -1'] == SJ[('selic', 1.0)] and A['Selic e mercado -1'] == SJ[('curva', 1.0)] and A['só mercado -1'] == SJ[('premio', 1.0)]
assert A['crescimento real +1'] == SJ[('crescimento real', 1.0)] and A['crescimento real -1'] == SJ[('crescimento real', -1.0)]
assert A['macro do PLDO'] == float(CSV_S[('6. Grade do PLDO', 2030)]['divida_pct_pib']) and A['deflator +1'] == float(CSV_S[('2b. O mesmo, deflator maior', 2030)]['divida_pct_pib'])
assert A['prêmio -1,5'] == float(CSV_S[('3. PLDO e prêmio menor', 2030)]['divida_pct_pib'])
assert A['canal fiscal central'] == CF[f'2. Primário do PLDO | canal fiscal central ({int(cc)} pb)']
assert ANC == float(re.search(r'ancora_alt_divida_2030_cenario2=([\d.]+)', CSV_S[('2. Primário do PLDO', 2030)]['nota']).group(1))
# multiplicador de 1,2: em build_S.py ele so age sobre o ajuste extra dos cenarios 4 e 4b (crescimento menos m vezes o ajuste do ano);
# sobre a base do cenario 2 nao ha ajuste extra e o efeito e zero por construcao. Nao vira alavanca isolada; fica fora do CSV.
assert 1.2 in MULT
with open(os.path.join(RAIZ, 'S2-sensibilidade-2030.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f); w.writerow(['alavanca', 'descricao', 'divida_2030_base', 'divida_2030_alavanca', 'efeito_pp', 'origem_parametro'])
  for nm, ds_, v, org in ALV: w.writerow([nm, ds_, BASE, v, round(v - BASE, 2), org])
print('S2 sens', BASE, [(a[0], a[2], round(a[2] - BASE, 2)) for a in ALV])

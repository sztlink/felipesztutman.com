#!/usr/bin/env python3
"""Frente V: reforma tributaria do consumo (EC 132/2023, LC 214/2025, LC 227/2026).

Le apenas arquivos ja baixados em brutos/V/* (e a planilha DGT PLOA 2026 de brutos/E/) e grava,
na raiz gastos-publicos/:
  V-reforma-consumo.csv
Colunas: tema, item, ano, valor, unidade, fonte_url, pagina_ou_artigo, nota.

Nenhum numero digitado a mao. Cada linha nasce de uma expressao regular aplicada ao texto da
fonte (lei no Planalto, nota da SERT/MF, DOU, Ipea, RFB) ou de uma celula de planilha. Se o
texto nao bater, o script para com erro. A nota de cada linha termina com o trecho literal
casado (entre aspas). Linha calculada pelo script comeca a nota com "derivado:". Valor vazio
com "nao encontrado" marca lacuna.

Texto do Planalto: paragrafos com estilo line-through ou <strike> (redacao revogada) sao
descartados, de modo que so a redacao vigente entra.

Rodar de fora das pastas de dados:  python3 -I brutos/V/build_V.py
Dependencias: openpyxl (~/.local/lib/python3.12/site-packages) e pymupdf (~/.local/lib/pdftools).
"""
import csv
import html
import os
import re
import sys
import warnings

warnings.filterwarnings('ignore')
HOME = os.path.expanduser('~')
for p in [os.path.join(HOME, '.local/lib/python3.12/site-packages'),
          os.path.join(HOME, '.local/lib/pdftools')]:
    if os.path.isdir(p) and p not in sys.path:
        sys.path.append(p)
import openpyxl  # noqa: E402
import pymupdf  # noqa: E402

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
P = lambda *a: os.path.normpath(os.path.join(AQUI, *a))
SAIDA = os.path.join(RAIZ, 'V-reforma-consumo.csv')
COLS = ['tema', 'item', 'ano', 'valor', 'unidade', 'fonte_url', 'pagina_ou_artigo', 'nota']

FONTE = {}
with open(P('downloads.tsv'), encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        FONTE[r['arquivo']] = r['url_oficial']

# ---------------------------------------------------------------- leitura das fontes
_cache = {}


def planalto(arq):
    """Texto vigente de uma norma do Planalto, um paragrafo por linha."""
    if arq in _cache:
        return _cache[arq]
    b = open(P(arq), 'rb').read().decode('cp1252', errors='replace')
    b = re.sub(r'(?is)<(script|style)\b.*?</\1>', '', b)
    b = re.sub(r'(?is)<strike\b.*?</strike>', '', b)
    b = re.sub(r'(?is)<del\b.*?</del>', '', b)
    out = []
    for p in re.split(r'(?i)<p\b', b):
        if re.search(r'(?i)line-through', p):
            continue
        p = p.split('>', 1)[1] if '>' in p else p
        t = re.sub(r'(?i)<br\s*/?>', ' ', p)
        t = re.sub(r'<[^>]*>', ' ', t)
        t = html.unescape(t)
        t = re.sub(r'[\s\xa0]+', ' ', t).strip()
        t = re.sub(r' ([.,;:)])', r'\1', t)
        if t:
            out.append(t)
    _cache[arq] = '\n'.join(out)
    return _cache[arq]


def dou(arq):
    if arq in _cache:
        return _cache[arq]
    b = open(P(arq), encoding='utf-8', errors='replace').read()
    m = re.search(r'(?s)<div class="texto-dou">(.*?)</div>\s*</div>', b)
    t = m.group(1)
    t = re.sub(r'(?i)</p>|<br\s*/?>|</td>', '\n', t)
    t = re.sub(r'<[^>]+>', ' ', t)
    t = html.unescape(t)
    t = re.sub(r'[ \t\xa0]+', ' ', t)
    t = re.sub(r'\n\s*\n+', '\n', t)
    _cache[arq] = t
    return t


def govbr(arq):
    if arq in _cache:
        return _cache[arq]
    b = open(P(arq), encoding='utf-8', errors='replace').read()
    m = re.search(r'(?s)<div id="parent-fieldname-text"[^>]*>(.*?)</div>', b)
    t = re.sub(r'<[^>]+>', ' ', m.group(1))
    t = html.unescape(re.sub(r'\s+', ' ', t))
    _cache[arq] = t
    return t


def pdf_pages(arq):
    if arq in _cache:
        return _cache[arq]
    d = pymupdf.open(P(arq))
    pags = [re.sub(r'\s+', ' ', p.get_text()).replace('­', '') for p in d]
    _cache[arq] = pags
    return pags


def achar(texto, padrao, onde):
    m = re.search(padrao, texto, re.S) or re.search(padrao, texto.replace('\n', ' '), re.S)
    if not m:  # tolera espaco ausente ou duplicado (ex.: 'caput ,' contra 'caput,')
        m = re.search(padrao.replace(' ', r'\s*'), texto, re.S)
    if not m:
        sys.exit(f'ERRO: padrao nao encontrado em {onde}: {padrao}')
    return m


def achar_pdf(arq, padrao):
    for flex in (padrao, padrao.replace(' ', r'\s*')):
        for i, pg in enumerate(pdf_pages(arq)):
            m = re.search(flex, pg, re.S)
            if m:
                return m, i + 1
    sys.exit(f'ERRO: padrao nao encontrado em {arq}: {padrao}')


def num(s):
    s = s.strip().replace('R$', '').replace(' ', '')
    if re.fullmatch(r'-?\d{1,3}(\.\d{3})+(,\d+)?', s):
        s = s.replace('.', '')
    s = s.replace(',', '.')
    return float(s)


def fmt(v):
    if isinstance(v, float):
        return f'{v:.6f}'.rstrip('0').rstrip('.')
    return v


def trecho(m, n=220):
    t = re.sub(r'\s+', ' ', m.group(0)).strip()
    if len(t) > n:
        t = t[:n].rsplit(' ', 1)[0] + ' (...)'
    return t.replace('"', "'")


linhas = []


def add(tema, item, ano, valor, unidade, arq, onde, nota, m=None):
    if m is not None:
        nota = f'{nota} Trecho: "{trecho(m)}"'
    linhas.append(dict(tema=tema, item=item, ano=ano, valor=fmt(valor), unidade=unidade,
                       fonte_url=FONTE[arq], pagina_ou_artigo=onde, nota=nota))


EC, LC214, LC227, DEC = 'leis/emc132.htm', 'leis/lcp214.htm', 'leis/lcp227.htm', 'leis/D12955.htm'
ec, lc, lc227, dec = planalto(EC), planalto(LC214), planalto(LC227), planalto(DEC)

# ---------------------------------------------------------------- 1. transicao
T = 'transicao'
m = achar(ec, r'Em 2026, o imposto previsto no art\. 156-A será cobrado à alíquota estadual de (0,1)% \(um décimo por cento\), e a contribuição prevista no art\. 195, V, ambos da Constituição Federal, será cobrada à alíquota de (0,9)%', 'EC art.125')
add(T, 'CBS, aliquota de teste', '2026', num(m.group(2)), '% do valor da operacao', EC, 'EC 132, art. 2 (ADCT art. 125, caput)',
    'Ano de teste. O valor recolhido e compensado com PIS/Cofins devidos (ADCT 125, par. 1); sem debitos suficientes, compensa com outro tributo federal ou e ressarcido em ate 60 dias (par. 2).', m)
add(T, 'IBS, aliquota de teste (estadual)', '2026', num(m.group(1)), '% do valor da operacao', EC, 'EC 132, art. 2 (ADCT art. 125, caput)',
    'Ano de teste. Nao segue vinculacoes nem reparticoes: vai integral e sucessivamente para financiar o Comite Gestor e compor o Fundo de Compensacao de Beneficios Fiscais (ADCT 125, par. 3).', m)
m = achar(lc, r'Art\. 348\..*?§ 1º Fica dispensado o recolhimento do IBS e da CBS relativo aos fatos geradores ocorridos no período indicado no caput em relação aos sujeitos passivos que cumprirem as obrigações acessórias previstas na legislação\.', 'LC art.348')
add(T, 'IBS e CBS 2026: dispensa de recolhimento', '2026', 'dispensado se cumprir obrigacoes acessorias', 'regra', LC214, 'LC 214, art. 348, par. 1',
    'Na pratica 2026 e ano de destaque em documento fiscal; quem cumpre as obrigacoes acessorias segue pagando PIS/Cofins integralmente (par. 2).', re.search(r'§ 1º Fica dispensado.*?legislação\.', m.group(0), re.S))
m = achar(lc, r'c\) não serão aplicadas em relação às operações dos contribuintes optantes pelo Simples Nacional\.', 'LC art.348 III c')
add(T, 'IBS e CBS 2026: Simples Nacional', '2026', 'fora do teste', 'regra', LC214, 'LC 214, art. 348, III, c', 'Optantes do Simples nao aplicam as aliquotas de teste em 2026.', m)
rfb = govbr('rfb/destaque-cbs-2026-10-09.html')
m = achar(rfb, r'emitiram ([\d,]+) bilhões de documentos fiscais com destaque da CBS e ([\d,]+) bilhão sem o destaque', 'RFB destaque')
add(T, 'Documentos fiscais com destaque da CBS (30 dias ate 07/10/2026)', '2026', num(m.group(1)), 'bilhoes de documentos', 'rfb/destaque-cbs-2026-10-09.html', 'RFB, noticia de 09/10/2026, painel ROC',
    f'Empresas obrigadas (Simples fora). Sem destaque no mesmo periodo: {m.group(2)} bilhao. Dado observado, nao estimativa.', m)
m = achar(ec, r'Art\. 126\. A partir de 2027: I - serão cobrados: a\) a contribuição prevista no art\. 195, V, da Constituição Federal; b\) o imposto previsto no art\. 153, VIII, da Constituição Federal; II - serão extintas as contribuições previstas no art\. 195, I, "b", e IV, e a contribuição para o Programa de Integração Social', 'EC 126')
add(T, 'CBS cobrada integralmente; Imposto Seletivo comeca', '2027', 'inicio', 'regra', EC, 'EC 132, art. 2 (ADCT art. 126, I)', 'CBS (art. 195, V) e Imposto Seletivo (art. 153, VIII) cobrados a partir de 2027.', m)
add(T, 'PIS e Cofins extintos', '2027', 'extincao', 'regra', EC, 'EC 132, art. 2 (ADCT art. 126, II)', 'Cofins (art. 195, I, b, e IV) e PIS (art. 239) extintos desde que instituida a CBS.', m)
m = achar(ec, r'III - o imposto previsto no art\. 153, IV, da Constituição Federal: a\) terá suas alíquotas reduzidas a zero, exceto em relação aos produtos que tenham industrialização incentivada na Zona Franca de Manaus', 'EC 126 III')
add(T, 'IPI com aliquota zero, salvo produtos com industrializacao incentivada na ZFM', '2027', 0.0, '% (aliquota)', EC, 'EC 132, art. 2 (ADCT art. 126, III, a)', 'O IPI nao e extinto: sobrevive so como instrumento do diferencial da Zona Franca de Manaus.', m)
m = achar(lc, r'Art\. 454\. A partir de 1º de janeiro de 2027, as alíquotas do IPI ficam reduzidas a zero para produtos sujeitos a alíquota inferior a (6,5)% \(seis inteiros e cinco décimos por cento\) prevista na Tabela de Incidência', 'LC 454')
add(T, 'IPI: corte para manter aliquota (produtos de aliquota TIPI igual ou acima de 6,5% feitos na ZFM)', '2027', num(m.group(1)), '% (aliquota TIPI em 31/12/2023)', LC214, 'LC 214, art. 454', 'Produto feito na ZFM (em 2024 ou com projeto Suframa) com aliquota TIPI de 6,5% ou mais mantem IPI quando produzido fora da ZFM, o que preserva o diferencial; com aliquota abaixo de 6,5% o IPI vai a zero e a ZFM recebe credito presumido de CBS (par. 1). Produto que a ZFM nao faz vai a zero pelo ADCT 126, III.', m)
m, pg = achar_pdf('fazenda/nota-tecnica-aliquotas_2024-07-01_sertmf-1.pdf', r'quase (97)% dos mais de 10 mil códigos de produtos da tabela de incidência do IPI terão suas alíquotas zeradas a partir de 2027\. Os cerca de (300) produtos remanescentes')
add(T, 'IPI: codigos da TIPI zerados em 2027 (lista preliminar)', '2027', num(m.group(1)), '% dos codigos', 'fazenda/nota-tecnica-aliquotas_2024-07-01_sertmf-1.pdf', f'SERT/MF nota de 01/07/2024, p. {pg}',
    f'Estimativa preliminar da SERT sobre o PLP 68; cerca de {m.group(2)} produtos seguem com IPI nao nulo. Lista definitiva e do Executivo (LC 214, art. 454, par. 3).', m)
m = achar(ec, r'Art\. 127\. Em 2027 e 2028, o imposto previsto no art\. 156-A da Constituição Federal será cobrado à alíquota estadual de (0,05)% \(cinco centésimos por cento\) e à alíquota municipal de (0,05)% \(cinco centésimos por cento\)\. Parágrafo único\. No período referido no caput , a alíquota da contribuição prevista no art\. 195, V, da Constituição Federal, será reduzida em (0,1) \(um décimo\) ponto percentual', 'EC 127')
for ano in ('2027', '2028'):
    add(T, 'IBS estadual', ano, num(m.group(1)), '% do valor da operacao', EC, 'EC 132, art. 2 (ADCT art. 127)', 'IBS total de 0,1% (0,05 estadual + 0,05 municipal).', m)
    add(T, 'IBS municipal', ano, num(m.group(2)), '% do valor da operacao', EC, 'EC 132, art. 2 (ADCT art. 127)', 'IBS total de 0,1%.', m)
    add(T, 'CBS: reducao sobre a aliquota de referencia', ano, -num(m.group(3)), 'pontos percentuais', EC, 'EC 132, art. 2 (ADCT art. 127, par. unico)', 'CBS = aliquota de referencia fixada pelo Senado menos 0,1 p.p. (LC 214, art. 347), compensando o IBS de 0,1%.', m)
m = achar(ec, r'Art\. 128\. De 2029 a 2032, as alíquotas dos impostos previstos nos arts\. 155, II, e 156, III, da Constituição Federal, serão fixadas nas seguintes proporções das alíquotas fixadas nas respectivas legislações: I - 9/10 \(nove décimos\), em 2029; II - 8/10 \(oito décimos\), em 2030; III - 7/10 \(sete décimos\), em 2031; IV - 6/10 \(seis décimos\), em 2032\.', 'EC 128')
for ano, fr in zip(('2029', '2030', '2031', '2032'), re.findall(r'(\d)/10', m.group(0))):
    add(T, 'ICMS e ISS: fracao da aliquota atual', ano, int(fr) / 10, 'fracao da aliquota vigente', EC, 'EC 132, art. 2 (ADCT art. 128)',
        'Beneficios e incentivos de ICMS e ISS caem na mesma proporcao (par. 1). O IBS sobe em contrapartida, calibrado pelo Senado para repor a receita (ADCT 130, II e III).', m)
m = achar(ec, r'Art\. 129\. Ficam extintos, a partir de 2033, os impostos previstos nos arts\. 155, II, e 156, III, da Constituição Federal\.', 'EC 129')
add(T, 'ICMS e ISS extintos', '2033', 'extincao', 'regra', EC, 'EC 132, art. 2 (ADCT art. 129)', 'A partir de 2033 o sistema e so CBS + IBS + Imposto Seletivo.', m)
m = achar(ec, r'I - de 2029 a 2032, (80)% \(oitenta por cento\); II - em 2033, (90)% \(noventa por cento\); III - de 2034 a 2077, percentual correspondente ao aplicado em 2033, reduzido à razão de 1/45', 'EC 131')
add(T, 'IBS: parcela retida e distribuida pela receita media historica', '2029-2032', num(m.group(1)), '% do IBS de cada ente', EC, 'EC 132, art. 2 (ADCT art. 131, par. 1)', 'Transicao federativa: o resto vai pelo destino. Cai 1/45 por ano de 2034 a 2077.', m)
add(T, 'IBS: parcela retida e distribuida pela receita media historica', '2033', num(m.group(2)), '% do IBS de cada ente', EC, 'EC 132, art. 2 (ADCT art. 131, par. 1)', 'Transicao federativa ate 2077.', m)
m = achar(ec, r'c\) do imposto previsto no art\. 153, V, da Constituição Federal, sobre operações de seguros;', 'EC 130 I c')
add(T, 'IOF-Seguros entra na receita a repor pela CBS', '2027-2033', 'incluido', 'regra', EC, 'EC 132, art. 2 (ADCT art. 130, I, c)', 'A CBS repoe PIS, Cofins, IPI e IOF-Seguros.', m)
m = achar(lc, r'Art\. 409\. Fica instituído o Imposto Seletivo.*?I - veículos; II - embarcações e aeronaves; III - produtos fumígenos; IV - bebidas alcoólicas; V - bebidas açucaradas; VI - bens minerais; VII - concursos de prognósticos e fantasy sport \.', 'LC 409')
add(T, 'Imposto Seletivo: bases', '2027', 7, 'grupos de bens e servicos', LC214, 'LC 214, art. 409, par. 1',
    'Veiculos; embarcacoes e aeronaves; fumigenos; bebidas alcoolicas; bebidas acucaradas; bens minerais; concursos de prognosticos e fantasy sport. Aliquotas por lei ordinaria (art. 422).', re.search(r'I - veículos.*?fantasy sport', m.group(0), re.S))
m = achar(lc, r'§ 2º As alíquotas do Imposto Seletivo respeitarão o percentual máximo de (0,25)% \(vinte e cinco centésimos por cento\), nas operações com bens minerais extraídos\.', 'LC 422')
add(T, 'Imposto Seletivo: teto para bens minerais extraidos', '2027', num(m.group(1)), '% (aliquota maxima)', LC214, 'LC 214, art. 422, par. 2 (redacao LC 227/2026)', 'Demais aliquotas do IS dependem de lei ordinaria, nao fixadas na LC.', m)

# ---------------------------------------------------------------- 2. aliquota de referencia
A = 'aliquota_referencia'
f23 = 'fazenda/nt-sert-aliquota-padrao-2023.pdf'
m, pg = achar_pdf(f23, r'alcançando (34,4)%, sendo (24,2)% correspondentes ao ICMS e (10,2)% ao PIS/Cofins')
add(A, 'Aliquota-padrao atual equivalente (ICMS 18% + PIS/Cofins 9,25%, por fora)', '2023', num(m.group(1)), '% do preco sem tributo', f23, f'SERT/MF nota 08/08/2023, p. {pg}', f'ICMS {m.group(2)}% + PIS/Cofins {m.group(3)}%. Referencia de comparacao usada pela SERT.', m)
m, pg = achar_pdf(f23, r'H Cenário G \+ Demais tratamentos favorecidos ([\d,]+) ([\d,]+) ([\d,]+) ([\d,]+) ([\d,]+) ([\d,]+)')
for lab, i in (('CBS', 1), ('IBS', 2), ('total', 3)):
    add(A, f'Estimativa SERT ago/2023, cenario factivel (hiato 10%), {lab}', '2023', num(m.group(i)), '% (aliquota-padrao)', f23, f'SERT/MF nota 08/08/2023, p. {pg}, tabela 2, cenario H',
        'ESTIMATIVA. Texto da PEC 45 aprovado na Camara (jul/2023). Hiato de conformidade de 10% (Hungria 2018-2019) em 2033.', m)
for lab, i in (('CBS', 4), ('IBS', 5), ('total', 6)):
    add(A, f'Estimativa SERT ago/2023, cenario conservador (hiato 15%), {lab}', '2023', num(m.group(i)), '% (aliquota-padrao)', f23, f'SERT/MF nota 08/08/2023, p. {pg}, tabela 2, cenario H',
        'ESTIMATIVA. Mesmas regras; hiato de conformidade 50% maior (15%).', m)
fan = 'fazenda/nt-sert-aliquota-padrao-anexo-metodologico.pdf'
m, pg = achar_pdf(fan, r'o hiato de conformidade na Hungria alcançou o valor médio de (10,0)% no biênio pré-pandemia.*?meta menos ambiciosa de hiato tributário em (15)% no ano de 2033')
add(A, 'Premissa: hiato de conformidade em 2033 (factivel / conservador)', '2033', num(m.group(1)), '% da arrecadacao potencial', fan, f'SERT/MF anexo metodologico 08/08/2023, p. {pg}', f'Conservador: {m.group(2)}%. E a premissa que carrega o efeito esperado de split payment, documento eletronico e simplificacao; a SERT nao separa quanto vem de cada um.', m)
f24 = 'fazenda/2024-04-24_regulamentacao-da-reforma-tributaria.pdf'
m, pg = achar_pdf(f24, r'ESTIMATIVA DE ALÍQUOTAS.*?CBS IBS ([\d,]+)% ([\d,]+)% TOTAL ([\d,]+)%')
for lab, i in (('CBS', 1), ('IBS', 2), ('total', 3)):
    add(A, f'Estimativa MF com o PLP 68/2024 (texto do Executivo), {lab}', '2024', num(m.group(i)), '% (aliquota de referencia)', f24, f'SERT/MF apresentacao 24/04/2024, p. {pg}', 'ESTIMATIVA. Ponto central do intervalo.', m)
fj = 'fazenda/nota-tecnica-aliquotas_2024-07-01_sertmf-1.pdf'
m, pg = achar_pdf(fj, r'A Alíquota única \+ Regimes pré-existentes \+ Regimes específicos \+ Imposto Seletivo ([\d,]+) ([\d,]+) ([\d,]+)')
add(A, 'Estimativa SERT jul/2024, cenario-base sem favorecimentos (media)', '2024', num(m.group(2)), '% (aliquota de referencia)', fj, f'SERT/MF nota 01/07/2024, p. {pg}, tabela 1, cenario A', f'ESTIMATIVA. Intervalo {m.group(1)} a {m.group(3)} (hiato factivel e conservador). Aliquota unica com Simples, ZFM, regimes especificos e IS.', m)
m, pg = achar_pdf(fj, r'L Cenário K \+ Devolução dos tributos a famílias de baixa renda \(Cashback\) ([\d,]+) ([\d,]+) ([\d,]+)')
add(A, 'Estimativa SERT jul/2024, PLP 68 completo com cashback (media)', '2024', num(m.group(2)), '% (aliquota de referencia)', fj, f'SERT/MF nota 01/07/2024, p. {pg}, tabela 1, cenario L', f'ESTIMATIVA. Intervalo {m.group(1)} a {m.group(3)}. E a origem do numero de 26,5%.', m)
m, pg = achar_pdf(fj, r'a meta de arrecadação dos novos tributos foi redefinida para ([\d,]+)% do PIB')
add(A, 'Premissa: meta de arrecadacao do IVA dual', '2024', num(m.group(1)), '% do PIB', fj, f'SERT/MF nota 01/07/2024, p. {pg}', 'Media PIS/Cofins/IPI 2025-2028 do PLDO 2025 (4,47% do PIB) + ICMS/ISS 2022-2023 da STN (7,76%), mais IOF-Seguros e ajustes de fundos estaduais e ZFM.', m)
fa = 'fazenda/nota-tecnica-aliquotas_2024-08-23_sertmf.pdf'
m, pg = achar_pdf(fa, r'Total ([\d,]+) ([\d,]+) ([\d,]+) Fonte')
add(A, 'Estimativa SERT ago/2024: acrescimo pelas mudancas da Camara no PLP 68 (media)', '2024', num(m.group(2)), 'pontos percentuais', fa, f'SERT/MF nota 23/08/2024, p. {pg}, tabela 1', f'ESTIMATIVA. Intervalo {m.group(1)} a {m.group(3)} p.p. A nota nao publica o novo total.', m)
m2, pg2 = achar_pdf(fa, r'F Carnes na cesta básica ([\d,]+) ([\d,]+) ([\d,]+)')
add(A, 'Estimativa SERT ago/2024: efeito de incluir carnes na cesta basica (media)', '2024', num(m2.group(2)), 'pontos percentuais', fa, f'SERT/MF nota 23/08/2024, p. {pg2}, tabela 1, cenario F', 'ESTIMATIVA. Maior item isolado da tramitacao na Camara.', m2)
mL, _ = achar_pdf(fj, r'L Cenário K \+ Devolução dos tributos a famílias de baixa renda \(Cashback\) ([\d,]+) ([\d,]+) ([\d,]+)')
add(A, 'Estimativa implicita apos a Camara (26,47 + 1,47)', '2024', round(num(mL.group(2)) + num(m.group(2)), 2), '% (aliquota de referencia)', fa, f'SERT/MF notas de 01/07/2024 (tab. 1, cen. L) e 23/08/2024 (tab. 1, total)',
    'derivado: soma da media de jul/2024 com o acrescimo medio de ago/2024. ESTIMATIVA; a SERT nao publicou este total.')
fc = 'dou/resolucao-cgibs-14-2026.html'
cg = dou(fc)
m = achar(cg, r'Alíquota total inicial \(SERT\)\s*([\d,]+)%\s*IBS correspondente\s*([\d,]+)%\s*Nova alíquota total estimada\s*([\d,]+)%.*?IBS atualizado\s*([\d,]+)%', 'CGIBS quadro 2')
add(A, 'Aliquota total (IBS + CBS) adotada pelo CGIBS como parametro', '2026', num(m.group(3)), '% (aliquota de referencia)', fc, 'Resolucao CGIBS 14/2026 (DOU 31/07/2026), anexo, quadro 2',
    'PARAMETRO METODOLOGICO, nao aliquota oficial: usado so para estimar a arrecadacao do IBS de 2027. O CGIBS diz que as estimativas publicas da SERT passaram a indicar cerca de 28%; o documento da SERT com esse numero nao foi achado.', m)
add(A, 'Parcela IBS adotada pelo CGIBS', '2026', num(m.group(4)), '% (aliquota de referencia)', fc, 'Resolucao CGIBS 14/2026, anexo, quadro 2', f'PARAMETRO. Fator 27,91/26,50 aplicado ao IBS da SERT ({m.group(2)}%). A parcela CBS implicita nao e escrita no texto.', m)
m = achar(cg, r'totaliza R\$ ([\d\.,]+) \(cinco bilhões', 'CGIBS art2')
add(A, 'Arrecadacao estimada do IBS (0,1%)', '2027', num(m.group(1)) / 1e9, 'R$ bilhoes correntes', fc, 'Resolucao CGIBS 14/2026, art. 2', 'ESTIMATIVA do CGIBS; ingressos de marco a dezembro. Ate 50% pode financiar o CGIBS (LC 227, art. 51, I, b).', m)
add(A, 'Aliquota de referencia oficial da CBS para 2027', '2027', '', '% (aliquota de referencia)', fc, 'Resolucao CGIBS 14/2026, anexo, item 4',
    'nao encontrado: a RFB envia a proposta ao TCU, que manda o calculo ao Senado ate 30/10/2026 (prazo de 2026 prorrogado em 45 dias, segundo o CGIBS); o Senado ainda nao fixou em 19/10/2026.',
    achar(cg, r'Excepcionalmente para o ano de 2026, os prazos legais aplicáveis foram prorrogados em 45 dias, de modo que o encaminhamento do cálculo pelo TCU ao Senado Federal deverá ocorrer até 30 de outubro de 2026\.', 'CGIBS prazo'))
m = achar(lc, r'§ 11\. Caso a soma das alíquotas de referência estimadas de que trata o § 10 resulte em percentual superior a (26,5)% \(vinte e seis inteiros e cinco décimos por cento\), o Poder Executivo da União, ouvido o Comitê Gestor do IBS, deverá encaminhar ao Congresso Nacional projeto de lei complementar propondo medidas que reduzam o percentual', 'LC 475 §11')
add(A, 'Trava de referencia (IBS + CBS) da LC 214', '2033', num(m.group(1)), '% (soma das aliquotas de referencia)', LC214, 'LC 214, art. 475, par. 11',
    'Gatilho, nao teto automatico: acima de 26,5% o Executivo deve propor PLP que reduza regimes favorecidos. Avaliacao com dados de 2030, PLP ate o ultimo dia util de marco de 2031, eficacia a partir de 2032 (par. 9).', m)
m = achar(ec, r'I - Teto de Referência da União: a média da receita no período de 2012 a 2021, apurada como proporção do PIB', 'EC 130 §3')
add(A, 'Trava constitucional: Teto de Referencia (media 2012-2021, % do PIB)', '2030 e 2035', 'media 2012-2021', '% do PIB', EC, 'EC 132, art. 2 (ADCT art. 130, par. 3 a 6)',
    'Se a Receita-Base da Uniao em 2027-2028 passar do teto, a CBS cai em 2030; se a Receita-Base Total de 2029-2033 passar do Teto Total, CBS e IBS caem em 2035. O valor do teto em % do PIB nao esta na EC.', m)

# ---------------------------------------------------------------- 3. split payment
S = 'split_payment'
m = achar(lc, r'Art\. 31\. Nas transações de pagamento relativas a operações com bens ou com serviços, os prestadores de serviços de pagamento eletrônico e as instituições operadoras de sistemas de pagamentos deverão segregar e recolher ao Comitê Gestor do IBS e à RFB, no momento da liquidação financeira da transação \( split payment \)', 'LC 31')
add(S, 'Mecanismo', '', 'recolhimento na liquidacao financeira', 'regra', LC214, 'LC 214, art. 31', 'Bancos, adquirentes e operadores de pagamento separam IBS e CBS no momento do pagamento e repassam ao CGIBS e a RFB.', m)
m = achar(lc, r'§ 3º Antes da disponibilização dos recursos ao fornecedor, o prestador de serviço de pagamento ou a instituição operadora do sistema de pagamento deverá, com base nas informações recebidas, consultar sistema do Comitê Gestor do IBS e da RFB sobre os valores a serem segregados e recolhidos, que corresponderão à diferença positiva', 'LC 32 §3')
add(S, 'Procedimento padrao', '', 'debito destacado menos parcela ja extinta', 'regra', LC214, 'LC 214, art. 32, par. 3', 'Consulta ao sistema antes de liberar o dinheiro ao fornecedor; sem consulta, recolhe o valor cheio e o excesso volta em ate 3 dias uteis (par. 4).', m)
m = achar(lc, r'§ 1º No procedimento simplificado de que trata o caput deste artigo, os valores do IBS e da CBS a serem segregados e recolhidos pelo prestador de serviço de pagamento ou pela instituição operadora do sistema de pagamentos serão calculados com base em percentual preestabelecido do valor das operações\.', 'LC 33 §1')
add(S, 'Procedimento simplificado (opcional)', '', 'percentual preestabelecido do valor', 'regra', LC214, 'LC 214, art. 33, par. 1', 'Percentual fixado por CGIBS e RFB, pode variar por setor ou contribuinte; o nao usado volta em ate 3 dias uteis apos a apuracao (par. 4).', m)
m = achar(lc, r'§ 1º O split payment deverá entrar em funcionamento de forma simultânea, nas operações com adquirentes que não são contribuintes do IBS e da CBS no regime regular, para os principais instrumentos de pagamento eletrônico utilizados nessas operações\. § 2º Ato conjunto do Comitê Gestor do IBS e da RFB: I - estabelecerá a implementação gradual do split payment', 'LC 35')
add(S, 'Inicio: implementacao gradual por ato conjunto RFB/CGIBS', '', 'sem data na lei', 'regra', LC214, 'LC 214, art. 35, par. 1 e 2', 'A LC nao fixa data. O art. 35 produz efeitos desde 1/1/2025 (art. 544, II) e manda aprovar orcamento do sistema.', m)
m = achar(dec, r'Art\. 33\. Nas transações de pagamento a que se refere o art\. 28, o split payment será implementado de forma gradual em, no mínimo, duas etapas.*?b\) nas transações de pagamento relativas a operações em que o adquirente seja contribuinte do regime regular; e II - será aplicado aos arranjos de pagamento a que se refere o art\. 28, § 5º, incisos I a VII; e III - será de uso facultativo', 'Dec 33')
add(S, 'Primeira etapa (regulamento da CBS)', '', 'B2B, facultativo, boleto/Pix/TED/TEF', 'regra', DEC, 'Decreto 12.955/2026, art. 33, par. 1', 'Na etapa seguinte entram cartoes e vouchers e o consumidor final, com funcionamento simultaneo para todos os arranjos (par. 2). Datas ficam para ato conjunto.', m)
m = achar(dec, r'§ 5º O split payment é aplicável aos seguintes arranjos de pagamento: I - boleto;.*?XI - voucher \(arranjo aberto e arranjo fechado\)', 'Dec 28 §5')
add(S, 'Arranjos de pagamento alcancados', '', len(re.findall(r'\b[IVX]+ - ', m.group(0))), 'arranjos listados', DEC, 'Decreto 12.955/2026, art. 28, par. 5', 'Boleto, cinco modalidades de Pix, TED, TEF, cartao de credito, debito, pre-pago e voucher.', m)
for arq, onde in (('dou/ato-conjunto-2-2026-05-27.html', 'Ato Conjunto RFB/CGIBS 2/2026 (DOU 03/06/2026)'),
                  ('dou/atc-4-2026-08-28.html', 'Ato Tecnico Conjunto 4/2026 (DOU 08/09/2026)'),
                  ('dou/atc-5-2026-09-22.html', 'Ato Tecnico Conjunto 5/2026 (DOU 23/09/2026)')):
    t = dou(arq)
    m = achar(t, r'Plataforma Pública do Split Payment', arq)
    mm = achar(t, r'(Manual de [^;:\n]*?versão [\d\.]+|Manual de Integração e do Swagger)', arq)
    add(S, 'Ato normativo da Plataforma Publica do Split Payment', '2026', 'documentacao tecnica', 'ato', arq, onde, 'Aprova ou publica manuais; nao fixa data de obrigatoriedade.', mm)
add(S, 'Data de inicio obrigatorio do split payment', '', '', 'data', LC214, 'LC 214, art. 35; Decreto 12.955, art. 33',
    'nao encontrado: nenhum ato normativo lido (DOU ate 19/10/2026) fixa a data. Imprensa relata testes da RFB desde 15/10/2026 e uso facultativo B2B em 2027, sem fonte primaria localizada.')
add(S, 'Estimativa oficial de ganho de arrecadacao ou de reducao de sonegacao pelo split payment', '', '', 'R$ ou % do PIB', fan, 'SERT/MF anexo metodologico 08/08/2023; notas de 01/07/2024 e 23/08/2024',
    'nao existe estimativa oficial separada: as notas da SERT so supoem hiato de conformidade de 10% a 15% em 2033 para o sistema todo, sem atribuir parcela ao split payment.')

# ---------------------------------------------------------------- 4. cashback
C = 'cashback'
m = achar(lc, r'Art\. 113\. O destinatário das devoluções.*?Cadastro Único para Programas Sociais do Governo Federal \(CadÚnico\).*?I - possuir renda familiar mensal per capita de até meio salário-mínimo nacional', 'LC 113')
add(C, 'Publico: familia no CadUnico com renda per capita ate', '', 0.5, 'salario minimo mensal per capita', LC214, 'LC 214, art. 113, I', 'Tambem exige residencia no pais e CPF regular; inclusao automatica (par. 1).', re.search(r'I - possuir renda.*', m.group(0)))
m = achar(lc, r'I - (100)% \(cem por cento\) para a CBS e (20)% \(vinte por cento\) para o IBS na aquisição de botijão de até 13 kg \(treze quilogramas\) de gás liquefeito de petróleo, nas operações de fornecimento domiciliar de energia elétrica, abastecimento de água, esgotamento sanitário e gás canalizado e nas operações de fornecimento de telecomunicações; e II - (20)% \(vinte por cento\) para a CBS e para o IBS, nos demais casos\.', 'LC 118')
add(C, 'Devolucao da CBS: gas de botijao, energia, agua, esgoto, gas canalizado, telecom', '', num(m.group(1)), '% do tributo', LC214, 'LC 214, art. 118, I', 'Piso nacional; o percentual da CBS neste grupo nao pode ser alterado (par. 3).', m)
add(C, 'Devolucao do IBS: gas de botijao, energia, agua, esgoto, gas canalizado, telecom', '', num(m.group(2)), '% do tributo', LC214, 'LC 214, art. 118, I', 'Piso; estados e municipios podem subir por lei propria (par. 1).', m)
add(C, 'Devolucao da CBS: demais bens e servicos', '', num(m.group(3)), '% do tributo', LC214, 'LC 214, art. 118, II', 'Piso; exclui bens e servicos sujeitos ao Imposto Seletivo (art. 117, par. 2, I).', m)
add(C, 'Devolucao do IBS: demais bens e servicos', '', num(m.group(3)), '% do tributo', LC214, 'LC 214, art. 118, II', 'Piso; entes podem subir.', m)
m = achar(lc, r'Art\. 123\. As devoluções previstas no art\. 112 desta Lei Complementar serão calculadas com base no consumo familiar realizado a partir do: I - mês de janeiro de 2027, para a CBS; e II - mês de janeiro de 2029, para o IBS\.', 'LC 123')
add(C, 'Inicio da devolucao da CBS (consumo a partir de)', '2027', 'janeiro de 2027', 'data', LC214, 'LC 214, art. 123, I', '', m)
add(C, 'Inicio da devolucao do IBS (consumo a partir de)', '2029', 'janeiro de 2029', 'data', LC214, 'LC 214, art. 123, II', '', m)
fcb = 'fazenda/2024-05-20-_regulamentacao-da-reforma_3a-reuniao-tecnica-cd_cashback-e-cesta-basica.pdf'
m, pg = achar_pdf(fcb, r'renda mensal até ½ salário-mínimo, integrado ao Cadastro Único: um terço da população brasileira')
add(C, 'Alcance estimado do publico', '2024', 'um terco da populacao', 'populacao', fcb, f'SERT/MF apresentacao 20/05/2024, p. {pg}', 'Estimativa da SERT, sem numero absoluto no documento.', m)
mt, pg = achar_pdf(fj, r'L Devolução dos tributos a famílias de baixa renda \(Cashback\) ([\d,]+) ([\d,]+) ([\d,]+)')
add(C, 'Custo do cashback na aliquota de referencia (media)', '2024', num(mt.group(2)), 'pontos percentuais', fj, f'SERT/MF nota 01/07/2024, p. {pg}, tabela 2', f'ESTIMATIVA. Intervalo {mt.group(1)} a {mt.group(3)}. PLP 68 original (50% da CBS em energia, agua e esgoto).', mt)
m, pg = achar_pdf(fa, r'J Cashback de 100% da CBS para energia, água e esgoto ([\d,]+) ([\d,]+) ([\d,]+)')
add(C, 'Custo adicional de subir a CBS devolvida de 50% para 100% em energia, agua e esgoto (media)', '2024', num(m.group(2)), 'pontos percentuais', fa, f'SERT/MF nota 23/08/2024, p. {pg}, tabela 1, cenario J', 'ESTIMATIVA.', m)

# ---------------------------------------------------------------- 5. cesta basica e reducoes
B = 'cesta_e_reducoes'


def anexo(n):
    m = achar(lc, rf'\nANEXO {n}\n(.*?)\nANEXO ', f'Anexo {n}')
    corpo = m.group(1)
    itens = re.findall(r'\n(\d+)\n([^\n]+)', corpo)
    titulo = corpo.split('\nITEM\n')[0].replace('\n', ' ')
    if [int(i) for i, _ in itens] != list(range(1, len(itens) + 1)):
        sys.exit(f'ERRO: numeracao inesperada no Anexo {n}')
    return titulo, itens


tit, itens = anexo('I')
add(B, 'Cesta Basica Nacional de Alimentos (aliquota zero de IBS e CBS): itens', '2027', len(itens), 'itens', LC214, 'LC 214, art. 125 e Anexo I',
    f'derivado: contagem dos itens do Anexo I. Titulo do anexo: {tit[:160]}.')
for n, d in itens:
    curto = re.split(r' (?:d[oa]s? |classificad|em conformidade|comumente)', d, 1)[0]
    add(B, f'Anexo I, item {n}: {curto[:80]}', '2027', 0.0, '% (aliquota IBS e CBS)', LC214, f'LC 214, Anexo I, item {n}', f'Trecho: "{d[:200]}"')
for n, rot in (('XV', 'Horticolas, frutas e ovos com aliquota zero'), ('VII', 'Alimentos com reducao de 60% (cesta estendida)'),
               ('II', 'Servicos de educacao com reducao de 60%'), ('III', 'Servicos de saude com reducao de 60%'),
               ('VIII', 'Higiene pessoal e limpeza com reducao de 60%'), ('IX', 'Insumos agropecuarios e aquicolas com reducao de 60%'),
               ('X', 'Producoes artisticas, culturais, jornalisticas e audiovisuais com reducao de 60%')):
    tit, itens = anexo(n)
    exemplos = '; '.join(re.split(r' (?:d[oa]s? |classificad|em conformidade)', d, 1)[0][:50] for _, d in itens[:6])
    add(B, rot, '2027', len(itens), 'itens', LC214, f'LC 214, Anexo {n}', f'derivado: contagem de itens. Titulo: {tit[:140]}. Primeiros itens: {exemplos}.')
m = achar(lc, r'Art\. 127\. Ficam reduzidas em (30)% \(trinta por cento\) as alíquotas do IBS e da CBS incidentes sobre a prestação de serviços pelos seguintes profissionais.*?XVIII - técnicos agrícolas\.', 'LC 127')
profs = re.findall(r'\b[IVX]+ - ([^;\.]+)', m.group(0))
add(B, 'Reducao de 30%: profissoes intelectuais regulamentadas', '2027', len(profs), 'profissoes', LC214, 'LC 214, art. 127',
    'derivado: contagem dos incisos. ' + ', '.join(re.sub(r' e$', '', p.strip()) for p in profs) + '. Vale para pessoa fisica e sociedade de profissionais (par. 1).', re.search(r'Art\. 127\.[^:]*:', m.group(0)))
m = achar(lc, r'Art\. 128\. Desde que observadas.*?ficam reduzidas em (60)% \(sessenta por cento\) as alíquotas do IBS e da CBS incidentes sobre operações com:(.*?)Seção II', 'LC 128')
cats = re.findall(r'\b[IVX]+ - ([^;]+)', m.group(2))
add(B, 'Reducao de 60%: categorias', '2027', len(cats), 'categorias', LC214, 'LC 214, art. 128',
    'derivado: contagem dos incisos. ' + '; '.join(re.sub(r' e$', '', c.strip().rstrip('.')) for c in cats)[:700], re.search(r'Art\. 128\.[^:]*:', m.group(0), re.S))
m, pg = achar_pdf(fcb, r'A carga tributária média dos alimentos incluídos na cesta básica e na cesta estendida vai cair de ([\d,]+)% para ([\d,]+)%\. No caso dos mais pobres, cairá para ([\d,]+)%, após o cashback')
add(B, 'Carga media sobre alimentos da cesta e da cesta estendida, hoje', '2024', num(m.group(1)), '% do preco', fcb, f'SERT/MF apresentacao 20/05/2024, p. {pg}', 'ESTIMATIVA SERT sobre o PLP 68 original (antes de carnes e queijos irem para a aliquota zero).', m)
add(B, 'Carga media sobre alimentos da cesta e da cesta estendida, com a reforma', '2024', num(m.group(2)), '% do preco', fcb, f'SERT/MF apresentacao 20/05/2024, p. {pg}', 'ESTIMATIVA SERT, PLP 68 original.', m)
add(B, 'Carga media sobre alimentos para a baixa renda, com reforma e cashback', '2024', num(m.group(3)), '% do preco', fcb, f'SERT/MF apresentacao 20/05/2024, p. {pg}', 'ESTIMATIVA SERT, PLP 68 original.', m)
m, pg = achar_pdf(fj, r'TABELA 2\..*?B Alíquota reduzida para alimentos e demais produtos agropecuários ([\d,]+) ([\d,]+) ([\d,]+) C Alíquota zero para alimentos da cesta básica ([\d,]+) ([\d,]+) ([\d,]+) D Alíquota reduzida para produtos de higiene pessoal e limpeza ([\d,]+) ([\d,]+) ([\d,]+) E Alíquotas favorecidas para serviços de saúde e educação ([\d,]+) ([\d,]+) ([\d,]+)')
for rot, i in (('Custo na aliquota: reducao para alimentos e demais agropecuarios', 2), ('Custo na aliquota: cesta basica com aliquota zero', 5),
               ('Custo na aliquota: higiene pessoal e limpeza', 8), ('Custo na aliquota: saude e educacao favorecidas', 11)):
    add(B, rot + ' (media)', '2024', num(m.group(i)), 'pontos percentuais', fj, f'SERT/MF nota 01/07/2024, p. {pg}, tabela 2', 'ESTIMATIVA, PLP 68 original. Carnes na cesta somaram mais 0,56 p.p. na Camara (nota de 23/08/2024).', m if i == 2 else None)

# ---------------------------------------------------------------- 6. fundos
F = 'fundos'
m = achar(ec, r'§ 1º De 2025 a 2032, a União entregará ao Fundo recursos que corresponderão aos seguintes valores, atualizados, de 2023 até o ano anterior ao da entrega, pela variação acumulada do IPCA ou de outro índice que vier a substituí-lo:(.*?)§ 2º', 'EC 12')
soma = 0
for ano, v in re.findall(r'em (\d{4}), a R\$ ([\d\.,]+)', m.group(1)):
    soma += num(v)
    add(F, 'Fundo de Compensacao de Beneficios Fiscais do ICMS: aporte da Uniao', ano, num(v) / 1e9, 'R$ bilhoes de 2023 (corrigidos pelo IPCA)', EC, 'EC 132, art. 12, par. 1',
        'Compensa titulares de beneficios onerosos de ICMS concedidos ate 31/05/2023, de 2029 a 2032. A Uniao complementa se faltar (par. 8); saldo em 2032 vai ao FNDR (par. 9).', re.search(rf'em {ano}, a R\$ [\d\.,]+ \([^)]*\)', m.group(1)))
add(F, 'Fundo de Compensacao de Beneficios Fiscais: total 2025-2032', '2025-2032', soma / 1e9, 'R$ bilhoes de 2023 (corrigidos pelo IPCA)', EC, 'EC 132, art. 12, par. 1', 'derivado: soma dos oito aportes. Valores reais (base 2023), nao nominais.')
m = achar(ec, r'Art\. 13\. Os recursos de que trata o art\. 159-A da Constituição Federal.*?IPCA ou de outro índice que vier a substituí-lo:(.*?)Art\. 14\.', 'EC 13')
pares = re.findall(r'(?:em|a partir de) (\d{4}), a R\$ ([\d\.,]+)', m.group(1))
soma = 0
for ano, v in pares:
    soma += num(v) if ano != '2043' else 0
    rot = ano if ano != '2043' else '2043 em diante (por ano)'
    add(F, 'Fundo Nacional de Desenvolvimento Regional: aporte da Uniao', rot, num(v) / 1e9, 'R$ bilhoes de 2023 (corrigidos pelo IPCA)', EC, 'EC 132, art. 13',
        'Entregue a estados e DF para infraestrutura, fomento produtivo e inovacao; rateio 30% populacao e 70% coeficiente do FPE (CF art. 159-A, par. 4).', re.search(rf'(?:em|a partir de) {ano}, a R\$ [\d\.,]+ \([^)]*\)', m.group(1)))
add(F, 'Fundo Nacional de Desenvolvimento Regional: total 2029-2042', '2029-2042', soma / 1e9, 'R$ bilhoes de 2023 (corrigidos pelo IPCA)', EC, 'EC 132, art. 13', 'derivado: soma dos aportes ate 2042; de 2043 em diante sao 60 bilhoes por ano, sem prazo final.')
m = achar(ec, r'I - população do Estado ou do Distrito Federal, com peso de (30)% \(trinta por cento\); II - coeficiente individual de participação do Estado ou do Distrito Federal nos recursos de que trata o art\. 159, I, "a", da Constituição Federal, com peso de (70)%', 'CF 159-A')
add(F, 'FNDR: peso da populacao no rateio', '', num(m.group(1)), '%', EC, 'EC 132, art. 1 (CF art. 159-A, par. 4)', f'O resto ({m.group(2)}%) segue o coeficiente do FPE. TCU calcula os coeficientes.', m)
m = achar(ec, r'Art\. 15\. Os recursos entregues na forma do art\. 159-A da Constituição Federal.*?os recursos de que trata o art\. 12 e as compensações de que trata o art\. 7º não se incluem em bases de cálculo ou em limites de despesas estabelecidos pela lei complementar de que trata o art\. 6º da Emenda Constitucional nº 126', 'EC 15')
add(F, 'FNDR e Fundo de Compensacao fora do limite de despesas', '', 'fora do limite', 'regra', EC, 'EC 132, art. 15', 'Nao entram no limite do arcabouco fiscal (LC do art. 6 da EC 126, a LC 200/2023).', m)
m = achar(lc, r'Art\. 484\. A União custeará, por meio de operação de crédito, as despesas necessárias à instalação do CGIBS, no período de 2025 a 2028, no montante de até R\$ ([\d\.,]+) .*?I - em 2025, no valor de R\$ ([\d\.,]+) .*?II - em 2026, no valor de R\$ ([\d\.,]+) .*?III - em 2027, no valor de R\$ ([\d\.,]+) .*?IV - em 2028, no valor de R\$ ([\d\.,]+) ', 'LC 484')
for ano, i in (('2025', 2), ('2026', 3), ('2027', 4), ('2028', 5)):
    add(F, 'Credito da Uniao para instalar o Comite Gestor do IBS', ano, num(m.group(i)) / 1e9, 'R$ bilhoes nominais', LC214, 'LC 214, art. 484 (redacao LC 227/2026)',
        'Emprestimo, nao doacao: Selic, ressarcido em 20 parcelas semestrais a partir de junho de 2029 (par. 3 e 4). Em 2025 reduzido de 1/12 por mes ate a comunicacao de instalacao.', re.search(r'em ' + ano + r', no valor de R\$ [\d\.,]+ \([^)]*\)', m.group(0)))
add(F, 'Credito da Uniao para instalar o Comite Gestor do IBS: teto 2025-2028', '2025-2028', num(m.group(1)) / 1e9, 'R$ bilhoes nominais', LC214, 'LC 214, art. 484, caput', '', re.search(r'no montante de até R\$ [\d\.,]+ \([^)]*\)', m.group(0)))
m = achar(ec, r'§ 2º Lei complementar instituirá Fundo de Sustentabilidade e Diversificação Econômica do Estado do Amazonas, que será constituído com recursos da União', 'EC 92-B')
add(F, 'Fundo de Sustentabilidade e Diversificacao Economica do Amazonas e Fundo da Amazonia Ocidental e Amapa', '', '', 'R$', EC, 'EC 132, art. 2 (ADCT art. 92-B, par. 2 a 7)',
    'nao encontrado: a EC manda lei complementar fixar o aporte minimo anual; nem a LC 214 nem a LC 227 trazem o valor.', m)

# ---------------------------------------------------------------- 7. efeito distributivo e PIB
D = 'efeito_distributivo'
add(D, 'Estimativa oficial (Fazenda/SERT) do efeito da reforma por decimo de renda', '', '', '% da renda', fj, 'paginas de estudos e de regulamentacao da reforma no MF; notas SERT 2023-2024',
    'nao encontrado: nenhuma nota ou apresentacao da SERT lida traz efeito por decimo. O que existe oficial e a carga atual por decimo (Ipea TD 2823, frente T) e a carga dos alimentos acima (tema cesta_e_reducoes).')
fcc = 'fazenda/simulacoes-pec45-ccif.pdf'
m, pg = achar_pdf(fcc, r'0-1 s\.m\. ([\d,]+)% ([\d,]+)% ([\d,]+)% ([\d,]+)%.*?Acima de 30 s\.m\. ([\d,]+)% ([\d,]+)% ([\d,]+)% ([\d,]+)% Média ([\d,]+)% ([\d,]+)%')
add(D, 'Ganho de bem-estar, familias de 0 a 1 salario minimo (cenario padrao)', '2020', num(m.group(1)), '% da renda (variacao equivalente)', fcc, f'CCiF out/2020, p. {pg}, tabela 4',
    'NAO OFICIAL: CCiF (think tank), hospedado na pagina de estudos do MF. PEC 45 original (IBS unico), faixas de salario minimo e nao decimos, sem cashback. Cenario com produtividade: ' + m.group(3) + '%.', m)
add(D, 'Ganho de bem-estar, familias acima de 30 salarios minimos (cenario padrao)', '2020', num(m.group(5)), '% da renda (variacao equivalente)', fcc, f'CCiF out/2020, p. {pg}, tabela 4', 'NAO OFICIAL, mesmas ressalvas. Media: ' + m.group(9) + '%.', m)
G = 'efeito_pib'
fip = 'ipea/cc60-nota01-reforma-tributaria-pib.pdf'
m, pg = achar_pdf(fip, r'Para a PEC no 45/2019, ao final do período de transição \(2036\), o PIB cresce ([\d,]+)%\. Para a PEC no 110/2019, até 2032 o PIB cresce ([\d,]+)%, enquanto para o substitutivo da PEC no 45/2019, também até 2032, cresce ([\d,]+)%')
add(G, 'PIB acumulado acima do cenario sem reforma, substitutivo da PEC 45 (base da EC 132)', '2032', num(m.group(3)), '% do PIB', fip, f'Ipea Carta de Conjuntura 60, nota 1 (06/07/2023), p. {pg}',
    f'ESTIMATIVA. Modelo de equilibrio geral, produtividade endogena, sem ganho de custo de conformidade. PEC 45 original: {m.group(1)}% ate 2036.', m)
m, pg = achar_pdf(fip, r'no cenário do substitutivo da PEC, ao fim do período de transição \(2032\), o emprego seria ([\d,]+)% maior')
add(G, 'Emprego acima do cenario sem reforma, substitutivo da PEC 45', '2032', num(m.group(1)), '% do pessoal ocupado', fip, f'Ipea CC 60, nota 1, p. {pg}', 'ESTIMATIVA.', m)
fbo = 'fazenda/impactos-macro-pec45.pdf'
m, pg = achar_pdf(fbo, r'em um aumento do PIB potencial do Brasil de ([\d,]+)% em 15 anos e de ([\d,]+)% no longo')
add(G, 'PIB potencial em 15 anos (PEC 45 original)', '2020', num(m.group(1)), '% do PIB potencial', fbo, f'Borges/CCiF jun/2020, p. {pg}',
    f'NAO OFICIAL: nota para o CCiF hospedada na pagina de estudos do MF; PEC 45 original, sem as excecoes da EC 132. Longo prazo: {m.group(2)}%. Modelo semiestrutural com ganho de produtividade exogeno.', m)
add(G, 'Estimativa da Fazenda/SPE ou SERT de efeito da EC 132/LC 214 sobre o PIB', '', '', '% do PIB', fj, 'paginas de estudos do MF',
    'nao encontrado: a pagina de estudos da reforma no MF hospeda so estudos externos (CCiF, UFMG, Banco Mundial); nenhuma nota da SPE ou SERT com efeito sobre o PIB foi achada.')

# ---------------------------------------------------------------- 8. gastos tributarios
GT = 'gastos_tributarios'
XL = '../E/dgt-previsao-ploa-2026-quadros.xlsx'
wb = openpyxl.load_workbook(P(XL), data_only=True, read_only=True)
q6 = {str(r[0]).strip(): r[1] for r in wb['Q VI'].iter_rows(values_only=True) if r[0] and isinstance(r[1], (int, float))}
TOT = q6['TOTAL']
consumo = {'PIS': 'Contribuição Social para o PIS-PASEP', 'Cofins': 'Contribuição para o Financiamento da Seguridade Social - COFINS',
           'IPI interno': 'Imposto sobre Produtos Industrializados - Operações Internas - IPI-Interno',
           'IPI vinculado': 'Imposto sobre Produtos Industrializados - Vinculado à Importação - IPI-Vinculado'}
s = 0
for k, nome in consumo.items():
    v = q6[nome]
    s += v
    add(GT, f'Gasto tributario federal em {k}', '2026', v / 1e9, 'R$ bilhoes (projecao PLOA)', XL, 'RFB DGT PLOA 2026, Quadro VI',
        f'Tributo extinto (PIS/Cofins em 2027) ou zerado salvo ZFM (IPI). {100 * v / TOT:.1f}% do total de gastos tributarios federais (derivado).')
add(GT, 'Gasto tributario federal nos tributos que a reforma extingue ou zera (PIS + Cofins + IPI)', '2026', s / 1e9, 'R$ bilhoes (projecao PLOA)', XL, 'RFB DGT PLOA 2026, Quadro VI',
    f'derivado: soma das quatro linhas; {100 * s / TOT:.1f}% do total de R$ {TOT / 1e9:.1f} bi. Nao inclui ICMS e ISS (estaduais e municipais, fora do DGT).')
q7 = list(wb['Q VII'].iter_rows(values_only=True))
por = {}
trib = None
for r in q7:
    if isinstance(r[0], str) and r[0].strip().endswith('.') and r[1]:
        trib = r[1]
    elif isinstance(r[0], (int, float)) and r[1] and trib in consumo.values():
        por.setdefault(trib, []).append((r[1].strip(), r[2] or 0))
for rot, pad, trat in (('Simples Nacional', r'^Simples Nacional$', 'MANTIDO: Simples segue com regras proprias e pode optar por pagar IBS/CBS no regime regular (LC 214, art. 41, par. 2 e 3).'),
                       ('Zona Franca de Manaus e Areas de Livre Comercio', r'Zona Franca|Livre Comércio', 'MANTIDO em outra forma: diferencial preservado por creditos presumidos e aliquota zero de IBS/CBS (LC 214, arts. 444 a 451) e IPI residual (art. 454) (ADCT 92-B).'),
                       ('Desoneracao da cesta basica', r'Cesta Básica', 'SUBSTITUIDO: Cesta Basica Nacional com aliquota zero (26 itens) e cesta estendida com reducao de 60%; custo deixa de ser renuncia de PIS/Cofins e passa a pesar na aliquota de referencia.')):
    v = sum(x for t in por for n, x in por[t] if re.search(pad, n))
    add(GT, f'{rot}: gasto em PIS, Cofins e IPI', '2026', v / 1e9, 'R$ bilhoes (projecao PLOA)', XL, 'RFB DGT PLOA 2026, Quadro VII',
        f'derivado: soma das linhas com esse nome nos quatro tributos (II fica fora). {trat}')
m = achar(lc, r'§ 2º Os contribuintes optantes pelo Simples Nacional ou pelo MEI ficam sujeitos às regras desses regimes\. § 3º Os optantes pelo Simples Nacional poderão exercer a opção de apurar e recolher o IBS e a CBS pelo regime regular', 'LC 41')
add(GT, 'Simples Nacional na reforma', '2027', 'mantido, com opcao pelo regime regular', 'regra', LC214, 'LC 214, art. 41, par. 2 e 3', 'O gasto tributario do Simples continua a existir; na SERT ele ja esta no cenario-base da aliquota (nota 01/07/2024).', m)
rb = govbr('rfb/balanco-opcao-simples-regime-regular-2026-10-15.html')
m = achar(rb, r'foram registradas ([\d\.]+) solicitações de opção pelo Simples Nacional e ([\d\.]+) solicitações de opção pelo regime regular do IBS e da CBS', 'RFB balanco')
add(GT, 'Pedidos de opcao pelo regime regular do IBS e da CBS', '2027', int(m.group(2).replace('.', '')), 'solicitacoes', 'rfb/balanco-opcao-simples-regime-regular-2026-10-15.html', 'RFB, noticia de 15/10/2026',
    f'Dado observado, parcial (ate 15/10/2026). Opcao prevista para optantes do Simples que querem gerar credito pleno (LC 214, art. 41, par. 3). Pedidos de opcao pelo Simples: {m.group(1)}.', m)
m = achar(ec, r'§ 1º Os benefícios ou os incentivos fiscais ou financeiros relativos aos impostos previstos nos arts\. 155, II, e 156, III, da Constituição Federal não alcançados pelo disposto no caput deste artigo serão reduzidos na mesma proporção\.', 'EC 128 §1')
add(GT, 'Beneficios de ICMS e ISS', '2029-2032', 'reduzidos na mesma proporcao das aliquotas', 'regra', EC, 'EC 132, art. 2 (ADCT art. 128, par. 1)', 'Extintos com os impostos em 2033; os onerosos sao compensados pelo Fundo de Compensacao.', m)
m, pg = achar_pdf(fj, r'Total ([\d,]+) ([\d,]+) ([\d,]+) Fonte: Elaboração própria\.')
add(GT, 'Custo de todos os tratamentos favorecidos e do cashback na aliquota (media)', '2024', num(m.group(2)), 'pontos percentuais', fj, f'SERT/MF nota 01/07/2024, p. {pg}, tabela 2',
    f'ESTIMATIVA. Intervalo {m.group(1)} a {m.group(3)}. E a medida oficial do que os favorecimentos mantidos custam no novo sistema; mais 1,47 p.p. vieram da Camara (nota 23/08/2024).', m)
add(GT, 'Estimativa oficial de quanto do gasto tributario atual de PIS/Cofins/IPI a reforma extingue ou mantem', '', '', 'R$ bilhoes', XL, 'DGT PLOA 2026; notas SERT',
    'nao encontrado: a RFB nao publicou gasto tributario projetado da CBS; o DGT 2026 ainda mede PIS/Cofins/IPI. A comparacao possivel e a das linhas acima (gasto atual) com o custo em pontos de aliquota (SERT).')

# ---------------------------------------------------------------- saida
with open(SAIDA, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=COLS, lineterminator='\n')
    w.writeheader()
    for r in linhas:
        for k, v in r.items():
            if isinstance(v, str) and '\u2014' in v:
                sys.exit(f'ERRO: travessao em {k}: {v}')
        w.writerow(r)
print(f'{len(linhas)} linhas -> {SAIDA}')

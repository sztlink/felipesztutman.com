# Frente V: reforma tributaria do consumo

Levantamento de 19/10/2026. Regenerar, de fora desta pasta:

    python3 -I brutos/V/build_V.py

Grava `V-reforma-consumo.csv` na raiz `gastos-publicos/` (166 linhas, idempotente: duas rodadas saem iguais byte a byte). Colunas: `tema, item, ano, valor, unidade, fonte_url, pagina_ou_artigo, nota`.

Regras do script:

- Nenhum numero digitado. Cada linha sai de expressao regular sobre o texto da fonte ou de celula de planilha; se o texto nao bater, o script para.
- A nota termina com o trecho literal casado, entre aspas.
- Texto do Planalto: paragrafo riscado (estilo line-through ou `<strike>`) e descartado, entao so entra a redacao vigente, ja com as mudancas da LC 227/2026.
- Nota que comeca com "derivado:" e conta ou soma feita pelo script. Valor vazio com "nao encontrado" marca lacuna.
- "ESTIMATIVA" marca projecao oficial; "PARAMETRO" marca numero usado so como insumo de calculo; "NAO OFICIAL" marca estudo externo hospedado pelo MF.
- Na coluna `ano`, estimativa leva o ano em que foi publicada; regra de lei leva o ano em que vale.

## Fontes (URL e data em `downloads.tsv`)

| pasta | fonte | tipo |
|---|---|---|
| `leis/` | EC 132/2023, LC 214/2025 (compilada), LC 227/2026 (CGIBS), Decreto 12.955/2026 (regulamento da CBS), todos do Planalto | primaria |
| `fazenda/` | SERT/MF: nota da aliquota-padrao (08/08/2023) e anexo metodologico; nota de 01/07/2024 (PLP 68); nota de 23/08/2024 (mudancas da Camara); apresentacoes de 24/04/2024 e 20/05/2024 (cashback e cesta) | primaria |
| `fazenda/` | CCiF: nota de Braulio Borges (jun/2020) e simulacoes da PEC 45 (out/2020), hospedadas na pagina de estudos do MF | **nao oficial** |
| `ipea/` | Ipea Carta de Conjuntura 60, nota 1 (06/07/2023), efeito sobre PIB e emprego | oficial secundaria |
| `dou/` | Resolucao CGIBS 14/2026; Ato Conjunto RFB/CGIBS 2/2026; Atos Tecnicos Conjuntos 4 e 5/2026 (split payment) | primaria |
| `rfb/` | Noticias da RFB de 09/10/2026 (destaque da CBS) e 15/10/2026 (opcoes Simples e regime regular) | primaria |
| `../E/` | DGT PLOA 2026, quadros (RFB, ago/2025), reusado da frente E sem copiar | primaria |

**Cinco PDFs da SERT sairam do ar.** Em 19/10/2026 o gov.br responde "Conteudo Restrito" nas notas de 01/07/2024 e 23/08/2024 e nas apresentacoes de 2024. Vieram do Wayback Machine (`id_`, bytes crus); o SHA-1 em base32 de cada arquivo e igual ao digest que o CDX registrou para a resposta original do gov.br. `fonte_url` aponta o endereco oficial; `downloads.tsv` guarda os dois. As notas de 2023 ainda abrem direto.

## Resposta curta

| tema | numero | fonte |
|---|---|---|
| 2026 | CBS 0,9% e IBS 0,1%, compensaveis com PIS/Cofins; dispensa de recolhimento para quem cumpre obrigacoes acessorias | ADCT 125; LC 214, arts. 343, 346, 348 |
| 2027 | CBS cheia (referencia menos 0,1 p.p.), Imposto Seletivo, PIS/Cofins extintos, IPI zero salvo ZFM; IBS 0,05% + 0,05% em 2027 e 2028 | ADCT 126 e 127 |
| 2029 a 2032 | ICMS e ISS a 9/10, 8/10, 7/10, 6/10 da aliquota; extintos em 2033 | ADCT 128 e 129 |
| aliquota de referencia | SERT: 25,45% a 27% (ago/2023); 26,5% (abr/2024, CBS 8,8 + IBS 17,7); 26,47% (jul/2024); +1,47 p.p. pela Camara (ago/2024). CGIBS usa 27,91% como parametro (jul/2026) | notas SERT; Res. CGIBS 14/2026 |
| trava | 26,5%: acima disso o Executivo propoe PLP em 2031 com eficacia em 2032 | LC 214, art. 475, par. 11 |
| split payment | recolhimento na liquidacao; gradual por ato conjunto; 1a etapa B2B facultativa | LC 214, arts. 31 a 35; Dec. 12.955, art. 33 |
| cashback | CadUnico ate 1/2 SM per capita; 100% CBS e 20% IBS em gas, energia, agua, esgoto, telecom; 20% e 20% no resto; CBS desde jan/2027, IBS desde jan/2029 | LC 214, arts. 113, 118, 123 |
| cesta | 26 itens com aliquota zero (Anexo I) + 6 de horticolas, frutas e ovos (Anexo XV); 17 alimentos com 60% de reducao (Anexo VII); 18 profissoes com 30%; 13 categorias com 60% | LC 214 |
| fundos | Compensacao: R$ 160 bi de 2023 entre 2025 e 2032 (8, 16, 24, 32, 32, 24, 16, 8). FNDR: 8 bi em 2029 subindo a 60 bi por ano a partir de 2043 | EC 132, arts. 12 e 13 |
| gastos tributarios | PIS + Cofins + IPI = R$ 194,7 bi em 2026 (31,8% dos gastos federais); Simples 61,2 bi, ZFM/ALC 27,4 bi, cesta 45,1 bi nesses tributos | DGT PLOA 2026 |

## Ressalvas

- **Fundos em reais de 2023.** Os valores da EC sao corrigidos pelo IPCA de 2023 ate o ano anterior ao da entrega; o CSV traz o valor de face. O credito ao CGIBS (LC 214, art. 484) e nominal e e emprestimo a Selic, devolvido a partir de 2029.
- **Aliquota de referencia.** Todas sao estimativas condicionadas ao hiato de conformidade em 2033 (10% factivel, 15% conservador). O 27,94% e soma feita pelo script; a SERT nao publicou o total pos-Camara. A Resolucao CGIBS 14/2026 cita "estimativas publicas da SERT em torno de 28%" sem indicar documento.
- **CBS de 2027.** A aliquota oficial ainda nao existe em 19/10/2026: o TCU manda o calculo ao Senado ate 30/10/2026 e o Senado fixa depois.
- **Gastos tributarios.** O DGT mede so tributos federais e ainda pela legislacao atual. O que a reforma "mantem" aparece como custo em pontos de aliquota (4,96 p.p. em jul/2024, mais 1,47 p.p. da Camara), nao como renuncia em reais.
- **Estudos CCiF.** Entram so para mostrar que existem e o que dizem; sao da PEC 45 original (IBS unico, sem excecoes) e nao sao oficiais.

## Procurado e nao achado

- Data de inicio obrigatorio do split payment em ato normativo. Os atos do DOU ate 19/10/2026 so aprovam manuais. A imprensa cita comunicado da RFB de 30/09/2026 (testes desde 15/10/2026, uso facultativo B2B em 2027); a pagina da RFB nao foi localizada.
- Estimativa oficial de ganho de arrecadacao ou de reducao de sonegacao atribuida ao split payment. Nao existe: a SERT so supoe o hiato do sistema todo.
- Estimativa oficial (Fazenda, SERT, SPE) do efeito da reforma por decimo de renda. Para a carga atual por decimo, ver frente T.
- Estimativa da Fazenda (SPE ou SERT) do efeito sobre o PIB. O que ha e o Ipea (2,39% ate 2032) e o CCiF (nao oficial).
- Nota da SERT com o total apos o Senado e a sancao (o "cerca de 28%").
- Aporte minimo do Fundo de Sustentabilidade do Amazonas e do Fundo da Amazonia Ocidental e Amapa (ADCT 92-B manda LC fixar; LC 214 e 227 nao trazem).
- IFI/Senado, Estudo Especial 19 (mar/2024): a pagina do Senado devolve verificacao de seguranca e o Wayback nao tem copia.

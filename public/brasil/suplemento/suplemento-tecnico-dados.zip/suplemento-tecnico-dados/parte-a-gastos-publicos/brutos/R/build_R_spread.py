#!/usr/bin/env python3
# Juro real de 10 anos do Brasil (NTN-B interpolada, N-juro-real-mensal.csv) menos o dos EUA (TIPS 10 anos, FRED DFII10),
# media mensal e media por governo; Selic meta media contra Fed funds efetivo (FRED FEDFUNDS).
import csv, os, statistics as st
from collections import defaultdict
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..', '..')
us = defaultdict(list)
for r in csv.DictReader(open(os.path.join(AQUI, 'DFII10.csv'))):
  if r['DFII10'] not in ('', '.'): us[r['observation_date'][:7]].append(float(r['DFII10']))
ff = {r['observation_date'][:7]: float(r['FEDFUNDS']) for r in csv.DictReader(open(os.path.join(AQUI, 'FEDFUNDS.csv')))}
FONTE = 'Tesouro Direto via N-juro-real-mensal.csv; FRED DFII10 e FEDFUNDS (https://fred.stlouisfed.org/series/DFII10, /FEDFUNDS), consulta 2026-10-18'
mes, gov = [], defaultdict(list)
for r in csv.DictReader(open(os.path.join(RAIZ, 'N-juro-real-mensal.csv'))):
  m = r['mes']
  if not r['juro_real_10a'] or m not in us: continue
  b, u = float(r['juro_real_10a']), st.mean(us[m])
  l = dict(mes=m, presidente=r['presidente'], br=b, us=u, spread=b - u, selic=float(r['selic_meta_media_mes']), fed=ff.get(m))
  mes.append(l); gov[r['presidente']].append(l)
with open(os.path.join(RAIZ, 'R-juro-real-br-eua.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['periodo', 'presidente', 'n_meses', 'juro_real_10a_br', 'juro_real_10a_eua', 'diferenca_pp', 'selic_meta_media', 'fed_funds_medio', 'fonte'])
  for p, v in gov.items():
    w.writerow(['mandato', p, len(v)] + [round(st.mean(x[k] for x in v if x[k] is not None), 2) for k in ('br', 'us', 'spread', 'selic', 'fed')] + [FONTE])
  for a in sorted({l['mes'][:4] for l in mes}):
    v = [l for l in mes if l['mes'].startswith(a)]
    w.writerow([a, '/'.join(dict.fromkeys(x['presidente'] for x in v)), len(v)] + [round(st.mean(x[k] for x in v if x[k] is not None), 2) for k in ('br', 'us', 'spread', 'selic', 'fed')] + [FONTE])
print('R ok')

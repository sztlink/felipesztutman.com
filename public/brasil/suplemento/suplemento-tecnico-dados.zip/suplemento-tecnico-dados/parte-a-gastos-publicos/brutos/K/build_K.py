#!/usr/bin/env python3
"""Frente K. Resultado primario do Governo Central sem eventos nao recorrentes, 1997-2025.

Le somente arquivos baixados (nada de memoria):
  - RTN serie historica ago/2026 (brutos/D/seriehistoricaago26.xlsx), tabelas 2.1 e 2.1-A
  - SPE/MF, Boletim Resultado Fiscal Estrutural 2024 e 1o sem. 2025 (dez/2025),
    Apendice A, Tabelas A.1 e A.2 (paginas 30 a 34) e Tabela 1 (pagina 16)
  - RFB, Analise da Arrecadacao dez/2025 (fatores nao recorrentes de 2025)
  - RTN mensais (set/2010, dez/2015, dez/2019, dez/2020, jun/2022, dez/2022, dez/2023)
    para os trechos que dao valor aos eventos nomeados

Gera na raiz gastos-publicos/:
  K-primario-recorrente.csv, K-eventos-nao-recorrentes.csv, K-por-mandato.csv

Rodar de fora da pasta de dados:  python3 /caminho/brutos/K/build_K.py
(usa openpyxl e pymupdf; pymupdf vem de ~/.local/lib/pdftools)
"""
import csv
import os
import re
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.abspath(os.path.join(AQUI, '..', '..'))
sys.path.insert(0, os.path.expanduser('~/.local/lib/pdftools'))
import openpyxl  # noqa: E402
import pymupdf  # noqa: E402

RTN_XLSX = os.path.join(AQUI, '..', 'D', 'seriehistoricaago26.xlsx')
RTN_URL = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'
SPE_PDF = os.path.join(AQUI, 'spe-rfe-2025', 'boletim-rfe-24-semestre-1-25.pdf')
SPE_URL = ('https://www.gov.br/fazenda/pt-br/central-de-conteudo/publicacoes/transparencia-fiscal/'
           'boletim-resultado-fiscal-estrutural/2025/boletim-rfe-24-semestre-1-25.pdf')
SPE_URL_COPIA = ('http://web.archive.org/web/20260320034503id_/' + SPE_URL)
RFB_TXT = os.path.join(AQUI, 'rfb-arrecadacao-mensal', 'analisemensal-dez-2025.txt')
RFB_PDF = os.path.join(AQUI, 'rfb-arrecadacao-mensal', 'analisemensal-dez-2025.pdf')
RFB_URL = ('https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/'
           'arrecadacao-federal/2025/analisemensal-dez-2025.pdf')
RTNM = os.path.join(AQUI, 'rtn-mensal')

ANOS = list(range(1997, 2026))

MANDATOS = [
    ('FHC (1997-2002)', 1997, 2002),
    ('Lula 1 (2003-2006)', 2003, 2006),
    ('Lula 2 (2007-2010)', 2007, 2010),
    ('Dilma (2011-2015)', 2011, 2015),
    ('2016 Dilma/Temer', 2016, 2016),
    ('Temer (2017-2018)', 2017, 2018),
    ('Bolsonaro (2019-2022)', 2019, 2022),
    ('Lula 3 (2023-2025)', 2023, 2025),
]


# ---------------------------------------------------------------- RTN
def le_rtn():
    wb = openpyxl.load_workbook(RTN_XLSX, read_only=True, data_only=True)

    def tabela(nome):
        rows = list(wb[nome].iter_rows(values_only=True))
        cab = None
        out = {}
        for r in rows:
            if r[0] == 'Discriminação':
                cab = list(r)
                continue
            if cab and r[0] is not None:
                rot = str(r[0]).strip()
                d = {}
                for k, v in zip(cab[1:], r[1:]):
                    if isinstance(k, int) and isinstance(v, (int, float)):
                        d[k] = float(v)
                if d:
                    out[rot] = d
        return out, rows

    t21, _ = tabela('2.1')
    _, rows_a = tabela('2.1-A')
    pib = None
    for i, r in enumerate(rows_a):
        if r[0] and str(r[0]).strip().startswith('Memorando'):
            anos = r[1:]
            vals = rows_a[i + 1][1:]
            pib = {int(a): float(v) for a, v in zip(anos, vals) if isinstance(a, int)}
            break

    def linha(prefixo):
        for k, v in t21.items():
            if k.startswith(prefixo):
                return v
        raise KeyError(prefixo)

    return {
        'acima': linha('5. RESULTADO PRIM'),
        'abaixo': linha('8. RESULTADO PRIM'),
        'concessoes': linha('1.4.1'),
        'dividendos': linha('1.4.2'),
        'cred_extra': linha('4.3.07'),
        'apoio_eemm': linha('4.3.03'),
        'campanha': linha('4.3.19'),
        'pis_pasep_ec126': linha('6.3'),
        'lc194_pre': linha('6.4'),
        'pib': pib,
    }


# ---------------------------------------------------------------- SPE, tabelas A.1 e A.2
def _num(txt):
    t = txt.replace('.', '').replace(',', '.').strip()
    if t in ('', '-'):
        return None
    return float(t)


def _segmento(page, y0, y1, anos_bloco):
    """Le um bloco de tabela entre y0 e y1. Celulas de rotulo sao retangulos em x~41."""
    words = page.get_text('words')
    cells = set()
    for dr in page.get_drawings():
        for it in dr['items']:
            if it[0] == 're':
                r = it[1]
                if abs(r.x0 - 41) < 2 and r.height > 5 and y0 <= r.y0 < y1:
                    cells.add((round(r.y0, 1), round(r.y1, 1), round(r.x1, 1)))
    cells = sorted(cells)
    if not cells:
        return []
    xlab = max(c[2] for c in cells)
    # colunas: centros x dos numeros dentro do bloco
    nums = [w for w in words if w[0] > xlab and y0 <= w[1] < y1 and re.fullmatch(r'-?[\d.]+|-', w[4]) and (w[3] - w[1]) < 11]
    xs = sorted(((w[0] + w[2]) / 2) for w in nums if w[4] != '-')
    grupos = []
    for x in xs:
        if grupos and x - grupos[-1][-1] < 9:
            grupos[-1].append(x)
        else:
            grupos.append([x])
    centros = [sum(g) / len(g) for g in grupos]
    if len(centros) != len(anos_bloco):
        raise RuntimeError(f'pag {page.number + 1}: {len(centros)} colunas, esperado {len(anos_bloco)}')
    linhas = []
    for (cy0, cy1, _) in cells:
        rot = ' '.join(w[4] for w in sorted(
            [w for w in words if w[0] < xlab and cy0 - 1 <= (w[1] + w[3]) / 2 <= cy1 + 1],
            key=lambda w: (round(w[1]), w[0])))
        dentro = [w for w in nums if cy0 - 1 <= (w[1] + w[3]) / 2 <= cy1 + 1]
        vals = {}
        for j, cx in enumerate(centros):
            ws = sorted([w for w in dentro if abs((w[0] + w[2]) / 2 - cx) < 12], key=lambda w: w[1])
            txt = ''.join(w[4] for w in ws)
            if txt.startswith('--'):
                txt = txt[1:]
            v = _num(txt) if txt else None
            vals[anos_bloco[j]] = v
        if rot.strip():
            linhas.append((rot, vals))
    return linhas


def le_spe():
    doc = pymupdf.open(SPE_PDF)
    a1 = list(range(1997, 2012))
    a2 = list(range(2012, 2026))
    H = 842
    blocos = {
        'A.1': [(29, 90, H, a1), (30, 60, H, a2)],
        'A.2': [(31, 95, H, a1), (32, 60, 400, a1), (32, 400, H, a2), (33, 60, H, a2)],
    }
    out = {}
    for tab, segs in blocos.items():
        series = {}
        ordem = []
        for (pn, y0, y1, anos) in segs:
            for rot, vals in _segmento(doc[pn], y0, y1, anos):
                if rot not in series:
                    series[rot] = {}
                    ordem.append(rot)
                series[rot].update(vals)
        out[tab] = (ordem, series)
    # conferencia: soma dos eventos = linha TOTAL publicada
    for tab, (ordem, s) in out.items():
        for a in ANOS:
            tot = s['TOTAL'][a]
            soma = sum((s[r].get(a) or 0) for r in ordem if r != 'TOTAL')
            if abs(soma - tot) > 3:
                raise RuntimeError(f'{tab} {a}: soma {soma} != TOTAL {tot}')
    return out


def le_spe_tabela1():
    """Tabela 1 (pag. 16): Governo Central RF, RF estrutural, delta, % PIB potencial, 2018-2024."""
    doc = pymupdf.open(SPE_PDF)
    t = doc[15].get_text()
    i = t.find('Tabela 1 –')
    toks = t[i:].split()
    res = {}
    for k, tok in enumerate(toks):
        if re.fullmatch(r'20(1[89]|2[0-4])', tok) and int(tok) not in res:
            nums = toks[k + 1:k + 4]
            try:
                res[int(tok)] = tuple(float(x.replace(',', '.')) for x in nums)
            except ValueError:
                pass
    return res


def le_rfb_2025():
    t = re.sub(r'\s+', ' ', open(RFB_TXT, encoding='utf-8').read())
    m = re.search(r'IRPJ/CSLL \(ATÍPICOS\) - - - - ([\d.]+) ([\d.]+)', t)
    return float(m.group(1).replace('.', '')), m.group(0)


def trecho(arquivo, padrao, largura=180):
    t = re.sub(r'\s+', ' ', open(os.path.join(RTNM, arquivo), encoding='utf-8').read())
    m = re.search(padrao, t)
    if not m:
        return ''
    return t[max(0, m.start() - largura // 3):m.end() + largura].strip()


# ---------------------------------------------------------------- montagem
def main():
    rtn = le_rtn()
    spe = le_spe()
    tab1 = le_spe_tabela1()
    rfb25, rfb25_trecho = le_rfb_2025()
    pib = rtn['pib']

    def pct(v, a):
        return None if v is None else 100.0 * v / pib[a]

    ordem1, s1 = spe['A.1']
    ordem2, s2 = spe['A.2']

    # 2025: a coluna 2025 do SPE e so o 1o semestre. Monto estimativa anual propria
    # com as linhas do RTN que o SPE usa como fonte, e RFB para receitas atipicas.
    est25_rec = {
        'Concessões (RTN 1.4.1, ano cheio)': rtn['concessoes'][2025],
        'Receitas atípicas RFB (RFB dez/2025, IRPJ/CSLL atípicos, R$ de dez/2025)': rfb25,
        'Dividendos extras Petrobras/BNDES': None,
    }
    est25_desp = {
        'Créditos Extraordinários (RTN 4.3.07, ano cheio)': rtn['cred_extra'][2025],
        'Apoio financeiro Estados e Municípios (RTN 4.3.03, ano cheio)': rtn['apoio_eemm'][2025],
        'Financiamento de campanha eleitoral (RTN 4.3.19)': rtn['campanha'][2025],
        'Capitalização estatais não dependentes': None,
    }

    def total_rec(a):
        if a == 2025:
            return sum(v for v in est25_rec.values() if v is not None)
        return s1['TOTAL'][a]

    def total_desp(a):
        if a == 2025:
            return sum(v for v in est25_desp.values() if v is not None)
        return s2['TOTAL'][a]

    # ---------- CSV 1: por ano
    linhas = []
    for a in ANOS:
        rec = total_rec(a)
        desp = total_desp(a)
        cheio_ab = rtn['abaixo'][a]
        cheio_ac = rtn['acima'][a]
        recor = cheio_ab - rec + desp
        recor_ac = cheio_ac + rtn['pis_pasep_ec126'][a] - rec + desp
        r = {
            'ano': a,
            'pib_rs_mi': round(pib[a], 1),
            'primario_cheio_rs_mi': round(cheio_ab, 1),
            'primario_cheio_pct_pib': round(pct(cheio_ab, a), 3),
            'primario_cheio_acima_linha_pct_pib': round(pct(cheio_ac, a), 3),
            'receitas_nao_recorrentes_rs_mi': round(rec, 1),
            'receitas_nao_recorrentes_pct_pib': round(pct(rec, a), 3),
            'despesas_nao_recorrentes_rs_mi': round(desp, 1),
            'despesas_nao_recorrentes_pct_pib': round(pct(desp, a), 3),
        }
        # ajustes por tipo (pct PIB, ja com sinal do efeito sobre o primario)
        for rot in ordem1:
            if rot == 'TOTAL':
                continue
            v = s1[rot].get(a) if a != 2025 else None
            r['rec_' + rot] = '' if v is None else round(pct(v, a), 3)
        for rot in ordem2:
            if rot == 'TOTAL':
                continue
            v = s2[rot].get(a) if a != 2025 else None
            r['desp_' + rot] = '' if v is None else round(pct(v, a), 3)
        r['primario_recorrente_rs_mi'] = round(recor, 1)
        r['primario_recorrente_pct_pib'] = round(pct(recor, a), 3)
        r['primario_recorrente_acima_linha_pct_pib'] = round(pct(recor_ac, a), 3)
        r['primario_recorrente_spe'] = ''
        r['primario_estrutural_spe_pct_pib_potencial'] = tab1[a][1] if a in tab1 else ''
        r['primario_cheio_spe_tabela1'] = tab1[a][0] if a in tab1 else ''
        fontes = [RTN_URL + ' (RTN tab. 2.1 e 2.1-A, ago/2026)', SPE_URL + ' (Tab. A.1 e A.2)']
        nota = ('cheio = RTN linha 8, abaixo da linha (BCB), mesmo conceito do SPE; '
                'recorrente = cheio - receitas NR + despesas NR do SPE')
        if a == 2025:
            fontes = [RTN_URL, RFB_URL]
            nota = ('2025: SPE so publicou o 1o semestre. Estimativa propria com RTN 1.4.1, 4.3.07, 4.3.03, 4.3.19 '
                    'e RFB (atípicos). Dividendos extras e capitalizacao de estatais: nao encontrado (0). '
                    'Ver eventos.')
        if a == 2023:
            nota += ('; acima da linha 2023 inclui R$ 26,0 bi de PIS/Pasep nao sacado (EC 126), '
                     'que o abaixo da linha ja exclui')
        if a in tab1:
            fontes.append(SPE_URL + ' (Tab. 1, estrutural % PIB potencial)')
        r['fonte_url'] = ' | '.join(fontes)
        r['nota'] = nota
        linhas.append(r)
    cab = list(linhas[0].keys())
    with open(os.path.join(RAIZ, 'K-primario-recorrente.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cab)
        w.writeheader()
        w.writerows(linhas)

    # ---------- CSV 2: eventos
    ev = []

    def add(ano, evento, valor_mi, sinal, fonte, trecho_txt, obs=''):
        ev.append({
            'ano': ano, 'evento': evento,
            'valor_rs_bi': '' if valor_mi is None else round(valor_mi / 1000, 3),
            'pct_pib': '' if valor_mi is None else round(pct(valor_mi, ano), 3),
            'sinal': sinal, 'fonte_url': fonte, 'trecho_fonte': trecho_txt, 'obs': obs,
        })

    # todas as celulas nao nulas das tabelas A.1/A.2 (exceto 2025, semestral)
    for tab, ordem, s, sinal in (('A.1', ordem1, s1, 'receita'), ('A.2', ordem2, s2, 'despesa')):
        for rot in ordem:
            if rot == 'TOTAL':
                continue
            for a in ANOS:
                v = s[rot].get(a)
                if v:
                    add(a, f'SPE {tab}: {rot}', v, sinal, SPE_URL,
                        f'Tabela {tab} (R$ milhoes), linha "{rot}", coluna {a}: ' + f'{v:,.0f}'.replace(',', '.'),
                        'coluna 2025 = 1o semestre' if a == 2025 else '')
    # 2025 estimativa propria
    for k, v in est25_rec.items():
        add(2025, 'K 2025 (estimativa): ' + k, v, 'receita',
            RFB_URL if 'RFB' in k else (RTN_URL if v is not None else ''),
            (rfb25_trecho if 'RFB' in k else ('RTN tab. 2.1 linha 1.4.1 2025' if v is not None else 'não encontrado')))
    for k, v in est25_desp.items():
        add(2025, 'K 2025 (estimativa): ' + k, v, 'despesa', RTN_URL if v is not None else '',
            'RTN tab. 2.1, 2025' if v is not None else 'não encontrado')

    # eventos nomeados na pauta, com o valor do proprio RTN mensal
    def u(nome):
        for ln in open(os.path.join(RTNM, 'urls.txt'), encoding='utf-8'):
            p = ln.split()
            if p and p[0] == nome:
                return p[1]
        return ''
    add(2010, 'Cessão onerosa: ingresso (RTN set/2010)', 74807.6, 'receita', u('rtn_2010_09_Nimset2010.pdf'),
        trecho('rtn_2010_09_Nimset2010.txt', r'ingresso de R\$ 74,8 bilhões a título de cessão onerosa'))
    add(2010, 'Capitalização da Petrobras: despesa (RTN set/2010)', 42900, 'despesa', u('rtn_2010_09_Nimset2010.pdf'),
        trecho('rtn_2010_09_Nimset2010.txt', r'R\$ 42,9 bilhões \(93,4%\)'), 'RTN da R$ 42,9 bi; SPE A.2 usa 42.928')
    add(2015, 'Pedaladas: pagamento de passivos (Acórdãos TCU 825 e 3.297/2015)', 55600, 'despesa',
        u('rtn_2015_12_Nimdez2015.pdf'), trecho('rtn_2015_12_Nimdez2015.txt', r'R\$ 55,6 bilhões de passivos'),
        'RTN (caixa) R$ 55,6 bi; SPE usa R$ 45,9 bi do BCB (competencia, Equacionamento de passivos)')
    add(2019, 'Leilão do excedente da cessão onerosa: ingresso', 70000, 'receita', u('rtn_2019_12_relatorio_dez19.pdf'),
        trecho('rtn_2019_12_relatorio_dez19.txt', r'leilão da cessão onerosa ocorrido em nov/19'),
        'dentro de Concessoes 2019 (SPE 93.281 total)')
    add(2019, 'Pagamento à Petrobras pela revisão do contrato da cessão onerosa', 34400, 'despesa',
        u('rtn_2019_12_relatorio_dez19.pdf'), trecho('rtn_2019_12_relatorio_dez19.txt', r'R\$ 34,4 bilhões em dez/19'),
        'SPE A.2 usa 34.700')
    add(2019, 'Repasse a entes de parte do leilão da cessão onerosa', 11700, 'despesa',
        u('rtn_2019_12_relatorio_dez19.pdf'), trecho('rtn_2019_12_relatorio_dez19.txt', r'cessão onerosa\), no montante de R\$ 11,7'),
        'transferencia a EE/MM; SPE nao a lista como evento proprio')
    add(2020, 'Créditos extraordinários da pandemia (exceto PAC), RTN linha 4.3.07', rtn['cred_extra'][2020], 'despesa',
        RTN_URL, 'RTN tab. 2.1 linha 4.3.07, 2020', 'SPE A.2 usa 429.608 e devolve 64.134 como recorrente (Ajustes Gastos BF)')
    add(2021, 'Créditos extraordinários (exceto PAC), RTN linha 4.3.07', rtn['cred_extra'][2021], 'despesa',
        RTN_URL, 'RTN tab. 2.1 linha 4.3.07, 2021', 'SPE devolve 60.576 como recorrente (Ajustes Gastos BF)')
    add(2020, 'Auxílio a estados e municípios (Apoio Fin. EE/MM), RTN 4.3.03', rtn['apoio_eemm'][2020], 'despesa',
        RTN_URL, 'RTN tab. 2.1 linha 4.3.03, 2020')
    add(2022, 'Eletrobras: bônus de outorga da desestatização', 26600, 'receita', u('rtn_2022_06_boletim_jun22.pdf'),
        trecho('rtn_2022_06_boletim_jun22.txt', r'R\$ R\$ 26,6 bilhões'), 'dentro de Concessoes 2022 (SPE 46.847)')
    add(2022, 'Dividendos extras Petrobras (método SPE)', s1['Dividendos extras Petrobras'][2022], 'receita', SPE_URL,
        'Tabela A.1, Dividendos extras Petrobras, 2022')
    add(2022, 'Compensação ICMS LC 194/2022, pré-acordo (lançada retroativamente)', 7695.3, 'despesa',
        u('rtn_2023_12_boletim_dez23.pdf'), trecho('rtn_2023_12_boletim_dez23.txt', r'R\$ 7\.695,3 milhões serão distribuídos'))
    add(2023, 'Compensação ICMS LC 194/2022: pré-acordo jan-jun/23 + pós-acordo', 963.6 + 13837.3, 'despesa',
        u('rtn_2023_12_boletim_dez23.pdf'), trecho('rtn_2023_12_boletim_dez23.txt', r'totalizaram R\$ 13\.837,3 milhões'),
        'soma 963,6 + 13.837,3; inclui antecipacao de 8.715,5 de 2024')
    add(2023, 'Precatórios: pagamento do estoque (ADI 7064), dez/2023', 92388, 'despesa',
        u('rtn_2023_12_apresentacao_dez23.pdf'), trecho('rtn_2023_12_apresentacao_dez23.txt', r'Precatórios ADI 7064 0 92\.388'),
        'SPE nao expurga: so realoca (Ajuste calendario precatorios fora do teto: -15.832 em 2022, +48.085 em 2023, -32.253 em 2024)')
    add(2023, 'PIS/Pasep não sacado (EC 126/2022), ajuste metodológico RTN 6.3', -rtn['pis_pasep_ec126'][2023], 'receita',
        RTN_URL, 'RTN tab. 2.1 linha 6.3, 2023', 'so afeta o acima da linha; abaixo da linha ja exclui')
    add(2024, 'Transação tributária / CARF, receita anual', None, 'receita', '', 'não encontrado',
        'SPE nao classifica como nao recorrente; RFB nao publica total anual')
    add(2025, 'Transação tributária / CARF, receita anual', None, 'receita', '', 'não encontrado',
        'so ha mencao mensal: dez/2025 R$ 2.078 mi (RFB). Nao entra no ajuste')
    add(2025, 'Transação tributária, arrecadação atípica de dez/2025 (só o mês)', 2078, 'receita', RFB_URL,
        re.search(r'arrecadação atípica de aproximadamente R\$ 2\.078 milhões correspondente à transação tributária',
                  re.sub(r'\s+', ' ', open(RFB_TXT, encoding='utf-8').read())).group(0), 'informativo, nao entra no ajuste')
    with open(os.path.join(RAIZ, 'K-eventos-nao-recorrentes.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(ev[0].keys()))
        w.writeheader()
        w.writerows(ev)

    # ---------- CSV 3: por mandato
    pm = []
    por_ano = {r['ano']: r for r in linhas}
    for nome, a0, a1 in MANDATOS:
        anos = range(a0, a1 + 1)
        def media(c):
            return round(sum(por_ano[a][c] for a in anos) / len(anos), 3)
        def razao(c):
            return round(100 * sum(por_ano[a][c] for a in anos) / sum(pib[a] for a in anos), 3)
        est = [tab1[a][1] for a in anos if a in tab1]
        pm.append({
            'mandato': nome, 'anos': f'{a0}-{a1}', 'n_anos': len(anos),
            'primario_cheio_media_pct_pib': media('primario_cheio_pct_pib'),
            'primario_recorrente_media_pct_pib': media('primario_recorrente_pct_pib'),
            'diferenca_pp': round(media('primario_recorrente_pct_pib') - media('primario_cheio_pct_pib'), 3),
            'primario_cheio_soma_sobre_pib_pct': razao('primario_cheio_rs_mi'),
            'primario_recorrente_soma_sobre_pib_pct': razao('primario_recorrente_rs_mi'),
            'primario_cheio_acima_linha_media_pct_pib': media('primario_cheio_acima_linha_pct_pib'),
            'estrutural_spe_media_pct_pib_potencial': round(sum(est) / len(est), 3) if est else '',
            'anos_com_estrutural_spe': ','.join(str(a) for a in anos if a in tab1),
            'nota': ('media simples dos anos; soma_sobre_pib = soma R$ / soma PIB' +
                     ('; 2025 e estimativa propria parcial' if a1 == 2025 else '') +
                     ('; 1997 e o primeiro ano da serie, 1995-1996 fora' if a0 == 1997 else '')),
        })
    with open(os.path.join(RAIZ, 'K-por-mandato.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(pm[0].keys()))
        w.writeheader()
        w.writerows(pm)

    for p in pm:
        print(p['mandato'], p['primario_cheio_media_pct_pib'], p['primario_recorrente_media_pct_pib'],
              p['estrutural_spe_media_pct_pib_potencial'])


if __name__ == '__main__':
    main()

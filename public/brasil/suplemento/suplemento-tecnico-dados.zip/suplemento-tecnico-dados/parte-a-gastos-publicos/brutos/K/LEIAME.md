# Frente K. Primário do Governo Central sem eventos não recorrentes (1997-2025)

Data: 18/10/2026. Script: `build_K.py` (rodar de fora da pasta: `python3 .../brutos/K/build_K.py`). É idempotente: duas rodadas dão os mesmos CSVs.

Saídas na raiz `gastos-publicos/`:
- `K-primario-recorrente.csv`: uma linha por ano, 1997-2025. Traz o primário cheio, o total de receitas e de despesas não recorrentes, cada evento do SPE em % do PIB (colunas `rec_*` e `desp_*`), o recorrente e o estrutural do SPE (2018-2024).
- `K-eventos-nao-recorrentes.csv`: formato longo. Traz todas as células não nulas das Tabelas A.1 e A.2 do SPE, a estimativa de 2025 e os eventos da pauta, cada um com o valor e o trecho do RTN mensal que o dá.
- `K-por-mandato.csv`: médias por mandato.

## Fontes (todas baixadas, nenhum número de memória)

| Arquivo | Fonte | Data |
|---|---|---|
| `../D/seriehistoricaago26.xlsx` (só leitura) | Tesouro, RTN série histórica, tab. 2.1 e 2.1-A, https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326 | 29/09/2026 |
| `spe-rfe-2025/boletim-rfe-24-semestre-1-25.pdf` | SPE/Ministério da Fazenda, Boletim Resultado Fiscal Estrutural 2024 e 1º semestre de 2025, Apêndice A (Tab. A.1 e A.2, págs. 30-34) e Tab. 1 (pág. 16). URL oficial https://www.gov.br/fazenda/pt-br/central-de-conteudo/publicacoes/transparencia-fiscal/boletim-resultado-fiscal-estrutural/2025/boletim-rfe-24-semestre-1-25.pdf | dez/2025 |
| `rfb-arrecadacao-mensal/analisemensal-dez-2025.pdf` (cópia igual em `rfb-arrecadacao-dez2025/`) | RFB, Análise da Arrecadação dez/2025, tabela de fatores não recorrentes, https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/arrecadacao-federal/2025/analisemensal-dez-2025.pdf | jan/2026 |
| `rfb-arrecadacao-mensal/*` | RFB, relatórios mensais mar-dez de 2024 e 2025, só para procurar valores de transação tributária e CARF | baixados em 18/10/2026 |
| `rtn-mensal/rtn_*.pdf` | RTN mensais de set/2010, dez/2015, dez/2019, dez/2020, jun/2022, dez/2022 e dez/2023, com apresentação e sumário de dez/2023. As URLs do CDN do Tesouro estão em `rtn-mensal/urls.txt` | baixados em 18/10/2026 |
| `spe-pagina/*.html` | páginas do SPE sobre o RFE. As coleções vêm vazias e a "tabela de dados" não lista arquivo | 18/10/2026 |

**O PDF do SPE no gov.br está como "Conteúdo Restrito"** (pede login, tanto no caminho novo quanto no antigo `estudos-economicos/2025/...vf.pdf`). Baixei a cópia do Internet Archive do mesmo URL oficial, capturada em 20/03/2026 (`web.archive.org/web/20260320034503id_/...`). São 39 páginas, assinadas pela SPE. A soma dos eventos bate com a linha TOTAL de cada tabela em todos os anos, e o script confere isso a cada rodada.

## Método

- **Primário cheio** = RTN linha 8, "abaixo da linha" (apurado pelo BCB). É o conceito que o SPE usa. Para 2018-2024 ele bate, até a 2ª casa, com o RF_t da Tabela 1 do SPE (-1,66; -1,20; -9,79; -0,40; 0,55; -2,42; -0,39). A coluna `primario_cheio_acima_linha_pct_pib` traz a linha 5 (a manchete do Tesouro).
- **Recorrente (cálculo K)** = cheio − receitas não recorrentes + despesas não recorrentes, com os valores das Tabelas A.1 e A.2 do SPE. É o método do SPE aplicado aos números do próprio SPE. O SPE **não publica em número** o recorrente do Governo Central: ele só aparece em gráfico (Gráf. B1.2) e numa planilha que a página não oferece mais. Por isso `primario_recorrente_spe` fica vazio.
- **Recorrente pela linha de cima** (`primario_recorrente_acima_linha_pct_pib`) = linha 5 + ajuste 6.3 (tira os R$ 26,0 bi de PIS/Pasep não sacado de 2023) − receitas NR + despesas NR.
- **Estrutural SPE** = Tab. 1, Governo Central, em % do **PIB potencial**, só 2018-2024. Não tem a mesma base do resto, que é PIB efetivo do RTN.
- **% do PIB** = PIB nominal do memorando da tab. 2.1-A do RTN.
- **Mandato**: média simples dos anos e soma R$ / soma PIB. FHC começa em 1997 porque a série começa lá.

## Cuidados

1. **2025 é estimativa parcial minha.** A coluna 2025 do SPE cobre só o 1º semestre, por isso não a uso. No lugar, uso as linhas que o SPE tira do RTN no ano cheio: concessões (1.4.1, R$ 7,2 bi), créditos extraordinários (4.3.07, R$ 6,4 bi), apoio a EE/MM (4.3.03, R$ 5,6 bi) e campanha (4.3.19, zero). Os atípicos vêm da RFB (R$ 3,0 bi de IRPJ/CSLL, a preços de dez/2025). **Dividendos extras de Petrobras e BNDES em 2025 e a capitalização de estatais: não encontrado.** Entram como zero. O SPE calcula os dividendos extras pelo plano estratégico da Petrobras, e não refiz essa conta.
2. **A lista do SPE é mais larga que "evento grande".** Ela inclui compensação da desoneração da folha (2012-2022, até R$ 25 bi/ano), PSI caixa x competência, Auxílio CDE, antecipação de dividendos 2012/13 e "receitas atípicas RFB" (REFIS etc.) em quase todos os anos. Um leitor pode discordar de alguns desses itens: as colunas `rec_*` e `desp_*` deixam refazer a conta sem eles.
3. **Pandemia**: o SPE tira R$ 429,6 bi (2020) e R$ 117,2 bi (2021) de créditos extraordinários, mas devolve R$ 64,1 bi e R$ 60,6 bi como gasto recorrente com transferência de renda (linha "Ajustes Gastos BF"), porque o novo patamar do Bolsa Família ficou.
4. **Precatórios de 2023**: o SPE **não** tira os R$ 92,4 bi. Ele só redistribui entre anos: −15,8 bi em 2022, +48,1 bi em 2023 e −32,3 bi em 2024. Na soma dos três anos o efeito é zero.
5. **Pedaladas de 2015**: o RTN (caixa) diz que foram pagos R$ 55,6 bi de passivos. O SPE usa R$ 45,9 bi, que vêm do BCB (competência). No recorrente vale o número do SPE.
6. **Transação tributária e CARF (2024-2025)**: o SPE não trata como não recorrente. Na série da RFB não achei total anual, só a menção de R$ 2,08 bi em dez/2025. Ficam listados com valor vazio.
7. A compensação de ICMS da LC 194/2022 está listada à parte com os valores do RTN: R$ 7,7 bi em 2022 e R$ 14,8 bi em 2023. No recorrente ela não entra além do que o SPE já põe em "Apoio financeiro EE/MM" (R$ 6,3 bi em 2022 e R$ 12,3 bi em 2023). O SPE não diz quanto da compensação está nessa linha.

# Confere se um trecho literal esta num arquivo baixado (frente N2).
# Uso: python3 -I confere.py <arquivo> "<trecho>"
# Normalizacao (a mesma do build_N2.py): HTML sem script/style e sem tags, entidades resolvidas; JSON recarregado sem escapes
# unicode; PDF pelo pymupdf (ou pdftotext); travessoes viram hifen; espacos em branco colapsados em um so. A busca ignora maiusculas e minusculas.
import html, json, os, re, subprocess, sys

_cache = {}
PDFTOOLS = os.environ.get('PDFTOOLS', os.path.expanduser('~/.local/lib/pdftools'))   # onde esta o pymupdf na maquina de origem


def _pdf(caminho):
    # texto do PDF pelo pymupdf, pagina a pagina; sem pymupdf, cai para o pdftotext do poppler
    try:
        if PDFTOOLS not in sys.path:
            sys.path.append(PDFTOOLS)
        import pymupdf
        doc = pymupdf.open(caminho)
        return '\n\n'.join(p.get_text() for p in doc)
    except ImportError:
        bruto = subprocess.run(['pdftotext', caminho, '-'], capture_output=True).stdout
        return bruto.decode('utf-8', 'replace')


def texto(caminho):
    if caminho in _cache:
        return _cache[caminho]
    if caminho.lower().endswith('.pdf'):
        t = _pdf(caminho)
    else:
        b = open(caminho, 'rb').read()
        t = None
        for enc in ('utf-8', 'cp1252', 'latin-1'):
            try:
                t = b.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        low = caminho.lower()
        if low.endswith('.json'):
            try:
                t = json.dumps(json.loads(t), ensure_ascii=False)
            except ValueError:
                pass
        elif low.endswith(('.htm', '.html', '.xml')) or '<html' in t[:2000].lower():
            t = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', t)
            t = re.sub(r'(?s)<[^>]+>', ' ', t)
            t = html.unescape(t)
    t = re.sub(r'\s+', ' ', t.replace('\xa0', ' ').replace('\u2014', '-').replace('\u2013', '-'))
    _cache[caminho] = t
    return t


def norm(s):
    return re.sub(r'\s+', ' ', s.replace('\xa0', ' ').replace('\u2014', '-').replace('\u2013', '-')).strip().lower()


def contem(caminho, trecho):
    return norm(trecho) in texto(caminho).lower()


if __name__ == '__main__':
    arq, tr = sys.argv[1], sys.argv[2]
    ok = contem(arq, tr)
    print('OK' if ok else 'NAO ENCONTRADO')
    sys.exit(0 if ok else 1)

# Frente N2: estudo de eventos fiscais (protocolo de pré-análise do brief v11)

## 1. Detalhamento operacional fixado antes de rodar qualquer retorno

Escrito em 19/10/2026 às 17:45 (horário de Brasília), antes de montar o inventário e antes de calcular qualquer retorno.
O brief v11 fixa o desenho. Esta seção só decide o que o brief deixa aberto. Nada daqui muda depois de ver os números.
Desvio posterior, se houver, vai para a seção 4, com o motivo.

O que já era visto antes desta seção: as variações de t-5 a t+5 dos 13 eventos da frente N (N-eventos-fiscais.csv), que
estavam no material de partida. A direção desses 13 eventos é decidida pelo conteúdo do ato, como a de todos os outros.

### 1.1 Inventário
- Período: eventos de 01/01/2015 a 15/10/2026 (último dia do Tesouro Direto no bruto da frente N).
- Entra (a) anúncio oficial do Executivo de proposta fiscal com impacto oficial estimado de pelo menos 0,1% do PIB: anúncio
  público do presidente ou do ministro da Fazenda, Economia ou Planejamento, envio formal de proposição ao Congresso, edição de
  MP ou decreto. Entra (b) cada votação de mérito em plenário dessa medida, na Câmara, no Senado ou em sessão do Congresso
  (para PLN de meta). Turnos de PEC contam separados. Texto-base e destaques do mesmo dia são um evento. Votação em comissão e
  votação de requerimento ou de procedimento não entram. Entra (c) a promulgação de emenda constitucional e a sanção de lei
  ou lei complementar com esse impacto.
- Impacto: estimativa oficial (exposição de motivos, Fazenda, Economia, Planejamento, Tesouro, Agência Câmara, Agência Senado,
  consultorias legislativas, IFI). Vale o efeito anual, no primeiro ano cheio de vigência. Se a fonte só der um total de vários
  anos, vale a média anual (total dividido pelo número de anos). Divide-se pelo PIB nominal do IBGE do ano de referência. Mudança
  de meta vale pela diferença entre a meta nova e a antiga.
- Ficam fora: receita extraordinária não recorrente (parcelamento especial, leilão, concessão, cessão onerosa), contingenciamento
  e bloqueio bimestral, leis orçamentárias que não mudam a meta, medidas sem estimativa oficial localizada. Cada candidato
  excluído fica listado com o motivo em `excluidos.tsv`.
- Direção, pelo conteúdo do ato e antes de ver qualquer retorno: melhora = o efeito primário oficial aumenta o resultado
  primário (corte de despesa, receita nova, regra mais restritiva, meta mais alta); piora = o contrário; neutra = a estimativa
  oficial de efeito líquido é nula (medida compensada). Casos de conteúdo misto ficam marcados em `direcao_ambigua`.
- Sinal esperado: em melhora, juro real, inflação implícita, prefixado e câmbio (R$ por US$) caem; em piora, sobem.
- Cada data e cada impacto do inventário vêm com arquivo baixado e um trecho literal que o build confere no arquivo.

### 1.2 Indicadores e janelas
- Principais: juro real de 10 anos constantes e inflação implícita de 10 anos (`brutos/N/diario_td.csv`, Taxa Compra Manhã do
  Tesouro Direto, vértice de 10 anos interpolado, em pontos-base). Secundários: prefixado de 10 anos (mesma fonte) e câmbio
  (DEXBZUS do FRED, variação do logaritmo em %, tomando no dia do TD o último valor disponível até essa data).
- t0 = primeiro dia com cotação TD na data do evento ou depois. Variação na janela h = valor em t0+h menos valor em t0-1, em
  dias com cotação TD. h = 1 é a principal (t-1 a t+1), h = 5 é robustez, h = 20 e h = 60 medem persistência.
- A taxa TD é da manhã. Por isso a janela parte de t-1 e o dia seguinte ao evento entra: votação à tarde ou anúncio à noite
  só aparece na taxa da manhã seguinte.

### 1.3 Retorno anormal
- Controles: DFII10 (pb), VIX (pontos) e logaritmo do dólar amplo DTWEXBGS (em %), do FRED, diários, mais intercepto. Cada
  controle entra com o valor do último dia útil americano estritamente anterior à data do TD (a taxa da manhã no Brasil só
  conhece o fechamento americano da véspera). A variação do controle é medida na mesma janela do indicador.
- Estimação por MQO, para cada data (evento ou placebo), cada indicador e cada h, nas datas s de t0-250-h a t0-11-h, de modo
  que a janela de estimação acaba antes de t0-10. Saem da estimação os s a 10 dias com cotação ou menos de qualquer evento do
  inventário. Com menos de 100 observações, o retorno anormal fica vazio.
- Retorno anormal = variação observada menos a prevista pelos controles (com intercepto).

### 1.4 Placebo e inferência
- 1.000 datas sorteadas sem reposição, semente 20261019, entre os dias com cotação TD de 2015 a 2026 que estão a mais de 10 dias
  com cotação de qualquer evento do inventário. As mesmas datas valem para todos os indicadores e janelas. A conta é a mesma dos
  eventos.
- Para cada evento: percentil do retorno anormal com sinal na distribuição placebo e p-valor bilateral
  p = (1 + número de placebos com |RA| >= |RA do evento|) / (1 + número de placebos válidos).
- "Passa do percentil 95" = |RA| acima do percentil 95 de |RA placebo|. Esperado por acaso: 5% dos eventos, teste binomial.
- Correção para testes múltiplos: Holm e Benjamini-Hochberg, os dois declarados. A família principal é eventos (datas TD únicas)
  vezes {juro real 10a, inflação implícita 10a}, na janela de 1 dia. As demais combinações de indicador e janela levam a correção
  dentro da própria família, só como robustez.
- Eventos que caem no mesmo t0 têm o mesmo retorno. Nas contagens, nos grupos e na correção, cada t0 conta uma vez por grupo.

### 1.5 Grupos e assimetria
- Grupos: anúncio, votação, promulgação; melhora, piora. Também o retorno alinhado (RA vezes +1 em piora e -1 em melhora), cuja
  média é positiva se o mercado reage no sentido esperado.
- Intervalo pelo placebo: 1.000 sorteios, com reposição, de n retornos placebo (n = tamanho do grupo). Faixa nula = percentis
  2,5 e 97,5 da média sorteada. Intervalo da média do grupo = média menos os percentis 97,5 e 2,5 da faixa nula. p = fração de
  médias sorteadas com módulo maior ou igual ao da média do grupo.
- Teste de assimetria: estatística = média de RA em piora + média de RA em melhora (zero se o efeito da piora for do mesmo
  tamanho que o da melhora, com sinal trocado). A nula vem de sorteios de n_piora e n_melhora placebos. Teste de direção à parte:
  média de RA em piora menos média de RA em melhora (positivo no sentido esperado).

### 1.6 Surpresa no Focus
- Focus, ExpectativasMercadoAnuais, "Resultado primário", baseCalculo 0 (últimos 30 dias, o número do relatório), mediana, ano
  de referência = ano do evento + 1. Série semanal = a observação de sexta-feira (ou do último dia útil da semana com dado).
- Surpresa = mediana na primeira observação semanal com data posterior ao evento menos a mediana na última com data anterior,
  em pontos do PIB (positivo = mercado passou a esperar primário maior). Robustez: a quarta observação semanal depois.
- A mesma conta nas 1.000 datas placebo dá a variação de uma semana comum. Surpresa mensurável = |surpresa| acima do percentil
  95 de |surpresa placebo|. Menos de 5 eventos com surpresa mensurável = surpresas não mensuráveis.
- Razão = RA de 1 dia (pb) dividido pela surpresa (pontos do PIB), por evento com surpresa mensurável. Intervalo = (RA menos os
  percentis 97,5 e 2,5 do RA placebo) dividido pela surpresa. Razão agregada = MQO sem intercepto de RA contra surpresa nos
  eventos com surpresa mensurável; intervalo pela nula de 1.000 sorteios de RA placebo nos mesmos eventos. Sinal esperado da razão:
  negativo (mais primário esperado, juro menor).

### 1.7 Regra de parada e classes
- Os retornos são distinguíveis do placebo se pelo menos uma destas vale: (i) algum par evento-indicador da família principal com
  BH q <= 0,10; (ii) o número de passagens do percentil 95 na família principal tem p binomial < 0,05; (iii) alguma das quatro
  médias alinhadas (melhora e piora, juro real e implícita, 1 dia) fora da faixa nula com Holm a 5% entre as quatro.
- Classe C (inconclusivo): retornos indistinguíveis do placebo ou surpresas não mensuráveis. Não se reporta coeficiente.
- Classe B: distinguíveis e surpresas mensuráveis, mas o intervalo da razão agregada inclui zero ou tem o sinal trocado.
- Classe A: distinguíveis, surpresas mensuráveis e razão agregada com intervalo que exclui zero, no sinal esperado.

## 2. Como rodar

```
cd /tmp && python3 gastos-publicos-brasil-dados/brutos/N2/build_N2.py
```

As tabelas dos lotes (`fontes/P*/eventos_P*.tsv`, `excluidos_P*.tsv`, `downloads_P*.tsv`) já trazem os acréscimos da noite de 19/10. Para
refazê-las do zero: os montadores dos lotes (`lotes/monta_P5.py`, `lotes/p4/build.py`), depois `python3 lotes/acrescimos_camara.py`
(idempotente) e `python3 lotes/triagem_camara.py`.

Precisa de numpy e pandas, que estão no site-packages do usuário. Por isso o script não roda com `-I`. Rode de fora da
pasta dos dados. O script é determinístico: duas rodadas seguidas dão o mesmo md5 nos quatro CSV. Antes de calcular, ele confere
cada trecho de data e de impacto no arquivo citado (`confere.py`) e para se algum não bater.

| arquivo | conteúdo |
|---|---|
| `../../N2-eventos.csv` | inventário: 214 eventos de 65 medidas, 183 dias de pregão distintos |
| `../../N2-retornos.csv` | um registro por evento e indicador: variações, RA, percentil, p, Holm, BH, persistência em 20 e 60 dias |
| `../../N2-surpresa.csv` | surpresa no Focus e razão RA/surpresa por evento |
| `../../N2-resumo.csv` | grupos, assimetria, passagens do P95, razão agregada, regra de parada |
| `excluidos.tsv` | 94 candidatos fora, com o motivo |
| `placebo_datas.csv` | as 1.000 datas placebo |
| `downloads.tsv` | 847 linhas: arquivos baixados pelos lotes e insumos lidos de outras frentes |
| `fontes/P1` a `fontes/P5` | brutos e tabelas de cada lote (2015-16, 2017-19, 2020-22, 2023, 2024-26) |
| `fontes/P2/triagem_camara_P2.tsv`, `fontes/P4/triagem_camara_P4.tsv` | triagem das votações do Plenário da Câmara de 2017-2019 e de 2023, uma linha por proposição, com a decisão |
| `lotes/acrescimos_camara.py`, `lotes/triagem_camara.py` | acréscimos ao inventário depois do bloqueio da Câmara e a triagem (ver desvio 6) |

## 3. Resultado

Números da noite de 19/10/2026, com os acréscimos do desvio 6. A família principal é juro real e inflação implícita de 10 anos, na janela de 1 dia.

- **Passagens do percentil 95.** 35 dos 366 testes passam do P95 do placebo (18 no juro real e 17 na implícita). Por acaso
  seriam 18,3. O p binomial é 0,0002, mas supõe testes independentes, e aqui eles não são (ver limitações).
- **Correção para testes múltiplos.** Nenhum par evento-indicador sobrevive. O menor q de BH é 0,31, em três pares empatados (anúncio
  dos JCP pela MP 694 em 30/09/2015, implícita a -53 pb; anúncio do auxílio emergencial em 18/03/2020, juro real e implícita). Com Holm também não sobra nenhum.
- **Grupos, 1 dia, intervalo pelo placebo:**

  | grupo | juro real (pb) | inflação implícita (pb) |
  |---|---|---|
  | anúncio | +3,5 [0,7; 7,1] | +1,8 [-1,3; 4,5] |
  | votação | -1,3 [-3,5; 1,3] | -3,6 [-6,2; -1,6] |
  | promulgação | -0,8 [-4,4; 2,9] | 0,0 [-3,6; 3,5] |
  | melhora | +0,5 [-2,0; 3,3] | 0,0 [-2,8; 2,4] |
  | piora | +0,6 [-1,4; 3,0] | -1,7 [-3,9; 0,2] |

  - Retorno alinhado ao sinal esperado: juro real -0,3 [-2,1; 1,4] e implícita -1,3 [-3,0; 0,5]. Nenhuma das quatro médias
    alinhadas de melhora e piora sai da faixa nula; com Holm, o menor p é 0,60.
- **Assimetria e direção.** A assimetria (média da piora mais média da melhora) dá +1,1 pb [-1,8; 5,0] no juro real e -1,7 pb
  [-5,5; 0,9] na implícita. A direção (piora menos melhora) dá +0,1 e -1,6 pb, com intervalos que cruzam o zero. Em 1 dia, o
  mercado não separa a melhora da piora.
- **Janela de 5 dias (só robustez):**
  - Os anúncios sobem +9,7 pb no juro real e +7,0 pb na implícita, fora da faixa nula.
  - A piora sobe +5,5 pb no juro real, e a melhora +2,1 pb.
  - A soma piora mais melhora dá +7,5 pb no juro real. Não é assimetria: as duas sobem, e com o placebo casado por trimestre
    a soma não se distingue (p = 0,08).
  - Essas contas não entram na regra de parada e não estão corrigidas para testes múltiplos.
- **Surpresa no Focus.**
  - Com 30 eventos (23 dias distintos), a mudança semanal da mediana do primário passa do P95 placebo (0,10 ponto do PIB).
  - Razão agregada: +1,4 pb por ponto do PIB no juro real [-19,1; 21,0] e +15,2 na implícita [-4,0; 36,0]. O sinal esperado é
    negativo, e os dois intervalos cruzam o zero.
- **Regra de parada: classe B.** Pelo critério (ii) os retornos são distinguíveis do placebo, e há surpresas mensuráveis. Mas a
  razão agregada tem intervalo que inclui o zero, então não se reporta coeficiente.

**Leitura honesta.**
- Em datas fiscais, o juro longo se mexe mais do que num dia qualquer: há o dobro de passagens do P95.
- Só que nenhum evento resiste à correção, e o sentido do movimento não acompanha o conteúdo fiscal do ato: melhora e piora dão
  médias iguais.
- A classe B vem só da contagem de passagens. Ela sai de um binomial que supõe independência e de um placebo que não casa a
  volatilidade de cada época, e os eventos se concentram em períodos agitados (2015, 2020, dez/2024). Uma contagem assim é
  compatível com "dias de evento caem em épocas de mais volatilidade", sem efeito causal do conteúdo fiscal.
- Placebo casado por trimestre (cada evento trocado por um dia sem evento do mesmo trimestre, 2.000 sorteios, script da
  auditoria v11 rodado de novo com o inventário acrescido): 35 passagens contra 24,0 esperadas, p = 0,03. Separando os
  indicadores, o juro real fica em 18 contra 9,8 (p = 0,006) e a implícita em 17 contra 14,1 (p = 0,25). A época explica parte
  do excesso, e o que sobra é só no juro real.
- Para o relatório, o resultado prudente é B no limite de C. O mercado reage a datas fiscais com mais ruído, mas não há um preço
  mensurável por ponto do PIB de surpresa no primário.

## 4. Desvios do protocolo (com o motivo)

1. **Exclusão em torno de eventos: de 10 para 5 dias com cotação.** Vale para a janela de estimação e para o sorteio do placebo.
   Com 174 datas de evento (inventário de 19/10, antes dos acréscimos do desvio 6), a exclusão de 10 dias deixava só 96 dos 201 eventos e 523 dos 1.000 placebos com 100 observações de
   estimação. Cinco dias ainda cobrem a janela de robustez mais longa (5 dias). A decisão saiu da contagem de cobertura, antes de
   abrir qualquer retorno, média ou p. Do resultado só se via a linha de diagnóstico da classe.
2. **Mínimo de observações na estimação: de 100 para 60.** Com a exclusão de 5 dias, ainda faltavam 35 eventos. Com 60, todos os
   201 eventos e 993 dos 1.000 placebos têm retorno anormal (4 parâmetros, mínimo de 63 observações). O motivo é o mesmo do
   desvio 1, decidido na mesma ordem.
3. **Veto total da desoneração da folha (23/11/2023): fora.** O lote P4 o trazia como anúncio. Veto não é proposta, votação nem
   sanção (regra 1.1). Fica a votação do veto no Congresso, em 14/12/2023. É uma decisão da coordenação, tomada antes dos retornos
   e registrada em `EXCLUSAO_COORD`, no build.
4. **Impacto fora do Executivo, aceito como fonte oficial do Legislativo.**
   - Teto: R$ 77 bi em 2017, cenário do Boletim Legislativo 49 da Consultoria do Senado. A Fazenda não publicou estimativa.
   - LC 194: R$ 65 bi, número que o relator diz que o governo admite (Rádio Senado).
   - PEC 133 e PEC 188: estimativas de líder do governo e do ministro.
   - Arcabouço: 0,5 ponto do PIB, o degrau das metas.
   - Essas linhas estão marcadas na nota ou em `direcao_ambigua`.
5. **Agência Brasil (EBC) como último recurso.** Usada em poucos anúncios em que o gov.br devolveu "Conteúdo Restrito", marcada
   na nota: metas de ago/2017, diesel de mai/2018, pacote de jan/2023, Auxílio de R$ 400 em out/2021.
6. **Inventário completado depois do bloqueio da Câmara (noite de 19/10/2026).** Desde perto das 18h de 19/10/2026, a Câmara
   (dadosabertos, portal e legin) deixou de responder ao IP deste host, depois de varreduras em paralelo dos lotes. Na mesma noite, a partir das 19h, a
   Câmara foi lida pelo túnel VPN, uma requisição por vez com pausa de 2 s.
   O protocolo não mudou. O que entrou, por `lotes/acrescimos_camara.py`, que roda depois dos montadores dos lotes e antes do
   build:
   - Pendências fechadas: anúncio do teto em 24/05/2016 (nota da Fazenda, pelo Internet Archive); envio da PEC 287/2016, com a
     economia de R$ 793 bi em 2018-27 da nota da Fazenda de 26/04/2017, posterior ao envio (a EM não quantifica); votações da
     Câmara das MP 838/2018 (04/09/2018) e 871/2019 (29/05/2019); envio do PL 2385/2023 (05/05/2023); envio do PL 3394/2024
     (30/08/2024, R$ 21 bi em 2025 pela Fazenda, na Agência Câmara); PLP 128/2025 e LC 224/2025 (votações de 17/12/2025 e sanção
     de 26/12/2025, R$ 17 bi pelo relator na Rádio Câmara, como na LC 194 do desvio 4).
   - Varredura sistemática do Plenário da Câmara em 2017-2019 e 2023, que faltava nos lotes P2 e P4: todas as votações do mês
     (65 páginas) e a ementa de cada proposição votada que não fosse só requerimento (522 consultas). A triagem está em
     `fontes/P2/triagem_camara_P2.tsv` e `fontes/P4/triagem_camara_P4.tsv`, uma linha por proposição com a decisão. A decisão
     pela ementa ("sem tema fiscal" ou "tema fiscal sem efeito primário federal evidente de 0,1% do PIB") é julgamento, não
     conta de impacto; as candidatas com chance de passar do corte foram conferidas na exposição de motivos ou em nota oficial.
   - A varredura achou uma medida acima do corte que o lote P4 não tinha: a MP 1170/2023 (reajuste de 9% dos servidores do
     Executivo, R$ 13,82 bi anualizado pela EM), com edição, votações e sanção (4 eventos, piora).
   - E quatro excluídas, com o motivo em `excluidos_P2.tsv`: MP 765/2016 e MP 767/2017 (abaixo do corte pela EM), PL 7626/2017
     (receita não recorrente) e MP 795/2017, o Repetro (ver o desvio 8).
   - Ao todo, 13 eventos a mais (214 em 183 datas, eram 201 em 174). A classe continua B, e a leitura não muda.
   - Limite: a API da Câmara não descreve todas as votações antigas do mesmo jeito (a da MP 795 aparece só como "Mantido o
     texto"), e a busca por ementa pode deixar passar medida com ementa genérica. A triagem reduz a lacuna, não a elimina.
7. **Lote P5 (2024 a 2026).** O build leu as tabelas do P5 como estavam no fim da tarde de 19/10/2026, com todos os trechos conferidos; rodado de novo com os lotes finais, os quatro CSV saíram idênticos.
   O relatório final desse lote não tinha chegado. Se o P5 acrescentar linhas, é preciso rodar o build de novo; o protocolo não muda.

8. **Repetro (MP 795/2017): fora por julgamento.** A Consultoria de Orçamento da Câmara (NT 39/2017, com números da Fazenda)
   soma renúncia de R$ 16,37 bi em 2018, o que passaria do corte. Mas R$ 11,4 bi são do art. 3, que deixa pagar em jan/2018
   diferenças de IRRF de fatos até 2014 com perdão das multas: efeito de uma vez só, do mesmo tipo do parcelamento especial que a
   regra 1.1 deixa fora. Sem ele, 2018 fica em cerca de R$ 5,3 bi (0,08% do PIB) e 2019 em R$ 5,83 bi. A decisão foi tomada pela
   regra, antes de calcular qualquer retorno do Repetro, mas é uma leitura da regra: com o total, a medida entraria com 4 a 5
   eventos de piora (Câmara em 05-06/12/2017, Senado em 12/12, Câmara em 13/12 e sanção em 28/12).

## 5. Limitações

- **Taxa do TD.** É a taxa de compra da manhã de títulos com cupom, não uma curva zero-cupom. O vértice de 10 anos é interpolado
  e a inflação implícita sai de Fisher em títulos com cupom.
- **Dados diários.** Não são intradiários: a janela de 1 dia pega tudo o que aconteceu entre a manhã de t-1 e a de t+1 (Copom,
  exterior, outros atos).
- **Focus semanal.** A mediana de 30 dias reage devagar. Só 30 eventos têm surpresa acima do ruído de uma semana comum, e a
  surpresa de uma semana mistura outras notícias.
- **Antecipação.** Votações e promulgações costumam ser esperadas, e o preço anda antes da data. Isso joga o efeito medido para
  perto de zero, e talvez explique por que só os anúncios destoam em 5 dias.
- **Eventos agrupados.** 201 eventos caem em 174 datas, muitas a 1 ou 2 dias uma da outra (dez/2016, dez/2024). As janelas se
  sobrepõem, os testes não são independentes, e o binomial das passagens e a correção por evento ficam otimistas.
- **Placebo sem casar a época.** O sorteio é uniforme em 2015 a 2026 e não casa a volatilidade do período. Eventos concentrados
  em 2015, 2020 e dez/2024 tendem a passar mais do P95 por causa do regime, não do ato.
- **Impacto heterogêneo.** Há governo central, setor público consolidado e estados, primeiro ano contra média de 10 anos, metas
  contra medidas. O corte de 0,1% do PIB é aproximado nessas bordas.
- **Direção pelo conteúdo do ato.** Não é pela surpresa. Um ato de "melhora" menor do que o esperado é notícia ruim (por exemplo,
  o pacote de nov/2024, anunciado junto da isenção do IR). Isso dilui o teste de direção.


## Correções da auditoria v11
- Omissão: o envio da PEC 287/2016 pelo Executivo (dez/2016) está dentro do período e cabia na regra de anúncio; não entrou porque a fonte da Câmara estava bloqueada. Resolvida na noite de 19/10/2026 (desvio 6).
- A afirmação de assimetria nas janelas de 5 e 20 dias foi retirada do relatório: as melhoras também sobem o juro real, e o resultado não resiste ao placebo casado por trimestre nem à correção.

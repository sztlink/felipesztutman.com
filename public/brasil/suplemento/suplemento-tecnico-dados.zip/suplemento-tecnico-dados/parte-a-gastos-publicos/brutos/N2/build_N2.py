# Frente N2: estudo de eventos fiscais pelo protocolo do brief v11 (secao 1 do LEIAME, fixada antes dos resultados).
# Gera, na raiz gastos-publicos/:
#   N2-eventos.csv, N2-retornos.csv, N2-surpresa.csv, N2-resumo.csv
# e, dentro de brutos/N2/: excluidos.tsv, placebo_datas.csv
# Entradas:
#   fontes/P*/eventos_P*.tsv, excluidos_P*.tsv   inventario por periodo, com arquivo e trecho literal de cada data e impacto
#   fontes/ibge/sidra_1846_pib_corrente.json     PIB trimestral a precos correntes (IBGE)
#   ../N/diario_td.csv                           Tesouro Direto diario, vertice de 10 anos (frente N)
#   ../R/DFII10.csv, ../X/dados/VIXCLS.csv, ../X/dados/DTWEXBGS.csv, ../X/dados/DEXBZUS.csv   FRED
#   ../X/dados/focus_primario.json               Focus, resultado primario (Olinda)
#   ../../N-eventos-fiscais.csv                  inventario da frente N (so para marcar o que ja estava la)
# Rodar de fora da pasta dos dados: cd /tmp && python3 -I /caminho/brutos/N2/build_N2.py
import csv, glob, json, math, os, sys, datetime as dt
import numpy as np
import pandas as pd

H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(H, '..', '..'))
B = os.path.abspath(os.path.join(H, '..'))
sys.path.insert(0, H)
import confere  # noqa: E402

SEMENTE = 20261019
N_PLACEBO = 1000
N_SORTEIO_GRUPO = 1000
EXCL = 5             # dias com cotacao em torno de evento fora da estimacao e do placebo (era 10; desvio 1, LEIAME secao 4)
JAN_EST = 250
FIM_EST = 11
MIN_OBS = 60          # era 100; desvio 2, LEIAME secao 4
HS = [1, 5, 20, 60]
INICIO = dt.date(2015, 1, 1)
FIM = dt.date(2026, 10, 15)
CORTE_PIB = 0.1
# decisoes da coordenacao sobre linhas dos lotes, tomadas antes de calcular retornos (LEIAME, secao 4)
EXCLUSAO_COORD = {
    ('desoneracao_folha_lei14784', '2023-11-23', 'anuncio'):
        'veto total nao e anuncio de proposta, votacao de merito nem sancao (regra 1.1); a votacao do veto no Congresso fica',
}
FONTES = os.environ.get('N2_FONTES_TESTE') or os.path.join(H, 'fontes')   # override so para teste do codigo
SAIDA = os.environ.get('N2_SAIDA_TESTE') or ROOT
SAIDA_H = os.environ.get('N2_SAIDA_TESTE') or H

IND = [  # nome, coluna, unidade
    ('juro_real_10a', 'juro_real_10a', 'pb'),
    ('inflacao_implicita_10a', 'inflacao_implicita_10a', 'pb'),
    ('prefixado_10a', 'prefixado_10a', 'pb'),
    ('cambio_brl_usd', 'cambio', '%'),
]
PRINCIPAIS = ['juro_real_10a', 'inflacao_implicita_10a']


def presidente(d):
    if d <= dt.date(2016, 5, 12):
        return 'Dilma'
    if d <= dt.date(2018, 12, 31):
        return 'Temer'
    if d <= dt.date(2022, 12, 31):
        return 'Bolsonaro'
    return 'Lula 3'


def r(x, n=2):
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return ''
    return round(float(x), n)


def limpa(v):
    return v.replace('\u2014', '-').replace('\u2013', '-') if isinstance(v, str) else v


def escreve(caminho, linhas, campos):
    with open(caminho, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=campos, lineterminator='\n')
        w.writeheader()
        for l in linhas:
            w.writerow({k: limpa(l.get(k, '')) for k in campos})


# ---------------------------------------------------------------- PIB
def pib_anual():
    d = json.load(open(os.path.join(H, 'fontes', 'ibge', 'sidra_1846_pib_corrente.json'), encoding='utf-8'))[1:]
    tri = sorted((x['D3C'], float(x['V'])) for x in d if x['V'] not in ('', '-', '...'))
    por_ano = {}
    for cod, v in tri:
        por_ano.setdefault(int(cod[:4]), []).append(v)
    pib = {a: sum(v) / 1000.0 for a, v in por_ano.items() if len(v) == 4}   # R$ bi
    ult4 = sum(v for _, v in tri[-4:]) / 1000.0
    ult_lbl = '%s a %s' % (tri[-4][0], tri[-1][0])
    return pib, ult4, ult_lbl


PIB, PIB_ULT4, PIB_ULT4_LBL = pib_anual()


def pib_de(ano):
    if ano in PIB:
        return PIB[ano], 'IBGE 1846, %d' % ano
    return PIB_ULT4, 'IBGE 1846, 4 trimestres %s (ano %d sem os 4 trimestres)' % (PIB_ULT4_LBL, ano)


# ---------------------------------------------------------------- inventario
def le_tsv(caminho):
    with open(caminho, encoding='utf-8') as f:
        return list(csv.DictReader(f, delimiter='\t', quoting=csv.QUOTE_NONE))


def inventario():
    linhas, excl, falhas = [], [], []
    for arq in sorted(glob.glob(os.path.join(FONTES, 'P*', 'eventos_P*.tsv'))):
        lote = os.path.basename(arq)[8:-4]
        for l in le_tsv(arq):
            l = {k: (v or '').strip() for k, v in l.items()}
            l['lote'] = lote
            for campo in ('data', 'impacto'):
                a, t = l['arquivo_' + campo], l['trecho_' + campo]
                p = os.path.normpath(os.path.join(H, a))
                if not a or not t or not os.path.exists(p) or not confere.contem(p, t):
                    falhas.append('%s %s %s: %s | %s' % (lote, l['data'], l['id_medida'], campo, t[:60]))
            linhas.append(l)
    for arq in sorted(glob.glob(os.path.join(FONTES, 'P*', 'excluidos_P*.tsv'))):
        for l in le_tsv(arq):
            l = {k: (v or '').strip() for k, v in l.items()}
            l['lote'] = os.path.basename(arq)[10:-4]
            excl.append(l)
    if falhas:
        print('TRECHOS NAO CONFERIDOS:', len(falhas))
        for f in falhas:
            print('  ', f)
        sys.exit(1)
    # impacto em % do PIB e corte
    dentro = []
    for l in linhas:
        k = (l['id_medida'], l['data'], l['tipo'])
        if k in EXCLUSAO_COORD:
            excl.append({'id_medida': l['id_medida'], 'ato': l['ato'], 'data_ref': l['data'], 'motivo': EXCLUSAO_COORD[k],
                         'url': l['url_data'], 'arquivo': l['arquivo_data'], 'nota': 'decisao da coordenacao', 'lote': l['lote']})
            continue
        v = float(l['impacto_valor'].replace(',', '.'))
        uni = l['impacto_unidade']
        anos = float(l['impacto_anos'] or 1)
        ano = int(l['impacto_ano_ref'])
        pib, fonte_pib = pib_de(ano)
        if uni == 'pct_pib':
            pct = v
            fonte_pib = 'fonte em % do PIB'
        elif uni == 'rs_bi_ano':
            pct = 100.0 * v / pib
        elif uni == 'rs_bi_total':
            pct = 100.0 * v / anos / pib
        else:
            raise SystemExit('unidade desconhecida: %s' % uni)
        l['impacto_pct_pib'] = abs(pct)
        l['pib_usado'] = fonte_pib
        d = dt.date.fromisoformat(l['data'])
        if abs(pct) + 1e-9 < CORTE_PIB:
            excl.append({'id_medida': l['id_medida'], 'ato': l['ato'], 'data_ref': l['data'],
                         'motivo': 'impacto de %.3f%% do PIB, abaixo do corte de 0,1%% (PIB: %s)' % (abs(pct), fonte_pib),
                         'url': l['url_impacto'], 'arquivo': l['arquivo_impacto'], 'nota': 'cortado no build', 'lote': l['lote']})
            continue
        if not (INICIO <= d <= FIM):
            excl.append({'id_medida': l['id_medida'], 'ato': l['ato'], 'data_ref': l['data'],
                         'motivo': 'fora do periodo de 01/01/2015 a 15/10/2026', 'url': l['url_data'],
                         'arquivo': l['arquivo_data'], 'nota': 'cortado no build', 'lote': l['lote']})
            continue
        dentro.append(l)
    ordem = {'anuncio': 0, 'votacao': 1, 'promulgacao': 2}
    dentro.sort(key=lambda l: (l['data'], ordem.get(l['tipo'], 9), l['id_medida']))
    vistos = {}
    for l in dentro:
        base = '%s_%s_%s_%s' % (l['data'], l['id_medida'], l['tipo'], l['casa'].lower())
        k = vistos.get(base, 0)
        vistos[base] = k + 1
        l['id_evento'] = base if k == 0 else '%s_%d' % (base, k + 1)
    return dentro, excl


# ---------------------------------------------------------------- mercado
def le_fred(caminho, nome):
    s = pd.read_csv(caminho)
    s.columns = ['data', nome]
    s['data'] = pd.to_datetime(s['data'])
    s[nome] = pd.to_numeric(s[nome], errors='coerce')
    return s.dropna().sort_values('data')


def mercado():
    td = pd.read_csv(os.path.join(B, 'N', 'diario_td.csv'))
    td['data'] = pd.to_datetime(td['data'])
    td = td[['data', 'juro_real_10a', 'inflacao_implicita_10a', 'prefixado_10a']].sort_values('data').reset_index(drop=True)
    for c in ('juro_real_10a', 'inflacao_implicita_10a', 'prefixado_10a'):
        td[c] = pd.to_numeric(td[c], errors='coerce') * 100.0   # pb
    fx = le_fred(os.path.join(B, 'X', 'dados', 'DEXBZUS.csv'), 'cambio')
    fx['cambio'] = np.log(fx['cambio']) * 100.0
    td = pd.merge_asof(td, fx, on='data', direction='backward', tolerance=pd.Timedelta(days=4))
    ctr = {'dfii10': (os.path.join(B, 'R', 'DFII10.csv'), 100.0, False),
           'vix': (os.path.join(B, 'X', 'dados', 'VIXCLS.csv'), 1.0, False),
           'dolar_amplo': (os.path.join(B, 'X', 'dados', 'DTWEXBGS.csv'), 100.0, True)}
    for nome, (cam, esc, lg) in ctr.items():
        s = le_fred(cam, nome)
        if lg:
            s[nome] = np.log(s[nome])
        s[nome] = s[nome] * esc
        td = pd.merge_asof(td, s, on='data', direction='backward', allow_exact_matches=False,
                           tolerance=pd.Timedelta(days=5))
    return td


# ---------------------------------------------------------------- regressao
class Estudo:
    def __init__(self, td, idx_eventos):
        self.td = td
        self.n = len(td)
        self.Y = {nome: td[col].to_numpy(float) for nome, col, _ in IND}
        self.X = np.column_stack([td['dfii10'], td['vix'], td['dolar_amplo']]).astype(float)
        ev = np.array(sorted(set(idx_eventos)))
        dist = np.full(self.n, 10 ** 6)
        for e in ev:
            dist = np.minimum(dist, np.abs(np.arange(self.n) - e))
        self.longe = dist > EXCL
        self.dy, self.dx = {}, {}
        for h in HS:
            for nome in self.Y:
                y = self.Y[nome]
                d = np.full(self.n, np.nan)
                d[1:self.n - h] = y[1 + h:] - y[:self.n - h - 1]
                self.dy[(nome, h)] = d
            dx = np.full((self.n, 3), np.nan)
            dx[1:self.n - h] = self.X[1 + h:] - self.X[:self.n - h - 1]
            self.dx[h] = dx

    def ra(self, i, nome, h):
        """variacao observada, retorno anormal, n de obs, r2 para o t0 de indice i"""
        dy, dx = self.dy[(nome, h)], self.dx[h]
        if i - 1 < 0 or i + h >= self.n:
            return np.nan, np.nan, 0, np.nan
        obs = dy[i]
        a, b = max(1, i - JAN_EST - h), i - FIM_EST - h
        if b < a:
            return obs, np.nan, 0, np.nan
        s = np.arange(a, b + 1)
        s = s[self.longe[s]]
        y, x = dy[s], dx[s]
        ok = ~np.isnan(y) & ~np.isnan(x).any(axis=1)
        y, x = y[ok], x[ok]
        if len(y) < MIN_OBS or np.isnan(obs) or np.isnan(dx[i]).any():
            return obs, np.nan, len(y), np.nan
        Xm = np.column_stack([np.ones(len(y)), x])
        beta, *_ = np.linalg.lstsq(Xm, y, rcond=None)
        res = y - Xm @ beta
        r2 = 1 - res.var() / y.var() if y.var() > 0 else np.nan
        prev = np.concatenate([[1.0], dx[i]]) @ beta
        return obs, obs - prev, len(y), r2


def holm(p):
    p = np.asarray(p, float)
    m = len(p)
    o = np.argsort(p)
    adj = np.empty(m)
    run = 0.0
    for k, j in enumerate(o):
        run = max(run, min(1.0, (m - k) * p[j]))
        adj[j] = run
    return adj


def bh(p):
    p = np.asarray(p, float)
    m = len(p)
    o = np.argsort(p)[::-1]
    adj = np.empty(m)
    run = 1.0
    for k, j in enumerate(o):
        rank = m - k
        run = min(run, p[j] * m / rank)
        adj[j] = min(run, 1.0)
    return adj


def binom_cauda(k, n, q=0.05):
    return sum(math.comb(n, j) * q ** j * (1 - q) ** (n - j) for j in range(k, n + 1))


# ---------------------------------------------------------------- Focus
def focus_semanal():
    d = json.load(open(os.path.join(B, 'X', 'dados', 'focus_primario.json'), encoding='utf-8'))['value']
    f = pd.DataFrame([x for x in d if x['baseCalculo'] == 0])
    f['data'] = pd.to_datetime(f['Data'])
    f['ref'] = f['DataReferencia'].astype(int)
    f['semana'] = f['data'].dt.to_period('W-SUN')
    ult = f.groupby('semana')['data'].transform('max')   # sexta-feira ou ultimo dia util da semana com dado
    w = f[f['data'] == ult][['data', 'ref', 'Mediana', 'numeroRespondentes']]
    return w.sort_values('data')


def surpresa(fw, dia, k_depois=1):
    ref = dia.year + 1
    s = fw[fw['ref'] == ref]
    antes = s[s['data'] < pd.Timestamp(dia)]
    depois = s[s['data'] > pd.Timestamp(dia)]
    if antes.empty or len(depois) < k_depois:
        return None
    a, b = antes.iloc[-1], depois.iloc[k_depois - 1]
    return {'ref': ref, 'data_antes': a['data'].date().isoformat(), 'med_antes': float(a['Mediana']),
            'data_depois': b['data'].date().isoformat(), 'med_depois': float(b['Mediana']),
            'surpresa': float(b['Mediana']) - float(a['Mediana']), 'resp_depois': int(b['numeroRespondentes'])}


# ---------------------------------------------------------------- principal
def main():
    eventos, excl = inventario()
    td = mercado()
    datas = td['data'].dt.date.to_numpy()
    pos = {d: i for i, d in enumerate(datas)}

    def t0_de(d):
        j = np.searchsorted(datas, d)
        return int(j) if j < len(datas) else None

    for e in eventos:
        e['_d'] = dt.date.fromisoformat(e['data'])
        e['_i'] = t0_de(e['_d'])
    idx_ev = [e['_i'] for e in eventos if e['_i'] is not None]
    est = Estudo(td, idx_ev)

    # placebo
    cand = np.array([i for i, d in enumerate(datas) if INICIO <= d <= FIM and i >= 1 and est.longe[i]])
    rng = np.random.default_rng(SEMENTE)
    pl_idx = np.sort(rng.choice(cand, size=N_PLACEBO, replace=False))
    escreve(os.path.join(SAIDA_H, 'placebo_datas.csv'),
            [{'data': datas[i].isoformat(), 'presidente': presidente(datas[i])} for i in pl_idx], ['data', 'presidente'])

    PL = {}
    for nome, _, _ in IND:
        for h in HS:
            PL[(nome, h)] = np.array([est.ra(i, nome, h)[1] for i in pl_idx])

    # ---- retornos por evento
    prim_t0 = {}
    for e in eventos:
        prim_t0.setdefault(e['_i'], e['id_evento'])
    linhas_ret = []
    for e in eventos:
        i = e['_i']
        for nome, _, uni in IND:
            l = {'id_evento': e['id_evento'], 'data': e['data'], 'presidente': presidente(e['_d']),
                 't0': datas[i].isoformat() if i is not None else '', 'tipo': e['tipo'], 'direcao': e['direcao'],
                 'indicador': nome, 'unidade': uni,
                 'mesmo_t0_que': '' if prim_t0.get(i) == e['id_evento'] else prim_t0.get(i, '')}
            for h in HS:
                obs, ra, nobs, r2 = est.ra(i, nome, h) if i is not None else (np.nan, np.nan, 0, np.nan)
                pl = PL[(nome, h)]
                pl = pl[~np.isnan(pl)]
                l['var_%dd' % h] = r(obs)
                l['ra_%dd' % h] = r(ra)
                if not np.isnan(ra) and len(pl):
                    l['percentil_%dd' % h] = r(100.0 * np.mean(pl <= ra), 1)
                    l['p_%dd' % h] = r((1 + np.sum(np.abs(pl) >= abs(ra))) / (1 + len(pl)), 4)
                    l['passa_p95_%dd' % h] = 'sim' if abs(ra) > np.percentile(np.abs(pl), 95) else 'nao'
                if h == 1:
                    l['n_estimacao_1d'] = nobs
                    l['r2_estimacao_1d'] = r(r2, 3)
            if e['direcao'] in ('melhora', 'piora') and l['ra_1d'] != '':
                l['ra_alinhado_1d'] = r(l['ra_1d'] * (1 if e['direcao'] == 'piora' else -1))
            linhas_ret.append(l)
    # correcoes: por t0 unico
    for nome, _, _ in IND:
        for h in HS:
            if h > 5:
                continue
            uni = [l for l in linhas_ret if l['indicador'] == nome and not l['mesmo_t0_que'] and l.get('p_%dd' % h, '') != '']
            if not uni:
                continue
            if h == 1 and nome in PRINCIPAIS:
                continue
            ph, pb_ = holm([l['p_%dd' % h] for l in uni]), bh([l['p_%dd' % h] for l in uni])
            for l, a, b in zip(uni, ph, pb_):
                l['holm_%dd' % h], l['bh_%dd' % h] = r(a, 4), r(b, 4)
                l['familia_%dd' % h] = 'robustez: %s, %d dia(s), %d testes' % (nome, h, len(uni))
    fam = [l for l in linhas_ret if l['indicador'] in PRINCIPAIS and not l['mesmo_t0_que'] and l.get('p_1d', '') != '']
    ph, pb_ = holm([l['p_1d'] for l in fam]), bh([l['p_1d'] for l in fam])
    for l, a, b in zip(fam, ph, pb_):
        l['holm_1d'], l['bh_1d'] = r(a, 4), r(b, 4)
        l['familia_1d'] = 'principal: juro real e implicita 10a, 1 dia, %d testes' % len(fam)
    # quem divide t0 herda a correcao do primeiro
    chave = {(l['id_evento'], l['indicador']): l for l in linhas_ret}
    for l in linhas_ret:
        if l['mesmo_t0_que']:
            src = chave[(l['mesmo_t0_que'], l['indicador'])]
            for h in (1, 5):
                for c in ('holm_%dd' % h, 'bh_%dd' % h, 'familia_%dd' % h):
                    if c in src:
                        l[c] = src[c]

    campos_ret = ['id_evento', 'data', 'presidente', 't0', 'tipo', 'direcao', 'indicador', 'unidade', 'mesmo_t0_que']
    for h in HS:
        campos_ret += ['var_%dd' % h, 'ra_%dd' % h, 'percentil_%dd' % h, 'p_%dd' % h, 'passa_p95_%dd' % h]
        if h <= 5:
            campos_ret += ['holm_%dd' % h, 'bh_%dd' % h, 'familia_%dd' % h]
        if h == 1:
            campos_ret += ['ra_alinhado_1d', 'n_estimacao_1d', 'r2_estimacao_1d']
    escreve(os.path.join(SAIDA, 'N2-retornos.csv'), linhas_ret, campos_ret)

    # ---- inventario de saida
    nev = list(csv.DictReader(open(os.path.join(ROOT, 'N-eventos-fiscais.csv'), encoding='utf-8')))
    n_datas = {x['data']: x['evento'] for x in nev}
    usados_n = set()
    linhas_ev = []
    for e in eventos:
        marca = ''
        if e['data'] in n_datas:
            marca = 'sim'
            usados_n.add(e['data'])
        linhas_ev.append(e | {'no_inventario_N': marca})
    # eventos de N sem par de mesma data: procura a 3 dias, mesmo tipo de ato
    for x in nev:
        if x['data'] in usados_n:
            continue
        dn = dt.date.fromisoformat(x['data'])
        for l in linhas_ev:
            if not l['no_inventario_N'] and abs((l['_d'] - dn).days) <= 3:
                l['no_inventario_N'] = 'sim, N usa a data %s' % x['data']
                usados_n.add(x['data'])
                break
    faltam_n = [x['data'] + ' ' + x['evento'] for x in nev if x['data'] not in usados_n]
    for l in linhas_ev:
        l['presidente'] = presidente(l['_d'])
        l['t0'] = datas[l['_i']].isoformat() if l['_i'] is not None else ''
        l['impacto_pct_pib'] = r(l['impacto_pct_pib'], 3)
        if not l['no_inventario_N']:
            l['no_inventario_N'] = 'nao'
    campos_ev = ['id_evento', 'data', 'presidente', 't0', 'tipo', 'casa', 'ato', 'descricao', 'id_medida', 'impacto_texto',
                 'impacto_valor', 'impacto_unidade', 'impacto_anos', 'impacto_ano_ref', 'impacto_pct_pib', 'pib_usado',
                 'direcao', 'direcao_ambigua', 'motivo_direcao', 'horario', 'no_inventario_N', 'url_data', 'arquivo_data',
                 'trecho_data', 'url_impacto', 'arquivo_impacto', 'trecho_impacto', 'nota']
    escreve(os.path.join(SAIDA, 'N2-eventos.csv'), linhas_ev, campos_ev)
    campos_ex = ['id_medida', 'ato', 'data_ref', 'motivo', 'url', 'arquivo', 'nota', 'lote']
    with open(os.path.join(SAIDA_H, 'excluidos.tsv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=campos_ex, delimiter='\t', lineterminator='\n', extrasaction='ignore')
        w.writeheader()
        for x in sorted(excl, key=lambda x: (x.get('data_ref', ''), x.get('id_medida', ''))):
            w.writerow({k: limpa(x.get(k, '')) for k in campos_ex})

    # ---- surpresa
    fw = focus_semanal()
    pl_sur = []
    for i in pl_idx:
        s = surpresa(fw, datas[i])
        pl_sur.append(np.nan if s is None else s['surpresa'])
    pl_sur = np.array(pl_sur)
    lim_sur = float(np.nanpercentile(np.abs(pl_sur), 95))
    ra1 = {(l['id_evento'], l['indicador']): l['ra_1d'] for l in linhas_ret}
    q = {nome: np.nanpercentile(PL[(nome, 1)], [2.5, 97.5]) for nome, _, _ in IND}
    linhas_sur = []
    for e in eventos:
        s = surpresa(fw, e['_d'])
        s4 = surpresa(fw, e['_d'], 4)
        l = {'id_evento': e['id_evento'], 'data': e['data'], 'presidente': presidente(e['_d']), 'tipo': e['tipo'],
             'direcao': e['direcao'], 'mesmo_t0_que': '' if prim_t0.get(e['_i']) == e['id_evento'] else prim_t0.get(e['_i'], ''),
             'limite_mensuravel_pp': r(lim_sur, 3)}
        if s:
            l.update({'ano_ref_focus': s['ref'], 'data_focus_antes': s['data_antes'], 'mediana_antes': s['med_antes'],
                      'data_focus_depois': s['data_depois'], 'mediana_depois': s['med_depois'],
                      'surpresa_pp_pib': r(s['surpresa'], 3), 'respondentes_depois': s['resp_depois'],
                      'mensuravel': 'sim' if abs(s['surpresa']) > lim_sur else 'nao',
                      'percentil_placebo': r(100.0 * np.nanmean(pl_sur <= s['surpresa']), 1)})
        if s4:
            l['data_focus_4a_depois'] = s4['data_depois']
            l['surpresa_4semanas_pp_pib'] = r(s4['surpresa'], 3)
        if s and l['mensuravel'] == 'sim':
            for nome in ('juro_real_10a', 'inflacao_implicita_10a', 'prefixado_10a'):
                ra = ra1.get((e['id_evento'], nome), '')
                if ra == '':
                    continue
                sv = s['surpresa']
                a, b = (ra - q[nome][1]) / sv, (ra - q[nome][0]) / sv
                l['razao_%s_pb_por_pp' % nome] = r(ra / sv, 1)
                l['razao_%s_ic_inf' % nome] = r(min(a, b), 1)
                l['razao_%s_ic_sup' % nome] = r(max(a, b), 1)
        linhas_sur.append(l)
    campos_sur = ['id_evento', 'data', 'presidente', 'tipo', 'direcao', 'mesmo_t0_que', 'ano_ref_focus', 'data_focus_antes',
                  'mediana_antes', 'data_focus_depois', 'mediana_depois', 'surpresa_pp_pib', 'respondentes_depois',
                  'percentil_placebo', 'limite_mensuravel_pp', 'mensuravel', 'data_focus_4a_depois',
                  'surpresa_4semanas_pp_pib']
    for nome in ('juro_real_10a', 'inflacao_implicita_10a', 'prefixado_10a'):
        campos_sur += ['razao_%s_pb_por_pp' % nome, 'razao_%s_ic_inf' % nome, 'razao_%s_ic_sup' % nome]
    escreve(os.path.join(SAIDA, 'N2-surpresa.csv'), linhas_sur, campos_sur)

    # ---- resumo
    rng2 = np.random.default_rng(SEMENTE + 1)
    res = []
    unicos = [l for l in linhas_ret if not l['mesmo_t0_que']]

    def grupo(nome_g, filtro, nome, h, alinhar=False):
        vals = []
        for l in linhas_ret:
            if l['indicador'] != nome or not filtro(l) or l['ra_%dd' % h] == '':
                continue
            sg = (1.0 if l['direcao'] == 'piora' else -1.0) if alinhar else 1.0
            vals.append((l['t0'], l['ra_%dd' % h] * sg, sg))
        vistos, v, sinais = set(), [], []
        for t, x, sg in vals:          # um por t0 dentro do grupo
            if t not in vistos:
                vistos.add(t)
                v.append(x)
                sinais.append(sg)
        v = np.array(v)
        pl = PL[(nome, h)]
        pl = pl[~np.isnan(pl)]
        n = len(v)
        if n == 0:
            return None
        # nula: n placebos sorteados, com os mesmos sinais de alinhamento do grupo
        sort = (rng2.choice(pl, size=(N_SORTEIO_GRUPO, n), replace=True) * np.array(sinais)).mean(axis=1)
        m = v.mean()
        lo, hi = np.percentile(sort, [2.5, 97.5])
        return {'grupo': nome_g, 'indicador': nome, 'janela_dias': h, 'n_datas': n, 'media': r(m),
                'faixa_nula_p2_5': r(lo), 'faixa_nula_p97_5': r(hi), 'ic_p2_5': r(m - hi), 'ic_p97_5': r(m - lo),
                'p_placebo': r(np.mean(np.abs(sort) >= abs(m)), 4), 'fora_da_faixa_nula': 'sim' if (m < lo or m > hi) else 'nao'}

    grupos = [('todos', lambda l: True, False), ('anuncio', lambda l: l['tipo'] == 'anuncio', False),
              ('votacao', lambda l: l['tipo'] == 'votacao', False), ('promulgacao', lambda l: l['tipo'] == 'promulgacao', False),
              ('melhora', lambda l: l['direcao'] == 'melhora', False), ('piora', lambda l: l['direcao'] == 'piora', False),
              ('neutra', lambda l: l['direcao'] == 'neutra', False),
              ('alinhado: melhora e piora', lambda l: l['direcao'] in ('melhora', 'piora'), True),
              ('alinhado: melhora', lambda l: l['direcao'] == 'melhora', True),
              ('alinhado: piora', lambda l: l['direcao'] == 'piora', True)]
    for tipo in ('anuncio', 'votacao', 'promulgacao'):
        grupos.append(('alinhado: %s' % tipo, (lambda t: lambda l: l['tipo'] == t and l['direcao'] in ('melhora', 'piora'))(tipo), True))
    for nome, _, _ in IND:
        for h in HS:
            for g, f, al in grupos:
                x = grupo(g, f, nome, h, al)
                if x:
                    x['unidade'] = dict((a, c) for a, _, c in IND)[nome]
                    res.append(x)

    # assimetria e direcao
    def coleta(nome, h, dire):
        vistos, v = set(), []
        for l in linhas_ret:
            if l['indicador'] == nome and l['direcao'] == dire and l['ra_%dd' % h] != '' and l['t0'] not in vistos:
                vistos.add(l['t0'])
                v.append(l['ra_%dd' % h])
        return np.array(v)
    for nome, _, uni in IND:
        for h in HS:
            p_, m_ = coleta(nome, h, 'piora'), coleta(nome, h, 'melhora')
            if len(p_) == 0 or len(m_) == 0:
                continue
            pl = PL[(nome, h)]
            pl = pl[~np.isnan(pl)]
            sp = rng2.choice(pl, size=(N_SORTEIO_GRUPO, len(p_)), replace=True).mean(axis=1)
            sm = rng2.choice(pl, size=(N_SORTEIO_GRUPO, len(m_)), replace=True).mean(axis=1)
            for g, est_, nula in (('assimetria: media piora + media melhora', p_.mean() + m_.mean(), sp + sm),
                                  ('direcao: media piora - media melhora', p_.mean() - m_.mean(), sp - sm)):
                lo, hi = np.percentile(nula, [2.5, 97.5])
                res.append({'grupo': g, 'indicador': nome, 'unidade': uni, 'janela_dias': h,
                            'n_datas': '%d piora, %d melhora' % (len(p_), len(m_)), 'media': r(est_),
                            'faixa_nula_p2_5': r(lo), 'faixa_nula_p97_5': r(hi), 'ic_p2_5': r(est_ - hi),
                            'ic_p97_5': r(est_ - lo), 'p_placebo': r(np.mean(np.abs(nula) >= abs(est_)), 4),
                            'fora_da_faixa_nula': 'sim' if (est_ < lo or est_ > hi) else 'nao'})

    # passagens do percentil 95
    contagem = {}
    for nome, _, uni in IND:
        for h in (1, 5):
            u = [l for l in unicos if l['indicador'] == nome and l.get('passa_p95_%dd' % h, '') in ('sim', 'nao')]
            k = sum(l['passa_p95_%dd' % h] == 'sim' for l in u)
            contagem[(nome, h)] = (k, len(u))
            res.append({'grupo': 'passagens do percentil 95 do placebo', 'indicador': nome, 'unidade': uni, 'janela_dias': h,
                        'n_datas': len(u), 'media': k, 'esperado_por_acaso': r(0.05 * len(u), 1),
                        'p_placebo': r(binom_cauda(k, len(u)), 4), 'nota': 'media = numero de datas acima do P95; p = binomial P(X>=k), q=0,05'})
    kf = contagem[('juro_real_10a', 1)][0] + contagem[('inflacao_implicita_10a', 1)][0]
    nf = contagem[('juro_real_10a', 1)][1] + contagem[('inflacao_implicita_10a', 1)][1]
    p_bin_fam = binom_cauda(kf, nf)
    res.append({'grupo': 'passagens do percentil 95 do placebo', 'indicador': 'familia principal (juro real e implicita)',
                'unidade': 'pb', 'janela_dias': 1, 'n_datas': nf, 'media': kf, 'esperado_por_acaso': r(0.05 * nf, 1),
                'p_placebo': r(p_bin_fam, 4), 'nota': 'testes = datas x 2 indicadores; binomial supoe independencia'})
    bh_ok = [l for l in fam if l['bh_1d'] <= 0.10]
    holm_ok = [l for l in fam if l['holm_1d'] <= 0.05]
    res.append({'grupo': 'sobreviventes da correcao (familia principal, 1 dia)', 'indicador': 'juro real e implicita',
                'unidade': 'pb', 'janela_dias': 1, 'n_datas': len(fam), 'media': len(bh_ok),
                'nota': 'media = pares com BH q<=0,10; com Holm p<=0,05: %d; pares BH: %s' % (
                    len(holm_ok), '; '.join('%s %s' % (l['id_evento'], l['indicador']) for l in bh_ok))})

    # razao agregada
    sur_ok = [l for l in linhas_sur if l.get('mensuravel') == 'sim' and not l['mesmo_t0_que']]
    razoes = {}
    for nome in ('juro_real_10a', 'inflacao_implicita_10a', 'prefixado_10a'):
        par = [(ra1[(l['id_evento'], nome)], l['surpresa_pp_pib']) for l in sur_ok if ra1.get((l['id_evento'], nome), '') != '']
        if len(par) < 1:
            continue
        a = np.array([p[0] for p in par])
        s = np.array([p[1] for p in par])
        bcoef = float((a * s).sum() / (s * s).sum())
        pl = PL[(nome, 1)]
        pl = pl[~np.isnan(pl)]
        nula = (rng2.choice(pl, size=(N_SORTEIO_GRUPO, len(s)), replace=True) * s).sum(axis=1) / (s * s).sum()
        lo, hi = np.percentile(nula, [2.5, 97.5])
        razoes[nome] = (bcoef, bcoef - hi, bcoef - lo, len(s))
        res.append({'grupo': 'razao agregada RA/surpresa (MQO sem intercepto)', 'indicador': nome, 'unidade': 'pb por ponto do PIB',
                    'janela_dias': 1, 'n_datas': len(s), 'media': r(bcoef, 1), 'faixa_nula_p2_5': r(lo, 1),
                    'faixa_nula_p97_5': r(hi, 1), 'ic_p2_5': r(bcoef - hi, 1), 'ic_p97_5': r(bcoef - lo, 1),
                    'p_placebo': r(np.mean(np.abs(nula) >= abs(bcoef)), 4),
                    'nota': 'so eventos com surpresa mensuravel; sinal esperado negativo'})

    # regra de parada
    al = [x for x in res if x['grupo'] in ('alinhado: melhora', 'alinhado: piora') and x['indicador'] in PRINCIPAIS
          and x['janela_dias'] == 1]
    holm_al = holm([x['p_placebo'] for x in al]) if al else []
    c1 = len(bh_ok) > 0
    c2 = p_bin_fam < 0.05
    c3 = any(p <= 0.05 for p in holm_al)
    disting = c1 or c2 or c3
    n_mens = len(sur_ok)
    mensur = n_mens >= 5
    rz = razoes.get('juro_real_10a')
    rz2 = razoes.get('inflacao_implicita_10a')
    if not disting or not mensur:
        classe = 'C'
    else:
        bons = [x for x in (rz, rz2) if x and x[2] < 0]   # intervalo inteiro abaixo de zero
        classe = 'A' if bons else 'B'
    res.append({'grupo': 'regra de parada', 'indicador': 'classe %s' % classe, 'unidade': '', 'janela_dias': 1,
                'nota': ('(i) BH q<=0,10 em algum par: %s; (ii) binomial das passagens p<0,05: %s (p=%.4f); '
                         '(iii) media alinhada fora da nula com Holm: %s (Holm %s); distinguivel: %s; '
                         'eventos com surpresa mensuravel: %d (minimo 5): %s') % (
                    'sim' if c1 else 'nao', 'sim' if c2 else 'nao', p_bin_fam, 'sim' if c3 else 'nao',
                    ', '.join('%s %s %.4f' % (x['grupo'], x['indicador'], h_) for x, h_ in zip(al, holm_al)),
                    'sim' if disting else 'nao', n_mens, 'sim' if mensur else 'nao')})
    campos_res = ['grupo', 'indicador', 'unidade', 'janela_dias', 'n_datas', 'media', 'faixa_nula_p2_5', 'faixa_nula_p97_5',
                  'ic_p2_5', 'ic_p97_5', 'p_placebo', 'fora_da_faixa_nula', 'esperado_por_acaso', 'nota']
    escreve(os.path.join(SAIDA, 'N2-resumo.csv'), res, campos_res)

    # diagnostico para o LEIAME
    print('eventos', len(eventos), 'datas t0 unicas', len(set(idx_ev)), 'excluidos', len(excl))
    print('eventos de N sem par:', faltam_n)
    print('placebo validos 1d:', {n: int((~np.isnan(PL[(n, 1)])).sum()) for n, _, _ in IND})
    print('limite surpresa mensuravel (P95 placebo):', round(lim_sur, 3), 'eventos mensuraveis', n_mens)
    print('classe', classe)


# ---------------------------------------------------------------- downloads.tsv
FIXOS = [
    ('fontes/ibge/sidra_1846_pib_corrente.json',
     'https://apisidra.ibge.gov.br/values/t/1846/n1/all/v/all/p/all/c11255/90707?formato=json', '2026-10-19',
     'PIB nominal para converter impacto em % do PIB', 'IBGE SIDRA 1846, valores a precos correntes, R$ milhoes, 1996T1 a 2026T2; ano = soma dos 4 trimestres; ano sem os 4 trimestres usa os 4 ultimos'),
    ('../N/diario_td.csv', 'derivado de https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv',
     '2026-10-18', 'juro real, inflacao implicita e prefixado de 10 anos, diarios', 'lido da frente N sem copiar (ver brutos/N/LEIAME.md)'),
    ('../R/DFII10.csv', 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=DFII10', '2026-10-18', 'controle: TIPS 10 anos', 'lido da frente R sem copiar'),
    ('../X/dados/VIXCLS.csv', 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=VIXCLS', '2026-10-19', 'controle: VIX', 'lido da frente X sem copiar'),
    ('../X/dados/DTWEXBGS.csv', 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=DTWEXBGS', '2026-10-19', 'controle: dolar amplo', 'lido da frente X sem copiar; ultimo dado 2026-10-09'),
    ('../X/dados/DEXBZUS.csv', 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=DEXBZUS', '2026-10-19', 'indicador secundario: cambio R$ por US$', 'lido da frente X sem copiar; ultimo dado 2026-10-09'),
    ('../X/dados/focus_primario.json', 'https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais?%24filter=Indicador%20eq%20%27Resultado%20prim%C3%A1rio%27&%24format=json&%24select=Indicador%2CIndicadorDetalhe%2CData%2CDataReferencia%2CMedia%2CMediana%2CnumeroRespondentes%2CbaseCalculo',
     '2026-10-19', 'surpresa: mediana do primario esperado (Focus)', 'lido da frente X sem copiar'),
    ('../../N-eventos-fiscais.csv', 'ver brutos/N/LEIAME.md', '2026-10-18', 'marcar eventos que ja estavam na frente N', 'frente N, so leitura'),
]


def downloads():
    campos = ['arquivo', 'url', 'consulta', 'uso', 'nota']
    linhas = [dict(zip(campos, x)) for x in FIXOS]
    vistos = set(x['arquivo'] for x in linhas)
    for arq in sorted(glob.glob(os.path.join(FONTES, 'P*', 'downloads_P*.tsv'))):
        for l in le_tsv(arq):
            l = {k: (v or '').strip() for k, v in l.items()}
            if l.get('arquivo') and l['arquivo'] not in vistos:
                vistos.add(l['arquivo'])
                linhas.append({k: l.get(k, '') for k in campos})
    with open(os.path.join(SAIDA_H, 'downloads.tsv'), 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=campos, delimiter='\t', lineterminator='\n')
        w.writeheader()
        for l in linhas:
            w.writerow({k: limpa(v) for k, v in l.items()})


if __name__ == '__main__':
    downloads()
    main()

#!/usr/bin/env python3
# Frente EE. Baixa a serie do Orcamento de Investimento (SEST/MGI), um arquivo por vez, com pausa de 4 s.
# Tambem baixa as portarias do 6o bimestre de 2022 a 2025 no DOU (in.gov.br), que trazem o executado do ano por grupo, fonte e empresa.
# O in.gov.br recusa o urllib (403) e aceita o curl com cabecalho de navegador; em 24/10/2026 estava fora do ar, em 27/10 respondeu.
# Falha vai para downloads.tsv com sha256 vazio.
import hashlib, os, subprocess, sys, time, urllib.request, datetime
AQUI = os.path.dirname(os.path.abspath(__file__)); FON = os.path.join(AQUI, 'fontes')
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'
OI = 'https://www.gov.br/gestao/pt-br/assuntos/estatais/central-de-conteudo/guias-e-manuais/dados-e-estatisticas/orcamento-de-investimento/'
ARQ = [
  ('SEST, Orcamento de Investimento executado 2009 a 2021 por grupo de empresas e por fonte (OI - Tabelas_v2)', 'oi-tabelas_v2.pdf', OI + 'oi-tabelas_v2.pdf/@@download/file'),
  ('DOU, Portaria SEST do 6o bimestre de 2022 (executado 2022)', 'dou_oi_6bim2022.html', 'https://www.in.gov.br/web/dou/-/portaria-sest/mgi-n-16-de-27-de-janeiro-de-2023-460781919'),
  ('DOU, Portaria SEST do 6o bimestre de 2023 (executado 2023)', 'dou_oi_6bim2023.html', 'https://www.in.gov.br/web/dou/-/portaria-sest/mgi-n-479-de-29-de-janeiro-de-2024-540354394'),
  ('DOU, Portaria SEST do 6o bimestre de 2024 (executado 2024)', 'dou_oi_6bim2024.html', 'https://www.in.gov.br/web/dou/-/portaria-sest-/mgi-n-709-de-29-de-janeiro-de-2025-609766149'),
  ('DOU, Portaria SEST do 6o bimestre de 2025 (executado 2025)', 'dou_oi_6bim2025.html', 'https://in.gov.br/web/dou/-/portaria-sest/mgi-n-630-de-26-de-janeiro-de-2026-683359728'),
]
so = set(sys.argv[1:])
os.makedirs(FON, exist_ok=True)
tsv = os.path.join(AQUI, 'downloads.tsv')
if not os.path.exists(tsv): open(tsv, 'w').write('data\tdescricao\tarquivo\turl\tsha256\n')
primeiro = True
for d, a, u in ARQ:
  if so and a not in so: continue
  if not primeiro: time.sleep(4)
  primeiro = False
  try:
    if 'in.gov.br' in u:
      dados = subprocess.run(['curl', '-s', '-L', '-f', '-m', '90', '-A', UA, u], check=True, capture_output=True).stdout
      if b'texto-dou' not in dados: raise ValueError('pagina sem o texto do ato')
    else:
      dados = urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=90).read()
  except Exception as e:
    open(tsv, 'a').write(f'{datetime.date.today()}\t{d} (FALHOU: {type(e).__name__} {str(e)[:60]})\t\t{u}\t\n'); print('falhou', a, e); continue
  open(os.path.join(FON, a), 'wb').write(dados)
  h = hashlib.sha256(dados).hexdigest()
  open(tsv, 'a').write(f'{datetime.date.today()}\t{d}\tfontes/{a}\t{u}\t{h}\n')
  print(a, len(dados), h)

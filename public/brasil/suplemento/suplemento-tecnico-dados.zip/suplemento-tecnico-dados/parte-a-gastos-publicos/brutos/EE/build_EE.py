#!/usr/bin/env python3
# Frente EE. Investimento executado das estatais federais no Orcamento de Investimento (OI), por grupo de empresas e por fonte,
# 2009 a 2021 pela tabela da SEST (oi-tabelas_v2.pdf) e 2022 a 2025 pelas portarias SEST do 6o bimestre no DOU (tabelas 02, 06 e
# 10 do anexo, baixadas em 27/10/2026). R$ correntes, R$ de dez/2025 (IPCA dez a dez, SIDRA 1737, a convencao das frentes H e Z)
# e % do PIB (K-primario-recorrente.csv). Presidente data o ano, nao atribui causa.
# O OI cobre as estatais que nao estao no Orcamento Fiscal e da Seguridade (nao dependentes) e so aquisicao de ativo imobilizado.
import csv, json, os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..', '..')
sys.path.insert(0, os.path.expanduser('~/.local/lib/pdftools'))
import fitz
num = lambda v: float(v.replace('.', '')) if v != '-' else 0.0
URL = 'https://www.gov.br/gestao/pt-br/assuntos/estatais/central-de-conteudo/guias-e-manuais/dados-e-estatisticas/orcamento-de-investimento/oi-tabelas_v2.pdf/@@download/file'
t = re.sub(r'\s+', ' ', fitz.open(os.path.join(AQUI, 'fontes', 'oi-tabelas_v2.pdf'))[1].get_text())
ANOS = list(range(2009, 2022))
cab = re.search(r'GRUPOS ((?:\d{4} ){13})', t).group(1).split()
assert [int(a) for a in cab] == ANOS
V = r'((?:(?:\d{1,3}(?:\.\d{3})*|-) ){13})'
def lin(rot, txt):
  return [num(x) for x in re.search(re.escape(rot) + ' ' + V, txt + ' ').group(1).split()]
g = t[t.index('Consolidado por Grupos de Empresas'):t.index('Consolidado por Fontes de Financiamento')]
f = t[t.index('Consolidado por Fontes de Financiamento'):]
GR = [('I - Setor Produtivo Estatal', 'Setor produtivo estatal (total)'), ('Grupo PETROBRAS', 'Grupo Petrobras'), ('Grupo ELETROBRAS', 'Grupo Eletrobras'),
      ('Demais Empresas do SPE', 'Demais empresas do setor produtivo'), ('II - Instituições Financeiras', 'Instituições financeiras (bancos federais, total)'), ('TOTAL (I + II)', 'Total do OI')]
FO = [('Recursos Próprios', 'Recursos próprios'), ('Recursos p/ Aumento do Patrimônio Líquido', 'Aumento do patrimônio líquido (inclui aporte do Tesouro)'),
      ('Operações de Crédito de Longo Prazo', 'Operações de crédito de longo prazo'), ('Outros Recursos de Longo Prazo', 'Outros recursos de longo prazo'), ('TOTAL', 'Total do OI (por fonte)')]
D = {nm: lin(r, g) for r, nm in GR}
F = {nm: lin(r, f) for r, nm in FO}
for i in range(13):  # identidades da tabela
  # a tabela publica milhoes arredondados: tolerancia de 2 milhoes nas somas
  dif = D['Grupo Petrobras'][i] + D['Grupo Eletrobras'][i] + D['Demais empresas do setor produtivo'][i] - D['Setor produtivo estatal (total)'][i]
  assert abs(dif) <= 2 or (ANOS[i] == 2016 and dif == 12), (ANOS[i], dif)  # 2016: as tres linhas somam 12 milhoes a mais que o total publicado
  assert abs(D['Setor produtivo estatal (total)'][i] + D['Instituições financeiras (bancos federais, total)'][i] - D['Total do OI'][i]) <= 2
  assert abs(sum(F[nm][i] for _, nm in FO[:-1]) - F['Total do OI (por fonte)'][i]) <= 2 and F['Total do OI (por fonte)'][i] == D['Total do OI'][i]
import html as _html
def dou_txt(ano):
  s = open(os.path.join(AQUI, 'fontes', 'dou_oi_6bim%d.html' % ano), encoding='utf-8', errors='ignore').read()
  s = s[s.find('texto-dou'):]
  s = re.sub(r'<script.*?</script>', '', s, flags=re.S)
  s = _html.unescape(re.sub(r'<[^>]+>', '|', s))
  return re.sub(r'\|\s*\|+', '|', re.sub(r'[ \t\r\n]+', ' ', s))
reais = lambda x: float(x.replace('.', '').replace(',', '.'))
DOU_URL = {2022: 'https://www.in.gov.br/web/dou/-/portaria-sest/mgi-n-16-de-27-de-janeiro-de-2023-460781919',
           2023: 'https://www.in.gov.br/web/dou/-/portaria-sest/mgi-n-479-de-29-de-janeiro-de-2024-540354394',
           2024: 'https://www.in.gov.br/web/dou/-/portaria-sest-/mgi-n-709-de-29-de-janeiro-de-2025-609766149',
           2025: 'https://in.gov.br/web/dou/-/portaria-sest/mgi-n-630-de-26-de-janeiro-de-2026-683359728'}
DOU_PORT = {2022: 'Portaria SEST/MGI nº 16, de 27/01/2023', 2023: 'Portaria SEST/MGI nº 479, de 29/01/2024',
            2024: 'Portaria SEST/MGI nº 709, de 29/01/2025', 2025: 'Portaria SEST/MGI nº 630, de 26/01/2026'}
GR_DOU = [('Setor Produtivo Estatal', 'Setor produtivo estatal (total)'), ('Grupo Petrobras', 'Grupo Petrobras'), ('Grupo Eletrobras', 'Grupo Eletrobras'),
          ('Grupo ENBPar', 'Grupo ENBPar'), ('Grupo NAV Brasil', 'Grupo NAV Brasil'), ('Demais Empresas do Setor Produtivo', 'Demais empresas do setor produtivo'),
          ('Setor Financeiro', 'Instituições financeiras (bancos federais, total)'), ('TOTAL', 'Total do OI')]
FO_DOU = [('Recursos Próprios', 'Recursos próprios'), ('Recursos Para Aumento Do Patrimônio Líquido', 'Aumento do patrimônio líquido (inclui aporte do Tesouro)'),
          ('Operações De Crédito De Longo Prazo', 'Operações de crédito de longo prazo'), ('Outros Recursos De Longo Prazo', 'Outros recursos de longo prazo'),
          ('Convênios', 'Convênios'), ('Total', 'Total do OI (por fonte)')]
BANCOS = [(r'Banco do Brasil S\.A\.', 'Banco do Brasil'), (r'Caixa Econômica Federal', 'Caixa'), (r'Banco Nacional de Desenvolvimento Econômico e Social', 'BNDES'),
          (r'Banco do Nordeste do Brasil', 'Banco do Nordeste'), (r'Banco da Amazônia', 'Banco da Amazônia'), (r'Financiadora de Estudos e Projetos', 'Finep')]
DOU = {}
EMPRESAS = []
for ano in (2022, 2023, 2024, 2025):
  s = dou_txt(ano)
  t2 = s[s.find('TABELA 02'):s.find('TABELA 03')]
  g = {}
  for rot, nm in GR_DOU:
    m = re.search(r'\|' + re.escape(rot) + r'\|(?: \|[\d.,-]+\|){3} \|([\d.]+)\|', t2)
    if m: g[nm] = reais(m.group(1)) / 1e6
  partes = [v for k, v in g.items() if k.startswith('Grupo') or k.startswith('Demais')]
  assert abs(sum(partes) - g['Setor produtivo estatal (total)']) < 0.01, (ano, sum(partes), g)
  resto = g['Total do OI'] - g['Setor produtivo estatal (total)'] - g['Instituições financeiras (bancos federais, total)']
  if abs(resto) >= 0.01:
    # 2022: a Tabela 02 deixa Eletronuclear e INB (que iriam para a ENBPar) fora do setor produtivo, mas dentro do total
    g['Fora dos grupos na tabela da SEST'] = resto
  t6 = s[s.find('TABELA 06'):s.find('TABELA 07')]
  f = {}
  for rot, nm in FO_DOU:
    m = re.search(r'\|' + re.escape(rot) + r'\|(?: \|[\d.,]+\|){4} \|([\d.]+)\|', t6)
    if m: f[nm] = reais(m.group(1)) / 1e6
  assert abs(sum(v for k, v in f.items() if k != 'Total do OI (por fonte)') - f['Total do OI (por fonte)']) < 0.01, (ano, f)
  assert abs(f['Total do OI (por fonte)'] - g['Total do OI']) < 0.01, ano
  t10 = s[s.find('TABELA 10'):s.find('TABELA 11')]
  orgao, soma, b = None, 0.0, {}
  for nome, dot, bim, acum in re.findall(r'\|([^|]{3,160}?)\| \|([\d.]+)\| \|([\d.]+)\| \|([\d.]+)\| \|[\d,]+\|', t10):
    nome = nome.strip()
    if nome.upper() == nome and re.match(r'(MINISTÉRIO|PRESIDÊNCIA|SECRETARIA)', nome): orgao = nome; continue
    if nome.upper() == 'TOTAL': continue
    v = reais(acum) / 1e6; soma += v
    EMPRESAS.append(dict(ano=ano, orgao=orgao, empresa=nome, dotacao_atual_rs_mi=round(reais(dot) / 1e6, 2), realizado_ano_rs_mi=round(v, 2),
                         fonte=f'DOU, {DOU_PORT[ano]}, anexo, Tabela 10 ({DOU_URL[ano]})'))
    for rx, bn in BANCOS:
      if re.match(rx, nome): b[bn] = b.get(bn, 0) + v
  assert abs(soma - g['Total do OI']) < 0.05, (ano, soma, g['Total do OI'])
  assert abs(sum(b.values()) - g['Instituições financeiras (bancos federais, total)']) < 0.05, (ano, b)
  DOU[ano] = (g, f, b)
ipca = {x['D3C']: float(x['V']) for x in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:]}
fator = lambda a: ipca['202512'] / ipca['%d12' % a]
PIB = {int(r['ano']): float(r['pib_rs_mi']) for r in csv.DictReader(open(os.path.join(RAIZ, 'K-primario-recorrente.csv'), encoding='utf-8'))}
def presidente(a):
  return 'Lula 2' if a <= 2010 else 'Dilma' if a <= 2015 else 'Dilma/Temer' if a == 2016 else 'Temer' if a <= 2018 else 'Bolsonaro' if a <= 2022 else 'Lula 3'
NOTA = {'Grupo Eletrobras': 'grupo federal até 2021 nesta série; a capitalização com diluição da União é de 2022 (J-desestatizacao.csv), fora do período coberto',
        'Instituições financeiras (bancos federais, total)': 'a tabela da SEST não abre por banco (BB, Caixa, BNDES e demais); o investimento de banco é imobilizado próprio (agências, TI), não crédito',
        'Grupo Petrobras': 'investimento do grupo no OI (imobilizado), não inclui arrendamento; a série oscila com a contabilização de ativos de exploração e produção, sem decomposição na fonte'}
out = []
for bloco, dd in (('grupo de empresas', D), ('fonte de financiamento', F)):
  for nm, vals in dd.items():
    for a, v in zip(ANOS, vals):
      out.append(dict(ano=a, presidente=presidente(a), bloco=bloco, item=nm, valor_rs_mi_correntes=round(v, 1), valor_rs_mi_dez2025=round(v * fator(a), 1),
                      pct_pib=round(100 * v / PIB[a], 3), participacao_no_total_pct=round(100 * v / D['Total do OI'][ANOS.index(a)], 1),
                      classe='A', fonte=f'SEST/MGI, Orçamento de Investimento executado, OI - Tabelas_v2, p. 2 ({URL})',
                      nota=('na fonte, Petrobras, Eletrobras e demais somam R$ 12 mi a mais que o total do setor produtivo em 2016; ' if a == 2016 and bloco == 'grupo de empresas' else '') + NOTA.get(nm, '') + ('; ' if nm in NOTA else '') + 'deflator IPCA dez/dez (SIDRA 1737) até dez/2025; PIB nominal de K-primario-recorrente.csv'))
NOTA_DOU = {'Grupo Eletrobras': 'em 2022 a SEST ainda lista o grupo, que deixa de ser estatal com a capitalização de junho de 2022; a partir de 2023 o que ficou com a União aparece como Grupo ENBPar',
            'Grupo ENBPar': 'ENBPar, Empresa Brasileira de Participações em Energia Nuclear e Binacional, grupo que a SEST lista a partir de 2023; não é comparável ao grupo Eletrobras até 2022',
            'Grupo NAV Brasil': 'grupo aberto pela SEST em 2025 (NAV Brasil e a nova subsidiária ALADA); até 2024 a NAV estava em Demais empresas',
            'Convênios': 'fonte que aparece só em 2025 na tabela da SEST',
            'Fora dos grupos na tabela da SEST': 'diferença entre o total e a soma do setor produtivo com o financeiro na Tabela 02; em 2022 bate com Eletronuclear mais INB na Tabela 10 (empresas que foram para a ENBPar)',
            'Instituições financeiras (bancos federais, total)': 'Setor Financeiro da SEST (7 bancos oficiais); aberto por banco no bloco banco, Tabela 10'}
for ano, (g, f, b) in DOU.items():
  fonte = f'DOU, {DOU_PORT[ano]}, anexo, realizado até o 6º bimestre (Tabelas 02, 06 e 10) ({DOU_URL[ano]})'
  for bloco, dd in (('grupo de empresas', g), ('fonte de financiamento', f), ('banco', b)):
    for nm, v in dd.items():
      out.append(dict(ano=ano, presidente=presidente(ano), bloco=bloco, item=nm, valor_rs_mi_correntes=round(v, 1), valor_rs_mi_dez2025=round(v * fator(ano), 1),
                      pct_pib=round(100 * v / PIB[ano], 3), participacao_no_total_pct=round(100 * v / g['Total do OI'], 1), classe='A', fonte=fonte,
                      nota=NOTA_DOU.get(nm, NOTA.get(nm, '') if nm != 'Grupo Eletrobras' else '') + ('; ' if (nm in NOTA_DOU or nm in NOTA) else '') +
                           'deflator IPCA dez/dez (SIDRA 1737) até dez/2025; PIB nominal de K-primario-recorrente.csv'))
ANOS_TODOS = ANOS + sorted(DOU)
# media por mandato do total e da Petrobras (aritmetica sobre a serie; mandato incompleto quando o periodo corta)
for nm in ('Total do OI', 'Grupo Petrobras', 'Grupo Eletrobras', 'Instituições financeiras (bancos federais, total)', 'Demais empresas do setor produtivo'):
  for pres in dict.fromkeys(presidente(a) for a in ANOS_TODOS):
    L = [r for r in out if r['bloco'] == 'grupo de empresas' and r['item'] == nm and r['presidente'] == pres]
    if not L: continue
    anos = [r['ano'] for r in L]
    out.append(dict(ano=f'{min(anos)}-{max(anos)}', presidente=pres, bloco='média anual por mandato', item=nm, valor_rs_mi_correntes='',
                    valor_rs_mi_dez2025=round(sum(r['valor_rs_mi_dez2025'] for r in L) / len(L), 1), pct_pib=round(sum(r['pct_pib'] for r in L) / len(L), 3),
                    participacao_no_total_pct='', classe='A', fonte='cálculo sobre as linhas anuais deste arquivo',
                    nota=f'{len(L)} anos na série (2009 a 2025); ' + ('Lula 2 só com 2009 e 2010; ' if pres == 'Lula 2' else '') + ('Bolsonaro com 2022, ano da capitalização da Eletrobras; ' if pres == 'Bolsonaro' else '') + ('Lula 3 de 2023 a 2025; ' if pres == 'Lula 3' else '') + 'Dilma/Temer = 2016, ano da troca'))
cab = ['ano', 'presidente', 'bloco', 'item', 'valor_rs_mi_correntes', 'valor_rs_mi_dez2025', 'pct_pib', 'participacao_no_total_pct', 'classe', 'fonte', 'nota']
with open(os.path.join(RAIZ, 'EE-investimento-estatais.csv'), 'w', newline='', encoding='utf-8') as fh:
  w = csv.DictWriter(fh, fieldnames=cab); w.writeheader()
  for r in out: w.writerow(r)
with open(os.path.join(RAIZ, 'EE-oi-por-empresa-2022-2025.csv'), 'w', newline='', encoding='utf-8') as fh:
  w = csv.DictWriter(fh, fieldnames=['ano', 'orgao', 'empresa', 'dotacao_atual_rs_mi', 'realizado_ano_rs_mi', 'fonte']); w.writeheader()
  for r in EMPRESAS: w.writerow(r)
print('EE ok', len(out), [(r['ano'], r['valor_rs_mi_dez2025'], r['pct_pib']) for r in out if r['item'] == 'Total do OI' and r['bloco'] == 'grupo de empresas'])

# Frente EE, investimento das estatais federais não dependentes (Orçamento de Investimento)

Feita em 24/10/2026 (2009 a 2021) e estendida em 27/10/2026 (2022 a 2025). Lacuna aberta desde a v12.6 ("investimento das estatais não dependentes não foi coberto").

## Fonte
- SEST/MGI, "OI - Tabelas_v2": Orçamento de Investimento executado de 2009 a 2021, por grupo de empresas (Petrobras, Eletrobras,
  demais do setor produtivo, instituições financeiras) e por fonte de financiamento, R$ milhões correntes
  (`fontes/oi-tabelas_v2.pdf`, página de dados e estatísticas do OI no gov.br/gestao).
- O OI cobre as estatais cuja programação não está no Orçamento Fiscal e da Seguridade e só a aquisição de ativo imobilizado
  (sem leasing nem benfeitoria em bem da União). Banco investe em imobilizado próprio, não em crédito.

- DOU, portarias SEST/MGI do 6º bimestre, anexo "Orçamento de Investimento, Relatório de Execução Orçamentária": nº 16 de
  27/01/2023 (executado 2022), nº 479 de 29/01/2024 (2023), nº 709 de 29/01/2025 (2024) e nº 630 de 26/01/2026 (2025).
  Lidas as Tabelas 02 (por setor e grupo), 06 (por fonte) e 10 (por órgão e empresa), "Realizado até o 6º bimestre", R$ 1,00.
  O in.gov.br recusa o urllib (403) e aceita o curl com cabeçalho de navegador. Em 24/10/2026 estava fora do ar, em 27/10 respondeu.

## Conferências (build_EE.py para se não baterem)
- Em cada portaria, a soma dos grupos bate com o setor produtivo, as fontes somam o total e o total por fonte é igual ao total por
  grupo. A soma das empresas da Tabela 10 bate com o total, e a soma dos bancos (BB, Caixa, BNDES, BNB, Basa, Finep) bate com o
  setor financeiro.
- Na portaria de 2022 o setor produtivo mais o financeiro dá R$ 1.332,4 mi a menos que o total. A diferença é Eletronuclear
  (R$ 1.321,5 mi) mais INB (R$ 10,9 mi) na Tabela 10, empresas que a SEST deixou fora dos grupos naquele ano. O CSV traz a linha
  "Fora dos grupos na tabela da SEST".
- A Tabela 03 da portaria de 2022 repete o 2021 com total igual ao da SEST (R$ 57.503 mi), mas com Eletrobras de R$ 2.554 mi contra
  R$ 4.087 mi na tabela consolidada, e as linhas dela não somam o total. O CSV usa a tabela consolidada para 2021.

## Mudanças de grupo
- Eletrobras: grupo federal até 2022 nas tabelas da SEST. A capitalização com diluição da União é de 2022 (`J-desestatizacao.csv`).
  De 2023 em diante a SEST lista o Grupo ENBPar (Empresa Brasileira de Participações em Energia Nuclear e Binacional), que não é
  comparável ao grupo Eletrobras.
- Em 2025 a SEST abre o Grupo NAV Brasil (NAV e a nova subsidiária ALADA), que antes ficava em demais empresas.

## O que ficou de fora e por quê
- Por banco e por empresa de 2009 a 2021. A tabela consolidada só traz o total das instituições financeiras. As portarias de 2000
  a 2012 têm links internos quebrados no gov.br (404). Por banco e por empresa só de 2022 a 2025 (`EE-oi-por-empresa-2022-2025.csv`).
- 2000 a 2008. As páginas existem no gov.br/gestao, mas os anexos (resolveuid) dão 404.

## Método
- R$ de dez/2025 pelo IPCA dez a dez (SIDRA 1737, `brutos/N/ibge`), a convenção das frentes H e Z. % do PIB pelo PIB nominal de
  `K-primario-recorrente.csv`. Presidente data o ano (2016 = Dilma/Temer), não atribui causa.
- Média anual por mandato só com os anos da série (Lula 2 com 2009 e 2010, Bolsonaro de 2019 a 2022, Lula 3 de 2023 a 2025).
- Na fonte, as três linhas do setor produtivo somam R$ 12 mi a mais que o total em 2016; o CSV mantém os números publicados.

## Números principais (EE-investimento-estatais.csv)
- Total do OI: 2,13% do PIB em 2009 e 2013 (pico de R$ 220,3 bi de dez/2025 em 2013), 0,90% em 2016, 0,64% em 2021, mínimo da
  série em 2022 (0,51%), depois 0,61% em 2023, 0,82% em 2024 e 0,91% em 2025 (R$ 115,9 bi).
- Petrobras é 82% a 91% do total em todos os anos; 1,92% do PIB em 2010, 0,42% em 2022, 0,82% em 2025.
- Instituições financeiras entre R$ 3,2 bi (2022) e R$ 7,2 bi (2014) de dez/2025 por ano. De 2022 a 2025 Banco do Brasil e Caixa
  fazem de 97% a 99% do investimento dos bancos federais.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/EE/baixa_EE.py
cd /tmp && python3 -I <pacote>/brutos/EE/build_EE.py
```

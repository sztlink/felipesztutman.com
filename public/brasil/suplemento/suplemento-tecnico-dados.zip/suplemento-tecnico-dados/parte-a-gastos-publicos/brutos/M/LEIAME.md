# Frente M: juros do Brasil contra emergentes

Pergunta: o Brasil paga juros altos so contra a OCDE, ou tambem contra emergentes?

## Como rodar

    python3 -I brutos/M/build_M.py            # le do cache em api/
    python3 -I brutos/M/build_M.py --refresh  # rebaixa tudo

Gera `../../M-juros-emergentes.csv` (longo) e `../../M-resumo-2025.csv` (uma linha por pais),
mais `notas-metodologicas-weo.txt` (nota do FMI por pais, copiada da propria resposta da API).
Cada resposta baixada fica em `api/`, e `api/manifesto.json` guarda URL, data de consulta e
status HTTP de cada arquivo. `api/_sondagem_inicial/` sao respostas da primeira sondagem
manual do DataMapper (mesma consulta de 18/10/2026), nao usadas pelo script.

## Fontes (todas consultadas em 18/10/2026)

| Fonte | Edicao | Uso |
|---|---|---|
| FMI WEO via SDMX `api.imf.org/external/sdmx/3.0/data/dataflow/IMF.RES/WEO/+/<pais>.<indicador>.A?attributes=all` (CSV) | World Economic Outlook October 2026, PUBLICATION_DATE 2026-10-13 (rotulo confirmado no campo `source` do DataMapper) | resultado nominal, primario, divida bruta e liquida (% PIB e em moeda), PIB nominal, CPI medio e fim de periodo, crescimento real, e marca `LATEST_ACTUAL_ANNUAL_DATA` que separa observado de projecao |
| FMI DataMapper Fiscal Monitor `imf.org/external/datamapper/api/v1/<ind>` | Fiscal Monitor October 2026 | agregado "Emerging Market and Middle-Income Economies" (FM_EMG) e Advanced Economies; o WEO SDMX devolve vazio para o grupo G1201 |
| FMI DataMapper `ie` | Public Finances in Modern History Database, Dec 2025 | juros BRUTOS pagos, % PIB, ate 2024 |
| BIS `stats.bis.org/api/v2` WS_CBPOL (mensal, fim de periodo) e WS_LONG_CPI (unidade 771, variacao 12 meses) | consulta 18/10/2026 | taxa basica nominal e CPI de dez/2025, taxa real ex post = (1+i)/(1+pi)-1 |

Edicao do WEO: a de outubro de 2026 ja saiu (publicada 13/10/2026), entao ela e a usada.

## Definicoes

- **juros_liquidos_gg = primario menos nominal.** O FMI define o primario como "overall
  balance excluding net interest payment (interest expenditure minus interest revenue)"
  (descricao do indicador GGXONLB_G01_GDP_PT no DataMapper). Logo a diferenca e juro
  LIQUIDO, nao despesa bruta de juros. Para o Brasil isso pesa: juro bruto FPP 2024 = 8,28% do
  PIB (bate com o COFOG 8,3% do relatorio), juro liquido WEO 2024 = 6,0%.
- **juro_implicito** = (GGXONLB menos GGXCNL em moeda nacional, ano t) / GGXWDG em moeda
  nacional no ano t-1. Juro liquido sobre divida bruta, portanto subestima o custo bruto.
  Nao calculado para grupos (sem niveis em moeda).
- **crescimento nominal aproximado** = (1+NGDP_RPCH)(1+PCPIPCH)-1, como pedido.
  Tambem vai a versao pelo PIB nominal (NGDP t / t-1, deflator implicito), que e a correta
  para r menos g; as duas aparecem no resumo.
- **projecao**: `sim` quando o ano e posterior a `LATEST_ACTUAL_ANNUAL_DATA` da serie. India e
  Africa do Sul marcam "FY2024/25"; pelas notas do FMI, FY(t/t+1) entra no ano civil t, logo o
  ultimo observado e 2024. Derivados herdam `sim` se qualquer insumo for projecao. Grupos e
  Fiscal Monitor nao trazem marca: regra assumida, 2026 em diante = projecao (2025 dos grupos
  inclui estimativas de paises como India e Africa do Sul).

## Ressalvas de conceito (governo geral FMI x BCB)

1. **Divida bruta do Brasil no FMI inclui toda a divida federal na carteira do BCB**, mesmo a
   que nao esta em compromissada (nota metodologica do proprio WEO). Por isso FMI 2025 =
   93,3% do PIB contra DBGG do BCB 78,64% (F-divida.csv, SGS 13762).
2. **Juros**: o BCB (NFSP) mede juros nominais apropriados do setor publico consolidado,
   incluindo BCB e estatais, 7,91% do PIB em 2025 (F-divida.csv, SGS 4616; 8,74% sem o swap
   cambial). O FMI mede governo geral, liquido de juros recebidos. Pelas notas do WEO, de 2010 a
   2019 os juros incluem o resultado de reservas e swaps do BCB (Lei 11.803/2008); desde 2020
   nao (Lei 13.820/2019).
3. **Mexico nao e governo geral classico**: o FMI inclui governo central, seguridade,
   estatais (Pemex, CFE) e bancos de desenvolvimento, e EXCLUI estados e municipios. O juro
   mexicano carrega o da Pemex.
4. **Africa do Sul**: divida bruta e so do governo central.
5. **India**: governo geral estimado pelo FMI, dados estaduais com longa defasagem.
6. **Turquia**: juro implicito alto e r menos g muito negativo sao efeito da inflacao
   (CPI medio 2025 = 34,9%); a divida em % do PIB e corroida pela inflacao.
7. COFOG da OCDE (2,2%) e juro bruto; a comparacao justa com o FMI e liquido com liquido
   (WEO) ou bruto com bruto (FPP, que vai so ate 2024).

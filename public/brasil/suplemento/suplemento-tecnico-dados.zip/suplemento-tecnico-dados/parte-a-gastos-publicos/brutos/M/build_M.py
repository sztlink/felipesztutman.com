#!/usr/bin/env python3
"""Frente M: juros do governo geral do Brasil contra emergentes (FMI WEO/FM, BIS).

Idempotente. Baixa cada resposta de API uma vez para ./api/ (com manifesto de URL e
data de consulta) e depois so le de la. --refresh rebaixa tudo.

Saidas (raiz gastos-publicos/):
  M-juros-emergentes.csv  formato longo, 2008 ate o fim das projecoes
  M-resumo-2025.csv       uma linha por pais, ultimo ano observado
"""
import csv
import io
import json
import sys
import time
import urllib.request
from datetime import date
from pathlib import Path

AQUI = Path(__file__).resolve().parent
API = AQUI / "api"
RAIZ = AQUI.parent.parent  # gastos-publicos/
MANIFESTO = API / "manifesto.json"
REFRESH = "--refresh" in sys.argv

ANO_INI = 2008

PAISES = [  # (nome, iso3 FMI, iso2 BIS)
    ("Brasil", "BRA", "BR"), ("Mexico", "MEX", "MX"), ("Colombia", "COL", "CO"),
    ("Chile", "CHL", "CL"), ("Peru", "PER", "PE"), ("Africa do Sul", "ZAF", "ZA"),
    ("India", "IND", "IN"), ("Indonesia", "IDN", "ID"), ("Turquia", "TUR", "TR"),
    ("Polonia", "POL", "PL"), ("Hungria", "HUN", "HU"), ("Estados Unidos", "USA", "US"),
]
# grupos no WEO SDMX (G1201 = Emerging Market and Middle-Income Economies,
# G200 = Emerging Market and Developing Economies, G110 = Advanced Economies)
# G1201 (EMMIE) foi consultado e veio vazio para todas as series: o agregado EMMIE sai do Fiscal Monitor.
GRUPOS_WEO = [("Grupo FMI: Emerging Market and Developing Economies", "G200"),
              ("Grupo FMI: Advanced Economies", "G110")]
# grupos no Fiscal Monitor via DataMapper
GRUPOS_FM = [("Grupo FMI (FM): Emerging Market and Middle-Income Economies", "FM_EMG"),
             ("Grupo FMI (FM): Advanced Economies", "ADVEC")]

IND_WEO = ["GGXCNL_NGDP", "GGXONLB_NGDP", "GGXWDG_NGDP", "GGXWDN_NGDP",
           "PCPIPCH", "PCPIEPCH", "NGDP_RPCH", "GGXCNL", "GGXONLB", "GGXWDG", "NGDP"]
IND_FM = ["GGXCNL_G01_GDP_PT", "GGXONLB_G01_GDP_PT", "G_XWDG_G01_GDP_PT", "GGXWDN_G01_GDP_PT"]
IND_FPP = "ie"  # Public Finances in Modern History: juros pagos (brutos), % PIB

SDMX = ("https://api.imf.org/external/sdmx/3.0/data/dataflow/IMF.RES/WEO/+/"
        "{area}.{ind}.A?attributes=all")
DM = "https://www.imf.org/external/datamapper/api/v1/{ind}"
BIS_POL = ("https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/M.{iso2}"
           "?startPeriod=2025-01&format=csv")
BIS_CPI = ("https://stats.bis.org/api/v2/data/dataflow/BIS/WS_LONG_CPI/1.0/M.{iso2}.771"
           "?startPeriod=2025-01&format=csv")


# ---------------------------------------------------------------- cache
def manifesto():
    if MANIFESTO.exists():
        return json.loads(MANIFESTO.read_text())
    return {}


MAN = manifesto()


def baixa(nome, url, accept=None):
    """Devolve texto da resposta, do cache se ja baixado (com registro no manifesto)."""
    alvo = API / nome
    if alvo.exists() and nome in MAN and not REFRESH:
        return alvo.read_text()
    API.mkdir(exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "curl/8.5.0"})
    if accept:
        req.add_header("Accept", accept)
    for tent in range(4):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                txt = r.read().decode("utf-8")
                status = r.status
            break
        except Exception as e:  # noqa: BLE001
            if tent == 3:
                print(f"falhou {url}: {e}", file=sys.stderr)
                MAN[nome] = {"url": url, "consulta": date.today().isoformat(), "erro": str(e)}
                return None
            time.sleep(3 * (tent + 1))
    alvo.write_text(txt)
    MAN[nome] = {"url": url, "consulta": date.today().isoformat(), "http": status}
    MANIFESTO.write_text(json.dumps(MAN, indent=1, ensure_ascii=False))
    time.sleep(0.3)
    return txt


def fnum(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------- WEO SDMX
WEO = {}       # (area, ind) -> {ano: valor}
WEO_LAST = {}  # (area, ind) -> ultimo ano observado (LATEST_ACTUAL_ANNUAL_DATA)
WEO_URL = {}
WEO_NOTA = {}
EDICAO = None
CSV_ACCEPT = "application/vnd.sdmx.data+csv;version=2.0.0"

for _, area, *_r in [(p[0], p[1]) for p in PAISES] + [(g[0], g[1]) for g in GRUPOS_WEO]:
    for ind in IND_WEO:
        if area.startswith("G") and ind in ("GGXCNL", "GGXONLB", "GGXWDG", "NGDP"):
            continue  # grupos nao tem nivel em moeda
        url = SDMX.format(area=area, ind=ind)
        txt = baixa(f"weo_{area}_{ind}.csv", url, CSV_ACCEPT)
        if not txt or not txt.strip():
            continue
        linhas = list(csv.DictReader(io.StringIO(txt)))
        if not linhas:
            continue
        serie = {}
        for x in linhas:
            v = fnum(x.get("OBS_VALUE"))
            if v is not None:
                serie[int(x["TIME_PERIOD"])] = v
        WEO[(area, ind)] = serie
        WEO_URL[(area, ind)] = url
        la = (linhas[0].get("LATEST_ACTUAL_ANNUAL_DATA") or "").strip()
        # 'FY2024/25' (India, Africa do Sul): pelas notas do FMI, FY(t/t+1) entra no ano civil t
        # (India: FY(t/t+1)=CY(t); Africa do Sul: CY(t)=0.75 FY(t/t+1)+0.25 FY(t-1/t)), logo o
        # ultimo ano civil observado e o primeiro ano do FY.
        if la.startswith("FY") and la[2:6].isdigit():
            la = la[2:6]
        WEO_LAST[(area, ind)] = int(la) if la.isdigit() else None
        WEO_NOTA[(area, ind)] = (linhas[0].get("METHODOLOGY_NOTES") or "").strip()
        pub = linhas[0].get("PUBLICATION_DATE", "")
        if pub and not EDICAO:
            EDICAO = pub[:10]

# edicao: publicacao 2026-10-13 => WEO outubro 2026 (confirmado no campo 'source' do DataMapper)
dm_meta = json.loads(baixa("datamapper_indicators.json",
                           "https://www.imf.org/external/datamapper/api/v1/indicators"))
FONTE_WEO = dm_meta["indicators"]["GGXCNL_NGDP"]["source"]       # "World Economic Outlook (October 2026)"
FONTE_FM = dm_meta["indicators"]["GGXONLB_G01_GDP_PT"]["source"]  # "Fiscal Monitor (October 2026)"
FONTE_FPP = dm_meta["indicators"]["ie"]["source"]
ED_WEO = f"{FONTE_WEO}; SDMX IMF.RES:WEO publicado em {EDICAO}"

# ---------------------------------------------------------------- DataMapper FM e FPP
DMV = {}
for ind in IND_FM + [IND_FPP]:
    txt = baixa(f"dm_{ind}.json", DM.format(ind=ind))
    DMV[ind] = json.loads(txt)["values"][ind]


def dm(ind, area):
    return {int(k): v for k, v in DMV[ind].get(area, {}).items() if v is not None}


# ---------------------------------------------------------------- BIS
BIS = {}
for _n, iso3, iso2 in PAISES:
    pol = baixa(f"bis_cbpol_{iso2}.csv", BIS_POL.format(iso2=iso2))
    cpi = baixa(f"bis_cpi_{iso2}.csv", BIS_CPI.format(iso2=iso2))
    def le(t):
        if not t:
            return {}
        return {x["TIME_PERIOD"]: fnum(x["OBS_VALUE"]) for x in csv.DictReader(io.StringIO(t))
                if fnum(x.get("OBS_VALUE")) is not None}
    BIS[iso3] = {"pol": le(pol), "cpi": le(cpi),
                 "url_pol": BIS_POL.format(iso2=iso2), "url_cpi": BIS_CPI.format(iso2=iso2)}

# ---------------------------------------------------------------- linhas longas
LONGO = []


def add(nome, iso, ano, indicador, valor, unidade, proj, edicao, url):
    if valor is None:
        return
    LONGO.append({"pais": nome, "iso3": iso, "ano": ano, "indicador": indicador,
                  "valor": round(valor, 4), "unidade": unidade,
                  "projecao": "sim" if proj else "nao", "edicao_weo": edicao, "fonte_url": url})


ROTULO = {
    "GGXCNL_NGDP": ("resultado_nominal_gg", "% PIB"),
    "GGXONLB_NGDP": ("resultado_primario_gg", "% PIB"),
    "GGXWDG_NGDP": ("divida_bruta_gg", "% PIB"),
    "GGXWDN_NGDP": ("divida_liquida_gg", "% PIB"),
    "PCPIPCH": ("inflacao_media_cpi", "% a.a."),
    "PCPIEPCH": ("inflacao_fim_periodo_cpi", "% a.a."),
    "NGDP_RPCH": ("crescimento_real_pib", "% a.a."),
}


def proj_de(area, ind, ano):
    la = WEO_LAST.get((area, ind))
    if la is None:
        return ano >= 2026  # sem marca: regra do ano corrente (ver LEIAME)
    return ano > la


RESUMO_DADOS = {}

for nome, area in [(p[0], p[1]) for p in PAISES] + [(g[0], g[1]) for g in GRUPOS_WEO]:
    anos = sorted({a for ind in IND_WEO for a in WEO.get((area, ind), {}) if a >= ANO_INI})
    for ind, (rot, un) in ROTULO.items():
        for a, v in WEO.get((area, ind), {}).items():
            if a >= ANO_INI:
                add(nome, area, a, rot, v, un, proj_de(area, ind, a), ED_WEO, WEO_URL[(area, ind)])
    cnl = WEO.get((area, "GGXCNL_NGDP"), {})
    pb = WEO.get((area, "GGXONLB_NGDP"), {})
    dg = WEO.get((area, "GGXWDG_NGDP"), {})
    pi = WEO.get((area, "PCPIPCH"), {})
    g = WEO.get((area, "NGDP_RPCH"), {})
    lvl_cnl = WEO.get((area, "GGXCNL"), {})
    lvl_pb = WEO.get((area, "GGXONLB"), {})
    lvl_dg = WEO.get((area, "GGXWDG"), {})
    ngdp = WEO.get((area, "NGDP"), {})
    url_d = f"derivado de {WEO_URL.get((area, 'GGXONLB_NGDP'), '')} e {WEO_URL.get((area, 'GGXCNL_NGDP'), '')}"
    por_ano = {}
    for a in anos:
        p = lambda ind: proj_de(area, ind, a)  # noqa: E731
        d = {}
        if a in pb and a in cnl:
            d["juros"] = pb[a] - cnl[a]
            add(nome, area, a, "juros_liquidos_gg (primario - nominal)", d["juros"], "% PIB",
                p("GGXONLB_NGDP") or p("GGXCNL_NGDP"), ED_WEO, url_d)
        # juro implicito: juros liquidos em moeda / divida bruta em moeda do fim do ano anterior
        if a in lvl_pb and a in lvl_cnl and (a - 1) in lvl_dg and lvl_dg[a - 1]:
            d["juro_impl"] = 100 * (lvl_pb[a] - lvl_cnl[a]) / lvl_dg[a - 1]
            add(nome, area, a, "juro_implicito (juros liquidos t / divida bruta t-1)", d["juro_impl"],
                "% a.a.", p("GGXONLB") or p("GGXCNL") or proj_de(area, "GGXWDG", a - 1), ED_WEO,
                f"derivado de niveis GGXONLB, GGXCNL, GGXWDG em moeda nacional ({area})")
        if a in pi and a in g:
            d["gnom_cpi"] = 100 * ((1 + g[a] / 100) * (1 + pi[a] / 100) - 1)
            add(nome, area, a, "crescimento_nominal_aprox ((1+g)(1+pi)-1, CPI medio)", d["gnom_cpi"],
                "% a.a.", p("NGDP_RPCH") or p("PCPIPCH"), ED_WEO, "derivado de NGDP_RPCH e PCPIPCH")
        if a in ngdp and (a - 1) in ngdp:
            d["gnom_pib"] = 100 * (ngdp[a] / ngdp[a - 1] - 1)
            add(nome, area, a, "crescimento_nominal_pib (NGDP t / t-1)", d["gnom_pib"], "% a.a.",
                p("NGDP"), ED_WEO, WEO_URL.get((area, "NGDP"), ""))
        if "juro_impl" in d and "gnom_cpi" in d:
            d["rg_cpi"] = d["juro_impl"] - d["gnom_cpi"]
            add(nome, area, a, "juro_implicito_menos_cresc_nominal_aprox (CPI)", d["rg_cpi"], "p.p.",
                p("GGXONLB") or p("NGDP_RPCH") or p("PCPIPCH"), ED_WEO, "derivado")
        if "juro_impl" in d and "gnom_pib" in d:
            d["rg_pib"] = d["juro_impl"] - d["gnom_pib"]
            add(nome, area, a, "juro_implicito_menos_cresc_nominal_pib (deflator)", d["rg_pib"], "p.p.",
                p("GGXONLB") or p("NGDP"), ED_WEO, "derivado")
        por_ano[a] = d
    RESUMO_DADOS[area] = por_ano

# Fiscal Monitor (grupos e paises) e FPP (juros brutos pagos)
for nome, area in [(p[0], p[1]) for p in PAISES] + GRUPOS_FM:
    pb, cnl = dm("GGXONLB_G01_GDP_PT", area), dm("GGXCNL_G01_GDP_PT", area)
    dg, dn = dm("G_XWDG_G01_GDP_PT", area), dm("GGXWDN_G01_GDP_PT", area)
    eh_grupo = area in ("FM_EMG", "ADVEC")
    if eh_grupo:  # paises ja vem do WEO; para grupos, FM e a unica fonte do agregado EMMIE
        for a, v in pb.items():
            if a >= ANO_INI:
                add(nome, area, a, "resultado_primario_gg", v, "% PIB", a >= 2026, FONTE_FM,
                    DM.format(ind="GGXONLB_G01_GDP_PT"))
        for a, v in cnl.items():
            if a >= ANO_INI:
                add(nome, area, a, "resultado_nominal_gg", v, "% PIB", a >= 2026, FONTE_FM,
                    DM.format(ind="GGXCNL_G01_GDP_PT"))
        for a, v in dg.items():
            if a >= ANO_INI:
                add(nome, area, a, "divida_bruta_gg", v, "% PIB", a >= 2026, FONTE_FM,
                    DM.format(ind="G_XWDG_G01_GDP_PT"))
        for a, v in dn.items():
            if a >= ANO_INI:
                add(nome, area, a, "divida_liquida_gg", v, "% PIB", a >= 2026, FONTE_FM,
                    DM.format(ind="GGXWDN_G01_GDP_PT"))
        for a in sorted(set(pb) & set(cnl)):
            if a >= ANO_INI:
                add(nome, area, a, "juros_liquidos_gg (primario - nominal)", pb[a] - cnl[a], "% PIB",
                    a >= 2026, FONTE_FM, "derivado de GGXONLB_G01_GDP_PT e GGXCNL_G01_GDP_PT")
    for a, v in dm(IND_FPP, area).items():
        if a >= ANO_INI:
            add(nome, area, a, "juros_brutos_pagos (FPP)", v, "% PIB", False, FONTE_FPP,
                DM.format(ind=IND_FPP))

# BIS: juro basico real ex post no fim de 2025
REAL = {}
for nome, iso3, _ in PAISES:
    b = BIS[iso3]
    i, pi = b["pol"].get("2025-12"), b["cpi"].get("2025-12")
    if i is not None:
        add(nome, iso3, 2025, "taxa_basica_nominal_dez2025 (BIS)", i, "% a.a.", False, "BIS WS_CBPOL",
            b["url_pol"])
    if pi is not None:
        add(nome, iso3, 2025, "inflacao_cpi_12m_dez2025 (BIS)", pi, "% a.a.", False, "BIS WS_LONG_CPI",
            b["url_cpi"])
    if i is not None and pi is not None:
        REAL[iso3] = 100 * ((1 + i / 100) / (1 + pi / 100) - 1)
        add(nome, iso3, 2025, "taxa_basica_real_expost_dez2025 ((1+i)/(1+pi)-1)", REAL[iso3], "% a.a.",
            False, "BIS WS_CBPOL e WS_LONG_CPI", "derivado")

LONGO.sort(key=lambda r: (r["iso3"], r["indicador"], r["ano"]))
CAMPOS = ["pais", "iso3", "ano", "indicador", "valor", "unidade", "projecao", "edicao_weo", "fonte_url"]
with open(RAIZ / "M-juros-emergentes.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=CAMPOS)
    w.writeheader()
    w.writerows(LONGO)

# ---------------------------------------------------------------- resumo
RES = []
for nome, area in [(p[0], p[1]) for p in PAISES] + [(g[0], g[1]) for g in GRUPOS_WEO]:
    fiscais = ["GGXCNL_NGDP", "GGXONLB_NGDP", "GGXWDG_NGDP"]
    las = [WEO_LAST.get((area, i)) for i in fiscais if (area, i) in WEO]
    las = [x for x in las if x]
    if not las and not WEO.get((area, "GGXCNL_NGDP")):
        RES.append({"pais": nome, "iso3": area, "nota": "sem dados fiscais no WEO SDMX"})
        continue
    ano = min(las) if las else 2025
    d = RESUMO_DADOS[area].get(ano, {})
    g = lambda ind: WEO.get((area, ind), {}).get(ano)  # noqa: E731
    r = {"pais": nome, "iso3": area, "ano": ano,
         "juros_liquidos_pct_pib": d.get("juros"),
         "primario_pct_pib": g("GGXONLB_NGDP"), "nominal_pct_pib": g("GGXCNL_NGDP"),
         "divida_bruta_pct_pib": g("GGXWDG_NGDP"), "divida_liquida_pct_pib": g("GGXWDN_NGDP"),
         "juro_implicito_pct": d.get("juro_impl"),
         "cresc_nominal_aprox_pct": d.get("gnom_cpi"),
         "juro_menos_cresc_nominal_pp": d.get("rg_cpi"),
         "juro_menos_cresc_nominal_deflator_pp": d.get("rg_pib"),
         "juros_brutos_fpp_2024_pct_pib": dm(IND_FPP, area).get(2024),
         "taxa_basica_real_dez2025_pct": REAL.get(area),
         "edicao_weo": ED_WEO,
         "nota": ("ano = ultimo ano observado (LATEST_ACTUAL_ANNUAL_DATA) das series fiscais; "
                  "juros = liquidos (primario menos nominal)")}
    if area.startswith("G"):
        r["nota"] = "grupo: sem niveis em moeda, juro implicito nao calculado; ano observado sem marca no SDMX, assumido 2025"
    RES.append(r)

# grupo EMMIE do Fiscal Monitor (WEO SDMX nao traz G1201 para as series fiscais)
pb, cnl, dg = dm("GGXONLB_G01_GDP_PT", "FM_EMG"), dm("GGXCNL_G01_GDP_PT", "FM_EMG"), dm("G_XWDG_G01_GDP_PT", "FM_EMG")
dn = dm("GGXWDN_G01_GDP_PT", "FM_EMG")
if 2025 in pb and 2025 in cnl:
    RES.append({"pais": "Grupo FMI (FM): Emerging Market and Middle-Income Economies", "iso3": "FM_EMG",
                "ano": 2025, "juros_liquidos_pct_pib": pb[2025] - cnl[2025],
                "primario_pct_pib": pb[2025], "nominal_pct_pib": cnl[2025],
                "divida_bruta_pct_pib": dg.get(2025), "divida_liquida_pct_pib": dn.get(2025),
                "edicao_weo": FONTE_FM,
                "nota": "Fiscal Monitor via DataMapper; DataMapper nao marca projecao, 2025 tratado como observado/estimativa"})

for r in RES:
    for k, v in list(r.items()):
        if isinstance(v, float):
            r[k] = round(v, 2)
CAMPOS_R = ["pais", "iso3", "ano", "juros_liquidos_pct_pib", "primario_pct_pib", "nominal_pct_pib",
            "divida_bruta_pct_pib", "divida_liquida_pct_pib", "juro_implicito_pct", "cresc_nominal_aprox_pct",
            "juro_menos_cresc_nominal_pp", "juro_menos_cresc_nominal_deflator_pp",
            "juros_brutos_fpp_2024_pct_pib", "taxa_basica_real_dez2025_pct", "edicao_weo", "nota"]
with open(RAIZ / "M-resumo-2025.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=CAMPOS_R)
    w.writeheader()
    w.writerows(RES)

# notas metodologicas do FMI por pais (para o LEIAME e conferencia)
with open(AQUI / "notas-metodologicas-weo.txt", "w") as f:
    for nome, area, _ in PAISES:
        f.write(f"== {nome} ({area}) ultimo observado fiscal: {WEO_LAST.get((area, 'GGXCNL_NGDP'))}\n")
        f.write(WEO_NOTA.get((area, "GGXCNL_NGDP"), "") + "\n\n")

MANIFESTO.write_text(json.dumps(MAN, indent=1, ensure_ascii=False))
print(f"{len(LONGO)} linhas longas, {len(RES)} linhas de resumo; edicao: {ED_WEO}")

#!/usr/bin/env python3
# Juros do governo geral = juro implicito x base da divida. Separa quanto da distancia entre o Brasil e cada emergente
# (e o emergente mediano) vem da taxa e quanto vem do tamanho da divida, pela media dos dois caminhos (Shapley).
# Entrada: M-resumo-2025.csv (FMI WEO out/2026). juro_implicito = juros liquidos do ano / divida bruta do ano anterior,
# entao base = juros / juro_implicito e a divida do ano anterior medida sobre o PIB do ano (identidade exata nos dados).
import csv, os, statistics
RAIZ = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
R = [r for r in csv.DictReader(open(os.path.join(RAIZ, 'M-resumo-2025.csv'), newline='', encoding='utf-8'))
     if r['juro_implicito_pct'] and r['juros_liquidos_pct_pib']]
pt = {r['iso3']: (float(r['juros_liquidos_pct_pib']), float(r['juro_implicito_pct'])) for r in R}
base = lambda j, i: 100 * j / i
br = pt.pop('BRA'); emg = {k: v for k, v in pt.items() if k != 'USA'}
nome = {r['iso3']: r['pais'] for r in R}
med_i = statistics.median(i for _, i in emg.values()); med_s = statistics.median(base(j, i) for j, i in emg.values())

def decomp(i0, s0, i1, s1):
  # (i0, s0) Brasil, (i1, s1) comparador; juros em % do PIB = i x s / 100
  taxa = (i0 - i1) * (s0 + s1) / 2 / 100
  estoque = (s0 - s1) * (i0 + i1) / 2 / 100
  return round(i0 * s0 / 100 - i1 * s1 / 100, 2), round(taxa, 2), round(estoque, 2)

j0, i0 = br; s0 = base(j0, i0)
linhas = []
for k, (j, i) in sorted(pt.items(), key=lambda kv: -kv[1][0]):
  d, t, e = decomp(i0, s0, i, base(j, i))
  linhas.append([nome[k], k, j, i, round(base(j, i), 1), d, t, e, ''])
d, t, e = decomp(i0, s0, med_i, med_s)
linhas.append(['Emergente mediano (taxa mediana x base mediana dos 10)', 'MED', round(med_i * med_s / 100, 2), round(med_i, 2), round(med_s, 1), d, t, e,
               'mediana separada de cada componente; o produto nao e a mediana dos juros'])
with open(os.path.join(RAIZ, 'M-decomposicao-juros.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['comparador', 'iso3', 'juros_pct_pib', 'juro_implicito_pct', 'base_divida_pct_pib', 'brasil_menos_comparador_pp',
              'efeito_taxa_pp', 'efeito_estoque_pp', 'nota'])
  w.writerow(['Brasil', 'BRA', j0, i0, round(s0, 1), '', '', '', 'FMI WEO out/2026; divida bruta do Brasil no FMI inclui os titulos na carteira do BC'])
  w.writerows(linhas)
print('decomp ok', linhas[-1])

#!/usr/bin/env python3
# Frente MK, leitura para quem aloca capital. Curva a termo da ANBIMA contra a Selic do Focus, o que o primario do PLDO 2027 pede
# para ser cumprido, o custo de 1 ponto de IVA pela base da Fazenda e o calendario de 2027 com data, valor e fonte.
# Rodar: cd /tmp && PYTHONPATH=~/.local/lib/pdftools python3 -P <pacote>/brutos/MK/build_MK.py
# A pagina da ANBIMA (fontes/anbima_ettj_cz_*.html) nao vai no pacote (direitos reservados). Sem ela o script pula a curva.
import csv, glob, html, json, os, re, sys
sys.path.insert(0, os.environ.get('PDFTOOLS', os.path.expanduser('~/.local/lib/pdftools')))
import fitz
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes')
num = lambda s: float(s.replace('.', '').replace(',', '.'))
norm = lambda s: re.sub(r'\s+', ' ', s)
def grava(nome, cab, linhas):
  with open(os.path.join(RAIZ, nome), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f, lineterminator='\n'); w.writerow(cab); w.writerows(linhas)
  print(nome, len(linhas))
U_ANB = 'https://www.anbima.com.br/informacoes/est-termo/CZ.asp'
U_PLDO = 'PLDO 2027, Anexo IV.2, metas fiscais (brutos/S/pldo2027-anexo-iv-02-metas-fiscais.pdf)'
U_FOC = 'https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais'

# 1. curva a termo da ANBIMA contra o caminho da Selic no Focus
FO = json.load(open(os.path.join(RAIZ, 'brutos', 'S', 'bcb-focus-olinda-anuais-out2026.json'), encoding='utf-8'))
FO = FO['value'] if isinstance(FO, dict) else FO
selic_fim = {int(r['DataReferencia']): r['Mediana'] for r in FO if r['Indicador'] == 'Selic' and r['Data'] == '2026-10-09' and r['baseCalculo'] == 0}
ipca_ano = {int(r['DataReferencia']): r['Mediana'] for r in FO if r['Indicador'] == 'IPCA' and r['Data'] == '2026-10-09' and r['baseCalculo'] == 0}
W = {r['mes']: r for r in csv.DictReader(open(os.path.join(RAIZ, 'W-curva-mensal.csv'), encoding='utf-8'))}
arqs = sorted(glob.glob(os.path.join(F, 'anbima_ettj_cz_*.html')))
if arqs:
  t = norm(re.sub(r'<[^>]+>', ' ', re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', open(arqs[-1], encoding='latin-1').read())))
  data = re.search(r'Download (\d\d/\d\d/\d{4})', t).group(1)
  bloco = t[t.index('Vértices ETTJ IPCA ETTJ PRE Inflação Implícita') + 46:]
  V = {}
  for m in re.finditer(r'(\d{1,2}\.?\d{3}|\d{3}) (\d+,\d{4}) (\d+,\d{4}) (\d+,\d{4})', bloco):
    du = int(m.group(1).replace('.', '')); V[du] = (num(m.group(2)), num(m.group(3)), num(m.group(4)))
    if du >= 2520: break
  assert all(k in V for k in (252, 504, 756, 1008, 1260)), sorted(V)[:8]
  # caminho mensal da Selic, interpolado entre a media de outubro de 2026 (W) e as medianas de fim de ano do Focus, plano depois de 2030
  d0, m0 = int(data[6:]), int(data[3:5])
  pontos = {(2026, 10): float(W['2026-10']['selic_meta_media_mes'])}
  pontos.update({(a, 12): selic_fim[a] for a in selic_fim}); pontos[(2031, 12)] = selic_fim[2030]
  chaves = sorted(pontos); idx = lambda k: k[0] * 12 + k[1]
  def selic(k):
    for a, b in zip(chaves, chaves[1:]):
      if idx(a) <= idx(k) <= idx(b): return pontos[a] + (pontos[b] - pontos[a]) * (idx(k) - idx(a)) / (idx(b) - idx(a))
  lin = []
  for n in range(1, 6):
    ra, rb = V[252 * (n - 1)][1] if n > 1 else None, V[252 * n][1]
    fw = 100 * (((1 + rb / 100) ** n / ((1 + ra / 100) ** (n - 1) if ra else 1)) - 1)
    qa, qb = (V[252 * (n - 1)][0] if n > 1 else None), V[252 * n][0]
    fr = 100 * (((1 + qb / 100) ** n / ((1 + qa / 100) ** (n - 1) if qa else 1)) - 1)
    meses = [((d0 * 12 + m0 - 1 + 12 * (n - 1) + j) // 12, (m0 - 1 + 12 * (n - 1) + j) % 12 + 1) for j in range(12)]
    sm = sum(selic(k) for k in meses) / 12
    ipj = sum(ipca_ano.get(a, ipca_ano[max(ipca_ano)]) for a, _ in meses) / 12  # IPCA anual do Focus ponderado pelos meses de cada ano na janela
    impl = 100 * ((1 + fw / 100) / (1 + fr / 100) - 1)
    janela = f'{m0:02d}/{d0 + n - 1} a {m0:02d}/{d0 + n}'
    lin.append([n, janela, round(fw, 2), round(sm, 2), round(100 * (fw - sm)), round(fr, 2), round(impl, 2), round(ipj, 2), round(100 * (impl - ipj)), round(100 * (fw - sm) - 100 * (impl - ipj)), data,
                'Focus de 09/10/2026 (fim de ano), interpolado por mes' + ('; depois de dez/2030 supoe a Selic plana' if n == 5 else ''), U_ANB + ' e ' + U_FOC])
  grava('MK-curva-termo.csv', ['ano_a_frente', 'janela', 'taxa_a_termo_prefixada_pct', 'selic_media_focus_pct', 'diferenca_pb',
                               'juro_real_a_termo_pct', 'inflacao_implicita_a_termo_pct', 'ipca_focus_janela_pct', 'diferenca_inflacao_pb', 'diferenca_real_pb', 'data_curva', 'premissa_selic', 'fonte_url'], lin)
else:
  print('pula a curva: falta a pagina da ANBIMA em fontes/ (baixa_MK.py)')

# 2. o que o primario do PLDO 2027 pede
pl = norm(' '.join(p.get_text() for p in fitz.open(os.path.join(RAIZ, 'brutos', 'S', 'pldo2027-anexo-iv-02-metas-fiscais.pdf'))))
A = range(2027, 2031)
def linha(rot, pares=True):
  m = re.search(re.escape(rot) + r' ((?:-?[\d.]+,\d+ ){7}-?[\d.]+,\d+)', pl)
  v = [num(x) for x in m.group(1).split()]
  return {a: (v[2 * i], v[2 * i + 1]) for i, a in enumerate(A)}
lin = []
for rot, chave in (('Governo Central (I)', 'primario_projetado'), ('Governo Central - Exclusão da verificação da Meta de Resultado Primário (II)', 'exclusoes_da_meta'),
                   ('Governo Central - Meta de Resultado Primário', 'meta')):
  for a, (rs, pib) in linha(rot).items(): lin.append([chave, a, rs, pib, 'Tabela 3', U_PLDO])
for rot, chave in (('III - Receita Primária Líquida (I - II)', 'receita_primaria_liquida'), ('IV - Despesa Primária Total', 'despesa_primaria_total')):
  for a, (rs, pib) in linha(rot).items(): lin.append([chave, a, round(rs / 1000, 2), pib, 'Tabela 5 (R$ milhoes no original)', U_PLDO])
m = re.search(r'VII\. Discricionárias líquidas das emendas e dos mínimos \(IV - V - VI\) ((?:[\d.]+,\d+ ){3}[\d.]+,\d+)', pl)
for a, v in zip(A, m.group(1).split()): lin.append(['discricionarias_livres', a, round(num(v) / 1000, 2), '', 'Tabela 8, liquidas de emendas e dos minimos de saude e educacao (R$ milhoes no original)', U_PLDO])
for frase, chave in (('Quanto às receitas de Dividendos, não há previsão de pagamento de destaque para o período de 2027 a 2030', 'dividendos'),
                     ('As receitas de concessões e permissões, no período de 2027 a 2030, consideram apenas os contratos vigentes, não havendo previsão de novas concessões', 'concessoes'),
                     ('a nota técnica que apresenta as estimativas de dividendos é classificada com nível de acesso restrito', 'dividendos_nota_restrita'),
                     ('Foram trazidos para as projeções de arrecadação o efeito de medidas tributárias em estudo, no âmbito do Poder Executivo', 'receita_medidas_em_estudo'),
                     ('sobre as despesas anuais da União com precatórios e requisições de pequeno valor, os projetos estratégicos de defesa e despesas temporárias com saúde e educação com recursos do Fundo Social', 'exclusoes_composicao')):
  assert frase in pl, chave; lin.append([chave, '2027-2030', '', '', frase, U_PLDO])
m = re.search(r'Leilão da Folha do INSS, no valor de R\$ ([\d,]+) bilhões', pl); lin.append(['receita_propria_2027_leilao_folha_inss', 2027, num(m.group(1)), '', 'destaque das receitas proprias de 2027', U_PLDO])
grava('MK-pldo-execucao.csv', ['serie', 'ano', 'valor_rs_bi', 'pct_pib', 'nota', 'fonte'], lin)

# 3. custo de 1 ponto de IVA (IBS mais CBS), conta proporcional sobre a meta de arrecadacao da Fazenda
V_ = {r['item']: r for r in csv.DictReader(open(os.path.join(RAIZ, 'V-reforma-consumo.csv'), encoding='utf-8'))}
meta = float(V_['Premissa: meta de arrecadacao do IVA dual']['valor']); aliq = float(V_['Aliquota total (IBS + CBS) adotada pelo CGIBS como parametro']['valor'])
ibs = float(V_['Parcela IBS adotada pelo CGIBS']['valor'])
pib27 = num(re.search(r'PIB nominal \(R\$ bilhões\) (?:[\d.]+,\d ){2}([\d.]+,\d)', pl).group(1))
assert 'sugere um acréscimo de 1% do PIB em arrecadação para cada 2 pontos adicionais de alíquota' in norm(' '.join(p.get_text() for p in fitz.open(os.path.join(RAIZ, 'brutos', 'V', 'fazenda', 'nota-tecnica-aliquotas_2024-07-01_sertmf-1.pdf'))))
por = meta / aliq
grava('MK-iva-ponto.csv', ['serie', 'valor', 'unidade', 'nota', 'fonte'], [
  ['meta_de_arrecadacao_ibs_cbs', meta, '% do PIB', 'SERT/MF nota de 01/07/2024, p. 5', V_['Premissa: meta de arrecadacao do IVA dual']['fonte_url']],
  ['aliquota_total_cgibs', aliq, '%', f'parametro metodologico do CGIBS para estimar o IBS de 2027, nao e aliquota oficial (CBS {round(aliq - ibs, 2)} e IBS {ibs}), Resolucao CGIBS 14/2026', V_['Aliquota total (IBS + CBS) adotada pelo CGIBS como parametro']['fonte_url']],
  ['arrecadacao_por_ponto', round(por, 3), '% do PIB', 'meta dividida pela aliquota, conta estatica sem efeito de comportamento nem de conformidade', ''],
  ['arrecadacao_por_ponto_rs_bi_2027', round(por / 100 * pib27, 2), 'R$ bi', f'sobre o PIB nominal de 2027 do PLDO (R$ {pib27} bi)', U_PLDO],
  ['padrao_internacional_citado_pela_fazenda', 0.5, '% do PIB por ponto', '1% do PIB a cada 2 pontos, SERT/MF nota de 01/07/2024, p. 14', V_['Premissa: meta de arrecadacao do IVA dual']['fonte_url']]])

# 4. calendario de 2027 com data, valor e fonte (leis e PLDO ja no pacote)
PRB = {(r['serie'], r['ano']): r['valor'] for r in csv.DictReader(open(os.path.join(RAIZ, 'PR-base.csv'), encoding='utf-8'))}
cf = norm(html.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'(?is)<(style|script)[^>]*>.*?</\1>', ' ', open(os.path.join(RAIZ, 'brutos', 'PR', 'fontes', 'planalto_constituicao.htm'), 'rb').read().decode('latin-1')))))
assert 'terá início em 5 de janeiro do ano seguinte ao de sua eleição' in cf and 'devolvido para sanção até o encerramento da sessão legislativa' in cf
P3 = {(r[0], r[1]): r for r in csv.reader(open(os.path.join(RAIZ, 'MK-pldo-execucao.csv'), encoding='utf-8'))}
brn = lambda x, d: f'{x:,.{d}f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
pv = lambda s, c: float(P3[(s, '2027')][c])
grava('MK-calendario.csv', ['ordem', 'data', 'evento', 'valor', 'fonte'], [
  [1, 'até o fim da sessão legislativa de 2026', 'Votação do orçamento de 2027 pelo Congresso', '', 'Constituição, ADCT, art. 35, § 2º, III'],
  [2, '1º/01/2027', 'Novo salário mínimo, pelo INPC até novembro mais o PIB de 2025, com o ganho real limitado pelo arcabouço', f"R$ {brn(float(PRB[('salario_minimo_rs', '2027')]), 0)} na grade do PLDO, R$ {brn(float(PRB[('salario_minimo_lei_atual_focus_rs', '2027')]), 0)} com o Focus", 'Leis 14.663 e 15.077, PLDO 2027'],
  [3, '1º/01/2027', 'Benefícios do INSS acima do piso corrigidos pelo INPC', 'sem ganho real', 'Lei 8.213, art. 41-A'],
  [4, '1º/01/2027', 'CBS cheia no lugar de PIS e Cofins, IPI a zero salvo produtos da Zona Franca', 'ICMS e ISS sem mudança até 2028', 'LC 214'],
  [5, '05/01/2027', 'Posse do presidente eleito', '', 'Constituição, art. 82'],
  [6, '2027', 'Meta de primário do Governo Central', f"{brn(pv('meta', 3), 2)}% do PIB, com R$ {brn(pv('exclusoes_da_meta', 2), 2)} bi de exclusões (precatórios, defesa e Fundo Social) sobre primário projetado de {brn(pv('primario_projetado', 3), 2)}%", 'PLDO 2027, tabela 3'],
  [7, '2027', 'Primeira declaração com a tributação mínima de rendas acima de R$ 600 mil por ano', 'até 10%', 'Lei 15.270, art. 16-A (exercício de 2027, ano-calendário de 2026)'],
  [8, 'até 30/10/2026', 'Cálculo da alíquota de referência da CBS de 2027 enviado pelo TCU ao Senado', 'a CBS de 2027 será essa alíquota menos 0,1 ponto', 'Resolução CGIBS 14/2026, LC 214, art. 347'],
  [9, '1º/01/2027', 'Começa o Imposto Seletivo', 'alíquotas dependem de lei, salvo o teto de 0,25% para bens minerais', 'EC 132 (ADCT art. 126, I), LC 214, art. 422'],
  [10, '2029', 'Começa a troca de ICMS e ISS pelo IBS', 'ICMS e ISS a 90% da alíquota atual', 'LC 214'],
])

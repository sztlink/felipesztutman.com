#!/usr/bin/env python3
# Frente MK. Baixa a curva zero estimada da ANBIMA (pagina publica com os vertices do dia) e registra em downloads.tsv.
# A pagina tem direitos reservados e nao vai no pacote. Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/MK/baixa_MK.py
import datetime, hashlib, os, re, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
U = 'https://www.anbima.com.br/informacoes/est-termo/CZ.asp'
arqs = sorted(f for f in os.listdir(F) if f.startswith('anbima_ettj_cz_'))
if not arqs:
  b = urllib.request.urlopen(urllib.request.Request(U, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'}), timeout=60).read()
  d = re.search(rb'Download (\d\d)/(\d\d)/(\d{4})', b).groups(); nome = f'anbima_ettj_cz_{d[2].decode()}{d[1].decode()}{d[0].decode()}.html'
  open(os.path.join(F, nome), 'wb').write(b); arqs = [nome]
linhas = []
for a in arqs:
  p = os.path.join(F, a); h = hashlib.sha256(open(p, 'rb').read()).hexdigest()
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime('%Y-%m-%d'), 'ANBIMA, estrutura a termo estimada (vertices prefixados, IPCA e implicita), pagina do dia', 'fontes/' + a, U, h]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n'); print(linhas)

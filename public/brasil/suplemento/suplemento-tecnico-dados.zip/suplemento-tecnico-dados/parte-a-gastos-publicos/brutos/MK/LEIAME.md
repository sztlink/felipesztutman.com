# Frente MK, leitura para quem aloca capital

Feita em 20/10/2026 para a v12.1 (nota "Para quem aloca capital", logo depois do Essencial). Origem: leitura simulada de um
leitor de mercado sobre a v12, que pediu o que a curva já precifica, o risco de execução do PLDO, o custo de 1 ponto de IVA e um
calendário de 2027.

## O que entra
- `MK-curva-termo.csv`. Taxas a termo de 252 dias úteis, prefixada e real, tiradas dos vértices da estrutura a termo estimada da
  ANBIMA de 19/10/2026, contra a Selic média esperada pelo Focus de 09/10/2026 em cada janela. A Selic esperada interpola por mês
  a média de outubro de 2026 (W-curva-mensal.csv) e as medianas de fim de ano, plana depois de dez/2030.
- `MK-pldo-execucao.csv`. Do PLDO 2027, Anexo IV.2: primário projetado, exclusões da meta e meta (tabela 3), receita e despesa
  primária (tabela 5), discricionárias líquidas de emendas e mínimos (tabela 8), e as frases sobre dividendos e concessões. O
  script para se alguma frase não estiver no texto.
- `MK-iva-ponto.csv`. Custo estático de 1 ponto da alíquota total de IBS e CBS, meta de arrecadação da Fazenda (12,30% do PIB,
  nota SERT de 01/07/2024) dividida pela alíquota do Comitê Gestor (27,91%, Resolução CGIBS 14/2026), sobre o PIB de 2027 do PLDO.
- `MK-calendario.csv`. Datas de 2027 que já estão em lei ou no PLDO, conferidas no texto da Constituição baixado pela frente PR.

## Licença
A página da ANBIMA traz "Todos os direitos reservados". O arquivo bruto fica fora do pacote e o verificador pula a frente sem ele.
O pacote leva só as taxas a termo calculadas.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/MK/baixa_MK.py        # baixa a página do dia (a data muda)
cd /tmp && PYTHONPATH=~/.local/lib/pdftools python3 -P <pacote>/brutos/MK/build_MK.py
```

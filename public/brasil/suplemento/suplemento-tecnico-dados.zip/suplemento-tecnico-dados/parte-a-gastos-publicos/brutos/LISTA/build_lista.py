# Gera LISTA.csv, RESUMO.csv, RESUMO-pais.csv e ARMADILHAS.csv a partir das frentes A a E
# e dos brutos de B (Portal agregado e consultas SIOP por acao). Rodar com: python3 -I build_lista.py
import csv, os
from collections import defaultdict

D = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')) + '/'
B = D + 'brutos/B/'
PIB25 = 12738.6  # R$ bi, IBGE SIDRA 1846 (mesmo de A e D)
PIB24_STN = 5377.5206 / 0.45787  # PIB implicito da STN no COFOG 2024

U = {
    'RTN': 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326',
    'RREO2': 'https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio=2025&nr_periodo=6&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%2002&id_ente=1',
    'SIOP': 'https://www1.siop.planejamento.gov.br/sparql/',
    'PORTAL': 'https://portaldatransparencia.gov.br/download-de-dados/despesas-execucao',
    'COFOG': 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/27169',
    'BCB': 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.4616/dados?formato=json',
    'RREO12': 'https://cdn.tesouro.gov.br/sistemas-internos/apex/producao/sistemas/thot/arquivos/publicacoes/53743_1693038/12_%20RREODez2025%20(REPUBL_).pdf',
    'DGT': 'https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/renuncia/gastos-tributarios-ploa/dgt-previsao-ploa-2026-quadros.xlsx',
    'OSU': 'https://www.gov.br/planejamento/pt-br/assuntos/avaliacao-de-politicas-publicas/arquivos/orcamento-de-subsidios-da-uniao/osu_2025-anexos-publicacao.xlsx',
    'SP': 'https://portal.fazenda.sp.gov.br/servicos/orcamento/Documents/LDO/LEI%20DE%20DIRETRIZES%20OR%C3%87AMENT%C3%81RIAS%202026%20-%20ACESSO%20A%20LEI%20N%C2%B0%2018.178,%20DE%2016%20DE%20JULHO%20DE%202025%20-%20LDO%202026.pdf',
}

def load(f):
    return list(csv.DictReader(open(D + f, encoding='utf-8')))

def bi(x):
    return float(x) / 1e9

A = load('A-uniao-por-funcao.csv'); Bc = load('B-uniao-por-orgao-e-gnd.csv')
C = load('C-governo-geral-cofog.csv'); Dd = load('D-rtn-despesa-primaria.csv')
E = load('E-renuncias-e-subsidios.csv')

def get(rows, ano, est, cat, sub=None, startswith=False):
    for r in rows:
        if r['ano'] == str(ano) and r['estagio'] == est and r['categoria'] == cat:
            if sub is None or r['subcategoria'] == sub or (startswith and r['subcategoria'].startswith(sub)):
                return bi(r['valor_brl'])
    raise KeyError((ano, est, cat, sub))

def rtn(ano, cat, sub='total', est='RTN pago'):
    return get(Dd, ano, est, cat, sub, startswith=True)

def rtn25(ano, sub):
    return get(Dd, ano, 'RTN valor pago (tab 2.5)', '4.2 Pessoal e Encargos Sociais', sub)

def fa(ano, est, cat, sub=''):
    return get(A, ano, est, cat, sub)

def fa_sub(ano, est, cat, subs):
    return sum(get(A, ano, est, cat, s) for s in subs)

def gnd(ano, est, cat, sub='total do grupo'):
    return get(Bc, ano, est, cat, sub)

def cof(cat, sub='Governo Geral consolidado'):
    return get(C, 2024, 'despesa_competencia_cofog', cat, sub)

def e(ano, est, cat, sub):
    return get(E, ano, est, cat, sub)

# SIOP por orgao e por acao (consultas de 17/10/2026, brutos/B/siop)
def siop_org(ano, orgs, col):
    s = 0.0
    for r in csv.DictReader(open(B + f'siop/siop_{ano}_org_gnd_rp_el_mod.csv')):
        if r['org'].rsplit('/', 1)[1] in orgs:
            s += float(r[col] or 0)
    return s / 1e9

def siop_acao(ano, acoes, col, org=None):
    s = 0.0
    for r in csv.DictReader(open(B + f'siop/siop_{ano}_org_acao.csv')):
        if r['acao'] in acoes and (org is None or r['org'].endswith('/' + org)):
            s += float(r[col] or 0)
    return s / 1e9

# Portal da Transparencia, execucao mensal agregada (so Executivo)
PORT = list(csv.DictReader(open(B + 'portal_exec_agg_acao_mod_2024_2026.csv')))
def portal(ano, filt, col='liquidado'):
    return sum(float(r[col]) for r in PORT if r['ano'] == str(ano) and filt(r)) / 1e9

ESTATAIS_UO = ['20415', '22202', '24209', '26294', '26443', '32202', '32314', '32398', '36210', '39207',
               '41260', '49202', '52221', '52233', '53201', '56201', '56202']

rows = []
def L(grupo, linha, desc, v25, v24, v26, est26, regua, frente, url, nota, conf, pct=None):
    rows.append(dict(grupo=grupo, linha=linha, descricao_leigo=desc,
                     valor_2025_rs_bi='' if v25 is None else f'{v25:.1f}',
                     pct_pib_2025='' if v25 is None else f'{(pct if pct is not None else 100 * v25 / PIB25):.2f}',
                     valor_2024_rs_bi='' if v24 is None else f'{v24:.1f}',
                     valor_2026_rs_bi='' if v26 is None else f'{v26:.1f}',
                     estagio_2026=est26 if v26 is not None else '', regua=regua, frente=frente,
                     fonte_url=url, nota_dupla_contagem=nota, confianca=conf))

RJA = 'RTN pago jan-ago/2026 (parcial)'
DOT_A = 'dotacao atualizada 2026 (RREO 4o bim)'
DOT_S = 'dotacao atualizada 2026 (SIOP, posicao 16/10/2026)'
PLOA = 'projecao DGT PLOA 2026'
G = 'Previdencia e aposentadorias'
cat41 = '4.1 Benefícios Previdenciários'
L(G, 'INSS urbano (RGPS urbano)', 'Aposentadorias, pensoes e auxilios do INSS pagos a quem trabalhou na cidade',
  rtn(2025, cat41, '4.1.1 Benefícios Previdenciários - Urbano'), rtn(2024, cat41, '4.1.1 Benefícios Previdenciários - Urbano'),
  rtn(2026, cat41, '4.1.1 Benefícios Previdenciários - Urbano'), RJA, 'RTN pago, linha 4.1.1', 'D', U['RTN'],
  'Inclui sentencas previdenciarias urbanas (R$ 33,2 bi em 2025). Nao somar com funcao 09 (frente A), que junta urbano, rural e servidores.', 'alta')
L(G, 'INSS rural (RGPS rural)', 'Aposentadorias do INSS de trabalhadores do campo, quase sem contribuicao previa',
  rtn(2025, cat41, '4.1.2 Benefícios Previdenciários - Rural'), rtn(2024, cat41, '4.1.2 Benefícios Previdenciários - Rural'),
  rtn(2026, cat41, '4.1.2 Benefícios Previdenciários - Rural'), RJA, 'RTN pago, linha 4.1.2', 'D', U['RTN'],
  'Inclui sentencas rurais (R$ 9,1 bi em 2025). Urbano + rural = linha 4.1 do RTN (R$ 1.026,9 bi em 2025).', 'alta')
L(G, 'Aposentadorias e pensoes de servidores civis da Uniao (RPPS)', 'Servidores federais aposentados e pensionistas, de todos os Poderes',
  rtn25(2025, 'aposentadorias e pensoes civis'), rtn25(2024, 'aposentadorias e pensoes civis'), rtn25(2026, 'aposentadorias e pensoes civis'),
  'RTN valor pago jan-ago/2026 (parcial)', 'RTN valor pago, tabela 2.5 (Pessoal: aposentadorias e pensoes civis)', 'D', U['RTN'],
  'Esta dentro de Pessoal (RTN 4.2) e do GND 1. Nao somar com pessoal ativo se a fonte for GND 1 total. Funcao 09.272 (A, R$ 104,5 bi em 2025) e outra regua.', 'alta')
L(G, 'Militares inativos e pensoes militares', 'Militares da reserva, reformados e pensionistas das Forcas Armadas',
  rtn25(2025, 'reformas e pensoes militares'), rtn25(2024, 'reformas e pensoes militares'), rtn25(2026, 'reformas e pensoes militares'),
  'RTN valor pago jan-ago/2026 (parcial)', 'RTN valor pago, tabela 2.5 (reformas e pensoes militares)', 'D', U['RTN'],
  'Dentro de Pessoal (RTN 4.2) e do orgao 52000 (Defesa, R$ 124,8 bi liquidados em 2025). Nao somar com a linha Defesa por orgao.', 'alta')
# COFOG 2024 por esfera (STN tabelas 1.3 e 1.4, R$ milhoes), lidos do xlsx em brutos/C
PREV_SUBNAC_2024 = (227770.97 + 52758.48 + 96838.94 + 11259.45) / 1000
L(G, 'Previdencia de estados e municipios', 'Aposentadorias de professores, policiais e demais servidores estaduais e municipais',
  None, PREV_SUBNAC_2024, None, '', 'COFOG 7102 (terceira idade) + 7103 (sobreviventes), Governos Estaduais + Municipais, 2024', 'C (xlsx STN tabelas 1.3 e 1.4)', U['COFOG'],
  f'{100 * PREV_SUBNAC_2024 / PIB24_STN:.2f}% do PIB em 2024. Estados 280,5 + municipios 108,1. Inclui alguma assistencia a idosos e e por competencia; separar RPPS puro exige RREO Anexo 4 de cada ente. Nao somar com INSS (que e da Uniao).', 'media')

G = 'Pessoal e custo dos Poderes'
ativo = lambda a: rtn25(a, 'ativo civil') + rtn25(a, 'ativo militar')
L(G, 'Pessoal ativo do Executivo federal (civis e militares)', 'Salarios e encargos de servidores e militares na ativa',
  ativo(2025), ativo(2024), ativo(2026), 'RTN valor pago jan-ago/2026 (parcial)', 'RTN valor pago, tabela 2.5 (ativo civil + ativo militar)', 'D', U['RTN'],
  'Todos os Poderes (o RTN nao abre por Poder). Civis 180,5 + militares 37,0 em 2025. Sem inativos e sem auxilios (ver linha de beneficios).', 'media')
LEG = ['01000', '02000', '03000']
L(G, 'Legislativo (Camara, Senado, TCU)', 'Quanto custa o Congresso e o tribunal de contas',
  siop_org(2025, LEG, 'liquidado'), siop_org(2024, LEG, 'liquidado'), siop_org(2026, LEG, 'dot_atual'), DOT_S,
  'SIOP liquidado, orgaos 01000 + 02000 + 03000', 'B (SIOP)', U['SIOP'],
  'Inclui aposentados e contribuicao patronal intraorcamentaria. Funcao 01 da so R$ 9,1 bi em 2025 porque os inativos ficam na funcao 09: por funcao e por orgao NAO dao numeros proximos.', 'media')
JUD = ['10000', '11000', '12000', '13000', '14000', '15000', '16000', '17000']
L(G, 'Judiciario federal (STF, tribunais superiores, Justicas Federal, Trabalho, Eleitoral, Militar, do DF, CNJ)', 'Quanto custa o Judiciario da Uniao',
  siop_org(2025, JUD, 'liquidado'), siop_org(2024, JUD, 'liquidado'), siop_org(2026, JUD, 'dot_atual'), DOT_S,
  'SIOP liquidado, orgaos 10000 a 17000', 'B (SIOP)', U['SIOP'],
  'Inclui aposentados, patronal intra e o Fundo Partidario (R$ 1,3 bi, orgao 14000). Precatorios NAO estao nos orgaos dos tribunais em 2024 a 2026: as acoes de sentencas ficam nos orgaos 71000, 33000 e 55000 (SIOP por acao). Funcao 02 (A) da R$ 45,1 bi em 2025 sem inativos.', 'media')
MP = ['34000', '29000', '59000']
L(G, 'Ministerio Publico da Uniao e Defensoria Publica da Uniao', 'Procuradores e defensores federais',
  siop_org(2025, MP, 'liquidado'), siop_org(2024, MP, 'liquidado'), siop_org(2026, MP, 'dot_atual'), DOT_S,
  'SIOP liquidado, orgaos 34000 (MPU) + 29000 (DPU) + 59000 (CNMP)', 'B (SIOP)', U['SIOP'],
  'Inclui aposentados e patronal intra. Funcao 03 (A) mistura com a AGU, do Executivo.', 'media')
BEN = ['212B', '2004']
L(G, 'Beneficios a servidores fora da folha', 'Auxilio-alimentacao, plano de saude, creche e transporte de servidores',
  siop_acao(2025, BEN, 'liquidado'), siop_acao(2024, BEN, 'liquidado'), siop_acao(2026, BEN, 'dot_atual'), DOT_S,
  'SIOP liquidado, acoes 212B (beneficios obrigatorios: alimentacao, pre-escolar, transporte) + 2004 (assistencia medica), todos os Poderes', 'B (SIOP por acao)', U['SIOP'],
  'Acoes 2010, 2011 e 2012 estao extintas (R$ 0 em 2024 a 2026): foram consolidadas na 212B. 2025: 212B 16,5 + 2004 11,1. RTN 4.4.1.1 da R$ 21,3 bi so do Executivo. Fica no GND 3, fora de Pessoal.', 'media')

G = 'Saude'
L(G, 'Saude federal total (piso ASPS)', 'Tudo que a Uniao gasta no SUS e conta para o piso constitucional',
  234.5, None, 254.3, 'dotacao atualizada ASPS 2026 (RREO ago/2026 Anexo 12)', 'RREO Anexo 12, ASPS aplicado (empenhado apos deducoes)', 'D', U['RREO12'],
  'Empenhado, nao pago. 2024 nao foi baixado pela frente D. Minimo 2025 era R$ 227,7 bi (103%). Nao somar com funcao 10, RTN saude ou orgao 36000.', 'baixa')
SUBS = ['Atenção Básica', 'Assistência Hospitalar e Ambulatorial', 'Suporte Profilático e Terapêutico', 'Vigilância Epidemiológica']
L(G, 'Atencao a saude federal por nivel (primaria, hospitais, remedios e vacinas)', 'Postos e Saude da Familia, hospitais e cirurgias, Farmacia Popular e vacinas',
  fa_sub(2025, 'liquidado', 'Saúde', SUBS), fa_sub(2024, 'liquidado', 'Saúde', SUBS), fa_sub(2026, 'dotacao_atualizada', 'Saúde', SUBS), DOT_A,
  'RREO liquidado, subfuncoes 10.301 + 10.302 + 10.303 + 10.305', 'A', U['RREO2'],
  '2025: atencao basica 56,9, hospitais 94,0, remedios 25,4, vigilancia epidemiologica 11,4. Parte da funcao 10 (R$ 217,1 bi). Boa parte e repasse fundo a fundo (linha seguinte): nao somar as duas.', 'media')
sus = lambda a, col='liquidado': portal(a, lambda r: r['funcao'] == '10' and r['mod'] in ('31', '41'), col)
L(G, 'Transferencias fundo a fundo do SUS', 'Dinheiro que o Ministerio da Saude repassa direto aos fundos estaduais e municipais de saude',
  sus(2025), sus(2024), sus(2026), 'liquidado jan-out/2026 (Portal, outubro parcial)',
  'Portal da Transparencia, liquidado, funcao 10, modalidades 31 (estados) + 41 (municipios)', 'B (brutos Portal, agregado por mim)', U['PORTAL'],
  f'2025: estados {portal(2025, lambda r: r["funcao"]=="10" and r["mod"]=="31"):.1f} + municipios {portal(2025, lambda r: r["funcao"]=="10" and r["mod"]=="41"):.1f}. Fora isso, R$ {portal(2025, lambda r: r["funcao"]=="10" and r["mod"] in ("31","41"), "rp_pagos"):.1f} bi de restos a pagar pagos. Ja esta dentro da funcao 10 e das subfuncoes 301 a 305; e o que a COFOG elimina na consolidacao.', 'media')
L(G, 'Saude total do pais (Uniao + estados + municipios)', 'Gasto publico total com saude, sem contar repasse duas vezes',
  None, cof('707 Saúde'), None, '', 'COFOG 707 Governo Geral consolidado, 2024', 'C', U['COFOG'],
  '5,03% do PIB em 2024. Soma das esferas 805,5 menos 214,4 de consolidacao. Nao somar com nenhuma linha federal de saude.', 'alta')

G = 'Educacao'
c410 = '4.3 Outras Despesas Obrigatórias'
L(G, 'Complementacao da Uniao ao Fundeb', 'Dinheiro federal que completa o fundo da educacao basica nos estados mais pobres',
  rtn(2025, c410, '4.3.10'), rtn(2024, c410, '4.3.10'), rtn(2026, c410, '4.3.10'), RJA,
  'RTN pago, linha 4.3.10 (acao 00SB)', 'D', U['RTN'],
  'Codigo correto: acao 00SB, classificada em 12.847 (dentro da funcao 12, orgao 26000), nao 0E36 nem 28.847. Liquidado 2025: 51,6 (SIOP); RTN inclui restos a pagar. Dotacao 2026: 70,0. A subfuncao 28.847 (R$ 102 bi em 2025) e outra coisa: acao 0C33 (parcela de FPE/FPM que vai ao Fundeb, dinheiro dos entes) + 0369 (cotas do salario-educacao).', 'alta')
UNI = ['Ensino Superior', 'Ensino Profissional']
L(G, 'Universidades e institutos federais', 'Ensino superior e tecnico federal, inclusive hospitais universitarios e pesquisa',
  fa_sub(2025, 'liquidado', 'Educação', UNI), fa_sub(2024, 'liquidado', 'Educação', UNI), fa_sub(2026, 'dotacao_atualizada', 'Educação', UNI), DOT_A,
  'RREO liquidado, subfuncoes 12.364 + 12.363', 'A', U['RREO2'],
  'Aposentados das universidades ficam na funcao 09.272. EBSERH tem parte na funcao 10.', 'media')
EDB = ['00PI', '20RQ', '0969', '0515', '00W2', '00VI', '20RP', '0509', '00O0', '20RM']
L(G, 'Educacao basica federal (livro, merenda, transporte, Pe-de-Meia)', 'Programas federais para escolas de estados e municipios e para alunos',
  siop_acao(2025, EDB, 'liquidado'), siop_acao(2024, EDB, 'liquidado'), siop_acao(2026, EDB, 'dot_atual'), DOT_S,
  'SIOP liquidado, acoes FNDE/MEC: 00PI merenda, 20RQ livro, 0969 transporte, 0515 PDDE, 00W2 Pe-de-Meia, 00VI tempo integral, 20RP infraestrutura, 0509, 00O0 bolsas, 20RM avaliacoes', 'B (SIOP por acao)', U['SIOP'],
  'Selecao de acoes feita por mim. Sem Fundeb. Pe-de-Meia no orcamento: 0 em 2024, 1,0 em 2025, 10,4 dotados em 2026; o resto rodou pelo fundo Fipem, fora do orcamento.', 'media')
L(G, 'Educacao total do pais (Uniao + estados + municipios)', 'Gasto publico total com educacao',
  None, cof('709 Educação'), None, '', 'COFOG 709 Governo Geral consolidado, 2024', 'C', U['COFOG'],
  '5,10% do PIB em 2024. Soma das esferas 786,2 menos 187,0 de consolidacao.', 'alta')

G = 'Assistencia social e trabalho'
c44 = '4.4 Despesas do Poder Executivo Sujeitas à Programação Financeira'
L(G, 'Bolsa Familia', 'Transferencia de renda para familias pobres',
  rtn(2025, c44, '4.4.1.2'), rtn(2024, c44, '4.4.1.2'), rtn(2026, c44, '4.4.1.2'), RJA, 'RTN pago, linha 4.4.1.2', 'D', U['RTN'],
  'Acao 8442 conferida (SIOP 2025: 158,2 liquidado). Subfuncao 08.244 em 2024 e 08.246 em 2025 e 2026. Dotacao atualizada 2026: 161,7.', 'alta')
L(G, 'BPC/LOAS', 'Um salario minimo por mes a idosos e pessoas com deficiencia de baixa renda',
  rtn(2025, c410, '4.3.05 '), rtn(2024, c410, '4.3.05 '), rtn(2026, c410, '4.3.05 '), RJA, 'RTN pago, linha 4.3.05 (BPC e RMV)', 'D', U['RTN'],
  'Acoes 00H5 (idoso, 08.241) e 00IN (deficiencia, 08.242) conferidas: 50,2 + 71,4 liquidados em 2025. RTN inclui sentencas de BPC (6,0). Dotacao 2026: 123,2.', 'alta')
L(G, 'Seguro-desemprego e abono salarial', 'Pagamento a quem foi demitido e o abono anual (PIS) a quem ganha pouco',
  rtn(2025, c410, '4.3.01 '), rtn(2024, c410, '4.3.01 '), rtn(2026, c410, '4.3.01 '), RJA, 'RTN pago, linha 4.3.01', 'D', U['RTN'],
  '2025: seguro 56,9 (com defeso 7,2) + abono 30,9. Funcao 11.331 (A) e outra regua.', 'alta')

G = 'Divida publica'
L(G, 'Juros da divida pagos (orcamento, caixa)', 'Juros que a Uniao efetivamente paga aos donos de titulos publicos',
  gnd(2025, 'liquidado', 'GND: 2 Juros e Encargos da Dívida'), gnd(2024, 'liquidado', 'GND: 2 Juros e Encargos da Dívida'),
  gnd(2026, 'dotacao_atualizada', 'GND: 2 Juros e Encargos da Dívida'), DOT_S, 'GND 2 liquidado (igual ao pago), SIOP', 'B', U['SIOP'],
  'Liquidado jan-out/2026 ja e 490,1. Dotacao de divida e sempre superestimada. Nao inclui correcao monetaria do principal (vai para GND 6).', 'alta')
jn = lambda a: get(C, a, 'juros_nominais_apropriados_bcb', 'JUROS: setor publico consolidado (BCB, NFSP)', None)
jn26 = [r for r in C if r['estagio'] == 'juros_nominais_apropriados_bcb' and r['ano'] == '2026' and r['subcategoria'].startswith('12 meses')]
L(G, 'Juros nominais apropriados (setor publico consolidado)', 'Custo de juros do ano pelo regime de competencia, conceito do Banco Central',
  jn(2025), jn(2024), bi(jn26[-1]['valor_brl']) if jn26 else None, '12 meses ate ago/2026 (BCB)', 'BCB NFSP juros nominais, SGS 4616 (soma de 12 meses)', 'C', U['BCB'],
  'Setor publico consolidado (Uniao, BCB, estados, municipios, estatais). Inclui correcao monetaria e swaps. pct_pib e o do BCB (SGS 5760, PIB proprio do BCB). Nao somar com juros do orcamento.', 'media',
  pct=7.91)
L(G, 'Amortizacao paga com receita propria', 'Divida que foi de fato reduzida, nao rolada',
  gnd(2025, 'liquidado', 'GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)'),
  gnd(2024, 'liquidado', 'GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)'),
  gnd(2026, 'dotacao_atualizada', 'GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)'), DOT_S,
  'GND 6 liquidado menos refinanciamento (elementos 76 e 77), SIOP', 'B', U['SIOP'],
  'Inclui R$ 111,2 bi de operacao Tesouro x Banco Central (elemento 26) em 2025 e atualizacao monetaria do principal.', 'media')
rol = lambda a, est: fa(a, est, 'Encargos especiais', '841 Refinanciamento da Dívida Interna (rolagem)') + fa(a, est, 'Encargos especiais', '842 Refinanciamento da Dívida Externa (rolagem)')
L(G, 'Rolagem (refinanciamento) da divida', 'Troca de titulo que vence por titulo novo; nao e gasto com servico publico',
  rol(2025, 'liquidado'), rol(2024, 'liquidado'), rol(2026, 'dotacao_atualizada'), DOT_A, 'RREO liquidado, subfuncoes 28.841 + 28.842', 'A', U['RREO2'],
  'Fica FORA de todo total desta lista. E o que faz a divida parecer metade do orcamento.', 'media')

G = 'Transferencias a estados e municipios'
L(G, 'FPE, FPM e demais reparticoes constitucionais', 'Parte dos impostos federais que pertence por Constituicao a estados e municipios',
  rtn(2025, '2. TRANSF. POR REPARTIÇÃO DE RECEITA'), rtn(2024, '2. TRANSF. POR REPARTIÇÃO DE RECEITA'), rtn(2026, '2. TRANSF. POR REPARTIÇÃO DE RECEITA'), RJA,
  'RTN pago, linha 2 (transferencias por reparticao de receita)', 'D', U['RTN'],
  '2025: FPM/FPE/IPI-EE 454,7, royalties 70,2, salario-educacao 21,4, fundos constitucionais 18,7. O RTN deduz da receita: nao e despesa primaria. Funcao 28.845 (A, 469,9) e orgao 73000 (B, 571,3) sao outras reguas.', 'alta')

G = 'Funcoes de Estado'
L(G, 'Defesa', 'Forcas Armadas',
  fa(2025, 'liquidado', 'Defesa nacional'), fa(2024, 'liquidado', 'Defesa nacional'), fa(2026, 'dotacao_atualizada', 'Defesa nacional'), DOT_A,
  'RREO liquidado, funcao 05', 'A', U['RREO2'],
  'Orgao 52000 da R$ 124,8 bi em 2025 porque carrega reformas e pensoes militares. Nao somar com a linha de militares inativos se usar o orgao.', 'alta')
L(G, 'Seguranca publica', 'Policia Federal, PRF, Forca Nacional, fundos de seguranca e penitenciario',
  fa(2025, 'liquidado', 'Segurança pública'), fa(2024, 'liquidado', 'Segurança pública'), fa(2026, 'dotacao_atualizada', 'Segurança pública'), DOT_A,
  'RREO liquidado, funcao 06', 'A', U['RREO2'],
  'Orgao 30000 (MJSP) da R$ 19,9 bi em 2025. O grosso do gasto com policia e estadual: COFOG 703 do pais da R$ 347,0 bi em 2024.', 'alta')

G = 'Desenvolvimento e infraestrutura'
L(G, 'Ciencia e tecnologia', 'FNDCT, CNPq, institutos de pesquisa',
  fa(2025, 'liquidado', 'Ciência e tecnologia'), fa(2024, 'liquidado', 'Ciência e tecnologia'), fa(2026, 'dotacao_atualizada', 'Ciência e tecnologia'), DOT_A,
  'RREO liquidado, funcao 19', 'A', U['RREO2'], 'Capes e universidades ficam na funcao 12. Orgao 24000 (MCTI) da R$ 11,7 bi em 2025.', 'alta')
L(G, 'Cultura', 'MinC, Funarte, Iphan, Ancine, Fundo Nacional de Cultura, Lei Aldir Blanc (PNAB)',
  fa(2025, 'liquidado', 'Cultura'), fa(2024, 'liquidado', 'Cultura'), fa(2026, 'dotacao_atualizada', 'Cultura'), DOT_A,
  'RREO liquidado, funcao 13', 'A', U['RREO2'], 'Orgao 42000 (MinC) da R$ 2,4 bi em 2025. A Lei Rouanet nao esta aqui: e renuncia.', 'alta')
L(G, 'Investimentos e Novo PAC', 'Obras e equipamentos pagos pelo orcamento federal',
  gnd(2025, 'liquidado', 'GND: 4 Investimentos'), gnd(2024, 'liquidado', 'GND: 4 Investimentos'), gnd(2026, 'dotacao_atualizada', 'GND: 4 Investimentos'), DOT_S,
  'GND 4 liquidado, SIOP', 'B', U['SIOP'],
  'Recorte por natureza: atravessa saude, transporte etc. e inclui emendas. Nao somar com funcoes. Marcador Novo PAC nao foi medido; obra paga em restos a pagar no ano seguinte nao aparece no liquidado.', 'alta')
L(G, 'Agricultura e Plano Safra (equalizacao de juros)', 'Subsidio para o juro do credito rural ficar abaixo do mercado, mais seguro rural e precos minimos',
  None, e(2024, 'realizado (OSU)', 'Agregado', 'Plano Safra e apoio agricola (subsidios financeiros)'), None, '',
  'OSU 2024, subsidios financeiros agricolas (soma da frente E)', 'E', U['OSU'],
  'OSU de 2025 ainda nao saiu. Funcao 20 (A) da R$ 40,5 bi liquidados em 2025, mas inclui Conab, Embrapa e o MAPA inteiro. Ja esta dentro da despesa (RTN 4.3.15).', 'media')
L(G, 'Habitacao (Minha Casa Minha Vida)', 'Subsidio a moradia popular',
  None, e(2024, 'realizado (OSU)', 'Subsidio financeiro (explicito)', 'Minha Casa Minha Vida - MCMV'), None, '',
  'OSU 2024, subsidio financeiro MCMV', 'E', U['OSU'],
  'Portal 2025 (Executivo, liquidado): FAR 00AF 6,7 + subvencoes 00CX/00CW 1,0 + 00TI 0,4; e mais 11,7 de financiamento reembolsavel (00XF, emprestimo). Funcao 16 e quase vazia. O grosso do MCMV roda no FGTS.', 'alta')

G = 'Politica e emendas'
em = lambda a, est: gnd(a, est, 'EMENDAS: total RP 6 a 9', 'orçamento do ano')
L(G, 'Emendas parlamentares', 'Dinheiro do orcamento cujo destino e escolhido por deputados e senadores',
  em(2025, 'liquidado'), em(2024, 'liquidado'), em(2026, 'dotacao_atualizada'), DOT_S,
  'SIOP liquidado, RP 6 + RP 7 + RP 8 do orcamento do ano', 'B', U['SIOP'],
  'Recorte transversal: ja esta dentro de saude, urbanismo etc. Nunca somar. 2025: empenhado 47,1; mais 13,4 de restos a pagar de emendas pagos (inclui 1,4 de RP 9).', 'alta')
fp = lambda a, col: siop_acao(a, ['0413'], col) + siop_acao(a, ['0EB8'], col)
L(G, 'Fundo Partidario e Fundo Eleitoral (FEFC)', 'Dinheiro publico para partidos e campanhas',
  fp(2025, 'liquidado'), fp(2024, 'liquidado'), fp(2026, 'dot_atual'), DOT_S,
  'SIOP liquidado, acao 0413 (Fundo Partidario, orgao 14000) + acao 0EB8 (FEFC, orgao 71000)', 'B (SIOP por acao)', U['SIOP'],
  'FEFC fica no orgao 71000 (Encargos Financeiros), nao no 14000. 2024: partidario 1,24 + FEFC 4,95; 2025 so partidario 1,31; 2026: 1,43 + 4,96. RTN 4.3.19 mede so o FEFC.', 'media')

G = 'Outras despesas obrigatorias'
sent = lambda a: get(Dd, a, 'RTN pago (calculo)', 'Calculo: sentencas judiciais e precatorios (todas)', None)
L(G, 'Sentencas judiciais e precatorios', 'Dividas da Uniao reconhecidas pela Justica',
  sent(2025), sent(2024), sent(2026), RJA, 'RTN pago, soma 4.1.1.1 + 4.1.2.1 + 4.2.1 + 4.3.05.1 + 4.3.14 (calculo da frente D)', 'D', U['RTN'],
  'Ja esta dentro de INSS, pessoal e BPC; so 4.3.14 (42,8 em 2025) e linha propria. No SIOP as acoes de sentencas ficam nos orgaos 71000, 33000 e 55000, nao nos tribunais.', 'media')
L(G, 'Subsidios e subvencoes explicitos', 'Equalizacoes, tarifa social de energia, FCVS, Proagro',
  rtn(2025, c410, '4.3.15 '), rtn(2024, c410, '4.3.15 '), rtn(2026, c410, '4.3.15 '), RJA, 'RTN pago, linha 4.3.15', 'D', U['RTN'],
  'OSU financeiro (R$ 65,0 bi em 2024) e mais amplo (FCVS e MCMV ficam em outras linhas do RTN). Nao somar OSU com a despesa.', 'alta')
est = lambda a: portal(a, lambda r: r['uo'] in ESTATAIS_UO)
L(G, 'Estatais dependentes', 'Empresas que vivem do Tesouro: Conab, Embrapa, EBSERH, Codevasf, Hemobras e outras',
  est(2025), est(2024), est(2026), 'liquidado jan-out/2026 (Portal, parcial)',
  'Portal liquidado, 17 unidades orcamentarias de empresas dependentes (lista minha)', 'B (brutos Portal, agregado por mim)', U['PORTAL'],
  'Lista: EBSERH (HU Brasil), Embrapa, GHC, HCPA, Conab, CBTU, Trensurb, Codevasf, SGB/CPRM, Nuclep, EBC, Amazul, Imbel, Infra SA/Valec, Telebras, EPE, Ceitec. Hemobras nao aparece no Portal. Ja esta nas funcoes: nao somar.', 'baixa')
L(G, 'Investimentos das estatais nao dependentes', 'Petrobras, Banco do Brasil, Caixa, Correios: investimento com recurso proprio',
  None, None, None, '', 'Orcamento de Investimento (OI) da LOA', 'nenhuma', '',
  'VAZIO: nenhum bruto tem o Orcamento de Investimento (SIOP OFSS e Portal nao cobrem). Exige baixar o volume do OI da LOA/SEST. Nao e gasto do Tesouro.', '')
L(G, 'BNDES e operacoes oficiais de credito', 'Emprestimos da Uniao (FIES, fundos, repasse do FAT ao BNDES)',
  gnd(2025, 'liquidado', 'GND: 5 Inversões Financeiras'), gnd(2024, 'liquidado', 'GND: 5 Inversões Financeiras'), gnd(2026, 'dotacao_atualizada', 'GND: 5 Inversões Financeiras'), DOT_S,
  'GND 5 Inversoes Financeiras liquidado, SIOP', 'B', U['SIOP'],
  'Emprestimo volta: o custo e o subsidio crediticio (linha propria). Orgao 74000 da R$ 112,1 bi em 2025. Fica fora do RESUMO.', 'alta')

G = 'Fora do orcamento de despesa'
OSU = 'realizado (OSU)'
t24 = lambda s: e(2024, OSU, 'Subsidio tributario (top 12)', s)
p26 = lambda s: e(2026, 'projecao PLOA', 'Gasto tributario (top 25)', s)
NR = 'Renuncia: coluna a parte, nunca parcela do total de despesa.'
L(G, 'Renuncias tributarias federais (total)', 'Imposto que a Uniao deixa de cobrar por excecao legal; e gasto pela porta da receita',
  None, e(2024, OSU, 'Modalidade', 'Subsidios tributarios (renuncias)'), e(2026, 'projecao PLOA', 'TOTAL gastos tributarios federais', 'todos'), PLOA,
  'DGT: 2024 realizado (OSU, Bases Efetivas 2024); 2026 PLOA', 'E', U['OSU'],
  '4,80% do PIB em 2024; 4,43% em 2026. Sem valor realizado de 2025 publicado. ' + NR, 'alta')
L(G, 'Simples Nacional e MEI', 'Imposto reduzido para micro e pequenas empresas',
  None, t24('SIMPLES Nacional') + 8.195, p26('Simples Nacional') + p26('MEI - Microempreendedor Individual'), PLOA,
  'DGT/OSU: Simples + MEI', 'E (MEI 2024 do xlsx OSU Tab_3)', U['OSU'], '2024: Simples 118,2 + MEI 8,2. ' + NR, 'media')
L(G, 'Zona Franca de Manaus e desenvolvimento regional', 'Isencoes para a industria de Manaus e reducao de IR nas areas SUDENE/SUDAM',
  None, t24('Zona Franca de Manaus e Áreas de Livre Comércio') + t24('Desenvolvimento Regional'),
  p26('Zona Franca de Manaus e Áreas de Livre Comércio') + p26('Desenvolvimento Regional'), PLOA,
  'DGT/OSU: ZFM e ALC + Desenvolvimento Regional', 'E', U['OSU'], '2024: ZFM 27,6 + regional 23,6. ' + NR, 'media')
L(G, 'IR da pessoa fisica: isencoes e deducoes', 'Despesas medicas e escola dedutiveis, aposentado 65+ e com doenca grave isentos, rescisao, poupanca',
  None, t24('Rendimentos Isentos e Não Tributáveis - IRPF') + t24('Deduções do Rendimento Tributável - IRPF'),
  p26('Rendimentos Isentos e Não Tributáveis - IRPF') + p26('Deduções do Rendimento Tributável - IRPF'), PLOA,
  'DGT/OSU: rendimentos isentos + deducoes do IRPF', 'E', U['OSU'],
  'Deducao medica 35,4 em 2026. Poupanca isenta e IRRF, fica fora daqui. Lucros e dividendos isentos nao estao no DGT. ' + NR, 'media')
L(G, 'Entidades sem fins lucrativos e filantropicas', 'Hospitais, escolas e associacoes isentas de IR, Cofins e cota patronal',
  None, t24('Entidades Sem Fins Lucrativos - Imunes / Isentas'), p26('Entidades Sem Fins Lucrativos - Imunes / Isentas'), PLOA,
  'DGT/OSU: Entidades sem fins lucrativos, imunes e isentas', 'E', U['OSU'],
  'O grupo do DGT ja inclui a cota patronal das filantropicas (22,7 em 2026; Q III soma 55,9). ' + NR, 'alta')
L(G, 'Agro e cesta basica', 'PIS/Cofins zero na cesta basica, defensivos, exportacao rural sem contribuicao',
  None, t24('Agricultura e Agroindústria'), p26('Agricultura e Agroindústria'), PLOA,
  'DGT/OSU: Agricultura e Agroindustria', 'E', U['OSU'],
  'Inclui cesta basica (45,1 em 2026) e defensivos (7,4). Exportacao da producao rural (24,0) aparece como item proprio no Q III; nao conferi se esta no grupo. ' + NR, 'media')
L(G, 'Lei Rouanet e audiovisual', 'Empresas e pessoas abatem do IR o que patrocinam em cultura',
  None, 2.952, p26('Cultura e Audiovisual'), PLOA,
  'DGT/OSU: grupo Cultura e Audiovisual (renuncia, nao captacao)', 'E (2024 do xlsx OSU Tab_3)', U['OSU'],
  'Rouanet sozinha: 3,09 projetados 2026. Captado (MinC, painel Salic) e outra serie: 3,45 em 2025. ' + NR, 'alta')
L(G, 'Desoneracao da folha', 'Contribuicao ao INSS menor para 17 setores e municipios pequenos',
  None, t24('Desoneração da Folha de Salários') + 10.555,
  e(2026, 'projecao PLOA', 'Item detalhado', 'Desoneracao da folha (17 setores)') + e(2026, 'projecao PLOA', 'Item detalhado', 'Desoneracao da folha dos municipios'), PLOA,
  'DGT/OSU: desoneracao 17 setores + municipios', 'E (municipios 2024 do xlsx OSU Tab_3)', U['OSU'],
  'A compensacao ao RGPS e despesa (RTN 4.3.08, zero em 2024 e 2025) e nao soma com a renuncia. ' + NR, 'media')
L(G, 'Subsidios crediticios', 'Custo de emprestar barato: fundos constitucionais, FIES, FAT/BNDES',
  None, e(2024, OSU, 'Modalidade', 'Subsidios crediticios (custo implicito de credito subsidiado)'), None, '',
  'OSU 2024, subsidios crediticios', 'E', U['OSU'], 'Custo implicito estimado pelo MPO; pode ser negativo (FMM -10,9). Nao esta na despesa.', 'alta')
L(G, 'Renuncias estaduais (ICMS), exemplo SP', 'Imposto estadual nao cobrado por beneficios fiscais',
  None, None, e(2026, 'previsto LDO', 'Renuncia estadual SP', 'Total ICMS + IPVA + ITCMD'), 'previsto LDO SP 2026',
  'LDO SP 2026, Anexo de Metas Fiscais', 'E', U['SP'], 'So SP. ICMS 78,7. Nao ha consolidado nacional oficial.', 'media')

# conferir ordem com E-linhas
EL = load('E-linhas.csv')
assert len(EL) == len(rows) == 50, (len(EL), len(rows))
for i, (a, b) in enumerate(zip(EL, rows)):
    assert a['linha'] == b['linha'], (i, a['linha'], b['linha'])
cols = ['ordem', 'grupo', 'linha', 'descricao_leigo', 'valor_2025_rs_bi', 'pct_pib_2025', 'valor_2024_rs_bi', 'valor_2026_rs_bi',
        'estagio_2026', 'regua', 'frente', 'fonte_url', 'nota_dupla_contagem', 'confianca']
with open(D + 'LISTA.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, cols); w.writeheader()
    for i, r in enumerate(rows, 1):
        r['ordem'] = i; w.writerow(r)

# ---------------- RESUMO federal 2025 ----------------
y = 2025
p = lambda s: rtn(y, c410, s)
q = lambda s: rtn(y, c44, s)
inss_u = rtn(y, cat41, '4.1.1 Benefícios Previdenciários - Urbano'); inss_r = rtn(y, cat41, '4.1.2 Benefícios Previdenciários - Rural')
pes = rtn(y, '4.2 Pessoal e Encargos Sociais'); inat = rtn25(y, 'aposentadorias e pensoes civis') + rtn25(y, 'reformas e pensoes militares')
o43 = rtn(y, c410); o441 = q('4.4.1 '); o442 = q('4.4.2 ')
disc_saude, disc_edu = q('4.4.2.1'), q('4.4.2.2')
blocos = [
    ('Aposentadorias e pensoes do INSS, cidade', inss_u, 'RTN 4.1.1 pago (inclui sentencas previdenciarias urbanas)'),
    ('Aposentadorias e pensoes do INSS, campo', inss_r, 'RTN 4.1.2 pago'),
    ('Aposentados e pensionistas de servidores civis e militares', inat, 'RTN tab 2.5: aposentadorias e pensoes civis + reformas e pensoes militares'),
    ('Servidores e militares na ativa', pes - inat, 'RTN 4.2 menos inativos (inclui sentencas de pessoal 9,7)'),
    ('Bolsa Familia', q('4.4.1.2'), 'RTN 4.4.1.2 pago'),
    ('BPC (idosos e pessoas com deficiencia pobres)', p('4.3.05 '), 'RTN 4.3.05 pago'),
    ('Seguro-desemprego e abono salarial', p('4.3.01 '), 'RTN 4.3.01 pago'),
    ('Saude (custeio e investimento, sem pessoal)', q('4.4.1.3') + disc_saude, 'RTN 4.4.1.3 + 4.4.2.1 pago'),
    ('Educacao (custeio, investimento e Fundeb, sem pessoal)', q('4.4.1.4') + disc_edu + p('4.3.10'), 'RTN 4.4.1.4 + 4.4.2.2 + 4.3.10 pago'),
    ('Precatorios e sentencas fora de beneficios e pessoal', p('4.3.14'), 'RTN 4.3.14 pago'),
    ('Demais despesas obrigatorias (subsidios, custeio dos outros Poderes, FCDF, auxilios de servidores, creditos extraordinarios)',
     o43 - p('4.3.01 ') - p('4.3.05 ') - p('4.3.10') - p('4.3.14') + q('4.4.1.1') + q('4.4.1.5'),
     'RTN 4.3 menos 4.3.01, 4.3.05, 4.3.10, 4.3.14; mais 4.4.1.1 e 4.4.1.5'),
    ('Resto da maquina e investimentos do Executivo (defesa, transporte, ciencia, seguranca, administracao, emendas)',
     o442 - disc_saude - disc_edu, 'RTN 4.4.2 menos 4.4.2.1 e 4.4.2.2 (discricionarias)'),
    ('Repasses constitucionais a estados e municipios (FPE, FPM, royalties)', rtn(y, '2. TRANSF. POR REPARTIÇÃO DE RECEITA'), 'RTN linha 2 pago'),
    ('Juros da divida', gnd(y, 'liquidado', 'GND: 2 Juros e Encargos da Dívida'), 'GND 2 liquidado = pago, SIOP'),
    ('Amortizacao da divida paga sem rolar', gnd(y, 'liquidado', 'GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)'),
     'GND 6 menos refinanciamento, SIOP'),
]
prim = rtn(y, '4. DESPESA TOTAL')
assert abs(sum(v for _, v, _ in blocos[:12]) - prim) < 0.01, (sum(v for _, v, _ in blocos[:12]), prim)

def largest_remainder(vals, total=1000):
    s = sum(vals); raw = [v * total / s for v in vals]; fl = [int(x) for x in raw]
    rest = total - sum(fl)
    for i in sorted(range(len(raw)), key=lambda i: raw[i] - fl[i], reverse=True)[:rest]:
        fl[i] += 1
    return [x / 10 for x in fl]

def write_resumo(path, blocos, pib, fonte_map, total_label):
    tot = sum(v for _, v, _ in blocos)
    por = largest_remainder([v for _, v, _ in blocos])
    with open(D + path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(['bloco', 'valor_2025_rs_bi' if '2025' in total_label else 'valor_2024_rs_bi', 'por_100_reais', 'pct_pib', 'regua', 'fonte'])
        for (b, v, rg), pc in zip(blocos, por):
            w.writerow([b, f'{v:.1f}', f'{pc:.1f}', f'{100 * v / pib:.2f}', rg, fonte_map(rg)])
        w.writerow(['TOTAL ' + total_label, f'{tot:.1f}', '100.0', f'{100 * tot / pib:.2f}', 'soma dos blocos acima', ''])
    return tot

fed_src = lambda rg: U['SIOP'] if 'SIOP' in rg else U['RTN']
TOTF = write_resumo('RESUMO.csv', blocos, PIB25, fed_src, '2025 (despesa primaria RTN + repasses + juros + amortizacao, sem rolagem)')

# ---------------- RESUMO pais 2024 COFOG ----------------
xl = {  # STN COFOG 2024, tabela 1.5 (Governo Geral consolidado), R$ milhoes
    '7101': 202132.474, '7102': 1041074.858, '7103': 327190.749, '7104': 180874.381, '7105': 81830.999}
def grp(code):
    for r in C:
        if r['ano'] == '2024' and r['estagio'] == 'despesa_competencia_cofog' and r['subcategoria'].startswith('grupo ' + code) and r['subcategoria'].endswith('Governo Geral consolidado'):
            return bi(r['valor_brl'])
    raise KeyError(code)
ps = cof('710 Proteção social')
fam = grp('7104') + grp('7106') + grp('7107')
seg = cof('703 Ordem pública e segurança')
pais = [
    ('Aposentadorias e pensoes (INSS, servidores e militares de todas as esferas)', grp('7102') + grp('7103'), 'COFOG 7102 + 7103'),
    ('Auxilio-doenca, invalidez e BPC da pessoa com deficiencia', grp('7101'), 'COFOG 7101'),
    ('Familia, criancas e combate a pobreza (Bolsa Familia e afins)', fam, 'COFOG 7104 + 7106 + 7107'),
    ('Seguro-desemprego e demais protecao social', ps - (grp('7101') + grp('7102') + grp('7103')) - fam, 'COFOG 710 menos 7101 a 7104, 7106 e 7107 (7105 + 7108 + 7109)'),
    ('Saude', cof('707 Saúde'), 'COFOG 707'),
    ('Educacao', cof('709 Educação'), 'COFOG 709'),
    ('Juros da divida', grp('7017'), 'COFOG 7017 (competencia)'),
    ('Policia, bombeiros e prisoes', seg - grp('7033'), 'COFOG 703 menos 7033'),
    ('Tribunais e Justica', grp('7033'), 'COFOG 7033'),
    ('Maquina publica geral (Executivo, Legislativo, administracao)', cof('701 Serviços públicos gerais') - grp('7017'), 'COFOG 701 menos 7017'),
    ('Transporte, agricultura, energia e outros assuntos economicos', cof('704 Assuntos econômicos'), 'COFOG 704'),
    ('Habitacao, agua, iluminacao e urbanismo', cof('706 Habitação e serviços comunitários'), 'COFOG 706'),
    ('Meio ambiente (residuos, esgoto, biodiversidade)', cof('705 Proteção ambiental'), 'COFOG 705'),
    ('Cultura', grp('7082'), 'COFOG 7082'),
    ('Esporte e lazer', grp('7081'), 'COFOG 7081'),
    ('Radio, TV e publicacao publicas e outros', cof('708 Lazer, cultura e religião') - grp('7081') - grp('7082'), 'COFOG 708 menos 7081 e 7082 (7083 a 7086)'),
    ('Defesa', cof('702 Defesa'), 'COFOG 702'),
]
assert abs(sum(v for _, v, _ in pais) - cof('7 Despesa total')) < 0.05
TOTP = write_resumo('RESUMO-pais.csv', pais, PIB24_STN, lambda rg: U['COFOG'], '2024 Governo Geral consolidado (COFOG, competencia)')
print('LISTA', len(rows), 'RESUMO', round(TOTF, 1), 'PAIS', round(TOTP, 1))
for b, v, _ in blocos: print(f'  {v:8.1f}  {b}')

#!/usr/bin/env python3
# Gera as tabelas em valor absoluto (R$ bi), ordenadas, a partir de RESUMO.csv, RESUMO-pais.csv e F-divida.csv.
# Juros entram pelo custo econômico (BCB, competência), não pelo caixa do orçamento.
import csv, glob, json, os, re

AQUI = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
# PIB 2025, R$ bi: BCB SGS 4382 (PIB acumulado em 12 meses, dezembro), o mesmo denominador do % do PIB dos juros
PIB_2025 = next(float(x['valor']) for x in json.load(open(os.path.join(AQUI, 'brutos', 'F', 'sgs_4382.json'))) if x['data'] == '01/12/2025') / 1000

def le(arq):
  with open(os.path.join(AQUI, arq), newline='', encoding='utf-8') as f:
    return list(csv.DictReader(f))

def grava(arq, cab, linhas):
  with open(os.path.join(AQUI, arq), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(cab)
    w.writerows(linhas)

CAB = ['ordem', 'bloco', 'valor_rs_bi', 'pct_pib', 'beneficiados', 'beneficiados_unidade', 'rs_por_beneficiado_ano',
       'soma', 'regua', 'fonte', 'beneficiados_conceito', 'beneficiados_referencia', 'beneficiados_fonte']

# Beneficiados por bloco (frente G): junta os CSVs dos agentes em G-beneficiarios.csv e usa a linha marcada "principal"
G = []
for arq in sorted(glob.glob(os.path.join(AQUI, 'brutos', 'G', 'G-beneficiarios-*.csv'))):
  with open(arq, newline='', encoding='utf-8') as f:
    G += list(csv.DictReader(f))
GCAB = ['tabela', 'bloco', 'beneficiarios', 'unidade', 'conceito', 'referencia', 'fonte_url', 'confianca', 'nota']
grava('G-beneficiarios.csv', GCAB, [[g.get(c, '') for c in GCAB] for g in G])

def principal(tabela, bloco):
  chave = lambda b: re.split(r' \(|,', b)[0]  # nome sem o detalhe entre parenteses
  cands = [g for g in G if g['tabela'] == tabela and chave(g['bloco']) == chave(bloco)]
  marcadas = [g for g in cands if 'principal' in g['nota'].lower()]
  return (marcadas or cands or [None])[0]

MM = {(x['serie'], x['ano']): x for x in le(os.path.join('brutos', 'H', 'H-beneficiarios-media-mensal.csv'))}
MM_ID = [('Aposentadorias e pensoes do INSS', 'inss'), ('BPC', 'bpc'), ('Bolsa Familia', 'bolsa_familia')]
def com_benef(tabela, linha):
  # linha no formato antigo: ordem, bloco, valor, pct, soma, regua, fonte
  # juros: o Tesouro Direto nao e quem recebe os juros (3% dos titulos); fica so na nota do relatorio
  g = principal(tabela, linha[1]) if linha[1] and 'juros' not in linha[1].lower() else None
  n = int(g['beneficiarios']) if g and g['beneficiarios'].strip() else ''
  # INSS, BPC e Bolsa Familia: media dos 12 meses do ano (brutos/H/H-beneficiarios-media-mensal.csv), nao o mes de referencia
  mm = next((k for p_, k in MM_ID if linha[1].startswith(p_)), None) if tabela == 'uniao-2025' and linha[1] else None
  ref_mm = ''
  if n and mm and (mm, '2025') in MM:
    ref_mm = f" media mensal de 2025 ({MM[(mm, '2025')]['meses_com_dado']} meses); {n} no mes de referencia"
    n = round(float(MM[(mm, '2025')]['media_mensal']))
  # sem divisao por cabeca onde o numero e piso ou parcial (juros: Tesouro Direto e 3% dos detentores; precatorios: so RPV)
  divide = n and linha[4] == 'sim' and 'juros' not in linha[1].lower() and 'parcial' not in g['nota'].lower() and 'repasses' not in linha[1].lower()
  por = round(linha[2] * 1e9 / n) if divide else ''
  extra = [g['conceito'], (g['referencia'] + ';' + ref_mm) if ref_mm else g['referencia'], MM[(mm, '2025')]['fonte_url'] if ref_mm else g['fonte_url']] if g else ['', '', '']
  return linha[:4] + [n, g['unidade'] if g and n else '', por] + linha[4:] + extra
# juros nominais apropriados (competencia), lidos de F-divida.csv (SGS 4606, 4607 e 4616 somadas por mes)
FD = le('F-divida.csv')
juros = lambda ano, est, esfera: float(next(x for x in FD if x['ano'] == ano and x['estagio'] == est and x['categoria'].startswith('JUROS NOMINAIS')
                                             and x['subcategoria'].startswith(esfera))['valor_brl']) / 1e9
# 2025 por bloco: RTN tab 2.5 valor pago, a mesma regua da serie historica (H-gasto-uniao-historico.csv)
H25 = {x['bloco_id']: float(x['valor_rs_bi_correntes']) for x in le('H-gasto-uniao-historico.csv') if x['ano'] == '2025'}
H_ID = [('Aposentados e pensionistas', 'servidores_inativos'), ('Servidores e militares', 'servidores_ativos'), ('Bolsa Familia', 'bolsa_familia'),
        ('BPC', 'bpc'), ('Seguro-desemprego', 'seguro_desemprego_abono'), ('Saude', 'saude'), ('Educacao', 'educacao'), ('Precatorios', 'precatorios'),
        ('Demais despesas', 'demais_obrigatorias'), ('Resto da maquina', 'maquina'), ('Repasses', 'repasses')]
h25 = lambda b: H25[next(i for k, i in H_ID if b.startswith(k))]
BCB = 'BCB Estatisticas fiscais, Tabela 2 (NFSP, juros nominais por esfera), https://www.bcb.gov.br/estatisticas/estatisticasfiscais (a SGS 4616 e o setor publico consolidado, nao o Governo Federal)'

# União 2025
r = [x for x in le('RESUMO.csv') if not x['bloco'].startswith('TOTAL')]
fora = ('Juros da divida', 'Amortizacao da divida paga sem rolar')
blocos = [x for x in r if x['bloco'] not in fora and 'INSS' not in x['bloco']]
inss = [x for x in r if 'INSS' in x['bloco']]
uniao = [(x['bloco'], h25(x['bloco']), 'RTN tab 2.5 valor pago', x['fonte']) for x in blocos]
uniao.append(('Aposentadorias e pensoes do INSS (urbano e rural)', H25['inss'], 'RTN tab 2.5 valor pago', inss[0]['fonte']))
uniao.append(('Juros da divida, nominais apropriados no ano (competencia, Governo Federal sem BCB)', juros('2025', 'competencia_ano', 'Governo Federal'),
              'BCB NFSP juros nominais, competencia', BCB))
uniao.sort(key=lambda b: -b[1])
total = sum(b[1] for b in uniao)
linhas = [[i + 1, b[0], round(b[1], 4), round(100 * b[1] / PIB_2025, 2), 'sim', b[2], b[3]] for i, b in enumerate(uniao)]
linhas.append(['', 'TOTAL gasto da Uniao 2025 (primaria RTN tab 2.5 + repasses + juros nominais por competencia)', round(total, 1), round(100 * total / PIB_2025, 2), '', 'soma das linhas acima', ''])
linhas.append(['', '', '', '', '', '', ''])
B_ = le('B-uniao-por-orgao-e-gnd.csv')
siop = lambda cat, sub: float(next(r for r in B_ if r['ano'] == '2025' and r['estagio'] == 'liquidado' and r['categoria'] == cat and r['subcategoria'] == sub)['valor_brl']) / 1e9
ref = [
  ('Referencia: juros nominais apropriados, 12 meses ate ago/2026 (Governo Federal)', juros('2026', 'competencia_12m_ate_ago', 'Governo Federal'), 'BCB NFSP, competencia', BCB),
  ('Referencia: juros nominais apropriados 2025, Governo Central (Governo Federal + BCB)', juros('2025', 'competencia_ano', 'Governo Central'), 'BCB NFSP, competencia', BCB),
  # caixa do orcamento, lido da frente B (SIOP, liquidado de 2025)
  ('Referencia: juros pagos em dinheiro pelo orcamento 2025 (GND 2)', siop('ORGAO: DÍVIDA (todos os órgãos)', 'juros e encargos (GND 2)'), 'SIOP liquidado', 'frente B'),
  ('Referencia: amortizacao paga sem rolar 2025 (principal, inclui correcao monetaria)', siop('GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)'), 'SIOP, GND 6 menos refinanciamento', 'frente B'),
  ('Referencia: rolagem (refinanciamento) da divida 2025', siop('GND: 6 Amortização/Refinanciamento da Dívida', 'refinanciamento (rolagem)'), 'SIOP, GND 6 refinanciamento', 'frente B'),
]
linhas += [['', b, round(v, 1), round(100 * v / PIB_2025, 2), 'nao', g, f] for b, v, g, f in ref]
grava('ABSOLUTO-uniao-2025.csv', CAB, [com_benef('uniao-2025', l) for l in linhas])

# País 2024 (COFOG já mede juros por competência)
p = [x for x in le('RESUMO-pais.csv') if not x['bloco'].startswith('TOTAL')]
tot_p = [x for x in le('RESUMO-pais.csv') if x['bloco'].startswith('TOTAL')][0]
p.sort(key=lambda x: -float(x['valor_2024_rs_bi']))
linhas = [[i + 1, x['bloco'], float(x['valor_2024_rs_bi']), float(x['pct_pib']), 'sim', x['regua'], x['fonte']] for i, x in enumerate(p)]
linhas.append(['', tot_p['bloco'], float(tot_p['valor_2024_rs_bi']), float(tot_p['pct_pib']), '', 'soma das linhas acima', ''])
linhas.append(['', '', '', '', '', '', ''])
jsp25, jsp12 = juros('2025', 'competencia_ano', 'Setor publico consolidado'), juros('2026', 'competencia_12m_ate_ago', 'Setor publico consolidado')
pct_sp = lambda ano, est: float(next(x for x in FD if x['ano'] == ano and x['estagio'] == est and x['subcategoria'].startswith('Setor publico consolidado'))['pct_pib'])
linhas.append(['', 'Referencia: juros nominais apropriados, setor publico consolidado 2025 (inclui BCB e estatais)', round(jsp25, 1), round(pct_sp('2025', 'competencia_ano'), 2), 'nao', 'BCB NFSP, competencia', BCB])
linhas.append(['', 'Referencia: idem, 12 meses ate ago/2026', round(jsp12, 1), round(pct_sp('2026', 'competencia_12m_ate_ago'), 2), 'nao', 'BCB NFSP, competencia', BCB])
grava('ABSOLUTO-pais-2024.csv', CAB, [com_benef('pais-2024', l) for l in linhas])
print('uniao', round(total, 1), 'pais', tot_p['valor_2024_rs_bi'])

# Razao per capita: R$ por habitante (todas as linhas) e R$ por beneficiado (onde ha numero honesto), ordenado por beneficiado
POP = {'uniao-2025': 213421037, 'pais-2024': 212583750}  # IBGE SIDRA 6579, 1/jul
SM = {'uniao-2025': 1518, 'pais-2024': 1412}  # salario minimo mensal: Decreto 12.342/2024 (2025) e Decreto 11.864/2023 (2024)
RCAB = ['tabela', 'bloco', 'valor_rs_bi', 'rs_por_habitante_ano', 'beneficiados', 'beneficiados_unidade',
        'rs_por_beneficiado_ano', 'rs_por_beneficiado_mes', 'salarios_minimos_por_mes', 'vezes_o_gasto_por_habitante']
razao = []
for tabela, arq in (('uniao-2025', 'ABSOLUTO-uniao-2025.csv'), ('pais-2024', 'ABSOLUTO-pais-2024.csv')):
  linhas = [x for x in le(arq) if x['soma'] == 'sim']
  com = []
  for x in linhas:
    v = float(x['valor_rs_bi'])
    hab = round(v * 1e9 / POP[tabela])
    b = x['rs_por_beneficiado_ano']
    if b:
      b = int(b)
      com.append([tabela, x['bloco'], v, hab, int(x['beneficiados']), x['beneficiados_unidade'], b, round(b / 12),
                  round(b / 12 / SM[tabela], 2), round(b / hab, 1)])
    else:
      com.append([tabela, x['bloco'], v, hab, x['beneficiados'], x['beneficiados_unidade'], '', '', '', ''])
  com.sort(key=lambda l: (l[6] == '', -(l[6] or 0), -l[2]))
  razao += com
  razao.append([tabela, 'TOTAL', round(sum(float(x['valor_rs_bi']) for x in linhas), 1),
                round(sum(float(x['valor_rs_bi']) for x in linhas) * 1e9 / POP[tabela]), POP[tabela], 'habitantes', '', '', '', ''])
  razao.append([''] * len(RCAB))
grava('RAZAO-per-capita.csv', RCAB, razao)

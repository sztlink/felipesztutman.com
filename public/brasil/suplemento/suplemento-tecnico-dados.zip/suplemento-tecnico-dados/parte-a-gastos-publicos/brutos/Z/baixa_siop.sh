#!/bin/bash
# Frente Z: SIOP, dados abertos do orcamento (SPARQL), execucao por resultado primario e acao.
# Uso: bash baixa_siop.sh 2014 2015 ... 2026
E="https://www1.siop.planejamento.gov.br/sparql/"
O="$(dirname "$(readlink -f "$0")")/siop"
mkdir -p "$O"
for y in "$@"; do
q="PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
SELECT ?rp ?acao (SUM(?ini) AS ?dot_ini) (SUM(?atu) AS ?dot_atual) (SUM(?emp) AS ?empenhado) (SUM(?liq) AS ?liquidado) (SUM(?pag) AS ?pago)
FROM <http://orcamento.dados.gov.br/$y/>
WHERE { ?s a loa:ItemDespesa ; loa:temResultadoPrimario ?rp ; loa:temAcao ?acao ;
 loa:valorDotacaoInicial ?ini ; loa:valorLeiMaisCredito ?atu ; loa:valorEmpenhado ?emp ; loa:valorLiquidado ?liq ; loa:valorPago ?pag . }
GROUP BY ?rp ?acao"
curl -s -m 900 "$E" --data-urlencode "query=$q" -H "Accept: text/csv" -o "$O/siop_${y}_rp_acao.csv"
echo "$y $(wc -l < "$O/siop_${y}_rp_acao.csv") $(date -I)"
sleep 2
done

# Frente Z: agrega as bases anuais "Despesas e Transferencias Totais da Uniao" (Tesouro Transparente)
# por ano, indicador de resultado primario (RP), acao (so 0EC2/0EC3, transferencias especiais), poder e categoria RTN.
# Uso: python3 -P agrega_tesouro.py saida.csv arquivo1.xlsx arquivo2.xlsx ...
import sys, csv, os, collections, openpyxl
saida = sys.argv[1]
VAL = ['DOTACAO_INICIAL', 'DOTACAO_ATUALIZADA', 'DESPESAS_EMPENHADAS', 'DESPESAS_LIQUIDADAS',
       'DESPESAS_PAGAS', 'RESTOS_A_PAGAR_PAGOS', 'PAGAMENTOS_TOTAIS']
TE = {'0EC2', '0EC3'}
linhas = []
for arq in sys.argv[2:]:
    wb = openpyxl.load_workbook(arq, read_only=True)
    ws = wb.worksheets[1]
    it = ws.iter_rows(values_only=True)
    h = [str(x).upper() if x is not None else '' for x in next(it)]
    ix = {k: h.index(k) for k in h if k}
    ipod = ix.get('PODER_ORGAO', ix.get('PODER'))
    acc = collections.defaultdict(lambda: [0.0] * len(VAL))
    n = 0
    for row in it:
        if row[ix['ID_ANO']] is None:
            continue
        n += 1
        acao = str(row[ix['ACAO']] or '')
        k = (str(row[ix['ID_ANO']]), str(row[ix['ID_IN_RESULTADO_EOF']]), str(row[ix['NO_IN_RESULTADO_EOF']]),
             acao if acao in TE else '', str(row[ipod]), str(row[ix['CATEGORIA_RTN']]))
        a = acc[k]
        for i, v in enumerate(VAL):
            x = row[ix[v]]
            if x not in (None, ''):
                a[i] += float(x)
    for k, a in acc.items():
        linhas.append([os.path.basename(arq)] + list(k) + ['%.2f' % x for x in a])
    print(arq, n, 'linhas lidas', flush=True)
with open(saida, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['arquivo', 'ano', 'rp', 'rp_nome', 'acao_te', 'poder', 'categoria_rtn'] + [v.lower() for v in VAL])
    w.writerows(sorted(linhas, key=lambda r: r[1:7]))

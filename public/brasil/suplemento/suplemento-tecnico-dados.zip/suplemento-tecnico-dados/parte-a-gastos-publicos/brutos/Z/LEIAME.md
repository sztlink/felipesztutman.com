# Frente Z. Emendas parlamentares ao orçamento da União (2014-2026)

Data: 19/10/2026. Pergunta: quanto do orçamento federal passa pelas emendas de deputados e senadores, por tipo (individuais, bancada, comissão, relator-geral e transferências especiais), como isso mudou desde 2014 e quanto pesa na despesa discricionária do Executivo.

## Como rodar

    bash brutos/Z/baixa_siop.sh 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024 2025 2026
    python3 -P brutos/Z/agrega_tesouro.py brutos/Z/tesouro/agregado_rp_poder_rtn.csv \
        brutos/Z/tesouro/base-despesas-201{4,5,6,7,8,9}.xlsx brutos/Z/tesouro/tetodez2{0,1,2,3}.xlsx \
        brutos/Z/tesouro/limite-gastos-lc200dez24.xlsx brutos/D/limite-gastos-lc200dez25.xlsx brutos/D/limite-gastos-lc200ago26.xlsx
    python3 -P brutos/Z/build_Z.py

O `agrega_tesouro.py` lê 13 planilhas de 30 a 40 MB em modo streaming (cerca de 3 minutos cada, pouca memória). `-P` e não `-I`, porque o openpyxl está no site do usuário. Os xlsx de 2014 a 2024 estão em `brutos/Z/tesouro/`; os de 2025 e 2026 são lidos de `brutos/D/` sem cópia. URL, data de consulta e md5 de cada arquivo em `downloads.tsv`.

Gera na raiz do dossiê:

| Arquivo | Conteúdo |
|---|---|
| `Z-emendas.csv` | formato longo: ano x tipo x medida x fonte, em R$ correntes, R$ de dez/2025 (IPCA) e % do PIB |
| `Z-emendas-participacao.csv` | emendas pagas e empenhadas do Executivo como % da linha 4.4.2 (discricionárias) do RTN |
| `Z-marcos.csv` | 18 marcos institucionais, com URL do texto oficial e o arquivo local onde o número do ato foi conferido |

## Fontes

- **Principal: Tesouro Nacional, base "Despesas e Transferências Totais da União"** (Tesouro Transparente, CKAN `despesas-e-transferencias-totais`), uma planilha por ano, mensal, com dotação inicial, dotação atualizada, empenhado, liquidado, pago do exercício, **restos a pagar pagos** e pagamentos totais, por órgão, ação, **indicador de resultado primário (RP)**, Poder e **categoria do RTN**. É a base que o Tesouro usa para o teto (EC 95) e para o limite da LC 200, critério "valor pago". É a única fonte oficial aberta que achei que dá, no mesmo arquivo, RP e restos a pagar pagos por ano de pagamento.
- **Conferência: SIOP**, dados abertos do orçamento (endpoint SPARQL), execução do orçamento do próprio ano por RP e ação. Não tem restos a pagar.
- **Conferência: Portal da Transparência (CGU)**, download "Emendas parlamentares" (`EmendasParlamentares.zip`, gerado em 09/10/2026), uma linha por emenda, com autor, tipo e localidade.
- **Denominador: RTN**, linha 4.4.2 "Despesas Discricionárias": 2019-2026 de `D-rtn-despesa-primaria.csv`; 2014-2018 da mesma série histórica do RTN (ago/2026, tabela 2.2, `brutos/D/seriehistoricaago26.xlsx`). O script confere que as duas leituras dão o mesmo número em 2019-2025.
- **IPCA**: SIDRA 1737 (`brutos/N/ibge/`). **PIB**: `pib_rs_mi` de `K-primario-recorrente.csv`.
- **Marcos**: textos no Planalto (ECs, LDOs, Lei 13.957/2019, LC 210/2024), andamentos e peças do STF (ADPF 854 e ADI 7697), e duas sínteses oficiais secundárias: Informativo ST 55/2025 da Consultoria de Orçamento da Câmara e Nota Informativa do Senado de 27/02/2025.

## Método

- **Tipos** pelo identificador de resultado primário do orçamento: RP 6 individuais, RP 7 bancada estadual, RP 8 comissão, RP 9 relator-geral. **Transferências especiais** ("emendas Pix", EC 105/2019) = RP 6 na ação **0EC2 "Transferências Especiais"**, um **subconjunto** das individuais (não somar). A ação 0EC3, que pensei ser a perna municipal, é outra coisa (participação no capital da Companhia Docas do RN) e ficou fora.
- **Medidas** (`medida`): `dotacao_inicial`, `dotacao_atualizada` (lei + créditos), `empenhado`, `liquidado`, `pago_exercicio` (pago do orçamento do ano), `rap_pago` (restos a pagar de anos anteriores pagos no ano) e `pago_total` = `pago_exercicio` + `rap_pago`, que é o caixa do ano. As linhas `fonte = SIOP` repetem as cinco primeiras para conferência.
- **Todos os Poderes** em `Z-emendas.csv` (há um pouco de RP 6 executado pela Justiça e pelo MPU, até R$ 0,05 bi por ano). Em `Z-emendas-participacao.csv`, só o Executivo, que é o perímetro da linha 4.4.2.
- **R$ de dez/2025**: valor x IPCA(dez/2025) / IPCA(dez do ano), dez a dez. Para 2026, que é parcial, o divisor é o último índice publicado (set/2026).
- **% do PIB**: PIB nominal do ano. Vazio em 2026.
- **Presidente**: Dilma até 2015, "Dilma/Temer" em 2016, Temer em 2017-2018, Bolsonaro em 2019-2022, Lula 3 desde 2023. Nos marcos, a data decide (12/05/2016).

## O perímetro: as emendas estão dentro das discricionárias do RTN

O RTN não separa emendas. A base do Tesouro traz, linha a linha, a categoria do RTN em que cada despesa entra. Toda emenda RP 6 a RP 9 paga pelo Executivo está classificada em **4.4.2 Discricionárias**, com uma exceção: em 2020, R$ 2,45 bi de emendas pagas foram por créditos extraordinários da Covid e caem na linha 4.3.08 (coluna `emendas_exe_pagas_fora_4_4_2_rs`). Ficam fora também as poucas emendas executadas por Judiciário e MPU, que entram em 4.3.14. Então a razão emendas / 4.4.2 tem numerador contido no denominador. A soma da linha 4.4.2 na base do Tesouro (critério valor pago) fica a até 1,9% do RTN publicado (pagamento efetivo): de 0,0% a 0,9% em 2019-2026 e até 1,9% em 2014-2018; a coluna `emendas_pct_discricionarias_base` dá a razão com o denominador da própria base.

Para empenho não existe linha no RTN, que é de caixa. `emendas_empenhado_pct_discricionarias` usa no denominador o empenhado da categoria 4.4.2 na base do Tesouro.

## Conferências

- **Tesouro x SIOP**: dotação, empenho, liquidação e pagamento do exercício batem a menos de R$ 5 milhões em todos os tipos de 2014 a 2025, com duas exceções: em 2014 o SIOP dá liquidado de individuais igual ao empenhado (R$ 6,14 bi) e o Tesouro dá R$ 0,20 bi, o que parece convenção de encerramento do SIOP para aquele ano (use o Tesouro); em 2015 a dotação inicial de individuais difere em R$ 0,02 bi. Em 2026 diferem pelo corte: o Tesouro vai até agosto, o SIOP até 16/10/2026.
- **Tesouro x Portal**: o pago do exercício por tipo bate com o Portal de 2021 a 2025, com diferença de até R$ 0,01 bi (exemplo de 2024: individuais 19,87 x 19,87; bancada 4,13 x 4,13; comissão 7,40 x 7,40; Pix 7,68 x 7,68). Em 2020 o Portal dá relator pago de R$ 8,34 bi contra R$ 7,01 bi de RP 9 no SIOP e no Tesouro, e bancada de R$ 3,62 bi contra R$ 3,43 bi: o Portal classifica pelo autor da emenda, não pelo RP.
- **Restos a pagar no Portal**: o arquivo por favorecido (`EmendasParlamentares_PorFavorecido.csv`) subestima os restos a pagar. Para RP 9, dá R$ 1,80 bi pagos em 2024 e R$ 0,89 bi em 2025, contra R$ 2,16 bi e R$ 1,41 bi na base do Tesouro. Por isso os restos a pagar vêm só do Tesouro.

## Números principais (pago total = exercício + restos a pagar, R$ bi de dez/2025)

| Ano | Individuais (RP6) | dos quais Pix | Bancada (RP7) | Comissão (RP8) | Relator (RP9) | Total | % das discricionárias (RTN) |
|---|---|---|---|---|---|---|---|
| 2019 | 10,31 | n/a | 3,76 | n/a | n/a | 14,07 | 6,1% |
| 2020 | 12,35 | 0,83 | 6,75 | 0,36 | 9,34 | 28,80 | 17,7% |
| 2021 | 11,55 | 2,42 | 6,04 | 0,17 | 12,62 | 30,39 | 20,2% |
| 2022 | 12,30 | 1,90 | 6,48 | 0,16 | 13,16 | 32,09 | 18,4% |
| 2023 | 24,21 | 9,59 | 7,18 | 0,31 | 5,94 | 37,64 | 18,8% |
| 2024 | 23,36 | 8,01 | 7,49 | 8,64 | 2,25 | 41,74 | 21,8% |
| 2025 | 24,35 | 6,90 | 9,97 | 9,24 | 1,41 | 44,97 | 22,0% |
| 2026 (jan-ago) | 18,34 | 4,38 | 7,27 | 7,68 | 0,41 | 33,71 | 23,8% |

Em 2014 o pago total foi de R$ 0,27 bi (só RP 6, primeiro ano do identificador, quase tudo empenhado e deixado para 2015), e a participação foi de 0,1%; em 2018, de 7,8%. RP 9 de 2023 em diante é só resto a pagar de 2020-2022.

## Limitações

1. **Empenho não é pagamento.** O empenho reserva a dotação; o pagamento é o caixa. Emenda é muito empenhada no fim do ano e paga depois. Em 2014 as individuais empenharam R$ 6,09 bi e pagaram R$ 0,15 bi no ano. Em 2020 o RP 9 empenhou R$ 19,74 bi e pagou R$ 7,01 bi no ano. Comparar anos pelo empenho mede a decisão orçamentária; pelo pagamento total mede o caixa.
2. **Restos a pagar.** `pago_total` de um ano mistura orçamentos de anos diferentes. Em 2022 o RP 9 pagou R$ 11,51 bi, mais que o empenhado no ano (R$ 8,64 bi), porque R$ 4,46 bi eram restos a pagar de 2020 e 2021. Os restos a pagar de RP 9 seguem saindo depois do fim do RP 9: R$ 5,43 bi em 2023, R$ 2,16 bi em 2024, R$ 1,41 bi em 2025, R$ 0,43 bi em jan-ago/2026. A base do Tesouro não diz de que ano é cada resto a pagar, só o RP de origem.
3. **A classificação muda entre anos.** RP 6 nasce na LDO 2014. RP 7 nasce na LDO 2017; antes, bancada ia em RP 2 (o Portal mostra R$ 3,64 bi empenhados de "Emenda de Bancada" em 2016 que não aparecem como RP 7). RP 8 e RP 9 nascem com a Lei 13.957/2019, que alterou a LDO 2020 depois do veto aos itens originais. **Antes de 2020, emendas de relator e de comissão existiam, mas iam em RP 2**: o Portal mostra "Emenda de Relator" com R$ 13,75 bi empenhados em 2016 e R$ 4,46 bi em 2017, classificados pelo código do autor, com muitos registros "Sem informação". Não entram na série, que segue o RP, e não são comparáveis ao RP 9.
4. **2023 não acaba com o dinheiro do relator, muda o rótulo.** A EC 126/2022 elevou as individuais a 2% da RCL (as individuais dobram de R$ 10,9 bi para R$ 21,3 bi de dotação inicial) e autorizou o relator-geral do orçamento de 2023 a apresentar até R$ 9,85 bi em emendas classificadas como **RP 2**, isto é, como despesa discricionária comum do Executivo. Esses R$ 9,85 bi não aparecem como emenda em nenhuma das fontes desta frente. Em 2024 o RP 8 salta para R$ 15,4 bi de dotação inicial. O próprio STF registrou, na ADPF 854, que "não importa a embalagem ou o rótulo (RP 2, RP 8, "emendas pizza", etc.)" (citado no Informativo da Câmara).
5. **Quem indicou cada emenda de relator: a fonte não permite saber.** A base do Tesouro e o SIOP não têm autor. No Portal, a emenda RP 9 tem como autor o próprio relator-geral; o deputado ou senador que pediu o recurso não aparece. O STF mandou publicar os "solicitadores" (decisões de 05/11/2021 e 02/12/2024), mas essas listas não foram baixadas nem cruzadas aqui. Também não dá para saber, por estas fontes, quem indicou as emendas de comissão (o despacho do STF de 23/12/2024 trata de 5.449 indicações, R$ 4,2 bi, feitas por líderes sem ata das comissões).
6. **Pix: destino, não uso.** A transferência especial é paga ao ente e passa a pertencer a ele. O pagamento federal (ação 0EC2) é conhecido; em que o município gastou, não, nestas fontes. O STF registrou, em 01/04/2025, 6.247 planos de trabalho de emendas Pix não cadastrados (Informativo da Câmara).
7. **2026 é parcial**: jan-ago na base do Tesouro e no RTN; até 16/10 no SIOP. A participação de 2026 compara os mesmos oito meses nos dois lados, mas a sazonalidade das emendas é forte (pagamento concentrado no fim do ano e, em ano de eleição, antes do prazo eleitoral), então não projetar o ano.
8. **Critério de caixa.** A base do Tesouro usa "valor pago"; o RTN, "pagamento efetivo". A diferença no total da linha 4.4.2 vai de 0,0% a 1,9% por ano (a maior em 2016).
9. **Dotação na base do Tesouro**: a base é mensal; a soma dos meses de dotação confere com a dotação anual do SIOP, então a dotação não se repete mês a mês. Quem reusar a base mês a mês deve conferir isso antes de somar.
10. **Erro de data na fonte secundária**: o Informativo ST 55/2025 da Câmara diz que a cautelar da ADPF 854 foi referendada "em 10 de novembro de 2022". O andamento do STF mostra o julgamento virtual encerrado em 10/11/2021, ata nº 6 de 11/11/2021. `Z-marcos.csv` usa a data do STF.

## O que não foi achado

- Lista oficial, em arquivo aberto, de quem pediu cada emenda RP 9 (as planilhas do Congresso e da CMO de 2021-2022 não foram procuradas a fundo).
- Texto integral do acórdão de 19/12/2022 (o andamento do STF traz o dispositivo truncado; o trecho da interpretação conforme sobre o RP 9 veio da Nota do Senado).
- Peça da decisão de 01/08/2024 (o andamento só registra a audiência e a ata; o conteúdo veio do Informativo da Câmara) e da de 14/08/2024 na ADI 7697 além do resumo do andamento.
- Separação de transferências especiais a estados e a municípios: a ação 0EC2 junta os dois; a modalidade de aplicação não foi agregada.

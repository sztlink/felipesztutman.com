# Frente Z: emendas parlamentares ao orcamento da Uniao (RP 6, 7, 8, 9 e transferencias especiais)
#
# Gera na raiz do dossie:
#   Z-emendas.csv                 anual 2014-2026, por tipo e medida (dotacao, empenho, pagamento, restos a pagar)
#   Z-emendas-participacao.csv    emendas pagas e empenhadas como % das discricionarias do Executivo (RTN 4.4.2)
#   Z-marcos.csv                  marcos institucionais, com URL do texto oficial e arquivo local conferido
#
# Entradas (todas em brutos/, URL e data em brutos/Z/downloads.tsv):
#   Z/tesouro/agregado_rp_poder_rtn.csv   gerado por Z/agrega_tesouro.py a partir das bases anuais
#                                         "Despesas e Transferencias Totais da Uniao" (Tesouro Transparente)
#   Z/siop/siop_{ano}_rp_acao.csv         SIOP, SPARQL, por RP e acao (gerado por Z/baixa_siop.sh)
#   N/ibge/sidra_1737_v2266.json          IBGE SIDRA 1737, IPCA numero-indice
#   ../K-primario-recorrente.csv          PIB nominal anual (pib_rs_mi)
#   ../D-rtn-despesa-primaria.csv         RTN linha 4.4.2, 2019-2026
#   D/seriehistoricaago26.xlsx            RTN tabela 2.2, linha 4.4.2, 2014-2018
#
# Rodar: python3 -P brutos/Z/build_Z.py   (-P e nao -I: openpyxl esta no site do usuario)
import csv, json, os, re, collections

Z = os.path.dirname(os.path.abspath(__file__))
BR = os.path.dirname(Z)
RAIZ = os.path.dirname(BR)

ANOS = list(range(2014, 2027))
CONSULTA = '2026-10-19'

URL_TES = ('https://www.tesourotransparente.gov.br/ckan/dataset/despesas-e-transferencias-totais '
           '(bases anuais 2014 a 2026; recurso de cada ano em brutos/Z/downloads.tsv)')
URL_SIOP = 'https://www1.siop.planejamento.gov.br/sparql/ (grafos http://orcamento.dados.gov.br/{ano}/)'
URL_RTN = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'
URL_IPCA = 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'

TIPOS = [
    ('6', '', 'individuais (RP6)'),
    ('6', '0EC2', 'transferencias especiais, emendas Pix (RP6, acao 0EC2; subconjunto das individuais)'),
    ('7', '', 'bancada estadual (RP7)'),
    ('8', '', 'comissao (RP8)'),
    ('9', '', 'relator-geral (RP9)'),
    ('6789', '', 'total das emendas (RP6 a RP9)'),
]
MEDIDAS_TES = [('dotacao_inicial', 'dotacao_inicial'), ('dotacao_atualizada', 'dotacao_atualizada'),
               ('empenhado', 'despesas_empenhadas'), ('liquidado', 'despesas_liquidadas'),
               ('pago_exercicio', 'despesas_pagas'), ('rap_pago', 'restos_a_pagar_pagos'),
               ('pago_total', 'pagamentos_totais')]
MEDIDAS_SIOP = [('dotacao_inicial', 'dot_ini'), ('dotacao_atualizada', 'dot_atual'), ('empenhado', 'empenhado'),
                ('liquidado', 'liquidado'), ('pago_exercicio', 'pago')]


def presidente(a):
    if a <= 2015:
        return 'Dilma'
    if a == 2016:
        return 'Dilma/Temer'
    if a <= 2018:
        return 'Temer'
    if a <= 2022:
        return 'Bolsonaro'
    return 'Lula 3'


def corte(a, fonte):
    if a < 2026:
        return 'ano cheio'
    return {'Tesouro': 'jan-ago/2026', 'SIOP': 'execucao ate 16/10/2026 (SIOP atualizado em 17/10/2026)'}[fonte]


# ---------- IPCA e PIB ----------
ipca = {x['D3C']: float(x['V']) for x in json.load(open(os.path.join(BR, 'N', 'ibge', 'sidra_1737_v2266.json'),
                                                        encoding='utf-8'))[1:]}
ult_mes = max(ipca)
BASE = ipca['202512']


def fator(a):
    m = '%d12' % a
    if m not in ipca:
        m = ult_mes
    return BASE / ipca[m]


pib = {}
for r in csv.DictReader(open(os.path.join(RAIZ, 'K-primario-recorrente.csv'), encoding='utf-8')):
    pib[int(r['ano'])] = float(r['pib_rs_mi']) * 1e6

# ---------- Tesouro (agregado) ----------
tes = collections.defaultdict(float)       # (ano, rp, acao, medida) -> valor, todos os poderes
tes_exe442 = collections.defaultdict(float)  # (ano, rp, medida) -> emendas do Executivo classificadas em 4.4.2
tes_exe_fora = collections.defaultdict(float)  # (ano, rp, medida) -> emendas do Executivo fora de 4.4.2
disc442 = collections.defaultdict(float)   # (ano, medida) -> total 4.4.2 na base do Tesouro
R442 = re.compile(r'^(II\.4\.2|2\.4\.2)')
for r in csv.DictReader(open(os.path.join(Z, 'tesouro', 'agregado_rp_poder_rtn.csv'), encoding='utf-8')):
    a = int(r['ano'])
    rp = r['rp']
    e442 = bool(R442.match(r['categoria_rtn']))
    for m, col in MEDIDAS_TES:
        v = float(r[col])
        if e442:
            disc442[(a, m)] += v
        if rp in ('6', '7', '8', '9'):
            tes[(a, rp, '', m)] += v
            tes[(a, '6789', '', m)] += v
            if r['acao_te'] == '0EC2' and rp == '6':
                tes[(a, '6', '0EC2', m)] += v
            if r['poder'] == 'EXE':
                if e442:
                    tes_exe442[(a, rp, m)] += v
                else:
                    tes_exe_fora[(a, rp, m)] += v

# ---------- SIOP ----------
siop = collections.defaultdict(float)
for a in ANOS:
    for r in csv.DictReader(open(os.path.join(Z, 'siop', 'siop_%d_rp_acao.csv' % a), encoding='utf-8')):
        rp = r['rp'].rsplit('/', 1)[1]
        ac = r['acao'].rsplit('/', 1)[1]
        if rp not in ('6', '7', '8', '9'):
            continue
        for m, col in MEDIDAS_SIOP:
            v = float(r[col])
            siop[(a, rp, '', m)] += v
            siop[(a, '6789', '', m)] += v
            if rp == '6' and ac == '0EC2':
                siop[(a, '6', '0EC2', m)] += v

# ---------- Z-emendas.csv ----------
NOTA_TES = ('Tesouro, base "Despesas e Transferencias Totais da Uniao" (criterio valor pago), todos os Poderes; '
            'pago_exercicio = despesas pagas do orcamento do ano; rap_pago = restos a pagar de anos anteriores pagos no ano; '
            'pago_total = pago_exercicio + rap_pago (caixa do ano)')
NOTA_SIOP = 'SIOP, dados abertos do orcamento, execucao do orcamento do proprio ano (sem restos a pagar), todos os Poderes'


def existe(a, rp, ac):
    if rp == '7' and a < 2017:
        return False, 'RP7 so existe a partir da LDO 2017 (Lei 13.408/2016); antes, emendas de bancada iam em RP2'
    if rp == '8' and a < 2020:
        return False, 'RP8 criado pela Lei 13.957/2019, que alterou a LDO 2020; antes, emendas de comissao iam em RP2'
    if rp == '9' and a < 2020:
        return False, 'RP9 criado pela Lei 13.957/2019, que alterou a LDO 2020; antes, emendas de relator iam em RP2'
    if ac == '0EC2' and a < 2020:
        return False, 'transferencias especiais (EC 105/2019) so existem a partir do orcamento de 2020'
    return True, ''


linhas = []
for a in ANOS:
    f = fator(a)
    for rp, ac, nome in TIPOS:
        ok, motivo = existe(a, rp, ac)
        for fonte, dic, medidas in (('Tesouro', tes, MEDIDAS_TES), ('SIOP', siop, MEDIDAS_SIOP)):
            for m, _ in medidas:
                v = dic.get((a, rp, ac, m), 0.0)
                nota = []
                if not ok:
                    if abs(v) < 0.5:
                        nota.append(motivo)
                    else:
                        nota.append(motivo + '; valor aqui e resto a pagar ou residuo de classificacao')
                if rp == '9' and a >= 2023 and m in ('dotacao_inicial', 'dotacao_atualizada', 'empenhado',
                                                     'liquidado', 'pago_exercicio'):
                    nota.append('sem RP9 no orcamento desde 2023 (EC 126/2022 e decisao do STF de 19/12/2022); '
                                'so restos a pagar de 2020-2022')
                if a == 2026:
                    nota.append('2026 parcial; % do PIB vazio')
                if ac == '0EC2':
                    nota.append('ja incluido em individuais (RP6); nao somar')
                pp = '' if a not in pib else '%.4f' % (100 * v / pib[a])
                linhas.append(['Z', a, presidente(a), nome, 'RP' + rp if rp != '6789' else 'RP6+RP7+RP8+RP9', m,
                               '%.0f' % v, '%.0f' % (v * f), pp, fonte,
                               URL_TES if fonte == 'Tesouro' else URL_SIOP, CONSULTA, corte(a, fonte),
                               '; '.join(nota)])

cab = ['frente', 'ano', 'presidente', 'tipo', 'identificador', 'medida', 'valor_rs_correntes', 'valor_rs_dez2025',
       'pct_pib', 'fonte', 'fonte_url', 'data_consulta', 'corte', 'nota']
with open(os.path.join(RAIZ, 'Z-emendas.csv'), 'w', newline='', encoding='utf-8') as fo:
    w = csv.writer(fo)
    w.writerow(cab)
    w.writerows(linhas)

# ---------- Z-emendas-participacao.csv ----------
rtn442 = {}
for r in csv.DictReader(open(os.path.join(RAIZ, 'D-rtn-despesa-primaria.csv'), encoding='utf-8')):
    if r['estagio'] == 'RTN pago' and r['subcategoria'] == '4.4.2 Despesas Discricionárias':
        rtn442[int(r['ano'])] = float(r['valor_brl'])
import openpyxl
wb = openpyxl.load_workbook(os.path.join(BR, 'D', 'seriehistoricaago26.xlsx'), read_only=True)
ws = wb['2.2']
anos_cab = None
rtn22 = {}
for row in ws.iter_rows(values_only=True):
    if row and row[0] == 'Discriminação':
        anos_cab = row
    if row and isinstance(row[0], str) and row[0].startswith('4.4.2 Despesas Discricion'):
        for i, x in enumerate(row):
            if i and isinstance(anos_cab[i], int) and anos_cab[i] in ANOS:
                rtn22[anos_cab[i]] = float(x) * 1e6
        break
# conferencia: D e RTN 2.2 dao o mesmo numero de 2019 a 2025; 2014-2018 so existem na 2.2
for a, v in rtn22.items():
    if a in rtn442:
        assert abs(rtn442[a] - v) < 1e3, (a, rtn442[a], v)
    else:
        rtn442[a] = v

linhas = []
for a in ANOS:
    num_pago = sum(tes_exe442[(a, rp, 'pago_total')] for rp in '6789')
    num_emp = sum(tes_exe442[(a, rp, 'empenhado')] for rp in '6789')
    fora_pago = sum(tes_exe_fora[(a, rp, 'pago_total')] for rp in '6789')
    den_rtn = rtn442[a]
    den_base_pago = disc442[(a, 'pago_total')]
    den_base_emp = disc442[(a, 'empenhado')]
    por_rp = {rp: tes_exe442[(a, rp, 'pago_total')] for rp in '6789'}
    nota = ('numerador = pagamentos totais (pago do ano + restos a pagar pagos) das emendas RP6-RP9 do Executivo '
            'que a base do Tesouro classifica na linha 4.4.2 do RTN; denominador RTN = linha 4.4.2, pagamento efetivo')
    if fora_pago > 1e6:
        nota += ('; fora de 4.4.2 ficaram %.2f bi de emendas pagas do Executivo (creditos extraordinarios da Covid, '
                 'linha 4.3.08)' % (fora_pago / 1e9))
    if a == 2026:
        nota += '; 2026 = jan-ago nos dois lados da razao'
    linhas.append(['Z', a, presidente(a), '%.0f' % den_rtn, '%.0f' % num_pago,
                   '%.2f' % (100 * num_pago / den_rtn),
                   '%.2f' % (100 * por_rp['6'] / den_rtn), '%.2f' % (100 * por_rp['7'] / den_rtn),
                   '%.2f' % (100 * por_rp['8'] / den_rtn), '%.2f' % (100 * por_rp['9'] / den_rtn),
                   '%.0f' % den_base_pago, '%.2f' % (100 * num_pago / den_base_pago),
                   '%.0f' % num_emp, '%.0f' % den_base_emp, '%.2f' % (100 * num_emp / den_base_emp),
                   '%.0f' % fora_pago,
                   URL_RTN + ' (RTN, linha 4.4.2) | ' + URL_TES, CONSULTA,
                   'jan-ago/2026' if a == 2026 else 'ano cheio', nota])
cab = ['frente', 'ano', 'presidente', 'discricionarias_rtn_4_4_2_pago_rs', 'emendas_pago_total_exe_rs',
       'emendas_pct_discricionarias_rtn', 'rp6_pct', 'rp7_pct', 'rp8_pct', 'rp9_pct',
       'discricionarias_base_tesouro_pago_rs', 'emendas_pct_discricionarias_base',
       'emendas_empenhado_exe_rs', 'discricionarias_base_tesouro_empenhado_rs', 'emendas_empenhado_pct_discricionarias',
       'emendas_exe_pagas_fora_4_4_2_rs', 'fonte_url', 'data_consulta', 'corte', 'nota']
with open(os.path.join(RAIZ, 'Z-emendas-participacao.csv'), 'w', newline='', encoding='utf-8') as fo:
    w = csv.writer(fo)
    w.writerow(cab)
    w.writerows(linhas)

# ---------- Z-marcos.csv ----------
P = 'https://www.planalto.gov.br/ccivil_03/'
STF854 = 'https://portal.stf.jus.br/processos/detalhe.asp?incidente=6199750'
STF7697 = 'https://portal.stf.jus.br/processos/detalhe.asp?incidente=6997560'
CAM = 'https://www2.camara.leg.br/orcamento-da-uniao/estudos/2025/informativo-decisoes-stf-emendas-2025'
SEN = 'https://www12.senado.leg.br/noticias/arquivos/2025/02/28/nota-informativa-decisoes-stf-versao-final.pdf'
MARCOS = [
    ('2013-12-24', 'Lei 12.919/2013 (LDO 2014)', 'lei',
     'cria o identificador RP 6, "discricionaria e decorrente de emendas individuais" (art. 7, par. 4, II, d)',
     P + '_ato2011-2014/2013/lei/l12919.htm', 'marcos/ldo2014_l12919.htm'),
    ('2015-03-17', 'Emenda Constitucional 86/2015', 'emenda constitucional',
     'individuais impositivas: aprovadas ate 1,2% da RCL prevista no projeto, metade para saude; execucao '
     'obrigatoria de 1,2% da RCL realizada no ano anterior (art. 166, par. 9 e 11)',
     P + 'constituicao/emendas/emc/emc86.htm', 'marcos/constituicao_emendas_emc_emc86.htm'),
    ('2016-12-15', 'Emenda Constitucional 95/2016 (teto de gastos)', 'emenda constitucional',
     'de 2018 ate o fim do Novo Regime Fiscal, o montante obrigatorio das individuais passa a ser o de 2017 '
     'corrigido pelo IPCA (ADCT, art. 111)',
     P + 'constituicao/emendas/emc/emc95.htm', 'marcos/constituicao_emendas_emc_emc95.htm'),
    ('2016-12-26', 'Lei 13.408/2016 (LDO 2017)', 'lei',
     'cria o identificador RP 7, emendas de bancada estadual de execucao obrigatoria nos termos do art. 72 da LDO',
     P + '_ato2015-2018/2016/lei/l13408.htm', 'marcos/ldo2017_l13408.htm'),
    ('2019-06-26', 'Emenda Constitucional 100/2019', 'emenda constitucional',
     'bancada impositiva: execucao obrigatoria das emendas de bancada estadual ate 1% da RCL realizada no ano '
     'anterior (art. 166, par. 12); 0,8% no exercicio seguinte ao da promulgacao (art. 2)',
     P + 'constituicao/emendas/emc/emc100.htm', 'marcos/constituicao_emendas_emc_emc100.htm'),
    ('2019-11-11', 'Lei 13.898/2019 (LDO 2020), texto sancionado', 'lei',
     'os itens que criariam RP 8 e RP 9 (art. 6, par. 4, II, c, 3 e 4) foram VETADOS na sancao',
     P + '_ato2019-2022/2019/lei/l13898.htm', 'marcos/ldo2020_l13898.htm'),
    ('2019-12-12', 'Emenda Constitucional 105/2019', 'emenda constitucional',
     'cria o art. 166-A: individuais impositivas podem ir a estados, DF e municipios por transferencia especial '
     '(sem convenio, recurso pertence ao ente na transferencia; 70% em capital) ou com finalidade definida; vigor '
     'em 1/1/2020',
     P + 'constituicao/emendas/emc/emc105.htm', 'marcos/constituicao_emendas_emc_emc105.htm'),
    ('2019-12-18', 'Lei 13.957/2019 (altera a LDO 2020)', 'lei',
     'inclui na LDO 2020 o RP 8 (emendas de comissao permanente do SF, CD e mista do CN) e o RP 9 (emendas de '
     'relator-geral, excluidas as de ordem tecnica): nascimento do RP 9',
     P + '_ato2019-2022/2019/lei/l13957.htm', 'marcos/l13957.htm'),
    ('2021-11-05', 'STF, ADPF 854 (e 850, 851), cautelar da ministra Rosa Weber', 'decisao judicial',
     'suspende integralmente a execucao do RP 9 do orcamento de 2021 e manda dar publicidade as demandas de RP 9 '
     'de 2020 e 2021; referendada pelo Plenario em sessao virtual encerrada em 10/11/2021',
     STF854, 'marcos/stf_adpf854_andamentos.html; marcos/camara_informativo_decisoes_stf_emendas_2025.pdf'),
    ('2021-12-06', 'STF, ADPF 854, decisao da relatora a pedido das Mesas', 'decisao judicial',
     'afasta a suspensao do item c da cautelar e autoriza a continuidade da execucao do RP 9, observados o Ato '
     'Conjunto das Mesas 1/2021 e a Resolucao CN 2/2021; referendada por maioria (vencidos Fachin e Carmen Lucia) '
     'em sessao virtual de 14 a 16/12/2021',
     STF854, 'marcos/stf_adpf854_andamentos.html; marcos/camara_informativo_decisoes_stf_emendas_2025.pdf'),
    ('2022-12-19', 'STF, ADPFs 850, 851, 854 e 1.014, julgamento de merito', 'decisao judicial',
     'por maioria, declara incompativeis com a Constituicao as praticas do "orcamento secreto" (uso das emendas do '
     'relator-geral para incluir despesas), declara inconstitucionais o art. 4 do Ato Conjunto 1/2021 e a Resolucao '
     'CN 2/2021, e veda usar o RP 9 das LOAs 2021 e 2022 para atender pedidos de parlamentares; ministros orientam '
     'a execucao, sem carater vinculante das indicacoes do relator',
     STF854, 'marcos/stf_adpf854_andamentos.html; marcos/senado_nota_informativa_decisoes_stf_2025-02-28.pdf'),
    ('2022-12-21', 'Emenda Constitucional 126/2022', 'emenda constitucional',
     'individuais passam a 2% da RCL do ano anterior ao projeto (1,55% deputados, 0,45% senadores); art. 8 autoriza o '
     'relator-geral do PLOA 2023 a apresentar ate R$ 9,85 bi em emendas classificadas como RP 2 (art. 7, par. 4, II, b '
     'da LDO 2023): destinacao dos recursos que eram RP 9 no projeto de 2023, parte para individuais e parte para '
     'discricionarias do Executivo',
     P + 'constituicao/emendas/emc/emc126.htm', 'marcos/constituicao_emendas_emc_emc126.htm; marcos/ldo2023_l14436.htm'),
    ('2024-08-01', 'STF, ADPFs 850, 851, 854 e 1.014, audiencia de conciliacao (ministro Flavio Dino)', 'decisao judicial',
     'vinculacao federativa das emendas ao estado do parlamentar; RP 8 e restos a pagar de RP 9 so pagos com '
     'previa e total transparencia e rastreabilidade; regras de contratacao para ONGs. Na pratica, suspende RP 8',
     STF854, 'marcos/stf_adpf854_andamentos.html; marcos/camara_informativo_decisoes_stf_emendas_2025.pdf'),
    ('2024-08-14', 'STF, ADI 7697, cautelar do ministro Flavio Dino', 'decisao judicial',
     'interpretacao conforme aos dispositivos das ECs 86, 100, 105 e 126: impositividade relativa, exige criterios de '
     'eficiencia, transparencia e rastreabilidade e suspende a execucao das emendas impositivas, salvo obras em '
     'andamento e calamidade; referendada por unanimidade em 19/08/2024',
     STF7697, 'marcos/stf_adi7697_andamentos.html; marcos/camara_informativo_decisoes_stf_emendas_2025.pdf'),
    ('2024-11-25', 'Lei Complementar 210/2024', 'lei complementar',
     'regras de proposicao e execucao de emendas (bancada so para projetos estruturantes; comissao so para acoes de '
     'interesse nacional ou regional; Pix com objeto e conta especifica; 27 hipoteses de impedimento tecnico; limite '
     'de crescimento: 2025 = limites constitucionais + R$ 11,5 bi para nao impositivas, depois corrigido pelo limite da '
     'LC 200 e pelo IPCA; contingenciamento na mesma proporcao das discricionarias)',
     P + 'leis/lcp/lcp210.htm', 'marcos/leis_lcp_lcp210.htm'),
    ('2024-12-02', 'STF, ADPF 854 e ADIs 7688, 7695 e 7697, decisao do ministro Flavio Dino', 'decisao judicial',
     'libera a execucao com condicoes (nome do parlamentar no Portal da Transparencia para restos a pagar de RP 9 '
     'e RP 8; Pix so com plano de trabalho aprovado; saude segundo criterios do SUS) e fixa que emendas nao podem '
     'crescer mais que as discricionarias do Executivo, o limite da LC 200 ou a RCL, o menor; referendada por '
     'unanimidade em sessao virtual encerrada em 03/12/2024',
     STF854 + ' (peca https://portal.stf.jus.br/processos/downloadPeca.asp?id=15372536666&ext=.pdf)',
     'marcos/stf_adpf854_decisao_2024-12-02.pdf'),
    ('2024-12-23', 'STF, ADPF 854, despacho do ministro Flavio Dino', 'decisao judicial',
     'diante de oficio de 17 lideres com 5.449 emendas de comissao (R$ 4,2 bi) sem aprovacao das comissoes, exige '
     'atas, contas especificas na saude e condiciona a execucao das emendas de 2025 a conclusao das medidas corretivas',
     STF854 + ' (peca https://portal.stf.jus.br/processos/downloadPeca.asp?id=15373158511&ext=.pdf)',
     'marcos/stf_adpf854_despacho_2024-12-23.pdf'),
    ('2025-02-26', 'STF, ADPF 854, homologacao do plano de trabalho dos Poderes', 'decisao judicial',
     'autoriza a retomada da execucao das emendas de 2025 e anteriores, com aprovacao ou convalidacao em ata para '
     'comissao e bancada; referendada por unanimidade em sessao virtual encerrada em 05/03/2025',
     STF854, 'marcos/stf_adpf854_andamentos.html; marcos/camara_informativo_decisoes_stf_emendas_2025.pdf'),
]
with open(os.path.join(RAIZ, 'Z-marcos.csv'), 'w', newline='', encoding='utf-8') as fo:
    w = csv.writer(fo)
    w.writerow(['frente', 'data', 'presidente', 'ato', 'tipo_ato', 'o_que_mudou', 'url_oficial', 'arquivo_local',
                'data_consulta'])
    for d, ato, t, oq, url, arq in MARCOS:
        a = int(d[:4])
        pres = presidente(a)
        if a == 2016 and d < '2016-05-12':
            pres = 'Dilma'
        elif a == 2016:
            pres = 'Temer'
        w.writerow(['Z', d, pres, ato, t, oq, url, '; '.join('brutos/Z/' + x.strip() for x in arq.split(';')),
                    CONSULTA])

print('ok: Z-emendas.csv, Z-emendas-participacao.csv, Z-marcos.csv')

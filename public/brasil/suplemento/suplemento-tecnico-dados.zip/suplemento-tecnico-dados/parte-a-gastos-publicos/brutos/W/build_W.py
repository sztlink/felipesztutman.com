#!/usr/bin/env python3
# Frente W: taxas e transmissao.
# Gera, na raiz gastos-publicos/:
#   W-curva-mensal.csv, W-selic-real.csv, W-dpf-estrutura.csv, W-juros-perimetros.csv, W-transmissao.csv
# Brutos proprios (brutos/W/, ver downloads.tsv):
#   olinda/focus_ipca12m_suavizada.json   BCB Olinda, Focus, IPCA 12 meses a frente, suavizada, base 0
#   olinda/focus_selic_reuniao.json       BCB Olinda, Focus, Selic esperada por reuniao do Copom, base 0
#   ipeadata/BM12_TJOVER12_valores.json   Ipeadata, Selic over acumulada no mes (% a.m.), fonte BCB
# Brutos de outras frentes, so leitura:
#   ../N/td/precotaxatesourodireto.csv    Tesouro Direto, taxas diarias
#   ../N/bcb/historicotaxasjuros.json     BCB, metas Selic por reuniao do Copom
#   ../N/ibge/sidra_1737_v2266.json       IBGE, IPCA numero-indice
#   ../O/rmd/anexo/Anexo RMD_Agosto_26.xlsx  Tesouro, anexos do RMD ago/2026
#   ../J/dl-*/ e ../I/bcb-*               BCB, Tabelas de estatisticas fiscais (NFSP, juros por indexador)
#   ../../N-juro-real-mensal.csv, ../../J-dbgg-fatores.csv, ../../J-dlsp-fatores-ajustes.csv,
#   ../../J-dbgg-composicao.csv, ../../J-dlsp-ativos.csv, ../../B-uniao-por-orgao-e-gnd.csv
# Rodar de fora da pasta dos dados:
#   cd /tmp && python3 -P gastos-publicos-brasil-dados/brutos/W/build_W.py
import csv, glob, json, os, re, datetime as dt
from collections import defaultdict, Counter
import openpyxl, xlrd

H = os.path.dirname(os.path.abspath(__file__))
BR = os.path.dirname(H)
ROOT = os.path.dirname(BR)
CONSULTA = '2026-10-19'
CONSULTA_N = '2026-10-18'

URL_TD = ('https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/'
          'resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv')
URL_COPOM = 'https://www.bcb.gov.br/api/servico/sitebcb/historicotaxasjuros'
URL_IPCA = 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'
URL_RMD = ('https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322 (RMD ago/2026, pagina '
           'https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8)')
URL_OL = 'https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/'
URL_IPEA = "http://www.ipeadata.gov.br/api/odata4/ValoresSerie(SERCODIGO='BM12_TJOVER12')"
U_TAB = 'https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/{}_Tabelas_de_estatisticas_fiscais.{}'

NTNB = 'Tesouro IPCA+ com Juros Semestrais'
NTNBP = 'Tesouro IPCA+'
NTNF = 'Tesouro Prefixado com Juros Semestrais'
LTN = 'Tesouro Prefixado'
SIGLA = {NTNB: 'NTN-B', NTNBP: 'NTN-B Principal', NTNF: 'NTN-F', LTN: 'LTN'}
INICIO = dt.date(2008, 1, 1)


def presidente_dia(d):
    if d <= dt.date(2010, 12, 31):
        return 'Lula 2'
    if d <= dt.date(2016, 5, 12):
        return 'Dilma'
    if d <= dt.date(2018, 12, 31):
        return 'Temer'
    if d <= dt.date(2022, 12, 31):
        return 'Bolsonaro'
    return 'Lula 3'


def presidente_mes(y, m):
    if (y, m) == (2016, 5):
        return 'Dilma/Temer'
    return presidente_dia(dt.date(y, m, 1))


def presidente_ano(y):
    if y == 2016:
        return 'Dilma/Temer'
    return presidente_dia(dt.date(y, 6, 1))


def r(x, n=4):
    return '' if x is None else round(x, n)


def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def fisher(a, b):
    return ((1 + a / 100) / (1 + b / 100) - 1) * 100


def pdate(s):
    d, m, y = s.split('/')
    return dt.date(int(y), int(m), int(d))


def num(s):
    s = (s or '').strip().replace('.', '').replace(',', '.') if s and ',' in s else (s or '').strip()
    try:
        return float(s)
    except ValueError:
        return None


def escreve(nome, cab, linhas):
    with open(os.path.join(ROOT, nome), 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(cab)
        for l in linhas:
            w.writerow(l)


# ====================================================================== 1. curva do Tesouro Direto
# Leitura identica a build_N.py (mesmos filtros), para que o vertice de 10 anos bata com N-juro-real-mensal.csv.
dia = defaultdict(dict)
with open(os.path.join(BR, 'N', 'td', 'precotaxatesourodireto.csv'), encoding='utf-8-sig', newline='') as f:
    rd = csv.reader(f, delimiter=';')
    head = next(rd)
    assert head[:5] == ['Tipo Titulo', 'Data Vencimento', 'Data Base', 'Taxa Compra Manha', 'Taxa Venda Manha'], head
    for row in rd:
        tipo = row[0]
        if tipo not in SIGLA:
            continue
        base = pdate(row[2])
        if base < INICIO:
            continue
        venc = pdate(row[1])
        if venc <= base:
            continue
        tx = num(row[3])
        if not num(row[5]) and not num(row[6]):
            continue
        if tx is None or tx == 0:
            tx = num(row[4])
        if tx is None or tx == 0:
            continue
        dia[base][(tipo, venc)] = tx


def interp_n(t, tipos, alvo, tol):
    """Igual a build_N.interp: interpolacao linear em dias; sem vizinho dos dois lados, titulo mais proximo ate tol dias."""
    nos = sorted((v, x, tp) for (tp, v), x in t.items() if tp in tipos)
    if not nos:
        return None
    ab = [n for n in nos if n[0] <= alvo]
    ac = [n for n in nos if n[0] >= alvo]
    if ab and ac:
        a, b = ab[-1], ac[0]
        if a[0] == b[0]:
            return a[1], '%s %s' % (SIGLA[a[2]], a[0])
        w = (alvo - a[0]).days / (b[0] - a[0]).days
        return a[1] + w * (b[1] - a[1]), 'interp %s %s / %s %s' % (SIGLA[a[2]], a[0], SIGLA[b[2]], b[0])
    n = ab[-1] if ab else ac[0]
    if abs((n[0] - alvo).days) <= tol:
        return n[1], 'mais proximo %s %s' % (SIGLA[n[2]], n[0])
    return None


MIN_DIAS = 60  # vertices curtos novos (1, 2, 3, 5 anos): ignora titulos a menos de 60 dias do vencimento


def vertice(t, base, familias, alvo, tol):
    """Tenta interpolar dentro de cada familia na ordem dada (so com vizinhos dos dois lados);
    depois na uniao das familias; por fim o titulo mais proximo da uniao ate tol dias."""
    tt = {k: v for k, v in t.items() if (k[1] - base).days >= MIN_DIAS}
    for fam in familias + [sum(familias, [])]:
        q = interp_n(tt, fam, alvo, 0)
        if q is not None and not q[1].startswith('mais proximo'):
            return q
    return interp_n(tt, sum(familias, []), alvo, tol)


PRE_V = [(1, 183), (3, 365), (5, 548)]       # (anos, tolerancia em dias para o mais proximo)
REAL_V = [(2, 365), (5, 548)]
DIAS = sorted(dia)
diario = []
for d in DIAS:
    t = dia[d]
    o = {'data': d}
    for a, tol in PRE_V:
        q = vertice(t, d, [[LTN], [NTNF]], d + dt.timedelta(days=round(365.25 * a)), tol)
        if q:
            o['pre%d' % a], o['pre%d_nos' % a] = q
    for a, tol in REAL_V:
        q = vertice(t, d, [[NTNB], [NTNBP]], d + dt.timedelta(days=round(365.25 * a)), tol)
        if q:
            o['real%d' % a], o['real%d_nos' % a] = q
    alvo = d + dt.timedelta(days=round(3652.5))
    b10 = interp_n(t, [NTNB], alvo, 1096)
    f10 = interp_n(t, [NTNF], alvo, 1096)
    if b10:
        o['real10'], o['real10_nos'] = b10
    if f10:
        o['pre10'], o['pre10_nos'] = f10
    for a in (5, 10):
        if o.get('pre%d' % a) is not None and o.get('real%d' % a) is not None:
            o['impl%d' % a] = fisher(o['pre%d' % a], o['real%d' % a])
    diario.append(o)
ULT_TD = DIAS[-1]

# N-juro-real-mensal.csv: Selic meta media do mes e vertice de 10 anos de N (para conferencia)
NM = {}
with open(os.path.join(ROOT, 'N-juro-real-mensal.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f):
        NM[row['mes']] = row

por_mes = defaultdict(list)
for o in diario:
    por_mes[(o['data'].year, o['data'].month)].append(o)


def moda(xs):
    xs = [x for x in xs if x]
    return Counter(xs).most_common(1)[0][0] if xs else ''


CURVA = {}   # (y, m) -> dict de medias
lin_curva = []
dif10 = []
for (y, m) in sorted(por_mes):
    L = por_mes[(y, m)]
    k = '%04d-%02d' % (y, m)
    c = {}
    for v in ('pre1', 'pre3', 'pre5', 'pre10', 'real2', 'real5', 'real10', 'impl5', 'impl10'):
        c[v] = mean([o.get(v) for o in L])
        c[v + '_n'] = sum(1 for o in L if o.get(v) is not None)
    c['selic'] = float(NM[k]['selic_meta_media_mes']) if k in NM and NM[k]['selic_meta_media_mes'] else None
    CURVA[(y, m)] = c
    if k in NM and NM[k]['prefixado_10a'] and c['pre10'] is not None:
        dif10.append(abs(float(NM[k]['prefixado_10a']) - c['pre10']))
        dif10.append(abs(float(NM[k]['juro_real_10a']) - c['real10']))
    nota = ('medias simples dos dias com cotacao; nos = par de titulos mais frequente no mes; 1, 3 e 5 anos: LTN primeiro, '
            'NTN-F se a LTN nao cobrir; NTN-B 2 e 5 anos: NTN-B com cupom primeiro, NTN-B Principal se nao cobrir; '
            '10 anos = metodo de N (curvas NTN-F e NTN-B com cupom)')
    if (y, m) == (ULT_TD.year, ULT_TD.month):
        nota += '; mes parcial, dados ate %s' % ULT_TD
    if (y, m) == (2016, 5):
        nota += '; mes de troca de governo (Dilma ate 12/05)'
    falta = [v for v in ('pre1', 'pre3', 'pre5', 'pre10', 'real2', 'real5', 'real10') if c[v + '_n'] < len(L)]
    if falta:
        nota += '; dias sem vertice: ' + ', '.join('%s %d de %d' % (v, len(L) - c[v + '_n'], len(L)) for v in falta)
    lin_curva.append([k, r(c['pre1']), moda([o.get('pre1_nos') for o in L]), r(c['pre3']), moda([o.get('pre3_nos') for o in L]),
                      r(c['pre5']), moda([o.get('pre5_nos') for o in L]), r(c['pre10']), moda([o.get('pre10_nos') for o in L]),
                      r(c['real2']), moda([o.get('real2_nos') for o in L]), r(c['real5']), moda([o.get('real5_nos') for o in L]),
                      r(c['real10']), moda([o.get('real10_nos') for o in L]), r(c['impl5']), r(c['impl10']),
                      r(c['selic']), r(c['pre1'] - c['selic'] if c['pre1'] is not None and c['selic'] is not None else None),
                      r(c['pre10'] - c['pre1'] if c['pre10'] is not None and c['pre1'] is not None else None),
                      len(L), presidente_mes(y, m), URL_TD + ' ; ../N-juro-real-mensal.csv (selic_meta_media_mes)',
                      CONSULTA_N, nota])
assert max(dif10) < 1e-3, ('vertice de 10 anos diverge de N', max(dif10))
escreve('W-curva-mensal.csv',
        ['mes', 'prefixado_1a', 'nos_prefixado_1a', 'prefixado_3a', 'nos_prefixado_3a', 'prefixado_5a', 'nos_prefixado_5a',
         'prefixado_10a', 'nos_prefixado_10a', 'juro_real_ntnb_2a', 'nos_ntnb_2a', 'juro_real_ntnb_5a', 'nos_ntnb_5a',
         'juro_real_ntnb_10a', 'nos_ntnb_10a', 'inflacao_implicita_5a', 'inflacao_implicita_10a', 'selic_meta_media_mes',
         'prefixado_1a_menos_selic_pp', 'inclinacao_pre_10a_menos_1a_pp', 'dias_td', 'presidente', 'fonte_url', 'consulta', 'nota'],
        lin_curva)

# ====================================================================== 2. Selic real
cop = json.load(open(os.path.join(BR, 'N', 'bcb', 'historicotaxasjuros.json'), encoding='utf-8'))['conteudo']
vig = sorted((dt.date.fromisoformat(c['DataInicioVigencia'][:10]),
              dt.date.fromisoformat(c['DataFimVigencia'][:10]) if c['DataFimVigencia'] else None, c['MetaSelic']) for c in cop)


def selic_meta(d):
    v = None
    for ini, fim, m in vig:
        if ini <= d and (fim is None or d <= fim):
            v = m
    return v


# calendario de reunioes ordinarias: Rk/AAAA -> data da reuniao. Datas futuras (sem reuniao no JSON) = mesma reuniao k de 2025
# com o ano trocado (aproximacao declarada no LEIAME).
ordin = defaultdict(list)
for c in cop:
    if not c['ReuniaoExtraordinaria']:
        ordin[int(c['DataReuniaoCopom'][:4])].append(dt.date.fromisoformat(c['DataReuniaoCopom'][:10]))
REUNIAO = {}
for y, L in ordin.items():
    for k, d in enumerate(sorted(L), 1):
        REUNIAO['R%d/%d' % (k, y)] = (d, 'observada')
for y in range(2026, 2031):
    for k in range(1, 9):
        key = 'R%d/%d' % (k, y)
        if key not in REUNIAO:
            d25 = REUNIAO['R%d/2025' % k][0]
            REUNIAO[key] = (d25.replace(year=y), 'aproximada (data da R%d/2025 com o ano trocado)' % k)

ip = {}
for x in json.load(open(os.path.join(BR, 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:]:
    try:
        ip[(int(x['D3C'][:4]), int(x['D3C'][4:]))] = float(x['V'])
    except ValueError:
        pass
ULT_IPCA = max(ip)


def addm(y, m, k):
    t = y * 12 + (m - 1) + k
    return (t // 12, t % 12 + 1)


def ipca12(y, m):
    a, b = ip.get((y, m)), ip.get(addm(y, m, -12))
    return (a / b - 1) * 100 if a and b else None


ov = {}
for x in json.load(open(os.path.join(H, 'ipeadata', 'BM12_TJOVER12_valores.json'), encoding='utf-8'))['value']:
    y, m = int(x['VALDATA'][:4]), int(x['VALDATA'][5:7])
    if x['VALVALOR'] is not None:
        ov[(y, m)] = x['VALVALOR']
ULT_OV = max(ov)
MES_OV_PARCIAL = ULT_OV if ULT_OV >= (int(CONSULTA[:4]), int(CONSULTA[5:7])) else None   # mes corrente: parcial (Ipeadata)


def selic_acum(y, m, n):
    """Selic over acumulada nos n meses seguintes a (y, m), % no periodo, so meses completos."""
    p = 1.0
    for k in range(1, n + 1):
        mm = addm(y, m, k)
        if mm not in ov or mm == MES_OV_PARCIAL:
            return None
        p *= 1 + ov[mm] / 100
    return (p - 1) * 100


def selic_acum_passada(y, m):
    p = 1.0
    for k in range(0, 12):
        mm = addm(y, m, -k)
        if mm not in ov or mm == MES_OV_PARCIAL:
            return None
        p *= 1 + ov[mm] / 100
    return (p - 1) * 100


# Focus IPCA 12 meses, suavizada, mediana, base 0 (todos os respondentes)
fip = defaultdict(list)
for x in json.load(open(os.path.join(H, 'olinda', 'focus_ipca12m_suavizada.json'), encoding='utf-8'))['value']:
    assert x['Indicador'] == 'IPCA' and x['Suavizada'] == 'S' and x['baseCalculo'] == 0
    d = dt.date.fromisoformat(x['Data'])
    fip[(d.year, d.month)].append(x['Mediana'])

# Focus Selic por reuniao: Selic esperada media nos 365 dias seguintes a cada data de pesquisa
fs = defaultdict(dict)
for x in json.load(open(os.path.join(H, 'olinda', 'focus_selic_reuniao.json'), encoding='utf-8'))['value']:
    assert x['baseCalculo'] == 0
    if x['Mediana'] is not None:
        fs[dt.date.fromisoformat(x['Data'])][x['Reuniao']] = x['Mediana']
sem_data = set()
exp_mes = defaultdict(list)
exp_fim = defaultdict(list)
cob_mes = defaultdict(list)
aprox_mes = defaultdict(int)
for d in sorted(fs):
    if d < INICIO:
        continue
    reun = []
    for k, v in fs[d].items():
        if k not in REUNIAO:
            sem_data.add(k)
            continue
        rd_, tipo = REUNIAO[k]
        if rd_ >= d:                          # reuniao no dia da pesquisa ou depois: decisao ainda nao conhecida
            reun.append((rd_ + dt.timedelta(days=1), v, tipo))
    reun.sort()
    cur = selic_meta(d)
    fim = d + dt.timedelta(days=365)
    tot, val, j = 0.0, cur, 0
    usa_aprox = False
    for i in range(1, 366):
        t = d + dt.timedelta(days=i)
        while j < len(reun) and reun[j][0] <= t:
            val = reun[j][1]
            usa_aprox = usa_aprox or not reun[j][2].startswith('observada')
            j += 1
        tot += val
    # cobertura: a ultima reuniao com expectativa precisa ser posterior a ultima reuniao (calendario) antes do fim da janela
    ult_cal = max((dd for (dd, _) in REUNIAO.values() if dd < fim), default=None)
    coberto = bool(reun) and reun[-1][0] - dt.timedelta(days=1) >= ult_cal
    exp_mes[(d.year, d.month)].append(tot / 365)
    v12 = cur
    for (ini, v, _) in reun:
        if ini <= fim:
            v12 = v
    exp_fim[(d.year, d.month)].append(v12)
    cob_mes[(d.year, d.month)].append(coberto)
    if usa_aprox:
        aprox_mes[(d.year, d.month)] += 1
assert not sem_data or all(int(k.split('/')[1]) < 2008 for k in sem_data), sorted(sem_data)

lin_sr = []
SR = {}
meses = sorted(k for k in CURVA)
for (y, m) in meses:
    k = '%04d-%02d' % (y, m)
    s_media = CURVA[(y, m)]['selic']
    s_fim = float(NM[k]['selic_meta_fim_mes']) if k in NM and NM[k]['selic_meta_fim_mes'] else None
    acum = selic_acum(y, m, 12)
    i_seg = (ip[addm(y, m, 12)] / ip[(y, m)] - 1) * 100 if (y, m) in ip and addm(y, m, 12) in ip else None
    ex_post = fisher(acum, i_seg) if acum is not None and i_seg is not None else None
    i_pas = ipca12(y, m)
    bis = fisher(s_fim, i_pas) if s_fim is not None and i_pas is not None else None
    bis_s = s_fim - i_pas if s_fim is not None and i_pas is not None else None
    s_pas = selic_acum_passada(y, m)
    ex_post_pas = fisher(s_pas, i_pas) if s_pas is not None and i_pas is not None else None
    f_ip = mean(fip.get((y, m), []))
    ex_ante = fisher(s_media, f_ip) if s_media is not None and f_ip is not None else None
    ex_ante_s = s_media - f_ip if s_media is not None and f_ip is not None else None
    e_med = mean(exp_mes.get((y, m), []))
    e_fim = mean(exp_fim.get((y, m), []))
    ex_ante_e = fisher(e_med, f_ip) if e_med is not None and f_ip is not None else None
    cob = cob_mes.get((y, m), [])
    nota = []
    if acum is None:
        nota.append('ex-post vazio: faltam 12 meses seguintes completos de Selic over ou de IPCA (IPCA ate %02d/%d, Selic over completa ate %02d/%d)'
                    % (ULT_IPCA[1], ULT_IPCA[0], addm(*ULT_OV, -1)[1] if MES_OV_PARCIAL else ULT_OV[1],
                       addm(*ULT_OV, -1)[0] if MES_OV_PARCIAL else ULT_OV[0]))
    if cob and not all(cob):
        nota.append('Focus Selic sem expectativa ate o fim da janela de 12 meses em %d de %d pesquisas (ultima expectativa mantida)'
                    % (sum(1 for c in cob if not c), len(cob)))
    if aprox_mes.get((y, m)):
        nota.append('%d pesquisas usam data aproximada de reuniao futura' % aprox_mes[(y, m)])
    if (y, m) == (ULT_TD.year, ULT_TD.month):
        nota.append('mes parcial')
    SR[(y, m)] = dict(ex_post=ex_post, bis=bis, ex_ante=ex_ante, ex_ante_e=ex_ante_e, ex_post_pas=ex_post_pas)
    lin_sr.append(['mensal', k, r(s_media), r(s_fim), r(acum), r(i_seg), r(ex_post), r(i_pas), r(bis), r(bis_s), r(s_pas),
                   r(ex_post_pas), r(f_ip), len(fip.get((y, m), [])), r(ex_ante), r(ex_ante_s), r(e_med), r(e_fim),
                   len(exp_mes.get((y, m), [])), r(ex_ante_e),
                   r(e_med - s_media if e_med is not None and s_media is not None else None),
                   presidente_mes(y, m),
                   '../N-juro-real-mensal.csv (Selic meta: %s) ; %s ; %s ; %sExpectativasMercadoInflacao12Meses ; %sExpectativasMercadoSelic'
                   % (URL_COPOM, URL_IPEA, URL_IPCA, URL_OL, URL_OL), CONSULTA, '; '.join(nota)])

# medias por mandato (meses inteiros do mandato; mai/2016 fica fora dos dois)
MAND = ['Lula 2', 'Dilma', 'Temer', 'Bolsonaro', 'Lula 3']
for md in MAND:
    ks = [(y, m) for (y, m) in meses if presidente_mes(y, m) == md and (y, m) != (ULT_TD.year, ULT_TD.month)]
    g = lambda c: mean([SR[k][c] for k in ks])
    n_ = lambda c: sum(1 for k in ks if SR[k][c] is not None)
    per = '%04d-%02d a %04d-%02d' % (ks[0] + ks[-1])
    nota = ('media simples dos meses do mandato (%s); meses com valor: ex-post %d, BIS %d, ex-ante meta %d, ex-ante esperada %d'
            % (per, n_('ex_post'), n_('bis'), n_('ex_ante'), n_('ex_ante_e')))
    if md == 'Lula 2':
        nota += '; so desde jan/2008'
    if md in ('Dilma', 'Temer'):
        nota += '; mai/2016 (Dilma/Temer) fora das duas medias'
    if md == 'Lula 3':
        nota += '; out/2026 (parcial) fora; ex-post so ate a ultima janela completa'
    lin_sr.append(['media_mandato', md, '', '', '', '', r(g('ex_post')), '', r(g('bis')), '', '', r(g('ex_post_pas')), '', '',
                   r(g('ex_ante')), '', '', '', '', r(g('ex_ante_e')), '', md, 'calculado sobre as linhas mensais deste arquivo',
                   CONSULTA, nota])
escreve('W-selic-real.csv',
        ['tipo', 'mes_ou_mandato', 'selic_meta_media_mes', 'selic_meta_fim_mes', 'selic_over_acum_12m_seguintes',
         'ipca_12m_seguintes', 'selic_real_ex_post_12m_seguintes', 'ipca_12m_passados', 'selic_real_bis_meta_menos_ipca_passado',
         'selic_real_bis_diferenca_simples', 'selic_over_acum_12m_passados', 'selic_real_realizada_12m_passados',
         'focus_ipca_12m_mediana_suavizada', 'focus_ipca_n_pesquisas', 'selic_real_ex_ante_meta',
         'selic_real_ex_ante_meta_diferenca_simples', 'focus_selic_media_esperada_12m', 'focus_selic_esperada_em_12m',
         'focus_selic_n_pesquisas', 'selic_real_ex_ante_selic_esperada', 'selic_esperada_menos_meta_pp', 'presidente',
         'fonte_url', 'consulta', 'nota'], lin_sr)

# ====================================================================== 3. estrutura da DPF (RMD)
wb = openpyxl.load_workbook(os.path.join(BR, 'O', 'rmd', 'anexo', 'Anexo RMD_Agosto_26.xlsx'), read_only=True, data_only=True)
MESES = {'Jan': 1, 'Fev': 2, 'Mar': 3, 'Abr': 4, 'Mai': 5, 'Jun': 6, 'Jul': 7, 'Ago': 8, 'Set': 9, 'Out': 10, 'Nov': 11, 'Dez': 12}


def ym(s):
    a, b = s.strip().split('/')
    return (2000 + int(b), MESES[a.strip()[:3]])


def colunar(sh, hdr_row, labels, block_start=None):
    """Planilhas com meses nas colunas (3.7, 3.8, 3.10, 4.2). labels: {chave: (rotulo, ordem)}; devolve chave -> {(y,m): v}."""
    rows = list(wb[sh].iter_rows(values_only=True))
    hdr = rows[hdr_row]
    lin = defaultdict(list)
    for rw in rows:
        if rw and isinstance(rw[0], str):
            lin[rw[0].strip()].append(rw)
    out = {}
    for k, (rot, ordem) in labels.items():
        rw = lin[rot][ordem]
        out[k] = {}
        for j, h in enumerate(hdr):
            if isinstance(h, str) and '/' in h and isinstance(rw[j], (int, float)):
                out[k][ym(h)] = float(rw[j])
    return out


def linhas_data(sh):
    """Planilhas com meses nas linhas (2.4, 3.1, 3.2, 3.3): lista de blocos [(titulo, {(y,m): row})]."""
    blocos, tit, cur = [], None, None
    for rw in wb[sh].iter_rows(values_only=True):
        if not rw:
            continue
        c0 = rw[0]
        if isinstance(c0, str) and c0.strip() and not c0.strip().startswith(('Obs', 'Mês', 'ANEXO', '(R$')):
            tit = c0.strip()
            cur = {}
            blocos.append((tit, cur))
        elif isinstance(c0, dt.datetime):
            if cur is None:
                cur = {}
                blocos.append(('', cur))
            cur[(c0.year, c0.month)] = rw
    return blocos


comp = {}
for t, b in linhas_data('2.4'):
    comp.update(b)
v31 = {t: b for t, b in linhas_data('3.1')}
v32 = {t: b for t, b in linhas_data('3.2')}
assert set(['DPF', 'DPMFi', 'DPFe']) <= set(v31), v31.keys()
assert set(['Prefixados', 'Taxa Flutuante', 'Índice de Preços', 'Câmbio']) <= set(v32), v32.keys()
pm = colunar('3.7', 4, {'dpf': ('DPF', 0), 'dpmfi': ('DPMFi', 0), 'dpfe': ('DPFe', 0)})
pmi = colunar('3.8', 4, {'pre': ('Prefixados', 0), 'ip': ('Índice de Preços', 0), 'flut': ('Taxa Flutuante', 0),
                         'cam': ('Câmbio', 0)})
vm = colunar('3.10', 4, {'dpf': ('DPF', 0), 'dpmfi': ('DPMFi', 0), 'pre': ('Prefixado', 0), 'ip': ('Índice de Preços', 0),
                         'flut': ('Taxa Flutuante', 0), 'dpfe': ('DPFe', 0)})
cm = colunar('4.2', 4, {'dpf': ('DPF', 0), 'dpmfi': ('DPMFi', 0), 'lft': ('LFT', 0), 'ltn': ('LTN', 0), 'ntnb': ('NTN-B', 0),
                        'ntnf': ('NTN-F', 0), 'dpfe': ('DPFe', 0)})
rows = list(wb['4.3'].iter_rows(values_only=True))
h4, h5 = rows[4], rows[5]
lin3 = {(rw[0] or '').strip(): rw for rw in rows if rw and isinstance(rw[0], str)}
cme = defaultdict(dict)
for j, h in enumerate(h5):
    if isinstance(h, str) and '/' in h:
        for t in ('DPMFi', 'LTN', 'NTN-F', 'NTN-B', 'LFT'):
            v = lin3[t][j]
            if isinstance(v, (int, float)):
                cme[t][ym(h)] = (float(v), 'antiga')
for j, h in enumerate(h4):
    if isinstance(h, str) and '/' in h:
        assert (h5[j + 2] or '').strip() == 'CME', (h, h5[j + 2])
        for t in ('DPMFi', 'LTN', 'NTN-F', 'NTN-B', 'LFT'):
            v = lin3[t][j + 2]
            if isinstance(v, (int, float)):
                cme[t][ym(h)] = (float(v), 'nova')

ULT_RMD = max(cm['dpf'])
periodos = [((y, 12), 'anual_dez') for y in range(2008, 2026)] + [((2026, m), 'mensal_2026') for m in range(1, ULT_RMD[1] + 1)]


def janela12(y, m, campo):
    v = [CURVA[addm(y, m, -k)][campo] for k in range(12) if addm(y, m, -k) in CURVA]
    return mean(v) if len(v) == 12 else None


lin_dpf = []
EST = {}
for (y, m), tipo in periodos:
    c = comp[(y, m)]
    tot = c[11]
    d31, dm, de = v31['DPF'][(y, m)], v31['DPMFi'][(y, m)], v31['DPFe'][(y, m)]
    g32 = lambda t: v32[t][(y, m)][2] if isinstance(v32[t][(y, m)][2], (int, float)) else None
    i12 = ipca12(y, m)
    cdpf = cm['dpf'].get((y, m))
    ce = cme['DPMFi'].get((y, m))
    pre10_12, real10_12 = janela12(y, m, 'pre10'), janela12(y, m, 'real10')
    nota = []
    if ce and ce[1] == 'nova':
        nota.append('custo de emissoes pela metodologia nova (CME, jan/2021+), quebra de serie')
    if ce is None:
        nota.append('custo de emissoes: anexo 4.3 so comeca em dez/2010')
    if y < 2014 or (y, m) == (2013, 12):
        nota.append('vida media pela metodologia antiga (nova desde jan/2014)')
    if tipo == 'mensal_2026':
        nota.append('IPCA e custos em 12 meses ate %02d/%d' % (m, y))
    EST[(y, m)] = dict(tot=tot, pre=c[1], ip=c[3], flut=c[5], cam=c[7])
    lin_dpf.append([
        '%04d-%02d' % (y, m), tipo, r(tot, 2), r(c[2] * 100, 2), r(c[4] * 100, 2), r(c[6] * 100, 2), r(c[8] * 100, 2),
        r(pm['dpf'].get((y, m)), 2), r(pm['dpmfi'].get((y, m)), 2), r(pmi['pre'].get((y, m)), 2), r(pmi['ip'].get((y, m)), 2),
        r(pmi['flut'].get((y, m)), 2), r(pmi['cam'].get((y, m)), 2), r(pm['dpfe'].get((y, m)), 2),
        r(vm['dpf'].get((y, m)), 2), r(vm['dpmfi'].get((y, m)), 2), r(vm['pre'].get((y, m)), 2), r(vm['ip'].get((y, m)), 2),
        r(vm['flut'].get((y, m)), 2), r(vm['dpfe'].get((y, m)), 2),
        r(d31[1], 2), r(d31[2] * 100, 2), r(dm[2] * 100, 2), r(de[2] * 100, 2),
        r(g32('Prefixados') * 100, 2), r(g32('Índice de Preços') * 100, 2), r(g32('Taxa Flutuante') * 100, 2),
        r((g32('Câmbio') or 0) * 100, 2),
        r(cdpf, 2), r(cm['dpmfi'].get((y, m)), 2), r(cm['lft'].get((y, m)), 2), r(cm['ltn'].get((y, m)), 2),
        r(cm['ntnb'].get((y, m)), 2), r(cm['ntnf'].get((y, m)), 2), r(cm['dpfe'].get((y, m)), 2),
        r(ce[0] if ce else None, 2), ce[1] if ce else '',
        r(cme['LTN'].get((y, m), (None,))[0], 2), r(cme['NTN-F'].get((y, m), (None,))[0], 2),
        r(cme['NTN-B'].get((y, m), (None,))[0], 2), r(cme['LFT'].get((y, m), (None,))[0], 2),
        r(i12, 2), r(fisher(cdpf, i12) if cdpf is not None and i12 is not None else None, 2),
        r(fisher(ce[0], i12) if ce and i12 is not None else None, 2),
        r(pre10_12, 2), r(real10_12, 2), r(CURVA[(y, m)]['pre10'], 2), r(CURVA[(y, m)]['real10'], 2),
        r(janela12(y, m, 'selic'), 2),
        r(cdpf - pre10_12 if cdpf is not None and pre10_12 is not None else None, 2),
        presidente_ano(y) if tipo == 'anual_dez' else presidente_mes(y, m),
        URL_RMD + ' anexos 2.4, 3.1, 3.2, 3.7, 3.8, 3.10, 4.2, 4.3 ; ' + URL_IPCA + ' ; W-curva-mensal.csv',
        CONSULTA_N, '; '.join(nota)])
escreve('W-dpf-estrutura.csv',
        ['periodo', 'tipo', 'estoque_dpf_rs_bi', 'pct_prefixado', 'pct_indice_precos', 'pct_taxa_flutuante', 'pct_cambio',
         'prazo_medio_dpf_anos', 'prazo_medio_dpmfi_anos', 'prazo_medio_prefixado_anos', 'prazo_medio_indice_precos_anos',
         'prazo_medio_taxa_flutuante_anos', 'prazo_medio_cambio_dpmfi_anos', 'prazo_medio_dpfe_anos',
         'vida_media_dpf_anos', 'vida_media_dpmfi_anos', 'vida_media_prefixado_anos', 'vida_media_indice_precos_anos',
         'vida_media_taxa_flutuante_anos', 'vida_media_dpfe_anos',
         'vincendo_12m_dpf_rs_bi', 'vincendo_12m_dpf_pct', 'vincendo_12m_dpmfi_pct', 'vincendo_12m_dpfe_pct',
         'vincendo_12m_prefixado_pct_do_indexador', 'vincendo_12m_indice_precos_pct_do_indexador',
         'vincendo_12m_taxa_flutuante_pct_do_indexador', 'vincendo_12m_cambio_dpmfi_pct_do_indexador',
         'custo_medio_dpf_12m', 'custo_medio_dpmfi_12m', 'custo_medio_lft_12m', 'custo_medio_ltn_12m', 'custo_medio_ntnb_12m',
         'custo_medio_ntnf_12m', 'custo_medio_dpfe_12m', 'custo_emissoes_dpmfi_12m', 'metodologia_emissoes',
         'custo_emissoes_ltn_12m', 'custo_emissoes_ntnf_12m', 'custo_emissoes_ntnb_12m', 'custo_emissoes_lft_12m',
         'ipca_12m', 'juro_real_custo_estoque', 'juro_real_custo_emissoes', 'mercado_prefixado_10a_media_12m',
         'mercado_ntnb_10a_real_media_12m', 'mercado_prefixado_10a_mes', 'mercado_ntnb_10a_real_mes', 'selic_meta_media_12m',
         'custo_estoque_menos_prefixado_10a_pp', 'presidente', 'fonte_url', 'consulta', 'nota'], lin_dpf)

# ====================================================================== 4. juros nos tres perimetros
def abre(f):
    if f.endswith('.xlsx'):
        w = openpyxl.load_workbook(f, read_only=True, data_only=True)
        return {n: [list(x) for x in w[n].iter_rows(values_only=True)] for n in w.sheetnames}
    w = xlrd.open_workbook(f)
    return {n: [w.sheet_by_name(n).row_values(i) for i in range(w.sheet_by_name(n).nrows)] for n in w.sheet_names()}


def txt(c):
    return c.strip() if isinstance(c, str) else ''


def ano_int(c):
    if isinstance(c, (int, float)) and 2000 <= c <= 2030 and float(c).is_integer():
        return int(c)
    if isinstance(c, str) and re.fullmatch(r'\s*20\d\d\s*', c):
        return int(c)
    return None


EDS = []
for f in glob.glob(os.path.join(BR, 'J', 'dl-20??01', '*_Tabelas_de_estatisticas_fiscais.xls*')) + \
        glob.glob(os.path.join(BR, 'I', 'bcb-*_Tabelas_de_estatisticas_fiscais.xls*')):
    ed = re.search(r'(\d{6})_Tabelas', f).group(1)
    EDS.append((ed, f))
EDS.sort()
assert len(set(ed for ed, _ in EDS)) == len(EDS), 'edicao repetida entre J e I'

NF_ROT = [('consolidado', 'Juros nominais'), ('governo_central', 'Governo Central'), ('governo_federal_inss', 'Governo Federal'),
          ('bcb', 'Bacen'), ('governos_regionais', 'Governos regionais'), ('estaduais', 'Governos estaduais'),
          ('municipais', 'Governos municipais'), ('estatais', 'Empresas estatais')]
nfsp = {}      # ano -> (ed, f, {chave: (rs_mi, pct)}, pib)
jidx = {}      # ano -> (ed, f, {col: rs_mi})
for ed, f in EDS:
    T = abre(f)
    for n, L in T.items():
        cab = ' '.join(txt(c) for rw in L[:3] for c in rw)
        if re.search(r'financiamento do setor p', cab) and 'acumulados no ano' in cab and 'indexador' not in cab:
            i_ano = next((i for i, rw in enumerate(L[:15]) if sum(1 for c in rw if ano_int(c)) >= 3), None)
            i_jd = next((i for i, rw in enumerate(L[:15]) if any(txt(c).lower() == 'jan-dez' for c in rw)), None)
            if i_ano is None or i_jd is None:
                continue
            cols = {}
            for j, c in enumerate(L[i_ano]):
                a = ano_int(c)
                if a and j < len(L[i_jd]) and txt(L[i_jd][j]).lower() == 'jan-dez':
                    cols[a] = j
            i_j = next(i for i, rw in enumerate(L) if txt(rw[0]).startswith('Juros nominais'))
            i_pib = next((i for i, rw in enumerate(L) if txt(rw[0]).startswith('PIB')), None)
            bloco = {}
            for i in range(i_j, i_j + 14):
                rot = re.sub(r'\d/$', '', txt(L[i][0])).strip()
                if i > i_j and not rot:
                    break
                for k, alvo in NF_ROT:
                    if rot.startswith(alvo) and k not in bloco:
                        bloco[k] = i
            for a, j in cols.items():
                vals = {k: (L[i][j], L[i][j + 1]) for k, i in bloco.items()}
                if not all(isinstance(v[0], (int, float)) and isinstance(v[1], (int, float)) for v in vals.values()):
                    continue
                pib = vals['consolidado'][0] / (vals['consolidado'][1] / 100) / 1000   # R$ bi
                if a not in nfsp or ed > nfsp[a][0]:
                    nfsp[a] = (ed, f, vals, pib, n)
            break
    for n, L in T.items():
        cab = ' '.join(txt(c) for rw in L[:3] for c in rw)
        if 'Juros nominais por indexador' in cab:
            i_lab = next(i for i, rw in enumerate(L[:12]) if any(txt(c) == 'Outros' for c in rw))
            jo = next(j for j, c in enumerate(L[i_lab]) if txt(c) == 'Outros')
            js = next(j for j, c in enumerate(L[i_lab]) if txt(c) == 'Selic')
            anos_lin = [(i, ano_int(rw[0])) for i, rw in enumerate(L) if rw and ano_int(rw[0])]
            for idx, (i, a) in enumerate(anos_lin):
                prox = anos_lin[idx + 1][0] if idx + 1 < len(anos_lin) else len(L)
                meses_b = [txt(L[q][1]) for q in range(i + 1, prox) if len(L[q]) > 1]
                completo = idx + 1 < len(anos_lin) or 'Dez' in meses_b
                if not completo or not isinstance(L[i][jo], (int, float)):
                    continue
                tot = max(j for j, c in enumerate(L[i]) if isinstance(c, (int, float)))
                if a not in jidx or ed > jidx[a][0]:
                    jidx[a] = (ed, f, {'outros': L[i][jo], 'selic': L[i][js], 'total': L[i][tot]})
            break


def le_long(nome):
    out = {}
    with open(os.path.join(ROOT, nome), encoding='utf-8') as fh:
        for row in csv.DictReader(fh):
            if row['valor_rs_mi']:
                out[(row['serie'], int(row['ano']))] = row
    return out


JF = le_long('J-dbgg-fatores.csv')
JA = le_long('J-dlsp-fatores-ajustes.csv')
JC = le_long('J-dbgg-composicao.csv')
JD = le_long('J-dlsp-ativos.csv')
rows29 = list(wb['2.9'].iter_rows(values_only=True))
hdr29 = rows29[6]
l29 = defaultdict(list)
for rw in rows29:
    if rw and isinstance(rw[0], str):
        l29[rw[0].strip()].append(rw)
J29 = {}
for j, h in enumerate(hdr29):
    if isinstance(h, int):
        J29[h] = dict(dpf=l29['I.2 - Juros  Apropriados'][0][j], dpmfi=[x for k, x in l29.items() if k.startswith('- Juros Apropriados da DPMFi')][0][0][j],
                      dpfe=[x for k, x in l29.items() if k.startswith('- Juros Apropriados da DPFe')][0][0][j],
                      pag_dpmfi=[x for k, x in l29.items() if k.startswith('- Pagamentos Correntes (DPMFi)')][0][0][j],
                      estoque=l29['Estoque mês em análise'][0][j])
# orcamento 2025, juros e encargos pagos (frente B, regime de caixa)
GND2 = {}
with open(os.path.join(ROOT, 'B-uniao-por-orgao-e-gnd.csv'), encoding='utf-8') as fh:
    for row in csv.DictReader(fh):
        if row['subcategoria'] == 'juros e encargos (GND 2)' and row['estagio'] == 'pago_exercicio' and row['categoria'].startswith('ORGAO: DÍVIDA'):
            GND2[int(row['ano'])] = (float(row['valor_brl']) / 1e9, row['fonte_url'], row['data_fonte'])

lin_j = []
CONC = {}


def add(ano, perim, serie, rs_bi, pib, fonte, edicao, nota, pct=None):
    p = pct if pct is not None else (rs_bi / pib * 100 if rs_bi is not None and pib else None)
    lin_j.append([ano, perim, serie, r(rs_bi, 2), r(p, 3), presidente_ano(ano), fonte, edicao, CONSULTA, nota])
    return p


for a in range(2008, 2026):
    ed, f, vals, pib, sh = nfsp[a]
    fn = U_TAB.format(ed, 'xlsx' if f.endswith('x') else 'xls')
    P1 = 'P1 setor publico consolidado (NFSP, BCB)'
    for k, _ in NF_ROT:
        add(a, P1, 'nfsp_juros_nominais_' + k, vals[k][0] / 1000, pib, fn, ed,
            '%s, fluxo acumulado jan-dez, %% do PIB publicado na edicao%s' % (sh, '; Governo Federal inclui INSS' if 'federal' in k else ''),
            pct=vals[k][1])
    nf = vals['consolidado'][0] / 1000
    if a in jidx:
        e2, f2, v2 = jidx[a]
        add(a, P1, 'nfsp_juros_nominais_indexador_selic', v2['selic'] / 1000, pib, U_TAB.format(e2, 'xlsx' if f2.endswith('x') else 'xls'), e2,
            'juros nominais por indexador, coluna Selic (LFT, compromissadas, aplicacoes e divida bancaria de todas as esferas); % sobre o PIB da linha consolidado')
        add(a, P1, 'nfsp_juros_nominais_indexador_outros_inclui_swap', v2['outros'] / 1000, pib, U_TAB.format(e2, 'xlsx' if f2.endswith('x') else 'xls'), e2,
            'juros nominais por indexador, coluna Outros: dividas securitizadas e resultado caixa das operacoes de swap cambial do BCB (definicao da tabela); positivo = perda')
    P3 = 'P3 divida bruta do governo geral (DBGG, BCB)'
    jt = JF.get(('dbgg_fat_juros_nominais', a))
    dbgg = float(jt['valor_rs_mi']) / 1000
    add(a, P3, 'dbgg_juros_nominais_total', dbgg, pib, jt['fonte_url'], jt['edicao'],
        'lido de J-dbgg-fatores.csv (fatores condicionantes da DBGG); %% sobre o PIB da linha P1 do mesmo ano (publicado por J: %s)' % jt['valor_pct_pib'])
    det = {}
    for s, rot in [('dbgg_det_interna_exceto_compromissadas_juros_nominais', 'interna exceto compromissadas'),
                   ('dbgg_det_compromissadas_bcb_juros_nominais', 'compromissadas do BCB'),
                   ('dbgg_det_externa_juros_nominais', 'externa')]:
        x = JF.get((s, a))
        if x:
            det[s] = float(x['valor_rs_mi']) / 1000
            add(a, P3, s.replace('dbgg_det_', 'dbgg_juros_'), det[s], pib, x['fonte_url'], x['edicao'],
                'lido de J-dbgg-fatores.csv, detalhamento por instrumento (%s)' % rot)
    P2 = 'P2 divida publica federal (DPF, Tesouro, RMD)'
    j29 = J29[a]
    dpf = j29['dpf'] / 1000
    add(a, P2, 'dpf_juros_apropriados_total', dpf, pib, URL_RMD + ' anexo 2.9', 'RMD ago/2026',
        'juros apropriados (competencia) da DPF em poder do publico; DPFe inclui a variacao cambial; % sobre o PIB da linha P1')
    add(a, P2, 'dpf_juros_apropriados_dpmfi', j29['dpmfi'] / 1000, pib, URL_RMD + ' anexo 2.9', 'RMD ago/2026',
        'atualizacao monetaria do principal e juros reais da DPMFi')
    add(a, P2, 'dpf_juros_apropriados_dpfe_com_cambio', j29['dpfe'] / 1000, pib, URL_RMD + ' anexo 2.9', 'RMD ago/2026',
        'juros e variacao cambial da DPFe em reais')
    add(a, P2, 'dpf_pagamentos_correntes_dpmfi_caixa', -j29['pag_dpmfi'] / 1000, pib, URL_RMD + ' anexo 2.9', 'RMD ago/2026',
        'memo, regime de caixa: amortizacao mais juros pagos da DPMFi em mercado no ano (nao e despesa de juros)')
    # conciliacao
    PC = 'conciliacao'
    g = lambda s: float(JA[(s, a)]['valor_rs_mi']) / 1000 if (s, a) in JA else None
    cu, bnd, oc, ext = g('dlspaj_gf_conta_unica_juros_nominais'), g('dlspaj_gf_cred_ifo_total_juros_nominais'), \
        g('dlspaj_gf_outros_creditos_juros_nominais'), g('dlspaj_ext_bcb_juros_nominais')
    add(a, PC, 'c1_dbgg_menos_nfsp', dbgg - nf, pib, 'calculado: P3 total menos P1 consolidado', '',
        'o que a DBGG conta e a NFSP liquida: juros sobre ativos do setor publico (negativos na NFSP), resultado de swaps e passivos do BCB fora da DBGG')
    if cu is not None:
        add(a, PC, 'c1m_memo_conta_unica_cancela_na_consolidacao', -cu, pib, JA[('dlspaj_gf_conta_unica_juros_nominais', a)]['fonte_url'],
            JA[('dlspaj_gf_conta_unica_juros_nominais', a)]['edicao'],
            'memo, nao entra na ponte: remuneracao da conta unica do Tesouro no BCB (lido de J-dlsp-fatores-ajustes.csv, sinal trocado). '
            'E ativo do GF e passivo do BCB: na NFSP consolidada se anula com a renda do BCB sobre titulos do Tesouro em carteira; '
            'nao explica a diferenca entre DBGG e NFSP, mas aparece se o governo federal for olhado sozinho')
    if bnd is not None or oc is not None:
        add(a, PC, 'c1b_juros_recebidos_creditos_gf_bndes_e_outros', -((bnd or 0) + (oc or 0)), pib, 'J-dlsp-fatores-ajustes.csv', '',
            'creditos do GF junto a instituicoes financeiras oficiais (BNDES) e outros creditos, sinal trocado')
    if ext is not None:
        add(a, PC, 'c1c_juros_divida_externa_liquida_bcb_reservas', -ext, pib, JA[('dlspaj_ext_bcb_juros_nominais', a)]['fonte_url'],
            JA[('dlspaj_ext_bcb_juros_nominais', a)]['edicao'],
            'divida externa liquida do BCB (reservas internacionais menos passivos externos), sinal trocado: positivo = rendimento das reservas abate a NFSP')
    if a in jidx:
        add(a, PC, 'c1d_resultado_swap_e_securitizadas_na_nfsp', -jidx[a][2]['outros'] / 1000, pib, 'linha nfsp_juros_nominais_indexador_outros_inclui_swap', '',
            'sinal trocado: positivo = ganho de swap que reduz a NFSP sem passar pela DBGG')
    expl = sum(x for x in [-((bnd or 0) + (oc or 0)) if (bnd is not None or oc is not None) else None,
                           -ext if ext is not None else None, -jidx[a][2]['outros'] / 1000 if a in jidx else None] if x is not None)
    add(a, PC, 'c1e_residuo_nao_decomposto', dbgg - nf - expl, pib, 'calculado', '',
        'resto de c1 depois de c1b a c1d (ponte: P3 = P1 + c1b + c1c + c1d + c1e). Contem, sem valor separado nas tabelas lidas: '
        'remuneracao de passivos do BCB que estao na NFSP e fora da DBGG (depositos compulsorios e voluntarios remunerados), '
        'juros sobre outros ativos (aplicacoes de estados, municipios e estatais, FAT, fundos), juros de estatais e diferencas de safra entre as tabelas')
    comp_ = det.get('dbgg_det_compromissadas_bcb_juros_nominais')
    add(a, PC, 'c2_dbgg_menos_dpf', dbgg - dpf, pib, 'calculado: P3 total menos P2 total', '',
        'o que a DBGG tem e a DPF nao: compromissadas do BCB, divida bancaria e externa de estados e municipios; e a DPF tem e a DBGG nao: variacao cambial da DPFe (que na DBGG e fator separado)')
    if comp_ is not None:
        add(a, PC, 'c2a_juros_compromissadas_bcb', comp_, pib, 'linha dbgg_juros_compromissadas_bcb_juros_nominais', '',
            'custo de esterilizacao pago pelo BCB e contado na DBGG conceito Bacen, fora da DPF')
    xc = JF.get(('dbgg_fat_cambial_divida_externa', a))
    camb = float(xc['valor_rs_mi']) / 1000 if xc else None
    if camb is not None:
        add(a, PC, 'c2b_variacao_cambial_divida_externa_dbgg', camb, pib, xc['fonte_url'], xc['edicao'],
            'lido de J-dbgg-fatores.csv; na DPF entra nos juros apropriados da DPFe, na DBGG e fator separado; por isso entra com sinal + na ponte P3 = P2 + c2a - c2b + c2c')
    add(a, PC, 'c2c_residuo_nao_decomposto', dbgg - dpf - (comp_ or 0) + (camb or 0), pib, 'calculado', '',
        'resto de c2 depois de compromissadas e cambio: divida bancaria e externa de estados, municipios e GF, '
        'securitizadas, titulos de nao residentes e diferencas de criterio entre Tesouro (DPF em poder do publico) e BCB (mobiliaria em mercado)')
    if a in GND2:
        v, fu, df = GND2[a]
        add(a, PC, 'c3_memo_juros_e_encargos_pagos_orcamento_caixa', v, pib, fu, df,
            'lido de B-uniao-por-orgao-e-gnd.csv: GND 2 pago, todos os orgaos. Caixa e classificacao orcamentaria: juros de LTN e LFT pagos no resgate '
            'podem cair em amortizacao (GND 6), por isso fica abaixo dos juros por competencia; diferenca nao decomposta')
    CONC[a] = dict(nf=nf, dbgg=dbgg, dpf=dpf, pib=pib, comp=comp_)
escreve('W-juros-perimetros.csv',
        ['ano', 'perimetro', 'serie', 'valor_rs_bi', 'pct_pib', 'presidente', 'fonte_url', 'edicao', 'consulta', 'nota'], lin_j)

# ====================================================================== 5. transmissao
# Estrutura de dez/2025: estoques por indexador e perfil de vencimentos da DPMFi (RMD 3.2) e da DPFe (RMD 3.1).
BASE = (2025, 12)
FAIXAS = ['ate 1 ano', '1 a 2 anos', '2 a 3 anos', '3 a 4 anos', '4 a 5 anos', 'acima de 5 anos']


def perfil(bloco):
    rw = bloco[BASE]
    s = [rw[1 + 2 * i] for i in range(6)]
    return rw[13], [x / rw[13] for x in s]


S_pre, b_pre = perfil(v32['Prefixados'])
S_ip, b_ip = perfil(v32['Índice de Preços'])
S_fl, b_fl = perfil(v32['Taxa Flutuante'])
S_cd, b_cd = perfil(v32['Câmbio'])
S_fe, b_fe = perfil(v31['DPFe'])
S_tot = EST[BASE]['tot']
assert abs(S_pre + S_ip + S_fl + S_cd + S_fe - S_tot) < 1, (S_pre + S_ip + S_fl + S_cd + S_fe, S_tot)
c_base = cm['dpf'][BASE]
PIB25 = CONC[2025]['pib']
comp_dez25 = float(JC[('dbgg_compromissadas_bcb', 2025)]['valor_rs_mi']) / 1000
# variante de estoque crescendo: taxa nominal media observada 2023-2025 (DPF, RMD 2.9) e PIB pela mesma janela (PIB das linhas P1)
g_dpf = (J29[2025]['estoque'] / J29[2022]['estoque']) ** (1 / 3) - 1
g_pib = (CONC[2025]['pib'] / CONC[2022]['pib']) ** (1 / 3) - 1

CHOQUES = {
    'selic_1pp': dict(desc='+1 ponto so na Selic; curva de prefixados e NTN-B parada por premissa', lft=1.0, pre=0.0, ip=0.0, comp=1.0),
    'curva_paralela_1pp': dict(desc='+1 ponto paralelo: Selic e toda a curva (novas emissoes de prefixados e NTN-B, juro real com inflacao implicita parada)',
                               lft=1.0, pre=1.0, ip=1.0, comp=1.0),
    'premio_risco_1pp': dict(desc='+1 ponto so no premio de risco: curva de prefixados e NTN-B sobe, Selic parada', lft=0.0, pre=1.0, ip=1.0, comp=0.0),
}
FORM = ('dJ_k = S_LFT,k x dSelic + dr_pre x [S_pre,0 x E_pre,k + N_pre,k] + dr_ip x [S_ip,0 x E_ip,k + N_ip,k]; '
        'E_i,k = soma(b_i,j, j<k) + b_i,k/2 (vencimentos uniformes dentro do ano); b_i,j = parcela do estoque do indexador i em dez/2025 '
        'que vence no ano j (RMD anexo 3.2, inclui cupons nas datas de pagamento); N_i,k = emissao liquida acumulada do indexador i '
        '(zero na variante de estoque constante); juros sobre juros_k = c x (D_k-1 + dJ_k/2), D_k = soma dos dJ e juros sobre juros ate k, '
        'c = custo medio da DPF em 12 meses em dez/2025 (RMD anexo 4.2); dcusto_k = dJ_k / estoque medio do ano k')
lin_t = []
RES = {}
for var, g_s, g_p, vdesc in [('estoque_constante', 0.0, 0.0, 'estoque nominal de dez/2025 constante; PIB de 2025 constante'),
                             ('estoque_crescendo_2023_2025', g_dpf, g_pib,
                              'estoque cresce %.2f%% a.a. (media geometrica observada da DPF 2023-2025, RMD 2.9) e o PIB %.2f%% a.a. '
                              '(media observada 2023-2025, PIB das tabelas da NFSP); emissao liquida na composicao de dez/2025, toda a taxas novas'
                              % (g_dpf * 100, g_pib * 100))]:
    for ch, p in CHOQUES.items():
        D = 0.0
        acum = defaultdict(float)
        for k in range(1, 5):
            dS, dP, dI = p['lft'] / 100, p['pre'] / 100, p['ip'] / 100   # pontos percentuais -> fracao
            fat_med = (1 + g_s) ** (k - 0.5)          # estoque medio do ano k em relacao a dez/2025
            fat_fim = (1 + g_s) ** k
            pib_k = PIB25 * (1 + g_p) ** k
            E = lambda b: sum(b[:k - 1]) + b[k - 1] / 2
            F = lambda b: sum(b[:k])
            comp_v = [
                ('LFT e taxa flutuante (imediato, Selic)', S_fl, dS * S_fl * fat_med, p['lft'], p['lft']),
                ('prefixados (so na rolagem e nas novas emissoes)', S_pre, dP * (S_pre * E(b_pre) + S_pre * (fat_med - 1)),
                 (E(b_pre) + fat_med - 1) / fat_med, (F(b_pre) + fat_fim - 1) / fat_fim),
                ('indice de precos, NTN-B (so na rolagem e nas novas emissoes)', S_ip, dI * (S_ip * E(b_ip) + S_ip * (fat_med - 1)),
                 (E(b_ip) + fat_med - 1) / fat_med, (F(b_ip) + fat_fim - 1) / fat_fim),
                ('cambio, DPFe e DPMFi cambial (sem efeito: choque domestico)', S_cd + S_fe, 0.0, 0.0, 0.0),
            ]
            dJ = sum(v[2] for v in comp_v)
            jj = c_base / 100 * (D + dJ / 2)
            D += dJ + jj
            est_med = S_tot * fat_med
            for nome, S_i, v, em, ef in comp_v:
                acum[nome] += v
                lin_t.append([ch, var, nome, 'DPF', 12 * k, r(S_i * fat_med, 1), r(em, 4), r(ef, 4), r(v, 2), r(v / pib_k * 100, 3),
                              r(v / est_med * 100, 3), p['desc'], vdesc, FORM, ''])
            acum['juros sobre juros (capitalizacao do custo adicional)'] += jj
            lin_t.append([ch, var, 'juros sobre juros (capitalizacao do custo adicional)', 'DPF', 12 * k, r(D - dJ - jj, 2), '', '', r(jj, 2),
                          r(jj / pib_k * 100, 3), r(jj / est_med * 100, 3), p['desc'], vdesc, FORM,
                          'estoque base desta linha = divida adicional acumulada no inicio do ano'])
            tot = dJ + jj
            acum['total DPF'] += tot
            ef_tot = (p['lft'] * S_fl + p['pre'] * S_pre * ((F(b_pre) + fat_fim - 1) / fat_fim) +
                      p['ip'] * S_ip * ((F(b_ip) + fat_fim - 1) / fat_fim)) / S_tot
            lin_t.append([ch, var, 'total DPF', 'DPF', 12 * k, r(est_med, 1), '', r(ef_tot, 4), r(tot, 2), r(tot / pib_k * 100, 3),
                          r(dJ / est_med * 100, 3), p['desc'], vdesc, FORM,
                          'fracao_repreciada_fim = mudanca do custo medio do estoque no fim do mes %d, em pontos (custo instantaneo); '
                          'delta_custo_medio_dpf_pp_no_ano = so o efeito de taxa (dJ / estoque medio), sem os juros sobre juros, que vem de estoque maior' % (12 * k)])
            RES[(ch, var, 12 * k)] = (tot, tot / pib_k * 100, dJ / est_med * 100, ef_tot, dJ, jj)
            cv = p['comp'] / 100 * comp_dez25 * fat_med
            acum['compromissadas'] += cv
            lin_t.append([ch, var, 'memo: compromissadas do BCB (fora da DPF; perimetro DBGG e NFSP)', 'DBGG', 12 * k, r(comp_dez25 * fat_med, 1),
                          r(p['comp'], 4), r(p['comp'], 4), r(cv, 2), r(cv / pib_k * 100, 3), '', p['desc'], vdesc,
                          'dJ_k = estoque de compromissadas x dSelic (reprecificacao imediata)',
                          'estoque de dez/2025 de J-dbgg-composicao.csv (%s); nao entra no custo medio da DPF' % JC[('dbgg_compromissadas_bcb', 2025)]['fonte_url']])
        pib_soma = sum(PIB25 * (1 + g_p) ** k for k in range(1, 5))
        for nome, v in acum.items():
            nm = nome if nome != 'compromissadas' else 'memo: compromissadas do BCB (fora da DPF; perimetro DBGG e NFSP)'
            lin_t.append([ch, var, nm, 'DBGG' if nome == 'compromissadas' else 'DPF', '48_acumulado', '', '', '', r(v, 2),
                          r(v / pib_soma * 100, 3), '', p['desc'], vdesc, FORM,
                          'soma dos quatro anos pela trajetoria (nao e o primeiro ano vezes quatro); % do PIB = soma / soma dos PIB dos quatro anos'])
            if nome == 'total DPF':
                RES[(ch, var, 'acum')] = (v, v / pib_soma * 100)
escreve('W-transmissao.csv',
        ['choque', 'variante_estoque', 'componente', 'perimetro', 'horizonte_meses', 'estoque_base_medio_rs_bi',
         'fracao_repreciada_media_no_ano', 'fracao_repreciada_fim_do_ano', 'delta_juros_rs_bi_no_ano', 'delta_juros_pct_pib',
         'delta_custo_medio_dpf_pp_no_ano', 'choque_descricao', 'premissa_estoque', 'formula', 'nota'], lin_t)

# perfil usado, para o LEIAME
with open(os.path.join(H, 'perfil_vencimentos_dez2025.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['indexador', 'estoque_rs_bi'] + FAIXAS + ['fonte'])
    for nome, S, b, fo in [('prefixado (DPMFi)', S_pre, b_pre, 'RMD anexo 3.2'), ('indice de precos (DPMFi)', S_ip, b_ip, 'RMD anexo 3.2'),
                           ('taxa flutuante (DPMFi)', S_fl, b_fl, 'RMD anexo 3.2'), ('cambio (DPMFi)', S_cd, b_cd, 'RMD anexo 3.2'),
                           ('DPFe', S_fe, b_fe, 'RMD anexo 3.1')]:
        w.writerow([nome, r(S, 2)] + [r(x, 4) for x in b] + [fo])

# checagem de caracteres proibidos
for nome in ['W-curva-mensal.csv', 'W-selic-real.csv', 'W-dpf-estrutura.csv', 'W-juros-perimetros.csv', 'W-transmissao.csv']:
    s = open(os.path.join(ROOT, nome), encoding='utf-8').read()
    assert '\u2014' not in s and '\u2013' not in s, nome

print('TD', DIAS[0], ULT_TD, 'RMD', ULT_RMD, 'IPCA', ULT_IPCA, 'over', ULT_OV, 'parcial', MES_OV_PARCIAL)
print('g_dpf %.4f g_pib %.4f c_base %.3f PIB25 %.1f comp %.1f' % (g_dpf, g_pib, c_base, PIB25, comp_dez25))
print('nfsp eds', {a: nfsp[a][0] for a in sorted(nfsp)})
print('jidx eds', {a: jidx[a][0] for a in sorted(jidx)})
for k, v in sorted(RES.items(), key=str):
    print(k, [round(x, 3) for x in v])

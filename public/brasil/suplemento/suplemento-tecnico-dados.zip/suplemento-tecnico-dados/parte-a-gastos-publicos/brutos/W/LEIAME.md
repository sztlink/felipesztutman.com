# Frente W: taxas e transmissão

Pergunta: como a Selic e a curva de juros chegam ao custo da dívida, em que perímetro e em quanto tempo.

Consulta das fontes novas: 19/10/2026. Brutos reaproveitados de N, O, J e I: 18/10/2026. Nenhum número digitado à mão. Tudo sai dos arquivos listados em `downloads.tsv`.

## Como rodar

```
cd /tmp && python3 -P gastos-publicos-brasil-dados/brutos/W/build_W.py
```

Precisa de `openpyxl` e `xlrd` (site-packages do usuário). Rodar de fora da pasta dos dados. O script é idempotente: duas rodadas seguidas dão o mesmo md5 nos cinco CSV. Ele confere que o vértice de 10 anos bate com `N-juro-real-mensal.csv` (diferença máxima abaixo de 0,001 ponto) e que nenhuma saída tem travessão.

## Saídas (na raiz `gastos-publicos/`)

| arquivo | conteúdo |
|---|---|
| `W-curva-mensal.csv` | jan/2008 a out/2026 (out parcial, até 15/10): prefixado 1, 3, 5 e 10 anos; juro real NTN-B 2, 5 e 10 anos; inflação implícita 5 e 10 anos; Selic meta média do mês; prefixado 1 ano menos Selic; inclinação 10 anos menos 1 ano |
| `W-selic-real.csv` | mensal: Selic real ex-post (12 meses seguintes), versão contemporânea do tipo BIS, juro realizado nos 12 meses passados, ex-ante com a meta e ex-ante com a Selic esperada; no fim, médias por mandato (`tipo = media_mandato`) |
| `W-dpf-estrutura.csv` | dezembro de 2008 a 2025 e mensal jan a ago/2026: estoque e composição por indexador, prazo médio (total e por indexador), vida média, vincendo em 12 meses (total, DPMFi, DPFe e por indexador), custo médio do estoque e das emissões em 12 meses, IPCA, juro real implícito, taxa de mercado comparável |
| `W-juros-perimetros.csv` | 2008 a 2025, formato longo: P1 NFSP, P2 DPF, P3 DBGG e as linhas de conciliação |
| `W-transmissao.csv` | três choques de 1 ponto, duas variantes de estoque, por componente, em 12, 24, 36 e 48 meses e acumulado de 4 anos |
| `brutos/W/perfil_vencimentos_dez2025.csv` | o perfil de vencimentos usado na transmissão |

## Fontes e caminho de acesso

| bruto | origem |
|---|---|
| `olinda/focus_ipca12m_suavizada.json` | BCB, API Olinda, `ExpectativasMercadoInflacao12Meses`, IPCA, suavizada, `baseCalculo 0` (todos os respondentes), mediana |
| `olinda/focus_selic_reuniao.json` | BCB, API Olinda, `ExpectativasMercadoSelic`, mediana por reunião do Copom, `baseCalculo 0`, pesquisas desde dez/2007 |
| `ipeadata/BM12_TJOVER12_*.json` | Ipeadata OData4, Selic over acumulada no mês (% a.m.), fonte BCB |
| `bcb/sgs_4390_2008_2026.json` | BCB SGS 4390, só para conferência |
| `../N/td/precotaxatesourodireto.csv` | Tesouro Direto, taxas diárias (frente N) |
| `../N/bcb/historicotaxasjuros.json` | BCB, metas e datas do Copom (frente N) |
| `../N/ibge/sidra_1737_v2266.json` | IBGE, IPCA número-índice (frente N) |
| `../O/rmd/anexo/Anexo RMD_Agosto_26.xlsx` | Tesouro, anexos do RMD de ago/2026 (frente O): 2.4, 2.9, 3.1, 3.2, 3.7, 3.8, 3.10, 4.2, 4.3 |
| `../J/dl-AAAA01/`, `../I/bcb-*` | BCB, Tabelas de estatísticas fiscais: NFSP acumulada no ano (Tabela 2 ou Quadro II) e juros nominais por indexador (Tabela 16 ou Quadro XVI) |
| CSV da raiz | `N-juro-real-mensal.csv` (Selic meta média do mês), `J-dbgg-fatores.csv`, `J-dlsp-fatores-ajustes.csv`, `J-dbgg-composicao.csv`, `B-uniao-por-orgao-e-gnd.csv`, só leitura |

**api.bcb.gov.br.** O brief manda não usar. Outras frentes registraram "Requisição inválida" em 18/10/2026. Em 19/10/2026, uma consulta à SGS 4390 com intervalo de datas respondeu. Mesmo assim, a série de Selic usada vem do Ipeadata, que publica a mesma série do BCB. A cópia da SGS 4390 serviu só para conferir: os 226 meses de jan/2008 a out/2026 batem um a um. As expectativas vêm da Olinda.

## Método

### 1. Curva (W-curva-mensal.csv)
- Lê o CSV do Tesouro Direto com os mesmos filtros de `build_N.py`: taxa de compra da manhã, taxa de venda quando a de compra é zero, e descarte de registros com PU de compra e de venda zerados.
- **10 anos:** é o método de N, sem mudança: interpolação linear em dias no vértice data+10 anos, na curva NTN-F para o prefixado e na curva NTN-B com cupom para o juro real, com o título mais próximo até 3 anos se não houver vizinhos dos dois lados. Bate com N em todos os meses.
- **Vértices novos:** prefixado de 1, 3 e 5 anos e NTN-B de 2 e 5 anos.
  - Interpolação linear em dias dentro de uma família por vez: LTN e depois NTN-F para o prefixado; NTN-B com cupom e depois NTN-B Principal para o juro real.
  - Se nenhuma família tiver vizinhos dos dois lados, tenta a união das famílias e depois o título mais próximo. A tolerância é de 183 dias no vértice de 1 ano, 365 dias nos de 2 e 3 anos e 548 dias no de 5 anos.
  - Títulos a menos de 60 dias do vencimento ficam de fora.
  - As colunas `nos_*` dizem que títulos entraram.
- **Inflação implícita:** Fisher, (1+pré)/(1+real)-1, no mesmo vértice. No de 5 anos, mistura zero-cupom (LTN) com cupom (NTN-B) quando é isso que existe, o que é uma aproximação.
- **Selic meta média do mês:** copiada de `N-juro-real-mensal.csv`, que faz a média dos dias com cotação no TD.

### 2. Selic real (W-selic-real.csv)
- **Ex-post:** Selic over acumulada nos 12 meses seguintes (m+1 a m+12, Ipeadata) contra o IPCA dos mesmos 12 meses, por Fisher. Só com meses completos, e por isso vai até set/2025.
- **Versão contemporânea do tipo BIS:** meta Selic do fim do mês menos o IPCA acumulado nos 12 meses encerrados no mês, por Fisher e por diferença simples. O brief chama essa convenção de "versão do BIS". A documentação do BIS não foi baixada nem conferida, então o rótulo é do brief.
- **Juro realizado nos 12 meses passados:** Selic over acumulada contra o IPCA da mesma janela.
- **Ex-ante com a meta:** Selic meta média do mês contra a média mensal da mediana diária do Focus para o IPCA 12 meses à frente (suavizada), por Fisher e por diferença simples.
- **Ex-ante com a Selic esperada:**
  - Para cada data de pesquisa do Focus, monta a trajetória diária da meta nos 365 dias seguintes. Começa na meta vigente e troca para a mediana esperada de cada reunião a partir do dia seguinte a ela. O resultado é a média dessa trajetória.
  - Depois faz a média mensal e aplica Fisher contra o Focus IPCA 12 meses.
  - Reúne também a Selic esperada vigente daqui a 12 meses (`focus_selic_esperada_em_12m`).
  - As datas das reuniões vêm do JSON do Copom (reuniões ordinárias numeradas por ano, Rk/AAAA). Para as reuniões futuras, a data é a da reunião de mesmo número de 2025 com o ano trocado. Isso afeta só pesquisas a partir de nov/2025, e a nota da linha conta quantas.
  - A cobertura foi conferida: em toda pesquisa desde 2008 há expectativa até a última reunião da janela.
- **Médias por mandato:** média simples dos meses com valor. Mai/2016 (Dilma/Temer) e out/2026 (parcial) ficam fora. A nota diz quantos meses entram em cada medida. O ex-post de Lula 3 vai só até set/2025.

### 3. Estrutura da DPF (W-dpf-estrutura.csv)
- **Composição:** anexo 2.4 (DPF em poder do público, R$ bi e participação).
- **Prazo médio:** 3.7 (total, DPMFi, DPFe) e 3.8 (por indexador da DPMFi).
- **Vida média:** 3.10. Tem metodologia nova desde jan/2014, que é quebra de série e está anotada na linha.
- **Vincendo em 12 meses:** total, DPMFi e DPFe do 3.1. Por indexador, a coluna "Até 1 ano" do 3.2, em % do estoque do próprio indexador. A DPMFi é avaliada pela curva intrínseca, com cupons nas datas de pagamento.
- **Custo médio do estoque em 12 meses:** 4.2 (DPF, DPMFi, LFT, LTN, NTN-B, NTN-F, DPFe). O da DPFe inclui o câmbio.
- **Custo das emissões em oferta pública da DPMFi em 12 meses:** 4.3. Até dez/2020 usa a metodologia antiga. De jan/2021 em diante usa a coluna CME, que é quebra de série.
- **Juro real implícito:** Fisher contra o IPCA 12 meses no mesmo mês.
- **Taxa de mercado comparável:**
  - prefixado de 10 anos e NTN-B de 10 anos, média dos 12 meses que terminam no mês, para casar com a janela de 12 meses do custo, e também o valor do mês;
  - Selic meta média de 12 meses;
  - custo do estoque menos o prefixado de 10 anos.

### 4. Três perímetros (W-juros-perimetros.csv)
- **P1, setor público consolidado (BCB, NFSP):**
  - juros nominais acumulados jan-dez, em R$ e % do PIB publicado;
  - aberturas: Governo Central, Governo Federal com INSS, BCB, governos regionais, estados, municípios e estatais (sem Petrobras e Eletrobras);
  - regra de safra: para cada ano vale a edição de janeiro mais nova que traz o ano completo (2008 sai da edição 201301; 2021 a 2025 da 202601);
  - da tabela de juros por indexador: a coluna Selic e a coluna Outros, que a própria tabela define como "dívidas securitizadas e resultado caixa das operações de swap cambial".
- **P2, DPF (Tesouro, RMD 2.9):**
  - juros apropriados por competência, DPMFi e DPFe;
  - nos juros da DPFe entra a variação cambial;
  - memo de caixa: pagamentos correntes da DPMFi (amortização mais juros), que não são despesa de juros.
- **P3, DBGG (BCB):**
  - juros nominais dos fatores condicionantes e o detalhamento por instrumento (interna exceto compromissadas, compromissadas, externa), lidos de `J-dbgg-fatores.csv`.
- **% do PIB:** em P2, P3 e na conciliação, o denominador é o PIB implícito na linha P1 do mesmo ano (R$ / %). Assim os três perímetros dividem pelo mesmo número. O % que J publica para a DBGG fica na nota.
- **Conciliação:**
  - **c1 = P3 - P1**, ponte P3 = P1 + c1b + c1c + c1d + c1e:
    - c1b: juros recebidos sobre créditos do governo federal (BNDES e outros);
    - c1c: rendimento da dívida externa líquida do BCB (reservas);
    - c1d: resultado de swaps e securitizadas, com sinal trocado;
    - c1e: resíduo não decomposto. Contém, sem valor separado nas tabelas lidas, os depósitos remunerados no BCB (compulsórios e voluntários), que estão na NFSP e fora da DBGG; os juros sobre aplicações de estados, municípios e estatais, FAT e fundos; os juros das estatais; e diferenças de safra;
    - a remuneração da conta única aparece como memo (c1m) e não entra na ponte. Ela é ativo do Tesouro e passivo do BCB, e na consolidação se anula com a renda do BCB sobre os títulos do Tesouro em carteira.
  - **c2 = P3 - P2**, ponte P3 = P2 + c2a - c2b + c2c:
    - c2a: juros das compromissadas do BCB, que estão na DBGG e fora da DPF;
    - c2b: variação cambial da dívida externa na DBGG, que na DPF está dentro dos juros da DPFe;
    - c2c: resíduo. Inclui a dívida bancária e externa de estados e municípios, as securitizadas e diferenças de critério (DPF em poder do público contra mobiliária em mercado).
  - **c3 (só 2025):** juros e encargos pagos no orçamento (GND 2, caixa, frente B), contra a competência. A diferença não foi decomposta: parte dos juros de LTN e LFT pagos no resgate é classificada como amortização.

### 5. Transmissão (W-transmissao.csv)

Ponto de partida: estrutura de dez/2025 (RMD), estoque da DPF de R$ 8.635 bi.

| indexador | estoque R$ bi | até 1 ano | 1 a 2 | 2 a 3 | 3 a 4 | 4 a 5 | acima de 5 | fonte |
|---|---|---|---|---|---|---|---|---|
| prefixado (DPMFi) | 1.898,95 | 32,3% | 22,4% | 6,1% | 20,2% | 4,6% | 14,3% | RMD 3.2 |
| índice de preços (DPMFi) | 2.239,48 | 16,1% | 9,6% | 13,0% | 6,2% | 10,6% | 44,6% | RMD 3.2 |
| taxa flutuante (DPMFi) | 4.166,72 | reprecifica todo mês | | | | | | RMD 3.2 |
| câmbio (DPMFi + DPFe) | 329,95 | sem efeito | | | | | | RMD 3.2 e 3.1 |

Fórmula, por ano k = 1 a 4:

```
dJ_k = S_LFT,k x dSelic
     + dr_pre x [S_pre,0 x E_pre,k + N_pre,k]
     + dr_ip  x [S_ip,0  x E_ip,k  + N_ip,k]
E_i,k = soma(b_i,j para j < k) + b_i,k / 2
juros sobre juros_k = c x (D_k-1 + dJ_k / 2),  D_k = soma de dJ e juros sobre juros até k
dcusto_k = dJ_k / estoque médio do ano k
```

- **b_i,j:** parcela do estoque do indexador i em dez/2025 que vence no ano j (RMD 3.2, com cupons). É a premissa de rolagem e sai do perfil observado, não de número escolhido.
- **Vencimentos dentro do ano:** supostos uniformes (o fator 1/2).
- **c:** custo médio da DPF em 12 meses em dez/2025, 11,85% (RMD 4.2).
- **N_i,k:** emissão líquida acumulada do indexador. É zero na variante de estoque constante.
- **Choque permanente:** o título reprecificado que vence de novo dentro dos 4 anos é emitido de novo à mesma taxa nova. Por isso basta a parcela do estoque original que já venceu.

Choques (todos de +1 ponto, permanentes, desde jan/2026):

| choque | LFT (imediato) | prefixados e NTN-B (rolagem) | compromissadas (memo, fora da DPF) |
|---|---|---|---|
| `selic_1pp` | +1 | 0 | +1 |
| `curva_paralela_1pp` | +1 | +1 | +1 |
| `premio_risco_1pp` | 0 | +1 | 0 |

Critérios declarados:
1. O efeito mecânico da Selic sobre o pós-fixado e o efeito sobre as taxas das novas emissões de prefixados e NTN-B ficam em linhas separadas:
   - o primeiro é imediato, sobre o estoque de LFT na DPF; as compromissadas do BCB vêm em linha memo, porque estão no perímetro DBGG e NFSP e fora do custo médio da DPF;
   - o segundo só aparece na rolagem e só nos choques em que a curva se move.
2. **A mudança da curva é premissa do choque, não consequência da Selic.** No choque `selic_1pp` a curva fica parada por hipótese. No `curva_paralela_1pp` ela sobe por hipótese. Nada aqui estima quanto a curva responde à Selic ou a uma reforma. Isso é tarefa da literatura (etapa 2 do brief).
3. O acumulado de 4 anos sai da trajetória ano a ano: perfil de vencimentos, rolagem e capitalização do custo adicional (juros sobre juros). Não é o primeiro ano vezes quatro.
4. Variantes de estoque:
   - `estoque_constante`: estoque nominal e PIB de 2025 parados;
   - `estoque_crescendo_2023_2025`: o estoque cresce 13,21% a.a. e o PIB 8,10% a.a., as médias geométricas observadas de 2022 a 2025 (RMD 2.9 e PIB das tabelas da NFSP); a emissão líquida vai na composição de dez/2025 e toda a taxas novas.
5. O modelo é linear no tamanho do choque. Choques de 0,5 a 3 pontos são múltiplos destas linhas, salvo o termo de juros sobre juros, que também é linear em primeira ordem.

## Números principais de 2025

- **Estrutura (dez/2025):**
  - prazo médio da DPF de 4,00 anos (prefixado 2,23; índice de preços 7,11; flutuante 2,91);
  - vida média de 5,83 anos;
  - vincendo em 12 meses: 17,46% da DPF (R$ 1.507,5 bi), 17,75% da DPMFi; prefixado 32,3%, índice de preços 16,1%, flutuante 12,0% do próprio estoque.
- **Custos em 12 meses até dez/2025:**
  - estoque da DPF 11,85% (DPMFi 12,65%; LFT 14,51%);
  - emissões da DPMFi 13,81% (CME);
  - mercado: prefixado de 10 anos 14,14% e NTN-B de 10 anos 7,47% real (médias de 12 meses);
  - juro real implícito: estoque 7,28%, emissões 9,15% (IPCA de 4,26%).
- **Perímetros de juros em 2025 (% do PIB):**
  - NFSP consolidada R$ 1.007,6 bi, 7,91% (Governo Central 7,00; BCB 0,19; regionais 0,87; estatais 0,04);
  - DPF R$ 880,0 bi, 6,91%;
  - DBGG R$ 1.127,8 bi, 8,86%;
  - DBGG menos NFSP 0,94 ponto: créditos do GF 0,21, reservas 0,36, swaps e securitizadas 0,83, resíduo -0,45;
  - DBGG menos DPF 1,95 ponto: compromissadas 1,34, câmbio da DPFe 0,44, resíduo 0,17.

## Limitações e o que não foi achado

- **Prêmio de risco:** a transmissão do choque `premio_risco_1pp` põe +1 ponto em toda nova emissão de prefixado e NTN-B, inclusive LTN curtas. Na prática a ponta curta da curva acompanha a Selic, então o choque é um teto para um aumento só do prêmio longo. A Selic fica fixa e o spread da LFT parado.
- **NTN-B:** o choque paralelo vira +1 ponto no juro real das novas NTN-B, com a inflação implícita parada. A inflação corrente que corrige o estoque de NTN-B não muda em nenhum choque.
- **Câmbio:** nenhum choque mexe no câmbio, nem na DPFe, nem no custo de nova emissão externa.
- **Perfil de vencimentos:** foi tomado em faixas anuais (RMD 3.2), com vencimentos uniformes dentro do ano. O cronograma mensal (3.4) só existe para a posição corrente (ago/2026), não para dez/2025.
- **Compromissadas:** o estoque de dez/2025 vem de `J-dbgg-composicao.csv` (R$ 989,7 bi). A premissa é de reprecificação imediata. Os depósitos voluntários remunerados no BCB, também ligados à Selic, ficaram fora da linha memo, porque não há série deles nos CSV lidos.
- **Resíduos da conciliação:** c1e e c2c são resíduos de verdade. A remuneração dos compulsórios e depósitos no BCB e os juros de estados, municípios e estatais sobre ativos não têm linha própria nas tabelas lidas.
- **Swaps:** a coluna Outros do BCB mistura swaps (caixa) com securitizadas. O resultado de swap separado só existe em `J-dlsp-ativos.csv` de 2008 a 2020 e não foi usado na ponte.
- **Caixa contra competência:** só há o GND 2 do orçamento de 2025 (frente B). Não há série histórica de juros pagos, e a diferença não foi decomposta.
- **Curva:**
  - o vértice de 1 ano depende de LTN próximas do vencimento;
  - NTN-B de 2 anos fica vazia de jul/2020 a jul/2021, quando não havia NTN-B entre 60 dias e 3 anos no TD;
  - o prefixado de 10 anos fica vazio em jan e fev/2010 (filtro de N);
  - o prefixado de 1 ano fica vazio em dez/2022;
  - as taxas são as do Tesouro Direto, que não são as de leilão nem as do secundário (ANBIMA).
- **Taxa de mercado comparável:** é a média de 12 meses da taxa do TD. O custo das emissões é ponderado pelo volume emitido, e as duas coisas não são iguais por construção.
- **Selic esperada:** usa a mediana por reunião (base 0). Não foi usado o Top5. As datas das reuniões futuras de 2026 a 2028 são aproximadas.
- **Selic real do tipo BIS:** a convenção vem do brief e não foi conferida na documentação do BIS.
- **PIB:** é o de cada edição da NFSP. Edições antigas trazem PIB antes de revisões do IBGE. O % do PIB dos três perímetros usa o mesmo denominador por ano, mas não é o PIB mais recente.

# Frente FB: expectativas contra resultados, pelo protocolo do BRIEF-v13.md (fixado em 20/10/2026, antes dos dados).
# Gera, na raiz gastos-publicos/:
#   FB-erros.csv    um por ano de origem x variavel x horizonte (incluidos e excluidos, com o motivo)
#   FB-resumo.csv   distribuicao dos erros por variavel e horizonte e posicao de cada ano de eleicao
#   FB-curva.csv    parte B, prefixado de 1 ano do TD em setembro contra a Selic dos 12 meses seguintes
# e, dentro de brutos/FB/: excluidos.tsv, conferencia_primario.tsv, entradas.tsv (sha256 de tudo o que foi lido)
# Entradas:
#   fontes/focus_anuais_<t>.json      Focus anual (Olinda), baseCalculo 0, 15/09 a 07/10 de cada t
#   fontes/sidra_1737_v2266.json      IPCA numero-indice (IBGE)
#   fontes/sidra_5932_pib.json        PIB, taxa acumulada ao longo do ano (IBGE)
#   fontes/sgs432_<a>12.json          meta da Selic, dezembro (BCB)
#   fontes/sgs1_<a>12.json            PTAX venda, dezembro (BCB)
#   fontes/sgs5793.json               primario 12 meses % do PIB, NFSP sem desvalorizacao cambial (BCB)
#   ../I/bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx   Tabela 2, so para conferir a SGS 5793 em 2024 e 2025
#   ../../W-curva-mensal.csv, ../../W-selic-real.csv        parte B (frente W, so leitura)
# So biblioteca padrao. Rodar de fora da pasta: cd /tmp && python3 -I /caminho/brutos/FB/build_FB.py
import csv, datetime as dt, hashlib, json, os, re, sys, zipfile
import xml.etree.ElementTree as ET

H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(H, '..', '..'))
F = os.path.join(H, 'fontes')
REL = lambda p: os.path.relpath(p, ROOT)

ANOS = list(range(2000, 2025))
HORIZ = [('h1', 1), ('h2', 2)]
ULTIMO_REALIZADO = 2025
ELEICOES = {2002, 2006, 2010, 2014, 2018, 2022}
VARS = [  # nome no Focus, nome curto, unidade
    ('IPCA', 'ipca', 'pp'),
    ('PIB Total', 'pib', 'pp'),
    ('Selic', 'selic', 'pp'),
    ('Câmbio', 'cambio', 'R$ por US$'),
    ('Resultado primário', 'primario', 'pp do PIB'),
]
ENTRADAS = {}


def abre(caminho):
    b = open(caminho, 'rb').read()
    ENTRADAS[REL(caminho)] = hashlib.sha256(b).hexdigest()
    return b


def jload(caminho):
    return json.loads(abre(caminho).decode('utf-8'))


def r(x, n=4):
    return '' if x is None else round(x, n)


def presidente(d):
    """nome so data o valor, nao atribui causa"""
    if d <= dt.date(2002, 12, 31):
        return 'FHC'
    if d <= dt.date(2006, 12, 31):
        return 'Lula 1'
    if d <= dt.date(2010, 12, 31):
        return 'Lula 2'
    if d <= dt.date(2016, 5, 12):
        return 'Dilma'
    if d <= dt.date(2018, 12, 31):
        return 'Temer'
    if d <= dt.date(2022, 12, 31):
        return 'Bolsonaro'
    return 'Lula 3'


def escreve(caminho, linhas, campos, sep=','):
    with open(caminho, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=campos, delimiter=sep, lineterminator='\n')
        w.writeheader()
        for l in linhas:
            w.writerow({k: l.get(k, '') for k in campos})


def percentil(xs, p):
    """interpolacao linear entre ordens (tipo 7 de Hyndman e Fan, o padrao do R e do numpy)"""
    s = sorted(xs)
    if not s:
        return None
    k = (len(s) - 1) * p / 100.0
    i = int(k)
    if i + 1 >= len(s):
        return s[-1]
    return s[i] + (s[i + 1] - s[i]) * (k - i)


# ---------------------------------------------------------------- datas de origem
def sabado_antes_1o_domingo_out(t):
    d = dt.date(t, 10, 1)
    while d.weekday() != 6:
        d += dt.timedelta(days=1)
    return d - dt.timedelta(days=1)


# ---------------------------------------------------------------- Focus
def focus(t):
    arq = os.path.join(F, 'focus_anuais_%d.json' % t)
    d = jload(arq)['value']
    lim = sabado_antes_1o_domingo_out(t)
    datas = sorted({x['Data'] for x in d if x['baseCalculo'] == 0 and dt.date.fromisoformat(x['Data']) <= lim})
    if not datas:
        return None, {}, arq, lim
    orig = datas[-1]
    val = {}
    for x in d:
        if x['baseCalculo'] != 0 or x['Data'] != orig or x['IndicadorDetalhe'] not in (None, ''):
            continue
        k = (x['Indicador'], int(x['DataReferencia']))
        if k in val and val[k][0] != x['Mediana']:
            raise SystemExit('Focus com duas medianas para %s em %s' % (k, orig))
        val[k] = (x['Mediana'], x['numeroRespondentes'])
    return orig, val, arq, lim


# ---------------------------------------------------------------- realizados
def ipca():
    arq = os.path.join(F, 'sidra_1737_v2266.json')
    d = jload(arq)[1:]
    idx = {x['D3C']: float(x['V']) for x in d if x['V'] not in ('', '-', '...', 'X')}
    out = {}
    for a in range(1995, 2026):
        if '%d12' % a in idx and '%d12' % (a - 1) in idx:
            out[a] = (100.0 * (idx['%d12' % a] / idx['%d12' % (a - 1)] - 1.0),
                      'IPCA dez/%d sobre dez/%d (numero-indice %s / %s)' % (a, a - 1, idx['%d12' % a], idx['%d12' % (a - 1)]))
    return out, arq, 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'


def pib():
    arq = os.path.join(F, 'sidra_5932_pib.json')
    d = jload(arq)[1:]
    alvo = 'Taxa acumulada ao longo do ano (em relação ao mesmo período do ano anterior)'
    out = {}
    for x in d:
        if x['D2N'] == alvo and x['D3C'].endswith('04') and x['D4C'] == '90707' and x['V'] not in ('', '-', '...', 'X'):
            a = int(x['D3C'][:4])
            out[a] = (float(x['V']), 'SIDRA 5932 v%s, PIB a precos de mercado, %s, acumulada no ano ate o 4o trimestre' % (x['D2C'], x['D3N']))
    return out, arq, 'https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/all/p/all/c11255/90707?formato=json'


def sgs_dez(serie, a):
    arq = os.path.join(F, 'sgs%d_%d12.json' % (serie, a))
    return jload(arq), arq


def selic():
    out, arqs = {}, {}
    for a in range(2000, 2026):
        d, arq = sgs_dez(432, a)
        arqs[a] = arq
        v = [x for x in d if x['data'] == '31/12/%d' % a]
        if v:
            out[a] = (float(v[0]['valor']), 'SGS 432 em 31/12/%d' % a)
    return out, arqs


def cambio():
    out, arqs = {}, {}
    for a in range(2000, 2026):
        d, arq = sgs_dez(1, a)
        arqs[a] = arq
        if d:
            ult = max(d, key=lambda x: dt.datetime.strptime(x['data'], '%d/%m/%Y'))
            out[a] = (float(ult['valor']), 'SGS 1, PTAX venda de %s (ultimo dia util do ano no arquivo)' % ult['data'])
    return out, arqs


def primario():
    arq = os.path.join(F, 'sgs5793.json')
    d = jload(arq)
    out = {}
    for x in d:
        if x['data'].startswith('01/12/'):
            a = int(x['data'][6:])
            out[a] = (-float(x['valor']), 'SGS 5793 dez/%d = %s (deficit positivo), sinal trocado' % (a, x['valor']))
    primeiro = min(d, key=lambda x: (int(x['data'][6:]), int(x['data'][3:5])))['data']
    return out, arq, primeiro


# ---------------------------------------------------------------- conferencia do primario (Tabela 2, set/2026)
def le_xlsx_planilha(caminho, nome):
    z = zipfile.ZipFile(caminho)
    ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
          'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    ss = []
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', ns):
            ss.append(''.join(t.text or '' for t in si.iter('{%s}t' % ns['m'])))
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    rid = [s.get('{%s}id' % ns['r']) for s in wb.find('m:sheets', ns) if s.get('name') == nome][0]
    rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    alvo = [x.get('Target') for x in rels if x.get('Id') == rid][0]
    alvo = alvo.lstrip('/')
    alvo = alvo if alvo.startswith('xl/') else 'xl/' + alvo
    folha = ET.fromstring(z.read(alvo))
    cel = {}
    for c in folha.iter('{%s}c' % ns['m']):
        ref = c.get('r')
        m = re.match(r'([A-Z]+)(\d+)', ref)
        col = 0
        for ch in m.group(1):
            col = col * 26 + ord(ch) - 64
        v = c.find('m:v', ns)
        if v is None:
            is_ = c.find('m:is', ns)
            if is_ is None:
                continue
            val = ''.join(t.text or '' for t in is_.iter('{%s}t' % ns['m']))
        elif c.get('t') == 's':
            val = ss[int(v.text)]
        elif c.get('t') in ('str', 'inlineStr'):
            val = v.text
        else:
            val = float(v.text)
        cel[(int(m.group(2)), col)] = val
    return cel


def confere_primario(prim):
    arq = os.path.normpath(os.path.join(H, '..', 'I', 'bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx'))
    abre(arq)
    cel = le_xlsx_planilha(arq, 'Tabela 2')
    linha_prim = min(rw for (rw, c), v in cel.items() if c == 1 and isinstance(v, str) and v.strip() == 'Primário')
    saida = []
    for a in (2024, 2025):
        cols = [(rw, c) for (rw, c), v in cel.items() if v == float(a) or v == a]
        if not cols:
            raise SystemExit('Tabela 2 sem coluna do ano %d' % a)
        rw_ano, c_ano = min(cols)
        c_pct = c_ano + 3
        rot_ano = cel.get((rw_ano + 2, c_ano + 2), '')
        rot_pct = cel.get((rw_ano + 4, c_pct), '')
        if str(rot_ano).strip() != 'Ano' or not str(rot_pct).strip().startswith('%'):
            raise SystemExit('Tabela 2 com cabecalho inesperado em %d: %r %r' % (a, rot_ano, rot_pct))
        t2 = cel[(linha_prim, c_pct)]
        sgs = -prim[a][0]          # de volta ao sinal da fonte (deficit positivo)
        ok = abs(round(t2, 2) - sgs) < 1e-9
        saida.append({'ano': a, 'tabela2_primario_ano_pct_pib_deficit_positivo': r(t2, 4), 'sgs5793_dez': sgs,
                      'tabela2_arredondada_2_casas': round(t2, 2), 'confere': 'sim' if ok else 'nao',
                      'arquivo_tabela2': REL(arq), 'celula': 'linha %d, coluna %d' % (linha_prim, c_pct)})
        if not ok:
            raise SystemExit('SGS 5793 nao confere com a Tabela 2 em %d: %s contra %s' % (a, sgs, t2))
    escreve(os.path.join(H, 'conferencia_primario.tsv'), saida, list(saida[0].keys()), sep='\t')
    return saida


# ---------------------------------------------------------------- parte A
def parte_a():
    ip, arq_ip, _ = ipca()
    pb, arq_pb, _ = pib()
    se, arqs_se = selic()
    ca, arqs_ca = cambio()
    pr, arq_pr, prim_inicio = primario()
    conf = confere_primario(pr)
    real = {'ipca': (ip, lambda a: arq_ip), 'pib': (pb, lambda a: arq_pb), 'selic': (se, lambda a: arqs_se.get(a, '')),
            'cambio': (ca, lambda a: arqs_ca.get(a, '')), 'primario': (pr, lambda a: arq_pr)}
    linhas, excl = [], []
    for t in ANOS:
        orig, val, arq_f, lim = focus(t)
        for nome_f, nome, uni in VARS:
            for hz, h in HORIZ:
                alvo = t + h
                l = {'ano_origem': t, 'data_origem': orig or '', 'limite_data_origem': lim.isoformat(),
                     'presidente_na_origem': presidente(dt.date.fromisoformat(orig)) if orig else '',
                     'eleicao': 'sim' if t in ELEICOES else 'nao', 'variavel': nome, 'unidade': uni, 'horizonte': hz,
                     'ano_alvo': alvo, 'arquivo_esperado': REL(arq_f)}
                serie, arq_r = real[nome]
                l['arquivo_realizado'] = REL(arq_r(alvo)) if arq_r(alvo) else ''
                motivo = ''
                if orig is None:
                    motivo = 'sem data do Focus ate %s' % lim.isoformat()
                elif (nome_f, alvo) not in val:
                    motivo = 'Focus de %s sem mediana de %s para %d' % (orig, nome_f, alvo)
                if alvo > ULTIMO_REALIZADO:
                    motivo = 'ano alvo %d ainda nao realizado (ultimo ano realizado do protocolo, %d)' % (alvo, ULTIMO_REALIZADO)
                elif alvo not in serie and not motivo:
                    if nome == 'primario':
                        motivo = 'SGS 5793 sem dezembro de %d (a serie comeca em %s)' % (alvo, prim_inicio)
                    else:
                        motivo = 'realizado de %d ausente na fonte' % alvo
                if (nome_f, alvo) in val:
                    l['esperado'] = val[(nome_f, alvo)][0]
                    l['respondentes'] = val[(nome_f, alvo)][1] if val[(nome_f, alvo)][1] is not None else ''
                if alvo in serie and alvo <= ULTIMO_REALIZADO:
                    l['realizado'] = r(serie[alvo][0])
                    l['realizado_como'] = serie[alvo][1]
                if motivo:
                    l['situacao'] = 'excluido'
                    l['motivo_exclusao'] = motivo
                    excl.append({'ano_origem': t, 'variavel': nome, 'horizonte': hz, 'ano_alvo': alvo, 'motivo': motivo})
                else:
                    e = serie[alvo][0] - l['esperado']
                    l['erro'] = r(e)
                    l['erro_abs'] = r(abs(e))
                    l['situacao'] = 'incluido'
                linhas.append(l)
    campos = ['ano_origem', 'data_origem', 'limite_data_origem', 'presidente_na_origem', 'eleicao', 'variavel', 'unidade',
              'horizonte', 'ano_alvo', 'esperado', 'respondentes', 'realizado', 'erro', 'erro_abs', 'situacao',
              'motivo_exclusao', 'realizado_como', 'arquivo_esperado', 'arquivo_realizado']
    escreve(os.path.join(ROOT, 'FB-erros.csv'), linhas, campos)
    escreve(os.path.join(H, 'excluidos.tsv'), excl, ['ano_origem', 'variavel', 'horizonte', 'ano_alvo', 'motivo'], sep='\t')
    return linhas, excl, conf


# ---------------------------------------------------------------- parte B
def parte_b():
    wc = os.path.join(ROOT, 'W-curva-mensal.csv')
    ws = os.path.join(ROOT, 'W-selic-real.csv')
    cur = {x['mes']: x for x in csv.DictReader(abre(wc).decode('utf-8').splitlines())}
    sel = {x['mes_ou_mandato']: x for x in csv.DictReader(abre(ws).decode('utf-8').splitlines()) if x['tipo'] == 'mensal'}
    linhas = []
    for t in range(2008, ULTIMO_REALIZADO + 1):
        k = '%d-09' % t
        l = {'ano_origem': t, 'mes_esperado': k, 'eleicao': 'sim' if t in ELEICOES else 'nao',
             'presidente_na_origem': presidente(dt.date(t, 9, 1)),
             'janela_realizado': '%d-10 a %d-09' % (t, t + 1), 'arquivo_esperado': REL(wc), 'arquivo_realizado': REL(wc)}
        pre = cur.get(k, {}).get('prefixado_1a', '')
        meses = ['%d-%02d' % (t, m) for m in (10, 11, 12)] + ['%d-%02d' % (t + 1, m) for m in range(1, 10)]
        sm = [cur.get(m, {}).get('selic_meta_media_mes', '') for m in meses]
        motivo = ''
        if pre == '':
            motivo = 'sem prefixado de 1 ano em %s' % k
        elif any(v == '' for v in sm):
            motivo = 'faltam meses de Selic meta entre %s e %s' % (meses[0], meses[-1])
        if pre != '':
            l['prefixado_1a_media_set'] = float(pre)
            l['dias_td_set'] = cur[k]['dias_td']
            l['nos_prefixado_1a_set'] = cur[k]['nos_prefixado_1a']
        if not any(v == '' for v in sm):
            sm_media = sum(float(v) for v in sm) / 12.0
            l['selic_meta_media_12m_seguintes'] = r(sm_media)
        ov = sel.get(k, {}).get('selic_over_acum_12m_seguintes', '')
        if ov != '':
            l['selic_over_acum_12m_seguintes'] = float(ov)
            l['arquivo_over'] = REL(ws)
        if motivo:
            l['situacao'] = 'excluido'
            l['motivo_exclusao'] = motivo
        else:
            e = sm_media - float(pre)
            l['erro_meta_media'] = r(e)
            l['erro_abs_meta_media'] = r(abs(e))
            if ov != '':
                l['erro_over_acum'] = r(float(ov) - float(pre))
            l['situacao'] = 'incluido'
        l['nota'] = ('erro = Selic realizada menos prefixado de 1 ano; TD fica alguns pb abaixo da curva de mercado (declarado, '
                     'nao corrigido); over acumulada e complemento, a leitura do protocolo e a media da meta')
        linhas.append(l)
    campos = ['ano_origem', 'mes_esperado', 'presidente_na_origem', 'eleicao', 'prefixado_1a_media_set', 'dias_td_set',
              'nos_prefixado_1a_set', 'janela_realizado', 'selic_meta_media_12m_seguintes', 'erro_meta_media',
              'erro_abs_meta_media', 'selic_over_acum_12m_seguintes', 'erro_over_acum', 'situacao', 'motivo_exclusao',
              'arquivo_esperado', 'arquivo_realizado', 'arquivo_over', 'nota']
    escreve(os.path.join(ROOT, 'FB-curva.csv'), linhas, campos)
    return linhas


# ---------------------------------------------------------------- resumo
def resumo(la, lb):
    res = []
    grupos = [(nome, uni, hz, [(l['ano_origem'], l['erro']) for l in la
                               if l['variavel'] == nome and l['horizonte'] == hz and l['situacao'] == 'incluido'],
               sum(1 for l in la if l['variavel'] == nome and l['horizonte'] == hz and l['situacao'] == 'excluido'))
              for _, nome, uni in VARS for hz, _ in HORIZ]
    grupos.append(('curva_pre1a_vs_selic', 'pp', '12m', [(l['ano_origem'], l['erro_meta_media']) for l in lb
                                                          if l['situacao'] == 'incluido'],
                   sum(1 for l in lb if l['situacao'] == 'excluido')))
    for nome, uni, hz, pares, n_ex in grupos:
        erros = [e for _, e in pares]
        abss = [abs(e) for e in erros]
        anos = [a for a, _ in pares]
        res.append({'tipo': 'distribuicao', 'variavel': nome, 'unidade': uni, 'horizonte': hz, 'n': len(erros),
                    'n_excluidos': n_ex, 'anos_origem': '%d a %d' % (min(anos), max(anos)) if anos else '',
                    'mediana_erro': r(percentil(erros, 50)), 'mediana_erro_abs': r(percentil(abss, 50)),
                    'p10_erro': r(percentil(erros, 10)), 'p90_erro': r(percentil(erros, 90)),
                    'nota': 'erro = realizado menos esperado; percentis por interpolacao linear (tipo 7)'})
        for a in sorted(ELEICOES):
            l = {'tipo': 'eleicao', 'variavel': nome, 'unidade': uni, 'horizonte': hz, 'ano_origem': a, 'n': len(erros)}
            if a not in anos:
                l['nota'] = 'caso excluido (ver FB-erros.csv ou FB-curva.csv)' if (nome != 'curva_pre1a_vs_selic' or a >= 2008) \
                    else 'fora do periodo da parte B (desde 2008)'
            else:
                e = dict(pares)[a]
                maiores = sum(1 for x in abss if x > abs(e) + 1e-12)
                iguais = sum(1 for x in abss if abs(x - abs(e)) <= 1e-12) - 1
                l.update({'erro': r(e), 'erro_abs': r(abs(e)), 'posicao_erro_abs': maiores + 1,
                          'empatados': iguais,
                          'fracao_anos_com_erro_abs_menor': r(sum(1 for x in abss if x < abs(e) - 1e-12) / len(abss), 3),
                          'nota': 'posicao 1 = maior erro absoluto entre os n anos; com seis casos nao ha teste de significancia'})
            res.append(l)
    campos = ['tipo', 'variavel', 'unidade', 'horizonte', 'n', 'n_excluidos', 'anos_origem', 'mediana_erro',
              'mediana_erro_abs', 'p10_erro', 'p90_erro', 'ano_origem', 'erro', 'erro_abs', 'posicao_erro_abs', 'empatados',
              'fracao_anos_com_erro_abs_menor', 'nota']
    escreve(os.path.join(ROOT, 'FB-resumo.csv'), res, campos)
    return res


def main():
    la, excl, conf = parte_a()
    lb = parte_b()
    res = resumo(la, lb)
    escreve(os.path.join(H, 'entradas.tsv'), [{'arquivo': k, 'sha256': v} for k, v in sorted(ENTRADAS.items())],
            ['arquivo', 'sha256'], sep='\t')
    print('parte A: %d linhas, %d incluidas, %d excluidas' % (len(la), sum(l['situacao'] == 'incluido' for l in la), len(excl)))
    print('parte B: %d anos, %d incluidos' % (len(lb), sum(l['situacao'] == 'incluido' for l in lb)))
    print('conferencia primario:', [(c['ano'], c['sgs5793_dez'], c['tabela2_primario_ano_pct_pib_deficit_positivo'], c['confere']) for c in conf])
    for x in res:
        if x['tipo'] == 'distribuicao':
            print('%-22s %-3s n=%2d med=%s med_abs=%s p10=%s p90=%s' % (x['variavel'], x['horizonte'], x['n'], x['mediana_erro'],
                                                                      x['mediana_erro_abs'], x['p10_erro'], x['p90_erro']))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
# Frente FB, expectativas contra resultados (protocolo em BRIEF-v13.md). Baixa o Focus anual em torno de outubro de cada ano de
# 2000 a 2024 e as series realizadas do BCB, uma requisicao por vez com pausa, e registra cada arquivo em downloads.tsv.
# Rodar de fora da pasta: cd /tmp && python3 -I <pacote>/brutos/FB/baixa_FB.py
import datetime, hashlib, json, os, time, urllib.parse, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__)); F = os.path.join(AQUI, 'fontes'); os.makedirs(F, exist_ok=True)
OL = 'https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais'
SGS = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.{s}/dados?formato=json&dataInicial={a}&dataFinal={b}'
IND = ['IPCA', 'PIB Total', 'Selic', 'Câmbio', 'Resultado primário']
itens = []
for t in range(2000, 2025):
  filtro = "Data ge '%d-09-15' and Data le '%d-10-07' and baseCalculo eq 0 and (%s)" % (t, t, ' or '.join(f"Indicador eq '{i}'" for i in IND))
  q = {'$filter': filtro, '$format': 'json', '$select': 'Indicador,IndicadorDetalhe,Data,DataReferencia,Mediana,numeroRespondentes,baseCalculo'}
  itens.append((f'focus_anuais_{t}.json', f'BCB Focus, expectativas anuais de {", ".join(IND)}, datas de 15/09 a 07/10/{t}', OL + '?' + urllib.parse.urlencode(q, quote_via=urllib.parse.quote)))
for a in range(2000, 2026):
  itens.append((f'sgs432_{a}12.json', f'BCB SGS 432, meta da Selic, 20 a 31/12/{a}', SGS.format(s=432, a=f'20/12/{a}', b=f'31/12/{a}')))
  itens.append((f'sgs1_{a}12.json', f'BCB SGS 1, dolar PTAX venda, 20 a 31/12/{a}', SGS.format(s=1, a=f'20/12/{a}', b=f'31/12/{a}')))
itens.append(('sgs5793.json', 'BCB SGS 5793, NFSP sem desvalorizacao cambial, primario do setor publico consolidado, % do PIB, 12 meses', SGS.format(s=5793, a='01/12/2000', b='31/12/2025')))
# acrescimo de 24/10/2026 (realizados de IPCA e PIB que o protocolo pede e que faltavam), mesma regra de uma requisicao por vez
itens.append(('sidra_1737_v2266.json', 'IBGE SIDRA 1737, IPCA, numero-indice (dez/1993 = 100), mensal, Brasil', 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'))
itens.append(('sidra_5932_pib.json', 'IBGE SIDRA 5932, PIB a precos de mercado (c11255 90707), taxas de variacao do indice de volume trimestral, todas as variaveis, Brasil', 'https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/all/p/all/c11255/90707?formato=json'))
# lidos de outra frente sem copiar (nao baixa, so registra caminho, url e hash)
OUTRAS = [('../I/bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx', 'BCB, estatisticas fiscais de set/2026 (dados ate ago/2026), Tabela 2, primario acumulado no ano em % do PIB; lido da frente I sem copiar, so para conferir a identidade da SGS 5793 em 2024 e 2025', 'https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/202609_Tabelas_de_estatisticas_fiscais.xlsx')]
linhas = []
for arq, desc, url in itens:
  dst = os.path.join(F, arq)
  if not os.path.exists(dst):
    for tent in range(3):
      try:
        b = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=120).read(); json.loads(b); break
      except Exception as e:
        print('tentativa', tent + 1, arq, e); time.sleep(10)
    else: raise SystemExit('falhou ' + arq)
    open(dst, 'wb').write(b); time.sleep(3)
  h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, 'fontes/' + arq, url, h]))
for arq, desc, url in OUTRAS:
  dst = os.path.normpath(os.path.join(AQUI, arq))
  h = hashlib.sha256(open(dst, 'rb').read()).hexdigest()
  linhas.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(dst)).strftime('%Y-%m-%d'), desc, arq, url, h]))
open(os.path.join(AQUI, 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(linhas) + '\n')
print(len(linhas), 'arquivos')

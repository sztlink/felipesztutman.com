# Frente FB, expectativas contra resultados (protocolo do BRIEF-v13)

O protocolo está em `../../BRIEF-v13.md`, fixado em 20/10/2026 antes dos dados. Este LEIAME só registra como o build o executa,
o que saiu e o que ficou de fora. Build escrito e rodado em 24/10/2026.

## Arquivos

| arquivo | o que é |
|---|---|
| `../../FB-erros.csv` | um por ano de origem (2000 a 2024) x variável (ipca, pib, selic, cambio, primario) x horizonte (h1, h2), 250 linhas. Data de origem, esperado (mediana do Focus), respondentes, realizado, erro, erro absoluto, eleição sim ou não, presidente na data de origem (só data o valor), situação (incluido ou excluido com o motivo), arquivos de fonte |
| `../../FB-resumo.csv` | `tipo = distribuicao`, mediana do erro, mediana do erro absoluto, p10 e p90 do erro por variável e horizonte. `tipo = eleicao`, erro e posição do erro absoluto de cada ano de eleição (2002 a 2022) entre os anos da amostra |
| `../../FB-curva.csv` | parte B, 2008 a 2025. Prefixado de 1 ano do TD na média de setembro de t contra a Selic meta média de outubro de t a setembro de t+1 |
| `excluidos.tsv` | os 7 casos da parte A que saíram, com o motivo |
| `conferencia_primario.tsv` | SGS 5793 contra a Tabela 2 das estatísticas fiscais de set/2026 em 2024 e 2025 |
| `entradas.tsv` | sha256 de cada arquivo lido pelo build |
| `downloads.tsv` | data, descrição, arquivo, url e sha256 de cada bruto (escrito por `baixa_FB.py`) |
| `baixa_FB.py`, `build_FB.py` | download e build |

## Fontes

- Focus, Olinda `ExpectativasMercadoAnuais`, baseCalculo 0, 15/09 a 07/10 de cada ano (`fontes/focus_anuais_<t>.json`, baixados em 20/10/2026).
- IPCA, SIDRA 1737 v2266, número-índice (`fontes/sidra_1737_v2266.json`, 24/10/2026). O hash é o mesmo do arquivo da frente N.
- PIB, SIDRA 5932, c11255 90707 (PIB a preços de mercado), variável "Taxa acumulada ao longo do ano (em relação ao mesmo
  período do ano anterior)" no 4º trimestre (`fontes/sidra_5932_pib.json`, 24/10/2026). Série de hoje do IBGE, com revisões.
- Selic, SGS 432 em 31/12. Câmbio, SGS 1, último valor do arquivo de 20 a 31/12. Primário, SGS 5793 em dezembro, sinal trocado.
- Conferência do primário, `../I/bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx` (lido da frente I sem copiar).
- Parte B, `../../W-curva-mensal.csv` (prefixado_1a, selic_meta_media_mes) e `../../W-selic-real.csv` (selic_over_acum_12m_seguintes).

O acréscimo de 24/10/2026 ao `baixa_FB.py` baixou só os dois arquivos do IBGE, uma requisição por vez com pausa de 3 s, e
registra a planilha da frente I. As 78 linhas anteriores do `downloads.tsv` ficaram iguais.

## Como o build executa o protocolo

- Data de origem. Primeiro domingo de outubro de t, sábado anterior a ele, e a última data do Focus até esse sábado. A data é
  uma só por ano, para todas as variáveis. Se uma variável não tem mediana nessa data para o ano alvo, o caso sai.
- Só entram registros com `IndicadorDetalhe` vazio (é o caso de todos os arquivos baixados). Duas medianas diferentes para o
  mesmo indicador, data e ano alvo param o build.
- IPCA realizado = índice de dezembro de t sobre o de dezembro de t-1, menos 1. Os valores ficam com 4 casas, sem arredondar
  antes da subtração.
- Erro = realizado menos esperado. Percentis por interpolação linear entre ordens (tipo 7, o padrão do R e do numpy), com a
  biblioteca padrão do Python.
- Posição do ano de eleição = 1 mais o número de anos com erro absoluto estritamente maior. Posição 1 é o maior erro absoluto.
  A coluna `empatados` conta os outros anos com o mesmo erro absoluto.
- Parte B. A leitura do protocolo é a média simples das 12 médias mensais da meta da Selic (W). A coluna da over acumulada
  nos mesmos 12 meses (W-selic-real) é complemento declarado e não entra no resumo.

## Casos excluídos (parte A)

- 2000, PIB, h2. O Focus de 29/09/2000 não tem mediana de PIB para 2002.
- 2000, primário, h1. A SGS 5793 começa em nov/2002 e não tem dezembro de 2001. O caso de 2000 h2 (alvo 2002) fica.
- 2024, as cinco variáveis em h2. O alvo 2026 não está realizado (o último ano realizado do protocolo é 2025).

Na parte B nenhum ano saiu (18 anos, 2008 a 2025).

## Conferência do primário

A SGS 5793 de dezembro dá 0,40 em 2024 e 0,43 em 2025 (déficit positivo). A Tabela 2 de set/2026, coluna "Ano" em % do PIB,
dá 0,4037 e 0,4319. Arredondada a 2 casas, confere nos dois anos. O build para se não conferir.

## Números (classe A, medido)

Erro = realizado menos esperado, em pontos percentuais (R$ por dólar no câmbio), de `../../FB-resumo.csv`.

| variável | horizonte | n | mediana do erro | mediana do erro absoluto | p10 | p90 |
|---|---|---|---|---|---|---|
| IPCA | h1 | 25 | 0,47 | 0,96 | -0,47 | 4,13 |
| IPCA | h2 | 24 | 1,23 | 1,35 | -0,54 | 5,26 |
| PIB | h1 | 25 | -0,30 | 1,50 | -3,28 | 2,64 |
| PIB | h2 | 23 | -0,21 | 1,70 | -5,31 | 2,30 |
| Selic | h1 | 25 | 1,50 | 2,75 | -3,40 | 5,48 |
| Selic | h2 | 24 | 1,75 | 3,44 | -3,50 | 6,05 |
| Câmbio | h1 | 25 | 0,11 | 0,40 | -0,63 | 1,00 |
| Câmbio | h2 | 24 | 0,24 | 0,65 | -0,85 | 1,49 |
| Primário | h1 | 24 | -0,49 | 0,66 | -2,21 | 0,66 |
| Primário | h2 | 24 | -0,87 | 1,05 | -3,73 | 0,82 |
| Curva, pré 1 ano contra Selic (parte B) | 12 meses | 18 | 0,16 | 0,70 | -1,53 | 1,49 |

Leitura, sem teste de significância (seis casos de eleição por célula).

- O IPCA realizado ficou acima do esperado na mediana, 0,47 ponto em h1 e 1,23 ponto em h2.
- O primário realizado ficou abaixo do esperado na mediana, 0,49 ponto do PIB em h1 e 0,87 em h2.
- A Selic de fim de ano ficou acima da esperada na mediana, 1,50 ponto em h1 e 1,75 em h2.
- Entre os anos de eleição, a origem de 2014 tem o maior erro absoluto de câmbio em h1 (1º de 25), o 2º de PIB em h1 e o 3º de
  IPCA e de primário em h1. A origem de 2018 tem o maior erro absoluto de primário em h2 (1º de 24) e o 2º de PIB em h2, com ano
  alvo 2020. A origem de 2022 tem o 24º erro absoluto de Selic em h1, entre os menores.
- Esses anos aparecem como casos. A posição não diz que a eleição causou o erro nem qual governo produziu o resultado (classe C,
  fora do protocolo).

## O que o build não cobre

- PIB contra a série de hoje, não contra a primeira divulgação (declarado no protocolo).
- Parte B, TD alguns pb abaixo da curva de mercado, não corrigido.
- A SGS 5793 não cobre 2001, então o primário tem um caso a menos em h1.

## Como rodar

```
cd /tmp && python3 -I gastos-publicos-brasil-dados/brutos/FB/baixa_FB.py   # só baixa o que falta
cd /tmp && python3 -I gastos-publicos-brasil-dados/brutos/FB/build_FB.py
```

Só biblioteca padrão. Duas rodadas seguidas em 24/10/2026 deram os mesmos sha256 para os três CSV e os três TSV.

| arquivo | sha256 |
|---|---|
| FB-erros.csv | 0b33f00ef722ee2fc95b34a14cfa83abf41a8b8a37ef94f0ddc49faed8fb485a |
| FB-resumo.csv | 51d3bfdaf2ee12ae133f413aedbb30e3ce10e455ad05b86e76088a5c56c47900 |
| FB-curva.csv | 3dc9592c3d9f92e025658bc5d44d31a186e6d73d4d53f5ffdf8d626693c9de4a |

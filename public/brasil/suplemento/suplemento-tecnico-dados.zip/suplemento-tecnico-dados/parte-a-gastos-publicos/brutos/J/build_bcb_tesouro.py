#!/usr/bin/env python3
"""Resultado do BCB transferido ao Tesouro (e coberto pelo Tesouro), 2008 a 2025.

Grava brutos/J/bcb-tesouro-transferencias.csv. Os valores estao transcritos aqui a mao,
cada um com a pagina do documento de onde foi lido (PDFs em dl-bcb-tesouro/ e
dl-tesouro-rad-AAAA/). Nada e lido de memoria; o que nao foi achado fica vazio.

Ano = exercicio (semestre ou ano) do balanco do BCB, nao a data do pagamento.
A data de liquidacao vai na nota. R$ milhoes correntes.
"""
import csv
import os

AQUI = os.path.dirname(os.path.abspath(__file__))
SAIDA = os.path.join(AQUI, 'bcb-tesouro-transferencias.csv')

U_STN = ('https://cdn.tesouro.gov.br/sistemas-internos/apex/producao/sistemas/thot/arquivos/'
         'publicacoes/29828_926299/RelatorioTesouroBC.pdf')
B = 'https://www.bcb.gov.br/content/acessoinformacao/balanceteslai/'
U_DF = {
    '2019-06': B + 'Demonstra%C3%A7%C3%B5es%20Financeiras%20BCB%2030.6.2019.pdf',
    2019: B + 'Demonstra%C3%A7%C3%B5es%20Financeiras%20BCB%20-%2031.12.2019.pdf',
    2020: B + 'Demonstra%C3%A7%C3%B5es%20Financeiras%20BCB%20-%2031.12.2020.pdf',
}
for _a in (2021, 2022, 2023, 2024, 2025):
    U_DF[_a] = B + f'Demonstra%C3%A7%C3%B5es%20Financeiras%20BCB%20{_a}.pdf'
T = 'https://cdn.tesouro.gov.br/sistemas-internos/apex/producao/sistemas/thot/arquivos/publicacoes/'
U_RAD = {
    2020: T + '37047_1249118/RAD%202020%20_2021_01_27-17h.pdf',
    2021: T + '42534_1395830/RAD-PT_2021-2022_14-04-2022%20.pdf',
    2022: T + '46036_1476726/RAD-PT_2022%20_%202023_02_07.pdf',
    2023: T + '48784_1516477/RAD_2023.pdf',
    2024: T + '51345_2443552/RAD_2024.pdf',
    2025: T + '53715_2522283/RAD_2026.pdf',
}

# STN, "Relacionamento entre o Tesouro Nacional e o Banco Central, Relatorio Especial 2019",
# Tabela 1 (p. 11 e 12). Colunas: semestre, principal equalizacao, principal demais contas,
# atualizacao equalizacao, atualizacao demais contas, liquidacao equalizacao, liquidacao demais.
# Sinal positivo = BCB transferiu em dinheiro a Conta Unica; negativo = Tesouro cobriu com titulos (nota 1 da tabela).
TAB1 = [
    ('2008S1', -44798, 3249, -2776, 0, '22/12/2008', '09/09/2008'),
    ('2008S2', 171416, 10176, 3550, 211, '10/03/2009', '10/03/2009'),
    ('2009S1', -93787, -938, -3355, -42, '-', '15/12/2009'),
    ('2009S2', -53932, 6554, -1402, 121, '30/03/2010', '11/03/2010'),
    ('2010S1', -1893, 10806, -111, 200, '01/01/2011', '13/09/2010'),
    ('2010S2', -46637, 4930, -6114, 106, '27/01/2012', '11/03/2011'),
    ('2011S1', -46199, 12234, -2956, 214, '31/08/2011', '08/02/2012'),
    ('2011S2', 90240, 11244, 1779, 222, '07/03/2012', '07/03/2012'),
    ('2012S1', 32210, 12321, 544, 208, '05/09/2012', '05/09/2012'),
    ('2012S2', -9901, 12300, -1103, 246, '14/01/2014', '11/03/2013'),
    ('2013S1', 15767, 15464, 296, 290, '16/09/2013', '16/09/2013'),
    ('2013S2', 15919, 14271, 311, 278, '07/03/2014', '07/03/2014'),
    ('2014S1', -51224, 5275, -2349, 100, '12/11 e 15/12/2014', '10/09/2014'),
    ('2014S2', 65173, 25659, 1559, 614, '13/03/2015', '13/03/2015'),
    ('2015S1', 46407, 35188, 1102, 835, '11/09/2015', '11/09/2015'),
    ('2015S2', 110938, 41525, 2782, 1041, '09/03/2016', '09/03/2016'),
    ('2016S1', -184645, -17305, -11072, -1089, '26/12/2016 e 16/01/2017', '20/01/2017'),
    ('2016S2', -55674, 7783, -6087, 166, '-', '13/03/2017'),
    ('2017S1', -15745, 11275, -802, 203, '31/01/2018', '12/09/2017'),
    ('2017S2', -30677, 14714, -3016, 241, '-', '08/03/2018'),
    ('2018S1', 146201, 19658, 2994, 403, '13/09/2018', '13/09/2018'),
    ('2018S2', -19134, 25557, None, 416, '', '14/03/2019'),
]
# Datas que a Tabela 1 deixa em branco, lidas nas DF do BCB:
DATA_DF = {
    ('2017S2', 'eq'): '15/01/2019 (DF BCB 30/06/2019, p. 32)',
    ('2018S2', 'eq'): '15/01/2020 (DF BCB 31/12/2019, p. 63)',
}
PG_T1 = 'STN Relatorio Especial 2019, Tabela 1, p. 11-12'

linhas = []


def add(ano, tipo, sentido, valor, forma, url, pg, nota):
    linhas.append({'ano': ano, 'tipo': tipo, 'sentido': sentido,
                   'valor_rs_mi': '' if valor is None else round(valor, 1),
                   'forma': forma, 'fonte_url': url, 'pagina_ou_tabela': pg, 'nota': nota})


# 2008 a 2018: Tabela 1 da STN, soma dos semestres do ano por sinal (principal + atualizacao)
for ano in range(2008, 2019):
    sems = [r for r in TAB1 if r[0].startswith(str(ano))]
    for tipo, ip, ia, idt, k in (('equalizacao_cambial', 1, 3, 5, 'eq'), ('resultado_operacional', 2, 4, 6, 'dc')):
        for sentido, forma, pos in (('bc_para_tn', 'dinheiro', True), ('tn_para_bc', 'titulos', False)):
            tot, partes = 0, []
            for r in sems:
                p, at = r[ip], r[ia]
                if (p > 0) != pos or p == 0:
                    continue
                tot += p + (at or 0)
                dt = DATA_DF.get((r[0], k)) or r[idt] or ''
                partes.append(f"{r[0]}: principal {p}, atualizacao {'nao informada' if at is None else at}, liquidacao {dt}")
            rotulo = 'equalizacao cambial (Lei 11.803/2008, reservas e swaps)' if k == 'eq' else \
                'demais contas, resultado do BCB sem a equalizacao (Lei 4.595/64, LRF art. 7)'
            nota = (f"{rotulo}. " + ('; '.join(partes) if partes else 'nenhum semestre neste sentido na Tabela 1')
                    + '. Valor = principal + atualizacao, sinal tirado (a Tabela 1 usa negativo para cobertura em titulos).')
            if ano == 2018 and k == 'eq' and not pos:
                nota += (' A Tabela 1 nao traz atualizacao do 2S2018; a DF BCB 2021 (p. 70, coluna 2020) registra '
                         'emissao de R$ 28.734 mi em 2020 para cobrir 2S2018 e 1S2019 juntos, com atualizacao.')
            add(ano, tipo, sentido, abs(tot), forma, U_STN, PG_T1, nota)
    add(ano, 'uso_na_dpmf', 'bc_para_tn', None, 'dinheiro', U_STN, 'STN Relatorio Especial 2019, p. 9 e 22',
        'nao encontrado. A STN diz que os valores pagos ao TN se destinam exclusivamente ao pagamento da DPMF, '
        'prioritariamente a detida pelo BCB (Lei 11.803/2008, p. 9 e box p. 10), mas nao publica quanto foi usado por ano.')

# 2019
add(2019, 'equalizacao_cambial', 'bc_para_tn', 0, 'dinheiro', U_DF[2019], 'DF BCB 31/12/2019, p. 63',
    '1S2019 com equalizacao negativa; operacao encerrada em 30/06/2019 pela Lei 13.820/2019.')
add(2019, 'equalizacao_cambial', 'tn_para_bc', 7560.8, 'titulos', U_DF[2019], 'DF BCB 31/12/2019, p. 63',
    '1S2019: R$ 7.560.780 mil coberto pelo Tesouro em 15/01/2020 (junto com o 2S2018, emissao de R$ 28.734 mi '
    'com atualizacao, DF BCB 2021 p. 70, coluna 2020). Valor sem atualizacao.')
add(2019, 'resultado_operacional', 'bc_para_tn', 43042.8, 'dinheiro', U_DF[2019],
    'DF BCB 31/12/2019, p. 62 (resultado positivo a ser transferido, 2019) e p. 63',
    '1S2019 R$ 21.075.771 mil transferido em 12/09/2019 (regra antiga, sem reserva); 2S2019 R$ 21.966.989 mil, '
    'resultado com outras operacoes, transferido em 2020 (prazo 05/03/2020). Sem a remuneracao ate o pagamento.')
add(2019, 'resultado_operacional', 'tn_para_bc', 0, 'titulos', U_DF[2019], 'DF BCB 31/12/2019, p. 63',
    'nenhum resultado negativo em 2019 fora da equalizacao.')
add(2019, 'reserva_resultado_13820', 'bc_para_tn', 0, 'nao_informado', U_DF[2019], 'DF BCB 31/12/2019, p. 65',
    'nada transferido da reserva. Constituidos R$ 42.642.923 mil de reserva de resultado no 2S2019 '
    '(resultado com reservas e derivativos cambiais), que ficam no balanco do BCB.')
add(2019, 'uso_na_dpmf', 'bc_para_tn', None, 'dinheiro', '', '', 'nao encontrado (o ADR 2019 nao separa a fonte).')

# 2020
add(2020, 'resultado_operacional', 'bc_para_tn', 24759.8, 'dinheiro', U_DF[2020], 'DF BCB 31/12/2020, quadro de resultados, p. 73',
    '1S2020 R$ 24.759.815 mil transferido em 28/08/2020. 2S2020 negativo (R$ 33.610.207 mil, p. 77) coberto por '
    'reversao da reserva de resultado, sem fluxo do Tesouro. Caixa de 2020 (DF BCB 2021 p. 70): R$ 47.311 mi = 2S2019 + 1S2020 + remuneracao.')
add(2020, 'resultado_operacional', 'tn_para_bc', 0, 'titulos', U_DF[2020], 'DF BCB 31/12/2020, p. 73 e 77',
    'resultado negativo do 2S2020 coberto pela reserva de resultado do proprio BCB, nao pelo Tesouro.')
add(2020, 'reserva_resultado_13820', 'bc_para_tn', 325000, 'dinheiro', U_DF[2021],
    'DF BCB 31/12/2021, nota 20.2 p. 44 e quadro de operacoes com o Governo Federal p. 70 (coluna 2020)',
    'transferencia da reserva de resultado ao TN, art. 5 da Lei 13.820/2019, autorizada pelo CMN em ago/2020, '
    'creditada na Conta Unica. Reserva em 2020: saldo inicial 45.047, constituicao 478.468, realizacao 33.603, saldo final 164.912.')
add(2020, 'uso_na_dpmf', 'bc_para_tn', 152300, 'dinheiro', U_RAD[2020], 'RAD 2020, p. 10, texto e nota 9',
    'derivado: RAD 2020 diz que recebeu R$ 350,0 bi do BCB em 2020 (325,0 cambial + 24,8 operacional) e que '
    'R$ 197,7 bi serao usados em 2021; 350,0 - 197,7 = 152,3 bi usados em 2020. O RAD nao exclui o 2S2019 '
    '(R$ 22,0 bi pagos em 2020 segundo a DF BCB), entao a base pode estar incompleta.')

# 2021
add(2021, 'resultado_operacional', 'bc_para_tn', 71681, 'dinheiro', U_DF[2021], 'DF BCB 31/12/2021, p. 75 e quadro p. 71',
    'resultado com outras operacoes do exercicio 2021; transferido em 25/02/2022 (DF BCB 2022 p. 70), '
    'R$ 72.801 mi com remuneracao. RAD 2022 p. 9: ingresso de R$ 72,8 bi.')
add(2021, 'resultado_operacional', 'tn_para_bc', 0, 'titulos', U_DF[2021], 'DF BCB 31/12/2021, p. 75', 'resultado do exercicio positivo.')
add(2021, 'reserva_resultado_13820', 'bc_para_tn', 0, 'nao_informado', U_DF[2021], 'DF BCB 31/12/2021, nota 20.2, p. 44',
    'nada transferido da reserva; constituicao de R$ 14.220 mi, saldo final 179.132.')
add(2021, 'uso_na_dpmf', 'bc_para_tn', None, 'dinheiro', U_RAD[2021], '',
    'nao encontrado. Pista: RAD 2020 nota 9 previa usar R$ 197,7 bi em 2021 e o saldo da fonte no inicio de 2022 era '
    'R$ 76,3 bi (RAD 2022, Tabela 1, p. 11); nenhum RAD declara o uso de 2021.')

# 2022
add(2022, 'resultado_operacional', 'bc_para_tn', 0, 'dinheiro', U_DF[2022], 'DF BCB 31/12/2022, p. 74', 'resultado do exercicio negativo.')
add(2022, 'resultado_operacional', 'tn_para_bc', 36536, 'titulos', U_DF[2022], 'DF BCB 31/12/2022, p. 74 e quadro p. 70',
    'resultado negativo de R$ 298.473 mi absorvido por reversao da reserva (179.132) e reducao do patrimonio (82.799); '
    'R$ 36.536 mi ficaram para o Tesouro (prazo 15/01/2024). Coberto em 2024 com emissao de titulos de R$ 40.696 mi '
    '(DF BCB 2024 p. 72), que inclui remuneracao. E o resultado total do BCB apos reservas, inclui perda cambial: '
    'a Lei 13.820 nao separa equalizacao.')
add(2022, 'reserva_resultado_13820', 'bc_para_tn', 0, 'nao_informado', U_DF[2022], 'DF BCB 31/12/2022, p. 74',
    'nada transferido; reserva de R$ 179.132 mi revertida para cobrir o prejuizo.')
add(2022, 'uso_na_dpmf', 'bc_para_tn', 97800, 'dinheiro', U_RAD[2022], 'RAD 2022, Tabela 1, p. 11',
    'linha Resultado do Banco Central: saldo inicial 76,3, receita 72,8, despesa 97,8, saldo final 51,3 (R$ bi).')

# 2023
add(2023, 'resultado_operacional', 'bc_para_tn', 0, 'dinheiro', U_DF[2023], 'DF BCB 31/12/2023, p. 84', 'resultado do exercicio negativo.')
add(2023, 'resultado_operacional', 'tn_para_bc', 111245, 'titulos', U_DF[2023], 'DF BCB 31/12/2023, p. 84 e quadro p. 80',
    'resultado negativo de R$ 114.152 mi; patrimonio reduzido em 2.922 e R$ 111.245 mi como credito do BCB com a Uniao. '
    'Coberto em 2025 com emissao de titulos de R$ 124.024 mi com remuneracao (DF BCB 2025 p. 72). Resultado total, inclui perda cambial.')
add(2023, 'reserva_resultado_13820', 'bc_para_tn', 0, 'nao_informado', U_DF[2023], 'DF BCB 31/12/2023, p. 84', 'reserva zerada desde 2022.')
add(2023, 'uso_na_dpmf', 'bc_para_tn', None, 'dinheiro', U_RAD[2023], 'RAD 2023, Tabela 1, p. 10',
    'nao encontrado: a fonte 400 junta retorno de creditos de entes subnacionais e resultado do BCB '
    '(saldo inicial 86,2, receita 30,4, despesa 0,1, saldo final 116,5, R$ bi). Nao houve resultado positivo do BCB pago em 2023.')

# 2024
add(2024, 'resultado_operacional', 'bc_para_tn', 28163, 'dinheiro', U_DF[2024], 'DF BCB 31/12/2024, p. 76 e quadro p. 72',
    'resultado de R$ 270.942 mi: 242.785 para a reserva e 28.163 ao Tesouro; transferido em 2025 com remuneracao, '
    'R$ 28.746 mi (DF BCB 2025 p. 72). RAD 2025 (arquivo RAD_2026.pdf) p. 11: receita Resultado do BCB R$ 28,8 bi em 2025.')
add(2024, 'resultado_operacional', 'tn_para_bc', 0, 'titulos', U_DF[2024], 'DF BCB 31/12/2024, p. 76',
    'resultado do exercicio positivo. Em 2024 o Tesouro emitiu R$ 40.696 mi em titulos para cobrir o resultado de 2022 (ja contado em 2022).')
add(2024, 'reserva_resultado_13820', 'bc_para_tn', 0, 'nao_informado', U_DF[2024], 'DF BCB 31/12/2024, p. 76',
    'nada transferido; constituidos R$ 242.785 mi de reserva.')
add(2024, 'uso_na_dpmf', 'bc_para_tn', None, 'dinheiro', U_RAD[2024], 'RAD 2024, Tabela 1, p. 15',
    'nao encontrado: fonte 400 junta entes subnacionais e resultado do BCB (saldo inicial 116,5, receita 33,6, '
    'despesa 57,3, saldo final 92,8, R$ bi).')

# 2025
add(2025, 'resultado_operacional', 'bc_para_tn', 0, 'dinheiro', U_DF[2025], 'DF BCB 31/12/2025, p. 76', 'resultado do exercicio negativo.')
add(2025, 'resultado_operacional', 'tn_para_bc', 0, 'titulos', U_DF[2025], 'DF BCB 31/12/2025, p. 76',
    'resultado negativo de R$ 119.966 mi coberto por reversao da reserva (119.961), sem fluxo do Tesouro. '
    'Em 2025 o Tesouro emitiu R$ 124.024 mi em titulos para cobrir o resultado de 2023 (ja contado em 2023).')
add(2025, 'reserva_resultado_13820', 'bc_para_tn', 0, 'nao_informado', U_DF[2025], 'DF BCB 31/12/2025, p. 76',
    'nada transferido; reserva revertida em R$ 119.961 mi.')
add(2025, 'uso_na_dpmf', 'bc_para_tn', None, 'dinheiro', U_RAD[2025], 'RAD 2025 (RAD_2026.pdf), Tabela 1, p. 11',
    'nao encontrado: fonte 400 junta entes subnacionais, alienacao de ativos e resultado do BCB (saldo inicial 92,8, '
    'receita 72,1, despesa 151,7, saldo final 13,2, R$ bi); a receita do BCB nela foi R$ 28,8 bi.')

with open(SAIDA, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['ano', 'tipo', 'sentido', 'valor_rs_mi', 'forma', 'fonte_url', 'pagina_ou_tabela', 'nota'])
    w.writeheader()
    w.writerows(linhas)

# Conferencia com o texto da STN (p. 27): 2008 a 2018, BCB -> TN 1.015,5 bi (709,2 equalizacao, 306,3 demais);
# TN -> BCB 714,8 bi (695,4 equalizacao, 19,4 demais).
s = {}
for l in linhas:
    if 2008 <= l['ano'] <= 2018 and l['valor_rs_mi'] != '':
        s[(l['tipo'], l['sentido'])] = s.get((l['tipo'], l['sentido']), 0) + l['valor_rs_mi']
esperado = {('equalizacao_cambial', 'bc_para_tn'): 709200, ('resultado_operacional', 'bc_para_tn'): 306300,
            ('equalizacao_cambial', 'tn_para_bc'): 695400, ('resultado_operacional', 'tn_para_bc'): 19400}
for k, v in esperado.items():
    ok = abs(s[k] - v) <= 50
    print(f"{k}: {s[k]:,.0f} (STN p. 27: {v:,.0f}) {'confere' if ok else 'NAO CONFERE'}")
print('linhas:', len(linhas), '->', SAIDA)

#!/usr/bin/env python3
# Frente J: por que a DBGG (conceito Bacen) e a DLSP andam em sentidos opostos.
# Le as Tabelas de estatisticas fiscais do BCB (edicoes AAAA01 e AAAA12 baixadas em dl-AAAAMM/, mais as da frente I)
# e as series longas do ftp/notaecon (Divggnp, Dlspp, safra 26/12/2018, da frente I). Para cada (serie, ano) vale a
# edicao mais nova que traz dezembro daquele ano. Gera na raiz gastos-publicos/:
#   J-dbgg-composicao.csv, J-dbgg-fatores.csv, J-dlsp-ativos.csv, J-dlsp-fatores-ajustes.csv, J-desestatizacao.csv,
#   J-ponte-por-mandato.csv
# Tambem le: pagina do BNDES (dl-bndes-recursos-tesouro/), RAD/ADR do Tesouro (dl-tesouro-rad-AAAA/, valores transcritos
# na lista PARC e BCB_TN abaixo, com a passagem citada) e a serie historica do RTN (dl-tesouro-rtn-serie-historica/).
# Uso (de fora da pasta dos dados): PYTHONPATH=<dir com xlrd> python3 <caminho>/build_J.py
import csv, glob, os, re, sys
import openpyxl, xlrd

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..'))
DIR_I = os.path.normpath(os.path.join(AQUI, '..', 'I'))
U_TAB = 'https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/{}_Tabelas_de_estatisticas_fiscais.{}'
U_FTP = 'https://www.bcb.gov.br/ftp/notaecon/{}.zip'
FTP_KEY = '201812f'  # arquivos do ftp datados de 26/12/2018: depois da edicao 201812, antes da 201901
ANOS = range(2006, 2026)

# ---------------------------------------------------------------- leitura
def load(f):
    if f.endswith('.xlsx'):
        wb = openpyxl.load_workbook(f, read_only=True, data_only=True)
        return {n: [list(r) for r in wb[n].iter_rows(values_only=True)] for n in wb.sheetnames}
    b = xlrd.open_workbook(f)
    return {s.name: [s.row_values(i) for i in range(s.nrows)] for s in b.sheets()}

def title(L):
    return ' '.join(str(c) for r in L[:3] for c in r if c not in (None, ''))

def num(x):
    return float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) else None

def parse(L):
    """linhas (rotulo, {ano_dez: (R$ mi, % PIB)}) de uma tabela com colunas Saldos / % PIB."""
    i_ano = next(i for i, r in enumerate(L) if r and str(r[0]).strip().startswith('Discrimina'))
    i_mes = next(i for i in range(i_ano, i_ano + 5)
                 if any(isinstance(c, str) and c.strip().lower().startswith('dez') for c in L[i]))
    ano, cols = None, {}
    for j in range(len(L[i_mes])):
        a = L[i_ano][j] if j < len(L[i_ano]) else None
        try: ano = int(float(a))
        except (TypeError, ValueError): pass
        m = L[i_mes][j]
        if isinstance(m, str) and m.strip().lower().startswith('dez') and ano and ano not in cols:
            cols[ano] = j
    out = []
    for r in L[i_mes + 1:]:
        if not r or not isinstance(r[0], str) or not r[0].strip(): continue
        vals = {a: (num(r[j]) if j < len(r) else None, num(r[j + 1]) if j + 1 < len(r) else None)
                for a, j in cols.items()}
        if any(v != (None, None) for v in vals.values()): out.append((r[0], vals))
    return out

def norm(lab):
    s = re.sub(r'\d+/', '', str(lab))            # notas de rodape 2/, 10/
    s = re.sub(r'\([A-Z]\s*=?[^)]*\)', '', s)     # (C=D+E), (A), (J)
    s = s.replace('*', '').replace('–', '-').replace('—', '-')
    return re.sub(r'\s+', ' ', s).strip().lower()

# ---------------------------------------------------------------- mapeamentos de rotulos
def canon_t17(n, sec):
    """Tabela 'Divida liquida e bruta do Governo Geral' e Divggnp."""
    if n.startswith('dívida bruta do governo geral - conceito fmi'): return 'dbgg_conceito_fmi'
    if n.startswith('dívida bruta do governo geral'): return 'dbgg_total'
    if n.startswith('dívida líquida do setor público'): return 'dlsp_total'
    if n.startswith('dívida líquida do governo geral'): return 'dlgg_total'
    if n.startswith('dívida líquida do banco central'): return 'bcb_dl_total'
    if n.startswith('dívida líquida das empresas estatais'): return 'estatais_dl_total'
    if n == 'dívida interna': return 'dbgg_interna'
    if n == 'dívida externa': return 'dbgg_externa'
    if sec == 'ext':
        return {'governo federal': 'dbgg_ext_gf', 'títulos de div. negociados no mercado doméstico': 'dbgg_ext_gf_titulos_mercado_domestico',
                'demais': 'dbgg_ext_gf_demais', 'governos estaduais': 'dbgg_ext_estaduais',
                'governos municipais': 'dbgg_ext_municipais'}.get(n)
    if sec == 'credext':
        return 'gg_creditos_externos' if n.startswith('créditos externos') else None
    tab = [('dívida mobiliária em mercado', 'dbgg_mob_mercado'), ('dívida mobiliária do tesouro nacional', 'dbgg_mob_tesouro'),
           ('títulos sob custódia do fge', 'dbgg_mob_fge'), ('dívidas securitizadas e tda', 'dbgg_securitizadas_tda'),
           ('aplic. de entidades da adm. federal', 'dbgg_aplic_adm_federal'), ('aplicações dos governos subnacionais', 'dbgg_aplic_subnacionais'),
           ('operações compromissadas do bacen', 'dbgg_compromissadas_bcb'), ('dívida bancária do governo federal', 'dbgg_bancaria_gf'),
           ('dívida assumida pela união', 'dbgg_lei_8727'), ('dívida mobiliária dos governos estaduais', 'dbgg_mob_estaduais'),
           ('dívida bancária governos estaduais', 'dbgg_bancaria_estaduais'), ('outras dívidas estaduais', 'dbgg_outras_estaduais'),
           ('dívida mobiliária dos governos municipais', 'dbgg_mob_municipais'), ('dívida bancária governos municipais', 'dbgg_bancaria_municipais'),
           ('créditos do governo geral', 'gg_creditos_total'), ('créditos internos', 'gg_creditos_internos'),
           ('disponibilidades do governo geral', 'gg_disponibilidades'), ('aplic.da previdência social', 'gg_disp_previdencia'),
           ('arrecadação a recolher', 'gg_disp_arrecadacao'), ('depósitos à vista', 'gg_disp_depositos_vista'),
           ('disponibilidades do governo federal no bacen', 'gg_conta_unica'), ('aplicações na rede bancária', 'gg_disp_rede_estadual'),
           ('créditos concedidos a inst. financ. oficiais', 'gg_cred_ifo_total'), ('instrumentos híbridos de capital e dívida', 'gg_cred_ifo_hibridos'),
           ('créditos junto ao bndes', 'gg_cred_bndes'), ('aplicações em fundos e programas', 'gg_fundos_programas'),
           ('aplicações de fundos e programas', 'gg_fundos_programas'), ('créditos junto às estatais', 'gg_cred_estatais'),
           ('demais créditos do governo federal', 'gg_demais_creditos_gf'), ('recursos do fat na rede bancária', 'gg_fat_rede_bancaria'),
           ('títulos livres na carteira do bacen', 'gg_titulos_livres_bcb'), ('equalização cambial', 'gg_equalizacao_cambial')]
    for k, v in tab:
        if n.startswith(k): return v
    if n == 'pib': return 'pib_12m'
    return None

def sec_t17(n, sec):
    if n == 'dívida interna': return 'int'
    if n == 'dívida externa': return 'ext'
    if n.startswith('créditos do governo geral') or n.startswith('créditos internos'): return 'cred'
    if n.startswith('créditos externos'): return 'credext'
    if n.startswith('títulos livres'): return 'fim'
    return sec

def canon_dlsp(lab, sec):
    """Tabela 'Divida Liquida do Setor Publico (DLSP)' (e continuacoes -A/-B) e Dlspp. Devolve (serie, nova_secao)."""
    n, top = norm(lab), not str(lab).startswith(' ')
    if top:
        novo = {'dívida líquida total': 'tot', 'dívida interna líquida': 'int', 'governo federal': 'int_gf',
                'banco central do brasil': 'int_bcb', 'governos estaduais': 'int_est', 'governos municipais': 'int_mun',
                'empresas estatais': 'int_estat', 'dívida externa líquida': 'ext'}.get(n)
        if novo:
            nome = {'tot': 'dlsp_total', 'int': 'dlsp_interna', 'int_gf': 'dlsp_int_gf', 'int_bcb': 'dlsp_int_bcb',
                    'int_est': 'dlsp_int_estaduais', 'int_mun': 'dlsp_int_municipais', 'int_estat': 'dlsp_int_estatais',
                    'ext': 'dlsp_externa'}[novo]
            return nome, novo
        if n.startswith('pib'): return None, 'fim'
        return None, sec if not n.startswith('dívida fiscal') and not n.startswith('ajuste') else 'pre'
    if sec == 'tot':
        return {'governo federal': 'dlsp_ent_gf', 'banco central do brasil': 'dlsp_ent_bcb', 'governos estaduais': 'dlsp_ent_estaduais',
                'governos municipais': 'dlsp_ent_municipais', 'empresas estatais': 'dlsp_ent_estatais'}.get(n), sec
    if sec == 'int_gf':
        tab = [('dívida mobiliária em mercado', 'dlsp_gf_mob_mercado'), ('dívida mobiliária do tesouro nacional', 'dlsp_gf_mob_tesouro'),
               ('recursos do fat', 'dlsp_gf_fat'), ('renegociação (lei nº 9.', 'dlsp_gf_reneg_9496_estados_municipios'),
               ('renegociação (lei nº 8.', 'dlsp_gf_reneg_8727'), ('créditos concedidos a inst. financ. oficiais', 'dlsp_gf_cred_ifo_total'), ('créditos conced', 'dlsp_gf_cred_ifo_total'), ('inst híb', 'dlsp_gf_cred_ifo_hibridos'),
               ('instrumentos híbridos', 'dlsp_gf_cred_ifo_hibridos'), ('créditos junto ao bndes', 'dlsp_gf_cred_bndes'),
               ('aplicações em fundos e programas', 'dlsp_gf_fundos_programas'), ('carteira de fundos', 'dlsp_gf_fundos_programas'),
               ('outros créditos do governo federal', 'dlsp_gf_outros_creditos'), ('relacionamento com banco central', 'dlsp_gf_relac_bcb'), ('relacionamento c/ banco central', 'dlsp_gf_relac_bcb'), ('reneg. (lei nº 9.', 'dlsp_gf_reneg_9496_estados_municipios'), ('dív. mob. do tesouro', 'dlsp_gf_mob_tesouro'), ('dívida mob. na carteira', 'dlsp_gf_carteira_bcb'), ('dív. mob. na carteira', 'dlsp_gf_carteira_bcb'), ('outros créditos do gov', 'dlsp_gf_outros_creditos'),
               ('conta única', 'dlsp_gf_conta_unica'), ('dívida mobiliária na carteira do bacen', 'dlsp_gf_carteira_bcb'),
               ('equalização cambial', 'dlsp_gf_equalizacao_cambial')]
        for k, v in tab:
            if n.startswith(k): return v, sec
        return None, sec
    if sec == 'int_bcb':
        tab = [('base monetária', 'dlsp_bcb_base_monetaria'), ('operações compromissadas', 'dlsp_bcb_compromissadas'),
               ('depósitos no bacen', 'dlsp_bcb_depositos'), ('outros depósitos no bacen', 'dlsp_bcb_depositos'),
               ('depósitos voluntários remunerados', 'dlsp_bcb_dep_voluntarios_remunerados'), ('demais depósitos', 'dlsp_bcb_demais_depositos'),
               ('créditos do bacen às inst', 'dlsp_bcb_creditos_if'), ('demais contas do bacen', 'dlsp_bcb_demais_contas'),
               ('dívida mobiliária do bacen', 'dlsp_bcb_mob_bcb'), ('relacionamento com governo federal', 'dlsp_bcb_relac_gf'), ('relacionamento c/governo federal', 'dlsp_bcb_relac_gf'), ('relacionamento c/ governo federal', 'dlsp_bcb_relac_gf')]
        for k, v in tab:
            if n.startswith(k): return v, sec
        return None, sec
    if sec == 'ext':
        return {'governo federal': 'dlsp_ext_gf', 'banco central do brasil': 'dlsp_ext_bcb', 'governos estaduais': 'dlsp_ext_estaduais',
                'governos municipais': 'dlsp_ext_municipais', 'empresas estatais': 'dlsp_ext_estatais'}.get(n), sec
    return None, sec

def canon_fat(n, pre):
    tab = [('saldo', 'saldo'), ('var', 'variacao_no_ano'), ('fatores condicionantes', 'fatores_total'),
           ('necessidades financ', 'necessidades_financiamento'), ('nfsp', 'nfsp'), ('primário', 'primario'),
           ('emissões líquidas', 'emissoes_liquidas'), ('juros nominais', 'juros_nominais'), ('ajuste cambial', 'ajuste_cambial'),
           ('dívida interna indexada ao câmbio', 'cambial_divida_interna'), ('dívida mobiliária interna indexada', 'cambial_divida_interna'),
           ('dívida externa - metodológico', 'cambial_divida_externa'), ('dívida externa - outros ajustes', 'divida_externa_outros_ajustes'),
           ('reconhecimento de dívidas', 'reconhecimento_dividas'), ('privatizações', 'privatizacoes'),
           ('efeito crescimento pib', 'efeito_crescimento_pib')]
    if n.startswith('pib'): return 'pib_12m'
    for k, v in tab:
        if k in ('saldo', 'var'):
            if (k == 'saldo' and n.endswith('saldo')) or (k == 'var' and (' var' in n or n.startswith('var'))): return pre + v
            continue
        if n.startswith(k): return pre + v
    return None

# ---------------------------------------------------------------- coleta
ED = {}       # chave da edicao -> (url, rotulo)
VAL = {}      # (serie, ano) -> {edicao: (rs, pct)}
def put(serie, ano, ed, rs, pct):
    if ano not in ANOS or (rs is None and pct is None): return
    VAL.setdefault((serie, ano), {})
    if ed not in VAL[(serie, ano)]: VAL[(serie, ano)][ed] = (rs, pct)

def edicoes():
    fs = glob.glob(os.path.join(AQUI, 'dl-*', '*_Tabelas_de_estatisticas_fiscais.xls*'))
    fs += glob.glob(os.path.join(DIR_I, 'bcb-*_Tabelas_de_estatisticas_fiscais.xls*'))
    out = {}
    for f in fs:
        e = re.search(r'(\d{6})_Tabelas', f).group(1)
        out.setdefault(e, f)  # se houver duplicata, a primeira serve (mesmo arquivo do BCB)
    return sorted(out.items())

def tabelas(S):
    for n, L in S.items():
        t = title(L)
        if re.search(r'l[íi]quida e bruta do [Gg]overno [Gg]eral', t): yield 'T17', n, L
        elif re.search(r'bruta do [Gg]overno [Gg]eral . [Ff]atores', t) and 'detalh' in t: yield 'T20', n, L
        elif re.search(r'bruta do [Gg]overno [Gg]eral . [Ff]atores', t) and 'acumulados no ano' in t: yield 'T19', n, L
        elif re.search(r'Evolu..o da d.vida l.quida', t) and 'acumulados' in t: yield 'T6', n, L
        elif re.match(r'(Tabela|Quadro) [0-9IVXL]+(-[AB])? . D.vida L.quida do Setor P.blico \(DLSP\)', t): yield 'DLSP', n, L
        elif re.search(r'Banco Central do Brasil\s+Opera..es cambiais', t): yield 'T30', n, L
        elif re.search(r'D.vida L.quida do Setor P.blico . [Ff]atores condicionantes', t) and 'acumulados' in t: yield 'T8', n, L

def le_t17(L, ed):
    sec = None
    for lab, vals in parse(L):
        n = norm(lab); sec = sec_t17(n, sec)
        s = canon_t17(n, sec)
        if s:
            for a, (rs, p) in vals.items(): put(s, a, ed, rs, p)

def le_dlsp(Ls, ed):
    sec = None
    for L in Ls:
        for lab, vals in parse(L):
            s, sec = canon_dlsp(lab, sec)
            if s:
                for a, (rs, p) in vals.items(): put(s, a, ed, rs, p)

def le_fat(L, ed, pre):
    for lab, vals in parse(L):
        s = canon_fat(norm(lab), pre)
        if s == 'pib_12m':
            for a, (rs, p) in vals.items(): put(s, a, ed, rs, None)
            continue
        if s:
            for a, (rs, p) in vals.items(): put(s, a, ed, rs, p)

def le_t20(L, ed, pib):
    i = next(i for i, r in enumerate(L) if r and str(r[0]).strip().startswith('Discrimina'))
    try: ano = int(float(L[i][3]))
    except (TypeError, ValueError, IndexError): return
    im = next((k for k in range(i + 1, i + 5) if any(isinstance(c, str) and c.strip().lower().startswith('dez') for c in L[k][:3])), None)
    if im is None or not (isinstance(L[im][3], str) and L[im][3].strip().lower().startswith('dez')): return  # so ano fechado
    cols = {'emissoes_liquidas': 3, 'juros_nominais': 4, 'cambial_divida_interna': 5, 'cambial_divida_externa': 6,
            'divida_externa_outros_ajustes': 7, 'reconhecimento_dividas': 8, 'privatizacoes': 9}
    alvo = {'dívida bruta do governo geral': 'total', 'dívida interna': 'interna', 'dívida externa': 'externa',
            'operações compromissadas do bacen': 'compromissadas_bcb'}
    P = pib.get(ano); got = {}
    for r in L[im + 1:]:
        if not r or not isinstance(r[0], str): continue
        k = alvo.get(norm(r[0]))
        if not k: continue
        ini, fim = num(r[2]), num(r[10]) if len(r) > 10 else None
        fl = {c: num(r[j]) for c, j in cols.items()}
        if ini is not None and fim is not None:
            resid = fim - ini - sum(v or 0 for v in fl.values())
            if abs(resid) > 2: print(f'aviso T20 {ed} {ano} {k}: identidade fecha com resto {resid:.0f}', file=sys.stderr)
        for c, v in fl.items():
            if v is None or (k != 'total' and c not in ('emissoes_liquidas', 'juros_nominais')): continue
            put(f'dbgg_det_{k}_{c}', ano, ed, v, v / P * 100 if P else None)
            got[(k, c)] = v
    for c in ('emissoes_liquidas', 'juros_nominais'):  # divida interna exceto compromissadas: mobiliaria em mercado, bancaria do GF e de estados e municipios
        if ('interna', c) in got and ('compromissadas_bcb', c) in got:
            v = got[('interna', c)] - got[('compromissadas_bcb', c)]
            put(f'dbgg_det_interna_exceto_compromissadas_{c}', ano, ed, v, v / P * 100 if P else None)

T8_COLS = {3: 'primario', 4: 'juros_nominais', 5: 'metodologico_interno', 6: 'metodologico_externo', 7: 'paridade_cesta_moedas',
           8: 'caixa_competencia', 9: 'reconhecimento_dividas', 10: 'privatizacoes'}
def le_t8(Ls, ed, pib):
    """Tabela 8 / Quadro 9: DLSP, fatores condicionantes por instrumento, fluxo acumulado no ano (so ano fechado)."""
    sec = None
    for L in Ls:
        i = next(i for i, r in enumerate(L) if r and str(r[0]).strip().startswith('Discrimina'))
        try: ano = int(float(L[i][3]))
        except (TypeError, ValueError, IndexError): continue
        im = next((k for k in range(i + 1, i + 5) if any(isinstance(c, str) and c.strip().lower().startswith('dez') for c in L[k][:3])), None)
        if im is None or not (isinstance(L[im][3], str) and L[im][3].strip().lower().startswith('dez')): continue
        cab = ' '.join(str(c) for r in L[im:im + 6] for c in r[3:11] if c)
        if 'Privati' not in cab or 'Parida' not in cab: continue
        P = pib.get(ano)
        for r in L[im + 1:]:
            if not r or not isinstance(r[0], str) or not r[0].strip(): continue
            serie, sec = canon_dlsp(r[0], sec)
            if not serie: continue
            ini, fim = num(r[2]), num(r[11]) if len(r) > 11 else None
            fl = {c: num(r[j]) if j < len(r) else None for j, c in T8_COLS.items()}
            if ini is None or fim is None: continue
            resto = fim - ini - sum(v or 0 for v in fl.values())
            if abs(resto) > 2: print(f'aviso T8 {ed} {ano} {serie}: identidade fecha com resto {resto:.0f}', file=sys.stderr)
            base = serie.replace('dlsp_', '', 1)
            for c, v in fl.items():
                if v is not None: put(f'dlspaj_{base}_{c}', ano, ed, v, v / P * 100 if P else None)

def le_t30(L, ed):
    # linhas anuais (ano na coluna 0) ate 2018; de 2019 em diante, linha 'Acum. no ano' do bloco do ano
    cols = {'bcb_resultado_swap_cambial': 5, 'bcb_resultado_reservas': 7, 'bcb_resultado_operacoes_cambiais': 8,
            'bcb_resultado_outros': 9, 'bcb_resultado_total': 10}
    ano, viu_dez = None, False
    for r in L:
        if not r: continue
        a = num(r[0])
        if a and 2000 < a < 2100: ano, viu_dez = int(a), False
        mes = str(r[1]).strip() if len(r) > 1 and r[1] is not None else ''
        if mes.lower().startswith('dez'): viu_dez = True
        anual = (a and mes in ('', 'None')) or (mes.lower().startswith('acum. no ano') and viu_dez)  # ano incompleto fica de fora
        if ano and anual:
            for s, j in cols.items():
                v = num(r[j]) if j < len(r) else None
                if v is not None: put(s, ano, ed, v, None)

for e, f in edicoes():
    ext = 'xlsx' if f.endswith('.xlsx') else 'xls'
    ED[e] = (U_TAB.format(e, ext), f'Tabelas de estatisticas fiscais {e}')
    S = load(f)
    dl = []
    for k, n, L in tabelas(S):
        if k == 'T17': le_t17(L, e)
        elif k == 'DLSP': dl.append(L)
        elif k == 'T19': le_fat(L, e, 'dbgg_fat_')
        elif k == 'T6': le_fat(L, e, 'dlsp_fat_')
        elif k == 'T30': le_t30(L, e)
    le_dlsp(dl, e)
    pib = {}
    # PIB 12 meses da Tabela 19 da mesma edicao, para o % PIB do detalhamento
    for k, n, L in tabelas(S):
        if k == 'T19':
            for lab, vals in parse(L):
                if norm(lab).startswith('pib'):
                    pib = {a: v[0] for a, v in vals.items()}
    for k, n, L in tabelas(S):
        if k == 'T20': le_t20(L, e, pib)
    le_t8([L for k, n, L in tabelas(S) if k == 'T8'], e, pib)

# ftp/notaecon: Divggnp (governo geral) e Dlspp (DLSP), safra 26/12/2018
ED[FTP_KEY] = ('Divggnp: ' + U_FTP.format('Divggnp') + ' ; Dlspp: ' + U_FTP.format('Dlspp'), 'ftp notaecon 26/12/2018')
for nome in ('Divggnp', 'Dlspp'):
    S = load(os.path.join(DIR_I, f'ftp-{nome}', f'{nome}.xls'))
    R, P = parse(S['R$ milhões']), parse(S['% PIB'])
    pct, cnt = {}, {}
    for lab, vals in P:
        c = cnt.get(norm(lab), 0); cnt[norm(lab)] = c + 1; pct[(norm(lab), c)] = vals
    lin, cnt = [], {}
    for lab, vals in R:
        c = cnt.get(norm(lab), 0); cnt[norm(lab)] = c + 1
        pv = pct.get((norm(lab), c), {})
        lin.append((lab, {a: (v[0], (pv.get(a) or (None,))[0]) for a, v in vals.items()}))
    if nome == 'Divggnp':
        sec = None
        for lab, vals in lin:
            n = norm(lab); sec = sec_t17(n, sec); s = canon_t17(n, sec)
            if s:
                for a, (rs, p) in vals.items(): put(s, a, FTP_KEY, rs, p)
    else:
        sec = None
        for lab, vals in lin:
            s, sec = canon_dlsp(lab, sec)
            if s:
                for a, (rs, p) in vals.items(): put(s, a, FTP_KEY, rs, p)

def mais_nova(serie, ano):
    d = VAL.get((serie, ano))
    if not d: return None
    e = max(d)
    return (*d[e], e)

def em(serie, ano, e):
    d = VAL.get((serie, ano), {})
    return d.get(e)

def rotulo_ed(e):
    return 'ftp-notaecon-20181226' if e == FTP_KEY else e

def fonte(serie, e):
    if e != FTP_KEY: return ED[e][0]
    return U_FTP.format('Dlspp' if serie.startswith('dlsp_') and not serie == 'dlsp_total' else 'Divggnp')

# ---------------------------------------------------------------- notas por serie
NOTAS = {
 'dbgg_total': 'DBGG conceito Bacen (exclui titulos na carteira do BCB, inclui compromissadas do BCB). Serie comeca em dez/2006.',
 'dbgg_conceito_fmi': 'DBGG conceito FMI (inclui toda a divida mobiliaria na carteira do BCB). So publicada nas edicoes recentes.',
 'dbgg_mob_mercado': 'Divida mobiliaria do Tesouro em mercado, liquida de aplicacoes intra/intergovernamentais e titulos do FGE.',
 'dbgg_compromissadas_bcb': 'Operacoes compromissadas do BCB (inclui extramercado). Entram na DBGG conceito Bacen.',
 'dbgg_ext_gf_titulos_mercado_domestico': 'A partir das edicoes de 2019: titulos em reais em poder de nao residentes passam a ser dívida externa.',
 'gg_conta_unica': 'Disponibilidades do governo federal no BCB (conta unica do Tesouro). Ativo do GG, passivo do BCB: some na consolidacao do setor publico.',
 'gg_cred_bndes': 'Creditos do Tesouro junto ao BNDES (sem os instrumentos hibridos).',
 'gg_cred_ifo_hibridos': 'Instrumentos hibridos de capital e divida (BNDES, CEF, BB, BNB).',
 'gg_titulos_livres_bcb': 'Titulos do Tesouro na carteira do BCB menos o estoque de compromissadas.',
 'gg_equalizacao_cambial': 'Equalizacao cambial (Lei 11.803/2008): resultado das reservas e swaps a pagar/receber entre BCB e Tesouro. Zerada desde a Lei 13.820/2019.',
 'dlsp_ext_bcb': 'Divida externa liquida do BCB, inclui as reservas internacionais (valor negativo = ativo). As tabelas fiscais nao trazem as reservas brutas.',
 'dlsp_bcb_depositos': 'Depositos no BCB; inclui depositos voluntarios remunerados desde 2021.',
 'dlsp_gf_reneg_9496_estados_municipios': 'Haveres da Uniao sobre estados e municipios renegociados (ativo do GF na DLSP; some na consolidacao do governo geral).',
}
def nota(serie, e):
    n = NOTAS.get(serie, '')
    if e == FTP_KEY: n = (n + ' ' if n else '') + 'Serie longa do ftp/notaecon de 26/12/2018 (historico refeito sem Petrobras e Eletrobras).'
    elif e < '201001' and (serie.startswith('dlsp_') or serie.startswith('estatais')):
        n = (n + ' ' if n else '') + 'Edicao anterior a exclusao de Petrobras (2009) e Eletrobras (2010) das estatais.'
    if serie.startswith('dbgg_det_'):
        n = (n + ' ' if n else '') + 'Fluxo acumulado no ano (Tabela 20, detalhamento, edicao AAAA01 do ano seguinte); % PIB calculado = R$ / PIB 12 meses da Tabela 19 da mesma edicao.'
    if serie.startswith('dbgg_fat_') or serie.startswith('dlsp_fat_'):
        if serie.endswith('efeito_crescimento_pib'): n = (n + ' ' if n else '') + 'So % PIB: variacao da razao devida ao crescimento do PIB nominal.'
        elif serie.endswith('variacao_no_ano'): n = (n + ' ' if n else '') + '% PIB = variacao da razao divida/PIB em pontos.'
        elif not serie.endswith('saldo'): n = (n + ' ' if n else '') + '% PIB = fluxo do ano / PIB do ano (somado ao efeito PIB da a variacao da razao).'
    if serie.startswith('bcb_resultado'):
        n = (n + ' ' if n else '') + 'Resultado do BCB no ano, R$ mi (Tabela Operacoes cambiais; anual ate 2018, Acum. no ano depois). Tabela deixou de sair apos a edicao 202101.'
    return n

def estoque(serie):
    return not (serie.startswith('dbgg_fat_') or serie.startswith('dlsp_fat_') or serie.startswith('dbgg_det_')
                or serie.startswith('bcb_resultado') or serie.startswith('dlspaj_') or serie == 'pib_12m')

PIB = {}
for a in ANOS:
    m = mais_nova('pib_12m', a)
    if m and m[0]: PIB[a] = (m[0], m[2])

def fmt(x, nd):
    return '' if x is None else f'{x:.{nd}f}'

def grava(nome, pref, fora=(), lista=None):
    series = lista or sorted({s for (s, a) in VAL if any(s.startswith(p) for p in pref) and not any(s.startswith(x) for x in fora)})
    with open(os.path.join(RAIZ, nome), 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['serie', 'ano', 'valor_pct_pib', 'valor_rs_mi', 'fonte_url', 'edicao', 'nota'])
        for s in series:
            for a in ANOS:
                m = mais_nova(s, a)
                if m is None:
                    w.writerow([s, a, '', '', '', '', 'nao encontrado']); continue
                rs, p, e = m
                nt = nota(s, e)
                if estoque(s) and rs is not None and PIB.get(a):
                    pb, ep = PIB[a]
                    if ep != e:
                        nt = (nt + ' ' if nt else '') + (f'% PIB recalculado = R$ / PIB 12m de dez/{a} da edicao {rotulo_ed(ep)} '
                              f'(R$ {pb:.0f} mi); a edicao {rotulo_ed(e)} publicou {fmt(p, 2)}.')
                    p = rs / pb * 100
                elif s.startswith('dlspaj_') and rs is not None and PIB.get(a):
                    nt = (nt + ' ' if nt else '') + f'% PIB = R$ / PIB 12m de dez/{a} da edicao {rotulo_ed(PIB[a][1])}.'
                    p = rs / PIB[a][0] * 100
                w.writerow([s, a, fmt(p, 2), fmt(rs, 1), fonte(s, e), rotulo_ed(e), nt])
    return series

grava('J-dbgg-composicao.csv', ['dbgg_total', 'dbgg_conceito_fmi', 'dbgg_interna', 'dbgg_externa', 'dbgg_mob', 'dbgg_securitizadas',
                                'dbgg_aplic', 'dbgg_compromissadas', 'dbgg_bancaria', 'dbgg_lei', 'dbgg_outras', 'dbgg_ext_'])
grava('J-dbgg-fatores.csv', ['dbgg_fat_', 'dbgg_det_', 'dlsp_fat_'])
grava('J-dlsp-ativos.csv', ['gg_', 'dlsp_', 'dlgg_', 'bcb_', 'estatais_', 'pib_'], fora=('dlsp_fat_',))

# ---------------------------------------------------------------- ajustes da DLSP (Tabela 8 / Quadro 9 e Tabela 6)
AJ_LIN = ['total', 'ent_gf', 'ent_bcb', 'ent_estaduais', 'ent_municipais', 'ent_estatais', 'interna', 'externa',
          'gf_cred_bndes', 'gf_cred_ifo_total', 'gf_conta_unica', 'gf_mob_tesouro', 'gf_reneg_9496_estados_municipios',
          'gf_outros_creditos', 'bcb_compromissadas', 'ext_bcb']
AJ_COL = list(T8_COLS.values())
def tem_valor(serie):
    return any(abs(d[e][0] or 0) > 0.05 for (s_, a), d in VAL.items() if s_ == serie for e in d)
lista_aj = [f'dlspaj_{l}_{c}' for l in AJ_LIN for c in AJ_COL if tem_valor(f'dlspaj_{l}_{c}')]
lista_aj += [f'dlsp_fat_{c}' for c in ('reconhecimento_dividas', 'privatizacoes', 'ajuste_cambial', 'cambial_divida_interna',
                                        'cambial_divida_externa', 'divida_externa_outros_ajustes')]
NOTAS.update({f'dlspaj_total_{c}': f'DLSP, fator {c} do ano, total do setor publico (Tabela 8 / Quadro 9, edicao AAAA01 do ano seguinte).' for c in AJ_COL})
NOTAS['dlspaj_gf_cred_bndes_primario'] = ('Fluxo de financiamento registrado na linha Creditos junto ao BNDES: positivo = o ativo do Tesouro encolheu '
                                          '(devolucoes liquidas de novos emprestimos); os juros recebidos ficam na coluna juros_nominais.')
grava('J-dlsp-fatores-ajustes.csv', [], lista=lista_aj)

# ---------------------------------------------------------------- desestatizacao, devolucoes do BNDES, resultado do BCB, concessoes
U_BNDES = 'https://www.bndes.gov.br/wps/portal/site/home/transparencia/recursos-do-tesouro-nacional'
U_RTN = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'
U_RAD = {}
for linha_ in open(os.path.join(AQUI, 'downloads.tsv'), encoding='utf-8'):
    c_ = linha_.rstrip('\n').split('\t')
    if len(c_) > 3 and ('RAD' in c_[3] or 'ADR' in c_[3]):
        U_RAD[int(re.search(r'(\d{4})', c_[3]).group(1))] = c_[0]
DESEST = []  # (serie, ano, pct, rs, url, edicao, nota)
AFETA = {
 'bndes': 'Afeta DBGG: sim, reduz no recebimento (pagamento em titulos cancela divida; em dinheiro, entra na conta unica, '
          'enxuga liquidez e reduz compromissadas do BCB: RAD 2017 e 2018, ADR 2019). Afeta DLSP: nao de imediato (troca de ativo por passivo, '
          'RAD 2018). Afeta primario: nao (o principal; juros recebidos sao juros nominais).',
 'bcb': 'Afeta DBGG: sim quando usado para resgatar DPMFi (RAD 2020: recursos exclusivos para pagar divida). Afeta DLSP: nao '
        '(transferencia dentro do setor publico consolidado; o ganho cambial ja entrou na DLSP pelo ajuste cambial das reservas). '
        'Afeta primario: nao.',
 'priv': 'Afeta DLSP: sim, reduz (fator Privatizacoes, ajuste patrimonial fora do primario). Afeta DBGG: so se a receita for usada '
         'para resgatar divida ou enxugar liquidez. Afeta primario: nao.',
 'conc': 'Afeta primario: sim (receita primaria do Governo Central no RTN); por isso entra na DLSP pelo primario. Afeta DBGG: indireto.',
 'div': 'Afeta primario: sim (receita primaria do RTN). DLSP: pelo primario. Dividendos de estatais federais nao financeiras e bancos '
        'publicos sao transferencias dentro do setor publico apenas quando a estatal esta na DLSP; Petrobras e Eletrobras estao fora.',
}
def d_add(serie, ano, rs, url, ed, nt, pct=None):
    if pct is None and rs is not None and isinstance(ano, int) and PIB.get(ano):
        pct = rs / PIB[ano][0] * 100
    DESEST.append((serie, ano, pct, rs, url, ed, nt))

# 1) BNDES: devolucoes ao Tesouro por ano (pagina de transparencia do BNDES, R$ bi correntes)
txt = open(os.path.join(AQUI, 'dl-bndes-recursos-tesouro', 'pagina.html'), encoding='utf-8', errors='replace').read()
txt = re.sub(r'<script.*?</script>|<style.*?</style>', '', txt, flags=re.S)
import html as _html
txt = _html.unescape(re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', txt)))
atual = re.search(r'tima atualiza..o: ([0-9.]+)', txt)
dev = txt[txt.index('Devoluções'):txt.index('TOTAL', txt.index('Devoluções'))]
cap = txt[txt.index('Captações'):txt.index('TOTAL', txt.index('Captações'))]
nbr = lambda x: None if x.strip() in ('-', '') else float(x.replace('.', ',').replace(',', '.')) if x.count(',') + x.count('.') == 1 else float(x.replace('.', '').replace(',', '.'))
for m in re.finditer(r'(20\d\d)(?: \d)? ([0-9.,]+|-) ([0-9.,]+|-) ([0-9.,]+|-)', dev):
    a = int(m.group(1))
    if a > 2025: continue
    for serie, g in (('bndes_devolucao_ordinaria_principal_e_juros', 2), ('bndes_liquidacao_antecipada', 3), ('bndes_devolucao_total', 4)):
        v = nbr(m.group(g))
        d_add(serie, a, 0.0 if v is None else v * 1000, U_BNDES, f'BNDES, atualizacao {atual.group(1) if atual else "?"}',
              ('Valor "-" na fonte = zero. ' if v is None else '') + AFETA['bndes'])
for m in re.finditer(r'(20\d\d)( 2)? ([0-9]+,[0-9]{2})', cap):
    a = int(m.group(1)); v = nbr(m.group(3))
    nota_c = 'Captacao do BNDES junto ao Tesouro (emprestimo do Tesouro: aumenta a DBGG e cria ativo de mesmo valor na DLSP).'
    if m.group(2): nota_c += ' Valor referente a capitalizacao da Petrobras (nota 2 da fonte).'
    d_add('bndes_captacao_junto_ao_tesouro' + ('_capitalizacao_petrobras' if m.group(2) else ''), a, v * 1000, U_BNDES, 'BNDES', nota_c)
# fluxo medido pelo BCB na linha Creditos junto ao BNDES (Tabela 8): ver J-dlsp-fatores-ajustes.csv, serie dlspaj_gf_cred_bndes_primario

# 2) datas das antecipacoes (transcritas dos RAD/ADR do Tesouro, arquivos em dl-tesouro-rad-AAAA/)
PARC = [  # (ano, data, R$ bi, rad, observacao)
 (2016, '23/12/2016', 100.0, 2017, 'RAD 2017, Tabela 3'),
 (2017, '28/09/2017', 33.0, 2017, 'RAD 2017, Quadro 2: R$ 17,9 bi em especie e R$ 15,1 bi em titulos'),
 (2017, '27/10/2017', 17.0, 2017, 'RAD 2017, Quadro 2: integralmente em especie'),
 (2018, '29/03/2018', 30.0, 2018, 'RAD 2018, Box 1'), (2018, '29/06/2018', 30.0, 2018, 'RAD 2018, Box 1'),
 (2018, '13/08/2018', 40.0, 2018, 'RAD 2018, Box 1'), (2018, '20/08/2018', 30.0, 2018, 'RAD 2018, Box 1'),
 (2019, '31/05/2019', 30.0, 2019, 'ADR 2019 (versao em ingles do RAD), Box 1'), (2019, '19/09/2019', 40.0, 2019, 'ADR 2019, Box 1'),
 (2019, '11/12/2019', 30.0, 2019, 'ADR 2019, Box 1'),
 (2021, '08/03/2021', 36.5, 2021, 'RAD 2021, nota 5'), (2021, '16/03/2021', 1.5, 2021, 'RAD 2021, nota 5'),
 (2021, '01/07/2021', 13.5, 2021, 'RAD 2021, nota 5'), (2021, '26/07/2021', 3.0, 2021, 'RAD 2021, nota 5'),
 (2021, '22/10/2021', 5.0, 2021, 'RAD 2021, nota 5'), (2021, '28/12/2021', 3.5, 2021, 'RAD 2021, nota 5'),
]
for a, data, v, rad, obs in PARC:
    DESEST.append(('bndes_antecipacao_parcela', a, None, v * 1000, U_RAD.get(rad, ''), f'Tesouro RAD {rad}', f'Data {data}. {obs}.'))
for a in (2015, 2022):
    DESEST.append(('bndes_antecipacao_parcela', a, None, None, '', '', 'Datas das parcelas: nao encontrado nos RAD baixados (o RAD 2022 traz so o total anual de R$ 72,3 bi).'))
# impacto estimado pelo proprio Tesouro (ADR 2019, Tabela 1): % do PIB acumulado na DBGG
for a, pp in ((2015, 0.3), (2016, 2.1), (2017, 3.0), (2018, 5.0), (2019, 6.9)):
    DESEST.append(('tesouro_impacto_acumulado_bndes_na_dbgg', a, pp, None, U_RAD.get(2019, ''), 'Tesouro ADR 2019',
                   'Impacto acumulado das antecipacoes (e, em 2019, da reprogramacao de contratos) na razao DBGG/PIB, com efeito de juros acumulado, '
                   'estimativa do Tesouro (ADR 2019, Tabela 1, coluna a+b+c).'))

# 3) resultado do BCB recebido pelo Tesouro (RAD), so onde o RAD separa a fonte
BCB_TN = [(2020, 325000.0, 'RAD 2020: transferencia de R$ 325,0 bi da reserva de resultado (art. 5 da Lei 13.820/2019, CMN ago/2020) para pagar DPMFi', 2020),
          (2020, 24800.0, 'RAD 2020: R$ 24,8 bi de resultado operacional do BCB recebidos em 2020', 2020),
          (2022, 72800.0, 'RAD 2022: ingresso de resultado positivo do BCB referente ao exercicio de 2021; Tabela 1: despesa da fonte em 2022 R$ 97,8 bi', 2022),
          (2025, 28800.0, 'RAD 2025 (publicado 2026): receita da fonte Resultado do BCB em 2025', 2025)]
for a, v, obs, rad in BCB_TN:
    DESEST.append(('bcb_resultado_recebido_pelo_tesouro', a, v / PIB[a][0] * 100, v, U_RAD.get(rad, ''), f'Tesouro RAD {rad}', obs + '. ' + AFETA['bcb']))
for a in (2019, 2021, 2023, 2024):
    DESEST.append(('bcb_resultado_recebido_pelo_tesouro', a, None, None, U_RAD.get(a, ''), f'Tesouro RAD {a}',
                   'nao encontrado: o RAD do ano nao separa o resultado do BCB' + (' (2023 e 2024 juntam com retorno de creditos de entes subnacionais na fonte 400).' if a >= 2023 else '.')))

# 4) privatizacoes medidas pelo BCB (fator da DLSP), por esfera
for ent in ('total', 'ent_gf', 'ent_estaduais', 'ent_municipais', 'ent_estatais'):
    for a in ANOS:
        m = mais_nova(f'dlspaj_{ent}_privatizacoes', a) or (mais_nova('dlsp_fat_privatizacoes', a) if ent == 'total' else None)
        if m is None: continue
        rs, p, e = m
        d_add(f'bcb_privatizacoes_dlsp_{ent.replace("ent_", "")}', a, rs, fonte('dlsp_fat_privatizacoes', e), rotulo_ed(e),
              'Fator Privatizacoes da DLSP (BCB), fluxo do ano; negativo = reduziu a DLSP. ' + AFETA['priv'])
d_add('tesouro_alienacao_de_ativos_fonte_divida', 2025, 10000.0, U_RAD.get(2025, ''), 'Tesouro RAD 2025',
      'Receita de alienacao de ativos destinada a reserva de liquidez da divida em 2025 (RAD 2025, fonte 400). Anos anteriores: nao encontrado separado nos RAD.')
for nome_, ano_, nt_ in (
    ('venda_participacao_eletrobras_capitalizacao', 2022, 'Capitalizacao com diluicao da Uniao: o fator Privatizacoes do governo federal no BCB em 2022 e de so R$ 0,3 bi; '
     'a receita da Uniao veio como bonus de concessao (RTN, linha Concessoes e Permissoes). Valor da operacao: nao encontrado em fonte primaria baixada.'),
    ('venda_br_distribuidora_tag_nts_subsidiarias_petrobras', None, 'Vendas da Petrobras, nao da Uniao. Petrobras esta fora da DLSP e da DBGG (exclusao de 2009): '
     'nao afetam DBGG nem DLSP; a Uniao so sente via dividendos (primario). Valores: nao encontrado em fonte primaria baixada.')):
    DESEST.append((nome_, ano_ or '', None, None, '', '', nt_))

# 5) RTN: concessoes e dividendos (receita primaria do Governo Central), R$ correntes
wb_ = openpyxl.load_workbook(os.path.join(AQUI, 'dl-tesouro-rtn-serie-historica', 'rtn_serie_historica.xlsx'), read_only=True, data_only=True)
L_ = [list(r) for r in wb_['2.2'].iter_rows(values_only=True)]
anos_rtn = {j: int(c) for j, c in enumerate(L_[4]) if isinstance(c, (int, float))}
for r in L_:
    lab = str(r[0] or '')
    if re.match(r'1\.4\.1 |1\.4\.2', lab.strip()):
        serie = 'rtn_' + re.sub(r'[^a-z0-9]+', '_', _html.unescape(lab).lower().strip()
                                .translate(str.maketrans('áàãâéêíóôõúç', 'aaaaeeiooouc'))).strip('_')
        for j, a in anos_rtn.items():
            if a in ANOS and num(r[j]) is not None:
                d_add(serie, a, num(r[j]), U_RTN, 'RTN serie historica, Tabela 2.2',
                      AFETA['conc'] if '1.4.1' in lab else AFETA['div'])

with open(os.path.join(RAIZ, 'J-desestatizacao.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.writer(fh)
    w.writerow(['serie', 'ano', 'valor_pct_pib', 'valor_rs_mi', 'fonte_url', 'edicao', 'nota'])
    for serie, a, p, rs, u, ed, nt in DESEST:
        w.writerow([serie, a, fmt(p, 2), fmt(rs, 1), u, ed, nt])

def soma_des(serie, anos):
    vs = {a: [x[3] for x in DESEST if x[0] == serie and x[1] == a and x[3] is not None] for a in anos}
    falta = [a for a, v in vs.items() if not v and not any(x[0] == serie and x[1] == a for x in DESEST)]
    rs = sum(sum(v) for v in vs.values())
    pc = sum(sum(v) / PIB[a][0] * 100 for a, v in vs.items() if v)
    return pc, rs, falta, [a for a, v in vs.items() if not v]

# ---------------------------------------------------------------- ponte por mandato
# Para cada dezembro usa UMA edicao (a mais nova que traz a tabela do governo geral naquele ano) para todos os itens em R$,
# com % PIB = R$ / PIB 12 meses de dezembro da edicao mais nova que o traz (PIB revisado),
# para que a identidade feche: DLSP = DBGG + (creditos do GG exceto conta unica) + (base monetaria + depositos no BCB
# + demais contas do BCB) + divida externa liquida do BCB (reservas) + estatais. Conta unica e titulos livres na
# carteira do BCB se anulam na consolidacao GG + BCB (ver LEIAME).
MANDATOS = [('Lula 2', 2006, 2010), ('Dilma', 2010, 2015), ('2016 Dilma/Temer', 2015, 2016),
            ('Temer', 2016, 2018), ('Bolsonaro', 2018, 2022), ('Lula 3', 2022, 2025)]

def ed_ano(a):
    d = VAL.get(('dbgg_total', a), {})
    eds = [e for e in d if (('gg_creditos_total', a) in VAL and e in VAL[('gg_creditos_total', a)])]
    return max(eds) if eds else None

def v(serie, a, e):
    x = em(serie, a, e)
    if not x or x[0] is None: return (None, None)
    return (x[0], x[0] / PIB[a][0] * 100)

def ponte_ano(a):
    e = ed_ano(a)
    it = {}
    g = lambda s: v(s, a, e)
    def soma(*ps):
        rs = sum(p[0] for p in ps) if all(p[0] is not None for p in ps) else None
        pc = sum(p[1] for p in ps) if all(p[1] is not None for p in ps) else None
        return (rs, pc)
    def neg(p): return tuple(None if x is None else -x for x in p)
    it['dbgg'] = g('dbgg_total'); it['dlsp'] = g('dlsp_total')
    cu = g('gg_conta_unica')
    it['gg_cred_bndes_e_ifo'] = g('gg_cred_ifo_total')
    it['gg_fat'] = g('gg_fat_rede_bancaria')
    it['gg_fundos_programas'] = g('gg_fundos_programas')
    resto = soma(g('gg_creditos_total'), neg(cu), neg(it['gg_cred_bndes_e_ifo']), neg(it['gg_fat']), neg(it['gg_fundos_programas']))
    it['gg_demais_ativos'] = resto
    it['bcb_base_monetaria'] = g('dlsp_bcb_base_monetaria')
    dep = g('dlsp_bcb_depositos')
    it['bcb_depositos'] = dep
    it['bcb_demais'] = soma(g('dlsp_bcb_creditos_if'), g('dlsp_bcb_demais_contas'), g('dlsp_bcb_mob_bcb')) if em('dlsp_bcb_mob_bcb', a, e) else soma(g('dlsp_bcb_creditos_if'), g('dlsp_bcb_demais_contas'))
    it['bcb_externo_reservas'] = g('dlsp_ext_bcb')
    it['estatais'] = g('estatais_dl_total')
    comp = ['gg_cred_bndes_e_ifo', 'gg_fat', 'gg_fundos_programas', 'gg_demais_ativos', 'bcb_base_monetaria', 'bcb_depositos',
            'bcb_demais', 'bcb_externo_reservas', 'estatais']
    tot = soma(*[it[k] for k in comp])
    it['ponte_total'] = tot
    chk = soma(it['dbgg'], tot)
    if chk[0] is not None and it['dlsp'][0] is not None and abs(chk[0] - it['dlsp'][0]) > 50:
        print(f'aviso ponte {a} ed {e}: DBGG + ponte = {chk[0]:.0f} vs DLSP {it["dlsp"][0]:.0f}', file=sys.stderr)
    it['memo_conta_unica'] = cu
    it['memo_compromissadas'] = g('dbgg_compromissadas_bcb')
    it['memo_titulos_livres_bcb'] = g('gg_titulos_livres_bcb')
    it['memo_equalizacao_cambial'] = g('gg_equalizacao_cambial')
    it['memo_mob_mercado'] = g('dbgg_mob_mercado')
    it['memo_dbgg_externa'] = g('dbgg_externa')
    it['memo_dbgg_subnacional_bancaria'] = soma(g('dbgg_bancaria_estaduais'), g('dbgg_bancaria_municipais'))
    it['memo_cred_bndes'] = g('gg_cred_bndes')
    return e, it

PONTE = {a: ponte_ano(a) for a in range(2006, 2026)}
FAT = ['emissoes_liquidas', 'juros_nominais', 'ajuste_cambial', 'divida_externa_outros_ajustes', 'reconhecimento_dividas',
       'privatizacoes', 'efeito_crescimento_pib']
DET = ['total_emissoes_liquidas', 'compromissadas_bcb_emissoes_liquidas', 'interna_exceto_compromissadas_emissoes_liquidas',
       'externa_emissoes_liquidas', 'total_juros_nominais', 'compromissadas_bcb_juros_nominais']
DFAT = ['primario', 'juros_nominais', 'ajuste_cambial', 'divida_externa_outros_ajustes', 'reconhecimento_dividas',
        'privatizacoes', 'efeito_crescimento_pib']

with open(os.path.join(RAIZ, 'J-ponte-por-mandato.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.writer(fh)
    w.writerow(['serie', 'ano', 'valor_pct_pib', 'valor_rs_mi', 'fonte_url', 'edicao', 'nota'])
    for nome, a0, a1 in MANDATOS:
        e0, i0 = PONTE[a0]; e1, i1 = PONTE[a1]
        per = f'{a0 + 1}-{a1}'; base = f'{nome}: dez/{a0} a dez/{a1}.'
        src = f'{fonte("dbgg_total", e0)} | {fonte("dbgg_total", e1)}'
        if e0 == FTP_KEY or e1 == FTP_KEY: src += ' | ' + U_FTP.format('Dlspp')
        eds = (f'{rotulo_ed(e0)} (dez/{a0}) e {rotulo_ed(e1)} (dez/{a1}); PIB 12m de {rotulo_ed(PIB[a0][1])} e {rotulo_ed(PIB[a1][1])}')
        def linha(serie, pc, rs, nt=''):
            w.writerow([serie, per, fmt(pc, 2), fmt(rs, 1), src, eds, (base + ' ' + nt).strip()])
        def delta(k):
            x0, x1 = i0.get(k, (None, None)), i1.get(k, (None, None))
            return (None if x0[1] is None or x1[1] is None else x1[1] - x0[1],
                    None if x0[0] is None or x1[0] is None else x1[0] - x0[0])
        for k, lab in (('dbgg', 'DBGG conceito Bacen'), ('dlsp', 'DLSP')):
            linha(f'{k}_inicio', i0[k][1], i0[k][0], f'{lab}, saldo em dez/{a0}.')
            linha(f'{k}_fim', i1[k][1], i1[k][0], f'{lab}, saldo em dez/{a1}.')
            pc, rs = delta(k); linha(f'{k}_variacao', pc, rs, f'{lab}, variacao no mandato (pontos de PIB; R$ mi).')
        pc_b, rs_b = delta('dbgg'); pc_l, rs_l = delta('dlsp')
        linha('dlsp_menos_dbgg_variacao', pc_l - pc_b, rs_l - rs_b, 'Quanto a liquida andou alem da bruta = soma das linhas ponte_*.')
        Y0, Y1 = PIB[a0][0], PIB[a1][0]
        linha('pib_12m_inicio', None, Y0, f'PIB 12 meses em dez/{a0} (edicao {rotulo_ed(PIB[a0][1])}).')
        linha('pib_12m_fim', None, Y1, f'PIB 12 meses em dez/{a1} (edicao {rotulo_ed(PIB[a1][1])}); crescimento nominal no mandato {100 * (Y1 / Y0 - 1):.1f}%.')
        g0 = i0['dbgg'][0] - i0['dlsp'][0]; g1 = i1['dbgg'][0] - i1['dlsp'][0]
        linha('ativos_liquidos_inicio', g0 / Y0 * 100, g0, f'DBGG menos DLSP em dez/{a0}: ativos liquidos que separam as duas (com sinal positivo).')
        linha('ativos_liquidos_fim', g1 / Y1 * 100, g1, f'DBGG menos DLSP em dez/{a1}.')
        linha('dlsp_menos_dbgg_efeito_fluxo_rs', -(g1 - g0) / Y1 * 100, -(g1 - g0),
              'Parte de dlsp_menos_dbgg_variacao devida a variacao em reais dos ativos liquidos, medida no PIB final: -(ativos_fim - ativos_inicio) / PIB_fim.')
        linha('dlsp_menos_dbgg_efeito_denominador_pib', -g0 * (1 / Y1 - 1 / Y0) * 100, None,
              'Parte de dlsp_menos_dbgg_variacao devida so ao crescimento do PIB nominal sobre o estoque inicial de ativos liquidos: -ativos_inicio x (1/PIB_fim - 1/PIB_inicio).')
        desc = {'gg_cred_bndes_e_ifo': 'Creditos do Tesouro a instituicoes financeiras oficiais (BNDES e hibridos). Positivo = ativo encolheu.',
                'gg_fat': 'Recursos do FAT na rede bancaria (ativo do GG).',
                'gg_fundos_programas': 'Aplicacoes em fundos e programas (fundos constitucionais etc.).',
                'gg_demais_ativos': 'Demais creditos do GG exceto conta unica (disponibilidades na rede, depositos a vista, estatais, outros, externos).',
                'bcb_base_monetaria': 'Base monetaria (passivo do BCB fora da DBGG).',
                'bcb_depositos': 'Depositos no BCB, inclusive compulsorios e, desde 2021, voluntarios remunerados (passivo fora da DBGG).',
                'bcb_demais': 'Creditos do BCB a instituicoes financeiras e demais contas.',
                'bcb_externo_reservas': 'Divida externa liquida do BCB (reservas internacionais). Negativo = ativo cresceu.',
                'estatais': 'Divida liquida das estatais (exceto Petrobras e Eletrobras).'}
        for k, d in desc.items():
            pc, rs = delta(k); linha(f'ponte_{k}', pc, rs, d)
        pc, rs = delta('ponte_total'); linha('ponte_total', pc, rs, 'Soma das linhas ponte_*; deve igualar dlsp_menos_dbgg_variacao.')
        memo = {'memo_conta_unica': 'Memo: conta unica do Tesouro no BCB (ativo do GG, negativo). Some na consolidacao; mexe na DBGG quando o Tesouro resgata divida com caixa.',
                'memo_compromissadas': 'Memo: compromissadas do BCB dentro da DBGG.',
                'memo_mob_mercado': 'Memo: divida mobiliaria do Tesouro em mercado dentro da DBGG.',
                'memo_dbgg_externa': 'Memo: divida externa do GG dentro da DBGG.',
                'memo_dbgg_subnacional_bancaria': 'Memo: divida bancaria de estados e municipios dentro da DBGG.',
                'memo_titulos_livres_bcb': 'Memo: titulos livres na carteira do BCB (fora da DBGG conceito Bacen).',
                'memo_equalizacao_cambial': 'Memo: equalizacao cambial (Lei 11.803/2008).',
                'memo_cred_bndes': 'Memo: creditos junto ao BNDES (parte de ponte_gg_cred_bndes_e_ifo).'}
        for k, d in memo.items():
            pc, rs = delta(k); linha(f'{k}_variacao', pc, rs, d)
        # fatores condicionantes somados no mandato (cada ano da edicao mais nova)
        anos = range(a0 + 1, a1 + 1)
        def soma_fat(serie):
            ms = [mais_nova(serie, a) for a in anos]
            if any(m is None for m in ms): return None, None, [a for a, m in zip(anos, ms) if m is None]
            pc = sum(m[1] for m in ms) if all(m[1] is not None for m in ms) else None
            rs = sum(m[0] for m in ms) if all(m[0] is not None for m in ms) else None
            return pc, rs, []
        def soma_rec(serie):
            """soma no mandato: R$ do fluxo de cada ano (edicao mais nova) e % PIB recalculado = R$ / PIB 12m mais novo do ano."""
            ms = {a: mais_nova(serie, a) for a in anos}
            falta = [a for a, m in ms.items() if m is None]
            if serie.endswith('efeito_crescimento_pib'):
                pc = sum(m[1] for m in ms.values() if m) if not falta else None
                return pc, None, falta
            ok_ = [a for a, m in ms.items() if m and m[0] is not None]
            rs = sum(ms[a][0] for a in ok_) if ok_ else None
            pc = sum(ms[a][0] / PIB[a][0] * 100 for a in ok_) if ok_ else None
            return pc, rs, falta
        for pre, var, lista, rot in (('dbgg_fat_', pc_b, FAT, 'DBGG'), ('dlsp_fat_', pc_l, DFAT, 'DLSP')):
            tot = 0.0; completo = True
            for f in lista:
                pc, rs, falta = soma_rec(pre + f)
                if f == 'efeito_crescimento_pib':
                    nt = f'Efeito crescimento do PIB sobre a {rot}, soma dos valores publicados ano a ano (cada edicao com o PIB da epoca).'
                else:
                    nt = f'Fator condicionante da {rot} somado no mandato: R$ = soma dos fluxos anuais; % PIB = soma de (fluxo do ano / PIB 12m mais novo do ano).'
                    if pc is not None: tot += pc
                if falta: nt += f' Sem fonte para {falta}: nao encontrado.'; completo = False
                linha(f'{pre[:4]}_fator_{f}', pc, rs, nt)
            if completo:
                linha(f'{pre[:4]}_fator_efeito_pib_mais_residuo', var - tot, None,
                      f'Variacao da razao {rot}/PIB no mandato menos a soma dos fatores (sem o efeito PIB): efeito do crescimento do PIB nominal '
                      'calculado por diferenca, com o PIB revisado; compare com a linha efeito_crescimento_pib publicada.')
        for f in DET:
            pc, rs, falta = soma_rec('dbgg_det_' + f)
            nt = 'Detalhamento da DBGG por instrumento (Tabela 20, ano fechado) somado no mandato; % PIB = fluxo / PIB 12m mais novo.'
            if falta: nt += f' Sem fonte para {falta}: nao encontrado; soma so dos anos com dado.'
            linha(f'dbgg_detalhe_{f}', pc, rs, nt)
        # ajustes patrimoniais e metodologicos da DLSP (fora do primario e dos juros), um por tipo
        T6_FALL = {'metodologico_interno': 'cambial_divida_interna', 'metodologico_externo': 'cambial_divida_externa',
                   'paridade_cesta_moedas': 'divida_externa_outros_ajustes', 'reconhecimento_dividas': 'reconhecimento_dividas',
                   'privatizacoes': 'privatizacoes'}
        for c in ('metodologico_interno', 'metodologico_externo', 'paridade_cesta_moedas', 'caixa_competencia',
                  'reconhecimento_dividas', 'privatizacoes'):
            rs = pc = 0.0; usou6 = []; falta = []
            for a in anos:
                m = mais_nova(f'dlspaj_total_{c}', a)
                if m is None and c in T6_FALL:
                    m = mais_nova(f'dlsp_fat_{T6_FALL[c]}', a); usou6.append(a) if m else None
                if m is None or m[0] is None: falta.append(a); continue
                rs += m[0]; pc += m[0] / PIB[a][0] * 100
            nt = f'Ajuste da DLSP, tipo {c}, somado no mandato (Tabela 8 / Quadro 9 do BCB, total do setor publico; % PIB = soma de fluxo/PIB do ano).'
            if usou6: nt += f' Anos {usou6} da Tabela 6 (sem a abertura por tipo; paridade inclui caixa-competencia).'
            if falta: nt += f' Sem fonte para {falta}: nao encontrado.'
            linha(f'dlsp_ajuste_{c}', pc, rs, nt)
        # devolucoes do BNDES, resultado do BCB, concessoes e dividendos
        itens = [('bndes_captacao_junto_ao_tesouro', 'Emprestimos do Tesouro ao BNDES (captacoes, pagina do BNDES): aumentam a DBGG e criam ativo de igual valor na DLSP.'),
                 ('bndes_captacao_junto_ao_tesouro_capitalizacao_petrobras', 'Captacao do BNDES junto ao Tesouro referente a capitalizacao da Petrobras (2010).'),
                 ('bndes_liquidacao_antecipada', 'Liquidacoes antecipadas do BNDES ao Tesouro (pagina do BNDES). ' + AFETA['bndes']),
                 ('bndes_devolucao_total', 'Devolucoes totais do BNDES (ordinarias + antecipadas).'),
                 ('bcb_resultado_recebido_pelo_tesouro', 'Resultado do BCB recebido pelo Tesouro, onde o RAD separa a fonte. ' + AFETA['bcb']),
                 ('rtn_1_4_1_concessoes_e_permissoes', 'Concessoes e permissoes (RTN): receita primaria. ' + AFETA['conc']),
                 ('rtn_1_4_2_dividendos_e_participacoes', 'Dividendos e participacoes (RTN): receita primaria.')]
        S_ = {}
        for serie, d in itens:
            pc, rs, _, vazios = soma_des(serie, anos)
            nt = d
            if vazios: nt += f' Anos sem valor na fonte: {vazios} (nao encontrado ou zero).'
            S_[serie] = (pc, rs, vazios)
            linha(f'soma_{serie}', pc, rs, nt)
        rs_b1 = i1['dbgg'][0]; rs_b0 = i0['dbgg'][0]
        A = S_['bndes_liquidacao_antecipada'][1]; B = S_['bcb_resultado_recebido_pelo_tesouro'][1]
        linha('dbgg_variacao_sem_bndes_antecipado', (rs_b1 + A) / Y1 * 100 - rs_b0 / Y0 * 100, rs_b1 + A - rs_b0,
              'Contrafactual simples: DBGG final somada as liquidacoes antecipadas do BNDES no mandato (o Tesouro diz que cada real devolvido reduz a DBGG '
              'no mesmo valor, RAD 2018 e ADR 2019); nao inclui os juros que esse estoque teria acumulado (o ADR 2019 estima esse efeito).')
        nb = [a for a in S_['bcb_resultado_recebido_pelo_tesouro'][2] if a >= 2019]
        linha('dbgg_variacao_sem_bndes_antecipado_e_sem_resultado_bcb', (rs_b1 + A + B) / Y1 * 100 - rs_b0 / Y0 * 100, rs_b1 + A + B - rs_b0,
              'Igual a linha anterior, somando tambem o resultado do BCB recebido pelo Tesouro (supoe uso integral para resgatar divida). '
              + (f'PARCIAL: resultado do BCB nao encontrado para {nb}.' if nb else '')
              + (' Antes de 2019 (Lei 11.803/2008) o resultado do BCB tambem ia ao Tesouro; valores nao levantados.' if a0 < 2019 else ''))

print('ok: J-dbgg-composicao.csv, J-dbgg-fatores.csv, J-dlsp-ativos.csv, J-dlsp-fatores-ajustes.csv, J-desestatizacao.csv, J-ponte-por-mandato.csv')

#!/usr/bin/env python3
# Fatores da variacao da divida bruta (BCB, R$ correntes) por ano e por mandato, com os juros nominais separados em
# reposicao da inflacao (IPCA do ano x saldo de dezembro anterior, aproximacao) e juro real (o resto).
# Identidade do BCB em R$: variacao = juros nominais + emissoes liquidas + cambio + outros ajustes da externa
# + reconhecimento de dividas + privatizacoes. O efeito do PIB so existe na razao em % do PIB.
# Entradas: J-dbgg-fatores.csv (BCB, Tabelas de estatisticas fiscais) e IPCA SIDRA 1737 (brutos/N/ibge/).
import csv, json, os
RAIZ = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
F = {}
for r in csv.DictReader(open(os.path.join(RAIZ, 'J-dbgg-fatores.csv'), newline='', encoding='utf-8')):
  if r['serie'].startswith('dbgg_fat_') and r['valor_rs_mi']:
    F.setdefault(r['serie'][9:], {})[int(r['ano'])] = float(r['valor_rs_mi'])
IPCA = {r['D3C']: float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json')))[1:]}
ipca_ano = lambda a: IPCA[f'{a}12'] / IPCA[f'{a - 1}12'] - 1
OUT = ['divida_externa_outros_ajustes', 'reconhecimento_dividas', 'privatizacoes']
anos = sorted(a for a in F['juros_nominais'] if a - 1 in F['saldo'])
linhas = []
for a in anos:
  inf = ipca_ano(a) * F['saldo'][a - 1]
  outros = sum(F[k][a] for k in OUT)
  soma = F['juros_nominais'][a] + F['emissoes_liquidas'][a] + F['ajuste_cambial'][a] + outros
  var = F['saldo'][a] - F['saldo'][a - 1]
  assert abs(soma - var) < 1.0, (a, soma, var)  # a identidade do BCB fecha em R$
  r25 = IPCA['202512'] / IPCA[f'{a}12']  # fluxo do ano em R$ de dez/2025 (aproximacao dez a dez, como no resto do relatorio)
  linhas.append(dict(periodo=str(a), r25=r25, n=1, variacao=var, juros_nominais=F['juros_nominais'][a], reposicao_inflacao=inf, juro_real=F['juros_nominais'][a] - inf,
                     emissoes_liquidas=F['emissoes_liquidas'][a], cambio=F['ajuste_cambial'][a], outros=outros, ipca_pct=100 * ipca_ano(a),
                     variacao_real=var - inf))
MAND = [('Lula 2 (2007-2010)', 2007, 2010), ('Dilma (2011-2015)', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016), ('Temer (2017-2018)', 2017, 2018),
        ('Bolsonaro (2019-2022)', 2019, 2022), ('Lula 3 (2023-2025)', 2023, 2025)]
COLS = ['variacao', 'variacao_real', 'juros_nominais', 'reposicao_inflacao', 'juro_real', 'emissoes_liquidas', 'cambio', 'outros']
por_ano = {int(l['periodo']): l for l in linhas}
for l in linhas: l.update({c + '_r25': l[c] * l['r25'] for c in COLS})
for nm, a0, a1 in MAND:
  m = dict(periodo=nm, n=a1 - a0 + 1, **{c: sum(por_ano[a][c] for a in range(a0, a1 + 1)) for c in COLS})
  m.update({c + '_r25': sum(por_ano[a][c] * por_ano[a]['r25'] for a in range(a0, a1 + 1)) for c in COLS})
  m['ipca_pct'] = 100 * (IPCA[f'{a1}12'] / IPCA[f'{a0 - 1}12'] - 1)
  linhas.append(m)
with open(os.path.join(RAIZ, 'J-dbgg-fatores-reais.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['periodo', 'n_anos'] + [c + '_rs_bi' for c in COLS] + [c + '_rs_bi_2025' for c in COLS] + [c + '_rs_bi_2025_por_ano' for c in COLS] + ['ipca_periodo_pct', 'fonte', 'nota'])
  for l in linhas:
    w.writerow([l['periodo'], l['n']] + [round(l[c] / 1000, 1) for c in COLS] + [round(l[c + '_r25'] / 1000, 1) for c in COLS]
               + [round(l[c + '_r25'] / 1000 / l['n'], 1) for c in COLS] + [round(l['ipca_pct'], 2),
               'BCB, Tabelas de estatisticas fiscais, fatores condicionantes da DBGG (J-dbgg-fatores.csv); IBGE SIDRA 1737',
               'reposicao_inflacao = IPCA do ano x saldo de dez anterior (aproximacao: ignora o fluxo dentro do ano); juro_real = juros nominais menos reposicao; variacao_real = variacao menos reposicao = juro_real + emissoes + cambio + outros (variacao do estoque descontada a inflacao); _rs_bi_2025 = fluxo de cada ano em R$ de dez/2025 pelo IPCA dez a dez, somado; outros = ajustes da divida externa, reconhecimento de dividas, privatizacoes'])
print('dbgg real ok', [(l['periodo'], round(l['juro_real'] / 1000), round(l['variacao'] / 1000)) for l in linhas[-6:]])

# Frente J: bruta (DBGG) contra liquida (DLSP), por mandato, 2006 a 2025

Pergunta: por que, de dez/2018 a dez/2022, a DBGG (conceito Bacen) caiu de 75,3% para 71,7% do PIB enquanto a DLSP subiu de 52,8% para 56,1%? E o mesmo quadro para cada mandato desde 2006, com ativos e vendas de ativos explicitos.

Regenerar (de fora desta pasta, com xlrd no PYTHONPATH):

    PYTHONPATH=<dir com xlrd> python3 brutos/J/build_J.py

O script e idempotente e grava seis CSV na raiz `gastos-publicos/`, todos com as colunas `serie, ano, valor_pct_pib, valor_rs_mi, fonte_url, edicao, nota`. O que nao tem fonte fica vazio com a nota "nao encontrado".

## Fontes (todas baixadas; URL, data UTC e sha256 em `downloads.tsv`)

| Pasta | O que e |
|---|---|
| `dl-AAAA01/`, `dl-AAAA12/` | BCB, Tabelas de estatisticas fiscais, edicoes de janeiro e dezembro 2007 a 2026 (`https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/AAAAMM_Tabelas_de_estatisticas_fiscais.xls[x]`), baixadas em 18/10/2026 |
| `../I/bcb-*` | Edicoes 200901 a 202501 (anos impares) e 202609, baixadas pela frente I. So leitura |
| `../I/ftp-Divggnp`, `../I/ftp-Dlspp` | BCB ftp/notaecon, series longas do governo geral e da DLSP, arquivos de 26/12/2018 |
| `dl-bndes-recursos-tesouro/` | BNDES, pagina "Recursos financeiros captados junto ao Tesouro Nacional" (captacoes 2008 a 2014, devolucoes 2009 a 2026), atualizacao de 14/10/2026 |
| `dl-tesouro-rad-AAAA/` | Tesouro, Relatorio Anual da Divida do ano AAAA (2019 so na versao em ingles, ADR; a pasta 2025 guarda o arquivo `RAD_2026.pdf`, que e o relatorio sobre 2025) |
| `dl-tesouro-rtn-serie-historica/` | Tesouro, RTN serie historica (Tabela 2.2: concessoes e dividendos) |
| `dl-bndes-desestatizacao/` | BNDES, paginas de historico do PND (so totais em US$ ate 2015; nao serviram para serie anual) |

Regra de safra: para cada serie e cada dezembro vale a edicao mais nova que traz aquele dezembro (coluna `edicao`). Os arquivos do ftp contam como safra posterior a 201812 e anterior a 201901, entao valem para 2006 a 2015 nas tabelas de estoque.

PIB: o `% PIB` dos estoques e recalculado como R$ / PIB 12 meses de dezembro da edicao mais nova que traz esse PIB. Sem isso, dez/2018 sai 76,5% (edicao 202001, PIB antes da revisao) em vez de 75,3%. A nota de cada linha diz o valor publicado e a edicao do PIB. Fluxos de fatores condicionantes ficam com o % publicado na edicao; na ponte por mandato os fluxos sao divididos pelo PIB mais novo de cada ano.

## O que cada arquivo mede

- **J-dbgg-composicao.csv**: estoque da DBGG conceito Bacen e suas linhas (Tabela "Divida liquida e bruta do Governo Geral", Tabela 17 nas edicoes recentes; Divggnp ate 2015). Mobiliaria do Tesouro em mercado, compromissadas do BCB, divida bancaria do GF, de estados e de municipios, divida externa por esfera. A DBGG conceito FMI so aparece nas edicoes mais novas.
- **J-dbgg-fatores.csv**: fatores condicionantes da DBGG, fluxo acumulado no ano (Tabela 19: emissoes liquidas, juros nominais, ajuste cambial, outros ajustes da divida externa, reconhecimento de dividas, privatizacoes, efeito do crescimento do PIB) e o detalhamento por instrumento (Tabela 20, `dbgg_det_*`, so ano fechado, edicao AAAA01 do ano seguinte, 2008 em diante). Inclui, para comparacao, os fatores da DLSP (Tabela 6, `dlsp_fat_*`).
- **J-dlsp-ativos.csv**: estoques do lado do ativo e a ponte da propria Tabela 17 (`gg_*`: conta unica, creditos junto ao BNDES e hibridos, FAT na rede bancaria, fundos e programas, titulos livres na carteira do BCB, equalizacao cambial) e a composicao da DLSP (`dlsp_*`, Tabelas 4, 4-A e 4-B ou Dlspp: por esfera, haveres da Uniao sobre estados, BNDES, FAT, base monetaria, compromissadas, depositos no BCB, divida externa liquida do BCB, que inclui as reservas). `bcb_resultado_*`: resultado do BCB no ano (Tabela "Operacoes cambiais", 2008 a 2020; a tabela deixou de sair apos a edicao 202101).
- **J-dlsp-fatores-ajustes.csv**: Tabela 8 / Quadro 9 (DLSP, fatores condicionantes por instrumento, ano fechado, 2008 em diante), colunas primario, juros, metodologico interno, metodologico externo, paridade da cesta de moedas, caixa-competencia, reconhecimento de dividas e privatizacoes, para o total, cada esfera e linhas escolhidas (BNDES, conta unica, haveres sobre estados, compromissadas, divida externa do BCB). Mais as linhas da Tabela 6 para 2006 e 2007. `dlspaj_gf_cred_bndes_primario` e o fluxo liquido Tesouro e BNDES medido pelo BCB (positivo = ativo encolheu).
- **J-desestatizacao.csv**: devolucoes do BNDES ao Tesouro por ano (ordinarias e liquidacoes antecipadas), captacoes do BNDES junto ao Tesouro, datas das parcelas antecipadas (RAD 2017, 2018, ADR 2019, RAD 2021), impacto acumulado na DBGG estimado pelo Tesouro (ADR 2019), resultado do BCB recebido pelo Tesouro (RAD 2020, 2022, 2025), privatizacoes medidas pelo BCB por esfera, alienacao de ativos 2025 (RAD), concessoes e dividendos do RTN. A nota de cada linha diz se afeta DBGG, DLSP e primario.
- **J-ponte-por-mandato.csv**: por mandato (Lula 2 2007-2010, Dilma 2011-2015, 2016, Temer 2017-2018, Bolsonaro 2019-2022, Lula 3 2023-2025; dezembro a dezembro), saldos e variacoes, a ponte, memorandos, fatores somados, ajustes da DLSP por tipo, somas de BNDES, BCB, concessoes e dividendos, e a variacao da DBGG sem as liquidacoes antecipadas do BNDES e sem o resultado do BCB.

## A ponte

Identidade da Tabela 17: DLSP = DBGG + creditos do GG + titulos livres na carteira do BCB + equalizacao cambial + divida liquida do BCB + estatais. Consolidando GG com BCB, a conta unica e os titulos livres se anulam (ativo de um, passivo do outro), e sobra:

DLSP = DBGG + (creditos do GG exceto conta unica) + (base monetaria + depositos no BCB + demais contas do BCB) + divida externa liquida do BCB (reservas) + estatais.

E essa forma que `ponte_*` decompoe; a identidade fecha em cada dezembro dentro de uma mesma edicao (o script avisa se nao fechar). `dlsp_menos_dbgg_efeito_denominador_pib` separa a parte que vem so do crescimento do PIB nominal sobre o estoque inicial de ativos liquidos.

## Quebras de conceito

- DBGG: metodologia de 2008 (nota de 27/02/2008); a serie comeca em dez/2006. Edicoes 200701 e 200801 usam a metodologia anterior e perdem para o ftp.
- DLSP e estatais: Petrobras (2009) e Eletrobras (2010) excluidas. O ftp de 2018 traz o historico refeito; edicoes anteriores a 2010 nao, e as linhas que vem delas dizem isso na nota (`dlsp_fat_*` de 2006 a 2008, por exemplo: o saldo de 2006 sai 44,0% contra 46,5% refeito).
- Composicao da DBGG de 2018 em diante: titulos em reais de nao residentes passam de divida interna (mobiliaria) para externa. Entre dez/2017 (edicao 201901) e dez/2018 (edicao 202001) a mobiliaria cai e a externa sobe sem fluxo; o total nao muda. Afeta o memo do mandato Temer.
- Equalizacao cambial (Lei 11.803/2008) zerada desde a Lei 13.820/2019.
- Depositos voluntarios remunerados no BCB existem desde 2021 e ficam fora da DBGG conceito Bacen (0,81% do PIB em dez/2022, 1,61% em dez/2025).
- Fatores de 2006 a 2013 vem de edicoes com o PIB anterior a revisao de 2015; o residuo aparece em `*_efeito_pib_mais_residuo`.

## Nao encontrado

- Reservas internacionais brutas: as tabelas fiscais so trazem a divida externa liquida do BCB.
- Detalhamento da DBGG por instrumento e Tabela 8 da DLSP para 2006 e 2007 (as edicoes 200701 e 200801 nao trazem ano fechado nesse formato).
- Resultado do BCB recebido pelo Tesouro em 2019 e 2021 (o RAD nao separa) e em 2023 e 2024 (o RAD junta com retorno de creditos de entes subnacionais). Antes de 2019: ver `bcb-tesouro-transferencias.csv` (transferido e coberto por exercicio, STN e DF BCB).
- Datas das liquidacoes antecipadas de 2015 e 2022.
- Receita anual do PND por operacao para 2006 a 2025 (o BNDES publica so totais em US$ ate 2015); valor da capitalizacao da Eletrobras e das vendas de subsidiarias da Petrobras (BR, TAG, NTS) em fonte primaria. Estas ultimas foram vendas da Petrobras, que esta fora da DBGG e da DLSP.
- O contrafactual "DBGG sem devolucoes do BNDES" soma o principal devolvido e nao os juros que ele teria acumulado; o ADR 2019 estima o efeito acumulado em 6,9% do PIB ate 2019.

## bcb-tesouro-transferencias.csv: resultado do BCB entre BCB e Tesouro, 2008 a 2025

Regenerar: `python3 -I brutos/J/build_bcb_tesouro.py` (valores transcritos no script com a pagina de cada um; o script confere a soma 2008-2018 com o texto da STN). PDFs, URL e data em `dl-bcb-tesouro/downloads.tsv`.

Colunas `ano, tipo, sentido, valor_rs_mi, forma, fonte_url, pagina_ou_tabela, nota`. R$ milhoes correntes. **Ano = exercicio do balanco do BCB** (soma dos dois semestres), nao o ano do pagamento: o 2o semestre e pago em marco do ano seguinte, e a data de liquidacao de cada semestre esta na nota.

- 2008 a 2018: STN, "Relacionamento entre o Tesouro Nacional e o Banco Central, Relatorio Especial 2019", Tabela 1 (p. 11-12), por semestre, equalizacao cambial e demais contas, principal mais atualizacao. Positivo foi pago em dinheiro na Conta Unica; negativo foi coberto com emissao direta de titulos ao BCB.
- 2019 a 2025: demonstracoes financeiras anuais do BCB (quadro de operacoes com o Governo Federal e quadro de resultados a transferir ou a cobrir). Equalizacao encerrada em 30/06/2019; depois disso a parte cambial vai para a reserva de resultado e o resultado negativo e coberto primeiro pela reserva, depois pelo patrimonio, so entao pelo Tesouro (2022 e 2023).
- `uso_na_dpmf`: so onde o RAD separa a fonte (2022, Tabela 1) ou permite a conta (2020, nota 9, derivado). 2023 a 2025 a fonte 400 mistura BCB com entes subnacionais. 2008 a 2019 nao encontrado.

Conferencia: o texto da STN (p. 27) diz que de 2008 a 2018 o BCB transferiu R$ 1.015,5 bi (709,2 equalizacao, 306,3 resultado positivo) e o Tesouro transferiu R$ 714,8 bi em titulos (695,4 equalizacao, 19,4 cobertura de resultado negativo). A soma da Tabela 1 por exercicio, incluindo o 2S2018 pago em 14/03/2019, da exatamente isso. Pelo ano de pagamento, o dinheiro entrado de 2008 a 2018 soma R$ 989,5 bi.

Cuidado ao ligar isso a DBGG: a mesma publicacao da STN (p. 19 e 21) diz que fluxos TN e BCB nao afetam a DLSP e que pagar DPF em mercado com caixa da Conta Unica, se o BCB enxugar a liquidez com compromissadas, so muda a composicao da DBGG sem reduzir o estoque. O efeito na DBGG depende do que o BCB faz com a liquidez, nao do recebimento em si (diferente da devolucao do BNDES, que vem de fora do governo geral e do BCB).

Divergencia conhecida: RAD 2020 fala em R$ 350,0 bi recebidos do BCB em 2020 (325,0 + 24,8); a DF BCB registra R$ 372,3 bi entrados na Conta Unica em 2020 (325,0 + 47,3, este incluindo o 2S2019 pago em marco e a remuneracao).

Ressalva sobre o efeito na DBGG (relatorio, v7): a STN (Relatorio Especial 2019, p. 19 e 21) diz que os fluxos BC e Tesouro nao afetam a DLSP e que pagar DPF em mercado com caixa da Conta Unica, quando o BCB enxuga a liquidez com compromissadas, so muda a composicao da DBGG. Por isso o relatorio nao soma o efeito do resultado do BC sobre a bruta; a coluna `dbgg_variacao_sem_bndes_antecipado_e_sem_resultado_bcb` do J-ponte-por-mandato.csv fica so como registro e saiu do texto.

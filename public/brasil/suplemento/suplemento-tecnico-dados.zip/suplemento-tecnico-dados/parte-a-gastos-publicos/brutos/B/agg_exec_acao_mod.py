import csv, io, zipfile, sys, glob, os, json
from collections import defaultdict
base=sys.argv[1]; out=sys.argv[2]
agg=defaultdict(lambda:[0.0]*4)
names={}
def num(s):
    s=s.strip()
    if not s: return 0.0
    return float(s.replace('.','').replace(',','.'))
for f in sorted(glob.glob(os.path.join(base,'20[2][456]*_Despesas.zip'))):
    y=os.path.basename(f)[:4]
    with zipfile.ZipFile(f) as z:
        n=z.namelist()[0]
        with z.open(n) as fh:
            r=csv.reader(io.TextIOWrapper(fh,encoding='latin1'),delimiter=';')
            h=next(r)
            for row in r:
                key=(y,row[1],row[9],row[11],row[13],row[17],row[35],row[39])
                a=agg[key]
                a[0]+=num(row[41]);a[1]+=num(row[42]);a[2]+=num(row[43]);a[3]+=num(row[46])
                names.setdefault(('acao',row[17]),row[18]);names.setdefault(('org',row[1]),row[2]);names.setdefault(('mod',row[39]),row[40]);names.setdefault(('uo',row[9]),row[10])
    print(f,len(agg),file=sys.stderr)
with open(out,'w',newline='') as o:
    w=csv.writer(o)
    w.writerow(['ano','org_sup','uo','funcao','subfuncao','acao','gnd','mod','empenhado','liquidado','pago','rp_pagos'])
    for k,v in agg.items(): w.writerow(list(k)+[round(x,2) for x in v])
json.dump({f'{a}|{b}':c for (a,b),c in names.items()},open(out+'.names.json','w'),ensure_ascii=False)

import csv,collections,os,sys
def load(y):
    rows=[]
    for r in csv.DictReader(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "siop", f"siop_{y}_org_gnd_rp_el_mod.csv"))):
        rows.append(dict(org=r['org'].rsplit('/',1)[1],gnd=r['gnd'].rsplit('/',1)[1],rp=r['rp'].rsplit('/',1)[1],el=r['el'].rsplit('/',1)[1],mod=r['mod'].rsplit('/',1)[1],v=[float(r[k]) for k in ('dot_ini','dot_atual','empenhado','liquidado','pago')]))
    return rows

E="https://www1.siop.planejamento.gov.br/sparql/"
O="$(cd "$(dirname "$0")" && pwd)/siop"
for y in "$@"; do
q="PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
SELECT ?org ?gnd ?rp ?el ?mod (SUM(?ini) AS ?dot_ini) (SUM(?atu) AS ?dot_atual) (SUM(?emp) AS ?empenhado) (SUM(?liq) AS ?liquidado) (SUM(?pag) AS ?pago)
FROM <http://orcamento.dados.gov.br/$y/>
WHERE { ?s a loa:ItemDespesa ; loa:temUnidadeOrcamentaria ?uo ; loa:temGND ?gnd ; loa:temResultadoPrimario ?rp ; loa:temElementoDespesa ?el ; loa:temModalidadeAplicacao ?mod ;
 loa:valorDotacaoInicial ?ini ; loa:valorLeiMaisCredito ?atu ; loa:valorEmpenhado ?emp ; loa:valorLiquidado ?liq ; loa:valorPago ?pag . ?uo loa:temOrgao ?org }
GROUP BY ?org ?gnd ?rp ?el ?mod"
curl -s -m 900 "$E" --data-urlencode "query=$q" -H "Accept: text/csv" -o $O/siop_${y}_org_gnd_rp_el_mod.csv
echo $y $(wc -l < $O/siop_${y}_org_gnd_rp_el_mod.csv)
done

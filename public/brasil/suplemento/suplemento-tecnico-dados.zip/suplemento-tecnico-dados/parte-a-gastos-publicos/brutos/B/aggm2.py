# Portal execucao mensal -> RP pagos e pago por orgao orcamentario (UO[:2]) e GND, por ano
import csv,sys,json,collections,zipfile,io,os,glob
d=sys.argv[1]; outp=sys.argv[2]; anos=sys.argv[3].split(',')
res=json.load(open(outp)) if os.path.exists(outp) else {}
def tipo(c,n):
    n=n.upper()
    t=c[4:6]
    if t=='71': return 'bancada'
    if t=='81': return 'relator'
    if t in ('50','60','70'): return 'comissao'
    if n.startswith('BANCADA'): return 'bancada'
    if 'RELATOR' in n: return 'relator'
    if n.startswith('COM') or 'COMISS' in n: return 'comissao'
    return 'individual'
def num(s): return float(s.replace(',','.')) if s else 0.0
for z in sorted(glob.glob(d+'/*_Despesas.zip')):
    p=os.path.basename(z)[:6]
    if p[:4] not in anos or p in res: continue
    acc=collections.defaultdict(lambda:[0.0]*6)
    with zipfile.ZipFile(z) as zf:
        with zf.open(zf.namelist()[0]) as fb:
            r=csv.reader(io.TextIOWrapper(fb,encoding='latin1'),delimiter=';'); next(r)
            for row in r:
                v=[num(x) for x in row[41:47]]
                for k in ('UOR|'+row[9][:2]+'000','GND|'+row[35],'UORGND|'+row[9][:2]+'000|'+row[35],('EMA|'+tipo(row[31],row[32])+'|'+row[31][:4]) if row[31] not in ('-1','') else None):
                    if k is None: continue
                    a=acc[k]
                    for i in range(6): a[i]+=v[i]
    res[p]=acc; json.dump(res,open(outp,'w')); print(p,flush=True)

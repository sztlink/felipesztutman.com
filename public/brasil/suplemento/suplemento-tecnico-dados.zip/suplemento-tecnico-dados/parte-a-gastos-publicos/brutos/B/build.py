import csv, json, collections, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from rd import load

BASE = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
BR = BASE + '/brutos/B'
SIOP_URL = 'https://www1.siop.planejamento.gov.br/sparql/ (grafo http://orcamento.dados.gov.br/{y}/)'
RREO7 = 'https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio={y}&nr_periodo=6&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%2007&co_esfera=U&id_ente=1'
PORTAL = 'https://portaldatransparencia.gov.br/download-de-dados/despesas-execucao (arquivos {y}01 a {y}12)'

upd = {}
for l in open(BR + '/siop/siop_data_atualizacao.txt'):
    y, d = l.split()[0], l.split()[1].strip('"')
    upd[int(y)] = d

# PIB (R$ milhoes correntes)
pib = {}
for r in json.load(open(BR + '/sidra_6784.json'))[1:]:
    pib[int(r['D3N'])] = float(r['V']) * 1e6
q = {}
for r in json.load(open(BR + '/sidra_1846.json'))[1:]:
    q[r['D3N']] = float(r['V']) * 1e6
for y in (2024, 2025):
    pib[y] = sum(v for k, v in q.items() if k.endswith(str(y)))
pib[2026] = q['3º trimestre 2025'] + q['4º trimestre 2025'] + q['1º trimestre 2026'] + q['2º trimestre 2026']
PIBSRC = {y: 'SIDRA 6784 v9808' for y in range(2019, 2024)}
PIBSRC.update({2024: 'SIDRA 1846 v585 soma 4 tri 2024', 2025: 'SIDRA 1846 v585 soma 4 tri 2025', 2026: 'SIDRA 1846 v585 soma 3T2025 a 2T2026 (proxy 12 meses)'})

names = {}
for y in (2025, 2026):
    for r in csv.DictReader(open(BR + f'/siop/siop_{y}_orgaos.csv')):
        names[r['org'].rsplit('/', 1)[1]] = r['label']
names['01000'] = 'Câmara dos Deputados'
names['72000'] = 'Encargos Previdenciários da União'


def poder(c):
    i = int(c[:2])
    if i <= 3: return 'Legislativo'
    if 10 <= i <= 17: return 'Judiciário'
    if c in ('34000', '59000'): return 'Ministério Público'
    if c == '29000': return 'Defensoria Pública'
    if c == '75000': return 'Dívida (operação especial)'
    if 71 <= i <= 74: return 'Operação especial sob supervisão da Fazenda'
    if c == '90000': return 'Reserva de contingência'
    return 'Executivo'

REFIN = ('76', '77')
STG = ['dotacao_inicial', 'dotacao_atualizada', 'empenhado', 'liquidado', 'pago_exercicio']
out = []


def row(ano, est, cat, sub, val, den, fonte, data, nota):
    out.append(dict(frente='B', ano=ano, estagio=est, categoria=cat, subcategoria=sub,
                    valor_brl=f'{val:.2f}', pct_total=f'{100*val/den:.4f}' if den else '',
                    pct_pib=f'{100*val/pib[ano]:.4f}', fonte_url=fonte, data_fonte=data, nota=nota))


FONTE_REF = ('143', '343', '1443', '3443')
_rf = {}
def refin(R, i, y):
    if i >= 2:
        return sum(r['v'][i] for r in R if r['gnd'] == '6' and r['el'] in REFIN)
    if y not in _rf:
        k = ('dot_ini', 'dot_atual')
        _rf[y] = [sum(float(r[c]) for r in csv.DictReader(open(BR + f'/siop/siop_{y}_gnd6_fonte.csv')) if r['fc'] in FONTE_REF) for c in k]
    return _rf[y][i]

def denom(R, i, y):
    return sum(r['v'][i] for r in R) - refin(R, i, y)

# RP pagos (RREO Anexo 7) por orgao dos outros poderes
R7MAP = {'Câmara dos Deputados': '01000', 'Senado Federal': '02000', 'Tribunal de Contas da União': '03000',
         'Supremo Tribunal Federal': '10000', 'Superior Tribunal de Justiça': '11000', 'Justiça Federal': '12000',
         'Justiça Militar': '13000', 'Justiça Eleitoral': '14000', 'Justiça do Trabalho': '15000',
         'Justiça do Distrito Federal e Territórios': '16000', 'Conselho Nacional de Justiça': '17000',
         'Ministério Público da União': '34000', 'Conselho Nacional do Ministério Público': '59000',
         'DEFENSORIA PÚBLICA': '29000', 'PODER EXECUTIVO': 'EXEC'}
RPCOLS = ('RestosAPagarProcessadosENaoProcessadosLiquidadosPagos', 'RestosAPagarNaoProcessadosPagos',
          'RestosAPagarProcessadosENaoProcessadosLiquidadosPagosIntra', 'RestosAPagarNaoProcessadosPagosIntra')


def rp_rreo(y):
    t = collections.defaultdict(float)
    for i in json.load(open(BR + f'/rreo/rreo_{y}_p6_anexo07.json'))['items']:
        if i['cod_conta'] in RPCOLS and i['conta'] in R7MAP:
            t[R7MAP[i['conta']]] += i['valor']
    return t

portal = json.load(open(BR + '/portal_exec_agregado.json')) if os.path.exists(BR + '/portal_exec_agregado.json') else {}


def portal_year(y):
    t = collections.defaultdict(lambda: [0.0] * 6)
    ms = [p for p in portal if p[:4] == str(y)]
    for p in ms:
        for k, v in portal[p].items():
            for i in range(6): t[k][i] += v[i]
    return t, len(ms)

# ---------- 1/2. por orgao 2025 e 2026
for y in (2025, 2026):
    R = load(y)
    data = upd[y][:10]
    by = collections.defaultdict(lambda: [0.0] * 5)
    for r in R:
        for i in range(5): by[r['org']][i] += r['v'][i]
    stages = [1, 3, 4] if y == 2025 else [0, 1, 2, 3, 4]
    for i in stages:
        den = denom(R, i, y)
        for c, v in sorted(by.items(), key=lambda x: -x[1][i]):
            nota = ''
            if c == '75000': nota = 'inclui refinanciamento (rolagem) da dívida; ver subcategorias'
            if c == '90000': nota = 'reserva não se executa; só dotação'
            row(y, STG[i], f'ORGAO: {names.get(c, c)}', f'{c} | {poder(c)}', v[i], den, SIOP_URL.format(y=y), data, nota)
        # dívida decomposta (todos os órgãos)
        juros = sum(r['v'][i] for r in R if r['gnd'] == '2')
        refin_ = refin(R, i, y)
        amort = sum(r['v'][i] for r in R if r['gnd'] == '6') - refin_
        pm = sum(r['v'][i] for r in R if r['gnd'] == '6' and r['el'] == '26')
        tot = sum(r['v'][i] for r in R)
        row(y, STG[i], 'ORGAO: DÍVIDA (todos os órgãos)', 'juros e encargos (GND 2)', juros, den, SIOP_URL.format(y=y), data, 'fato: soma SIOP GND 2')
        row(y, STG[i], 'ORGAO: DÍVIDA (todos os órgãos)', 'amortização efetiva (GND 6 menos refinanciamento)', amort, den, SIOP_URL.format(y=y), data, f'inclui elemento 26 obrigações de política monetária (R$ {pm/1e9:.1f} bi)')
        row(y, STG[i], 'ORGAO: DÍVIDA (todos os órgãos)', 'refinanciamento (rolagem paga com nova emissão)', refin_, den, SIOP_URL.format(y=y), data, ('dotação: fonte 1443/3443 (143/343 até 2022); execução: elementos 76/77' ) + '; pct sobre denominador sem refinanciamento')
        row(y, STG[i], 'ORGAO: TOTAL', 'total geral com refinanciamento', tot, den, SIOP_URL.format(y=y), data, 'pct_total > 100 porque o denominador exclui refinanciamento')
        row(y, STG[i], 'ORGAO: TOTAL', 'total sem refinanciamento (denominador de pct_total)', den, den, SIOP_URL.format(y=y), data, 'cálculo')
        row(y, STG[i], 'ORGAO: TOTAL', 'total sem dívida (sem GND 2 e GND 6)', tot - juros - refin_ - amort, den, SIOP_URL.format(y=y), data, 'cálculo')
    # pago com RP (2025)
    if y == 2025:
        rr = rp_rreo(y)
        pt, nm = portal_year(y)
        tot_rp = 0.0; vals = {}
        for c, v in by.items():
            if poder(c) == 'Executivo' or c in ('71000', '72000', '73000', '74000', '75000', '90000', '83000'):
                rp = pt.get('UOR|' + c, [0] * 6)[5] if nm == 12 else None
            else:
                rp = rr.get(c, 0.0)
            if rp is None: continue
            vals[c] = (v[4] + rp, rp)
        if vals:
            den = denom(R, 4, y) + sum(x[1] for x in vals.values())
            for c, (val, rp) in sorted(vals.items(), key=lambda x: -x[1][0]):
                src = (PORTAL.format(y=y) + ' + SIOP') if (poder(c) == 'Executivo' or int(c[:2]) >= 71) else (RREO7.format(y=y) + ' + SIOP')
                row(y, 'pago_total_com_rp', f'ORGAO: {names.get(c, c)}', f'{c} | {poder(c)}', val, den, src, data, f'cálculo: pago no exercício + RP pagos em {y} (R$ {rp/1e9:.2f} bi); pct sobre total sem refinanciamento')
            row(y, 'pago_total_com_rp', 'ORGAO: TOTAL', 'total sem refinanciamento (denominador de pct_total)', den, den, SIOP_URL.format(y=y) + ' + ' + RREO7.format(y=y), data, 'cálculo: pago no exercício sem refinanciamento + todos os RP pagos')
            exec_rp_portal = sum(pt.get('UOR|' + c, [0]*6)[5] for c in by if (poder(c) == 'Executivo' or int(c[:2]) >= 71 or c=='83000'))
            row(y, 'pago_total_com_rp', 'ORGAO: TOTAL', 'RP pagos no ano, conferência', sum(x[1] for x in vals.values()), den, RREO7.format(y=y), data,
                f'RREO Anexo 7 Executivo RP pagos = R$ {rr["EXEC"]/1e9:.2f} bi; Portal mensal soma Executivo = R$ {exec_rp_portal/1e9:.2f} bi')

    if y == 2026:
        pt, nm = portal_year(y)
        if nm:
            den = denom(R, 4, y)
            ms = sorted(p for p in portal if p[:4] == '2026')
            for c in sorted(by, key=lambda c: -pt.get('UOR|' + c, [0]*6)[5]):
                if not (poder(c) == 'Executivo' or int(c[:2]) >= 71): continue
                v = pt.get('UOR|' + c, [0]*6)[5]
                if v == 0: continue
                row(y, 'rp_pagos_no_ano_executivo', f'ORGAO: {names.get(c, c)}', f'{c} | {poder(c)}', v, den, PORTAL.format(y=y), '2026-01 a 2026-10 (arquivo de outubro gerado em 2026-10-10, mês parcial)',
                    f'restos a pagar de anos anteriores pagos em 2026, {nm} meses do Portal; somar ao pago_exercicio para obter o pago total; outros poderes sem dado mensal')

# ---------- 3. GND 2019-2026
GN = {'1': 'Pessoal e Encargos Sociais', '2': 'Juros e Encargos da Dívida', '3': 'Outras Despesas Correntes', '4': 'Investimentos',
      '5': 'Inversões Financeiras', '6': 'Amortização/Refinanciamento da Dívida', '9': 'Reserva de Contingência'}
for y in range(2019, 2027):
    R = load(y); data = upd[y][:10]
    for i in (0, 1, 2, 3, 4):
        den = denom(R, i, y)
        g = collections.defaultdict(float)
        for r in R: g[r['gnd']] += r['v'][i]
        for k in sorted(g):
            if k == '9' and i > 1: continue
            if g[k] == 0: continue
            row(y, STG[i], f'GND: {k} {GN.get(k, k)}', 'total do grupo', g[k], den, SIOP_URL.format(y=y), data,
                'inclui refinanciamento; pct sobre total sem refinanciamento' if k == '6' else ('2026 parcial até ' + data if y == 2026 else ''))
        ref = refin(R, i, y)
        pm = sum(r['v'][i] for r in R if r['gnd'] == '6' and r['el'] == '26')
        row(y, STG[i], 'GND: 6 Amortização/Refinanciamento da Dívida', 'refinanciamento (rolagem)', ref, den, SIOP_URL.format(y=y), data, 'rolagem paga com emissão de títulos; dotação por fonte 1443/3443 (143/343 até 2022), execução por elementos 76/77')
        row(y, STG[i], 'GND: 6 Amortização/Refinanciamento da Dívida', 'amortização efetiva (GND 6 menos refinanciamento)', g['6'] - ref, den, SIOP_URL.format(y=y), data, f'elemento 26 política monetária = R$ {pm/1e9:.2f} bi')
        row(y, STG[i], 'GND: TOTAL', 'total sem refinanciamento (denominador)', den, den, SIOP_URL.format(y=y), data, 'cálculo')
        row(y, STG[i], 'GND: TOTAL', 'total com refinanciamento', sum(g.values()), den, SIOP_URL.format(y=y), data, 'cálculo')
        intra = sum(r['v'][i] for r in R if r['mod'] == '91')
        row(y, STG[i], 'GND: TOTAL', 'das quais intraorçamentárias (modalidade 91, dupla contagem)', intra, den, SIOP_URL.format(y=y), data, 'contribuição patronal da União ao RPPS etc; já incluída nos grupos')

# ---------- 4. emendas
RPN = {'6': 'individuais (RP 6)', '7': 'bancada estadual (RP 7)', '8': 'comissão (RP 8)', '9': 'relator geral (RP 9)'}
for y in (2024, 2025, 2026):
    R = load(y); data = upd[y][:10]
    for i in (0, 1, 2, 3, 4):
        den = denom(R, i, y)
        e = collections.defaultdict(float)
        for r in R:
            if r['rp'] in RPN: e[r['rp']] += r['v'][i]
        for k in sorted(e):
            row(y, STG[i], f'EMENDAS: {RPN[k]}', 'orçamento do ano (sem RP de anos anteriores)', e[k], den, SIOP_URL.format(y=y), data, ('2026 parcial até ' + data) if y == 2026 else '')
        row(y, STG[i], 'EMENDAS: total RP 6 a 9', 'orçamento do ano', sum(e.values()), den, SIOP_URL.format(y=y), data, 'cálculo')
    pt, nm = portal_year(y)
    if nm:
        R2 = collections.defaultdict(float)
        for k, v in pt.items():
            if k.startswith('EMA|'):
                R2[k.split('|')[1]] += v[5]
        den = denom(R, 4, y)
        for k, v in sorted(R2.items()):
            row(y, 'rp_pagos_no_ano', f'EMENDAS: {k}', f'restos a pagar de emendas pagos em {y} (Executivo)', v, den, PORTAL.format(y=y), ('2026-01 a 2026-10 (outubro parcial, arquivo de 2026-10-10)' if y == 2026 else f'{y}-01 a {y}-12 (arquivos gerados em 2026-10-10)'),
                'Portal classifica por código do autor; inclui emendas de anos anteriores' + ('' if nm == 12 else f'; {nm} meses, outubro parcial'))

with open(BASE + '/B-uniao-por-orgao-e-gnd.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['frente', 'ano', 'estagio', 'categoria', 'subcategoria', 'valor_brl', 'pct_total', 'pct_pib', 'fonte_url', 'data_fonte', 'nota'])
    w.writeheader(); w.writerows(out)
print(len(out), 'linhas'); print({y: round(pib[y]/1e9, 1) for y in pib})

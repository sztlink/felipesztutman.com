# Frente X: risco-país e fatores externos

Pergunta: quanto da variação do juro longo brasileiro anda junto com fatores externos (juro real americano, VIX, dólar, spread de emergentes) e quanto anda junto com a expectativa fiscal do Focus?

Tudo aqui é **associação e robustez, classe B no máximo**. Nenhuma regressão desta frente identifica causalidade. O que sobra depois dos fatores externos é resíduo de regressão, **não é prêmio fiscal**.

## Como rodar

    bash brutos/X/baixa_X.sh          # rebaixa os brutos para brutos/X/dados/ (consulta original 19/10/2026)
    python3 -P brutos/X/build_X.py    # le dados/, ../R/DFII10.csv e ../../N-juro-real-mensal.csv

`-P` e não `-I`: pandas e scipy estão em `~/.local` e `-I` desliga o site do usuário.

Gera na raiz do dossiê:

| Arquivo | Conteúdo |
|---|---|
| `X-fatores-mensal.csv` | 2008-01 a 2026-10, uma linha por mês, com presidente, fontes, consulta e nota |
| `X-regressoes.csv` | coeficientes (tipo `coeficiente`), decomposição 2019-2022 contra 2023-2026 (`decomposicao`), testes de quebra (`teste_quebra`) e resumo da janela móvel (`janela_movel_resumo`) |
| `X-janela-movel-36m.csv` | coeficientes de regressões de 36 meses deslizando um mês (pedido do coordenador) |
| `X-comparacao-emergentes.csv` | juro nominal de 10 anos do Brasil contra 7 emergentes da OCDE, médias por mandato e diferença para a mediana |

## Fontes

URL e data de cada arquivo em `downloads.tsv`. Resumo:

- **EMBI+ Brasil:** Ipeadata, série `JPM366_EMBI366`, API odata4. Fonte JP Morgan, diária, pontos-base, de 29/04/1994 a **30/07/2024**. O metadado diz "EMBI + Risco-Brasil - INATIVA", `SERSTATUS = I`, atualizado em 02/08/2024, e "Série interrompida por descontinuidade de fornecimento de dados". No Ipeadata não há outra série com EMBI, JPM ou risco no nome (busca nos 7,7 MB de metadados de todas as séries). Por isso, **as regressões com EMBI vão de 2008-01 a 2024-07** e a janela Lula 3 do EMBI tem só 19 meses (2023-01 a 2024-07).
- **Metodologia do EMBI+:** documento do Ipea (`dados/embi_metodologia.doc`, salvo em 2015) para o qual o metadado aponta. O EMBI+ substituiu o EMBI em 1994. Mede a diferença entre o retorno dos títulos de dívida externa de emergentes e o de títulos semelhantes do Tesouro americano. Só entram países com risco pelo menos moderado pelas agências de rating, e títulos com no mínimo US$ 500 milhões e prazo de pelo menos 2,5 anos. Na época do documento o Brasil pesava cerca de 23% do índice. O documento é de 2015, então a composição que ele cita pode ter mudado até 2024. Ele não diz se houve mudança de metodologia depois.
- **FRED** (`fredgraph.csv?id=`): DGS10, VIXCLS, DTWEXBGS, BAMLEMCBPIOAS, DEXBZUS e, da OCDE, IRLTLT01MXM156N, IRLTLT01ZAM156N, IRLTLT01CLM156N, IRLTLT01PLM156N, IRLTLT01HUM156N e IRLTLT01USM156N. DFII10 é lido de `brutos/R/DFII10.csv`, sem cópia. Colômbia e Índia não existem no código pedido (IRLTLT01COM156N e IRLTLT01INM156N devolveram 404). Entram pelos códigos novos da OCDE, `COLIRLTLT01STM` e `INDIRLTLT01STM`. Brasil, Indonésia, Turquia e China também deram 404 nos dois formatos de código. Os 7 emergentes são os da frente M que existem no FRED.
- **Spread de corporativos emergentes (BAMLEMCBPIOAS):** a página do FRED avisa "Starting in April 2026, this series will only include 3 years of observations", e o CSV atual começa em 20/10/2023. O histórico vem de um snapshot do Internet Archive da tabela do próprio FRED, de 26/10/2024, que cobre de 31/12/1998 a 25/10/2024. Usa o arquivado até 19/10/2023 e o atual depois. Nos 266 dias em que os dois se sobrepõem, a diferença máxima é 0,0000. A ICE declara na série que os dados são para uso interno e que não podem ser redistribuídos sem autorização. O CSV traz só médias mensais derivadas. **Antes de publicar, decidir se essa coluna sai**.
- **Focus:** BCB Olinda, `ExpectativasMercadoAnuais`, indicadores "Dívida líquida do setor público" e "Resultado primário" (% do PIB; no primário, positivo = superávit, conferido pelas medianas de 2008, perto de +3,6). A coluna `baseCalculo = 0`, que a documentação do Olinda define como "expectativas mais recentes ... a partir do 30º dia anterior", é a usada. Medida mensal: média das medianas diárias do mês, para o **ano seguinte** (DataReferencia = ano do mês + 1). O curl com `--data-urlencode` devolveu 400, porque troca espaço por `+`; a URL tem que ir com `%20`.
- **Brasil:** `juro_real_10a` (NTN-B interpolada em 10 anos) e `prefixado_10a` (NTN-F interpolada), de `N-juro-real-mensal.csv`. Metodologia em `brutos/N/LEIAME.md`.

## Método

- **Mensal:** séries diárias viram a média simples das observações do mês. As da OCDE já vêm mensais. Out/2026 é parcial: TD, DGS10 e DFII10 até 15/10; VIX e OAS até 16/10; DTWEXBGS e DEXBZUS até 09/10; Focus até 16/10; a OCDE ainda não tem outubro.
- **Presidente:** Lula 2 até 2010, Dilma até abr/2016, `Dilma/Temer` em mai/2016 (Dilma até 12/05), Temer até 2018, Bolsonaro de 2019 a 2022, Lula 3 desde 2023. Na comparação por mandato, mai/2016 fica fora dos dois.
- **Mediana de emergentes:** `em10_mediana_5` é a mediana mensal de África do Sul, Colômbia, Chile, Polônia e Hungria. São os 5 completos desde 2008, o que mantém a composição fixa, e é a mediana usada na regressão. O México fica fora porque tem 62 meses vazios desde 2008 na própria fonte, e a Índia porque só começa em 2011-12. `em10_mediana_disp` é a mediana dos 7 que tiverem dado no mês (mínimo 5), usada na comparação.
- **OLS e Newey-West em numpy:** statsmodels não está instalado na máquina de origem. Os coeficientes saem por OLS. A covariância é HAC de Newey-West com kernel de Bartlett, `lags = floor(4 (n/100)^(2/9))` (4 lags com n de 199 a 226, 3 lags nas janelas de 36 meses) e correção n/(n-k). Os p-valores usam a normal, como o default do statsmodels para HAC. A coluna `ep_hac_lags12` dá o erro padrão com 12 lags, para checar a sensibilidade da inferência à persistência. A coluna `rho_residuo` traz a autocorrelação de 1ª ordem do resíduo.
- **Especificações**, para cada dependente (juro real 10a do Brasil e EMBI+):
  - (a) `a_niveis`: DFII10, VIX, dólar amplo e OAS de emergentes;
  - (b) `b_niveis`: (a) mais as medianas Focus de DLSP e de primário para o ano seguinte;
  - (c), sobre (a) e sobre (b):
    - primeiras diferenças (`_c_dif`);
    - 2008-2015 e 2016-2026;
    - sem 2020;
    - mediana de 10 anos de emergentes no lugar do DFII10 (`_c_em10`);
    - DGS10 no lugar do DFII10 (`_c_dgs10`);
    - quatro regimes monetários, a pedido do coordenador (`_c_regime1` a `_c_regime4`: 2008-2012; 2013-2016, alta da Selic; 2017-2020, Selic baixa; 2021-2026, alta da Selic e autonomia do BC pela LC 179).
- **Decomposição:** delta = média 2023-2026 (Lula 3) menos média 2019-2022 (Bolsonaro), nos meses com todas as variáveis. A contribuição de cada regressor é coeficiente × variação da média dele. "Fatores externos" é a soma de DFII10 (ou do substituto), VIX, dólar e OAS. O que sobra é "não explicado pelos regressores", e não tem nome de prêmio fiscal. Nas primeiras diferenças, o coeficiente vai aplicado à variação das médias em nível, e a deriva fica no não explicado. Os coeficientes de 2008-2015 entram fora da amostra, e isso está marcado. Os regimes não têm decomposição.
- **Quebra:** teste de Wald com covariância Newey-West das interações regime × regressores, ou seja, um Chow robusto a autocorrelação. Ele é feito nos 3 limites de regime juntos e em quebras únicas em 2013-01, 2016-01, 2017-01 e 2021-01.
- **Robustez de sinal:** `sinal_igual_ao_base` e `razao_coef_base` comparam cada coeficiente com o da especificação base. `n_espec_signif_mesmo_sinal` conta em quantas especificações o coeficiente é significante, e com que sinal. `so_nesta_especificacao = sim` marca o resultado significante que só aparece numa especificação.

## Resultados (gerados por build_X.py em 19/10/2026)

Juro real 10a do Brasil, Bolsonaro 4,19% contra Lula 3 6,69%, delta de +2,50 p.p. (2023-01 a 2026-10):

| Especificação | DFII10 (t) | Fração do delta associada aos externos | Focus | Não explicado |
|---|---|---|---|---|
| a níveis (R² 0,61) | 1,09 (8,3) | 84% | | 16% |
| b níveis (R² 0,63) | 1,07 (5,5) | 90% | -5% | 15% |
| a primeiras diferenças (R² 0,28) | 0,39 (2,8) | 25% | | 75% |
| b primeiras diferenças | 0,40 (3,0) | 26% | +5% | 69% |
| a 2016-2026 / b 2016-2026 | 1,02 / 0,86 | 82% / 73% | / +6% | 18% / 21% |
| a sem 2020 / b sem 2020 | 0,96 / 0,97 | 78% / 90% | / -10% | 22% / 20% |
| a emergentes no lugar do DFII10 / b | 0,49 / 0,37 (coef. da mediana EM) | 43% / 45% | / +4% | 57% / 51% |
| a DGS10 no lugar do DFII10 / b | 0,99 / 1,13 | 81% / 100% | / -16% | 19% / 16% |
| a 2008-2015 / b, fora da amostra | 1,26 / 1,18 | 117% / 101% | / +5% | -17% / -6% |

EMBI+, Bolsonaro 292 pb contra 223 pb em 2023-01 a 2024-07, delta de -69 pb:

| Especificação | Fração associada aos externos | Focus | Não explicado |
|---|---|---|---|
| a níveis / b níveis | 59% / 39% | / 33% | 41% / 29% |
| primeiras diferenças (a / b) | 39% / 38% | / -3% | 61% / 65% |
| 2016-2026 (a / b) | 107% / 113% | / 0% | -7% / -13% |
| sem 2020 (a / b) | 55% / 32% | / 35% | 45% / 33% |
| emergentes no lugar do DFII10 (a / b) | 63% / 35% | / 32% | 37% / 33% |

Leitura:

- **A fração explicada depende da especificação.** No juro real ela vai de 25% (diferenças) a 90% e 100% (níveis). Em níveis, a variável dependente e os regressores são muito persistentes, com `rho_residuo` de 0,92 a 0,97. Isso pode dar correlação espúria por tendência comum. O de diferenças mede o co-movimento mês a mês. As duas são especificações alternativas com vieses potencialmente diferentes, e não limites superior e inferior (correção pela 5ª auditoria, 19/10/2026). Com a janela 2019-2026, a fração vai de 1% a 94%: o resultado informativo é que estes modelos não identificam a contribuição externa.
- **DFII10 é o único regressor com sinal estável no juro real:** positivo e significante em 16 de 18 especificações, nenhuma negativa. Mas a magnitude muda por regime:
  - 1,16 em 2008-2012;
  - 1,82 em 2013-2016;
  - 1,19 em 2017-2020;
  - **0,34 em 2021-2026** (t 1,96), e -0,06 (t -0,4) quando entra o Focus.
  Na janela móvel de 36 meses, o coeficiente é positivo em 79% das janelas e troca de sinal 8 vezes. A associação com o juro real americano enfraqueceu justamente no período da comparação.
- **Expectativa fiscal do Focus e juro real:** nada significante na amostra inteira, nem em níveis (DLSP -0,03, primário +0,06) nem em diferenças. Nos regimes, o sinal troca: o primário dá +0,59 em 2008-2012, -1,00 em 2017-2020 e +1,13 em 2021-2026. Um primário esperado maior associado a juro real maior é o oposto do que a hipótese fiscal prevê, o que indica endogeneidade ou fator omitido.
- **Expectativa fiscal e EMBI:** o primário esperado entra negativo e significante em níveis (-26,6 pb por p.p. do PIB, t -3,8) e em 7 de 11 especificações. **Não aparece em primeiras diferenças** (-3,6, t -0,5) e troca de sinal em 2008-2012 (+42,6) e em 2021-2024 (+25,9). A DLSP esperada entra com sinal negativo (-4,2 pb por p.p.), contrário ao esperado, e colinear com o primário.
- **No EMBI, o regressor estável é o OAS de corporativos emergentes:** positivo em 100% das janelas de 36 meses e significante positivo em 20 de 22 especificações. O DFII10 troca de sinal entre regimes no EMBI: +13 em 2008-2012, +25 em 2013-2016, **-50 em 2021-2024**.
- **Resultados que só aparecem numa especificação**, marcados `so_nesta_especificacao`:
  - juro real: VIX negativo (só no regime 2017-2020), OAS negativo (só no regime 2021-2026) e primário negativo (só no regime 2017-2020);
  - EMBI: mediana de emergentes negativa, DGS10 negativo e DLSP positivo (só no regime 2008-2012).
- **Quebras:** o Wald HAC rejeita coeficientes iguais entre os regimes em todos os casos (p < 0,001), exceto a quebra única de 2016-01 no juro real com Focus (p = 0,051). Com resíduos tão persistentes, o Wald com 4 lags tende a rejeitar demais. A conclusão segura é qualitativa: a relação muda de magnitude e, em vários regressores, de sinal. Os pontos exatos de quebra não ficam estabelecidos.

## Comparação com emergentes (juro nominal de 10 anos)

Brasil (prefixado 10a do TD) menos a mediana mensal dos emergentes da OCDE, em p.p.:

| Mandato | Diferença |
|---|---|
| Lula 2 | 5,4 |
| Dilma | 5,6 |
| Temer | 4,4 |
| Bolsonaro | 2,9 |
| Lula 3 | 5,8 |

Os valores de cada país estão no CSV. É juro nominal: países com inflação diferente não são diretamente comparáveis.

## Limitações declaradas

1. **O EMBI+ não mede o prêmio fiscal do título em reais.** É spread soberano em dólar sobre Treasuries, que mistura risco de crédito, liquidez e apetite global por risco. Não tem risco cambial nem inflação local. Não é usado aqui como proxy direta do prêmio do juro local, e a nota de cada linha do CSV mensal diz isso. Ele ainda acaba em 30/07/2024.
2. **As séries da OCDE usam definições nacionais.** O metadado da OCDE (`dados/oecd_finmark_irlt_2026.csv`) marca `METHODOLOGY = N (National)` nas 7 séries. Prazo, título de referência e método de média variam por país. O metadado baixado confirma a frequência mensal, mas não diz em cada país se o valor é média do mês ou fim do período. O Brasil não está na base da OCDE no FRED, e o lado brasileiro é a NTN-F interpolada da frente N, que é um instrumento e um método diferentes.
3. **A expectativa fiscal do Focus é endógena.** As medianas reagem ao próprio juro, ao câmbio e à atividade, e os analistas revisam a DLSP esperada com a taxa de juros (juro maior aumenta a dívida projetada). O coeficiente do Focus não separa expectativa fiscal causando juro de juro causando expectativa. DLSP e primário esperados também são colineares.
4. **Regressões em nível com séries persistentes podem ser espúrias.** As primeiras diferenças, a janela móvel e os regimes existem para mostrar quanto o resultado depende disso.
5. **O OAS de emergentes até 19/10/2023 vem do Internet Archive** e tem restrição de licença da ICE (ver Fontes).
6. **México com 62 meses vazios na fonte; Índia só desde 2011-12; Hungria até 2026-08.**
7. **A janela pós do EMBI tem 19 meses**, e a do juro real 46 (2026-10 parcial).

## Acréscimos de 19/10/2026 (auditoria v10, F1 e F2)

As linhas antigas não mudaram. Os blocos novos foram acrescentados no fim de cada arquivo, e o md5 das linhas anteriores confere com o da versão anterior.

- **Janela 2019-2026 (`j2019_*` em X-regressoes.csv):** os coeficientes são estimados só na janela da comparação, em níveis de 2019-01 a 2026-10 e em diferenças de 2019-02 a 2026-10. O EMBI vai até 2024-07. Essas linhas não entram na contagem de robustez de sinal das especificações antigas. Frações do delta associadas aos externos:

  | Especificação | Juro real 10a | EMBI |
  |---|---|---|
  | níveis | 94% | 109% |
  | diferenças | 4% | 61% |
  | níveis com Focus | 21% (Focus 76%) | 133% (Focus -35%) |
  | diferenças com Focus | 1% (Focus 17%) | 56% (Focus -15%) |

  Os 76% do Focus no juro real em níveis vêm de DLSP esperada (+0,20 por p.p.) e de primário esperado (+1,25 por p.p.). O sinal do primário é o oposto do que a hipótese fiscal prevê (primário esperado melhor junto com juro maior), e o OAS de emergentes entra negativo em j2019_niveis (-1,16). Com 94 meses e regressores colineares, a partilha entre externos e Focus nessa janela é instável e não serve como medida de prêmio fiscal.
- **X-variacoes.csv:** descrição direta, sem modelo, em médias mensais.

  | Período | Juro real 10a Brasil | DFII10 | Diferença Brasil menos DFII10 |
  |---|---|---|---|
  | dez/2018 a dez/2022 | +1,42 p.p. | +0,34 p.p. | +1,08 p.p. |
  | dez/2022 a out/2026 (out parcial) | +0,77 p.p. | +1,53 p.p. | -0,76 p.p. |
- **Mediana fixa de 5 países em X-comparacao-emergentes.csv** (ZA CO CL PL HU, só meses com os 5). Brasil menos ela, em p.p.:

  | Mandato | Diferença |
  |---|---|
  | Lula 2 | 5,3 |
  | Dilma | 6,3 |
  | Temer | 6,4 |
  | Bolsonaro | 4,7 |
  | Lula 3 | 6,0 |

  Com a mediana de composição variável, a diferença de Bolsonaro era 2,9: o número depende de quais países entram.

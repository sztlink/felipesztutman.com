#!/usr/bin/env python3
# Frente X: risco-pais e fatores externos do juro brasileiro de 10 anos.
# Le brutos/X/dados/ (baixados por baixa_X.sh em 2026-10-19), brutos/R/DFII10.csv e N-juro-real-mensal.csv.
# Gera na raiz do dossie: X-fatores-mensal.csv, X-regressoes.csv, X-janela-movel-36m.csv, X-comparacao-emergentes.csv.
# Regressoes sao ASSOCIACAO e robustez (classe B no maximo), nunca causalidade.
# statsmodels nao esta instalado na máquina de origem: OLS e Newey-West implementados em numpy (ver LEIAME, secao Metodo).
# Rodar: python3 -P brutos/X/build_X.py
import csv, json, math, os, re
import numpy as np
import pandas as pd
from scipy import stats

AQUI = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(AQUI, 'dados')
RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..'))
CONSULTA = '2026-10-19'
MESES = pd.period_range('2008-01', '2026-10', freq='M')

# ---------------------------------------------------------------- leitura
def fred(path, col=None):
    df = pd.read_csv(path)
    col = col or df.columns[1]
    s = pd.to_numeric(df[col], errors='coerce')
    s.index = pd.to_datetime(df['observation_date'])
    return s.dropna()

def mensal(s):
    """media simples das observacoes do mes"""
    return s.groupby(s.index.to_period('M')).mean()

def oecd(path):
    s = fred(path)
    s.index = s.index.to_period('M')
    return s

ser, ult = {}, {}
for nome, arq in [('dgs10', 'DGS10'), ('vix', 'VIXCLS'), ('dolar_amplo', 'DTWEXBGS'), ('brl_usd', 'DEXBZUS')]:
    s = fred(os.path.join(D, arq + '.csv'))
    ser[nome] = mensal(s); ult[nome] = s.index.max().date()
s = fred(os.path.join(AQUI, '..', 'R', 'DFII10.csv'))
ser['dfii10'] = mensal(s); ult['dfii10'] = s.index.max().date()

# ICE BofA EM Corporate Plus OAS: FRED atual (desde 2023-10-20) + Internet Archive (snapshot 2024-10-26, desde 1998-12-31)
t = open(os.path.join(D, 'wayback_20241026_BAMLEMCBPIOAS.html'), encoding='utf-8').read()
wb = {pd.Timestamp(d): v for d, v in re.findall(r'<th scope="row" class="pe-5">(\d{4}-\d{2}-\d{2})</th>\s*<td class="pe-5">\s*([^<]*?)\s*</td>', t)}
wb = pd.to_numeric(pd.Series(wb), errors='coerce').dropna().sort_index()
atual = fred(os.path.join(D, 'BAMLEMCBPIOAS.csv'))
sobre = pd.concat([wb, atual], axis=1, join='inner').dropna()
OAS_DIF_MAX = float((sobre.iloc[:, 0] - sobre.iloc[:, 1]).abs().max()) if len(sobre) else float('nan')
OAS_N_SOBRE = len(sobre)
oas = pd.concat([wb[wb.index < atual.index.min()], atual]).sort_index()
ser['em_oas'] = mensal(oas); ult['em_oas'] = oas.index.max().date()

# EMBI+ Brasil, Ipeadata JPM366_EMBI366 (pontos-base, diario)
v = json.load(open(os.path.join(D, 'ipeadata_JPM366_EMBI366.json'), encoding='utf-8'))['value']
embi = pd.Series({pd.Timestamp(r['VALDATA'][:10]): r['VALVALOR'] for r in v if r['VALVALOR'] is not None}).sort_index()
ser['embi_br_pb'] = mensal(embi); ult['embi_br_pb'] = embi.index.max().date()

# Juros longos de emergentes, OCDE via FRED (mensal)
EM = [('mx', 'Mexico', 'IRLTLT01MXM156N'), ('za', 'Africa do Sul', 'IRLTLT01ZAM156N'), ('co', 'Colombia', 'COLIRLTLT01STM'),
      ('cl', 'Chile', 'IRLTLT01CLM156N'), ('in', 'India', 'INDIRLTLT01STM'), ('pl', 'Polonia', 'IRLTLT01PLM156N'),
      ('hu', 'Hungria', 'IRLTLT01HUM156N')]
for k, _, sid in EM + [('us', 'Estados Unidos', 'IRLTLT01USM156N')]:
    ser[k + '10'] = oecd(os.path.join(D, sid + '.csv'))
    ult[k + '10'] = ser[k + '10'].index.max()

# Focus: mediana para o ano seguinte, base de calculo 0 (expectativas dos ultimos 30 dias), media das datas do mes
def focus(arq):
    v = json.load(open(os.path.join(D, arq), encoding='utf-8'))['value']
    f = pd.DataFrame(v)
    f = f[f['baseCalculo'] == 0].copy()
    f['mes'] = pd.PeriodIndex(f['Data'].str[:7], freq='M')
    f = f[f['DataReferencia'].astype(int) == f['mes'].dt.year + 1]
    return f.groupby('mes')['Mediana'].mean(), f['Data'].max()
ser['focus_dlsp_t1'], ult['focus_dlsp_t1'] = focus('focus_dlsp.json')
ser['focus_primario_t1'], ult['focus_primario_t1'] = focus('focus_primario.json')

# Brasil, juro real e prefixado de 10 anos (frente N, Tesouro Direto)
n = pd.read_csv(os.path.join(RAIZ, 'N-juro-real-mensal.csv'))
n.index = pd.PeriodIndex(n['mes'], freq='M')
ser['juro_real_10a_br'] = pd.to_numeric(n['juro_real_10a'], errors='coerce')
ser['prefixado_10a_br'] = pd.to_numeric(n['prefixado_10a'], errors='coerce')

X = pd.DataFrame({k: s.reindex(MESES) for k, s in ser.items()}, index=MESES)
EM5 = ['za10', 'co10', 'cl10', 'pl10', 'hu10']   # composicao fixa e completa desde 2008 (Mexico tem 62 meses vazios na fonte, India so desde 2011-12)
EM7 = ['mx10'] + EM5 + ['in10']
X['em10_mediana_5'] = X[EM5].median(axis=1).where(X[EM5].notna().all(axis=1))
X['em10_mediana_disp'] = X[EM7].median(axis=1).where(X[EM7].notna().sum(axis=1) >= 5)
X['em10_n_paises'] = X[EM7].notna().sum(axis=1)

def presidente(p):
    y, m = p.year, p.month
    if y <= 2010: return 'Lula 2'
    if (y, m) < (2016, 5): return 'Dilma'
    if (y, m) == (2016, 5): return 'Dilma/Temer'
    if y <= 2018: return 'Temer'
    if y <= 2022: return 'Bolsonaro'
    return 'Lula 3'
X['presidente'] = [presidente(p) for p in X.index]

# ---------------------------------------------------------------- X-fatores-mensal.csv
FONTES = ('Ipeadata JPM366_EMBI366; FRED DGS10, DFII10 (brutos/R), VIXCLS, DTWEXBGS, BAMLEMCBPIOAS (ate 2023-10-19 via Internet Archive), '
          'DEXBZUS, IRLTLT01MXM156N, IRLTLT01ZAM156N, COLIRLTLT01STM, IRLTLT01CLM156N, INDIRLTLT01STM, IRLTLT01PLM156N, '
          'IRLTLT01HUM156N, IRLTLT01USM156N; BCB Olinda ExpectativasMercadoAnuais; N-juro-real-mensal.csv. URLs em brutos/X/downloads.tsv')
COLS = ['juro_real_10a_br', 'prefixado_10a_br', 'embi_br_pb', 'dgs10', 'dfii10', 'vix', 'dolar_amplo', 'em_oas', 'brl_usd',
        'mx10', 'za10', 'co10', 'cl10', 'in10', 'pl10', 'hu10', 'us10', 'em10_mediana_5', 'em10_mediana_disp', 'em10_n_paises',
        'focus_dlsp_t1', 'focus_primario_t1']
with open(os.path.join(RAIZ, 'X-fatores-mensal.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['mes', 'presidente'] + COLS + ['fontes', 'consulta', 'nota'])
    for p, r in X.iterrows():
        nota = []
        if p < pd.Period('2023-10', 'M'): nota.append('em_oas de snapshot do Internet Archive de 26/10/2024 (FRED so mostra 3 anos desde abr/2026)')
        if p == pd.Period('2023-10', 'M'): nota.append('em_oas emenda Internet Archive ate 19/10 e FRED atual desde 20/10')
        if p > pd.Period('2024-07', 'M'): nota.append('EMBI+ Brasil sem dado: serie JPM366_EMBI366 encerrada em 30/07/2024 (inativa no Ipeadata)')
        if p == pd.Period('2024-07', 'M'): nota.append('ultimo mes do EMBI+ (dados ate 30/07/2024)')
        if p == pd.Period('2016-05', 'M'): nota.append('mes de transicao: Dilma ate 12/05/2016')
        if p == pd.Period('2026-10', 'M'):
            nota.append('mes parcial: TD ate 15/10, DGS10 e DFII10 ate 15/10, VIX e OAS ate 16/10, DTWEXBGS e DEXBZUS ate 09/10, Focus ate 16/10; OCDE sem outubro')
        if pd.isna(r['in10']) and p < pd.Period('2011-12', 'M'): nota.append('India (INDIRLTLT01STM) so desde 2011-12')
        nota.append('EMBI+ e spread em dolar sobre Treasuries (credito, liquidez e apetite global), nao e premio fiscal do juro local em reais')
        w.writerow([str(p), r['presidente']] + ['' if pd.isna(r[c]) else (int(r[c]) if c == 'em10_n_paises' else round(float(r[c]), 4)) for c in COLS]
                   + [FONTES, CONSULTA, '; '.join(nota)])

# ---------------------------------------------------------------- OLS com Newey-West
def nw_lags(n):
    return int(math.floor(4 * (n / 100.0) ** (2.0 / 9.0)))

def ols_nw(y, Xm, L):
    n, k = Xm.shape
    XtXi = np.linalg.inv(Xm.T @ Xm)
    b = XtXi @ Xm.T @ y
    e = y - Xm @ b
    u = Xm * e[:, None]
    S = u.T @ u
    for l in range(1, L + 1):
        G = u[l:].T @ u[:-l]
        S += (1 - l / (L + 1.0)) * (G + G.T)
    V = XtXi @ S @ XtXi * n / (n - k)
    r2 = 1 - (e @ e) / np.sum((y - y.mean()) ** 2)
    return b, V, r2, 1 - (1 - r2) * (n - 1) / (n - k), e

EXT = ['dfii10', 'vix', 'dolar_amplo', 'em_oas']
FOC = ['focus_dlsp_t1', 'focus_primario_t1']
DEPS = [('juro_real_10a_br', 'juro real 10 anos Brasil (NTN-B interpolada, % a.a.)'),
        ('embi_br_pb', 'EMBI+ Brasil (pontos-base, spread soberano em dolar)')]
REGIMES = [('2008-01', '2012-12', 'regime 2008-2012'), ('2013-01', '2016-12', 'regime 2013-2016 (alta da Selic)'),
           ('2017-01', '2020-12', 'regime 2017-2020 (Selic baixa)'), ('2021-01', '2026-12', 'regime 2021-2026 (alta da Selic e autonomia do BC, LC 179)')]

def specs():
    out = []
    for g, regs, gdesc in [('a', EXT, 'so fatores externos'), ('b', EXT + FOC, 'externos + expectativa fiscal Focus')]:
        out.append(dict(id=f'{g}_niveis', grupo=g, desc=f'{gdesc}, niveis, amostra inteira', regs=regs, dif=False))
        out.append(dict(id=f'{g}_c_dif', grupo='c', base=g, desc=f'{gdesc}, primeiras diferencas', regs=regs, dif=True))
        out.append(dict(id=f'{g}_c_2008_2015', grupo='c', base=g, desc=f'{gdesc}, subperiodo 2008-2015', regs=regs, dif=False, ini='2008-01', fim='2015-12'))
        out.append(dict(id=f'{g}_c_2016_2026', grupo='c', base=g, desc=f'{gdesc}, subperiodo 2016-2026', regs=regs, dif=False, ini='2016-01', fim='2026-12'))
        out.append(dict(id=f'{g}_c_sem_2020', grupo='c', base=g, desc=f'{gdesc}, excluindo 2020', regs=regs, dif=False, excl=[2020]))
        out.append(dict(id=f'{g}_c_em10', grupo='c', base=g, desc=f'{gdesc}, mediana do juro nominal 10a de 5 emergentes OCDE (ZA CO CL PL HU) no lugar do DFII10',
                        regs=['em10_mediana_5'] + regs[1:], dif=False))
        out.append(dict(id=f'{g}_c_dgs10', grupo='c', base=g, desc=f'{gdesc}, DGS10 (Treasury nominal) no lugar do DFII10',
                        regs=['dgs10'] + regs[1:], dif=False))
        for i, (a, z, rd) in enumerate(REGIMES, 1):
            out.append(dict(id=f'{g}_c_regime{i}', grupo='c', base=g, desc=f'{gdesc}, {rd}', regs=regs, dif=False, ini=a, fim=z, regime=True))
    return out

def amostra(dep, sp):
    cols = [dep] + sp['regs']
    df = X[cols].astype(float)
    if sp['dif']: df = df.diff()
    df = df.dropna()
    if 'ini' in sp: df = df[(df.index >= pd.Period(sp['ini'], 'M')) & (df.index <= pd.Period(sp['fim'], 'M'))]
    if 'excl' in sp: df = df[~df.index.year.isin(sp['excl'])]
    return df

def pres_amostra(idx):
    return '/'.join(dict.fromkeys(X.loc[idx, 'presidente']))

PRE = (pd.Period('2019-01', 'M'), pd.Period('2022-12', 'M'))
POS = (pd.Period('2023-01', 'M'), pd.Period('2026-12', 'M'))
def media_janela(dep, regs, jan, excl=()):
    df = X[[dep] + regs].astype(float).dropna()
    df = df[(df.index >= jan[0]) & (df.index <= jan[1]) & ~df.index.year.isin(list(excl))]
    return df.mean(), df.index.min(), df.index.max(), len(df)

NOTA_B = 'associacao estatistica, nao causalidade (classe B no maximo)'
linhas, coefrows = [], []
def linha(**k):
    base = dict(tipo='', dependente='', especificacao='', grupo='', descricao='', amostra='', presidentes_na_amostra='', n='', r2='', r2_ajustado='',
                lags_nw='', rho_residuo='', variavel='', coef='', ep_hac='', estat_t='', p_valor='', significante_5pct='', ep_hac_lags12='',
                sinal_igual_ao_base='', razao_coef_base='', n_espec_signif_mesmo_sinal='', so_nesta_especificacao='',
                janela_pre='', janela_pos='', media_pre='', media_pos='', delta_pos_menos_pre='', contribuicao='', fracao_do_delta='', nota=NOTA_B)
    base.update(k); linhas.append(base); return base

def estima(dep, sp):
    df = amostra(dep, sp)
    y = df[dep].values; Xm = np.column_stack([np.ones(len(df))] + [df[c].values for c in sp['regs']])
    L = nw_lags(len(df))
    b, V, r2, r2a, e = ols_nw(y, Xm, L)
    _, V12, _, _, _ = ols_nw(y, Xm, 12)
    am = f'{df.index.min()} a {df.index.max()}'
    for j, nome in enumerate(['constante'] + sp['regs']):
        se = math.sqrt(V[j, j]); tt = b[j] / se
        r = linha(tipo='coeficiente', dependente=dep, especificacao=sp['id'], grupo=sp['grupo'], descricao=sp['desc'], amostra=am,
                  presidentes_na_amostra=pres_amostra(df.index), n=len(df), r2=round(r2, 4), r2_ajustado=round(r2a, 4), lags_nw=L,
                  rho_residuo=round(float(np.corrcoef(e[1:], e[:-1])[0, 1]), 3),
                  variavel=nome, coef=round(b[j], 5), ep_hac=round(se, 5), estat_t=round(tt, 3),
                  p_valor=round(2 * stats.norm.sf(abs(tt)), 4), significante_5pct='sim' if abs(tt) > 1.959964 else 'nao',
                  ep_hac_lags12=round(math.sqrt(V12[j, j]), 5))
        r['_b'] = b[j]; r['_t'] = tt; r['_base'] = sp.get('base', sp['grupo']); r['_dif'] = sp['dif']
        coefrows.append(r)
    # decomposicao Bolsonaro (2019-2022) contra Lula 3 (2023-2026) pelas medias, com os coeficientes da especificacao
    if sp.get('regime'): return
    excl = sp.get('excl', [])
    m0, a0, z0, n0 = media_janela(dep, sp['regs'], PRE, excl)
    m1, a1, z1, n1 = media_janela(dep, sp['regs'], POS, excl)
    dy = m1[dep] - m0[dep]
    coef = dict(zip(sp['regs'], b[1:]))
    ext = [c for c in sp['regs'] if c not in FOC]
    cext = sum(coef[c] * (m1[c] - m0[c]) for c in ext)
    cfoc = sum(coef[c] * (m1[c] - m0[c]) for c in sp['regs'] if c in FOC)
    fora = 'ini' in sp and pd.Period(sp['fim'], 'M') < PRE[0]
    obs = []
    if fora: obs.append('coeficientes estimados em 2008-2015, aplicados fora da amostra')
    if sp['dif']: obs.append('coeficientes de primeiras diferencas aplicados a variacao das medias em nivel; constante (deriva) fica no nao explicado')
    if excl: obs.append('medias das janelas tambem excluem 2020')
    if dep == 'embi_br_pb': obs.append('EMBI+ acaba em 30/07/2024: janela pos so tem 2023-01 a 2024-07')
    obs.append('o nao explicado e residuo de uma regressao de associacao, nao e premio fiscal')
    jp, jq = f'{a0} a {z0} ({n0} meses)', f'{a1} a {z1} ({n1} meses)'
    comum = dict(tipo='decomposicao', dependente=dep, especificacao=sp['id'], grupo=sp['grupo'], descricao=sp['desc'], amostra=am,
                 presidentes_na_amostra='Bolsonaro contra Lula 3', n=len(df), r2=round(r2, 4), janela_pre=jp, janela_pos=jq,
                 nota='; '.join(obs + [NOTA_B]))
    linha(variavel=dep, media_pre=round(m0[dep], 4), media_pos=round(m1[dep], 4), delta_pos_menos_pre=round(dy, 4), **comum)
    for c in sp['regs']:
        linha(variavel=c, coef=round(coef[c], 5), media_pre=round(m0[c], 4), media_pos=round(m1[c], 4), delta_pos_menos_pre=round(m1[c] - m0[c], 4),
              contribuicao=round(coef[c] * (m1[c] - m0[c]), 4), fracao_do_delta=round(coef[c] * (m1[c] - m0[c]) / dy, 4), **comum)
    linha(variavel='TOTAL fatores externos', delta_pos_menos_pre=round(dy, 4), contribuicao=round(cext, 4), fracao_do_delta=round(cext / dy, 4), **comum)
    if cfoc or any(c in FOC for c in sp['regs']):
        linha(variavel='TOTAL expectativa fiscal Focus (associacao)', delta_pos_menos_pre=round(dy, 4), contribuicao=round(cfoc, 4),
              fracao_do_delta=round(cfoc / dy, 4), **comum)
    linha(variavel='nao explicado pelos regressores', delta_pos_menos_pre=round(dy, 4), contribuicao=round(dy - cext - cfoc, 4),
          fracao_do_delta=round((dy - cext - cfoc) / dy, 4), **comum)

for dep, depdesc in DEPS:
    for sp in specs():
        estima(dep, sp)

# robustez de sinal: compara com a especificacao base (a_niveis ou b_niveis) e conta especificacoes significantes
for r in coefrows:
    if r['variavel'] == 'constante': continue
    base = [q for q in coefrows if q['dependente'] == r['dependente'] and q['especificacao'] == r['_base'] + '_niveis' and q['variavel'] == r['variavel']]
    if base and r['especificacao'] != base[0]['especificacao']:
        r['sinal_igual_ao_base'] = 'sim' if np.sign(r['_b']) == np.sign(base[0]['_b']) else 'nao'
        if not r['_dif']: r['razao_coef_base'] = round(r['_b'] / base[0]['_b'], 3) if base[0]['_b'] else ''
for dep, _ in DEPS:
    for var in set(q['variavel'] for q in coefrows if q['dependente'] == dep) - {'constante'}:
        rs = [q for q in coefrows if q['dependente'] == dep and q['variavel'] == var]
        pos = [q for q in rs if q['_t'] > 1.959964]; neg = [q for q in rs if q['_t'] < -1.959964]
        for q in rs:
            q['n_espec_signif_mesmo_sinal'] = f'{len(pos)} positivas e {len(neg)} negativas significantes de {len(rs)}'
            if q['significante_5pct'] == 'sim' and len(pos if q['_t'] > 0 else neg) == 1:
                q['so_nesta_especificacao'] = 'sim: unica especificacao com este sinal significante'

# testes de quebra: Wald HAC das interacoes regime x regressores (Chow robusto a autocorrelacao)
for dep, _ in DEPS:
    for g, regs in [('a', EXT), ('b', EXT + FOC)]:
        df = amostra(dep, dict(regs=regs, dif=False))
        Z = np.column_stack([np.ones(len(df))] + [df[c].values for c in regs]); k = Z.shape[1]
        testes = [('quebras nos 3 limites de regime (2013-01, 2017-01, 2021-01)', ['2013-01', '2017-01', '2021-01'], True)] + \
                 [(f'quebra unica em {q}', [q], False) for q in ['2013-01', '2016-01', '2017-01', '2021-01']]
        for desc, qs, regime in testes:
            blocos = [Z]
            for i, q in enumerate(qs):
                if regime:
                    hi = qs[i + 1] if i + 1 < len(qs) else '2099-12'
                    d = ((df.index >= pd.Period(q, 'M')) & (df.index < pd.Period(hi, 'M'))).astype(float)
                else:
                    d = (df.index >= pd.Period(q, 'M')).astype(float)
                blocos.append(Z * d[:, None])
            M = np.column_stack(blocos)
            L = nw_lags(len(df))
            b, V, r2, _, _ = ols_nw(df[dep].values, M, L)
            gam = b[k:]; Vg = V[k:, k:]
            W = float(gam @ np.linalg.solve(Vg, gam)); dfw = len(gam)
            linha(tipo='teste_quebra', dependente=dep, especificacao=f'{g}_niveis', grupo=g, descricao=desc,
                  amostra=f'{df.index.min()} a {df.index.max()}', presidentes_na_amostra=pres_amostra(df.index), n=len(df), r2=round(r2, 4),
                  lags_nw=L, variavel=f'Wald HAC, {dfw} restricoes', coef=round(W, 3), p_valor=round(float(stats.chi2.sf(W, dfw)), 5),
                  significante_5pct='sim' if stats.chi2.sf(W, dfw) < 0.05 else 'nao',
                  nota='H0: coeficientes iguais entre regimes; Wald com covariancia Newey-West, qui-quadrado; ' + NOTA_B)

# janela movel de 36 meses
jm = []
for dep, _ in DEPS:
    for g, regs in [('a', EXT), ('b', EXT + FOC)]:
        df = amostra(dep, dict(regs=regs, dif=False))
        for i in range(36, len(df) + 1):
            w_ = df.iloc[i - 36:i]
            if (w_.index[-1] - w_.index[0]).n != 35: continue
            Z = np.column_stack([np.ones(36)] + [w_[c].values for c in regs])
            L = nw_lags(36)
            b, V, r2, _, _ = ols_nw(w_[dep].values, Z, L)
            for j, c in enumerate(regs, 1):
                se = math.sqrt(V[j, j])
                jm.append(dict(mes_inicio=str(w_.index[0]), mes_fim=str(w_.index[-1]), presidente_mes_fim=X.loc[w_.index[-1], 'presidente'],
                               dependente=dep, especificacao=f'{g}_niveis', variavel=c, coef=round(b[j], 5), ep_hac=round(se, 5),
                               estat_t=round(b[j] / se, 3), r2=round(r2, 4), n=36, lags_nw=L, nota=NOTA_B))
JM = pd.DataFrame(jm)
JM.to_csv(os.path.join(RAIZ, 'X-janela-movel-36m.csv'), index=False, encoding='utf-8')
for (dep, esp, var), gdf in JM.groupby(['dependente', 'especificacao', 'variavel'], sort=False):
    sig_p = (gdf['estat_t'] > 1.96).mean(); sig_n = (gdf['estat_t'] < -1.96).mean()
    trocas = int((np.sign(gdf['coef']).diff().fillna(0) != 0).sum())
    linha(tipo='janela_movel_resumo', dependente=dep, especificacao=esp, grupo=esp[0], descricao='regressoes de 36 meses deslizando 1 mes',
          amostra=f"{gdf['mes_fim'].min()} a {gdf['mes_fim'].max()} (mes final da janela)", n=len(gdf), variavel=var,
          coef=f"min {gdf['coef'].min():.4f}, mediana {gdf['coef'].median():.4f}, max {gdf['coef'].max():.4f}",
          estat_t=f'{sig_p:.0%} das janelas significante positivo, {sig_n:.0%} significante negativo',
          sinal_igual_ao_base=f'{(gdf["coef"] > 0).mean():.0%} das janelas com coef positivo; {trocas} trocas de sinal',
          nota='detalhe em X-janela-movel-36m.csv; ' + NOTA_B)

# janela restrita 2019-2026 (auditoria v10, F1): coeficientes estimados so na janela da comparacao Bolsonaro x Lula 3.
# Acrescentado depois; nao entra na contagem de robustez de sinal das linhas antigas.
n_antes = len(coefrows)
for dep, _ in DEPS:
    for sid, regs, dif, desc in [('j2019_niveis', EXT, False, 'so fatores externos, niveis, janela 2019-01 a 2026-10'),
                                 ('j2019_dif', EXT, True, 'so fatores externos, primeiras diferencas, janela 2019-02 a 2026-10'),
                                 ('j2019_niveis_focus', EXT + FOC, False, 'externos + expectativa fiscal Focus, niveis, janela 2019-01 a 2026-10'),
                                 ('j2019_dif_focus', EXT + FOC, True, 'externos + expectativa fiscal Focus, primeiras diferencas, janela 2019-02 a 2026-10')]:
        estima(dep, dict(id=sid, grupo='j2019', base='b' if FOC[0] in regs else 'a', desc=desc + ('; EMBI+ ate 2024-07' if dep == 'embi_br_pb' else ''),
                         regs=regs, dif=dif, ini='2019-02' if dif else '2019-01', fim='2026-10'))
for r in coefrows[n_antes:]:
    if r['variavel'] == 'constante': continue
    base = [q for q in coefrows[:n_antes] if q['dependente'] == r['dependente'] and q['especificacao'] == r['_base'] + '_niveis' and q['variavel'] == r['variavel']]
    if base:
        r['sinal_igual_ao_base'] = 'sim' if np.sign(r['_b']) == np.sign(base[0]['_b']) else 'nao'
        if not r['_dif']: r['razao_coef_base'] = round(r['_b'] / base[0]['_b'], 3) if base[0]['_b'] else ''
    r['n_espec_signif_mesmo_sinal'] = 'nao contado (janela 2019-2026 acrescentada depois)'

CAMPOS = [k for k in linhas[0] if not k.startswith('_')]
with open(os.path.join(RAIZ, 'X-regressoes.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=CAMPOS, extrasaction='ignore'); w.writeheader(); w.writerows(linhas)

# ---------------------------------------------------------------- X-comparacao-emergentes.csv
MAND = [('Lula 2', '2008-01', '2010-12'), ('Dilma', '2011-01', '2016-04'), ('Temer', '2016-06', '2018-12'),
        ('Bolsonaro', '2019-01', '2022-12'), ('Lula 3', '2023-01', '2026-12'), ('2008-2026 inteiro', '2008-01', '2026-12')]
SID = {k + '10': (nome, sid) for k, nome, sid in EM + [('us', 'Estados Unidos (referencia, fora da mediana)', 'IRLTLT01USM156N')]}
FONTE_C = 'Brasil: N-juro-real-mensal.csv (prefixado_10a, NTN-F interpolada, Tesouro Direto); demais: OCDE via FRED (fredgraph.csv?id=<serie>), consulta 2026-10-19'
with open(os.path.join(RAIZ, 'X-comparacao-emergentes.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['periodo', 'presidente', 'inicio', 'fim', 'pais', 'serie', 'n_meses', 'juro_nominal_10a_medio', 'brasil_mesmos_meses',
                'diferenca_brasil_menos_pais_pp', 'nota', 'fonte'])
    for nome, a, z in MAND:
        sel = X[(X.index >= pd.Period(a, 'M')) & (X.index <= pd.Period(z, 'M')) & (X['presidente'] != 'Dilma/Temer')]
        sel = sel[sel['prefixado_10a_br'].notna()]
        pres = nome if nome in [m[0] for m in MAND[:-1]] else '/'.join(dict.fromkeys(sel['presidente']))
        ini, fim = str(sel.index.min()), str(sel.index.max())
        nt0 = 'exclui 2016-05 (mes de transicao Dilma/Temer)' if nome in ('Dilma', 'Temer', '2008-2026 inteiro') else ''
        w.writerow([nome, pres, ini, fim, 'Brasil', 'prefixado_10a (N)', len(sel), round(sel['prefixado_10a_br'].mean(), 3), '', '', nt0, FONTE_C])
        s = sel[sel['em10_mediana_disp'].notna()]
        w.writerow([nome, pres, ini, fim, 'Mediana dos emergentes (mensal, 5 a 7 paises)', 'mediana de MX ZA CO CL IN PL HU', len(s),
                    round(s['em10_mediana_disp'].mean(), 3), round(s['prefixado_10a_br'].mean(), 3),
                    round((s['prefixado_10a_br'] - s['em10_mediana_disp']).mean(), 3),
                    '; '.join(x for x in [nt0, 'mediana do mes entre os paises com dado (minimo 5); India entra em 2011-12; juro nominal, nao corrige inflacao'] if x), FONTE_C])
        for c in EM7 + ['us10']:
            s = sel[sel[c].notna()]
            if not len(s): continue
            w.writerow([nome, pres, ini, fim, SID[c][0], SID[c][1], len(s), round(s[c].mean(), 3), round(s['prefixado_10a_br'].mean(), 3),
                        round((s['prefixado_10a_br'] - s[c]).mean(), 3), nt0, FONTE_C])

    # mediana com composicao fixa (auditoria v10, F2), acrescentada no fim do arquivo
    for nome, a, z in MAND:
        sel = X[(X.index >= pd.Period(a, 'M')) & (X.index <= pd.Period(z, 'M')) & (X['presidente'] != 'Dilma/Temer')]
        sel = sel[sel['prefixado_10a_br'].notna()]
        pres = nome if nome in [m[0] for m in MAND[:-1]] else '/'.join(dict.fromkeys(sel['presidente']))
        nt0 = 'exclui 2016-05 (mes de transicao Dilma/Temer)' if nome in ('Dilma', 'Temer', '2008-2026 inteiro') else ''
        s = sel[sel['em10_mediana_5'].notna()]
        w.writerow([nome, pres, str(s.index.min()), str(s.index.max()), 'Mediana fixa 5 paises (ZA CO CL PL HU)', 'mediana de ZA CO CL PL HU', len(s),
                    round(s['em10_mediana_5'].mean(), 3), round(s['prefixado_10a_br'].mean(), 3),
                    round((s['prefixado_10a_br'] - s['em10_mediana_5']).mean(), 3),
                    '; '.join(x for x in [nt0, 'composicao fixa, so meses com os 5 paises (Hungria ate 2026-08); juro nominal, nao corrige inflacao'] if x), FONTE_C])

# ---------------------------------------------------------------- X-variacoes.csv (auditoria v10, F2)
with open(os.path.join(RAIZ, 'X-variacoes.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['serie', 'presidente', 'mes_inicio', 'mes_fim', 'valor_inicio', 'valor_fim', 'variacao_pontos', 'nota', 'fonte'])
    X['dif_br_menos_dfii10'] = X['juro_real_10a_br'] - X['dfii10']
    for c, rot, fte in [('juro_real_10a_br', 'juro real 10 anos Brasil (NTN-B interpolada, % a.a.)', 'N-juro-real-mensal.csv (Tesouro Direto)'),
                        ('dfii10', 'DFII10, TIPS 10 anos EUA (% a.a.)', 'FRED DFII10 via brutos/R/DFII10.csv'),
                        ('dif_br_menos_dfii10', 'juro real 10a Brasil menos DFII10 (p.p.)', 'derivado das duas linhas acima')]:
        for a, z, pres in [('2018-12', '2022-12', 'Bolsonaro'), ('2022-12', '2026-10', 'Lula 3')]:
            v0, v1 = X.loc[pd.Period(a, 'M'), c], X.loc[pd.Period(z, 'M'), c]
            nt = 'media mensal das observacoes diarias'
            if z == '2026-10': nt += '; out/2026 parcial (TD e DFII10 ate 15/10/2026)'
            w.writerow([rot, pres, a, z, round(v0, 4), round(v1, 4), round(v1 - v0, 4), nt + '; descricao, sem modelo', fte + '; consulta 2026-10-19'])

# ---------------------------------------------------------------- resumo no terminal
print(f'X ok. OAS: sobreposicao Internet Archive x FRED atual {OAS_N_SOBRE} dias, diferenca maxima {OAS_DIF_MAX:.4f} pp')
print('ultimos dados:', {k: str(v) for k, v in ult.items()})
for r in linhas:
    if r['tipo'] == 'coeficiente' and r['variavel'] != 'constante' and r['especificacao'] in ('a_niveis', 'b_niveis', 'a_c_dif', 'b_c_dif', 'a_c_em10'):
        print(r['dependente'][:6], r['especificacao'], r['variavel'], r['coef'], r['ep_hac'], r['r2'], r['n'])
for r in linhas:
    if r['tipo'] == 'decomposicao' and r['variavel'].startswith(('TOTAL', 'nao')):
        print('DEC', r['dependente'][:6], r['especificacao'], r['variavel'], 'delta', r['delta_pos_menos_pre'], 'contrib', r['contribuicao'], 'frac', r['fracao_do_delta'])
for r in linhas:
    if r['tipo'] == 'teste_quebra':
        print('QUEBRA', r['dependente'][:6], r['especificacao'], r['descricao'], r['coef'], r['p_valor'])

#!/usr/bin/env bash
# Frente X: rebaixa os brutos de risco-pais e fatores externos para brutos/X/dados/.
# Consulta original: 2026-10-19. Rodar de qualquer lugar: bash brutos/X/baixa_X.sh
set -euo pipefail
D="$(cd "$(dirname "$0")" && pwd)/dados"; mkdir -p "$D/fred_series"
FRED="DGS10 VIXCLS DTWEXBGS BAMLEMCBPIOAS DEXBZUS IRLTLT01MXM156N IRLTLT01ZAM156N COLIRLTLT01STM IRLTLT01CLM156N INDIRLTLT01STM IRLTLT01PLM156N IRLTLT01HUM156N IRLTLT01USM156N"
for s in $FRED; do
  curl -sf -m 120 -o "$D/$s.csv" "https://fred.stlouisfed.org/graph/fredgraph.csv?id=$s"
  curl -sf -m 120 -o "$D/fred_series/$s.html" "https://fred.stlouisfed.org/series/$s"
done
curl -sf -m 120 -o "$D/fred_series/DFII10.html" "https://fred.stlouisfed.org/series/DFII10"
# ICE BofA EM corporate OAS: desde abril de 2026 o FRED so mostra 3 anos; o historico vem do Internet Archive
curl -sf -m 300 -o "$D/wayback_20241026_BAMLEMCBPIOAS.html" "http://web.archive.org/web/20241026195505id_/https://fred.stlouisfed.org/data/BAMLEMCBPIOAS"
curl -sf -m 300 -o "$D/wayback_20210401_BAMLEMCBPIOAS.txt" "http://web.archive.org/web/20210401040458id_/https://fred.stlouisfed.org/data/BAMLEMCBPIOAS.txt"
# Ipeadata EMBI+ Brasil (JP Morgan), serie inativa
curl -sf -m 600 -o "$D/ipeadata_JPM366_EMBI366.json" "http://www.ipeadata.gov.br/api/odata4/ValoresSerie(SERCODIGO='JPM366_EMBI366')"
curl -sf -m 120 -o "$D/ipeadata_metadados_JPM366_EMBI366.json" "http://www.ipeadata.gov.br/api/odata4/Metadados('JPM366_EMBI366')"
curl -sf -m 120 -o "$D/embi_metodologia.doc" "http://www.ipeadata.gov.br/doc/Metodologia%20Embi.doc"
# Focus, BCB Olinda, ExpectativasMercadoAnuais (espacos como %20; o curl --data-urlencode com + devolve 400)
O='https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais'
SEL='%24format=json&%24select=Indicador%2CIndicadorDetalhe%2CData%2CDataReferencia%2CMedia%2CMediana%2CnumeroRespondentes%2CbaseCalculo'
curl -sf -m 600 -o "$D/focus_dlsp.json" "$O?%24filter=Indicador%20eq%20%27D%C3%ADvida%20l%C3%ADquida%20do%20setor%20p%C3%BAblico%27&$SEL"
curl -sf -m 600 -o "$D/focus_primario.json" "$O?%24filter=Indicador%20eq%20%27Resultado%20prim%C3%A1rio%27&$SEL"
curl -sf -m 120 -o "$D/olinda_expectativas_documentacao.html" "https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/documentacao"
# OCDE, metadado de metodologia das taxas longas (METHODOLOGY = N, nacional)
curl -sf -m 300 -o "$D/oecd_finmark_irlt_2026.csv" -H 'Accept: application/vnd.sdmx.data+csv; charset=utf-8; labels=both' \
  "https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_STES@DF_FINMARK,4.0/MEX+ZAF+COL+CHL+IND+POL+HUN.M.IRLT.PA.....?startPeriod=2026-07"
echo "X baixado em $D"

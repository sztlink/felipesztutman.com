#!/usr/bin/env python3
# Divida bruta do governo geral (criterio Bacen), dezembro de cada ano e ultimo mes, com presidente:
# % do PIB (a mesma serie do grafico, I-divida-historico.csv), R$ bi correntes e R$ bi de dez/2025 pelo IPCA.
# Fontes: R$ ate 2017 em J-dbgg-composicao.csv (ftp/notaecon e Tabelas de estatisticas fiscais do BCB);
# de dez/2018 em diante e no ultimo mes, SGS 13761 (R$ mi) e 13762 (% PIB) em brutos/F/; IPCA SIDRA 1737 em brutos/N/ibge/.
import csv, json, os
AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.join(AQUI, '..', '..')
le = lambda arq: list(csv.DictReader(open(os.path.join(RAIZ, arq), newline='', encoding='utf-8')))
sgs = lambda n: {r['data']: float(r['valor']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'F', f'sgs_{n}.json')))}
S13761, S13762 = sgs(13761), sgs(13762)
IPCA = {r['D3C']: float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json')))[1:]}
PCT = {int(r['ano']): (float(r['pct_pib_dez']), r['fonte']) for r in le('I-divida-historico.csv') if r['serie'] == 'dbgg'}
RS = {int(r['ano']): (float(r['valor_rs_mi']), r['fonte_url']) for r in le('J-dbgg-composicao.csv') if r['serie'] == 'dbgg_total'}
U_SGS = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.{}/dados?formato=json'
U_IPCA = 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'
PRES = [(2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'), (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'),
        (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]
pres = lambda a: next(n for i, f, n in PRES if i <= a <= f)

linhas = []
for a in sorted(PCT):
  pct, fp = PCT[a]
  if a >= 2018:
    rs, fr = S13761[f'01/12/{a}'], U_SGS.format(13761)
    assert abs(S13762[f'01/12/{a}'] - pct) < 0.005, (a, pct)
  else:
    rs, fr = RS[a]
  nota = ''
  if a == 2017:
    nota = 'edicao 201901 publicou 74,07; com o PIB revisado da edicao 202001 a mesma divida da 73,74 (J-dbgg-composicao.csv)'
  linhas.append([str(a), f'dez/{a}', pres(a), pct, round(rs / 1000, 1), round(rs / 1000 * IPCA['202512'] / IPCA[f'{a}12'], 1), nota, fp, fr, U_IPCA])
# ultimo mes publicado
ult = max(S13761, key=lambda d: d[6:] + d[3:5])
m, a = ult[3:5], int(ult[6:])
rs = S13761[ult]
linhas.append([f'{a}-{m}', f'{["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"][int(m) - 1]}/{a}', pres(a), S13762[ult], round(rs / 1000, 1),
               round(rs / 1000 * IPCA['202512'] / IPCA[f'{a}{m}'], 1), 'ultimo mes publicado; ano incompleto', U_SGS.format(13762), U_SGS.format(13761), U_IPCA])
with open(os.path.join(RAIZ, 'I-divida-bruta-anual.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f)
  w.writerow(['periodo', 'rotulo', 'presidente', 'dbgg_pct_pib', 'dbgg_rs_bi_correntes', 'dbgg_rs_bi_dez2025_ipca', 'nota', 'fonte_pct', 'fonte_rs', 'fonte_ipca'])
  w.writerows(linhas)
print('dbgg anual ok', linhas[-1][:6])

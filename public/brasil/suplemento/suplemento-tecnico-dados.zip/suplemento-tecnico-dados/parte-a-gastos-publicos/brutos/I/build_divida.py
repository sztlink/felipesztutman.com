#!/usr/bin/env python3
# Divida bruta do governo geral (DBGG, criterio Bacen; a serie comeca em dez/2006) e liquida do setor publico (DLSP), % do PIB, dezembro de cada ano.
# Fontes: BCB ftp/notaecon Divggnp.xls e Dlspp.xls e Tabelas de estatisticas fiscais (ate 2017, vale a edicao mais nova);
# de dez/2018 em diante a SGS 13762 (DBGG) e 4513 (DLSP), uma so safra, baixadas em brutos/F/.
# Uso: PYTHONPATH=<dir com xlrd> python3 build_divida.py
import csv, glob, os, re, xlrd, openpyxl
AQUI = os.path.dirname(os.path.abspath(__file__))
U_FTP = 'https://www.bcb.gov.br/ftp/notaecon/{}.zip'
U_TAB = 'https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/{}'
serie = {}  # (serie, ano) -> (valor, fonte, edicao aaaamm); vale a edicao mais nova (PIB revisado)

def dez_cols(linhas, i_ano, i_mes):
  # colunas de dezembro com o ano herdado da linha de anos (celulas mescladas: ano so na primeira coluna)
  ano, out = None, {}
  for j, (a, m) in enumerate(zip(linhas[i_ano], linhas[i_mes])):
    try: ano = int(float(a))
    except (TypeError, ValueError): pass
    if isinstance(m, str) and m.strip().lower().startswith('dez') and ano: out[ano] = j
  return out

def acha(linhas, rotulo, ordem=0):
  achou = [r for r in linhas if r and isinstance(r[0], str) and r[0].strip().lower().startswith(rotulo.lower())]
  return achou[ordem] if len(achou) > ordem else None

def le_ftp(nome, rotulos):
  b = xlrd.open_workbook(os.path.join(AQUI, f'ftp-{nome}', f'{nome}.xls'))
  s = b.sheet_by_name('% PIB'); L = [s.row_values(i) for i in range(s.nrows)]
  i_ano = next(i for i, r in enumerate(L) if r and str(r[0]).startswith('Discrimina'))
  i_mes = next(i for i in range(i_ano, i_ano + 4) if any(str(c).startswith('Dezembro') for c in L[i]))
  cols = dez_cols(L, i_ano, i_mes)
  for chave, rot, ordem in rotulos:
    r = acha(L, rot, ordem)
    for ano, j in cols.items():
      if isinstance(r[j], float): serie[(chave, ano)] = (r[j], U_FTP.format(nome), 201812)  # arquivos do ftp de 26/12/2018

le_ftp('Divggnp', [('dbgg', 'Dívida bruta do governo geral', 0), ('dlsp', 'Dívida líquida do setor público', 0)])
le_ftp('Dlspp', [('dlsp_longa', 'Dívida líquida total', 0)])

for f in sorted(glob.glob(os.path.join(AQUI, 'bcb-*_Tabelas_de_estatisticas_fiscais.xls*'))):
  base = os.path.basename(f)[4:]
  if f.endswith('.xlsx'):
    wb = openpyxl.load_workbook(f, read_only=True, data_only=True)
    tab = lambda n: [list(r) for r in wb[n].iter_rows(values_only=True)] if n in wb.sheetnames else None
  else:
    wb = xlrd.open_workbook(f)
    tab = lambda n: [wb.sheet_by_name(n).row_values(i) for i in range(wb.sheet_by_name(n).nrows)] if n in wb.sheet_names() else None
  nomes = wb.sheetnames if f.endswith('.xlsx') else wb.sheet_names()
  titulo = lambda n: str((tab(n) or [['']])[0][0] or '')
  # a tabela de DBGG muda de numero entre edicoes: acha pelo titulo
  t_dbgg = next((n for n in nomes if re.search(r'D[íi]vida l[íi]quida e bruta do [Gg]overno [Gg]eral', titulo(n))), None)
  for nome_tab, chave, rot, ordem in (('Tabela 4', 'dlsp', 'Dívida líquida total', 0), (t_dbgg, 'dbgg', 'Dívida Bruta do Governo Geral', 1)):
    if not nome_tab: continue
    L = tab(nome_tab)
    if not L: continue
    i_ano = next(i for i, r in enumerate(L) if r and str(r[0]).startswith('Discrimina'))
    i_mes = next((i for i in range(i_ano + 1, i_ano + 5) if any(isinstance(c, str) and c.strip().lower().startswith('dez') for c in L[i])), None)
    if i_mes is None: continue
    cols = dez_cols(L, i_ano, i_mes)
    # DBGG: edicoes novas trazem conceito FMI e conceito Bacen; usa o Bacen (o mesmo das edicoes antigas)
    r = (next((x for x in L if x and isinstance(x[0], str) and 'Conceito Bacen' in x[0]), None) if chave == 'dbgg' else None) or acha(L, rot, 0)
    if not r: continue
    for ano, j in cols.items():
      v = r[j + 1] if j + 1 < len(r) else None  # coluna seguinte ao saldo e o % do PIB
      try: v = float(v)
      except (TypeError, ValueError): continue
      ed = int(base[:6])
      if (chave, ano) in serie and serie[(chave, ano)][2] > ed: continue
      if (chave, ano) in serie and abs(serie[(chave, ano)][0] - v) > 0.3:
        print('revisao', chave, ano, round(serie[(chave, ano)][0], 2), '->', round(v, 2), base)
      serie[(chave, ano)] = (v, U_TAB.format(base), ed)

# de 2018 em diante: SGS atual (uma so safra, sem misturar PIB de edicoes diferentes)
import json
U_SGS = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.{}/dados?formato=json'
for cod, chave in ((13762, 'dbgg'), (4513, 'dlsp')):
  for x in json.load(open(os.path.join(AQUI, '..', 'F', f'sgs_{cod}.json'))):
    if x['data'].startswith('01/12/'):
      ano = int(x['data'][-4:])
      if (chave, ano) in serie and abs(serie[(chave, ano)][0] - float(x['valor'])) > 0.3:
        print('safra SGS', chave, ano, round(serie[(chave, ano)][0], 2), '->', x['valor'])
      serie[(chave, ano)] = (float(x['valor']), U_SGS.format(cod), 999999)

with open(os.path.join(AQUI, '..', '..', 'I-divida-historico.csv'), 'w', newline='', encoding='utf-8') as fo:
  w = csv.writer(fo); w.writerow(['serie', 'ano', 'pct_pib_dez', 'fonte'])
  for (k, a) in sorted(serie): w.writerow([k, a, round(serie[(k, a)][0], 2), serie[(k, a)][1]])
for k in ('dbgg', 'dlsp', 'dlsp_longa'):
  print(k, ' '.join(f'{a}:{serie[(k, a)][0]:.1f}' for (kk, a) in sorted(serie) if kk == k))

# ---- fatores condicionantes da DLSP (Tabela 6, fluxo acumulado no ano, % do PIB): o que explica a variacao de cada ano
# sinal do BCB: positivo aumenta a divida (primario positivo = deficit)
FAT = [('variacao', 'Dívida líquida – variação'), ('primario', 'Primário'), ('juros', 'Juros nominais'),
       ('cambio', 'Ajuste cambial'), ('pib', 'Efeito crescimento PIB')]
fat = {}
for f in sorted(glob.glob(os.path.join(AQUI, 'bcb-*_Tabelas_de_estatisticas_fiscais.xls*'))):
  base = os.path.basename(f)[4:]; ed = int(base[:6])
  # a tabela se chama "Tabela 6" nas edicoes novas e "Quadro 7" nas antigas: acha pelo titulo
  if f.endswith('.xlsx'):
    wb = openpyxl.load_workbook(f, read_only=True, data_only=True)
    abas = {n: [list(r) for r in wb[n].iter_rows(values_only=True)] for n in wb.sheetnames}
  else:
    wb = xlrd.open_workbook(f)
    abas = {n: [wb.sheet_by_name(n).row_values(i) for i in range(wb.sheet_by_name(n).nrows)] for n in wb.sheet_names()}
  topo = lambda L: ' '.join(str(c) for r in L[:3] for c in r if c)
  L = next((L for L in abas.values() if 'Evolução da dívida líquida' in topo(L) and 'acumulados no ano' in topo(L)), None)
  if not L: continue
  i_ano = next(i for i, r in enumerate(L) if r and str(r[0]).startswith('Discrimina'))
  i_mes = next((i for i in range(i_ano + 1, i_ano + 5) if any(isinstance(c, str) and c.strip().lower().startswith('dez') for c in L[i])), None)
  if i_mes is None: continue
  cols = dez_cols(L, i_ano, i_mes)
  for chave, rot in FAT:
    r = next((x for x in L if x and isinstance(x[0], str) and x[0].strip().startswith(rot)), None)
    if not r: continue
    for ano, j in cols.items():
      try: v = float(r[j + 1])
      except (TypeError, ValueError, IndexError): continue
      if (chave, ano) in fat and fat[(chave, ano)][2] > ed: continue
      fat[(chave, ano)] = (v, U_TAB.format(base), ed)
with open(os.path.join(AQUI, '..', '..', 'I-divida-fatores.csv'), 'w', newline='', encoding='utf-8') as fo:
  w = csv.writer(fo); w.writerow(['fator', 'ano', 'pct_pib', 'fonte'])
  for (k, a) in sorted(fat): w.writerow([k, a, round(fat[(k, a)][0], 2), fat[(k, a)][1]])
for k, _ in FAT:
  print(k, ' '.join(f'{a}:{fat[(k, a)][0]:.1f}' for (kk, a) in sorted(fat) if kk == k))

# ---- por mandato: divida no inicio e no fim, soma dos fatores, primario medio do Governo Central (RTN 2.1-A)
RTN = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326'
wbr = openpyxl.load_workbook(os.path.join(AQUI, '..', 'D', 'seriehistoricaago26.xlsx'), read_only=True, data_only=True)
rr = list(wbr['2.1-A'].iter_rows(values_only=True))
hr = next(r for r in rr if r[0] and 'Discrimina' in str(r[0]))
lr = next(r for r in rr if r[0] and str(r[0]).strip().startswith('8. RESULTADO PRIM'))
prim_gc = {int(a): float(v) * (100 if abs(float(v)) < 1 else 1) for a, v in zip(hr[1:], lr[1:]) if isinstance(a, (int, float)) and v is not None}
# 2016 em linha propria: Dilma afastada em 12/05/2016, Temer executou o resto do ano
MAND = [('FHC 2', 1999, 2002), ('Lula 1', 2003, 2006), ('Lula 2', 2007, 2010), ('Dilma', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016),
        ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3 (ate 2025, incompleto)', 2023, 2025)]
val = lambda k, a: serie[(k, a)][0] if (k, a) in serie else (serie[('dlsp_longa', a)][0] if k == 'dlsp' and ('dlsp_longa', a) in serie else None)
soma = lambda k, a, b: round(sum(fat[(k, x)][0] for x in range(a, b + 1)), 1) if all((k, x) in fat for x in range(a, b + 1)) else ''
with open(os.path.join(AQUI, '..', '..', 'I-divida-por-mandato.csv'), 'w', newline='', encoding='utf-8') as fo:
  w = csv.writer(fo)
  # fatores: soma no mandato e media por ano; outros = variacao observada da DLSP menos os quatro fatores
  # (reconhecimento de dividas, privatizacoes, ajustes metodologicos e diferenca de safra do PIB entre edicoes)
  w.writerow(['mandato', 'anos', 'n_anos', 'primario_gov_central_medio_pct_pib', 'dbgg_inicio', 'dbgg_fim', 'dlsp_inicio', 'dlsp_fim',
              'fator_primario', 'fator_juros', 'fator_cambio', 'fator_pib', 'outros', 'juros_mais_pib',
              'ano_primario', 'ano_juros', 'ano_cambio', 'ano_pib', 'ano_outros', 'ano_juros_mais_pib', 'fontes'])
  for n, a, b in MAND:
    r2 = lambda v: round(v, 1) if v is not None else ''
    k = b - a + 1
    fs = [soma(f, a, b) for f in ('primario', 'juros', 'cambio', 'pib')]
    d0, d1 = val('dlsp', a - 1), val('dlsp', b)
    outros = round(d1 - d0 - sum(fs), 1) if '' not in fs and d0 is not None and d1 is not None else ''
    jp = round(fs[1] + fs[3], 1) if '' not in fs else ''
    pa = lambda v: round(v / k, 1) if v != '' else ''
    w.writerow([n, f'{a}-{b}', k, round(sum(prim_gc[x] for x in range(a, b + 1)) / k, 2),
                r2(val('dbgg', a - 1)), r2(val('dbgg', b)), r2(d0), r2(d1), *fs, outros, jp,
                *[pa(v) for v in fs], pa(outros), pa(jp),
                f'primario: RTN 2.1-A ({RTN}); divida e fatores: BCB (I-divida-historico.csv, I-divida-fatores.csv)'])
print(open(os.path.join(AQUI, '..', '..', 'I-divida-por-mandato.csv')).read())

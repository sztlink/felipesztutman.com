#!/usr/bin/env python3
# Frente PO. Baixa os documentos do PLOA 2027 usados na ponte de receita, um por vez, com pausa de 4 s.
# A Nota Tecnica Conjunta das Consultorias (congressonacional.leg.br) nao resolvia em DNS em 24/10/2026 e ficou de fora.
# Registra data, descricao, arquivo, url e sha256 em downloads.tsv (acrescenta; nao apaga linhas antigas).
import hashlib, os, sys, time, urllib.request, datetime
AQUI = os.path.dirname(os.path.abspath(__file__)); FON = os.path.join(AQUI, 'fontes')
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'
G = 'https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/ploa-2027/'
ARQ = [
  ('MPO, PLOA 2027, Mensagem Presidencial (Volume I)', 'ploa2027_mensagem_presidencial.pdf', G + 'mensagem-presidencial.pdf/@@display-file/file'),
  ('MPO, PLOA 2027, Volume IV inciso 11, grade de parametros macroeconomicos', 'ploa2027_vol4_inc11_grade_parametros.xlsx', G + 'volume_4_inciso_11_grade_de_parametros.xlsx/@@download/file'),
  ('MPO e MF, apresentacao do PLOA 2027 de 31/08/2026', 'ploa2027_apresentacao_book.pdf', G + '2026_08_31-9h50-00_book_oc_ploa_2026_2027-1.pdf/@@display-file/file'),
]
so = set(sys.argv[1:])
os.makedirs(FON, exist_ok=True)
tsv = os.path.join(AQUI, 'downloads.tsv')
if not os.path.exists(tsv): open(tsv, 'w').write('data\tdescricao\tarquivo\turl\tsha256\n')
for i, (d, a, u) in enumerate(ARQ):
  if so and a not in so: continue
  if i: time.sleep(4)
  dados = urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=120).read()
  open(os.path.join(FON, a), 'wb').write(dados)
  h = hashlib.sha256(dados).hexdigest()
  open(tsv, 'a').write(f'{datetime.date.today()}\t{d}\tfontes/{a}\t{u}\t{h}\n')
  print(a, len(dados), h)

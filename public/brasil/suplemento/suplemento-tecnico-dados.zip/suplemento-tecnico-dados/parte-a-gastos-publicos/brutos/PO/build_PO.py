#!/usr/bin/env python3
# Frente PO. Ponte da receita primaria liquida do Governo Central, da reprogramacao de 2026 (base do PLOA, 3a avaliacao
# bimestral) ao PLOA 2027, pela Tabela 9 da Mensagem Presidencial (Demonstrativo dos Resultados Primario e Nominal).
# Aritmetica contabil (classe A): variacao de cada linha = efeito do PIB nominal (valor de 2026 vezes o crescimento nominal
# do PIB da grade do PLOA, separado em crescimento real e precos) + o que vai alem do PIB (mudanca da proporcao do PIB).
# O "alem do PIB" nao e medida nova por si: junta medida, premissa de reforma, preco de petroleo, dividendos e elasticidade.
# Medidas com valor so onde o PLOA publica o valor (Tabela 11, Imposto Seletivo como fonte condicionada).
# Entradas: brutos/PO/fontes (baixa_PO.py), MK-pldo-execucao.csv, brutos/D/rardp_4bim2026_apresentacao.pdf.
# Saida: PO-ponte-receita-2027.csv na raiz do dossie.
import csv, os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.join(AQUI, '..', '..'); FON = os.path.join(AQUI, 'fontes')
sys.path.insert(0, os.path.expanduser('~/.local/lib/pdftools'))
sys.path.insert(0, os.path.expanduser('~/.local/lib/python3.12/site-packages'))
import fitz, openpyxl
num = lambda v: float(v.replace('.', '').replace(',', '.'))
MSG = os.path.join(FON, 'ploa2027_mensagem_presidencial.pdf')
URL_MSG = 'https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/ploa-2027/mensagem-presidencial.pdf/@@display-file/file'
URL_GRADE = 'https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/ploa-2027/volume_4_inciso_11_grade_de_parametros.xlsx/@@download/file'
doc = fitz.open(MSG)
pag = lambda a, b: re.sub(r'\s+', ' ', ' '.join(doc[i].get_text() for i in range(a - 1, b)))
t9 = pag(98, 100)
assert 'Tabela 9 - Demonstrativo dos Resultados Primário e Nominal do Governo Central' in pag(97, 98)
assert 'Realizado 2025 LOA 2026 Reprogramação 2026 PLOA 2027' in t9
NUM = r'-?\d{1,3}(?:\.\d{3})*,\d'
def linha(cod, n=8):
  m = re.search(r'(?<![\w.])' + re.escape(cod) + r' (?:[^\d-]|-(?!\d))*?((?:' + NUM + r' ){%d})' % n, t9 + ' ')
  v = [num(x) for x in m.group(1).split()]
  return v
T = {}  # codigo -> (2025, LOA 2026, reprog 2026, PLOA 2027) em R$ milhoes
COD = ['I.', 'I.1.', 'I.1.1.', 'I.1.2.', 'I.1.3.', 'I.1.4.', 'I.1.7.', 'I.1.8.', 'I.1.9.', 'I.1.11.', 'I.1.12.', 'I.2.', 'I.3.', 'I.4.',
       'I.4.1.', 'I.4.2.', 'I.4.3.', 'I.4.4.', 'I.4.5.', 'I.4.6.', 'I.4.7.', 'I.4.8.', 'II.', 'II.1.', 'II.2.', 'II.3.', 'II.4.', 'II.5.', 'II.6.', 'III.']
for c in COD:
  v = linha(c); T[c] = v[0::2]
for c in ('I.1.5.', 'I.1.6.'):  # Imposto Seletivo e CBS, so no PLOA 2027
  v = linha(c, 2); T[c] = [0.0, 0.0, 0.0, v[0]]
m = re.search(r'IV\.3\.19\. Fundo de Compensação aos Estados pela substituição do IPI pelo Imposto Seletivo ((?:' + NUM + r' ){8})', t9)
FUNDO_IS = [num(x) for x in m.group(1).split()][6]  # coluna PLOA 2027 em R$ milhoes
m = re.search(r'V\. PRIMÁRIO GOVERNO CENTRAL \(III - IV\) ((?:' + NUM + r' ){8})', t9)
PRIM = [num(x) for x in m.group(1).split()][0::2]
m = re.search(r'IV\. DESPESAS ((?:' + NUM + r' ){8})', t9)
DESP = [num(x) for x in m.group(1).split()][0::2]
# identidades da tabela
assert abs(T['I.'][3] - T['II.'][3] - T['III.'][3]) < 0.2 and abs(T['I.'][2] - T['II.'][2] - T['III.'][2]) < 0.2
rfb = ['I.1.1.', 'I.1.2.', 'I.1.3.', 'I.1.4.', 'I.1.5.', 'I.1.6.', 'I.1.7.', 'I.1.8.', 'I.1.9.', 'I.1.11.', 'I.1.12.']
for k in (2, 3):
  assert abs(sum(T[c][k] for c in rfb) - T['I.1.'][k]) < 0.5, (k, sum(T[c][k] for c in rfb), T['I.1.'][k])
  assert abs(sum(T[c][k] for c in T if c.startswith('I.4.') and c != 'I.4.') - T['I.4.'][k]) < 0.5
  assert abs(sum(T[c][k] for c in T if c.startswith('II.') and c != 'II.') - T['II.'][k]) < 0.5
  assert abs(T['I.1.'][k] + T['I.2.'][k] + T['I.3.'][k] + T['I.4.'][k] - T['I.'][k]) < 0.5
  assert abs(T['III.'][k] - DESP[k] - PRIM[k]) < 1.0  # a tabela publica arredondada (0,6 de diferenca em 2027)
# texto da mensagem: base de calculo, renuncias, IS condicionado, compensacao da meta
tx = re.sub(r'(\w)- (\w)', r'\1\2', pag(1, len(doc)))  # tira a hifenizacao de fim de linha
assert 'acréscimo de 6,9% em relação à estimativa da 3ª avaliação bimestral de receitas e despesas para o ano de 2026' in tx
assert 'a receita proveniente desse tributo foi classificada como fonte condicionada no PLOA 2027' in tx
m = re.search(r'permite-se compensar o valor de R\$ ([\d,]+) bilhões \(([\d,]+)% do PIB\)', tx); COMP_TXT = (num(m.group(1)), num(m.group(2)))
m = re.search(r'resultado primário após essa compensação fica previsto em superávit de R\$ ([\d,]+) bilhões, o que corresponde a ([\d,]+)% do PIB', tx); APOS = (num(m.group(1)), num(m.group(2)))
t10 = tx[tx.index('Tabela 10 - Sentenças Judiciais Referentes à Emenda Constitucional nº 136, de 2025 Discriminação'):][:600]
T10 = {k: num(re.search(re.escape(k) + r' (' + NUM + ')', t10).group(1)) for k in
       ('Projetos Estratégicos de Defesa', 'Fundo Social - Recursos destinados à Educação Pública e à Saúde (art. 6º Lei 15.164/2025)', 'Sentenças Judiciais Referentes à Emenda Constitucional nº 136', 'Total')}
t11 = tx[tx.index('Tabela 11 - Medidas Legislativas com efeitos negativos na receita consideradas no PLOA 2027 REDUÇÃO DE'):][:1600]
REN = []
for rot, desc in (('Portaria CNPq', 'Definição da Cota de Importação para 2027'), ('Copa Fifa Feminina 2027', 'Medidas Tributárias e Aduaneiras referentes à realização da Copa do Mundo Feminina de 2027'),
                  ('Pronon/Pronas', 'Projeto de Lei que prorroga a vigência do Pronon/Pronas'), ('Limite do MEI', 'Projeto de Lei Complementar que amplia os limites do MEI'),
                  ('LC 235/2026, art. 7º', None), ('LC 235/2026, art. 10', None)):
  if desc:
    v = re.search(re.escape(rot + ' ' + desc) + r' (-[\d.]+)', t11).group(1)
  else:
    v = re.search((r'art\. 7º (-[\d.]+)' if '7º' in rot else r'art\. 10º (-[\d.]+)'), t11).group(1)
  REN.append((rot, desc or 'renúncias para mitigar o choque de energia e benefícios de minerais críticos, fertilizantes e Copa Feminina', float(v.replace('.', ''))))
REN_TOT = float(re.search(r'TOTAL (-[\d.]+) Fonte: Secretaria Especial da Receita Federal', t11).group(1).replace('.', ''))
assert abs(sum(r[2] for r in REN) - REN_TOT) < 0.5
m = re.search(r'efeitos negativos na arrecadação que advirão de novas renúncias de receita, no montante de R\$ ([\d,]+) bilhões', tx); assert abs(num(m.group(1)) * 1000 + REN_TOT) < 50
# grade de parametros do PLOA (SPE/MF): PIB nominal, real e deflator
ws = openpyxl.load_workbook(os.path.join(FON, 'ploa2027_vol4_inc11_grade_parametros.xlsx'), data_only=True)['Resumo']
G = {}
for r in ws.iter_rows(values_only=True):
  if hasattr(r[0], 'year'): G[r[0].year] = dict(pib=r[1] / 1000, real=r[3], defl=r[5])
P26, P27 = G[2026]['pib'], G[2027]['pib']
gn = P27 / P26 - 1; gr = G[2027]['real'] / 100
assert abs((1 + gr) * (1 + G[2027]['defl'] / 100) - 1 - gn) < 1e-9
assert abs(T['III.'][3] / 1000 / P27 * 100 - 19.27) < 0.006  # 19,27% do PIB no texto da mensagem
# PLDO 2027 (frente MK) e 4o bimestre de 2026 (frente D)
tp = re.sub(r'\s+', ' ', ' '.join(p.get_text() for p in fitz.open(os.path.join(RAIZ, 'brutos', 'S', 'pldo2027-anexo-iv-02-metas-fiscais.pdf'))))
g1 = tp[tp.index('Tabela 1: Grade de Parâmetros Macroeconômicos 2026 – 2030 Parâmetros'):]
PLDO_PIB27 = num(re.search(r'PIB nominal \(R\$ bilhões\) ((?:-?[\d.,]+ ){6})', g1).group(1).split()[2])  # mesma leitura de build_S.py
MK = {(r['serie'], r['ano']): r for r in csv.DictReader(open(os.path.join(RAIZ, 'MK-pldo-execucao.csv'), encoding='utf-8'))}
mk = lambda s, c='valor_rs_bi': float(MK[(s, '2027')][c])
r4 = re.sub(r'\s+', ' ', ' '.join(p.get_text() for p in fitz.open(os.path.join(RAIZ, 'brutos', 'D', 'rardp_4bim2026_apresentacao.pdf'))))
m = re.search(r'3\. Receita Líquida de Transferências \(1\) - \(2\) ([\d.,]+) ([\d,]+) ([\d.,]+) ([\d,]+)', r4)
RPL_3B, RPL_4B = num(m.group(1)), num(m.group(3))
assert abs(RPL_3B * 1000 - T['III.'][2]) < 100  # a reprogramacao da Tabela 9 e a do 3o bimestre

bi = lambda x: round(x / 1000, 2)
FT9 = 'PLOA 2027, Mensagem Presidencial, Tabela 9, p. 98 a 100'
FG = 'PLOA 2027, Volume IV inciso XI, grade de parametros SPE/MF (aba Resumo)'
out = []
def add(bloco, item, v26, v27, sinal=1, classe='A', fonte=FT9, nota=''):
  d = (v27 - v26) * sinal
  ef = v26 * gn * sinal if v26 is not None else None
  out.append(dict(bloco=bloco, item=item, valor_2026_rs_bi=bi(v26) if v26 != '' else '', valor_2027_rs_bi=bi(v27) if v27 != '' else '',
                  efeito_na_receita_liquida_rs_bi=bi(d), efeito_pib_nominal_rs_bi=bi(ef), alem_do_pib_rs_bi=bi(d - ef),
                  alem_do_pib_pct_pib_2027=round((d - ef) / 1000 / P27 * 100, 3), classe=classe, fonte=fonte, nota=nota))
R26, R27 = T['III.'][2], T['III.'][3]
out.append(dict(bloco='1. total', item='Receita primária líquida do Governo Central', valor_2026_rs_bi=bi(R26), valor_2027_rs_bi=bi(R27),
                efeito_na_receita_liquida_rs_bi=bi(R27 - R26), efeito_pib_nominal_rs_bi=bi(R26 * gn), alem_do_pib_rs_bi=bi(R27 - R26 - R26 * gn),
                alem_do_pib_pct_pib_2027=round((R27 - R26 - R26 * gn) / 1000 / P27 * 100, 3), classe='A', fonte=FT9 + '; ' + FG,
                nota=f'2026 = reprogramação (3ª avaliação bimestral, base declarada do PLOA); % do PIB {round(R26 / 1000 / P26 * 100, 2)} em 2026 e {round(R27 / 1000 / P27 * 100, 2)} em 2027'))
out.append(dict(bloco='1. total', item='dos quais, crescimento real do PIB', valor_2026_rs_bi='', valor_2027_rs_bi='', efeito_na_receita_liquida_rs_bi=bi(R26 * gr),
                efeito_pib_nominal_rs_bi=bi(R26 * gr), alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A', fonte=FG, nota=f'PIB real {round(100 * gr, 2)}% em 2027'))
out.append(dict(bloco='1. total', item='dos quais, preços (deflator do PIB)', valor_2026_rs_bi='', valor_2027_rs_bi='', efeito_na_receita_liquida_rs_bi=bi(R26 * (gn - gr)),
                efeito_pib_nominal_rs_bi=bi(R26 * (gn - gr)), alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A', fonte=FG,
                nota=f'deflator {round(G[2027]["defl"], 2)}%; PIB nominal {round(P26, 1)} e {round(P27, 1)} R$ bi; crescimento nominal {round(100 * gn, 2)}%'))
# por componente
REF = ['I.1.2.', 'I.1.7.', 'I.1.8.', 'I.1.5.', 'I.1.6.']
v = lambda cs, k: sum(T[c][k] for c in cs)
add('2. reforma do consumo', 'PIS, Cofins e IPI (2026) contra CBS, Imposto Seletivo e residuais (2027)', v(REF, 2), v(REF, 3), classe='A',
    nota='o PLOA estima os novos tributos com a premissa de manter a arrecadação federal em proporção do PIB (LC 214, art. 353); estimativa preliminar, alíquota de referência ainda não definida; parte do Imposto Seletivo é repartida (bloco 5) e há um fundo de compensação aos estados pela troca do IPI (despesa, bloco 7)')
for c, nm in (('I.1.6.', 'CBS'), ('I.1.5.', 'Imposto Seletivo (fonte condicionada a lei ordinária)'), ('I.1.2.', 'IPI (só Zona Franca em 2027)'), ('I.1.7.', 'Cofins (residual)'), ('I.1.8.', 'PIS/Pasep (residual)')):
  add('2. reforma do consumo, detalhe', nm, T[c][2], T[c][3], nota='detalhe do bloco 2, não somar de novo')
for c, nm in (('I.1.3.', 'Imposto de Renda'), ('I.1.9.', 'CSLL'), ('I.1.1.', 'Imposto de Importação'), ('I.1.4.', 'IOF'), ('I.1.11.', 'Cide-Combustíveis'), ('I.1.12.', 'Outras administradas pela RFB'), ('I.2.', 'Incentivos fiscais')):
  add('3. demais receitas da RFB', nm, T[c][2], T[c][3])
add('3. demais receitas da RFB', 'Arrecadação líquida para o RGPS', T['I.3.'][2], T['I.3.'][3], nota='inclui a última etapa da reoneração da folha (Lei 14.973/2024), sem valor separado no PLOA')
for c, nm in (('I.4.6.', 'Dividendos e participações'), ('I.4.5.', 'Exploração de recursos naturais'), ('I.4.3.', 'Contribuição para o plano de seguridade do servidor'),
              ('I.4.4.', 'Salário-educação'), ('I.4.1.', 'Concessões e permissões'), ('I.4.7.', 'Receita própria e de convênios'), ('I.4.8.', 'Demais receitas'), ('I.4.2.', 'Complemento para o FGTS')):
  add('4. receitas não administradas', nm, T[c][2], T[c][3])
for c, nm in (('II.4.', 'FPE, FPM e IPI-exportação'), ('II.2.', 'Exploração de recursos naturais'), ('II.3.', 'Salário-educação'), ('II.5.', 'Fundos constitucionais'), ('II.1.', 'Cide-Combustíveis'), ('II.6.', 'Demais')):
  add('5. transferências a estados e municípios (com sinal invertido)', nm, T[c][2], T[c][3], sinal=-1, nota='transferência menor aumenta a receita líquida')
comp = [r for r in out if r['bloco'] in ('2. reforma do consumo', '3. demais receitas da RFB', '4. receitas não administradas') or r['bloco'].startswith('5.')]
assert abs(sum(r['efeito_na_receita_liquida_rs_bi'] for r in comp) - bi(R27 - R26)) < 0.1, sum(r['efeito_na_receita_liquida_rs_bi'] for r in comp)
# medidas com valor publicado
for rot, desc, val in REN:
  out.append(dict(bloco='6. medidas com valor no PLOA', item=f'{rot}: {desc}', valor_2026_rs_bi='', valor_2027_rs_bi='', efeito_na_receita_liquida_rs_bi=round(val / 1000, 3),
                  efeito_pib_nominal_rs_bi='', alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A', fonte='PLOA 2027, Mensagem Presidencial, Tabela 11, p. 108 (RFB/MF)',
                  nota='renúncia nova já incorporada na receita da RFB; valor estimado pelo governo, sem conferência ex post'))
out.append(dict(bloco='6. medidas com valor no PLOA', item='Total das renúncias novas (Tabela 11)', valor_2026_rs_bi='', valor_2027_rs_bi='', efeito_na_receita_liquida_rs_bi=round(REN_TOT / 1000, 3),
                efeito_pib_nominal_rs_bi='', alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A', fonte='PLOA 2027, Mensagem Presidencial, Tabela 11, p. 108 e p. 106', nota='a mensagem cita R$ 4,2 bi'))
out.append(dict(bloco='6. medidas com valor no PLOA', item='Imposto Seletivo, tributo novo da LC 214/2025, depende de lei ordinária com as alíquotas', valor_2026_rs_bi='', valor_2027_rs_bi=bi(T['I.1.5.'][3]),
                efeito_na_receita_liquida_rs_bi=bi(T['I.1.5.'][3]), efeito_pib_nominal_rs_bi='', alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A',
                fonte='PLOA 2027, Mensagem Presidencial, Tabela 9 e p. 107 (fonte condicionada, art. 140 do PLDO 2027)',
                nota='valor bruto; parte é repartida com estados e municípios e o PLOA prevê despesa de compensação pela troca do IPI (bloco 7); a CBS também é estimativa preliminar'))
for nm, ref in (('Reoneração da folha, última etapa em 2027', 'Lei 14.973/2024, mensagem p. 29'),
                ('LC 224/2025: corte de 10% em benefícios tributários, CSLL de fintechs, IRRF de JCP de 15% para 17,5%, bets', 'mensagem p. 28 e 29'),
                ('Adicional de CSLL do Pilar 2 da OCDE', 'Lei 15.079/2024, mensagem p. 29'),
                ('IOF recalibrado', 'Decreto 12.499/2025, mensagem p. 29'),
                ('Imposto de importação de mais de 1.000 NCM', 'Resolução Gecex 852/2026, mensagem p. 30')):
  out.append(dict(bloco='6b. medidas citadas sem valor no PLOA', item=nm, valor_2026_rs_bi='', valor_2027_rs_bi='', efeito_na_receita_liquida_rs_bi='', efeito_pib_nominal_rs_bi='',
                  alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='C', fonte='PLOA 2027, Mensagem Presidencial, ' + ref,
                  nota='a mensagem diz que a medida está na base de arrecadação, sem publicar o efeito em 2027; quanto dela entra no "além do PIB" não é demonstrado'))
# despesa ligada a reforma e comparacao com o que o dossie ja usa
out.append(dict(bloco='7. despesa ligada à reforma', item='Fundo de compensação aos estados pela substituição do IPI pelo Imposto Seletivo', valor_2026_rs_bi=0.0, valor_2027_rs_bi=bi(FUNDO_IS),
                efeito_na_receita_liquida_rs_bi='', efeito_pib_nominal_rs_bi='', alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A', fonte=FT9 + ' (IV.3.19)',
                nota='entra na despesa, não na receita; reduz o ganho líquido da queda das transferências'))
cmp_ = [('Receita primária líquida 2027', mk('receita_primaria_liquida'), R27 / 1000, 'MK-pldo-execucao.csv (PLDO Tabela 5)'),
        ('Despesa primária total 2027', mk('despesa_primaria_total'), DESP[3] / 1000, 'MK-pldo-execucao.csv (PLDO Tabela 5)'),
        ('Primário do Governo Central 2027, antes das exclusões da meta', mk('primario_projetado'), PRIM[3] / 1000, 'MK-pldo-execucao.csv (PLDO Tabela 3)'),
        ('Despesas excluídas da meta 2027', mk('exclusoes_da_meta'), T10['Total'] / 1000, 'MK-pldo-execucao.csv (PLDO Tabela 3); PLOA Tabela 10, p. 103'),
        ('Meta de 2027 (PLDO) contra primário para a meta depois das exclusões (PLOA)', mk('meta'), APOS[0], 'MK-pldo-execucao.csv (meta do PLDO, 0,50% do PIB); PLOA mensagem p. 24'),
        ('PIB nominal 2027', PLDO_PIB27, P27, 'PLDO 2027 Anexo IV.2, Tabela 1 (brutos/S/pldo2027-anexo-iv-02-metas-fiscais.pdf) e grade do PLOA')]
for nm, a, b, f in cmp_:
  pa = mk({'Receita primária líquida 2027': 'receita_primaria_liquida', 'Despesa primária total 2027': 'despesa_primaria_total', 'Primário do Governo Central 2027, antes das exclusões da meta': 'primario_projetado',
           'Despesas excluídas da meta 2027': 'exclusoes_da_meta', 'Meta de 2027 (PLDO) contra primário para a meta depois das exclusões (PLOA)': 'meta'}.get(nm, 'receita_primaria_liquida'), 'pct_pib') if nm != 'PIB nominal 2027' else ''
  pb = round(b / P27 * 100, 2) if nm != 'PIB nominal 2027' else ''
  out.append(dict(bloco='8. PLDO 2027 (o que o dossiê usa) contra PLOA 2027', item=nm, valor_2026_rs_bi=round(a, 2), valor_2027_rs_bi=round(b, 2), efeito_na_receita_liquida_rs_bi=round(b - a, 2),
                  efeito_pib_nominal_rs_bi='', alem_do_pib_rs_bi='', alem_do_pib_pct_pib_2027='', classe='A', fonte=f + '; ' + FT9,
                  nota=f'nesta linha valor_2026 = PLDO (abr/2026) e valor_2027 = PLOA (ago/2026), os dois para 2027; % do PIB {pa} no PLDO e {pb} no PLOA' if pa != '' else 'nesta linha valor_2026 = PLDO e valor_2027 = PLOA, os dois para 2027'))
out[-2]['nota'] += f'; a mensagem p. 24 fala em compensar R$ {COMP_TXT[0]} bi ({COMP_TXT[1]}% do PIB), a Tabela 10 soma R$ {round(T10["Total"] / 1000, 2)} bi, e o resultado após a compensação é {APOS[1]}% do PIB'
out.append(dict(bloco='9. base alternativa', item='Receita primária líquida 2026 na 4ª avaliação bimestral (set/2026)', valor_2026_rs_bi=RPL_4B, valor_2027_rs_bi=bi(R27),
                efeito_na_receita_liquida_rs_bi=round(R27 / 1000 - RPL_4B, 2), efeito_pib_nominal_rs_bi=round(RPL_4B * gn, 2), alem_do_pib_rs_bi=round(R27 / 1000 - RPL_4B - RPL_4B * gn, 2),
                alem_do_pib_pct_pib_2027=round((R27 / 1000 - RPL_4B - RPL_4B * gn) / P27 * 100, 3), classe='A', fonte='RARDP 4º bimestre 2026, apresentação (brutos/D/rardp_4bim2026_apresentacao.pdf); ' + FT9,
                nota=f'o PLOA foi feito sobre a 3ª avaliação ({RPL_3B} R$ bi); a 4ª reduziu a receita líquida de 2026 em {round(RPL_3B - RPL_4B, 1)} R$ bi'))
for i, r in enumerate(out, 1): r['ordem'] = i
cab = ['ordem', 'bloco', 'item', 'valor_2026_rs_bi', 'valor_2027_rs_bi', 'efeito_na_receita_liquida_rs_bi', 'efeito_pib_nominal_rs_bi', 'alem_do_pib_rs_bi', 'alem_do_pib_pct_pib_2027', 'classe', 'fonte', 'nota']
with open(os.path.join(RAIZ, 'PO-ponte-receita-2027.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.DictWriter(f, fieldnames=cab); w.writeheader()
  for r in out: w.writerow({**r, 'fonte': r['fonte'] + (f' ({URL_MSG})' if 'Mensagem' in r['fonte'] else '')})
print('PO ok', len(out), 'linhas; RPL', bi(R26), '->', bi(R27), 'delta', bi(R27 - R26), 'PIB', bi(R26 * gn), 'alem', bi(R27 - R26 - R26 * gn))

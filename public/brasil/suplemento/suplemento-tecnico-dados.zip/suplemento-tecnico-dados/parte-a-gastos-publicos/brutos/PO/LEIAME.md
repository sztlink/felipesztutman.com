# Frente PO, ponte da receita primária líquida de 2026 a 2027 pelo PLOA 2027

Feita em 24/10/2026. Pedido aberto desde a v12.6 ("ponte de receita pelo PLOA 2027"), pode sair contra qualquer lado.

## Fontes
- Mensagem Presidencial do PLOA 2027 (MPO, 31/08/2026), Tabela 9 (Demonstrativo dos Resultados Primário e Nominal do Governo
  Central, p. 98 a 100), Tabela 10 (exclusões da meta, p. 103), Tabela 11 (renúncias novas, p. 108) e texto das p. 22 a 30 e 106 a 109.
- Grade de parâmetros da SPE/MF usada no PLOA (Volume IV, inciso XI), aba Resumo: PIB nominal, real e deflator.
- Para comparar: `MK-pldo-execucao.csv` (PLDO 2027), `brutos/S/pldo2027-anexo-iv-02-metas-fiscais.pdf` (PIB do PLDO) e
  `brutos/D/rardp_4bim2026_apresentacao.pdf` (receita de 2026 na 4ª avaliação).
- Não baixada: a Nota Técnica Conjunta das Consultorias de Orçamento sobre o PLOA 2027 (congressonacional.leg.br não resolvia em
  DNS em 24/10/2026) e o Raio X da Câmara (404). Elas poderiam trazer estimativa própria das medidas.

## Método (classe A, aritmética contábil)
- Base de 2026 = "Reprogramação 2026" da Tabela 9, que é a 3ª avaliação bimestral, a base que o próprio PLOA declara (p. 106).
  A 4ª avaliação (set/2026) baixou a receita líquida de 2026 em R$ 6,8 bi; a ponte com essa base fica no bloco 9.
- Para cada linha da Tabela 9: variação = efeito do PIB nominal (valor de 2026 vezes 8,04% de crescimento nominal da grade,
  separado em 2,46% real e 5,44% de deflator) + "além do PIB" (mudança da proporção do PIB). Transferências entram com sinal
  invertido. A soma das linhas confere com a variação da receita líquida.
- "Além do PIB" não é sinônimo de medida nova. Junta medida, premissa da reforma do consumo, petróleo, dividendos e elasticidade.
- Medida com valor só onde o PLOA publica o valor: renúncias novas da Tabela 11 (R$ -4,2 bi) e o Imposto Seletivo (R$ 42,0 bi,
  fonte condicionada a lei ordinária). Medidas que a mensagem cita sem valor (reoneração da folha, LC 224/2025, Pilar 2, IOF,
  Gecex 852) ficam como classe C: estão na base, o efeito em 2027 não é demonstrado.

## Números principais (PO-ponte-receita-2027.csv)
- Receita primária líquida: R$ 2.593,6 bi (2026, 18,95% do PIB) para R$ 2.848,7 bi (2027, 19,27%), +R$ 255,1 bi.
  R$ 208,5 bi vêm do PIB nominal (63,8 real, 144,7 preços) e R$ 46,6 bi (0,32 ponto do PIB) vão além do PIB.
- Reforma do consumo: PIS, Cofins e IPI de 2026 (R$ 630,2 bi) contra CBS, IS e residuais de 2027 (R$ 750,4 bi), R$ 69,6 bi além
  do PIB, sob a premissa do PLOA de manter a arrecadação federal em proporção do PIB (estimativa preliminar).
- Transferências a estados e municípios caem R$ 33,0 bi (R$ 84,8 bi abaixo do que o PIB daria, FPE e FPM respondem por 58,1); na
  despesa aparece um fundo de compensação novo pela troca do IPI pelo IS, R$ 33,8 bi.
- Puxam para baixo: Imposto de Renda (R$ -48,1 bi além do PIB), dividendos (R$ -29,0 bi, de 55,5 para 30,9), outras da RFB
  (R$ -23,1 bi), CSLL (R$ -13,7 bi), IOF (R$ -12,4 bi), recursos naturais (R$ -9,7 bi). RGPS soma R$ 28,1 bi além do PIB.
- Contra o que o dossiê usa (MK, PLDO de abril): receita líquida de 2027 R$ 80,5 bi maior no PLOA, despesa R$ 69,8 bi maior,
  primário antes das exclusões de 0,05% (R$ 8,0 bi) para 0,13% do PIB (R$ 18,6 bi), exclusões de R$ 65,7 bi para R$ 64,7 bi, e
  primário para a meta de R$ 83,4 bi (0,56% do PIB) contra a meta de R$ 73,2 bi (0,50%). A mensagem fala em compensar R$ 64,6 bi
  (p. 24) e a Tabela 10 soma R$ 64,7 bi.

## Limites
- Os números de 2027 são projeção do Executivo, não execução. A ponte decompõe a projeção, não testa se ela é realista.
- A Tabela 9 é arredondada (R$ 0,6 mi de diferença na identidade do primário de 2027).
- Sem a nota das Consultorias, não há estimativa independente das medidas.

## Como rodar
```
cd /tmp && python3 -I <pacote>/brutos/PO/baixa_PO.py      # baixa os três arquivos, um por vez
cd /tmp && python3 -I <pacote>/brutos/PO/build_PO.py
```

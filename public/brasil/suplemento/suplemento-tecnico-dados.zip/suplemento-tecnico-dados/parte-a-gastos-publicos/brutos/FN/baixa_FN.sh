#!/usr/bin/env bash
# Frente FN, funcoes da Uniao (Cultura, Agricultura, Organizacao Agraria, Gestao Ambiental) por ano no SIOP, por subfuncao, modalidade de aplicacao e
# grupo de despesa (a modalidade 91 e intra-orcamentaria e sai na montagem; o GND 5, inversoes financeiras, e emprestimo e fica separado). Uma consulta por vez, com pausa. Uso: bash baixa_FN.sh 2000 2025
O="$(cd "$(dirname "$0")" && pwd)/fontes"; mkdir -p "$O"
for y in $(seq "$1" "$2"); do
  [ -s "$O/siop_funcoes_sf_$y.csv" ] && continue
  q="PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?fl ?sfl ?mod ?gnd (SUM(?ini) AS ?dot_ini) (SUM(?atu) AS ?dot_atual) (SUM(?liq) AS ?liquidado) (SUM(?pag) AS ?pago)
FROM <http://orcamento.dados.gov.br/$y/>
WHERE { ?s a loa:ItemDespesa ; loa:temFuncao ?f ; loa:temSubfuncao ?sf ; loa:temModalidadeAplicacao ?mod ; loa:temGND ?gnd ; loa:valorDotacaoInicial ?ini ; loa:valorLeiMaisCredito ?atu ; loa:valorLiquidado ?liq ; loa:valorPago ?pag . ?f rdfs:label ?fl . ?sf rdfs:label ?sfl . FILTER(REGEX(?fl, 'Cultura|Agricultura|Gestão Ambiental|Organização Agrária', 'i')) }
GROUP BY ?fl ?sfl ?mod ?gnd"
  curl -s -m 900 "https://www1.siop.planejamento.gov.br/sparql/" --data-urlencode "query=$q" -H "Accept: text/csv" -o "$O/siop_funcoes_sf_$y.csv"
  echo "$y $(wc -l < "$O/siop_funcoes_sf_$y.csv")"; sleep 5
done
# acoes do GND 5 (inversoes financeiras) nas quatro funcoes, de 2023 a 2025, para nomear o que e emprestimo e o que e fomento
for y in 2023 2024 2025; do
  [ -s "$O/siop_acoes_inversoes_$y.csv" ] && continue
  q="PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?fl ?al (SUM(?liq) AS ?liquidado)
FROM <http://orcamento.dados.gov.br/$y/>
WHERE { ?s a loa:ItemDespesa ; loa:temFuncao ?f ; loa:temAcao ?a ; loa:temGND ?g ; loa:temModalidadeAplicacao ?mod ; loa:valorLiquidado ?liq . ?f rdfs:label ?fl . ?a rdfs:label ?al . FILTER(REGEX(?fl, 'Cultura|Agricultura|Gestão Ambiental|Organização Agrária', 'i')) FILTER(STRENDS(STR(?g), '/5')) FILTER(!STRENDS(STR(?mod), '/91')) }
GROUP BY ?fl ?al ORDER BY ?fl DESC(?liquidado)"
  curl -s -m 900 "https://www1.siop.planejamento.gov.br/sparql/" --data-urlencode "query=$q" -H "Accept: text/csv" -o "$O/siop_acoes_inversoes_$y.csv"
  echo "acoes $y $(wc -l < "$O/siop_acoes_inversoes_$y.csv")"; sleep 5
done
# acoes da cultura fora da funcao Cultura (transferencias a estados e municipios em Encargos Especiais e outras funcoes), 2015 a 2025
for y in $(seq 2015 2025); do
  [ -s "$O/siop_acoes_cultura_fora_$y.csv" ] && continue
  q="PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?fl ?al ?gnd (SUM(?liq) AS ?liquidado) (SUM(?pag) AS ?pago)
FROM <http://orcamento.dados.gov.br/$y/>
WHERE { ?s a loa:ItemDespesa ; loa:temFuncao ?f ; loa:temAcao ?a ; loa:temGND ?gnd ; loa:temModalidadeAplicacao ?mod ; loa:valorLiquidado ?liq ; loa:valorPago ?pag . ?f rdfs:label ?fl . ?a rdfs:label ?al . FILTER(!REGEX(?fl, '^Cultura')) FILTER(REGEX(?al, 'Cultur|Aldir Blanc|Paulo Gustavo|Audiovisual|Rouanet', 'i')) FILTER(!STRENDS(STR(?mod), '/91')) }
GROUP BY ?fl ?al ?gnd ORDER BY DESC(?liquidado)"
  curl -s -m 900 "https://www1.siop.planejamento.gov.br/sparql/" --data-urlencode "query=$q" -H "Accept: text/csv" -o "$O/siop_acoes_cultura_fora_$y.csv"
  echo "cultura fora $y $(wc -l < "$O/siop_acoes_cultura_fora_$y.csv")"; sleep 5
done
# acoes da funcao Cultura, 2015 a 2025, para separar fomento, transferencias federativas, FSA e manutencao
for y in $(seq 2015 2025); do
  [ -s "$O/siop_acoes_cultura_funcao_$y.csv" ] && continue
  q="PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?al ?gnd ?mod (SUM(?liq) AS ?liquidado)
FROM <http://orcamento.dados.gov.br/$y/>
WHERE { ?s a loa:ItemDespesa ; loa:temFuncao ?f ; loa:temAcao ?a ; loa:temGND ?gnd ; loa:temModalidadeAplicacao ?mod ; loa:valorLiquidado ?liq . ?f rdfs:label ?fl . ?a rdfs:label ?al . FILTER(REGEX(?fl, '^Cultura')) FILTER(!STRENDS(STR(?mod), '/91')) }
GROUP BY ?al ?gnd ?mod ORDER BY DESC(?liquidado)"
  curl -s -m 900 "https://www1.siop.planejamento.gov.br/sparql/" --data-urlencode "query=$q" -H "Accept: text/csv" -o "$O/siop_acoes_cultura_funcao_$y.csv"
  echo "cultura funcao $y $(wc -l < "$O/siop_acoes_cultura_funcao_$y.csv")"; sleep 5
done
# registro das fontes com hash, como nas outras frentes
python3 -I - "$O" <<'PY'
import datetime, hashlib, os, sys
O = sys.argv[1]; lin = []
for a in sorted(os.listdir(O)):
  y = a.rsplit('_', 1)[1][:4]
  d = ('SIOP, funcoes Agricultura, Organizacao Agraria, Gestao Ambiental e Cultura por subfuncao, modalidade e GND, %s' if '_sf_' in a else 'SIOP, acoes da cultura fora da funcao Cultura (Encargos Especiais e outras), %s' if 'cultura_fora' in a else 'SIOP, acoes da funcao Cultura por GND e modalidade, %s' if 'cultura_funcao' in a else 'SIOP, acoes de inversao financeira (GND 5) das quatro funcoes, %s') % y
  p = os.path.join(O, a)
  lin.append('\t'.join([datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime('%Y-%m-%d'), d, 'fontes/' + a, f'https://www1.siop.planejamento.gov.br/sparql/ (grafo http://orcamento.dados.gov.br/{y}/, consulta neste script)', hashlib.sha256(open(p, 'rb').read()).hexdigest()]))
open(os.path.join(os.path.dirname(O), 'downloads.tsv'), 'w', encoding='utf-8').write('data\tdescricao\tarquivo\turl\tsha256\n' + '\n'.join(lin) + '\n')
print(len(lin), 'arquivos')
PY

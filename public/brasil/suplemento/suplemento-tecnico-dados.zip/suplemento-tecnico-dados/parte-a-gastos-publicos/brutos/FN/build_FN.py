#!/usr/bin/env python3
# Frente FN, agro, meio ambiente e cultura por mandato, de 2000 a 2025. Le as funcoes da Uniao no SIOP (baixa_FN.sh), os subsidios do
# Orcamento de Subsidios da Uniao (brutos/E, Tabela 1, 2003 a 2024), a captacao da Lei Rouanet (brutos/E, painel Salic) e o PIB da
# agropecuaria (brutos/PR, SIDRA 5932). Valores em R$ correntes e em R$ de 2025 (IPCA dez a dez). Mandato data o valor, nao atribui causa.
# Rodar: cd /tmp && python3 -P <pacote>/brutos/FN/build_FN.py   (precisa de openpyxl)
import csv, json, os, openpyxl
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..')); F = os.path.join(AQUI, 'fontes')
SIOP = 'https://www1.siop.planejamento.gov.br/sparql/ (grafo http://orcamento.dados.gov.br/{y}/, consulta em baixa_FN.sh)'
OSU = 'https://www.gov.br/planejamento/pt-br/assuntos/avaliacao-de-politicas-publicas/arquivos/orcamento-de-subsidios-da-uniao/osu_2025-anexos-publicacao.xlsx'
MANDS = [('FHC', 2000, 2002), ('Lula 1', 2003, 2006), ('Lula 2', 2007, 2010), ('Dilma', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016),
         ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2025)]
mand = lambda a: next(m for m, i, f in MANDS if i <= a <= f)
ANOS = range(2000, 2026)
IPCA = {int(r['D3C'][:4]): float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:] if r['D3C'].endswith('12')}
real = lambda v, a: v * IPCA[2025] / IPCA[a]
p6784 = {int(r['D3C']): float(r['V']) * 1e6 for r in json.load(open(os.path.join(RAIZ, 'brutos', 'A', 'sidra-6784.json'), encoding='utf-8'))[1:]}
q1846 = {r['D3C']: float(r['V']) * 1e6 for r in json.load(open(os.path.join(RAIZ, 'brutos', 'N2', 'fontes', 'ibge', 'sidra_1846_pib_corrente.json'), encoding='utf-8'))[1:]}
pib = lambda y: p6784.get(y) or sum(v for k, v in q1846.items() if k.startswith(str(y)))

# ---------- funcoes da Uniao (SIOP), liquidado, sem a modalidade 91 (intra-orcamentaria) ----------
# Gestao Ambiental se divide em duas linhas, porque a subfuncao Recursos Hidricos (obras como a transposicao do Sao Francisco) e
# metade da funcao em varios anos e nao e politica ambiental. O GND 5, inversoes financeiras, fica em coluna separada: em Agricultura e
# Gestao Ambiental sao emprestimos (Funcafe, Pronaf, refinanciamento de dividas rurais, Fundo Clima); na Cultura sao o Fundo Setorial
# do Audiovisual (investimento retornavel e financiamento), contado no total da cultura como na serie do RREO da frente CU.
LINHAS = ['Agricultura', 'Organização Agrária', 'Gestão Ambiental, sem recursos hídricos', 'Gestão Ambiental, recursos hídricos', 'Cultura']
def linha(fl, sfl):
  if fl == 'Gestão Ambiental': return LINHAS[3] if sfl == 'Recursos Hídricos' else LINHAS[2]
  return fl if fl in LINHAS else None
liq = {}
for y in ANOS:
  for r in csv.DictReader(open(os.path.join(F, f'siop_funcoes_sf_{y}.csv'), encoding='utf-8')):
    ln = linha(r['fl'].strip(), r['sfl'].strip())
    if ln is None or r['mod'].endswith('/91'): continue
    k = (y, ln, 'inversoes' if r['gnd'].endswith('/5') else 'despesa')
    liq[k] = liq.get(k, 0) + float(r['liquidado'])
lin = []
for y in ANOS:
  for ln in LINHAS:
    d, i = liq.get((y, ln, 'despesa'), 0), liq.get((y, ln, 'inversoes'), 0)
    lin.append([y, mand(y), ln, round(d / 1e9, 3), round(i / 1e9, 3), round(real(d, y) / 1e9, 3), round(real(i, y) / 1e9, 3), round(100 * d / pib(y), 4), SIOP.format(y=y)])
with open(os.path.join(RAIZ, 'FN-funcoes-uniao.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n')
  w.writerow(['ano', 'presidente', 'linha', 'despesa_rs_bi', 'inversoes_financeiras_rs_bi', 'despesa_rs_bi_2025', 'inversoes_financeiras_rs_bi_2025', 'despesa_pct_pib', 'fonte'])
  w.writerows(lin)

# ---------- subsidios (OSU, Tabela 1, R$ mil correntes, 2003 a 2024) e captacao da Rouanet ----------
wb = openpyxl.load_workbook(os.path.join(RAIZ, 'brutos', 'E', 'osu_2025-anexos-publicacao.xlsx'), read_only=True, data_only=True)
t1 = list(wb['Tab_1'].iter_rows(values_only=True)); cab = t1[2]
col = {a: cab.index(a) for a in cab if isinstance(a, int)}
osu = {}
for r in t1[3:]:
  if r[1] is None or r[2] is None: continue
  osu.setdefault(str(r[1]).strip(), {a: (r[c] if isinstance(r[c], (int, float)) else 0) * 1000 for a, c in col.items()})
# a mesma lista de equalizacoes e subvencoes agricolas da frente E (Plano Safra e apoio agricola, explicito, ja na despesa)
AGRO = ['PRONAF (Equalização)', 'Operações de Investimento Rural e Agroindustrial', 'Securitização Agrícola',
        'Subvenção Econômica ao Prêmio do Seguro Rural - PSR', 'Custeio Agropecuário', 'Garantia e Sustentação de Preços',
        'Programa Especial de Saneamento de Ativos - PESA (Explícito)', 'Recuperação da Lavoura Cacaueira (Equalização)',
        'AGF e Estoques Estratégicos', 'Garantia e Sustentação de Preços da Agricultura Familiar']
SER = [('agro_subsidio_financeiro', lambda a: sum(osu[n][a] for n in AGRO), 'OSU Tabela 1, soma das equalizacoes e subvencoes agricolas (lista da frente E), explicito, ja na despesa'),
       ('agro_subsidio_tributario', lambda a: osu['Agricultura e Agroindústria'][a], 'OSU Tabela 1, beneficio tributario Agricultura e Agroindustria, que as Tabelas 6 e 15 do mesmo arquivo rotulam como desoneracao da cesta basica, implicito'),
       ('cultura_subsidio_tributario', lambda a: osu['Cultura e Audiovisual'][a], 'OSU Tabela 1, beneficio tributario Cultura e Audiovisual, implicito'),
       ('agro_seguro_rural_psr', lambda a: osu['Subvenção Econômica ao Prêmio do Seguro Rural - PSR'][a], 'OSU Tabela 1, subvencao ao premio do seguro rural (PSR), explicito, contida no agro_subsidio_financeiro')]
sub = [[a, mand(a), s, round(fn(a) / 1e9, 3), round(real(fn(a), a) / 1e9, 3), round(100 * fn(a) / pib(a), 4), nota, OSU] for a in range(2003, 2025) for s, fn, nota in SER]
t15 = list(wb['Tabela 15'].iter_rows(values_only=True))
assert t15[4][2] == 'Agricultura e Agroindústria - Desoneração Cesta Básica'  # a linha de agricultura e agroindustria e a cesta basica
SAL = {int(r['ano']): (float(r['valor_captado_brl']), r['fonte']) for r in csv.DictReader(open(os.path.join(RAIZ, 'brutos', 'E', 'salic-captacao-por-ano.csv'), encoding='utf-8'))}
sub += [[a, mand(a), 'rouanet_captado', round(SAL[a][0] / 1e9, 3), round(real(SAL[a][0], a) / 1e9, 3), round(100 * SAL[a][0] / pib(a), 4), 'MinC, painel Salic Comparar, captacao por ano', SAL[a][1]] for a in ANOS]
sub.sort(key=lambda r: (r[2], r[0]))
with open(os.path.join(RAIZ, 'FN-subsidios-agro-cultura.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['ano', 'presidente', 'serie', 'rs_bi', 'rs_bi_2025', 'pct_pib', 'nota', 'fonte']); w.writerows(sub)

# ---------- PIB da agropecuaria, crescimento real no ano (taxa acumulada ate o 4o trimestre) ----------
AGP = {int(r['D3C'][:4]): float(r['V']) for r in json.load(open(os.path.join(RAIZ, 'brutos', 'PR', 'fontes', 'sidra_5932_v6563.json'), encoding='utf-8'))[1:]
       if r['D4N'] == 'Agropecuária - total' and r['D3C'].endswith('04')}
SIDRA_AGP = 'https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/6563/p/all/c11255/all (Agropecuaria - total, taxa acumulada no ano ate o 4o trimestre, brutos/PR/fontes/sidra_5932_v6563.json)'
with open(os.path.join(RAIZ, 'FN-pib-agro.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['ano', 'presidente', 'pib_agropecuaria_cresc_pct', 'fonte'])
  w.writerows([a, mand(a), AGP[a], SIDRA_AGP] for a in ANOS if a in AGP)
# subfuncao Ordenamento Territorial da Organizacao Agraria, todos os GND, sem a modalidade 91 (o texto a cita para a media do governo Dilma)
ot = {y: sum(float(r['liquidado']) for r in csv.DictReader(open(os.path.join(F, f'siop_funcoes_sf_{y}.csv'), encoding='utf-8'))
             if r['fl'].strip() == 'Organização Agrária' and r['sfl'].strip() == 'Ordenamento Territorial' and not r['mod'].endswith('/91')) for y in ANOS}
with open(os.path.join(RAIZ, 'FN-ordenamento-territorial.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['ano', 'presidente', 'liquidado_rs_bi', 'liquidado_rs_bi_2025', 'fonte'])
  w.writerows([y, mand(y), round(ot[y] / 1e9, 3), round(real(ot[y], y) / 1e9, 3), SIOP.format(y=y)] for y in ANOS)

# ---------- por mandato, media anual em R$ de 2025 (subsidios do OSU so de 2003 a 2024) ----------
med = lambda xs: round(sum(xs) / len(xs), 3) if xs else ''
fv = lambda a, ln, c: next(r[c] for r in lin if r[0] == a and r[2] == ln)
res = []
for m, i, f in MANDS:
  an = [a for a in ANOS if i <= a <= f]
  row = [m, f'{i}-{f}'] + [med([fv(a, ln, 5) for a in an]) for ln in LINHAS[:4]]
  row.append(med([fv(a, 'Organização Agrária', 5) + fv(a, 'Organização Agrária', 6) for a in an]))  # com a obtencao de terras e o credito a assentados (GND 5)
  row += [med([fv(a, 'Cultura', 5) + fv(a, 'Cultura', 6) for a in an]), med([fv(a, 'Cultura', 6) for a in an])]
  row.append(med([fv(a, 'Agricultura', 6) + fv(a, LINHAS[2], 6) + fv(a, LINHAS[3], 6) for a in an]))
  for s_ in ('agro_subsidio_financeiro', 'agro_subsidio_tributario', 'cultura_subsidio_tributario', 'rouanet_captado'):
    row.append(med([r[4] for r in sub if r[2] == s_ and r[0] in an]))
  g = 1
  for a in an: g *= 1 + AGP[a] / 100
  row.append(round(100 * (g ** (1 / len(an)) - 1), 2))
  res.append(row)
with open(os.path.join(RAIZ, 'FN-por-mandato.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n')
  w.writerow(['presidente', 'anos', 'agricultura_rs_bi_2025_ano', 'organizacao_agraria_rs_bi_2025_ano', 'gestao_ambiental_sem_recursos_hidricos_rs_bi_2025_ano',
              'recursos_hidricos_rs_bi_2025_ano', 'organizacao_agraria_com_inversoes_rs_bi_2025_ano', 'cultura_com_fsa_rs_bi_2025_ano', 'cultura_inversoes_fsa_rs_bi_2025_ano', 'inversoes_agro_ambiente_rs_bi_2025_ano',
              'agro_subsidio_financeiro_rs_bi_2025_ano', 'agro_subsidio_tributario_rs_bi_2025_ano', 'cultura_subsidio_tributario_rs_bi_2025_ano',
              'rouanet_captado_rs_bi_2025_ano', 'pib_agropecuaria_cresc_medio_pct_ano'])
  w.writerows(res)
# ---------- acoes de inversao financeira de 2023 a 2025 (o que e emprestimo e o que e fomento), as de R$ 100 mi ou mais ----------
ac = []
for y in (2023, 2024, 2025):
  for r in csv.DictReader(open(os.path.join(F, f'siop_acoes_inversoes_{y}.csv'), encoding='utf-8')):
    if float(r['liquidado']) >= 1e8: ac.append([y, r['fl'].strip(), r['al'].strip(), round(float(r['liquidado']) / 1e9, 3), SIOP.format(y=y)])
with open(os.path.join(RAIZ, 'FN-inversoes-acoes.csv'), 'w', newline='', encoding='utf-8') as f:
  w = csv.writer(f, lineterminator='\n'); w.writerow(['ano', 'funcao', 'acao', 'liquidado_rs_bi', 'fonte']); w.writerows(ac)
print('FN-inversoes-acoes.csv', len(ac))
print('FN-funcoes-uniao.csv', len(lin), 'FN-subsidios-agro-cultura.csv', len(sub), 'FN-por-mandato.csv', len(res))

# Frente FN, agro, meio ambiente e cultura por mandato

Feita em 20/10/2026 para a v12.5, junto com a frente FL. A cultura entra em todas as análises, por decisão do autor.

## O que entra
- `FN-funcoes-uniao.csv`. Despesa liquidada da União de 2000 a 2025 em cinco linhas (Agricultura, Organização Agrária, Gestão
  Ambiental sem recursos hídricos, Gestão Ambiental recursos hídricos, Cultura), em R$ correntes, R$ de 2025 (IPCA de dezembro a
  dezembro, frente N) e % do PIB (SIDRA 6784 e, quando faltar, a soma dos trimestres da SIDRA 1846, frente N2). Fonte, SIOP.
- `FN-subsidios-agro-cultura.csv`. Equalizações e subvenções agrícolas (a mesma lista da frente E), benefício tributário da agricultura
  e agroindústria, benefício tributário da cultura e audiovisual e subvenção ao seguro rural, do Orçamento de Subsídios da União
  (Tabela 1, 2003 a 2024), e a captação da Lei Rouanet por ano (painel Salic, frente E).
- `FN-por-mandato.csv`. Média anual por mandato, em R$ de 2025, e o crescimento médio do PIB da agropecuária (SIDRA 5932).
- `FN-inversoes-acoes.csv`. Ações de inversão financeira de R$ 100 mi ou mais nas quatro funções, de 2023 a 2025.
- `FN-pib-agro.csv`. Crescimento real do PIB da agropecuária por ano, taxa acumulada no ano (SIDRA 5932), para o texto ler sem o bruto.
- `FN-ordenamento-territorial.csv`. Subfunção Ordenamento Territorial da Organização Agrária, liquidado por ano, citada na nota da média do governo Dilma.

## Regras
- Sem a modalidade 91, intra-orçamentária.
- O GND 5, inversões financeiras, fica em coluna separada. Em Agricultura e Gestão Ambiental são empréstimos (Funcafé, Pronaf,
  refinanciamento de dívidas rurais em 2025, Fundo Clima em 2024 e 2025). Na Cultura são o Fundo Setorial do Audiovisual, investimento
  retornável e financiamento, e entram no total da cultura, como na série do RREO da frente CU.
- A subfunção Recursos Hídricos sai da Gestão Ambiental e vira linha própria, porque reúne obras como a transposição do São Francisco
  e chega a metade da função em vários anos.
- As equalizações do OSU estão, na maior parte, nas mesmas ações da função Agricultura, mas o OSU mede por outro critério e em
  alguns anos passa o liquidado da função. As duas séries não se somam nem se subtraem (auditoria de 20/10/2026).
- Na Organização Agrária, o GND 5 é sobretudo obtenção de terras e crédito a assentados, e entra na coluna com inversões.
- A renúncia que o OSU chama de agricultura e agroindústria é a desoneração da cesta básica, como as Tabelas 6 e 15 do mesmo
  arquivo a rotulam.
- Em 2019 a função Cultura bate com o RREO (R$ 0,72 bi) e em 2025 também (R$ 2,34 bi com o FSA).

## Limites
O valor das equalizações segue o juro e o calendário de pagamento (R$ 19,3 bi correntes em 2015 depois de R$ 2,8 bi em 2014). Os subsídios do OSU terminam em 2024. Lula 3 tem três anos de despesa (2023 a 2025) e dois de
subsídios (2023 e 2024). Mandato data o valor e não atribui causa.

## Como rodar
```
bash <pacote>/brutos/FN/baixa_FN.sh 2000 2025
cd /tmp && python3 -P <pacote>/brutos/FN/build_FN.py
```

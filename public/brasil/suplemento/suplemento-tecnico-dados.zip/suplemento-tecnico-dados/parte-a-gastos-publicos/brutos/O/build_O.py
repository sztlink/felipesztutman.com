#!/usr/bin/env python3
# Frente O: custo medio da DPF por indexador, composicao do estoque e decomposicao
# do custo total em inflacao, juro real e contribuicao de cada indexador. 2008 a 2025.
#
# Rodar com python3 -I (o script acrescenta o site-packages do usuario para achar openpyxl):
#   python3 -I gastos-publicos-brasil-dados/brutos/O/build_O.py
#
# Brutos (ver downloads.tsv):
#   rmd/anexo/Anexo RMD_Agosto_26.xlsx   Tesouro, anexo do RMD ago/2026 (2.1, 2.4, 4.2)
#   bcb/sgs_4189.json                    BCB SGS 4189 (Selic mensal anualizada base 252)
#   bcb/sgs_4390.json                    BCB SGS 4390 (Selic acumulada no mes)
#   ../N/ibge/sidra_1737_v2266.json      IBGE SIDRA 1737, IPCA numero-indice
import site
site.addsitedir(site.getusersitepackages())
import csv, json, os, datetime
import openpyxl

H = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(H, '..', '..'))
XLSX = os.path.join(H, 'rmd', 'anexo', 'Anexo RMD_Agosto_26.xlsx')
URL_RMD = 'https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322'
PAG_RMD = 'https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8'
URL_4189 = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.4189/dados (copia Internet Archive 20260210000031)'
URL_4390 = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.4390/dados?formato=json (copia Internet Archive 20260511211857)'
URL_IPCA = 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2266/p/all?formato=json'
ANOS = range(2008, 2026)
MES = {'Jan': 1, 'Fev': 2, 'Mar': 3, 'Abr': 4, 'Mai': 5, 'Jun': 6, 'Jul': 7, 'Ago': 8,
       'Set': 9, 'Out': 10, 'Nov': 11, 'Dez': 12}

wb = openpyxl.load_workbook(XLSX, read_only=True, data_only=True)


def tabela_por_linha(nome, linha_cab):
    """Planilhas com meses nas colunas (2.1, 4.2): devolve {rotulo: {(ano, mes): valor}}."""
    rows = list(wb[nome].iter_rows(values_only=True))
    cab = rows[linha_cab]
    cols = {}
    for j, c in enumerate(cab):
        if isinstance(c, str) and '/' in c and c[:3] in MES:
            cols[j] = (2000 + int(c[4:6]), MES[c[:3]])
    out = {}
    for r in rows[linha_cab + 1:]:
        if not r[0] or not isinstance(r[0], str):
            continue
        rot = ' '.join(r[0].split())
        if rot in out:      # rotulos repetidos (ex.: LTN da carteira do BC no 2.1): fica o primeiro
            continue
        d = {}
        for j, k in cols.items():
            v = r[j]
            d[k] = v if isinstance(v, (int, float)) else None
        out[rot] = d
    return out


custo = tabela_por_linha('4.2', 4)
estq = tabela_por_linha('2.1', 4)

# 2.4: composicao da DPF por indexador (R$ bi e participacao), uma linha por mes
COMP = {}
for r in wb['2.4'].iter_rows(min_row=7, values_only=True):
    if isinstance(r[0], datetime.datetime):
        COMP[(r[0].year, r[0].month)] = {
            'prefixado': (r[1], r[2]), 'indice_precos': (r[3], r[4]),
            'selic_flutuante': (r[5], r[6]), 'cambio': (r[7], r[8]),
            'demais': (r[9], r[10]), 'total': (r[11], r[12])}

# grupos de titulos do anexo 4.2 (custo) e 2.1 (estoque) que formam cada indexador
GRUPOS = {
    'prefixado': ['LTN', 'NTN-F'],
    'selic_flutuante': ['LFT'],
    'indice_precos': ['NTN-B', 'NTN-B1', 'NTN-C'],
    'cambio': ['DPFe', 'NTN - D'],
}
ESTQ_ROT = {'NTN - D': 'NTN-D', 'DPFe': 'DPFe ¹'}


def custo_grupo(g, ano):
    """Media dos custos 12m dos titulos do grupo em dez/ano, ponderada pelo estoque medio
    (media simples de dez/ano-1 e dez/ano, anexo 2.1). Devolve (custo, titulos usados)."""
    num = den = 0.0
    usados = []
    for t in GRUPOS[g]:
        c = custo.get(t, {}).get((ano, 12))
        rot = ESTQ_ROT.get(t, t)
        e0 = estq.get(rot, {}).get((ano - 1, 12)) or 0.0
        e1 = estq.get(rot, {}).get((ano, 12)) or 0.0
        w = (e0 + e1) / 2
        if c is None or w <= 0:
            continue
        num += c * w
        den += w
        usados.append(t)
    return (num / den if den else None), usados


# IPCA dez/dez
idx = {}
for x in json.load(open(os.path.join(H, '..', 'N', 'ibge', 'sidra_1737_v2266.json'), encoding='utf-8'))[1:]:
    idx[(int(x['D3C'][:4]), int(x['D3C'][4:]))] = float(x['V'])


def ipca(ano):
    return (idx[(ano, 12)] / idx[(ano - 1, 12)] - 1) * 100


def sgs(nome):
    d = {}
    for x in json.load(open(os.path.join(H, 'bcb', nome), encoding='utf-8')):
        dd, mm, aa = x['data'].split('/')
        d[(int(aa), int(mm))] = float(x['valor'])
    return d


s4189 = sgs('sgs_4189.json')
s4390 = sgs('sgs_4390.json')


def selic_media(ano):
    v = [s4189[(ano, m)] for m in range(1, 13)]
    return sum(v) / 12


def selic_acum(ano):
    f = 1.0
    for m in range(1, 13):
        f *= 1 + s4390[(ano, m)] / 100
    return (f - 1) * 100


def r4(x):
    return '' if x is None else f'{x:.4f}'


FONTE_RMD = f'{URL_RMD} (RMD ago/2026, pagina {PAG_RMD})'
lin_ind, lin_dec = [], []
for ano in ANOS:
    soma = 0.0
    for g in ['prefixado', 'selic_flutuante', 'indice_precos', 'cambio']:
        c, usados = custo_grupo(g, ano)
        p1 = COMP[(ano, 12)][g][1] * 100
        p0 = COMP[(ano - 1, 12)][g][1] * 100
        pm = (p0 + p1) / 2
        contrib = pm * c / 100 if c is not None else None
        soma += contrib or 0
        nota = (f'custo = media dos titulos {"+".join(usados)} do anexo 4.2 ponderada pelo estoque medio dez/{ano-1} e dez/{ano} do anexo 2.1; '
                f'pct_estoque_dez = anexo 2.4 em dez/{ano}; contribuicao = peso medio dez/{ano-1} ({p0:.2f}%) e dez/{ano} ({p1:.2f}%) x custo')
        if g == 'cambio':
            nota += '; custo da DPFe em reais inclui a variacao cambial'
        if g == 'selic_flutuante':
            nota += '; o grupo Taxa Flutuante do 2.4 inclui tambem divida securitizada e demais, de peso pequeno, sem custo proprio aqui'
        lin_ind.append([ano, g, r4(p1), r4(c), r4(contrib), f'{FONTE_RMD} anexos 2.1, 2.4 e 4.2', nota])
    tot = custo['DPF'][(ano, 12)]
    ip = ipca(ano)
    real = ((1 + tot / 100) / (1 + ip / 100) - 1) * 100
    sm = selic_media(ano)
    sa = selic_acum(ano)
    resid = tot - soma
    nota = (f'custo total = anexo 4.2 linha DPF dez/{ano}; IPCA dez/dez; juro real = (1+custo)/(1+IPCA)-1; '
            f'termo cruzado de Fisher = {tot - ip - real:.4f} pp; '
            f'soma das contribuicoes por indexador = {soma:.4f}, residuo frente ao total oficial = {resid:.4f} pp; '
            f'selic_media = media dos 12 meses do SGS 4189; Selic acumulada no ano (SGS 4390 composto) = {sa:.4f}')
    lin_dec.append([ano, r4(tot), r4(ip), r4(real), r4(sm),
                    f'{FONTE_RMD} anexo 4.2 ; {URL_IPCA} ; {URL_4189} ; {URL_4390}', nota])

with open(os.path.join(OUT, 'O-custo-divida-indexador.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['ano', 'indexador', 'pct_estoque_dez', 'custo_medio_12m_pct', 'contribuicao_pp', 'fonte_url', 'nota'])
    w.writerows(lin_ind)
with open(os.path.join(OUT, 'O-custo-divida-decomposicao.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['ano', 'custo_medio_total_pct', 'ipca_pct', 'juro_real_fisher_pct', 'selic_media_pct', 'fonte_url', 'nota'])
    w.writerows(lin_dec)

# medias por mandato: media simples dos valores anuais; 2016 fica sozinho (ano dividido)
MAND = [('Lula 2', 2008, 2010), ('Dilma', 2011, 2015), ('2016 (Dilma ate 12/05, Temer depois)', 2016, 2016),
        ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2025)]
dec = {int(r[0]): r for r in lin_dec}
ind = {(int(r[0]), r[1]): r for r in lin_ind}
cab = ['mandato', 'anos', 'custo_total', 'ipca', 'juro_real_fisher', 'selic_media']
for g in ['prefixado', 'selic_flutuante', 'indice_precos', 'cambio']:
    cab += [f'pct_{g}', f'custo_{g}', f'contrib_{g}']
with open(os.path.join(H, 'medias_mandato_O.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(cab)
    for nome, a, b in MAND:
        anos = range(a, b + 1)
        m = lambda vals: f'{sum(vals) / len(vals):.2f}'
        row = [nome, f'{a}-{b}' if a != b else str(a)]
        for k in [1, 2, 3, 4]:
            row.append(m([float(dec[y][k]) for y in anos]))
        for g in ['prefixado', 'selic_flutuante', 'indice_precos', 'cambio']:
            for k in [2, 3, 4]:
                row.append(m([float(ind[(y, g)][k]) for y in anos]))
        w.writerow(row)
print('ok')

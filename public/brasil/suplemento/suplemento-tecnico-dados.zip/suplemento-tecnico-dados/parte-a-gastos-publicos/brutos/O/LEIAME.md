# Frente O: custo da dívida por indexador

Pergunta: o Brasil paga uma taxa implícita alta sobre a dívida. Quanto dessa taxa é inflação, quanto é juro real e quanto depende da indexação (Selic, preços, prefixado, câmbio)?

Recorte: DPF (dívida pública federal em poder do público, DPMFi + DPFe), dezembro de cada ano, 2008 a 2025. Consulta de todas as fontes: 18/10/2026. Nenhum número digitado à mão.

## Como rodar

```
python3 -I gastos-publicos-brasil-dados/brutos/O/build_O.py
```

Roda com `-I`. O script acrescenta o site-packages do usuário para achar `openpyxl`, sem pôr no path a pasta dos dados nem o diretório corrente. É idempotente: duas rodadas seguidas deram o mesmo md5 nas três saídas.

## Saídas

| arquivo | conteúdo |
|---|---|
| `../../O-custo-divida-indexador.csv` | 18 anos x 4 indexadores: participação no estoque em dezembro, custo médio 12 meses do indexador, contribuição ao custo total |
| `../../O-custo-divida-decomposicao.csv` | por ano: custo médio total da DPF, IPCA, juro real por Fisher, Selic média; na nota, termo cruzado, resíduo e Selic acumulada |
| `medias_mandato_O.csv` | médias simples dos valores anuais por mandato, 2016 à parte |

## Fontes (ver `downloads.tsv`)

| bruto | origem |
|---|---|
| `rmd/anexo/Anexo RMD_Agosto_26.xlsx` | Tesouro Nacional, anexo do Relatório Mensal da Dívida de ago/2026, https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322 (página https://www.tesourotransparente.gov.br/publicacoes/relatorio-mensal-da-divida-rmd/2026/8). Planilhas usadas: 2.1 (estoque da DPF por título), 2.4 (composição da DPF por indexador, R$ bi e participação) e 4.2 (custo médio da DPF acumulado em 12 meses, por título, % a.a.) |
| `bcb/sgs_4189.json` | BCB SGS 4189, Selic acumulada no mês anualizada base 252. O `api.bcb.gov.br` devolveu "Requisição inválida" (bloqueio do servidor) em 18/10/2026; a cópia é a do Internet Archive de 10/02/2026, a resposta original da API sem alteração |
| `bcb/sgs_4390.json` | BCB SGS 4390, Selic acumulada no mês (% a.m.), mesma situação, cópia do Internet Archive de 11/05/2026 |
| `../N/ibge/sidra_1737_v2266.json` | IBGE SIDRA 1737, IPCA número-índice, já baixado pela frente N |

## A conta

Grupos de indexador, com os títulos do anexo 4.2:

| indexador | títulos | estoque no 2.4 |
|---|---|---|
| prefixado | LTN, NTN-F | Prefixado |
| selic_flutuante | LFT | Taxa Flutuante |
| indice_precos | NTN-B, NTN-B1, NTN-C | Índice Preços |
| cambio | DPFe (toda a dívida externa, custo em reais) e NTN-D enquanto existiu | Câmbio |

1. **pct_estoque_dez:** participação do indexador na DPF em dezembro do ano, lida do anexo 2.4.
2. **custo_medio_12m_pct do indexador:** o anexo 4.2 dá o custo por título, não por grupo. O custo do grupo é a média dos títulos ponderada pelo estoque médio do título (média simples de dez do ano anterior e dez do ano, anexo 2.1). É conta nossa, não número publicado.
3. **contribuicao_pp:** peso médio do indexador (média das participações de dez do ano anterior e dez do ano, anexo 2.4) vezes o custo do indexador. O peso médio aproxima a ponderação pelo estoque médio do período que o Tesouro usa no custo total.
4. **Fechamento:** a soma das quatro contribuições fica a no máximo 0,38 pp do custo total oficial (linha DPF do 4.2) em todos os anos; o resíduo de cada ano está na nota do arquivo de decomposição. Ele vem do peso aproximado (duas pontas em vez da média mensal), da dívida securitizada, TDA e "demais", que ficam sem custo, e do efeito de emissões e resgates dentro do ano.
5. **Inflação e juro real:** IPCA dez/dez pelo número-índice. Juro real = (1+custo)/(1+IPCA)-1. Custo total = IPCA + juro real + termo cruzado (IPCA x juro real), com o termo cruzado na nota.
6. **Selic:** `selic_media_pct` é a média simples dos 12 meses do SGS 4189. A nota traz também a Selic acumulada no ano (SGS 4390 composto), que é a comparação mais direta com um custo acumulado em 12 meses.

## Como ler

- O custo de cada indexador já contém a sua inflação ou o seu câmbio: a NTN-B paga IPCA mais cupom real, a DPFe em reais carrega a variação do real frente ao dólar e ao euro. Por isso a decomposição em "inflação" e "juro real" é sobre o total, e a decomposição por indexador é outra leitura do mesmo total, não uma soma das duas.
- O custo da LFT acompanha a Selic acumulada (diferença entre -0,02 e +0,18 pp em todos os anos).
- O câmbio pesa pouco no estoque (3,6% a 9,7%), mas o seu custo oscila de -13% a +49% e move o total em anos de choque cambial (2008, 2015, 2020, 2024).

## Lacunas

- Custo por grupo de indexador não é publicado no anexo 4.2: é média ponderada calculada aqui (ver conta).
- Composição e custo usam a DPF inteira (inclui DPFe). Para olhar só a DPMFi, o 2.5 e a linha DPMFi do 4.2 estão no mesmo arquivo e não foram usados.
- A Taxa Flutuante do 2.4 inclui, além da LFT, pequenos estoques de dívida securitizada e "demais"; o custo do grupo é só o da LFT.
- O RMD de ago/2026 é a versão atual das séries; revisões passadas do Tesouro, se houver, já estão nele. Não foi cruzado com os Relatórios Anuais da Dívida antigos.
- SGS do BCB veio do Internet Archive porque a API recusou as requisições no dia; os meses de 2008 a 2025 estão completos nas duas cópias.
- Não foi feita decomposição por exposição após swaps cambiais do BC (anexo 5.5): a composição aqui é a do título, não a do risco final do Tesouro mais BC.

# Frente Y: evidência empírica sobre política fiscal e juros

Pergunta: o que a literatura publicada permite dizer sobre o efeito de política fiscal nos juros que o Estado brasileiro paga, e qual parâmetro o simulador (frente S) pode usar com faixa de incerteza.

Feito em 19/10/2026. 25 estudos em `../../Y-literatura.csv`, todos abertos e lidos no PDF guardado em `estudos/`, com a página de onde saiu cada número. URL e data de cada download em `downloads.tsv`. A planilha é gerada por `build_Y.py` (fichas escritas à mão a partir da leitura; o script só valida colunas e grava o CSV).

Convenções da planilha:
- `pagina_ou_tabela` dá a página do PDF baixado ("p. N do PDF") e, quando difere, a numeração impressa.
- `tipo_variavel_fiscal` separa saldo esperado, saldo corrente, dívida/PIB, choque identificado, anúncio ou evento, regra fiscal. Estimativas de tipos diferentes não são misturadas abaixo.
- `taxa_afetada` diz em que juro o número vale: juro longo nominal doméstico, juro real longo, prêmio a termo, inclinação, spread soberano em dólar ou Selic.
- `resultado` marca efeito grande, moderado, pequeno, nulo ou instável, para que os achados nulos apareçam com o mesmo peso dos grandes.
- `classe_evidencia`: causal identificada (choque ou evento com estratégia que isola a causa), associação robusta (painel com controles e testes de robustez, sem isolar a causa), associação simples (série de tempo ou regressão em nível, sem identificação).

## Quantos estudos por tema

| Tema | Estudos (tema principal) | Também tocam o tema |
|---|---|---|
| 1. Resultado fiscal ou dívida e juros longos ou prêmio soberano | Y01 a Y10 (10) | Y25 |
| 2. Regras fiscais e custo de financiamento | Y11, Y12 (2) | Y10, Y24 |
| 3. Consolidação e crescimento, multiplicadores | Y13, Y14, Y15 (3) | Y12 |
| 4. Política monetária, custo da dívida e dominância fiscal | Y16 a Y19 (4) | |
| 5. Juros americanos e globais e juros de emergentes | Y20, Y21 (2) | Y06, Y08, Y17, Y22 |
| 6. Estudos de evento de anúncios fiscais no Brasil | Y23, Y24, Y25 (3) | Y12 |
| 7. Prêmio a termo publicado para o Brasil | Y22 (1) | Y08 |

Brasil como amostra única: Y07, Y08, Y09, Y10, Y14, Y16, Y17, Y18, Y19, Y22, Y23, Y24, Y25 (13). Painéis com o Brasil dentro: Y04, Y05, Y06, Y12, Y15. Emergentes sem o Brasil ou sem separação: Y02, Y03, Y11, Y13, Y20, Y21. Referência de método fora de emergentes: Y01.

## Síntese por tema

### Tema 1. Variável fiscal e juro longo, separado por tipo de variável

Unidade comum: pb no juro por 1 ponto do PIB de piora (ou, com sinal trocado, melhora) da variável fiscal. Cada bloco usa uma variável e uma taxa. Os blocos não se somam.

**A. Saldo esperado ou projetado (primário ou nominal), juro longo doméstico**

| Estudo | Amostra | Taxa | pb por 1 ponto do PIB | Resultado |
|---|---|---|---|---|
| Y06 BIS WP 474 | emergentes com Brasil, 2005 a 2013 | nominal 5a, primeira diferença mensal | 6 a 7 | pequeno |
| Y04 Jaramillo e Weber, VIX baixo | 15 emergentes com Brasil | nominal 10a | 4 (ep 11), não significativo | nulo |
| Y04 Jaramillo e Weber, linear | idem | nominal 10a | 13 a 15 (ep 9), significativo só a 15% | pequeno |
| Y02 Baldacci e Kumar, saldo esperado | 31 avançadas e emergentes | nominal 10a dado o juro curto | cerca de 20 | moderado |
| Y05 Nose e Menkulasi, após 2 anos | EMDEs, 36 grandes emissores com Brasil | nominal 10a dada a taxa básica | 26 (todos, ep 7) a 30 (grandes emissores, ep 9) | moderado |
| Y01 Laubach | EUA | real 10a, forward 5 anos à frente | 28 (ep 2) | moderado |
| Y04 Jaramillo e Weber, VIX alto | 15 emergentes | nominal 10a | 31 (ep 9) | moderado |
| Y05 Nose e Menkulasi, pico ou nexo bancário alto | EMDEs | nominal 10a | 31 a 36 (pico); cerca de 50 com bancos muito expostos ao soberano | grande |

Faixa: 4 a 50 pb, com o miolo entre 20 e 30 pb. A dispersão não é ruído: depende do estado (aversão global a risco, dívida e déficit iniciais, exposição dos bancos) e do horizonte (impacto de 6 a 10 pb, efeito pleno em 2 a 3 anos, decaimento depois se a projeção não se confirma, Y05).

**B. Saldo corrente**

| Estudo | Taxa | pb por 1 ponto do PIB | Resultado |
|---|---|---|---|
| Y08 BCB, primário | prêmio ACM 5a | não significativo | nulo |
| Y07 BCB WP 629, nível do juro de 5 anos | nominal 5a, variação mensal | 1,8 (só a 10%); primário esperado não significativo | nulo ou pequeno |
| Y02 Baldacci e Kumar | nominal 10a dado o juro curto | 13 (ep 2) | moderado |
| Y07 BCB WP 629, inclinação | 5a menos 1a | 24,5 (corrente) e 27,9 (Focus) | moderado, mas na inclinação |
| Y03 Baldacci, Gupta e Mati | spread em dólar (EMBI) | 30 a 40; cerca de 80 com default prévio | grande, em outra taxa |

**C. Dívida/PIB**

| Estudo | Taxa | pb por 1 ponto do PIB de dívida | Resultado |
|---|---|---|---|
| Y07 BCB WP 629 | inclinação e nível 5a | não significativo | nulo |
| Y08 BCB WP 637 / RPM | prêmio ACM 5a | de -2 a +3 conforme a especificação; preferida +3 | pequeno e instável |
| Y04 Jaramillo e Weber | nominal 10a | 4 (2 com VIX baixo, não significativo; 6 com VIX alto) | pequeno |
| Y02 Baldacci e Kumar | nominal 10a dado o juro curto | 3 a 5 | pequeno |
| Y01 Laubach | real 10a forward | 5 | pequeno |
| Y10 Montes e Tiberto | EMBI | 36 a 44 entre 40% e 60% de DLSP; zero acima de 60% por construção | grande no período, zero hoje |
| Y16 Blanchard | probabilidade de default | 0,23 ponto de probabilidade anual | não convertível sem o modelo |

Faixa no juro longo doméstico: 0 a 6 pb por ponto de dívida.

**Conversão entre A e C, com premissa.** Uma melhora permanente de 1 ponto do PIB no primário reduz a dívida, depois de T anos, em cerca de Δp vezes a soma de ((1+r)/(1+g))^k para k de 0 a T-1. Com o juro implícito de 12,9% e o crescimento nominal de 7,2% do cenário 1 da frente S (2026), (1+r)/(1+g) = 1,053: a dívida fica 5,6 pontos menor em 5 anos e 12 pontos menor em 10 anos. A 3 a 5 pb por ponto de dívida, isso dá 17 a 28 pb em 5 anos e 36 a 60 pb em 10 anos. O número de 5 anos bate com o miolo do bloco A (20 a 30 pb), como Laubach e Baldacci e Kumar argumentam para os EUA e para o painel deles. Premissa forte: r e g constantes e o efeito da queda do juro sobre r ignorado. Uso: **ou** o coeficiente do saldo esperado (o mercado precifica de saída a trajetória futura da dívida), **ou** o da dívida aplicado ano a ano. Os dois juntos contam o mesmo efeito duas vezes.

**Choques identificados no Brasil** (Y09, Ipea TD 1575): 1% de superávit ajustado derruba o vértice de 5 anos em até 182 pb no segundo mês, e o efeito some em cerca de 10 meses. É a única estimativa brasileira com choque fiscal identificado em VAR, e mostra uma reação forte e passageira, não um nível permanente. Duas ressalvas lidas no próprio documento: o texto da p. 16 inverte os rótulos (atribui os 180 pb ao vértice de 1 mês, mas a tabela põe -1,82 na linha de 5 anos), e a unidade do choque não é dita explicitamente em ponto do PIB.

### Tema 2. Regras fiscais

A evidência é fraca e escassa. Y11 (Banco Mundial) associa ter regra fiscal a spreads 319 a 378 pb menores na COVID e 36 a 67 pb menores em 2008. A magnitude (54% a 64% do spread) é implausível como efeito causal de uma regra: a adoção de regra é endógena à qualidade institucional, e com efeito fixo de país numa janela de dois anos sobram poucas mudanças de status para identificar o coeficiente. Y12 (FMI, com 37 anúncios brasileiros) acha que anúncio do Executivo quase não move o EMBI e que só a aprovação no Congresso tira cerca de 15 pb em 30 dias. Y24 acha a Selic 5,2 pontos abaixo de um controle sintético depois do teto, com p-valor de permutação de 0,33, ou seja, não significativo. Y10 trata reputação como função da dívida, não da regra. Nenhum estudo aberto mede o arcabouço de 2023.

### Tema 3. Consolidação e crescimento

- Y15 (narrativa, 14 países da América Latina com o Brasil): consolidação de 1% do PIB tira 0,9% do PIB em 2 anos (IC90% de 0,6 a 1,2). Sem evidência de consolidação expansionista. Com risco soberano alto, 0,9; com risco baixo, 1,2.
- Y14 (Brasil, SVAR): multiplicador de gasto de cerca de 0,5 no impacto, acumulado quase zero em 2 anos, e mais baixo depois de 2008.
- Y13 (SVAR, 44 países): multiplicador de impacto de -0,03 (não significativo) nos países em desenvolvimento; nulo ou negativo com câmbio flexível e com dívida acima de 60% do PIB.
- Y12 (canal de confiança): onde o spread cai após o anúncio, a perda de produto é metade da do contrafactual; o canal só pesa com spread alto.

Faixa do multiplicador de consolidação para o Brasil: 0 a 1,2. O valor baixo vem de VAR com ordenamento (Y13, Y14), o alto de identificação narrativa (Y15). A identificação narrativa é a mais crível e dá o número mais alto.

### Tema 4. Política monetária, custo da dívida e dominância fiscal

- Y16 (Blanchard, 2002 e 2003): com dívida de 53% do PIB e metade dolarizada, 100 pb de Selic depreciavam o câmbio em 258 pb líquidos.
- Y17 (Favero e Giavazzi): limiar de cerca de 54% de DLSP acima do qual o EMBI amplifica choques externos; a Selic não entra direto na equação do EMBI.
- Y18 (Campos e Cysne, 2025): dominância fiscal ausente até 2022 em todos os cenários, mas o limiar estimado é de cerca de 69% de DLSP. A DLSP de agosto de 2026 é 69,3% do PIB (frente F). O estudo mais recente sobre o tema coloca o Brasil de hoje exatamente no limiar, fora da amostra em que foi estimado.
- Y19 (BCB, Copom 2002 a 2009): 1 ponto de surpresa na Selic move o DI de 2 meses em 0,80 e o de 24 meses em 0,93. Serve para a transmissão da Selic ao custo da dívida prefixada curta.

### Tema 5. Juros globais e juros brasileiros

- Y20 (BIS, emergentes sem o Brasil): 100 pb de choque monetário americano movem o 10 anos dos emergentes em 29 pb (amostra completa) e 56 pb depois de 2008, quase tudo pelo prêmio a termo.
- Y21: 1 ponto de política americana eleva o diferencial de 12 meses dos emergentes em 2,5 pontos em 3 trimestres.
- Y06: 1 ponto de prêmio a termo americano leva a até 40 pb nos rendimentos locais.
- Y22 (Brasil): coeficiente do prêmio americano sobre o brasileiro de 0,58 a 1,12.
- Y08 (BCB, Brasil): 1 ponto de juro real americano de 5 anos associa-se a 64 pb no prêmio de 5 anos; os fatores externos são os maiores na decomposição por desvio padrão.

Faixa: 0,3 a 1,1 ponto no juro longo brasileiro por ponto de juro longo ou prêmio americano. Ordem de grandeza: uma alta de 40 pb no juro real americano tende a anular o efeito central de uma melhora de 1 ponto do PIB no primário esperado.

### Tema 6. Estudos de evento no Brasil

- Y23 (Ipea, 2020, replicando a SPE): teto de -0,6 a -1,2 ponto na NTN-B de 10 anos, eleição de 2018 de -0,7 a -0,9, reforma da Previdência de -0,8; juntos, -2,3 a -2,7 pontos. Dummies de degrau em regressão diária em nível: atribuem ao evento tudo o que mudou de nível depois dele. O próprio autor diz que os eventos não se separam.
- Y25 (ANPEC 2026): 1 desvio padrão de deterioração inesperada nas previsões do FMI e da OCDE sobe o 10 anos em 8 a 10 pb por 1 a 3 meses, depois volta a zero.
- Y24: teto e Selic, não significativo (p = 0,33).
- Y12: anúncio do Executivo quase nulo, aprovação legislativa cerca de 15 pb.

Nenhum estudo com metodologia foi encontrado para o arcabouço de 2023 nem para o pacote de novembro de 2024 (ver busca). Esses episódios ficam documentados só pelos eventos já registrados na frente N.

### Tema 7. Prêmio a termo publicado para o Brasil

- Y08 (BCB, ACM, LTN e NTN-F, 2007 a abr/2025): mediana do prêmio de 10 anos de 1,59% ao ano, contra 0,40% nos EUA; em abril de 2025 o prêmio era 25,8% da taxa nominal de 5 anos. O prêmio explica a maior parte da volatilidade (coeficiente de variação de 1,11 contra 0,08 da expectativa).
- Y22 (modelo afim, 2007 a 2022): o prêmio de 10 anos foi negativo de dezembro de 2018 a julho de 2021.

Não foi encontrada estimativa publicada do Tesouro Nacional nem do BIS específica para o Brasil. Y20 (BIS) decompõe o prêmio de emergentes sem incluir o Brasil. O dado publicado mais recente é de abril de 2025, então o dossiê não tem prêmio a termo publicado para 2026.

## Onde a evidência discorda

1. **Brasil: nível contra inclinação.** As regressões do BCB (Y07, Y08) e Y22 não acham efeito estável do nível fiscal sobre o nível do juro longo: o primário mexe na inclinação, e a dívida muda de sinal conforme a especificação. Os estudos brasileiros com choque ou evento (Y09, Y23) acham efeitos grandes. A diferença vem do método (regressão em nível de 2007 a 2025 contra choque identificado ou dummy de evento), do período (Y09 cobre a dívida dolarizada de 1999 a 2010) e da variável.
2. **Dependência do estado.** O mesmo coeficiente vai de zero em mercado calmo (Y04 com VIX baixo) a 30 pb sob aversão a risco (Y04 com VIX alto) e a 50 pb com bancos muito expostos à dívida (Y05). Ele também é maior com dívida ou déficit iniciais altos (Y02) e com default prévio (Y03).
3. **Regras fiscais.** Y11 diz 350 pb; Y12 diz que anúncio do Executivo não move nada; Y24 não é significativo. A discordância é de identificação, não de dado.
4. **Multiplicadores.** VAR com ordenamento dá multiplicador perto de zero (Y13, Y14); identificação narrativa dá 0,9 (Y15). Nenhum estudo aberto acha consolidação expansionista em emergentes.
5. **Dominância fiscal.** Os limiares de dívida não são estáveis entre modelos: 54% (Y17, ultrapassado sem crise do tipo de 2002), 60% (Y10, imposto) e 69% (Y18, igual à DLSP de hoje).
6. **Spillovers.** Todos concordam na direção; a magnitude vai de 0,3 a 1,1 ponto por ponto americano, conforme a taxa americana usada e o período.

Achados nulos ou pequenos, para pesar contra os grandes: Y04 em mercado calmo, Y06, Y07 no nível, Y08 no primário e na dívida (instável), Y12 no anúncio do Executivo, Y13, Y14 no acumulado, Y18 (sem dominância até 2022), Y22 no nível fiscal, Y24, Y25 depois de 3 meses. Achados grandes: Y03, Y05 no nexo bancário, Y09, Y10, Y11, Y16, Y20 depois de 2008, Y21, Y23.

## O que não pode ser quantificado com esta evidência

- A proposição 2 do brief (se uma agenda vai implementar as reformas). Nenhum estudo trata disso.
- O efeito do arcabouço de 2023 e do pacote de novembro de 2024 sobre os juros: sem estudo com metodologia.
- O efeito da credibilidade de uma regra específica, em pb, para o Brasil.
- A composição do ajuste (gasto ou receita) sobre os juros. Y15 trata do produto; Y03 diz que investimento público financiado sem déficit não piora o spread, sem número para o juro doméstico.
- A conversão para ponto do PIB dos choques de Y25 (desvio padrão) e de Y09 ("1%").
- A não linearidade perto dos limiares de dominância. O simulador pode mostrar a faixa linear, mas não o risco de quebra de regime.
- O prêmio a termo de 2026: a última estimativa publicada é de abril de 2025.
- A transmissão para NTN-B: Y05 exclui títulos indexados. A evidência em juro real vem de Y01 (EUA) e Y23 (NTN-B, por evento).

## Faixa proposta para o simulador

**Parâmetro: efeito de 1 ponto do PIB de melhora do resultado primário esperado, crível e persistente (pelo menos 4 anos, horizonte de Y05), sobre o juro longo nominal doméstico do Brasil (10 anos), mantida a trajetória esperada da Selic.**

| Cenário | pb por 1 ponto do PIB | De onde sai |
|---|---|---|
| Baixo | 11 | Y05, limite inferior do IC95% para todos os emergentes, 2 anos (Tabela AIII.1, p. 32 do PDF) |
| Central | 26 | Y05, todos os emergentes, 2 anos (30 pb nos 36 grandes emissores, com o Brasil) |
| Alto | 47 | Y05, limite superior do IC95% nos grandes emissores, 2 anos (cerca de 50 pb onde os bancos carregam mais dívida soberana) |

A faixa é de sensibilidade: junta o limite inferior do IC95% da amostra ampla (11 a 40 pb, centro 26) e o superior da amostra de
grandes emissores (12 a 47 pb, centro 30). Não é um intervalo de confiança único. O pico, de 31 a 36 pb, vem após 2,5 a 3 anos.

Revisão de 19/10/2026, pela auditoria independente (relatorio/AUDITORIA-v10.md, E2): a primeira versão desta tabela misturava
variáveis (saldo global previsto a 12 meses e juro de 5 anos em Y06; saldo global em Y04; déficit projetado e juro real forward
dos EUA em Y01; saldo esperado com juro curto como regressor em Y02). Pelo critério Y do brief, a faixa usa agora só Y05, o único
estudo com primário esperado e juro nominal doméstico de 10 anos em emergentes com o Brasil. Os demais ficam como contexto, sem
entrar no parâmetro: Y01, Y02 e Y04 dão ordens de grandeza parecidas (13 a 31 pb) com outras variáveis; Y07 e Y22, com dados
brasileiros, não acham efeito estável do nível fiscal no nível do juro longo, o que indica que o efeito no Brasil pode ficar abaixo
do piso da faixa.

Por que a faixa é defensável:
- O centro vem do único estudo com a estrutura do Brasil de hoje: dívida doméstica em moeda local, juro de 10 anos, saldo primário **esperado** (não o realizado, que é endógeno ao ciclo), amostra recente com o Brasil entre os grandes emissores. Os demais estudos com saldo esperado ficam entre 13 e 31 pb.
- O piso respeita os estudos que não acham efeito, inclusive os dois do BCB e o artigo de 2023 com dados brasileiros. A faixa não exclui que o efeito seja quase nulo.
- O teto reflete as condições que aumentam o efeito e que se aplicam ao Brasil de 2026: dívida alta (DBGG de 82,9% e DLSP de 69,3% do PIB em agosto de 2026, frente F), déficit primário inicial e bancos como grandes credores do soberano.
- O efeito cresce em 2 a 3 anos e se desfaz se a projeção não se confirma (Y05). Em Y05 o 10 anos reage com 6 a 10 pb no impacto, 12 a 16 pb em 1 ano e o efeito pleno em 2 anos. Na frente S, faz sentido aplicar cerca de metade do efeito no primeiro ano e o efeito pleno a partir do segundo, condicionado à melhora observada.
- Pela conversão com a dívida (tema 1), 5 anos de melhora sustentada dão 17 a 28 pb, coerente com o centro.

Onde aplicar, para não contar duas vezes:
- Vale para o juro longo nominal doméstico, na parte de prêmio. Os estudos de origem controlam a taxa básica (Y05, Y06) ou o juro curto (Y02), então o número **não** inclui uma eventual queda da Selic. Não somar a um choque de Selic derivado do mesmo ajuste fiscal sem evidência própria; a que existe (Y09, inflação 0,7 ponto menor) é transitória e não sustenta um parâmetro.
- O choque de "prêmio de risco" de 0,5 a 3 pontos do brief e este coeficiente medem a mesma coisa. Usar um ou outro: este coeficiente traduz 1 ponto do PIB de primário em prêmio; o choque de prêmio é um cenário direto. Nunca os dois somados.
- No custo da DPF, o efeito só entra na parte que reprecifica: emissões e rolagens de prefixados e, como premissa declarada, os mesmos pb na taxa real das NTN-B novas. LFT não muda sem mudança de Selic.
- Não vale para o spread em dólar. Para o EMBI, a referência é outra (Y03: 30 a 40 pb), e a dívida externa pesa pouco na DPF.
- Usar o coeficiente do saldo esperado **ou** o da dívida aplicado ano a ano, nunca os dois.

Classificação no padrão do brief: **B**. A faixa é compatível com os dados de emergentes e do Brasil, mas nenhum estudo identifica de forma causal esse coeficiente para o Brasil. A única estimativa causal brasileira (Y09) é transitória e não serve como efeito permanente. Nenhuma reforma produz automaticamente uma taxa específica: o simulador deve mostrar a faixa, não o ponto.

## A busca

Bases e caminhos:
- Busca nativa (WebSearch), 14 consultas. Termos principais: "Banco Central do Brasil working paper fiscal policy risk premium term structure", "Brazil term premium estimates Banco Central prêmio a termo", "event study Brazil spending cap teto de gastos announcement yields CDS", "Ipea texto para discussão risco fiscal juros longos prêmio de risco", "IMF working paper fiscal rules sovereign spreads emerging markets", "fiscal rules sovereign bond spreads ... no effect", "fiscal dominance Brazil inflation targeting Blanchard 2004 response", "estudo de evento anúncio fiscal Brasil curva DI arcabouço teto pacote", "arcabouço fiscal 2023 anúncio efeito sobre juros longos ... pacote novembro 2024", "Tesouro Nacional texto para discussão prêmio de risco curva de juros", "BIS working paper term premia emerging market economies Brazil", e buscas pelo título de Cavalcanti (2020), Miranda (2022) e David, Guajardo e Yépez (2019).
- Busca na web (SearXNG e Exa), 4 consultas em português e inglês sobre estudo de evento do arcabouço e do pacote de 2024, DI futuro e prêmio de prazo do Tesouro. Só trouxe notícias e o TD 238 do BCB (incluído como Y19).
- Repositórios abertos direto: séries de working papers do BCB, repositório do Ipea, FMI (por cópia do Internet Archive, porque imf.org devolve 403 a curl), BIS (idem), NBER, Banco Mundial, SciELO, ANPEC, Revista de Análisis Económico, RBEE.
- Bola de neve pelas referências dos textos lidos: Ferreira e Bertussi levaram a Cavalcanti (2020) e a Miranda (2022); Nose e Menkulasi confirmaram as versões publicadas de Laubach e de Jaramillo e Weber.

Busca deliberada de evidência contrária ou nula: consultas com "no effect" e "null"; leitura das especificações em que o coeficiente fiscal não é significativo (Y04, Y07, Y08, Y22); Y13 como contraponto a multiplicadores altos; Y18 como contraponto à tese de dominância fiscal; Y24 e Y12 como contraponto aos efeitos de regra e de anúncio.

Consultados e não incluídos:
- Guajardo, Leigh e Pescatori (FMI WP/11/158, PDF em `estudos/`): só OCDE; Y15 aplica o mesmo método à América Latina e já faz a comparação com a OCDE.
- Uribe e Yue (NBER 10018, PDF em `estudos/`): amostra de 1994 a 2002, superada por Y20 e Y21. Achado lido, para registro: o spread sobe mais de 1 ponto poucos trimestres depois de 1 ponto de juro americano (p. 14 do PDF).
- Hofmann, Shim e Shin (BIS WP 775, PDF em `estudos/`): trata do canal do câmbio sobre o spread, não de variável fiscal nem do nível do juro. Achado lido: 1% de apreciação contra o dólar reduz o spread local em até 9 pb em 50 dias (p. 18 do PDF).
- Arora e Cerisola (FMI WP/00/48): o PDF disponível é imagem sem texto; não foi lido, não entra.
- Miranda (2022), dissertação da FGV sobre eventos fiscais e juros: não localizada.
- Nota técnica da SPE de 09/04/2021 sobre a queda dos juros: o gov.br devolveu HTML em vez do PDF; o exercício que ela retoma (SPE 2019) está replicado em Y23.
- "Can fiscal rules improve financial market access for developing countries?" (Journal of Macroeconomics): atrás de paywall, não aberto.
- Marques Júnior (2020), sobre dominância fiscal depois de 2010: só o resumo apareceu na busca.
- Notas de mercado (Santander, Sigma, Itaú) sobre prêmio a termo e dominância fiscal: não são fontes elegíveis pela regra da frente.
- Nota da Presidência n. 5 do Ipea (2022): baixada por engano no lugar de Cavalcanti (2020) e apagada.

import csv, os, sys, warnings
warnings.filterwarnings('ignore')
import openpyxl

D = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')) + '/'
BR = D + 'brutos/E/'
RF = 'https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/renuncia/'
U_PLOA = RF + 'gastos-tributarios-ploa/dgt-previsao-ploa-2026-quadros.xlsx'
U_BE = RF + 'gastos-tributarios-bases-efetivas/dgt-bases-efetivas-2023-serie-2021-a-2026-quadros.xlsx'
OSU = 'https://www.gov.br/planejamento/pt-br/assuntos/avaliacao-de-politicas-publicas/arquivos/orcamento-de-subsidios-da-uniao/'
U_OSU = OSU + 'osu_2025-anexos-publicacao.xlsx'
U_OSU_PDF = OSU + 'orcamento-de-subsidios-da-uniao-9a-edicao.pdf'
U_MINC = 'https://www.gov.br/cultura/pt-br/assuntos/noticias/lei-rouanet-alcanca-r-3-41-bilhoes-em-captacao-e-consolida-politica-de-nacionalizacao-do-incentivo-cultural'
U_SP = 'https://portal.fazenda.sp.gov.br/servicos/orcamento/Documents/LDO/LEI%20DE%20DIRETRIZES%20OR%C3%87AMENT%C3%81RIAS%202026%20-%20ACESSO%20A%20LEI%20N%C2%B0%2018.178,%20DE%2016%20DE%20JULHO%20DE%202025%20-%20LDO%202026.pdf'

rows = []
def add(ano, est, cat, sub, v, tot, pib, url, data, nota):
    rows.append(['E', ano, est, cat, sub, f'{v:.2f}',
                 f'{100*v/tot:.3f}' if tot else '',
                 f'{100*v/pib:.3f}' if pib else '', url, data, nota])

def rows_of(wb, sheet):
    out = []
    for r in wb[sheet].iter_rows(values_only=True):
        out.append([c for c in r if c is not None])
    return out

# ---------- DGT PLOA 2026 ----------
wb = openpyxl.load_workbook(BR + 'dgt-previsao-ploa-2026-quadros.xlsx', read_only=True, data_only=True)
PIB26 = 13826294221146.102
TOT26 = None
qx = [r for r in rows_of(wb, 'Q X') if len(r) == 3 and isinstance(r[1], (int, float))]
TOT26 = [r for r in qx if r[0] == 'TOTAL'][0][1]
est = 'projecao PLOA'
nPL = 'DGT PLOA 2026 (RFB, ago/2025), Quadro X. Renuncia federal projetada; nao esta no orcamento de despesa.'
add(2026, est, 'TOTAL gastos tributarios federais', 'todos', TOT26, TOT26, PIB26, U_PLOA, '2025-08', nPL + ' Equivale a 20,2% da arrecadacao federal exceto CPSS.')
top = sorted([r for r in qx if r[0] != 'TOTAL'], key=lambda r: -r[1])
for i, r in enumerate(top[:25]):
    add(2026, est, 'Gasto tributario (top 25)', r[0].strip(), r[1], TOT26, PIB26, U_PLOA, '2025-08', f'{nPL} Posicao {i+1}.')
# detail items from Q VII
q7 = rows_of(wb, 'Q VII')
cur = ''
det = {}
for r in q7:
    if len(r) >= 3 and isinstance(r[0], str) and r[0].strip().endswith('.'):
        cur = r[1]
    elif len(r) >= 3 and isinstance(r[0], int):
        det[(cur, r[1].strip())] = r[2]
def d(tax, name):
    for (t, n), v in det.items():
        if tax in t and n.startswith(name):
            return v
    raise KeyError((tax, name))
pronac = d('IRPJ', 'Programa Nacional de Apoio') + d('IRPF', 'Programa Nacional de Apoio')
add(2026, est, 'Cultura', 'Lei Rouanet (PRONAC, IRPJ+IRPF)', pronac, TOT26, PIB26, U_PLOA, '2025-08',
    'Q VII: PRONAC IRPJ 3,019 bi + IRPF 0,069 bi. Renuncia fiscal, nao e o valor captado (ver linhas MinC).')
audiov = sum(v for (t, n), v in det.items() if n.startswith(('Atividade Audiovisual', 'RECINE', 'Programação', 'Indústria Cinematográfica')))
add(2026, est, 'Cultura', 'Lei do Audiovisual, Recine, Condecine e correlatos', audiov, TOT26, PIB26, U_PLOA, '2025-08',
    'Soma dos itens Atividade Audiovisual (IRPF, IRPJ, IRRF), RECINE, Programacao (Condecine) e Industria Cinematografica e Radiodifusao no Q VII.')
for tax, name, lab, nota in [
    ('IRPF', 'Despesas Médicas', 'IRPF: deducao de despesas medicas', 'Saude privada subsidiada via IR; nao entra na funcao 10 do orcamento.'),
    ('IRPF', 'Despesas com Educação', 'IRPF: deducao de despesas com educacao', 'Educacao privada subsidiada via IR.'),
    ('IRPF', 'Aposentadoria por Moléstia Grave', 'IRPF: isencao de aposentadoria por molestia grave', 'Maior item isolado dos rendimentos isentos.'),
    ('IRPF', 'Aposentadoria de Declarante com 65', 'IRPF: parcela isenta de aposentados 65+', ''),
    ('IRPF', 'Indenizações por Rescisão', 'IRPF: indenizacoes por rescisao de contrato', ''),
    ('IRPJ', 'Assistência Médica, Odontológica', 'IRPJ: assistencia medica a empregados', 'Somar CSLL do mesmo item para o custo total.'),
    ('Previdência', 'Entidades Filantrópicas', 'Contribuicao previdenciaria: entidades filantropicas', 'Isencao da cota patronal de entidades beneficentes (CEBAS).'),
    ('Previdência', 'Exportação da Produção Rural', 'Contribuicao previdenciaria: exportacao da producao rural', ''),
    ('Previdência', 'Desoneração da Folha de Salários', 'Desoneracao da folha (17 setores)', 'Em reoneracao gradual 2025-2027 (Lei 14.973/2024).'),
    ('Previdência', 'Desoneração da Folha dos Municípios', 'Desoneracao da folha dos municipios', ''),
    ('IRRF', 'Títulos de Crédito', 'IRRF: LCI, LCA, CRI, CRA isentos', ''),
    ('IRRF', 'Poupança', 'IRRF: poupanca isenta', ''),
    ('IRPJ', 'SUDENE', 'IRPJ: reducao SUDENE', ''),
    ('IRPJ', 'SUDAM', 'IRPJ: reducao SUDAM', ''),
]:
    add(2026, est, 'Item detalhado', lab, d(tax, name), TOT26, PIB26, U_PLOA, '2025-08', ('Q VII. ' + nota).strip())
cesta = d('PIS', 'Agricultura e Agroindústria - Desoneração Cesta') + d('COFINS', 'Agricultura e Agroindústria - Desoneração Cesta')
add(2026, est, 'Item detalhado', 'PIS/Cofins: desoneracao da cesta basica', cesta, TOT26, PIB26, U_PLOA, '2025-08', 'Q VII, PIS + Cofins. Maior parte do grupo Agricultura e Agroindustria.')
# by function (crosswalk use)
for r in rows_of(wb, 'Q I'):
    if len(r) == 7 and isinstance(r[6], (int, float)) and r[0] not in ('TOTAL', 'ARRECADAÇÃO*') and r[6] > 5e9:
        add(2026, est, 'Por funcao orcamentaria', r[0], r[6], TOT26, PIB26, U_PLOA, '2025-08',
            'Q I. Mesma taxonomia de funcoes da despesa (Portaria 42/1999), permite somar a frente A como coluna separada, nunca na mesma soma.')
# itens da funcao Cultura (Q III), ponte entre a categoria Cultura e Audiovisual do Q X e a funcao: o Q X junta PRONAC e Atividade
# Audiovisual, e lista Programacao (Condecine), Industria Cinematografica, RECINE e Livros em categorias proprias
q3, dentro = rows_of(wb, 'Q III'), False
for r in q3:
    if len(r) == 3 and r[0] == 'Cultura': dentro = True; continue
    if dentro and len(r) == 3 and isinstance(r[1], (int, float)):
        if r[0] == 'Defesa Nacional': break
        add(2026, est, 'Funcao Cultura, por gasto tributario', r[0].strip(), r[1], TOT26, PIB26, U_PLOA, '2025-08', 'Q III, itens da funcao Cultura. Somam o total da funcao no Q I.')

# ---------- DGT Bases Efetivas 2023 ----------
wb = openpyxl.load_workbook(BR + 'dgt-bases-efetivas-2023-serie-2021-a-2026-quadros.xlsx', read_only=True, data_only=True)
PIB23 = 10943344667905.049
qx = [r for r in rows_of(wb, 'Q X') if len(r) == 3 and isinstance(r[1], (int, float))]
TOT23 = sum(r[1] for r in qx if r[0] != 'TOTAL')
est = 'realizado (bases efetivas)'
nBE = 'DGT Bases Efetivas 2023 (RFB), Quadro X. Estimativa sobre declaracoes efetivamente entregues.'
add(2023, est, 'TOTAL gastos tributarios federais', 'todos', TOT23, TOT23, PIB23, U_BE, '2025', nBE + ' 24,7% da arrecadacao federal exceto CPSS.')
for i, r in enumerate(sorted([r for r in qx if r[0] != 'TOTAL'], key=lambda r: -r[1])[:15]):
    add(2023, est, 'Gasto tributario (top 15)', r[0].strip(), r[1], TOT23, PIB23, U_BE, '2025', f'{nBE} Posicao {i+1}.')

add(2023, est, 'Cultura', 'Lei Rouanet (PRONAC, IRPJ+IRPF)', 2431631063.2225003 + 50073727.66, TOT23, PIB23, U_BE, '2025',
    'Q VII Bases Efetivas 2023: IRPJ 2,432 bi + IRPF 0,050 bi. Renuncia estimada pela RFB a partir das declaracoes; difere do captado MinC (R$ 2,35 bi) por regime de competencia e metodo.')

# ---------- OSU 9a edicao (ano 2024) ----------
wb = openpyxl.load_workbook(BR + 'osu_2025-anexos-publicacao.xlsx', read_only=True, data_only=True)
PIB24 = 11744710041.81867 * 1000
t3 = [r for r in rows_of(wb, 'Tab_3') if len(r) >= 3 and isinstance(r[1], (int, float))]
osu = {}
order = []
grp = ''
for r in t3:
    name = str(r[0]).strip()
    if name in ('Benefícios Financeiros', 'Benefícios Creditícios', 'Benefícios Tributários', 'TOTAL'):
        grp = name
    osu[name] = (grp, r[1] * 1000, r[2] * 1000)
    order.append(name)
TOTO = osu['TOTAL'][2]
est = 'realizado (OSU)'
nO = 'Orcamento de Subsidios da Uniao, 9a edicao (SMA/MPO, ago/2025), Tabela 3, ano 2024.'
add(2024, est, 'TOTAL subsidios da Uniao', 'tributarios + financeiros + crediticios', TOTO, TOTO, PIB24, U_OSU, '2025-08-19', nO + ' 2023: R$ 668,1 bi (6,10% PIB).')
for g, lab, nota in [('Benefícios Tributários', 'Subsidios tributarios (renuncias)', 'Mesmo conceito do DGT Bases Efetivas 2024 (edicao mais nova que a 2023 baixada). Implicito: fora do orcamento de despesa.'),
                     ('Benefícios Financeiros', 'Subsidios financeiros (equalizacoes, subvencoes)', 'EXPLICITO: ja esta na despesa orcamentaria (frentes A/B/D, em geral funcao 28 e GND 3). Nao somar com a despesa.'),
                     ('Benefícios Creditícios', 'Subsidios crediticios (custo implicito de credito subsidiado)', 'Implicito: custo de oportunidade de fundos e emprestimos a taxa abaixo do custo de captacao da Uniao. Fora do orcamento de despesa.')]:
    add(2024, est, 'Modalidade', lab, osu[g][2], TOTO, PIB24, U_OSU, '2025-08-19', nO + ' ' + nota)
for name in order:
    g, v23, v24 = osu[name]
    if name == g or name == 'TOTAL':
        continue
    if g == 'Benefícios Financeiros' and v24 >= 5e8:
        add(2024, est, 'Subsidio financeiro (explicito)', name, v24, TOTO, PIB24, U_OSU, '2025-08-19', nO + ' Ja contido na despesa orcamentaria.')
    if g == 'Benefícios Creditícios' and abs(v24) >= 5e8:
        add(2024, est, 'Subsidio crediticio (implicito)', name, v24, TOTO, PIB24, U_OSU, '2025-08-19', nO + (' Valor negativo: retorno acima do custo de captacao no ano.' if v24 < 0 else ''))
agro = ['PRONAF (Equalização)', 'Operações de Investimento Rural e Agroindustrial', 'Securitização Agrícola',
        'Subvenção Econômica ao Prêmio do Seguro Rural - PSR', 'Custeio Agropecuário', 'Garantia e Sustentação de Preços',
        'Programa Especial de Saneamento de Ativos - PESA (Explícito)', 'Recuperação da Lavoura Cacaueira (Equalização)',
        'AGF e Estoques Estratégicos', 'Garantia e Sustentação de Preços da Agricultura Familiar']
agv = sum(osu[a][2] for a in agro)
add(2024, est, 'Agregado', 'Plano Safra e apoio agricola (subsidios financeiros)', agv, TOTO, PIB24, U_OSU, '2025-08-19',
    nO + ' Soma de equalizacoes PRONAF, investimento e custeio rural, securitizacao, PESA, PSR e politica de precos. Explicito, ja na despesa.')
for i, name in enumerate(sorted([n for n in order if osu[n][0] == 'Benefícios Tributários' and n != 'Benefícios Tributários'], key=lambda n: -osu[n][2])[:12]):
    add(2024, est, 'Subsidio tributario (top 12)', name, osu[name][2], TOTO, PIB24, U_OSU, '2025-08-19', nO + f' Posicao {i+1} entre tributarios.')

# ---------- Rouanet captado (MinC, painel Salic Comparar) ----------
U_SALIC = 'https://aplicacoes.cultura.gov.br/comparar/salicnet/'
nM = ('MinC, painel Salic Comparar, "Captacao de recursos por ano", lido em 18/10/2026 (Cloudflare: so abre em navegador; serie salva em brutos/E/salic-captacao-por-ano.csv). '
      'Captado = patrocinios e doacoes a projetos aprovados; a renuncia efetiva e menor (art. 26 deduz so parte do patrocinio).')
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'salic-captacao-por-ano.csv'), newline='', encoding='utf-8') as f:
    salic = {int(r['ano']): float(r['valor_captado_brl']) for r in csv.DictReader(f)}
PIBS = {2023: PIB23, 2024: PIB24}
for ano in range(2019, 2027):
    pib = PIBS.get(ano)
    add(ano, 'captado' if ano < 2026 else 'captado_parcial', 'Cultura', 'Lei Rouanet: valor captado no ano', salic[ano], None, pib, U_SALIC, '2026-10-18',
        nM + (' 2026 parcial, ate 18/10.' if ano == 2026 else '') + ('' if pib else ' Sem % do PIB: PIB do ano fora desta base.'))

# ---------- Estado de SP (LDO 2026) ----------
sp = [('ICMS', 78746.32e6), ('IPVA', 6625.54e6), ('ITCMD', 257.09e6)]
spt = sum(v for _, v in sp)
nS = 'LDO 2026 SP (Lei 18.178/2025), Anexo de Metas Fiscais, Estimativa e Compensacao da Renuncia de Receita. pct_total = parcela do total paulista.'
add(2026, 'previsto LDO', 'Renuncia estadual SP', 'Total ICMS + IPVA + ITCMD', spt, spt, None, U_SP, '2025-07-16', nS + ' PL LDO 2027 projeta R$ 79,9 bi so de ICMS (Adunesp, nao conferido na fonte).')
for n, v in sp:
    add(2026, 'previsto LDO', 'Renuncia estadual SP', n, v, spt, None, U_SP, '2025-07-16', nS)

with open(D + 'E-renuncias-e-subsidios.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['frente', 'ano', 'estagio', 'categoria', 'subcategoria', 'valor_brl', 'pct_total', 'pct_pib', 'fonte_url', 'data_fonte', 'nota'])
    w.writerows(rows)
print(len(rows), 'linhas')
for r in rows:
    print(r[1], r[2][:12], r[3][:30], '|', r[4][:60], round(float(r[5]) / 1e9, 2), r[6], r[7])

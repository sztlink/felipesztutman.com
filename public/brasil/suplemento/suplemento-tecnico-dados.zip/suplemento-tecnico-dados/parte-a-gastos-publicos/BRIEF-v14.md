# BRIEF v14, reação de mercado aos turnos da eleição presidencial (frente EL)

Protocolo fixado em 24/10/2026 às 21h25 (horário de Brasília), na véspera do 2º turno de 25/10/2026, antes de existir o pregão
de 26/10/2026 e antes de calcular qualquer variação em data de eleição. Nada daqui muda depois de ver os números. Desvio
posterior, se houver, vai para `brutos/EL/LEIAME.md`, seção de desvios, com o motivo e a data.

O que já era visto antes deste arquivo. Os níveis mensais da curva (`W-curva-mensal.csv`), as séries diárias do Tesouro Direto
usadas pelas frentes N, N2 e W, e o estudo de eventos fiscais da N2 (que não inclui nenhuma data de eleição). Nenhuma variação
em torno de data de eleição foi calculada antes deste protocolo.

## Pergunta
Quanto câmbio, juros prefixados, juro real, inflação implícita e risco-país se moveram no primeiro pregão depois de cada turno da
eleição presidencial, de 2002 a 2026, e como esse movimento se compara ao de um fim de semana comum dos doze meses anteriores.
A pergunta é sobre tamanho de movimento. Ela não mede qual candidato o mercado preferia, por que alguém votou em quem, nem que
parte do movimento foi causada pela eleição.

## Eventos
- 1º e 2º turno da eleição presidencial de 2002, 2006, 2010, 2014, 2018 e 2022. A data e a existência de cada turno vêm do TSE,
  dos arquivos `detalhe_votacao_munzona_<ano>.zip` do Portal de Dados Abertos (colunas de turno, data da eleição e cargo, sem ler
  voto nem candidato). O build confere que cada data é o primeiro e o último domingo de outubro.
- 2026, 1º turno em 04/10/2026 e 2º turno em 25/10/2026, pela regra do art. 77 da Constituição ("no primeiro domingo de outubro,
  em primeiro turno, e no último domingo de outubro, em segundo turno, se houver"), conferida no texto baixado do Planalto. Quando
  o TSE publicar o arquivo de 2026, a data é conferida contra ele.
- t-1 é o último dia com cotação antes do domingo da eleição. t0 é o primeiro dia com cotação depois dele, que precisa cair até
  três dias corridos depois do domingo. Sem t0 nesse prazo, o caso sai e a saída é registrada.

## Variáveis
- Câmbio, PTAX de venda (BCB, SGS 1), diário, variação de 100 vezes o logaritmo, em %. De 2002 a 2026.
- Prefixado de 1 ano, Tesouro Direto (Tesouro Transparente, Taxa Compra Manhã), interpolado no vencimento de 1 ano pelo mesmo
  método da frente W (LTN primeiro, NTN-F se a LTN não cobrir, títulos a menos de 60 dias do vencimento fora), em pb. O arquivo
  do TD começa em 31/12/2004, então vale de 2006 a 2026.
- Prefixado de 10 anos (curva NTN-F), juro real de 10 anos (curva NTN-B com cupom) e inflação implícita de 10 anos (Fisher entre
  os dois), pelo método da frente N (interpolação linear em dias, título mais próximo até 1.096 dias), em pb. De 2006 a 2026, se
  houver título que cubra o vértice, senão o caso sai e a saída é registrada.
- Risco-país, EMBI+ Brasil (JP Morgan, pelo Ipeadata, série JPM366_EMBI366), em pb. A série foi descontinuada em 30/07/2024, então
  vale de 2002 a 2022 e não tem linha de 2026. Fica como contexto histórico, declarado.
- A taxa do TD é da manhã. O resultado do turno sai na noite de domingo, então a manhã de segunda já o contém. A PTAX de segunda é
  média de consultas entre 10h e 13h e também o contém.

## Janelas
- 1 dia, principal. Valor em t0 menos valor em t-1 (sexta para segunda, na maior parte dos casos).
- 5 dias, persistência. Valor em t0+4 menos valor em t-1, em dias com cotação da própria variável.
- Nenhuma janela maior. Do 1º para o 2º turno há três semanas, e janela longa mistura os dois eventos.

## Comparação com fins de semana comuns
- Para cada evento, variável e janela, a referência são todas as variações da mesma janela que começam no primeiro dia com cotação
  depois de um fim de semana, com t0 entre 260 e 11 dias com cotação antes do t0 do evento. Saem da referência as variações cuja
  janela fica a 5 dias com cotação ou menos de qualquer turno da lista.
- Saídas por evento. Variação. Posição do módulo da variação entre os módulos da referência (percentil = porcentagem da
  referência com módulo menor). Razão entre a variação e o desvio-padrão amostral da referência. Número de variações na referência.
  Com menos de 30 na referência, a posição fica vazia.
- Saídas por turno, variável e janela, de 2002 a 2022. Número de eventos, mediana do percentil, número de eventos com percentil 95
  ou mais e o esperado por acaso (5% dos eventos). Com no máximo seis eventos por turno não há teste de significância, e nenhum
  resultado é lido como diferença estatística.
- 2026 aparece como caso, com a posição de cada turno contra a própria referência e contra os turnos de 2002 a 2022 (posição do
  módulo da variação de 2026 entre os módulos dos turnos do mesmo número).
- Sem controles externos. Dólar global, juros americanos e VIX não são descontados. Por isso a variação é medida (classe A), a
  posição contra fins de semana comuns é descrição (classe A), e a leitura de que a eleição causou o movimento é classe C, não
  demonstrada, e fica fora.

## Quando roda
- Agora (24/10/2026), para 2002 a 2022 e para o 1º turno de 2026. A linha do 2º turno de 2026 sai vazia com aviso.
- Depois do pregão de 26/10/2026, para a janela de 1 dia, e depois de 30/10/2026, para a de 5 dias. `baixa_EL.py --pos` baixa a
  PTAX e o arquivo do TD atualizados, e o build usa o arquivo mais recente. Nada muda no método.

## O que fica fora
- Atribuição de causa. O movimento do dia é descrito, não explicado pela eleição, por candidato ou por programa.
- Preferência de voto e preferência de investidor. O build não lê voto, candidato nem resultado, só datas e turnos.
- Nome de presidente só data o valor (presidente em exercício na data do turno), nunca atribui causa.
- Ibovespa e outras séries que não são de fonte oficial nem já usadas pelo dossiê.
- Qualquer escolha de data, variável ou janela depois de ver as variações. Se um dado faltar, o caso sai e a saída é registrada.

# Gastos públicos do Brasil: registro de mudanças

Cada entrada diz o que mudou, por quê e como foi verificado. Commits no repositório de origem.

## v10 (19/10/2026), a partir da v9.1 (17c7d0a3)
Origem: handoff do autor e brief aprovado (BRIEF-v10.md), com os critérios de validação de 19/10.

Novo
- Seção 15, "Quanto a política fiscal pode efetivamente reduzir os juros da dívida brasileira?", com conclusões classificadas
  em A (demonstrado), B (compatível, sem identificação causal) e C (não demonstrado), e o Anexo C com método, Selic real por
  mandato e a tabela dos 25 estudos.
- Frente W (brutos/W): curva prefixada e real de 1 a 10 anos, Selic real ex-post, pela meta menos o IPCA passado e ex-ante
  (Focus), estrutura e custo da dívida federal (RMD), três perímetros de juros com conciliação e transmissão de choques de 1 ponto
  pelo perfil de vencimentos.
- Frente X (brutos/X): EMBI+ (Ipeadata, até jul/2024), juros americanos, VIX, dólar, spread de emergentes e juros longos de
  emergentes; regressões de associação com Newey-West, robustez por diferenças, subperíodos, regimes monetários, teste de quebra
  e janela móvel.
- Frente Y (brutos/Y): revisão de 25 estudos com magnitude, página, intervalo, identificação e limites; faixa de 5, 25 e 50 pb
  por ponto do PIB de primário esperado sobre o juro longo nominal, classe B.
- Simulador (brutos/S): rolagem dos prefixados e das NTN-B pelo perfil de vencimentos de dez/2025, no lugar de 1/3 ao ano;
  sensibilidade a reduções de 0,5 a 3 pontos separando Selic, curva e prêmio (S-sensibilidade-juros.csv); canal fiscal com a
  faixa da literatura, aplicado uma vez e só às taxas de mercado (S-canal-fiscal.csv).
- relatorio/testes.py: identidades do simulador e da dívida, conciliação dos perímetros, ordem da sensibilidade e do canal,
  convenções (sem travessão, presidente nas séries novas), literatura com link e página.
- relatorio/monta_pacote_brutos.py: pacote opcional dos arquivos oficiais, antes montado à mão.

Mudou
- Seção 14: os números de 2030 mudam menos de 1 ponto com a rolagem por vencimento, a emissão líquida a taxa de mercado e a âncora
  em set/2026 (cenário 2 de 98,7% para 99,2%; grade do PLDO de 87,2% para 87,7%, contra 87,5% do Tesouro).
- Resumo: o item de juros entre emergentes foi condensado e passou a citar a Selic real ex-ante e a faixa da literatura, sem
  crescer.
- Pacote: o spread ICE BofA de emergentes sai do pacote e da planilha por licença; a reprodução da frente X exige baixá-lo no FRED,
  e relatorio/verifica_reproducao.py pula a frente sem ele e avisa.

Correções da auditoria independente (relatorio/AUDITORIA-v10.md), antes da entrega
- E1: a frase final dizia "dezenas de pb, não pontos percentuais"; passou a dar o efeito por ponto do PIB e a conta para o ajuste
  que estabilizaria a dívida (centro perto de 1 ponto), com classe C para a linearidade.
- E2: a faixa misturava variáveis fiscais e prazos; passou a usar só o estudo com primário esperado e juro nominal de 10 anos
  (Y05): 11, 26 e 47 pb (IC95%).
- E3 e E4: fontes que faltavam (Focus IPCA 12 meses e Selic na Olinda, Selic do Ipeadata, séries do FRED, NFSP) e fonte do TSE
  para a ausência de trajetória de primário nos programas.
- F1: "a maior parte da alta veio de fora" virou classe C; a fração vai de 1% a 94% conforme especificação e janela; acrescentada
  a janela 2019-2026 e a descrição sem modelo (desde dez/2022 o juro real americano subiu mais que o brasileiro).
- F2: comparação com emergentes pela mediana fixa de cinco países, com a variável ao lado.
- F3: diferença de Selic real ex-ante dada como faixa entre medidas; perímetros separados.
- F4: os estudos causais não entram na faixa, e o texto diz isso.
- F5: no simulador, a emissão líquida nova passa a sair à taxa de mercado.
- F6: âncora de mercado no último mês completo (set/2026), com a sensibilidade ao mês parcial.
- Testes: resíduo da conciliação, meia-risca, presidente nos gráficos, texto contra CSV e licença no pacote.

Limitações registradas
- EMBI+ do Ipeadata descontinuado em 30/07/2024; EMBI é spread em dólar e não prêmio dos títulos em reais.
- Sem estimativa publicada de prêmio a termo do Tesouro; a do BCB vai até abr/2025.
- Regressões em nível têm resíduos muito persistentes (risco de relação espúria); níveis e diferenças dão atribuições muito diferentes,
  e os modelos não identificam a contribuição externa.
- Nenhum estudo identifica causalmente, para o Brasil de hoje, o efeito do primário sobre o juro longo.

## v13.1 (27/10/2026), motor de PDF, Portaria 1.576 e separatas temáticas
Decisões do autor de 27/10/2026, pendentes desde a v12.6 e a v13.
- Motor de PDF. O volume passa a sair pelo WeasyPrint 70 (`estilo/base.py`, `imprime_pdf`), com o Chrome como alternativa
  (MOTOR_PDF=chrome). Mesmas 79 páginas, mesmo sumário e outline (46 entradas), fontes embutidas sem Type3, PDF/UA. O sumário
  deixou de usar flex, porque o WeasyPrint não grava link em item flex ou grid. Conferido com verifica_layout.py, testes.py
  (0 falha) e verifica_reproducao.py (154 CSV idênticos).
- Portaria 1.576/2019 no anexo T1. A liminar de 07/10/2019 da 11ª Vara Federal do Rio de Janeiro (ACP 5067900-76.2019.4.02.5101)
  entra com o trecho em que a juíza vê descompasso entre o motivo declarado e o edital. A motivação ligada a orientação sexual e
  identidade de gênero fica como alegação do MPF, hipótese não estabelecida. Sem petição, mérito nem acórdão do TRF2.
- Separatas temáticas. A 15ª leitura crítica propôs o núcleo fiscal como relatório principal e anexos independentes para agro e
  meio ambiente, cultura, educação, saúde e programas eleitorais. `relatorio/monta_tematicos.py` recorta do HTML final os anexos
  T1, T2, T4 e T5 em PDFs próprios (relatorio/tematicos/), sem texto novo além da capa, com as notas na numeração do volume e a
  mesma base de dados.

## v13 (24/10/2026), núcleo fiscal com anexos, sistema visual comum aos dois volumes e pendências fechadas
Origem: pedido de unificar a estética do dossiê inteiro e fechar o que estava em aberto, depois da abertura do volume 2
(Desenvolvimento do Brasil, `../desenvolvimento/`).

Estrutura
- Parte I, núcleo fiscal, seções 1 a 13. Parte II, anexos temáticos T1 (cultura, por governo e na OCDE), T2 (agro e meio
  ambiente), T3 (quem paga e quem recebe), T4 (educação e saúde), T5 (propostas para 2027 a 2030), T6 (expectativas contra
  resultados e mercado nos turnos) e T7 (investimento das estatais). Parte III, método e dados.
- Renumeração. Antigas seções 14 e 15 viram 12 e 13. Antigas 12, 13 e 16 viram os anexos T3, T4 e T5. Agro e cultura saem da seção 3
  e viram T2 e T1. Todas as remissões do texto foram trocadas numa passada só.
- Endereço (leitura de design, recomendação 6). Versão na capa e no rodapé, sumário com página (duas passadas do Chrome sobre o
  outline do PDF), Figura e Tabela numeradas, link interno em cada nota, fonte, seção e anexo.

Sistema visual (comum aos volumes 1 e 2, em `../estilo/`)
- Newsreader no texto e Instrument Sans em gráficos, tabelas e notas, com algarismos tabulares, no lugar da Inter. Fontes
  estáticas geradas das variáveis (o Chrome embutia a variável como Type3 e o matplotlib não lia os pesos). Licença OFL, no pacote.
- Folha comum `base.css` e módulo `base.py` (tokens, grade de 180 mm, faixas de governo iguais nos dois volumes, pontuação do texto,
  numeração, sumário). Dois-pontos e ponto-e-vírgula do texto corrido viram ponto ou vírgula, como desde a v11.2. `relatorio/estilo.py` e `relatorio/estilo.css` ficam só com o que é deste volume.

Novo
- Seção 9, "A regra, ano a ano": primário do Governo Central contra o primário que estabiliza a dívida bruta, 2007 a 2025, e o
  cenário 2 até 2030 (recomendação 7).
- Seção 12: "O que move a dívida de 2030", uma premissa por barra contra a mesma base (frente S2, recomendação 3). "Se a Selic não
  cair", Selic parada em 13,75% até 2030 (frente S2). "A receita do PLOA 2027", ponte da receita líquida de 2026 para 2027 (frente PO).
- Nota para quem aloca capital: curva a termo da ANBIMA contra o Focus desenhada (recomendação 8) e o item do PLOA 2027.
- Anexo T1: gasto público com cultura, Brasil, Canadá e OCDE pela COFOG 708x (frente CI).
- Anexo T6: backtest do Focus de outubro contra o realizado, 2000 a 2024 (frente FB, protocolo BRIEF-v13), e reação de mercado aos
  turnos da eleição presidencial de 2002 a 2026 (frente EL, protocolo BRIEF-v14, fixado em 24/10/2026). A linha do 2º turno de
  2026 fica vazia até os pregões de 26 a 30/10.
- Anexo T7: Orçamento de Investimento das estatais federais, 2009 a 2021 (frente EE). 2022 a 2025 pendentes do DOU.
- Simulador navegável da seção 12 (`relatorio/simulador/`), em JavaScript, partindo dos cenários publicados, com teste de
  paridade contra S-cenarios-divida.csv e S-sensibilidade-juros.csv (diferença máxima 0,005 ponto).

Mudou
- Gráfico 2 (primário por governo) numa cor só, com o sinal dado pela posição (recomendação 5).
- Gráfico por habitante em quatro colunas. Faixa de governo com o mesmo tom nos dois volumes.
- Corrigido: duas chaves repetidas no dicionário de fontes ('oecd' e 'camara') faziam a nota de saúde da seção 2 e a de eventos
  fiscais apontarem para a fonte errada. Viraram 'oecd_saude' e 'camara_eventos'.
- Frente CI baixa as tabelas da Statistics Canada direto da fonte, sem cópia de outra pasta.
- Auditoria independente da v13 (relatorio/AUDITORIA-v13.md): 11 erros, 6 vieses e 5 excessos, nenhum número de manchete errado,
  todos aplicados. Os principais: a ponte do PLOA atribui o ganho além do PIB à queda das transferências, e não à reforma; o trecho
  dos turnos da eleição passa a dizer que a linha de 2026 é descrição depois do fato, que a direção do movimento não indica
  preferência, e traz o histórico do 2º turno; a ordem das alavancas da seção 12 deixa de ser achado; o primário que estabiliza
  usa a dívida do ano anterior também na série histórica (2025 passa de 3,7 para 3,6 pontos de distância); remissões no feminino e
  uma remissão velha corrigidas; links das partes no sumário; alta da cultura na OCDE atribuída aos municípios no próprio dado.
- `verifica_reproducao.py` inclui FB, EL, CI, PO, S2 e EE: 151 CSV idênticos, 0 alterados. Teste limpo: zip extraído em pasta vazia,
  PDF de 79 páginas com texto igual página a página e as fontes embutidas.

## v12.6 (20/10/2026), correções da 15ª leitura crítica
Origem. Leitura crítica externa da v12.5, feita com ferramenta de IA de uso geral a pedido do autor. Ela apontou três problemas
materiais e quatro ajustes, todos tratados. A decisão editorial que ela propõe (separar relatórios temáticos) fica com o autor.
- Renúncias da cultura conciliadas. Os R$ 3,56 bi da categoria cultura e audiovisual do quadro X da Receita são a Lei Rouanet
  (R$ 3,09 bi) mais a dedução pela atividade audiovisual (R$ 0,47 bi). Os R$ 0,55 bi do audiovisual somam também Condecine, Recine
  e indústria cinematográfica (R$ 0,08 bi), que o quadro X lista em categorias próprias. A função Cultura (R$ 6,54 bi) inclui ainda
  os livros (R$ 2,73 bi) e as entidades culturais. Os itens da função entram em E-renuncias-e-subsidios.csv pelo quadro III, e
  build_CU.py confere a ponte com três asserts.
- Reprodução sem bruto. O relatório lia dois arquivos fora do pacote (SIDRA 5932 do PIB da agropecuária e o SIOP de 2013 da
  subfunção Ordenamento Territorial). Os dois viraram CSV (FN-pib-agro.csv e FN-ordenamento-territorial.csv), e um teste confere
  que todo arquivo de brutos/ lido pelo relatório está no zip. O relatório foi regerado numa pasta vazia só com o zip.
- Pareceres no pacote. As auditorias da v12.3 e as duas da v12.5 entram em relatorio/, a da cultura com três trocas de redação
  para que as hipóteses apareçam de forma impessoal e sem termo interno de trabalho. O "Como ler" passa a dizer cinco auditorias, e
  um teste confere que todo parecer está no zip. A origem da v12.5 neste registro passa a listar as hipóteses testadas sem
  atribuí-las a uma leitura pessoal.
- Cultura nos planos pelo mesmo critério. A comparação era do capítulo de cultura e esporte do PT (1.344 palavras) com o trecho de
  cultura do PL (138). Agora são os dois trechos só de cultura, do título ao título seguinte e sem cabeçalho de página, 992 palavras
  (4,0%) no PT e 138 (0,6%) no PL, e o vocabulário da cultura por 10 mil palavras (34,8 e 6,4).
- Auditoria manual dos temas (brutos/CV/audita_temas.py, CV-temas-auditoria.csv). Amostra de 141 títulos, até 12 por tema e
  governo, sorteada com semente fixa e lida título a título. Os 5 falsos positivos claros (Agulhas Negras, rubro-negro duas vezes,
  Vale Negro, abelhas indígenas) viraram filtro, que tira 23 títulos do resultado da busca. Sinônimos que o radical não pega foram
  buscados no painel (29 termos), filtrados por palavra porque a busca é por trecho, e 427 títulos foram lidos. Eles somam projetos
  em todos os governos e não mudam a ordem. O Lula 3 fica acima de todos nos três temas, e 2019 a 2022 não fica abaixo de 2016 a
  2018. As regras dos temas foram para brutos/CV/regras_temas.py.
- O custo da estrutura da cultura passa a ser referência de escala, sem a palavra teto, porque função e órgão não têm o mesmo perímetro.
- Na tabela de agro por governo, desmatamento e PIB agro ficam separados do orçamento, com nota de que o liquidado não mede a
  efetividade da política.
- Diagramação. A seção 4 abre com o texto e a tabela antes do gráfico, e a parte de simulações deixa de começar em página nova.
  As páginas 13 e 40, meio vazias, ficaram cheias, e o PDF passou de 68 para 67 páginas.
- Com o filtro novo, o tema indígena com Bolsonaro tem 9 de 10 projetos com valor aprovado, e o texto passou de "mais de 90%" para
  "90% ou mais".

## v12.5 (20/10/2026), agro, meio ambiente e cultura por governo, com hipóteses sobre a cultura testadas por dados
Origem. Pedido de comparar agro e desmatamento entre os candidatos também pelos governos anteriores, e não só pelas propostas, e de
fazer o mesmo com a cultura. Depois, quatro hipóteses sobre a cultura na disputa, com a regra de que entrassem só por dados.
- A cultura pesa pouco em dinheiro e muito no debate público.
- De 2019 a 2022 o fomento caiu, a estrutura mudou e houve restrição a temas nos projetos.
- O plano do PL não cita o MinC e propõe cortar 10 ministérios.
- Extinguir um ministério economiza pouco.

Entrou o que um dado ou um documento oficial mede. Intenção e motivo de decisão ficaram fora.
- Frente nova FL (brutos/FL). PRODES do INPE, Amazônia Legal e Cerrado, de 2000 a 2026, por ano e por mandato.
- Frente nova FN (brutos/FN). Funções Agricultura, Organização Agrária, Gestão Ambiental e Cultura da União no SIOP, de 2000 a 2025,
  por subfunção e grupo de despesa. Subsídios do agro do Orçamento de Subsídios, captação da Rouanet e PIB da agropecuária. Ações de
  inversão financeira de 2023 a 2025 (Fundo Clima, dívidas rurais, Funcafé, FSA).
- Frente nova CV (brutos/CV). A frente reúne quatro conjuntos de dados.
  - Atos oficiais com trecho conferido, os ministérios de 2018, 2019 e 2023, regras da Rouanet em 2019, 2022 e 2023, a Portaria
    1.576/2019, a Lei Aldir Blanc, os vetos totais derrubados da Lei Paulo Gustavo e da Política Nacional Aldir Blanc, e a MP 1.135.
  - Execução dessas transferências no SIOP.
  - Painel Salic Comparar, com projetos novos, avaliações da CNIC, dias de admissibilidade e temas no nome do projeto, com gospel como
    controle e sem o nome do proponente.
  - Google Trends, proposições na Câmara e o custo da estrutura da função Cultura.
- Seção 3, duas subseções novas, "Agro e meio ambiente por governo" e "Cultura por governo", com os gráficos 3b a 3f e quatro tabelas.
  - Agro e meio ambiente. A Amazônia teve 3.335 km² em 2026 pelo dado de outubro, sujeito a revisão, o menor desde 1988. Gestão
    Ambiental e Organização Agrária tiveram a menor média com Bolsonaro com qualquer perímetro testado.
  - Despesa com cultura. A função Cultura teve a menor média com Bolsonaro (R$ 0,79 bi), e R$ 1,79 bi com a Lei Aldir Blanc de 2020,
    acima de Temer.
  - Fluxo e temas da Rouanet. Os projetos novos e as avaliações da CNIC caem desde 2016 e foram os menores de 2019 a 2022, e a
    captação não caiu. Os temas negro, indígena e LGBT subiram de parte no Lula 3, e o controle gospel não.
- Seção 16, parte "Agro e meio ambiente" com oito temas citados dos dois planos (21 trechos novos, 83 no total). Na cultura, o plano
  do PL não cita o Ministério da Cultura nem a Rouanet, e a estrutura do ministério custa 0,03% da despesa primária. Matriz com seis
  linhas novas.
- Auditoria independente da parte de agro (relatorio/AUDITORIA-v12-5-agro-ambiente.md), com 4 erros, 7 vieses e 9 excessos corrigidos.
  - Equalizações e função Agricultura não se aninham.
  - Organização Agrária com a obtenção de terras.
  - A renúncia de agricultura e agroindústria é a cesta básica e saiu da leitura do agro.
  - O perímetro da cultura passou a ser um só, com a Lei Aldir Blanc de 2020 e a Política Nacional Aldir Blanc à parte.
  - Matriz com produtor rural e desmatamento separado de fiscalização.
  - Espaço do PT com e sem fome, proteção animal e segurança hídrica (12,3% e 9,7% contra 5,8% do PL).
  - Uma alegação de cada plano conferida.
  - Ressalva no dado de 2026 e médias arredondadas para cima.

- Segunda auditoria independente, da parte de cultura (relatorio/AUDITORIA-v12-5-cultura.md), com 6 erros, 9 vieses, 9 excessos e 12
  pontos em que o dado vai contra a hipótese, todos incorporados. As correções foram estas.
  - A queda das avaliações da CNIC vem desde 2012, e a da função Cultura, de 2015.
  - O total da cultura sai sem o FSA, como no agro.
  - Liquidado e empenho lado a lado, e pelo empenho Bolsonaro e Lula 3 ficam perto (R$ 2,89 bi e R$ 3,07 bi por ano).
  - A MP 1.135 também adiou o Perse. A Política Nacional Aldir Blanc teve dotação de R$ 0,01 bi em 2024, e a MP 1.274/2024 trocou
    os R$ 3 bi por ano por R$ 15 bi no total.
  - Extinção e recriação do MinC em maio de 2016 (MPs 726 e 728), ida da cultura ao Turismo em novembro de 2019 (Decreto 10.107) e
    os outros ministérios que saíram em 2019.
  - A portaria de 2019 é citada com os dois artigos e sem insinuar tema.
  - Os temas negro e indígena caem desde 2016 e não têm queda própria de 2019 a 2022. Os de 2019 a 2022 captaram em proporção maior.
    LGBT até 2022 não se distingue do acaso. A alta do Lula 3 passa no controle de volume (orquestra), e mais falsos positivos saíram.
  - Câmara por mandato, Trends com Fundo Eleitoral e de 2011 a 2025.
  - O custo da estrutura é um teto (art. 41, § 3º, da Constituição) e subiu com a recriação.
  - A frase da p. 72 do PL saiu do parágrafo de cultura.
- Seção 16, licenciamento ambiental. O PL propõe que, sem decisão no prazo, a licença seja concedida (p. 50), e o PT não usa a
  palavra. O tema entra na tabela e na matriz.
- Verificação. Testes com 0 falhas.

## v12.4 (20/10/2026), cultura em todas as análises
Origem. Decisão do autor, autor do dossiê, de incluir a cultura em todas as análises, e sua leitura de que investimento e mercado
cultural estão entre as distinções dos dois planos, que a seção 16 agora mede.
- Frente nova CU (brutos/CU). Função Cultura da União de 2015 a 2025 (RREO, Anexo 2, liquidado, exceto intra-orçamentárias), em R$
  de 2025, % do PIB e por habitante, com presidente. 2015 a 2018 baixados do Siconfi, 2019 em diante lidos da frente A. Resumo de
  2025 com o Ministério da Cultura (SIOP), as renúncias da cultura (DGT) e o país inteiro (COFOG).
- Cultura no Essencial, na seção 2 (o país gastou com juros 38 vezes o que gastou com cultura em 2024), na seção 4 (renúncias de
  cultura e audiovisual, Lei Rouanet), na seção 7 (gráfico 7c, série de 2015 a 2025), na seção 12 (recreação e cultura na POF), na
  seção 16 (parte própria com cinco temas citados dos dois planos, linha na matriz, medida do espaço de cada plano e pergunta sobre
  fomento), na nota para quem aloca capital e nos limites dos dados.
- Na seção 16, o plano do PT dedica 1.344 palavras a cultura e esporte (5,4% do texto) e o do PL, 138 palavras à cultura (0,6%).
  Nenhum dos dois traz valor de orçamento, renúncia ou meta para a cultura.

## v12.3 (20/10/2026), correções da auditoria independente da seção 16 e da frente MK
Origem. Auditoria adversarial feita por um agente de IA que não construiu a seção (research/economia-brasil/leituras/), pedida pelo
autor depois de uma leitura externa recomendar parecer independente da seção 16. Ela confirmou as 37 citações, as contagens e as
contas da frente MK, e achou 7 erros, 7 vieses e 7 excessos, todos corrigidos.
- Erros corrigidos. O plano do PL traz meta de crescimento de 4% ao ano na próxima década e R$ 900 bi em quatro anos em
  transportes, e o texto dizia que nenhum plano trazia meta de crescimento ou investimento. O plano do PT propõe o Imposto Seletivo
  contra produtos nocivos e diversificar as fontes de custeio da Previdência, e o texto dizia que ele não trazia medida tributária
  nova. A matriz era apresentada como fixada antes da contagem, e oito termos vinham da v12. O cenário 3 não fecha a distância da
  curva. O ponto de IVA é R$ 65 bi, e não R$ 64 bi. A contagem não pegava plural nem hifenização. "Nenhum número" virou "nenhuma
  meta numérica de primário, dívida, carga ou benefício para 2027 a 2030".
- Vieses corrigidos. A matriz agora junta o vocabulário dos dois planos em cada assunto (21 assuntos). Trechos mais representativos
  do PT em moradia (MCMV), previdência e trabalho, e do PL em programas sociais (regras de saída, retorno e apostas). Ressalva de
  custo fiscal para os cortes de tributo do PL e de efeito sobre emprego e custo fiscal nulo para a jornada do PT. O mecanismo dos
  juros dito para os dois. A seção não liga mais um plano a um cenário da seção 14. Itens de estatais e investimento dos dois
  planos na nota de mercado. São 52 trechos, 24 do PT e 28 do PL.
- Excessos corrigidos. A curva mostra que três quartos ou mais da distância contra o Focus estão na inflação implícita. O parâmetro
  de 27,91% do Comitê Gestor não é alíquota oficial. A POF sozinha não diz quem ganha mais com um corte de IVA, por causa da cesta
  zero, das reduções e do cashback. O teto do ganho real do salário mínimo depende do arcabouço que o PL propõe reformular.
- Notas incorporadas. Medidas tributárias em estudo na receita do PLDO, frase literal sobre dividendos, faixa de 11 a 47 pb lida
  do arquivo e dita como faixa de sensibilidade, calendário com o Imposto Seletivo, a regra da CBS e o prazo do TCU, linha de
  emendas parlamentares nos dois planos.

## v12.2 (20/10/2026), recomendações 1, 2 e 4 de uma leitura de design por agente de IA
Origem. Leitura feita por um agente de IA com a persona de saber "Casey Reas" do autor, sem participação do artista Casey Reas,
sobre a v12.1, e decisão do autor de seguir com
as melhorias propostas.
- Seção 16 com a mesma régua também na forma. Matriz de 17 termos contados nos dois planos, impressa uma vez no início da seção. Na
  v12 oito termos tinham sido contados só num plano, e a matriz mostrou que "meta fiscal" também falta no plano do PL. Ausência com
  estilo próprio igual nos dois lados, uma citação por célula com a contagem dos demais trechos, e o texto remetendo à matriz em
  vez de repetir ausências.
- Gráfico 14 com gramática do simulado. Todas as trajetórias tracejadas depois de 2025, cor só para o cenário central, a inércia e
  a grade do PLDO, faixa de 5% a 95% e de 25% a 75% do Monte Carlo do cenário 2 (95,1% a 102,3% em 2030), último dado observado
  (82,9% em ago/2026) em linha cheia, e Lula 3 sem fundo cinza.
- Eixos no padrão brasileiro em todos os gráficos, por uma regra única na hora de salvar a figura (vírgula decimal, ponto de milhar,
  anos intocados). Teste novo que falha se algum SVG trouxer número no padrão americano. Títulos longos do gráfico 4 em duas linhas
  e renda do trabalho do 12e a partir de zero.

## v12.1 (20/10/2026), nota para quem aloca capital
Origem. Leitura simulada de um leitor de mercado sobre a v12 e a decisão do autor de fazer as cinco melhorias recomendadas.
- Nota de duas páginas "Para quem aloca capital" depois do Essencial, com dívida de 2030, execução do PLDO, curva, a régua da
  seção 15, governo contra mercado, planos em ordem de grandeza e calendário de 2027.
- Frente nova MK (brutos/MK, LEIAME próprio). Curva a termo da ANBIMA de 19/10/2026 contra o Focus (primeiro ano igual, do
  segundo em diante a curva pede de 1,1 a 3,4 pontos acima). Primário projetado de 0,05% do PIB em 2027, com a meta de 0,50%
  cumprida por R$ 65,66 bi de exclusões, e discricionárias livres de R$ 143,0 bi a R$ 108,0 bi até 2030. Um ponto de IVA vale
  cerca de 0,44% do PIB. Calendário de 2027 com fonte.
- Seção 16 passa a dar o custo do ponto de IVA ao lado da proposta do PL.

## v12 (20/10/2026), seção 16, propostas para 2027 a 2030
Origem. Sugestão repassada pelo autor de uma seção final com as propostas dos dois planos do segundo turno, organizada em contas
públicas, economia nacional e orçamento familiar, com perguntas concretas e efeitos por faixa de renda, separando proposta de
resultado.
- Frente nova PR (brutos/PR, LEIAME próprio). Planos de governo baixados do TSE, 37 trechos literais conferidos por script contra
  a página citada, contagem de termos ausentes em cada plano e a base da lei atual (PLDO 2027, Focus, IBGE, Leis 14.663, 15.077,
  8.213 e 15.270, Constituição).
- Seção 16 com três tabelas de propostas lado a lado, a base de 2027 a 2030 do governo e do mercado, cinco perguntas concretas
  (proposto, efeito possível, o que não dá para calcular) e uma tabela condicional por faixa de renda. Item novo no Essencial.
- Achados na leitura dos planos. O do PT não usa superávit, dívida pública nem meta fiscal. O do PL não menciona salário mínimo,
  Imposto de Renda, Bolsa Família nem BPC. Nenhum dos dois traz número de primário, dívida, carga ou benefício. A leitura externa
  que originou a seção atribuía ao PT nova progressividade sobre rendas altas, o que o plano não propõe, e só ao PL as concessões,
  que os dois planos citam.
- Teste novo, cada trecho dos planos aparece literal no relatório.

## v11.3 (20/10/2026), renda e poder de compra por faixa
Origem. Leitura de uma leitora leiga, repassada pelo autor, de que o dossiê não media poder de compra, renda real e custo de vida,
e de que a mesma inflação pesa diferente em cada faixa de renda. Pedido do autor para incluir.
- Frente nova PC (brutos/PC, LEIAME próprio). Salário mínimo real pelo INPC desde 1995, horas de trabalho para a cesta de São
  Paulo (DIEESE), renda real do trabalho por trimestre móvel e renda domiciliar por pessoa por faixa (PNAD Contínua), inflação por
  faixa de renda (Ipea) e orçamento das famílias por classe (POF 2017-2018). Todos os números lidos dos arquivos baixados.
- Seção 12 ganha a subseção "Renda e poder de compra por faixa", com dois gráficos (12e e 12f), a tabela da POF e uma tabela por
  mandato. O essencial ganha um item. Limites dos dados e Anexo B atualizados.
- Todo gráfico com nome ou faixa de governo leva, logo abaixo, a linha "Os nomes e as faixas de governo datam os valores e não
  atribuem a causa a cada governo".
- Achados nas fontes. A planilha do Ipea tem rótulos de mês inconsistentes e, na renda alta de 2007 a 2012, as abas mensal e de
  12 meses divergem. O texto mostra as duas contas. Na POF, habitação é 39,0% e 22,7% (tabela 6715), e não 39,2% e 22,6% como na
  leitura externa.
- Verificação. Testes sem falha, reprodução com os CSV idênticos e os 7 CSV novos refeitos, PDF de 50 páginas.

## v11.2.1 (20/10/2026), pacote de dados sem autoria nem caminho local
Origem. Pedido do autor para auditar o zip antes de encaminhar, atrás de autoria e nomes próprios.
- O relatório e o PDF não mudaram. A mudança é só no pacote de dados.
- Scripts de A, B, E e LISTA acham a pasta pelo próprio arquivo, sem caminho absoluto da máquina de origem. O pymupdf é procurado
  em `~/.local/lib/pdftools` (N2/confere.py, S/build_S.py, testes.py). A cópia de depuração que A/build.py gravava fora do dossiê saiu.
- O montador do pacote troca, na prosa que vai no zip, quem pediu cada mudança por "o autor", o túnel usado na Câmara por "túnel
  VPN" e os caminhos locais por caminhos do pacote. As regras e a guarda ficam num arquivo local que não entra no zip. A guarda
  recusa o pacote se sobrar nome próprio, caminho local ou nome de serviço interno.
- Verificação. Reprodução com os CSV idênticos, testes sem falha, auditoria independente do zip extraído.

## v11.2 (19/10/2026, noite), regras de escrita no texto
Origem. Pedido do autor para aplicar ao dossiê as regras de escrita do autor (sem dois-pontos, sem ponto-e-vírgula, sem travessão, sem torção espelhada).
- Zero dois-pontos e zero ponto-e-vírgula no texto e nos gráficos. A passada final do montador (voz_saida) troca dois-pontos por
  ponto e maiúscula, e ponto-e-vírgula por vírgula em listas curtas e entre parênteses, ou por ponto quando junta duas frases
  inteiras, para não emendar frases. Fica de fora só o título de obra citada que a fonte escreve com dois-pontos.
- Cerca de 80 frases reescritas à mão. As torções do tipo "é X, não Y" e "não são X. São Y" deram lugar a afirmações diretas, os
  fechos aforísticos viraram informação, e as listas que dependiam de dois-pontos ganharam frase própria. O mesmo vale para os
  textos dos 25 estudos do Anexo C (brutos/Y/build_Y.py, Y-literatura.csv).
- Nota nova no gráfico 1. Juros por competência e despesa primária são contas diferentes, e uma queda dos juros não abre, sozinha,
  espaço igual para saúde ou outra despesa.
- testes.py ganhou as duas guardas da pontuação. Nenhum número mudou.

## v11.1 (19/10/2026, noite), inventário da N2 completado com a Câmara
Origem: pedido do autor para acessar a Câmara por VPN depois do bloqueio de 19/10.
- Câmara lida pelo túnel VPN, uma requisição por vez com pausa de 2 s; nenhum bloqueio novo.
- Pendências fechadas: anúncio do teto (24/05/2016), envio da PEC 287 (com a economia da nota da Fazenda), votações da Câmara
  das MP 838 e 871, envio do PL 2385/2023, envio do PL 3394/2024 e PLP 128/2025 com a LC 224.
- Varredura das votações do Plenário de 2017-2019 e 2023, com triagem por proposição (fontes/P2 e P4/triagem_camara_*.tsv):
  entra a MP 1170/2023 (reajuste dos servidores); saem por motivo registrado MP 765, MP 767, PL 7626 e o Repetro (MP 795),
  este por julgamento declarado (desvio 8 do LEIAME N2).
- N2 passa de 201 para 214 eventos (183 datas). Resultado: 35 de 366 testes passam do P95 (antes 33 de 348); menor q de 0,31;
  com placebo casado por trimestre, excesso só no juro real (p = 0,006; implícita p = 0,25). Classe B, leitura inalterada.
- Anexo C: a omissão da PEC 287 deu lugar à nota do inventário completado.

## v11 (19/10/2026), identificação de choques fiscais (BRIEF-v11.md)
Origem: proposta externa de inferência causal, aprovada pelo autor com N2, Y2 e S2 (X2 fora).
- N2: estudo de eventos com protocolo fixado antes dos resultados; 201 eventos de 2015 a 2026, placebo de 1.000 datas, correção
  para testes múltiplos, surpresa pelo Focus. Resultado: os juros se mexem mais em datas fiscais, mas não no sentido do conteúdo;
  nada sobrevive à correção; classe C para o efeito do conteúdo.
- Y2: inventário de 17 medidas com anunciado, aprovado e realizado por fonte oficial; nenhuma consolidação tem efeito realizado
  isolado; sem estimativa narrativa por falta de poder.
- S2: Monte Carlo de 2.000 sorteios sobre as faixas já documentadas, sem dupla contagem; classe B, ilustrativo.
- Auditoria independente (relatorio/AUDITORIA-v11.md): retirada a assimetria de 5 e 20 dias, que não existia; M17b sem realizado
  medido; contagens por medida; Monte Carlo como B; método das três frentes no Anexo C; registros de N2 corrigidos (PEC 287
  como omissão).
- Incidente: varreduras paralelas dos lotes da N2 levaram a Câmara a bloquear o acesso da máquina de origem por volta das 18h; duas medidas
  de 2024-2025 ficaram pendentes.

## v10.7 (19/10/2026), pela 10ª leitura crítica
- Emendas: a série só é homogênea desde 2020; o texto destaca 2022 para 2025 (alta real calculada) e diz que 2019 não é comparável;
  emendas são despesa já contada, mudam quem decide; denominador definido (RTN 4.4.2, pagamento efetivo, com restos a pagar e as
  emendas impositivas); "orçamento secreto" definido como o uso do RP9 para incluir programações a pedido de parlamentares não
  identificados, sem critério nem rastreabilidade; volume não mede desperdício. Linha no gráfico marca a quebra de 2019.
- Seção 15: "ajuste fiscal com transmissão associada à melhora do primário na literatura"; os dois resultados impõem choques
  diferentes em taxas diferentes.
- Paginação: seção 3 com gráfico e cronologia juntos, anexos sem quebra forçada, mínimo de 4 linhas no fim e no início de página.

## v10.6 (19/10/2026), emendas parlamentares
Origem: o autor sentiu falta do "orçamento secreto".
- Frente Z (brutos/Z): emendas por tipo (individuais, bancada, comissão, relator-geral), 2014 a 2026, empenhado e pago com restos
  a pagar, em R$ correntes, de 2025 e % do PIB, pela base Despesas e Transferências Totais da União do Tesouro, conferida contra o
  SIOP e o Portal da Transparência; participação na despesa discricionária do Executivo (RTN 4.4.2); 18 marcos com texto oficial.
- Seção 4: subseção "Emendas parlamentares e orçamento secreto", com gráfico por tipo e mandato.

## v10.5 (19/10/2026), pela 8ª leitura crítica
- Paginação: a parte de simulação deixa de forçar página nova e de trocar o rodapé (no CSS a troca de página nomeada força quebra);
  um rótulo de parte abre a seção 14. Some a página 29 quase vazia. As seis conclusões da seção 15 ficam juntas. Na seção 3, a lista
  de regras vem antes do gráfico. Restam páginas que terminam entre 53% e 59% quando um gráfico inteiro não cabe; nenhuma abaixo de 40%.
- Transmissão: o texto distingue a Selic (meses), a correção do principal das NTN-B pela inflação (todo mês) e as taxas contratadas
  dos prefixados e a taxa real das NTN-B (só na rolagem).
- Canal fiscal: variante com o efeito só nos prefixados, porque o estudo mede juro nominal (ajuste pela receita em 2030: 94,5%
  contra 94,4% nas duas taxas).
- Multiplicador: descrito como estresse parcial, sem receita endógena e com um só multiplicador para qualquer composição; cita a
  estimativa de cerca de 0,9 para a América Latina.

## v10.4 (19/10/2026), fase 1 do redesenho (parecer de design em relatorio/design/PARECER-design.md)
- Fim do encolhimento: o Chrome imprimia a 67% porque os cabeçalhos numéricos não quebravam; o corpo passa de 6,4 pt para 9,2 pt
  reais. O documento vai de 32 para 46 páginas legíveis.
- Folha de estilo única (relatorio/estilo.css): coluna de texto de 144 mm, figuras e tabelas em 180 mm, escala tipográfica com
  piso de 6,5 pt, rodapé com página e com "simulação condicional" nas seções 14 e 15, fontes sem quebra no meio da palavra.
- Estilo único dos gráficos (relatorio/estilo.py), figuras com 180 mm; IPCA sai do marrom-avermelhado.
- Quebras de página só nos inícios de parte; marcadores no PDF.
- Guarda de layout (relatorio/verifica_layout.py) nos testes.
- Erro corrigido: a variação do juro real brasileiro desde dez/2022 saía como -0,76 (era a diferença Brasil menos EUA, por
  colisão de chave) e a de 2018-2022 como 1,08; os valores certos são 0,77 e 1,42. Vinha da v10. Teste de texto contra CSV
  acrescentado.

## v10.3 (19/10/2026), pela 7ª leitura crítica
- Taxas a termo contra o Focus nas mesmas janelas: Selic do Focus mês a mês, da meta do mês da curva até a mediana de dezembro de
  cada ano; nota de que o Tesouro Direto não é curva zero-cupom (a ANBIMA publica uma) e de que as diferenças são aproximações.
- Descrição das revisões precisa: sete leituras críticas com ferramentas de IA de uso geral e duas auditorias de agentes de IA que
  não construíram os modelos; nenhuma de terceiros identificados; documento elaborado com assistência de IA. Seções 1 a 13
  descritas como dados publicados e indicadores construídos, não só observados.
- Anexo C: tabela com quatro campos (estudo, identificação, resultado, limitação), sem cortes no meio de palavra.
- Resumo reduzido a cinco conclusões e uma linha de pontos de entrada para as demais seções.
- Sensibilidade de crescimento nos ajustes 4 e 4b com o multiplicador fiscal da literatura (0 a 1,2): S-multiplicador.csv.

## v10.2 (19/10/2026), revisão curta depois da leitura simulada de um leitor de mercado
Origem: leitura por um proxy de leitor de mercado (simulação, fora do pacote) e a avaliação do autor sobre ela.
- Folha "Como ler este dossiê" antes do resumo: natureza independente e aberta a críticas, o que é observado, simulado e não
  identificado, juros (Selic contra rolagem), de onde vem a dispersão dos cenários de 2030, onde estão dados e testes.
- Âncora de mercado no dado mais recente (out/2026, 10 pregões), com set/2026 como referência; dívida de 2030 do cenário 2
  de 99,2% para 98,3%.
- Deflator: o resultado com deflator 1 ponto acima do IPCA aparece ao lado do principal na seção 14 e no resumo.
- Conciliação dos primários que estabilizam (3,2% nas condições de 2025, 4,4% em 2030 no cenário 2) numa frase.
- "O que a curva já precifica": taxas a termo da curva prefixada contra a Selic do Focus, com o prêmio de prazo estimado pelo BCB.
- Circuito completo entre fiscal, expectativas, Selic e custo da dívida na seção 15; menções ao Copom reduzidas onde vinham logo
  após números de um só governo; no resumo, ressalva simétrica para o Lula 3 (precatórios de 2023) ao lado da do BNDES.

## v10.1 (19/10/2026), pela 5ª auditoria externa
- Canal fiscal harmonizado: expectativa de primário no mesmo perímetro dos dois lados (setor público consolidado, PLDO Tabela 4
  contra Focus), média 2027-2029, como mudança de expectativa de médio prazo; resultados marcados como ilustrativos. A dívida de
  2030 no ajuste pela receita com o canal central passou de 95,2% para 95,3%.
- Faixa de 11, 26 e 47 pb descrita como sensibilidade que junta limites de duas amostras do mesmo estudo, não intervalo único;
  o texto dá o IC da amostra ampla (11 a 40), o dos grandes emissores (12 a 47) e o pico de 31 a 36 pb.
- "A política monetária pesou mais que qualquer outra variável" virou "a Selic foi o principal canal imediato de transmissão";
  a causa econômica da diferença é classe C.
- Regressões externas: o resultado é a instabilidade; sai a faixa de 1% a 94% do resumo e a leitura de nível como teto e diferenças
  como piso.
- EUA identificados como referência de economia avançada no gráfico e na tabela da seção 10.
- Pacote: entram AUDITORIA-v9.md, AUDITORIA-v10.md, testes.py, monta_pacote_brutos.py e REPRODUCAO.md, com a cobertura do teste
  limpo e o passo a passo da série ICE.

## v9.1 (19/10/2026, 17c7d0a3)
Cenário de ajuste pela despesa, receita indexada declarada, fundos da reforma e dado de ago/2026 nos cenários, ressalva da
previdência, pacote com as entradas do simulador e reprodução completa testada em pasta limpa.

## v9 (19/10/2026, 1ac6e78b e 3a29d0cb)
Cenários da dívida até 2030, incidência tributária total, previdência por regime, reforma do consumo, verificação de reprodução.

## Antes
v1 a v8 no histórico do git (research/economia-brasil/gastos-publicos).

# RESUMO: como os R$ 100 somam sem dupla contagem

Feito em 17/10/2026. **Versao anterior ao relatorio.** Aqui a despesa primaria vem da tabela 2.1 do RTN (pagamento efetivo na Conta Unica, R$ 2.394,2 bi) e os juros pelo caixa; o relatorio usa a tabela 2.5 (valor pago, R$ 2.392,6 bi, a que abre por linha) e os juros por competencia (ABSOLUTO-uniao-2025.csv). Os dois criterios sao do Tesouro e a diferenca de R$ 1,6 bi e de criterio, nao de conta. Arquivos: `RESUMO.csv` (Uniao, 2025), `RESUMO-pais.csv` (governo geral, 2024). Script: `brutos/LISTA/build_lista.py`, que tambem gera `LISTA.csv`.

## Versao federal (RESUMO.csv)

**Total usado: R$ 3.681,4 bi em 2025 (28,9% do PIB).** E a soma de quatro pecas que nao se sobrepoem:

| Peca | R$ bi | Fonte |
|---|---:|---|
| Despesa primaria do Governo Central (RTN linha 4) | 2.394,2 | RTN, pago |
| Repasses por reparticao de receita a estados e municipios (RTN linha 2) | 569,7 | RTN, pago |
| Juros da divida (GND 2) | 363,5 | SIOP, liquidado (igual ao pago) |
| Amortizacao paga sem rolar (GND 6 menos refinanciamento) | 354,0 | SIOP, liquidado (igual ao pago) |

Como garanti a soma:

1. **Uma particao so para a despesa primaria.** Os 12 primeiros blocos sao fatias exclusivas da linha 4 do RTN. Cada linha do RTN cai em exatamente um bloco, e o script confere que os 12 somam a linha 4 (2.394,2). Linhas "dos quais" (sentencas dentro do INSS, do BPC e de pessoal, seguro-defeso) nunca viram bloco proprio: ficam no bloco da linha-mae.
2. **Pessoal dividido sem sobra.** Inativos = aposentadorias civis + reformas e pensoes militares (tabela 2.5 do RTN, R$ 174,6 bi). Ativos = linha 4.2 inteira menos esses inativos (R$ 227,9 bi). A diferenca de 0,2% entre "valor pago" (tab 2.5) e "pagamento efetivo" (linha 4.2) fica no bloco dos ativos, junto com as sentencas de pessoal.
3. **Saude e educacao sem pessoal.** O RTN nao e corte por funcao: medico e professor federal estao no bloco de pessoal. Saude = obrigatorias com controle de fluxo + discricionarias de saude. Educacao = idem + complementacao do Fundeb (4.3.10).
4. **Repasses, juros e amortizacao vem de fora do RTN, e nao se repetem nele.** O RTN deduz os repasses da receita e nao tem juros nem amortizacao. Juros e amortizacao vem do SIOP pelo grupo de despesa.
5. **Rolagem fora.** Os R$ 1.417,6 bi de refinanciamento ficam de fora de todo o resumo.
6. **Inversoes financeiras fora.** Os R$ 173,0 bi do GND 5 (emprestimos do FIES, fundos, BNDES) sao troca de dinheiro por credito a receber, como a rolagem. So o impacto primario do FIES (R$ 2,2 bi) entra, porque ja esta no RTN.
7. **Renuncias fora.** Gasto tributario nao e despesa.
8. **Arredondamento.** Os "por R$ 100" usam o metodo do maior resto, para a coluna somar exatamente 100,0.

**Cuidado de estagio.** O RTN mede pagamento efetivo (inclui restos a pagar pagos); juros e amortizacao sao liquidados, mas na divida liquidado e pago coincidem em 2025 (R$ 363,5 bi nos dois). Por isso o total nao bate com os R$ 3.705,4 bi da frente A (liquidado por funcao, sem intra) nem com os R$ 3.737,1 bi da frente B (liquidado com intra). As diferencas sao o GND 5 (fora aqui), restos a pagar (dentro aqui) e intraorcamentarias (fora aqui).

**Se quiser so o "custo" do ano**, tire a amortizacao: o total fica R$ 3.327,4 bi e os juros passam a 10,9 de cada R$ 100.

## Versao pais (RESUMO-pais.csv)

**Total usado: R$ 5.377,5 bi em 2024 (45,8% do PIB), despesa do Governo Geral consolidado (Uniao + estados + municipios), COFOG da STN.** E o ultimo ano publicado; o de 2025 sai em dezembro de 2026. A coluna de valor chama `valor_2024_rs_bi` porque o ano e 2024.

Os 14 blocos sao as 10 divisoes COFOG, com tres abertas em grupos exclusivos:
- 710 Protecao social em quatro blocos: 7102+7103 (aposentadorias e pensoes), 7101 (doenca e invalidez), 7104+7106+7107 (familia, habitacao social, exclusao), resto (7105 desemprego + 7108 + 7109).
- 701 em juros (7017) e maquina publica (701 menos 7017). O grupo 7018, transferencias entre esferas, e zero no consolidado.
- 703 em tribunais (7033) e policia/bombeiros/prisoes (703 menos 7033).
- 705 e 708 juntos.

Nao ha dupla contagem porque a STN ja elimina os repasses entre esferas na coluna de consolidacao (R$ 1,29 tri em 2024). O script confere que os 14 blocos somam a despesa total consolidada. O % do PIB e o da STN (PIB implicito R$ 11.744,6 bi, um pouco diferente do IBGE atual).

Juros aqui (R$ 972,0 bi, 18,1 de cada R$ 100) sao por competencia e de todas as esferas: nao comparar com os R$ 363,5 bi pagos pela Uniao no RESUMO federal.

## Correcoes de codigo feitas na mesma passada

Conferidas nos microdados do Portal (`brutos/B/portal_exec_agg_acao_mod_2024_2026.csv`) e no SIOP por acao (`brutos/B/siop/siop_AAAA_org_acao.csv`, consulta de 17/10/2026):
- 8442 (Bolsa Familia), 00H5 e 00IN (BPC) estao certos.
- 0E36 nao existe em 2024 a 2026. A complementacao do Fundeb e a **00SB**, na funcao 12, subfuncao 847 (12.847), orgao 26000. A subfuncao 28.847 e a acao 0C33 (parcela de FPE/FPM que vai ao Fundeb) mais a 0369 (salario-educacao). A frase "a funcao 12 nao inclui a complementacao" (frente A e E-mapa, armadilha 7) estava errada.
- 2010, 2011 e 2012 estao zeradas: os auxilios foram consolidados na **212B**. Plano de saude segue na 2004.
- FEFC e a acao **0EB8**, no orgao **71000**, nao no 14000. Fundo Partidario e a 0413, no 14000.
- Precatorios nao estao nos orgaos dos tribunais em 2024 a 2026 (as acoes de sentenca ficam nos orgaos 71000, 33000 e 55000). E Legislativo por funcao (9,1) e por orgao (15,9) nao dao numeros proximos.

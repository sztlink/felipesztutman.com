# Sistema visual comum do dossie economia-brasil (volume 1, gastos publicos, e volume 2, desenvolvimento). Regras em DESIGN.md.
# Unificado em 24/10/2026 a partir do estilo do volume 1 e de uma pesquisa tipográfica de 24/10/2026 (Impeccable, DESIGN.md do Google, guias da Vercel, skill dataviz).
# Cada volume importa daqui e acrescenta so a sua cor semantica. Nada aqui depende de fonte instalada no sistema.
import os, re, subprocess
import matplotlib as mpl
from matplotlib import font_manager as fm
from cycler import cycler

AQUI = os.path.dirname(os.path.abspath(__file__))
FONTES = os.path.join(AQUI, 'fontes', 'estaticas')  # instancias estaticas (fontes/gera_estaticas.py), um arquivo por peso
for f in sorted(os.listdir(FONTES)):
  if f.endswith('.ttf'): fm.fontManager.addfont(os.path.join(FONTES, f))

TINTA, CINZA_1, CINZA_2, CINZA_3 = '#1f1f1f', '#4d4d4d', '#8a8a8a', '#c6c6c6'
GRADE, FAIXA, OCRE = '#e2e2e2', '#efefef', '#a8841f'
AZUL, AZUL_2 = '#1d4e89', '#8fa7c4'   # azul e a pergunta do grafico (juros no volume 1, o Brasil no volume 2)
BRASIL = AZUL
TEXTO_SERIF, TEXTO_SANS = 'Newsreader', 'Instrument Sans'

CM = 1 / 2.54
LARG = 18.0 * CM            # area util, 180 mm
# Grade do grafico amarrada a grade da pagina (180 mm = 30 mm de margem + 6 mm de calha + 144 mm de texto).
ESQ = 36 / 180              # area de dados comeca na coluna de texto
ESQ_CAT = 54 / 180          # categorias com nome longo
DIR = 152 / 180             # 28 mm a direita para rotulo direto
BASE, TOPO = 0.13, 0.86

STYLE = {
  'figure.figsize': (LARG, 7.5 * CM), 'figure.dpi': 100,
  'figure.facecolor': 'white', 'figure.edgecolor': 'white',
  'savefig.format': 'svg', 'savefig.facecolor': 'white', 'savefig.bbox': None, 'savefig.pad_inches': 0,
  'svg.fonttype': 'none',
  'font.family': TEXTO_SANS,
  'font.size': 8,
  'text.color': TINTA,
  'axes.facecolor': 'white', 'axes.edgecolor': TINTA, 'axes.linewidth': 0.6,
  'axes.spines.top': False, 'axes.spines.right': False, 'axes.spines.left': False, 'axes.spines.bottom': True,
  'axes.grid': True, 'axes.grid.axis': 'y', 'axes.axisbelow': True,
  'axes.titlesize': 8.5, 'axes.titleweight': 'semibold', 'axes.titlelocation': 'left', 'axes.titlepad': 13, 'axes.titlecolor': TINTA,
  'axes.labelsize': 7.5, 'axes.labelcolor': CINZA_1, 'axes.labelpad': 4, 'axes.labelweight': 'normal',
  'axes.prop_cycle': cycler(color=[AZUL, TINTA, CINZA_2, AZUL_2, CINZA_3]),
  'axes.xmargin': 0.01, 'axes.ymargin': 0.05,
  'axes.formatter.useoffset': False, 'axes.unicode_minus': True,
  'grid.color': GRADE, 'grid.linewidth': 0.5, 'grid.linestyle': '-',
  'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'xtick.color': CINZA_2, 'ytick.color': CINZA_2,
  'xtick.labelcolor': CINZA_1, 'ytick.labelcolor': CINZA_1,
  'xtick.major.size': 3, 'xtick.major.width': 0.6, 'xtick.major.pad': 3, 'xtick.direction': 'out',
  'ytick.major.size': 0, 'ytick.major.pad': 3, 'xtick.minor.visible': False, 'ytick.minor.visible': False,
  'lines.linewidth': 1.5, 'lines.markersize': 3, 'lines.markeredgewidth': 0,
  'lines.solid_capstyle': 'butt', 'lines.dash_capstyle': 'butt', 'lines.solid_joinstyle': 'round',
  'lines.dashed_pattern': [3.2, 1.6], 'lines.dotted_pattern': [1.0, 1.4], 'lines.scale_dashes': True,
  'patch.linewidth': 0, 'patch.force_edgecolor': False, 'patch.edgecolor': 'white',
  'hatch.color': '#cfcfcf', 'hatch.linewidth': 0.6,
  'legend.frameon': False, 'legend.fontsize': 7.5, 'legend.labelcolor': TINTA, 'legend.handlelength': 1.6,
  'legend.handleheight': 0.6, 'legend.handletextpad': 0.5, 'legend.borderaxespad': 0, 'legend.borderpad': 0,
  'legend.columnspacing': 1.4, 'legend.loc': 'upper left',
  'errorbar.capsize': 0,
  'scatter.edgecolors': 'none',
}
mpl.rcParams.update(STYLE)

br = lambda v, d=0: f'{v:,.{d}f}'.replace(',', 'X').replace('.', ',').replace('X', '.')

# Governos por ano civil, iguais nos dois volumes. 2016 e o ano da troca (Dilma afastada em 12/05/2016), com faixa hachurada.
# tom 1 = faixa cinza, 0 = branco, 2 = hachura. A alternancia e a mesma em todo grafico do dossie.
GOV = [(1990, 1992, 'Collor', 1), (1993, 1994, 'Itamar', 0), (1995, 2002, 'FHC', 1), (2003, 2010, 'Lula 1 e 2', 0),
       (2011, 2015, 'Dilma', 1), (2016, 2016, 'D/T', 2), (2017, 2018, 'Temer', 0), (2019, 2022, 'Bolsonaro', 1), (2023, 2026, 'Lula 3', 0)]
SIGLA = {'Collor': 'C', 'Itamar': 'I', 'FHC': 'FHC', 'Lula 1 e 2': 'L2', 'Lula 2': 'L2', 'Dilma': 'D', 'D/T': 'D/T', 'Temer': 'T',
         'Bolsonaro': 'B', 'Lula 3': 'L3'}
AVISO_MANDATO = 'Os nomes e as faixas de governo datam os valores e não atribuem a causa a cada governo.'

def faixas(ax, ini, fim, rotulo=True, y=None, fs=6.5, sigla=False):
  """Faixas de governo no fundo e nome no topo do eixo. O nome data o valor e nao atribui causa."""
  for a, b, nome, tom in GOV:
    if b < ini or a > fim: continue
    a, b = max(a, ini), min(b, fim)
    if tom == 1: ax.axvspan(a - 0.5, b + 0.5, color=FAIXA, lw=0, zorder=0)
    if tom == 2: ax.axvspan(a - 0.5, b + 0.5, facecolor='none', edgecolor='#d4d4d4', hatch='////', lw=0, zorder=0)
    if not rotulo or nome == 'D/T' or (b - a < 1 and len(nome) > 6 and not sigla): continue
    ax.text((a + b) / 2, 1.0 if y is None else y, SIGLA[nome] if sigla else nome, ha='center', va='bottom', fontsize=fs,
            color=CINZA_2, transform=ax.get_xaxis_transform(), clip_on=False)

def figura(altura_cm, esq=ESQ, dir=DIR, base=BASE, topo=TOPO):
  """Figura de 180 mm com o eixo numa posicao fixa: todos os graficos alinham entre si e com o texto."""
  import matplotlib.pyplot as plt
  fig = plt.figure(figsize=(LARG, altura_cm * CM))
  ax = fig.add_axes([esq, base, dir - esq, topo - base])
  return fig, ax

def unidade(ax, txt):
  """Unidade horizontal no topo do eixo y, no lugar do ylabel girado."""
  ax.text(0, 1.0, txt, transform=ax.transAxes, ha='right' if len(txt) < 22 else 'left', va='bottom', fontsize=7, color=CINZA_1)

def rotulo_fim(ax, x, y, txt, cor=TINTA, peso='normal', dx=0.6):
  """Rotulo direto no fim da linha. Texto em tinta, nunca na cor da serie, salvo o nome do Brasil."""
  ax.text(x + dx, y, txt, va='center', ha='left', fontsize=7.2, color=cor, fontweight=peso, clip_on=False)

def espalha(ys, gap):
  """Posicoes de rotulo direto sem sobreposicao. Mantem a ordem e afasta vizinhos a pelo menos gap (unidade do eixo y)."""
  ordem = sorted(range(len(ys)), key=lambda i: ys[i]); out = list(ys)
  for k in range(1, len(ordem)):
    a, b = ordem[k - 1], ordem[k]
    if out[b] - out[a] < gap: out[b] = out[a] + gap
  return out

def eixo_br(ax, eixo='y', d=0):
  from matplotlib.ticker import FuncFormatter
  (ax.yaxis if eixo == 'y' else ax.xaxis).set_major_formatter(FuncFormatter(lambda v, _: br(v, d)))

def salva(fig, caminho):
  """SVG reproduzivel: sem data no metadado, ids estaveis pelo svg.hashsalt."""
  import matplotlib.pyplot as plt
  fig.savefig(caminho, metadata={'Date': None, 'Creator': None}); plt.close(fig)

def css(destino_html):
  """Folha comum com as fontes apontadas a partir da pasta do HTML (o caminho relativo serve no repo e no pacote)."""
  rel = os.path.relpath(FONTES, os.path.dirname(os.path.abspath(destino_html))).replace(os.sep, '/')
  return open(os.path.join(AQUI, 'base.css'), encoding='utf-8').read().replace('__FONTES__', rel)

def glifos(h):
  """Caracteres que as fontes do dossie nao tem. O sobrescrito 2 (km2) vira marcacao, em HTML e dentro dos SVG."""
  partes = re.split(r'(<svg.*?</svg>)', h, flags=re.S)
  for k, p in enumerate(partes):
    if k % 2: partes[k] = re.sub(r'²', '<tspan baseline-shift="super" font-size="70%">2</tspan>', p)
    else: partes[k] = re.sub(r'²(?![^<]*>)', '<span class=e2>2</span>', p)
  return ''.join(partes)

def voz_saida(h, guardados=()):
  """Voz 2047 no texto corrido. Dois-pontos e ponto-e-virgula viram ponto (com maiuscula) ou virgula. Nao toca em tag, SVG,
  estilo, script, URL nem nos trechos guardados (titulos e citacoes literais)."""
  guarda = {}
  for i, t in enumerate(guardados):
    guarda['\x01%d\x01' % i] = t; h = h.replace(t, '\x01%d\x01' % i)
  partes = re.split(r'(<svg.*?</svg>|<style.*?</style>|<script.*?</script>|<[^>]*>|https?://[^\s"\'<]+|&#?\w+;)', h, flags=re.S)
  texto, mapa = [], []
  for k, p in enumerate(partes):
    if k % 2 == 0 or p.startswith(('http', '&')):
      for j, c in enumerate(p): texto.append(c); mapa.append((k, j, k % 2 == 0))
    elif re.match(r'</?(p|li|h\d|td|th|tr|div|table|ul|ol|figcaption|caption)\b', p, re.I):
      texto.append('\n'); mapa.append(None)
  plano = ''.join(texto)
  trocas = {}
  def proxima_letra(i):
    while i < len(plano) and plano[i] in ' \n': i += 1
    return i
  def ponto(i):
    trocas[mapa[i][:2]] = '.'
    j = proxima_letra(i + 1)
    if j < len(plano) and mapa[j] and mapa[j][2] and plano[j].islower(): trocas[mapa[j][:2]] = plano[j].upper()
  for m in re.finditer(r'[:;](?= )', plano):
    i = m.start()
    if not (mapa[i] and mapa[i][2]): continue
    if plano[i] == ':':
      if i == 0 or not re.match(r'[\wÀ-ÿ)\]%"”»*]', plano[i - 1]): continue
      ponto(i); continue
    ini = max(plano.rfind(c, 0, i) for c in '.\n')
    fim = min([x for x in (plano.find(c, i + 1) for c in '.;\n') if x >= 0] or [len(plano)])
    antes, depois = plano[ini + 1:i], plano[i + 1:fim]
    dentro = antes.count('(') > antes.count(')')
    curto = len(antes.strip()) < 45 or len(depois.strip()) < 45
    if dentro or curto: trocas[mapa[i][:2]] = ','
    else: ponto(i)
  por_parte = {}
  for (k, j), novo in trocas.items(): por_parte.setdefault(k, {})[j] = novo
  for k, d in por_parte.items():
    s = list(partes[k])
    for j, novo in d.items(): s[j] = novo
    partes[k] = ''.join(s)
  h = ''.join(partes)
  for k_, t in guarda.items(): h = h.replace(k_, t)
  return h


def _fora_de_tag(h, fn):
  """Aplica fn so ao texto corrido (fora de tag, SVG, estilo, script e links ja feitos)."""
  partes = re.split(r'(<svg.*?</svg>|<style.*?</style>|<script.*?</script>|<a\b.*?</a>|<h[12]\b.*?</h[12]>|<[^>]*>)', h, flags=re.S)
  return ''.join(fn(p) if k % 2 == 0 else p for k, p in enumerate(partes))

def ancora(titulo):
  m = re.match(r'(\d+)\.', titulo)
  if m: return 'sec-' + m.group(1)
  m = re.match(r'Parte ([IVX]+)\.', titulo)
  if m: return 'parte-' + m.group(1).lower()
  m = re.match(r'Anexo (T?\d+|[A-Z])\.', titulo)
  if m: return 'anx-' + m.group(1)
  t = re.sub(r'<[^>]+>', '', titulo).lower()
  for a, b in zip('áàâãéêíóôõúç', 'aaaaeeiooouc'): t = t.replace(a, b)
  return re.sub(r'[^a-z0-9]+', '-', t).strip('-')[:40]

def endereca(h):
  """Endereco do documento. Ancora em cada h2, Figura e Tabela numeradas, link interno em cada nota [n], em cada fonte e em cada
  'secao N' ou 'anexo X' citado no texto. O Chrome transforma href='#id' em link interno do PDF."""
  def h2(m):
    attrs, corpo = m.group(1), m.group(2)
    if 'id=' in attrs: return m.group(0)
    return f'<h2{attrs} id={ancora(corpo)}>{corpo}</h2>'
  h = re.sub(r'<h2([^>]*)>(.*?)</h2>', h2, h, flags=re.S)
  ids = set(re.findall(r'\bid=["\']?([\w-]+)', h))
  k = [0]
  def fig(m):
    k[0] += 1; return f'<figure id=fig-{k[0]}{m.group(1)}><div class=fn>Figura {k[0]}</div>'
  h = re.sub(r'<figure([^>]*)>', fig, h)
  t = [0]
  h = re.sub(r'<div class=tn>(.*?)</div>\s*<table', lambda m: f'<table data-tit="{m.group(1)}"', h, flags=re.S)  # titulo proprio da tabela
  def tab(m):
    t[0] += 1; a = m.group(1); tit = re.search(r' data-tit="([^"]*)"', a)
    rot = f'Tabela {t[0]}' + (f'. {tit.group(1)}' if tit else '')
    return f'<div class=tn id=tab-{t[0]}>{rot}</div><table{re.sub(r' data-tit="[^"]*"', '', a)}>'
  h = re.sub(r'<table((?![^>]*class=["\']?sumario)[^>]*)>', tab, h)
  h = re.sub(r'<sup>\[(\d+)\]</sup>', r'<sup><a href="#f-\1">[\1]</a></sup>', h)
  def fontes(m):
    i = [0]
    def li(_): i[0] += 1; return f'<li id=f-{i[0]}>'
    return re.sub(r'<li>', li, m.group(0))
  h = re.sub(r'<ol class=f>.*?</ol>', fontes, h, flags=re.S)
  def refs(txt):
    def sec(m):
      alvo = 'sec-' + m.group(2)
      return f'<a href="#{alvo}">{m.group(0)}</a>' if alvo in ids else m.group(0)
    txt = re.sub(r'\b([Ss]eç(?:ão|ões)) (\d+)\b', sec, txt)
    def anx(m):
      alvo = 'anx-' + m.group(2)
      return f'<a href="#{alvo}">{m.group(0)}</a>' if alvo in ids else m.group(0)
    return re.sub(r'\b([Aa]nexos?) (T\d+|[A-C])\b', anx, txt)
  return _fora_de_tag(h, refs)

def sumario(toc, html, ignora=()):
  """Sumario com pagina. Titulos do proprio HTML (h1 de parte e h2, em ordem), paginas do outline do PDF da passada anterior
  (fitz get_toc), que quebra palavra no fim de linha e por isso so serve para a pagina."""
  tit = [re.sub(r'<[^>]+>', '', t).strip() for t in re.findall(r'<h[12][^>]*>(.*?)</h[12]>', html, flags=re.S)]
  tit = [re.sub(r'\s+', ' ', t) for t in tit]
  pags = [pag for nivel, _, pag in toc if nivel <= 2]
  itens = []
  for titulo, pag in zip(tit, pags + [''] * (len(tit) - len(pags))):
    if any(titulo.startswith(x) for x in ignora): continue
    cls = ' class=parte-s' if titulo.startswith('Parte ') else ''
    itens.append(f'<li{cls}><a class=t href="#{ancora(titulo)}">{titulo}</a><span class=p>{pag}</span></li>')
  return '<ol class=sumario>' + ''.join(itens) + '</ol>'


# Motor de PDF dos volumes, desde 27/10/2026 o WeasyPrint (decisão do autor). O Chrome fica como alternativa: MOTOR_PDF=chrome.
# O WeasyPrint hifeniza melhor e grava o PDF com marcação de acessibilidade (PDF/UA). Ambiente em ~/.local/venvs/weasyprint (uv).
WEASY = os.path.expanduser(os.environ.get('WEASYPRINT', '~/.local/venvs/weasyprint/bin/weasyprint'))

def imprime_pdf(html_path, pdf_path, contorno=True, espera=15000, motor=None):
  """Grava pdf_path a partir de html_path. contorno=True grava o outline do PDF (usado pelo sumário com página).
  motor fixa o motor de um documento que piora no outro (a folha da régua fica no Chrome)."""
  motor = motor or os.environ.get('MOTOR_PDF', 'weasyprint')
  if motor == 'weasyprint' and os.path.exists(WEASY):
    subprocess.run([WEASY, '--quiet', '--pdf-variant', 'pdf/ua-1', html_path, pdf_path], check=True, capture_output=True)
  else:
    cmd = ['google-chrome', '--headless=new', '--no-sandbox', '--disable-gpu', '--no-pdf-header-footer', f'--virtual-time-budget={espera}']
    if contorno: cmd.append('--generate-pdf-document-outline')
    subprocess.run(cmd + [f'--print-to-pdf={pdf_path}', 'file://' + os.path.abspath(html_path)], check=True, capture_output=True)

#!/usr/bin/env python3
# Instancias estaticas das fontes variaveis (OFL). O Chrome embute fonte variavel como Type3 e o matplotlib so le o peso padrao dela,
# por isso o dossie usa estas. Rodar: cd /tmp && python3 -P <caminho>/gera_estaticas.py
import os
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
AQUI = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(AQUI, 'estaticas'); os.makedirs(OUT, exist_ok=True)
PESO = {400: 'Regular', 500: 'Medium', 600: 'SemiBold', 700: 'Bold'}
def instancia(origem, familia, eixos, peso, italico, arq):
  f = instantiateVariableFont(TTFont(os.path.join(AQUI, origem)), dict(eixos, wght=peso))
  sub = (PESO[peso] if peso != 400 or not italico else '') + ('Italic' if italico else '')
  sub = sub.replace('RegularItalic', 'Italic') or 'Regular'
  n = f['name']
  for rid in (1, 2, 3, 4, 6, 16, 17):
    n.removeNames(nameID=rid)
  n.setName(familia, 1, 3, 1, 0x409); n.setName(sub if sub in ('Regular', 'Italic', 'Bold', 'Bold Italic') else 'Regular', 2, 3, 1, 0x409)
  n.setName(familia, 16, 3, 1, 0x409); n.setName(sub, 17, 3, 1, 0x409)
  n.setName(f'{familia} {sub}', 4, 3, 1, 0x409); n.setName(f'{familia.replace(" ", "")}-{sub}', 6, 3, 1, 0x409)
  n.setName(f'{familia.replace(" ", "")}-{sub};economia-brasil', 3, 3, 1, 0x409)
  f['OS/2'].usWeightClass = peso
  f['OS/2'].fsSelection = (f['OS/2'].fsSelection & ~0b1100001) | (1 if italico else 0) | (0b100000 if peso == 700 else 0) | (0 if italico or peso == 700 else 0b1000000)
  f['head'].macStyle = (2 if italico else 0) | (1 if peso == 700 else 0)
  if 'STAT' in f: del f['STAT']
  f.recalcTimestamp = False; f['head'].modified = f['head'].created  # arquivo igual a cada rodada
  f.save(os.path.join(OUT, arq))
for p in (400, 500, 600, 700):
  instancia('Newsreader-opsz-wght.ttf', 'Newsreader', {'opsz': 12}, p, False, f'Newsreader-{PESO[p]}.ttf')
  instancia('InstrumentSans-wdth-wght.ttf', 'Instrument Sans', {'wdth': 100}, p, False, f'InstrumentSans-{PESO[p]}.ttf')
instancia('Newsreader-Italic-opsz-wght.ttf', 'Newsreader', {'opsz': 12}, 400, True, 'Newsreader-Italic.ttf')
instancia('InstrumentSans-Italic-wdth-wght.ttf', 'Instrument Sans', {'wdth': 100}, 400, True, 'InstrumentSans-Italic.ttf')
for p in (400, 500):  # titulos e numeros grandes, corpo otico de display
  instancia('Newsreader-opsz-wght.ttf', 'Newsreader Display', {'opsz': 48}, p, False, f'NewsreaderDisplay-{PESO[p]}.ttf')
print(sorted(os.listdir(OUT)))

---
name: Dossiê economia-brasil, sistema visual comum aos volumes 1 (Gastos públicos) e 2 (Desenvolvimento)
version: 1.0 (24/10/2026)
description: Dossiê impresso A4 (WeasyPrint 70 desde 27/10/2026, antes Chrome headless), de leitura e consulta. Sistema aberto em 24/10/2026 para o volume 2 e estendido ao dossiê inteiro na versão 13 do volume 1, a partir de uma pesquisa tipográfica (Impeccable, DESIGN.md do Google, guias da Vercel, skill dataviz) e do parecer de design do volume 1.
colors:
  tinta: "#1f1f1f"
  cinza-1: "#4d4d4d"
  cinza-2: "#8a8a8a"
  cinza-3: "#c6c6c6"
  grade: "#e2e2e2"
  faixa-mandato: "#efefef"
  brasil: "#1d4e89"
  america-latina: "#a8841f"
  emergentes: "#1baf7a"
  passou-o-brasil: "#6250d6"
  fator-capital: "#1f1f1f"
  fator-trabalho: "#8a8a8a"
  fator-capital-humano: "#c6c6c6"
  fator-ptf: "#a8841f"
typography:
  leitura: { fontFamily: Newsreader, fontSize: 10.2pt, lineHeight: 1.52 }
  titulo-secao: { fontFamily: Newsreader, fontSize: 24pt, fontWeight: 500 }
  numero-chave: { fontFamily: Newsreader, fontSize: 30pt, fontWeight: 400 }
  titulo-display: { fontFamily: Newsreader Display (corpo ótico 48), fontSize: 30pt, fontWeight: 400 }
  dados: { fontFamily: Instrument Sans, fontSize: 7.5pt, fontVariantNumeric: tabular-nums }
spacing:
  margem-pagina: 15mm
  area-util: 180mm
  coluna-texto: 144mm
  coluna-margem: 30mm
---

## Overview

Um documento sobre posição relativa. Quase todo gráfico responde "onde está o Brasil, e quem andou mais". Por isso
a forma padrão é **ênfase**: o Brasil numa cor, todo o resto em cinza, com nome direto onde importa. A cor de grupo
só entra quando o grupo é o argumento.

Herdado da pesquisa tipográfica: Newsreader no texto, Instrument Sans em tabelas e gráficos, `tabular-nums` em todo
número, nenhuma cor de acento na moldura, nenhuma caixa contornada, eixo amarrado à grade da página (área de dados
começa onde começa a coluna de texto). Herdado do parecer do volume 1: quatro atributos, quatro canais fixos.

## Os quatro canais fixos (volume 1, ampliado)

| atributo | canal | regra |
|---|---|---|
| quem (país, grupo) | cor | Brasil sempre `brasil`, mais grosso e com nome. Outros países em `cinza-3`, nome em cinza só nos extremos e nos que o texto cita |
| quando (governo) | faixa no fundo e nome no topo | faixas alternadas `faixa-mandato`, nome do presidente no topo do eixo, igual ao volume 1. Nome data o valor e não atribui causa (linha fixa sob o gráfico) |
| de onde (fonte) | linha "Fonte." sob o gráfico | separada da linha "Leitura." |
| quanto se pode afirmar | classe A, B ou C na margem | A medido, B associação ou pesquisa de opinião, C não demonstrado |

## Famílias de cor

Duas famílias com significado. **Nunca na mesma figura.**
- **Entidade**: `brasil`, `america-latina`, `emergentes`, `passou-o-brasil`. Os três de grupo passam todas as checagens do
  validador do skill dataviz com `--pairs all` (pior ΔE de daltonismo 9,1). O azul do Brasil é a cor da casa, um pouco
  mais escuro que a faixa ideal do validador, e por isso vai sempre com rótulo direto e traço mais grosso.
  Referência (Coreia, EUA) entra em `tinta`, traço fino, sempre com nome.
- **Fatores do crescimento**: capital `tinta`, trabalho `cinza-2`, capital humano `cinza-3`, produtividade (PTF) `ocre`.
  A PTF é a única com cor porque é o achado. Rótulo direto em todo segmento que couber.

Sem vermelho, sem verde de "bom", sem cor de estado. Melhora e piora se dizem no texto e no sinal, nunca na cor.

## Formas do volume

| pergunta | forma | exemplo |
|---|---|---|
| quem passou quem | inclinação entre dois anos, eixo log, Brasil em azul, quem passou em `passou-o-brasil` | gráfico "Countries That Overtook Brazil" refeito |
| o Brasil contra a fronteira ao longo do tempo | uma linha, faixas de governo | renda por habitante em % da dos EUA |
| de onde veio o crescimento | barras empilhadas divergentes por período, ponto preto para o PIB | decomposição PWT |
| onde o Brasil fica num indicador | pontos ordenados, um país por linha, Brasil em azul | investimento médio 1995-2024 |
| vários indicadores sociais de uma vez | pequenos múltiplos, eixo próprio por painel, Brasil contra a mediana dos comparadores | painel social |
| ranking no tempo | posição em linha com eixo invertido, nunca cor por posição | IDH, PISA |

Sem eixo duplo, sem pizza, sem número em cada ponto, sem legenda dentro da área de dados.

## Do's and Don'ts

- Nada mais largo que 180 mm numa página com margem (o Chrome encolhe o documento inteiro; regra da pesquisa mutek).
- Fonte do SVG instalada no sistema (`~/.local/share/fonts/mutek-dossie`), porque `svg.fonttype: none` grava só o nome.
- Comentário Python nunca no meio de uma linha de dicionário (bug achado no estilo da mutek).
- Fundo branco puro, nunca off-white. Sem rótulo em caixa alta, sem em dash, sem dois-pontos e ponto-e-vírgula no
  texto (voz 2047, regra do volume 1).
- Toda paleta nova passa pelo `validate_palette.js` antes de entrar aqui.

## Arquivos e uso

- `base.py` tem os tokens, o `STYLE` do matplotlib, a grade de 180 mm, as faixas de governo (`GOV`, iguais nos dois volumes, FHC,
  Dilma, Bolsonaro e Collor em cinza, os outros em branco, 2016 hachurado), e as funções de página: `css` (folha comum com as fontes
  apontadas a partir do HTML), `voz_saida` (voz 2047), `glifos` (sobrescrito sem depender da fonte), `endereca` (âncora em cada
  título, Figura e Tabela numeradas, link em cada nota e em cada "seção N" ou "anexo X") e `sumario` (sumário com página em duas
  passadas do motor de PDF, lendo o outline do PDF). `imprime_pdf` escolhe o motor, WeasyPrint por padrão e Chrome com
  MOTOR_PDF=chrome. O sumário não usa flex nem grid, porque o WeasyPrint não grava link em item flex ou grid. A folha da régua
  fica no Chrome, porque no WeasyPrint a matriz cresce e a nota final cai numa terceira página.
- `base.css` é a folha comum. Cada volume acrescenta só o rodapé e o que é seu (`relatorio/estilo.css` no volume 1).
- Cada volume tem `relatorio/estilo.py`, que importa a base e acrescenta a cor semântica própria. Volume 1, o `COR` por conceito
  (azul é juros e a pergunta do gráfico). Volume 2, as famílias Entidade e Fatores.
- Fontes em `fontes/estaticas/`, instâncias estáticas das variáveis geradas por `fontes/gera_estaticas.py` (determinístico). O
  Chrome embute fonte variável como Type3 e o matplotlib só lê o peso padrão dela, por isso as estáticas.
- Os pacotes de dados levam esta pasta como `estilo/`, ao lado de `relatorio/`, e os scripts procuram nos dois lugares.

## Do volume 1 (parecer de design e leitura de design por agente de IA, aplicados na versão 13)

- Cor sem juízo. Barras de resultado numa cor só, com o sinal dado pela posição.
- Endereço. Versão na capa e no rodapé, Figura e Tabela numeradas, link interno em notas, fontes, seções e anexos, sumário com página.
- Aviso de mandato só sob gráfico com faixa de governo.
- Tracejado quer dizer simulado ou projetado em todo o dossiê.

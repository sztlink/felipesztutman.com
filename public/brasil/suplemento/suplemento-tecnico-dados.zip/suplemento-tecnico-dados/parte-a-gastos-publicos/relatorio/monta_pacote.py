#!/usr/bin/env python3
# Pacote de dados que acompanha o relatorio: CSVs, scripts de montagem, LEIAMEs e listas de downloads. Sem brutos baixados.
# Uso: python3 monta_pacote.py  (gera relatorio/gastos-publicos-brasil-dados.zip)
import glob, os, sys, zipfile
AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
FORA = {'monta-sheets.py', 'limpeza_pacote.py'}  # credencial local e regras locais de limpeza, nao reproduzem nada do relatorio

def arquivos():
  pad = ['*.csv', '*.md', 'PC-referencias.json', 'brutos/*/*.py', 'brutos/*/*.md', 'brutos/*/*.sh', 'brutos/*/*.js', 'brutos/*/downloads.tsv', 'brutos/CV/auditoria_temas_*.tsv', 'brutos/*/*/downloads.tsv',
         'brutos/N/medias_mandato.csv', 'brutos/H/*.csv', 'brutos/G/G-beneficiarios-*.csv', 'brutos/O/medias_mandato_O.csv', 'brutos/J/bcb-tesouro-transferencias.csv', 'relatorio/monta_relatorio.py', 'relatorio/monta_tematicos.py', 'relatorio/simulador/*', 'relatorio/monta_pacote.py', 'relatorio/verifica_reproducao.py', 'relatorio/testes.py', 'relatorio/monta_pacote_brutos.py', 'relatorio/*.md', 'relatorio/estilo.py', 'relatorio/estilo.css', 'relatorio/verifica_layout.py', 'relatorio/gastos-publicos-brasil.pdf',
         'brutos/D/seriehistoricaago26.xlsx', 'brutos/I/bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx',
         'brutos/E/dgt-previsao-ploa-2026-quadros.xlsx', 'brutos/S/bcb-focus-olinda-anuais-out2026.json', 'brutos/S/pldo2027-anexo-iv-02-metas-fiscais.pdf', 'brutos/S/bcb-focus-R20261009.pdf', 'brutos/S/planalto-lcp-200-2023.htm', 'brutos/N/ibge/sidra_1737_v2266.json']  # entradas do simulador da secao 14  # as duas planilhas oficiais que o relatorio le direto
  vistos = set()
  for pd in pad:
    for f in sorted(glob.glob(os.path.join(RAIZ, pd))):
      r = os.path.relpath(f, RAIZ)
      if os.path.basename(r) in FORA or r in vistos: continue
      # diários de pregão e consultas da frente AP são caderno de trabalho, não dado do relatório
      if r.startswith('brutos/AP/') and r.endswith('.md') and os.path.basename(r) != 'LEIAME.md': continue
      vistos.add(r); yield f, r

LEIAME = """Gastos publicos do Brasil, pacote de dados

Conteudo
- *.csv na raiz: as tabelas que o relatorio le. Cada linha traz a URL da fonte primaria (coluna fonte, fonte_url ou nota).
- brutos/<frente>/*.py: scripts que montam os CSV a partir dos arquivos baixados das fontes; LEIAME.md e downloads.tsv de cada frente
  listam a URL e a data de consulta de cada arquivo bruto. Os brutos nao vao no pacote: baixe pelas URLs.
- relatorio/monta_relatorio.py: gera os graficos, o HTML e o PDF lendo os CSV e duas planilhas oficiais incluidas no pacote
  (brutos/D/seriehistoricaago26.xlsx, RTN do Tesouro; brutos/I/bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx, BCB;
  brutos/E/dgt-previsao-ploa-2026-quadros.xlsx, Receita).
  Todo numero do texto sai desses arquivos.

Dois pacotes
- gastos-publicos-brasil-dados.zip (este): CSV, scripts, LEIAMEs, listas de downloads e as entradas do simulador da secao 14.
  Sozinho, refaz os graficos, o HTML e o PDF, e os scripts que nao dependem de bruto (E/build_E_linhas, H/build_historico,
  J/build_bcb_tesouro, J/build_dbgg_real, M/build_M, M/build_M_decomp, Y/build_Y). Os demais pedem os brutos.
- gastos-publicos-brasil-brutos.zip (cerca de 530 MB, opcional): os arquivos oficiais baixados de cada frente, menos B e G, cujos
  CSV ja estao aqui. Extraido por cima deste, permite rodar relatorio/verifica_reproducao.py inteiro: em teste numa pasta limpa,
  78 CSV identicos, 0 alterados, e o relatorio regerado em 11 s com texto igual ao distribuido.

Ordem para refazer
1. Baixar os brutos de cada frente pelas URLs do LEIAME/downloads.tsv para brutos/<frente>/.
2. Rodar os scripts de brutos/ (H, LISTA, I, J, K, L, M, N); cada um escreve os CSV na raiz.
2b. Frentes novas: brutos/J/build_dbgg_real.py, brutos/O/build_O.py, brutos/P/build_P.py, brutos/Q/build_Q.py, brutos/M/build_M_decomp.py, brutos/R/build_R_spread.py, brutos/S/build_S.py, brutos/T/build_T.py, brutos/U/build_U.py, brutos/V/build_V.py.
2c. Conferir: python3 -P relatorio/verifica_reproducao.py refaz todos os CSV e compara com os do pacote.
3. python3 relatorio/monta_relatorio.py (precisa de matplotlib, openpyxl, pymupdf e WeasyPrint 70 para o PDF, ou google-chrome com MOTOR_PDF=chrome; as fontes Newsreader e
   Instrument Sans, licenca OFL, vao em estilo/fontes/).
"""

# O pacote sai sem autoria e sem rastro da maquina de origem. A prosa interna guarda no repositorio quem pediu cada mudanca
# e por onde cada fonte foi lida. As regras de troca e a guarda ficam em limpeza_pacote.py, local, que nao entra no zip.
# A guarda recusa o zip se sobrar nome proprio, caminho local ou nome de servico interno.
import re
try:
  sys.path.insert(0, AQUI); from limpeza_pacote import LIMPA, PROIBIDO
except ImportError:
  LIMPA, PROIBIDO = [], None
TEXTO = ('.md', '.py', '.sh', '.tsv', '.txt', '.csv', '.css', '.json', '.htm')
def limpa(t):
  for a, b in LIMPA: t = re.sub(a, b, t)
  return t
_sobras = []
def grava(z, f, r, dados=None):
  nome = os.path.join('gastos-publicos-brasil-dados', r)
  if dados is None and not r.endswith(TEXTO): z.write(f, nome); return
  if dados is None:
    try: dados = open(f, encoding='utf-8').read()
    except UnicodeDecodeError:  # arquivo oficial em latin-1: vai intacto, mas passa pela guarda
      if PROIBIDO: _sobras.extend(f'{r}: {m.group(0)!r}' for m in PROIBIDO.finditer(open(f, encoding='latin-1').read()))
      z.write(f, nome); return
  t = limpa(dados)
  if PROIBIDO: _sobras.extend(f'{r}: ...{t[max(0, m.start() - 40):m.end() + 30]!r}' for m in PROIBIDO.finditer(t))
  z.writestr(nome, t)

dst = os.path.join(AQUI, 'gastos-publicos-brasil-dados.zip')
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
  z.writestr('gastos-publicos-brasil-dados/LEIAME.txt', LEIAME)
  EST = os.path.normpath(os.path.join(RAIZ, '..', 'estilo'))  # sistema visual comum aos dois volumes, vai em estilo/ ao lado de relatorio/
  for pd in ('base.py', 'base.css', 'DESIGN.md', 'fontes/gera_estaticas.py', 'fontes/OFL-*.txt', 'fontes/estaticas/*.ttf'):
    for f in sorted(glob.glob(os.path.join(EST, pd))): grava(z, f, os.path.join('estilo', os.path.relpath(f, EST)))
  for f, r in arquivos():
    if r == 'X-fatores-mensal.csv':  # spread ICE BofA (em_oas) nao pode ser redistribuido: coluna em branco no pacote
      import csv, io
      rows = list(csv.reader(open(f, newline='', encoding='utf-8'))); k = rows[0].index('em_oas'); out = io.StringIO(); w = csv.writer(out)
      for i, row in enumerate(rows): w.writerow(row if i == 0 else row[:k] + [''] + row[k + 1:])
      grava(z, f, r, out.getvalue()); continue
    if 'BAMLEMCBPIOAS' in r: continue
    grava(z, f, r)
if _sobras:
  os.remove(dst); sys.exit('pacote recusado, sobrou nome proprio ou caminho local:\n' + '\n'.join(list(dict.fromkeys(_sobras))[:60]))
print(dst, round(os.path.getsize(dst) / 1e6, 1), 'MB', len(zipfile.ZipFile(dst).namelist()), 'arquivos')

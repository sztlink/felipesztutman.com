#!/usr/bin/env python3
# Pacote opcional com os arquivos oficiais baixados de cada frente (brutos/<frente>/), para refazer todos os CSV.
# Fora: B e G (os CSV que o relatorio usa ja estao no pacote principal) e o spread ICE BofA (licenca nao permite redistribuir).
# Uso: python3 monta_pacote_brutos.py  (gera brutos/gastos-publicos-brasil-brutos.zip, fora do git)
import os, zipfile
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
FORA_FRENTE = {'B', 'G'}
fora = lambda f: f.endswith(('.py', '.md', '.sh', '.tsv')) or 'BAMLEMCBPIOAS' in f or f == 'gastos-publicos-brasil-brutos.zip'
dst = os.path.join(RAIZ, 'brutos', 'gastos-publicos-brasil-brutos.zip'); n = 0
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
  for fr in sorted(os.listdir(os.path.join(RAIZ, 'brutos'))):
    if fr in FORA_FRENTE or not os.path.isdir(os.path.join(RAIZ, 'brutos', fr)): continue
    for dp, _, fs in os.walk(os.path.join(RAIZ, 'brutos', fr)):
      for f in sorted(fs):
        if fora(f): continue
        p = os.path.join(dp, f); z.write(p, os.path.join('gastos-publicos-brasil-dados', os.path.relpath(p, RAIZ))); n += 1
print(dst, round(os.path.getsize(dst) / 1e6, 1), 'MB', n, 'arquivos')

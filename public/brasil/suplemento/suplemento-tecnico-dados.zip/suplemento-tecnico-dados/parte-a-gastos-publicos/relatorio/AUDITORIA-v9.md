# Auditoria v9: partes novas do dossiê "Gastos públicos do Brasil"

Auditor independente, 19/10/2026. Escopo: seção 9 (primário que estabiliza a bruta, nota dos fluxos reais), seção 11 (quanto veio do mundo), seção 12 (todos os tributos por renda e tabela do topo, custo dos regimes de previdência, nota das linhas de pobreza do Banco Mundial), seção 14 (cenários da dívida até 2030) e os itens novos de "O essencial". Nenhum arquivo do dossiê foi editado. As contas de conferência rodaram num script à parte, no scratchpad da sessão.

Classes: **ERRO** = número ou fonte errados. **FRÁGIL** = premissa ou leitura discutível. **NOTA** = ajuste menor.

## Resumo

| # | Classe | Onde | Achado |
|---|---|---|---|
| E1 | ERRO | Seção 14 e Essencial | "Metas cumpridas" entram como primário cheio, mas a meta é líquida de abatimentos (precatórios etc.). Com o primário que o próprio PLDO projeta, o cenário 4 não estabiliza a dívida em 2030 |
| E2 | ERRO | Seção 12, FCDF | R$ 282.441 por beneficiário: a despesa (RREO republicado) e a contagem (PLDO) não são do mesmo universo. A diferença é de cerca de 1,8 vez |
| E3 | ERRO | Seção 9, nota dos fluxos | A nota diz que a soma dos fluxos reais não bate com a variação real do saldo. Bate, por construção, em todos os mandatos |
| E4 | ERRO | Seção 12, nota da pobreza | O Banco Mundial não "criou" a linha de US$ 8,30. Ele atualizou a de US$ 6,85 (PPC 2017) |
| E5 | ERRO | Seção 12, nota da previdência | O "sem patronal" (R$ -86,4 bi) cita [36] (MPS, 2-uniao.zip), mas o dado sai do RREO [35] |
| F1 | FRÁGIL | Seção 14 | Deflator = IPCA sem sensibilidade. +1 ponto no deflator tira 4,6 pontos da dívida de 2030 |
| F2 | FRÁGIL | Seção 14 | Prefixados e IPCA+ repreciam a partir do custo de 2025, não da taxa de mercado. Isso subestima a dívida de 2030 em cerca de 1,5 a 2 pontos |
| F3 | FRÁGIL | Seção 14 | A diferença para o PLDO (87,8%) não está explicada: não diz quanto pesam o crescimento nominal, a Selic, o primário e o resíduo |
| F4 | FRÁGIL | Seção 12 e Essencial | O título diz "custa ao Tesouro", mas o número dos civis conta a patronal da União como receita. O Essencial escolhe o INSS urbano por benefício |
| F5 | FRÁGIL | Seção 12, tabela do topo | Rótulos trocados ("sem o imposto retido na fonte") e colunas que misturam grupos diferentes |
| F6 | FRÁGIL | Seção 12, gráfico da previdência | O INSS urbano de 2012 a 2022 inclui a compensação do Tesouro pela desoneração (0,42% do PIB em 2015), e o relatório não avisa |
| F7 | FRÁGIL | Seção 14, cenário 4 | Não diz o valor em R$ e ignora a repartição com estados e municípios |
| F8 | FRÁGIL | Seção 11 | A frase de abertura afirma mais do que o parágrafo seguinte sustenta |
| N1 a N14 | NOTA | várias | ver abaixo |

## O que conferi e bate

- **Seção 9, primário que estabiliza a bruta.** i = 1.127.782,2 / 8.984.236,6 = 12,553% (BCB, Tabelas de estatísticas fiscais 202609, Tabela 19, conferido no xlsx). g = 12.738.565,6 / 11.779.250,6 - 1 = 8,144%. d = 78,64%. O primário que estabiliza é 3,21% do PIB; com i de 11%, 2,08%; com 10%, 1,35% (arredonda para 1,3 com g exato). Confere.
- **Seção 9, fatores reais.** Bolsonaro: juro real de R$ 140,8 bi por ano e variação real de R$ 152,5 bi por ano. Lula 3: R$ 594,2 bi e R$ 585,4 bi, em R$ de dez/2025. Confere com J-dbgg-fatores-reais.csv.
- **Seção 11.** As médias de DFII10 refeitas do CSV dão -0,170 (Bolsonaro) e 1,934 (Lula 3, 46 meses). Conferi DFII10 de 06/2022 e 03/2025 direto na FRED, ao vivo, e é idêntico ao arquivo baixado. O Tesouro Direto de 12/03/2025 (IPCA+ 2035 a 7,59) bate com o interpolado de 7,617. As diferenças anuais e a janela de 2023 a 2025 (4,59, ou 0,22 acima de 2019 a 2022) conferem.
- **Seção 12, POF.** TD 2823, p. 25, gráfico 3: diretos 3,0 e indiretos 23,4 no 1º décimo; 10,6 e 8,6 no 10º. Total 26,4 e 19,2. Na p. 22, 42,66% sobre a renda monetária. Confere.
- **Seção 12, topo.** Ipea CC 65, nota 8: 14,2 (percentil 98), 13,3 (último percentil), 13,2 (percentil 97), 10,3 e 9,7. SPE: 12,0 no centil 93 e 4,6 no 0,01% (2023, p. 9); 8,54, 5,67, 8,25 e 9,14 (PL 1.087, p. 4, 15 e 16). Os valores da RFB saem da aba BRV, e o script tem conferências de estrutura. Confere.
- **Seção 12, previdência.** RTN, tabela 2.2: urbano 696.507,4 / 808.101,3 e rural 13.206,9 / 218.771,3 (conferido no xlsx). Siconfi 2025: civil 42.513,1 (dos quais 23.787,4 de patronal) e despesa 105.091,5; militares 9.570,0, 28.212,1 e 34.389,9. PLDO IV.11, p. 15: 467.837 aposentados e 296.641 pensionistas; p. 18: déficit atuarial de R$ 1.483.930.703.882 a 5,42%. IV.12, p. 7 e 9: 486,4 bi, 386,3 bi e 168.564 inativos. Confere.
- **FCDF 2025 transcrito.** Renderizei a página 20 do RREO republicado: 1.144.579, 256.758, 887.821, 10.419.105, 10.410.381 e -9.274.526 batem com o dicionário `FCDF_2025_REPUBL`. A declaração está visível no relatório ("transcrito da versão republicada do RREO, cujo texto não é legível por máquina"), no LEIAME e na nota de cada linha do CSV.
- **Pobreza no Banco Mundial.** API PIP ao vivo: 2024 com US$ 8,30 dá 0,2065; 2019 com US$ 3,00 dá 0,0703. Confere com o CSV.
- **Seção 14.** Refiz o simulador do zero e ele reproduz o S-cenarios-divida.csv (94,17; 100,56; 90,76; 87,28; 105,35). Os pesos conferem: compromissadas 7,77/78,64 = 9,9%, mais 90,1% x 48,25% (Selic) = 53,4%; IPCA 23,4%; prefixados 19,9%. O Focus de 09/10/2026 no PDF tem IPCA 2026 de 5,22, Selic 13,25/12,00/10,50/10,00 e PIB 1,85/1,40/1,83/2,00, igual ao json. PLDO IV.2: metas de 0,50/1,00/1,25/1,50 e DBGG de 87,8% em 2029 (p. 7 e Tabela 4, p. 17).
- **Travessão.** Nenhum em dash (nem en dash) no HTML.
- **Presidente ou mandato nos gráficos novos.** Incidência: "POF 2017-2018 (Temer)". Previdência: faixas de mandato. Cenários: "Lula 3 / próximo mandato (2027-2030)". A seção 11 nova não tem gráfico (é tabela por governo). Atendem, com a ressalva de rótulo em N2.
- **Valor digitado no código.** O único dado digitado é o FCDF de 2025, e está declarado. São digitadas também premissas (1/5, 1,5 ponto, 2 pontos, um terço por ano) e fatos legais (Lei 15.270, R$ 600 mil, 10%), o que é aceitável. As descrições digitadas ("quase dois terços no rural" = 64,8%; "a menor da série em 2019"; "cai do 1º ao 6º décimo") conferem com os dados.

## ERROs

### E1. Meta de primário tomada como primário que move a dívida (seção 14 e Essencial)

Nos cenários 2 a 4, o primário do Governo Central é igual à meta do PLDO (0,50; 1,00; 1,25; 1,50). Só que a meta é aferida **depois de abatimentos**. O próprio Anexo IV.2, p. 6, diz que o primário projetado de 2027 é de 0,05% do PIB e que só chega a 0,50% "compensando R$ 65,66 bilhões (0,45% do PIB)" de precatórios, defesa e Fundo Social. A dívida vê o primário cheio. O ponto de partida (-0,46% em 2025, RTN) já é cheio, então os cenários saltam de uma base cheia para uma base líquida de abatimentos.

O PLDO, na Tabela 4 (p. 17), projeta o primário do SPNF compatível com as metas: 0,01, 0,59, 0,91 e 1,25 (2027 a 2030). Rodei o mesmo simulador com essa trajetória no lugar das metas:

| Cenário | Dívida 2030, relatório | Dívida 2030, primário do PLDO | Primário 2030 contra o que estabiliza |
|---|---|---|---|
| 2. Metas | 94,2 | 95,8 | |
| 3. Metas e prêmio menor | 90,8 | 92,3 | |
| 4. Ajuste forte | 87,3 (para em 87) | 88,8, ainda subindo (88,70 em 2029 e 88,84 em 2030) | 2,21 contra 2,35: **não estabiliza** |

**Correção sugerida.** Usar como primário o resultado do SPNF da Tabela 4 do PLDO, ou a meta menos os abatimentos previstos, e trocar o nome "metas cumpridas" por "metas cumpridas, com os abatimentos previstos no PLDO". O item do Essencial ("Só metas, Selic mais baixa e receita nova juntas a estabilizam, perto de 87%") cai: com o primário do PLDO, o cenário 4 chega a 2030 em 88,8% e ainda subindo. A alternativa é manter as metas como primário cheio e dizer explicitamente que isso é um esforço maior que o exigido pela meta (0,25 a 0,49 ponto por ano).

### E2. FCDF: R$ 282.441 por beneficiário com numerador e denominador de universos diferentes (seção 12, tabela de 2025)

A despesa é a do RREO republicado: R$ 10,42 bi, dos quais R$ 9,08 bi de aposentadorias. O denominador é a base do PLDO IV.11, Anexo XV (p. 88): 21.620 inativos com provento médio de R$ 17.031 e 11.217 pensionistas com R$ 6.650. Essa base implica 21.620 x 17.031 x 13 + 11.217 x 6.650 x 13 = **R$ 5,76 bi** por ano, perto da versão original do RREO (R$ 5,13 bi), não da republicada. Dividir a aposentadoria republicada pelos inativos dá cerca de R$ 32 mil por mês, quase o dobro do provento médio que a própria avaliação informa. Nos civis e nos militares, o mesmo teste fecha (civis: cerca de R$ 108 bi implícitos contra 105,1 no RREO; militares: 59,5 contra 62,6). Só o FCDF não fecha.

**Correção sugerida.** Não publicar o resultado por beneficiário do FCDF, ou mostrar a faixa: R$ -141 mil por ano, se a despesa for coerente com a base do PLDO ((5,76 - 1,14) / 32.837), até R$ -282 mil, com a despesa republicada. Dizer na nota que a republicação dobrou a despesa (de 5,13 para 10,42 bi) e que a contagem do PLDO não acompanha essa mudança. O resultado em % do PIB (-0,07) pode ficar, com a mesma ressalva.

### E3. A nota dos fluxos reais afirma uma desigualdade que não existe (seção 9)

A nota diz: "A soma dos fluxos corrigidos ano a ano não é igual à diferença entre os saldos inicial e final em reais, porque cada fluxo é corrigido pelo IPCA do seu ano e a reposição usa o saldo de dezembro anterior". Com a reposição definida como IPCA de dez a dez vezes D(t-1) e cada fluxo levado a R$ de dez/2025 pelo índice de dezembro do seu ano, a identidade é exata: D(t)/P(t) - D(t-1)/P(t-1) = (ΔD - π·D(t-1))/P(t). Conferi nos dados de todos os anos e mandatos:

| Mandato | Soma dos fluxos reais (J-dbgg-fatores-reais) | Saldo final menos inicial em R$ de dez/2025 (I-divida-bruta-anual) |
|---|---|---|
| Lula 2 | 875,6 | 875,6 |
| Dilma | 1.811,6 | 1.811,6 |
| Bolsonaro | 609,8 | 8.261,8 - 7.652,0 = 609,8 |
| Lula 3 (2023 a 2025) | 1.756,1 | 10.017,9 - 8.261,8 = 1.756,1 |

**Correção sugerida.** Trocar por: "A soma dos fluxos reais do mandato é igual, por construção, à variação do saldo em reais (R$ 610 bi no governo Bolsonaro, R$ 1.756 bi de 2023 a 2025). A aproximação está na divisão entre reposição da inflação e juro real, porque a reposição ignora a erosão dos fluxos de dentro do ano".

### E4. "Criou a [linha] de US$ 8,30" (nota da pobreza, seção 12)

A factsheet do Banco Mundial de 05/06/2025 diz: "the UMIC poverty line is adjusted from $6.85 to $8.30". A linha para países de renda média-alta já existia. **Correção sugerida:** "e atualizou a linha de países de renda média-alta, como o Brasil, de US$ 6,85 (PPC 2017) para US$ 8,30 (PPC 2021)". Os números (3,0 e 20,6 em 2024; 7,0 e 28,0 em 2019) conferem com a API.

### E5. Fonte trocada no "sem patronal" (nota da tabela de previdência de 2025)

"Sem ela, o resultado dos civis seria R$ -86,4 bi (-112.973 por beneficiário) [36]". O [36] é "Ministério da Previdência, estatísticas dos RPPS, União (2-uniao.zip)", mas o número sai de RREO-Anexo 04.2, conta ReceitaDeContribuicoesPatronalPrevidenciario (R$ 23.787,4 mi), isto é, do [35]. **Correção sugerida:** citar [35]; o denominador vem do [37].

## FRÁGEIS

### F1. Deflator igual ao IPCA, sem sensibilidade (seção 14)

A premissa está declarada, mas é a que mais pesa no resultado e não tem número de sensibilidade. Em 2025 o deflator implícito foi de cerca de 5,7% (8,14% de crescimento nominal com 2,3% de real), contra IPCA de 4,26%. A grade do PLDO (mar/2026) supõe deflator de 4,4% a 4,9% de 2026 a 2030, contra IPCA de 3,0% a 3,7%. No simulador, deflator 1 ponto acima do IPCA leva o cenário 2 de 94,2 para **89,6** em 2030; com o crescimento nominal da grade do PLDO, para 88,1. **Sugestão:** declarar na nota "cada ponto de deflator acima do IPCA tira cerca de 4,6 pontos da dívida de 2030" e dizer que o Focus não pesquisa o deflator.

### F2. A repreficação parte do custo de 2025, não da taxa de mercado (seção 14)

O termo dos prefixados só reage à diferença Selic(t) - Selic(2025). Mas o custo dos prefixados em 2025 (11,76%, RMD) ainda está abaixo da Selic média do ano (14,42%) e das taxas de emissão, porque o estoque tem papéis antigos. Com Selic constante, o modelo deixa esse desconto para sempre. O mesmo vale para o IPCA+: custo real do estoque de 5,6% em 2025 (10,13% de custo com IPCA de 4,26), contra NTN-B de mercado perto de 7,5%. Na conferência, fazendo os prefixados convergirem um terço por ano para a Selic do ano e o juro real do IPCA+ convergir 12% por ano para o de mercado, o cenário 2 vai de 94,2 para **96,3** em 2030 e o cenário 4 de 87,3 para **89,3**, ainda subindo. **Sugestão:** declarar que o peso dos prefixados mede só a variação da Selic, não o atraso já embutido no estoque, e dar a faixa de +1,5 a +2 pontos.

### F3. A diferença para o PLDO não está explicada (seção 14)

"Que usa premissas de crescimento e juros próprias" está certo, mas não explica o tamanho da diferença. Com o simulador:

- grade do PLDO de 05/03/2026: Selic acumulada de 13,53/10,55/9,27/8,27/7,27 contra 14,25/12,62/11,25/10,25/10,00 na premissa do relatório; crescimento nominal de 6,8/7,6/7,4/7,4/7,45% contra 7,2/5,8/5,7/5,6/5,6%;
- só a Selic do PLDO leva o cenário 2 de 2029 de 92,3 para 88,6; só o crescimento nominal do PLDO, para 88,0;
- com a macro e o primário do PLDO juntos, o simulador dá 84,5 em 2029, **abaixo** dos 87,85 do PLDO. A projeção do Tesouro embute cerca de 3 pontos de outros efeitos (ajustes entre fluxo e estoque, base de 2026), que o simulador não tem;
- o primário do PLDO é menor que as metas (E1), o que joga na direção contrária.

**Sugestão:** uma frase como "a grade do PLDO, de março, tem Selic de 7,3% e crescimento nominal de 7,4% em 2030, contra 10,0% e 5,6% aqui. Só essas duas premissas explicam mais que a diferença; o Tesouro soma ainda cerca de 3 pontos de ajustes que este simulador não tem". Mostrar também a trajetória inteira do PLDO no gráfico (85,96; 87,27; 87,85; 87,53), e não só o ponto de 2029.

### F4. "Quanto cada regime custa ao Tesouro" com a patronal da União contada como receita (seção 12 e Essencial)

O título fala em custo ao Tesouro, mas o número principal dos civis (R$ -62,6 bi, R$ -81.858 por beneficiário) conta como receita a patronal que a União paga a si mesma. O custo para o Tesouro é o "sem patronal" da nota: **R$ -86,4 bi (0,68% do PIB), R$ -112.973 por beneficiário**. O mesmo vale para o FCDF (patronal de 0,89 dos 1,14 bi) e para o déficit atuarial civil (o VP das contribuições futuras inclui a patronal). O Essencial cita o INSS urbano (R$ 4.516), e não o INSS inteiro (R$ 9.017, ou R$ 19.652 no rural), e não diz que esse número é por benefício, enquanto o dos regimes próprios é por pessoa. A comparação "INSS urbano por benefício contra civis com patronal por pessoa" puxa nas duas direções e não é neutra. **Sugestão:** trocar o título por "Resultado de cada regime"; ou manter o título e usar o sem patronal como número principal dos civis. No Essencial, dar o INSS total e dizer "por benefício".

### F5. Rótulos da tabela do topo (seção 12)

- "Só IRPF do ajuste anual (piso: sem o imposto retido na fonte)": o "Imposto Devido" da RFB é a tabela progressiva aplicada à base (metadados AC 2024, campo 42) e **inclui** o que foi retido na fonte sobre rendimento tributável. O que fica de fora é o IR **exclusivo ou definitivo** (13º, aplicações, ganho de capital, JCP, PLR). O LEIAME e a nota do gráfico do IRPF dizem isso certo; o rótulo da tabela diz errado. Corrigir para "sem o IR exclusivo na fonte".
- "IRPF com o retido na fonte": a SPE imputa o IR exclusivo (15% sobre aplicações etc., p. 5 do relatório). Corrigir para "com o IR exclusivo imputado".
- Nessa linha, as colunas "1% mais rico" e "0,1% mais rico" recebem o pico (centil 93) e o 0,01%. Quem lê a coluna compara 3,0 com 12,0 e 10,3 como se fossem o mesmo grupo. Mover esses valores para o texto, ou acrescentar uma coluna "outro grupo".
- "Metade do imposto da empresa": no Ipea, o Simples entra sempre com 100%; os 50% valem para Real e Presumido. Dizer isso.

### F6. Compensação da desoneração dentro do INSS urbano (gráfico da previdência)

De 2012 a 2022 a arrecadação do RTN inclui a compensação do Tesouro pela desoneração da folha (R$ 25,4 bi em 2015, cerca de 0,42% do PIB; R$ 3,1 bi em 2022; zero desde 2023). No gráfico, o urbano de 2015 aparece em +0,09% do PIB; sem a transferência do Tesouro, seria cerca de -0,3%. O LEIAME de U declara isso; o relatório não. **Sugestão:** uma frase na nota, ou plotar o urbano sem a compensação.

### F7. Cenário 4: valor em R$ e repartição (seção 14)

O relatório não dá o valor em R$. 1/5 dos subsídios tributários do OSU de 2024 (R$ 563,5 bi) dá **R$ 112,7 bi de 2024**. Mantido em 0,96% do PIB, isso é cerca de R$ 146 bi em 2028 e R$ 160 bi em 2030, em valores correntes. Parte desse gasto tributário é de IR e IPI, cuja arrecadação é repartida com estados e municípios (FPE, FPM e fundos regionais). O ganho no primário do Governo Central, que é o perímetro usado, seria menor que 0,96%. **Sugestão:** dar o valor em R$ e dizer que 0,96% é o ganho do governo geral, não o líquido de transferências. Harmonizar também com o Essencial, que cita 4,9% (2023, DGT [21]) enquanto aqui é 4,80% (2024, OSU [45]).

### F8. "Sobra a diferença que é do Brasil" (seção 11)

A frase de abertura atribui ao Brasil o resto da subtração. O parágrafo seguinte diz, corretamente, que esse resto inclui prêmio de emergentes, liquidez e apetite global por risco. **Sugestão:** "sobra a diferença em relação aos EUA". A subtração um para um é premissa não declarada, mas os dados a sustentam: numa regressão mensal de 2008 a 2026, o beta do juro real brasileiro contra o americano é de 1,06 em nível e 0,83 em variações de 12 meses. Vale dizer isso numa nota.

## NOTAs

- **N1.** R-juro-real-br-eua.csv rotula 2016 como "Temer" (pega o presidente do último mês do ano). Nas outras frentes, 2016 é "Dilma/Temer". O texto não usa o rótulo, mas o CSV sai no pacote.
- **N2.** O gráfico da previdência rotula 2008 a 2010 como "Lula 1 e 2" (a série começa em 2008, então é só Lula 2). O eixo usa ponto decimal ("−1.5"), e o resto do documento usa vírgula.
- **N3.** O Focus de 09/10/2026 também pesquisa o primário (-0,41; -0,40; -0,27; -0,15 de 2026 a 2029). Um cenário "Focus inteiro" dá 99,6% em 2030, perto da inércia. Ajudaria o leitor de mercado a situar as metas do PLDO, que estão longe do consenso.
- **N4.** O "primário que estabiliza em 2030" usa d(t) em vez de d(t-1) na fórmula. O efeito é de centésimos, mas a fórmula da seção 9 usa d(t-1).
- **N5.** "O crescimento nominal do Focus, perto de 5,6%": o Focus não publica crescimento nominal; ele é calculado com o IPCA (ver F1).
- **N6.** Seção 9: g citado em [1] (RTN), mas o PIB vem do BCB SGS 4380 e do IBGE (K-primario-recorrente, LEIAME de K). Citar a fonte do PIB.
- **N7.** Na seção 9, "para qualquer governo" soa como juízo. Trocar por "independe de quem governa: é aritmética do estoque".
- **N8.** O cenário de estresse sobe a Selic em 2 pontos sem mexer no crescimento nem na inflação. É coerente como choque isolado, mas convém dizer.
- **N9.** Na previdência de 2025, o INSS está em caixa (RTN, pago) e os regimes próprios em despesa empenhada (RREO, 6º bimestre). Declarar na nota.
- **N10.** Nota da pobreza: o Banco Mundial dá 3,0% com US$ 3,00 (PPC 2021), e o IBGE dá 3,5% com US$ 2,15 (PPC 2017). O leitor vai estranhar uma linha maior com pobreza menor. Uma frase sobre a mudança do fator PPC resolve.
- **N11.** A seção 11 usa a taxa de compra do Tesouro Direto, que fica alguns pontos-base abaixo da taxa indicativa da ANBIMA. O desvio é quase constante e não afeta diferenças entre governos, mas o nível fica levemente subestimado contra o DFII10, que é taxa de mercado.
- **N12.** Fonte [35]: a URL do PDF republicado do RREO de dez/2025 não está registrada (o LEIAME de U admite). Registrar.
- **N13.** O item do Essencial "déficit por beneficiário ... (2025) [35]" mistura fontes: o INSS vem de [1] e [48]. Citar as três. O "6,6 vezes" compara provento civil de 2024 com INSS de dez/2025; dizer os anos.
- **N14.** Seção 9: como i é o juro da DBGG, que inclui as compromissadas pagas pelo BC, sem o rendimento das reservas, a exigência de primário fica no teto. A frase "perímetros diferentes" cobre isso, mas pode citar o exemplo.

## Itens novos do Essencial

1. "Somando consumo, renda e patrimônio (POF 2017-2018) ... 26,4% ... 19,2%": confere (TD 2823, p. 25).
2. "Déficit por beneficiário: R$ 4.516 no INSS urbano, R$ 81.858 nos civis, R$ 134.981 nos militares": os números conferem, a leitura é frágil (F4) e a fonte está incompleta (N13).
3. "Descontado o juro real americano ... cai para 0,4 ponto, que não é só efeito doméstico": confere (2,50 - 2,10 = 0,40). Bom que diga "não é só doméstico".
4. "Focus de outubro e metas do PLDO: 94% em 2030; primário de 2025: 101%; só metas, Selic mais baixa e receita nova juntas a estabilizam, perto de 87%": o 94 e o 101 reproduzem o simulador, mas a conclusão sobre a estabilização cai com E1 e fica mais fraca com F1 e F2. Sugestão: "Com o primário que o próprio PLDO projeta para cumprir as metas, a dívida chega a 96% em 2030; nem com Selic mais baixa e receita nova ela para de subir até 2030 (89%)". Ou manter a frase atual, desde que diga que o primário das metas é tomado cheio, sem abatimentos.

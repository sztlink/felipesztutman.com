# Reprodução do dossiê: cobertura e passo a passo

Teste feito em 19/10/2026 numa pasta vazia, só com os dois pacotes distribuídos, depois das correções da v10.1.

Teste da v12.6, em 20/10/2026. Numa pasta vazia, só com `gastos-publicos-brasil-dados.zip` e sem nenhum bruto, `monta_relatorio.py`
refez os gráficos, o HTML e o PDF, com 67 páginas e o texto igual ao distribuído página a página, e `testes.py` passou sem falha. Na
v12.5 o relatório ainda lia dois brutos fora do pacote (SIDRA 5932 e SIOP de 2013), que viraram `FN-pib-agro.csv` e
`FN-ordenamento-territorial.csv`. Um teste confere que todo arquivo de `brutos/` lido pelo relatório está no zip.

## Pacotes
- `gastos-publicos-brasil-dados.zip`: CSV, scripts, LEIAMEs, `downloads.tsv` de cada frente, PDF, auditorias, testes e as entradas
  do simulador.
- `gastos-publicos-brasil-brutos.zip` (cerca de 550 MB, opcional): os arquivos oficiais baixados de cada frente, menos B e G, cujos
  CSV já estão no pacote principal, e menos o spread ICE BofA.

## Passos
1. Extrair os dois zips na mesma pasta.
2. `python3 -P relatorio/verifica_reproducao.py`: refaz todos os CSV a partir dos brutos e compara por hash com os distribuídos.
3. `python3 relatorio/monta_relatorio.py`: refaz os gráficos, o HTML e o PDF. Precisa de matplotlib, openpyxl, pymupdf e
   WeasyPrint 70 (ou google-chrome com MOTOR_PDF=chrome). Também gera as separatas temáticas em relatorio/tematicos/.
4. `python3 -P relatorio/testes.py`: identidades contábeis, simulador, conciliação, convenções editoriais, texto contra CSV e licença
   do pacote.

## Cobertura do teste limpo
- Todos os scripts, menos `brutos/X/build_X.py`, rodaram: 92 CSV idênticos aos distribuídos, 0 alterados. Com a série ICE baixada
  (máquina de origem), os 95 CSV, inclusive os da frente X, saem idênticos.
- O PDF regerado tem o mesmo texto do distribuído, descontada a data de geração embutida nos SVG.
- `testes.py` passou sem falha.

## O que precisa de download externo
- Frente X, regressões e fatores externos: o spread ICE BofA de corporativos de emergentes (FRED `BAMLEMCBPIOAS`) não pode ser
  redistribuído. Para rodar a frente:
  - `bash brutos/X/baixa_X.sh` baixa todas as séries da frente, inclusive a ICE: o FRED, que desde abril de 2026 mostra só 3 anos, e
    o histórico pelo Internet Archive (`wayback_20241026_BAMLEMCBPIOAS.html`);
  - depois, `python3 -P brutos/X/build_X.py`.
  Sem esses arquivos, o verificador pula a frente X e avisa, e os CSV X-*.csv do pacote ficam sem conferência independente. Na
  coluna `em_oas` de `X-fatores-mensal.csv`, o pacote traz a série em branco.
- Os demais brutos podem ser baixados de novo pelas URLs de cada `downloads.tsv`, com a data da consulta original. Algumas fontes
  do gov.br saíram do ar ("Conteúdo Restrito") e foram lidas na cópia do Internet Archive, com hash conferido. O LEIAME de cada
  frente indica quais.

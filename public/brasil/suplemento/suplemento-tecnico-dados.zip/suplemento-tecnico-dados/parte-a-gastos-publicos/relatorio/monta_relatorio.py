#!/usr/bin/env python3
# Relatorio em PDF dos gastos publicos: graficos (matplotlib, SVG) + HTML + Chrome headless.
import csv, json, os, re, subprocess, openpyxl
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.join(AQUI, '..')
G = os.path.join(AQUI, 'graficos'); os.makedirs(G, exist_ok=True)
import sys; sys.path.insert(0, AQUI)
from estilo import STYLE, LARG, css, glifos, endereca, sumario, imprime_pdf, voz_saida as _voz  # sistema visual comum do dossie (economia-brasil/estilo), fontes incluidas
plt.rcParams.update(STYLE)
ESCURO, CINZA, AZUL = '#1f1f1f', '#8a8a8a', '#1d4e89'
# mandatos por ano civil; 2016 e o ano da troca (Dilma afastada em 12/05/2016), com faixa propria hachurada
GOV = [(1997, 2002, 'FHC', 1), (2003, 2010, 'Lula 1 e 2', 0), (2011, 2015, 'Dilma', 1), (2016, 2016, 'D/T', 2), (2017, 2018, 'Temer', 0),
       (2019, 2022, 'Bolsonaro', 1), (2023, 2025, 'Lula 3', 0)]
SIGLA = {'FHC': 'FHC', 'Lula 1 e 2': 'L2', 'Lula 2': 'L2', 'Dilma': 'D', 'D/T': 'D/T', 'Temer': 'T', 'Bolsonaro': 'B', 'Lula 3': 'L3'}
def faixas(ax, ini=1997, rotulo=True, y=None, fs=7, sigla=False):
  for a, b, nome, tom in GOV:
    if b < ini: continue
    a = max(a, ini)
    if tom == 1: ax.axvspan(a - 0.5, b + 0.5, color='#efefef', lw=0, zorder=0)  # FAIXA do sistema comum
    if tom == 2: ax.axvspan(a - 0.5, b + 0.5, facecolor='none', edgecolor='#d4d4d4', hatch='////', lw=0, zorder=0)
    if nome == 'Lula 1 e 2' and ini > 2003: nome = 'Lula 2'
    if rotulo and (nome != 'D/T' or not sigla):
      ax.text((a + b) / 2, y if y is not None else 1.0, SIGLA[nome] if sigla else nome, ha='center', va='bottom', fontsize=fs, color=CINZA,
              transform=ax.get_xaxis_transform() if y is None else ax.transData, clip_on=False)

def le(arq):
  with open(os.path.join(RAIZ, arq), newline='', encoding='utf-8') as f:
    return list(csv.DictReader(f))
br = lambda v, d=0: f'{v:,.{d}f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
# eixos no padrao brasileiro em todo grafico: na hora de salvar, eixo que ainda usa o formatador padrao do matplotlib ganha
# virgula decimal e ponto de milhar. Eixo so de anos fica como esta, e eixo com formatador proprio nao e tocado.
import matplotlib.figure as _mfig
from matplotlib.ticker import ScalarFormatter as _SF, FuncFormatter as _FF
def _eixos_br(fig):
  for ax in fig.axes:
    for eixo in (ax.xaxis, ax.yaxis):
      if type(eixo.get_major_formatter()) is not _SF: continue
      locs = list(eixo.get_majorticklocs())
      if not locs or all(abs(v - round(v)) < 1e-9 and 1900 <= v <= 2100 for v in locs): continue
      d = next(d for d in range(4) if all(abs(v * 10 ** d - round(v * 10 ** d)) < 1e-6 for v in locs) or d == 3)
      eixo.set_major_formatter(_FF(lambda v, _, d=d: br(v, d)))
_salva = _mfig.Figure.savefig
def _salva_br(self, *a, **k):
  _eixos_br(self); return _salva(self, *a, **k)
_mfig.Figure.savefig = _salva_br

# 1. Uniao 2025 em R$ bi
u = [r for r in le('ABSOLUTO-uniao-2025.csv') if r['soma'] == 'sim']
nomes = {'Aposentadorias e pensoes do INSS': 'INSS', 'Juros da divida': 'Juros da dívida (nominais, competência)', 'Repasses constitucionais': 'Repasses a estados e municípios',
         'Saude': 'Saúde (sem pessoal)', 'Servidores e militares': 'Servidores e militares na ativa', 'Aposentados e pensionistas': 'Aposentados e pensionistas da União',
         'Bolsa Familia': 'Bolsa Família', 'BPC': 'BPC', 'Resto da maquina': 'Resto da máquina e investimentos', 'Demais despesas': 'Demais obrigatórias',
         'Educacao': 'Educação (sem pessoal)', 'Seguro-desemprego': 'Seguro-desemprego e abono', 'Precatorios': 'Precatórios'}
curto = lambda b: next((v for k, v in nomes.items() if b.startswith(k)), b)
fig, ax = plt.subplots(figsize=(LARG, 4.2))
ys = list(range(len(u)))[::-1]
vals = [float(r['valor_rs_bi']) for r in u]
ax.barh(ys, vals, color=[AZUL if 'Juros' in r['bloco'] else CINZA for r in u], height=0.65)
ax.set_yticks(ys, [curto(r['bloco']) for r in u]); ax.grid(axis='y', visible=False)
for y, v in zip(ys, vals): ax.text(v + 12, y, br(v, 1), va='center', fontsize=8, color=ESCURO)
ax.set_xlabel('R$ bilhões, 2025 (governo Lula 3)'); ax.tick_params(axis='y', length=0)
fig.tight_layout(); fig.savefig(f'{G}/1-uniao-2025.svg'); plt.close(fig)

# 2. Despesa primaria e resultado primario, % do PIB, 1997 a 2025, com governos
wb = openpyxl.load_workbook(os.path.join(RAIZ, 'brutos', 'D', 'seriehistoricaago26.xlsx'), read_only=True, data_only=True)
rows = list(wb['2.1-A'].iter_rows(values_only=True))
hdr = next(r for r in rows if r[0] and 'Discrimina' in str(r[0]))
anos = [int(a) for a in hdr[1:] if isinstance(a, (int, float))]
def serie(prefixo):
  r = next(r for r in rows if r[0] and str(r[0]).strip().startswith(prefixo))
  return [float(v) * (100 if abs(float(v)) < 1 else 1) for v in r[1:1 + len(anos)]]
desp, res = serie('4. DESPESA TOTAL'), serie('8. RESULTADO PRIM')
fig, (a1, a2) = plt.subplots(2, 1, figsize=(LARG, 4.6), sharex=True, gridspec_kw={'height_ratios': [3, 2]})
faixas(a1, fs=8); faixas(a2, rotulo=False)
a1.plot(anos, desp, color=ESCURO, lw=1.8); a1.set_ylim(12, 27); a1.set_ylabel('despesa primária, % do PIB')
a2.bar(anos, res, color='#4d4d4d', width=0.7)  # cor unica, o sinal vem da posicao (leitura de design por agente de IA, recomendacao 5); a2.axhline(0, color=ESCURO, lw=0.6)
a2.set_ylabel('resultado primário, % do PIB'); a2.set_ylim(-10.5, 3.5)
a2.annotate('-9,8 em 2020 (pandemia)', (2020, -9.8), xytext=(2009, -8.5), fontsize=8, color=ESCURO, arrowprops={'arrowstyle': '-', 'color': CINZA, 'lw': 0.6})
fig.tight_layout(); fig.savefig(f'{G}/2-primario-governos.svg'); plt.close(fig)

# 3. Historico por habitante, small multiples
ACENTO = {'Repasses a estados e municipios': 'Repasses a estados e municípios', 'Saude': 'Saúde', 'Aposentados da Uniao': 'Aposentados da União',
          'Bolsa Familia': 'Bolsa Família', 'Resto da maquina': 'Resto da máquina', 'Demais obrigatorias': 'Demais obrigatórias',
          'Educacao': 'Educação', 'Precatorios': 'Precatórios', 'por beneficio': 'por benefício', 'por familia': 'por família',
          'Seguro-desemprego e abono': 'Seguro-desemp. e abono'}
def acento(c):
  for k, v in ACENTO.items(): c = c.replace(k, v)
  return c
def largo(arq):
  r = le(arq); cols = [c for c in r[0] if c not in ('ano', 'ano_presidente')]
  return [int(x['ano']) for x in r], {acento(c): [float(x[c]) if x[c] else None for x in r] for c in cols}
A, H = largo('H-largo-por-habitante.csv')
def quebra_titulo(c):
  """Título longo de painel quebra em duas linhas, no parêntese ou no espaço mais perto do meio, para não invadir o vizinho."""
  if len(c) <= 24: return c
  if ' (' in c: return c.replace(' (', '\n(')
  esp = [k for k, ch in enumerate(c) if ch == ' ']
  k = min(esp, key=lambda k: abs(k - len(c) / 2))
  return c[:k] + '\n' + c[k + 1:]

def painel(nome, A, D, ncols, destaque, unidade):
  n = len(D); nl = -(-n // ncols)
  fig, axs = plt.subplots(nl, ncols, figsize=(LARG, 1.85 * nl + 0.3), sharex=True)
  for j, (ax, (c, v)) in enumerate(zip(axs.flat, D.items())):
    faixas(ax, ini=2008, fs=6, sigla=True)
    xs = [a for a, y in zip(A, v) if y is not None]; yv = [y for y in v if y is not None]
    ax.plot(A, [float('nan') if y is None else y for y in v], color=AZUL if destaque and c.startswith(destaque) else ESCURO, lw=1.5)  # buraco fica buraco
    ax.plot(xs[-1], yv[-1], 'o', ms=3, color=AZUL if destaque and c.startswith(destaque) else ESCURO)
    ax.set_ylim(0, max(yv) * 1.3); ax.set_xlim(2007.5, 2028.5); ax.set_title(quebra_titulo(c), fontsize=8.5, loc='left', color=ESCURO, pad=11)
    ax.text(xs[-1] + 0.6, yv[-1], br(yv[-1]), fontsize=7.5, va='center', ha='left', color=ESCURO)
    ax.set_xticks([2010, 2015, 2020, 2025]); ax.tick_params(labelsize=7); ax.yaxis.set_major_formatter(lambda x, _: br(x))
  for ax in list(axs.flat)[n:]: ax.set_visible(False)
  fig.text(0.01, 0.005, unidade, fontsize=7.5, color=CINZA)
  fig.tight_layout(rect=(0, 0.02, 1, 1)); fig.savefig(f'{G}/{nome}.svg'); plt.close(fig)
painel('3-por-habitante', A, H, 4, 'Juros', 'R$ de 2025 por habitante (IPCA dez a dez), escala própria a partir de zero. L2 Lula 2, D Dilma, hachura 2016, T Temer, B Bolsonaro, L3 Lula 3.')
A, B = largo('H-largo-por-beneficiado.csv')
# saude e educacao saem: o gasto federal sem pessoal dividido por usuarios de redes que sao sobretudo estaduais e municipais nao mede custo por atendido
B = {k: v for k, v in B.items() if not k.startswith(('Saúde', 'Educação'))}
painel('4-por-beneficiado', A, B, 3, None, 'R$ de 2025 por beneficiado por ano. Servidores sem dado de 2015 a 2019. L2, D, hachura 2016, T, B, L3 como acima.')
A, R = largo('H-largo-rs-bi-2025.csv')
fig, ax = plt.subplots(figsize=(LARG, 3.6))
faixas(ax, ini=2008)
rot = []
for c, v in R.items():
  if c in ('INSS', 'Juros', 'Repasses a estados e municípios', 'Saúde', 'Servidores ativos', 'Bolsa Família', 'Educação'):
    ax.plot(A, v, color=AZUL if c == 'Juros' else (ESCURO if c == 'INSS' else CINZA), lw=2 if c in ('Juros', 'INSS') else 1.2)
    rot.append([v[-1], c])
rot.sort()
for i in range(1, len(rot)):
  rot[i][0] = max(rot[i][0], rot[i - 1][0] + 38)
for y, c in rot: ax.text(A[-1] + 0.4, y, f'{c}  {br(R[c][-1])}', fontsize=7.5, va='center', color=ESCURO)
ax.set_xlim(2008, 2030); ax.set_xticks(range(2008, 2026, 2)); ax.set_ylabel('R$ bilhões de 2025'); ax.yaxis.set_major_formatter(lambda x, _: br(x))
fig.tight_layout(); fig.savefig(f'{G}/5-rs-bi.svg'); plt.close(fig)
print('graficos ok')

# 6. Divida bruta e liquida, % do PIB, dezembro, com presidentes
DV = {}
for r in le('I-divida-historico.csv'): DV.setdefault(r['serie'], {})[int(r['ano'])] = float(r['pct_pib_dez'])
dl = {**DV['dlsp_longa'], **DV['dlsp']}
fig, ax = plt.subplots(figsize=(LARG, 3.4))
faixas(ax, ini=2001)
ax.plot(sorted(DV['dbgg']), [DV['dbgg'][a] for a in sorted(DV['dbgg'])], color=AZUL, lw=2)
ax.plot(sorted(dl), [dl[a] for a in sorted(dl)], color=ESCURO, lw=1.6)
ax.text(2025.4, DV['dbgg'][2025], f"bruta {br(DV['dbgg'][2025], 1)}", fontsize=7.5, va='center', color=AZUL)
ax.text(2025.4, dl[2025], f"líquida {br(dl[2025], 1)}", fontsize=7.5, va='center', color=ESCURO)
ax.set_xlim(2000.5, 2028.5); ax.set_ylim(0, 100); ax.set_ylabel('% do PIB, dezembro'); ax.set_xticks(range(2001, 2026, 2))
fig.tight_layout(); fig.savefig(f'{G}/6-divida.svg'); plt.close(fig)

# 7. Fatores da variacao da divida liquida por ano (positivo aumenta a divida)
FT = {}
for r in le('I-divida-fatores.csv'): FT.setdefault(r['fator'], {})[int(r['ano'])] = float(r['pct_pib'])
anosf = [a for a in range(2006, 2026) if all(a in FT[k] for k in ('primario', 'juros', 'cambio', 'pib'))]
fig, ax = plt.subplots(figsize=(LARG, 3.8))
faixas(ax, ini=2006)
cores = {'juros': AZUL, 'primario': '#c9a227', 'cambio': '#9a9a9a', 'pib': '#5f8f6a'}
nomes_f = {'juros': 'juros', 'primario': 'déficit primário (negativo = superávit)', 'cambio': 'câmbio', 'pib': 'crescimento do PIB'}
pos = {a: 0 for a in anosf}; neg = {a: 0 for a in anosf}
for k in ('juros', 'primario', 'cambio', 'pib'):
  vs = [FT[k][a] for a in anosf]
  base = [pos[a] if v >= 0 else neg[a] for a, v in zip(anosf, vs)]
  ax.bar(anosf, vs, bottom=base, color=cores[k], width=0.72, label=nomes_f[k], zorder=2)
  for a, v in zip(anosf, vs):
    if v >= 0: pos[a] += v
    else: neg[a] += v
if 'variacao' in FT:
  xa = [a for a in anosf if a in FT['variacao']]
  ax.plot(xa, [FT['variacao'][a] for a in xa], 'o', color=ESCURO, ms=3.5, zorder=3, label='variação da dívida líquida')
ax.axhline(0, color=ESCURO, lw=0.6); ax.set_ylabel('pontos do PIB por ano'); ax.set_xticks(range(2006, 2026, 2))
ax.legend(fontsize=7, frameon=False, ncol=3, loc='lower left', bbox_to_anchor=(0, -0.32))
fig.tight_layout(); fig.savefig(f'{G}/7-fatores.svg'); plt.close(fig)
print('graficos divida ok')

# 6b. Divida bruta em R$ bi de dez/2025 (IPCA) e correntes, com presidentes (brutos/I/build_dbgg_anual.py)
DA = le('I-divida-bruta-anual.csv')
xa = [int(r['periodo'][:4]) for r in DA]
fig, ax = plt.subplots(figsize=(LARG, 3.6))
faixas(ax, ini=2005)
ax.bar(xa, [float(r['dbgg_rs_bi_dez2025_ipca']) for r in DA], color=[AZUL if r['periodo'].isdigit() else '#8fa7c4' for r in DA], width=0.7, zorder=2,
       label='R$ bi de dez/2025 (IPCA)')
ax.plot(xa, [float(r['dbgg_rs_bi_correntes']) for r in DA], 'o-', color=ESCURO, ms=2.5, lw=1.1, zorder=3, label='R$ bi correntes')
for r, x in zip(DA, xa):
  if r['periodo'] in ('2006', '2010', '2015', '2018', '2022') or not r['periodo'].isdigit():
    ax.text(x, max(float(r['dbgg_rs_bi_dez2025_ipca']), float(r['dbgg_rs_bi_correntes'])) + 250, br(float(r['dbgg_rs_bi_dez2025_ipca']) / 1000, 1) + ' tri', ha='center', fontsize=6.5, color=AZUL)
ax.text(xa[-1], -900, DA[-1]['rotulo'], ha='center', fontsize=6.5, color=CINZA)
ax.set_xlim(2005.4, 2026.6); ax.set_ylim(0, 13000); ax.set_xticks(range(2006, 2026, 2))
ax.set_ylabel('R$ bilhões'); ax.yaxis.set_major_formatter(lambda x, _: br(x)); ax.legend(fontsize=7, frameon=False, loc='upper left')
fig.tight_layout(); fig.savefig(f'{G}/6b-divida-reais.svg'); plt.close(fig)

# 6c. Variacao real da divida bruta por mandato, media por ano em R$ bi de 2025, por fator (brutos/J/build_dbgg_real.py)
DR = [r for r in le('J-dbgg-fatores-reais.csv') if not r['periodo'].isdigit()]
fr = lambda r, c: float(r[c + '_rs_bi_2025_por_ano'])
fig, ax = plt.subplots(figsize=(LARG, 3.6))
xs = range(len(DR))
PARTES = [('juro_real', 'juro real', AZUL), ('emissoes_liquidas', 'emissões líquidas', '#c9a227'), ('cambio', 'câmbio', CINZA), ('outros', 'outros ajustes', '#5b8a5b')]
pos = [0.0] * len(DR); neg = [0.0] * len(DR)
for c, rot, cor in PARTES:
  v = [fr(r, c) for r in DR]
  base = [pos[i] if x >= 0 else neg[i] for i, x in enumerate(v)]
  ax.bar(xs, v, bottom=base, color=cor, width=0.6, label=rot, zorder=2)
  for i, x in enumerate(v):
    if x >= 0: pos[i] += x
    else: neg[i] += x
ax.plot(xs, [fr(r, 'variacao_real') for r in DR], 'o', color=ESCURO, ms=5, zorder=3, label='variação real do estoque')
for i, r in enumerate(DR): ax.text(i, max(pos[i], fr(r, 'variacao_real')) + 18, br(fr(r, 'variacao_real'), 0), ha='center', fontsize=7.5, color=ESCURO)
ax.axhline(0, color=ESCURO, lw=0.6)
ax.set_xticks(list(xs), [r['periodo'].replace(' (', '\n(').replace('2016\n(Dilma/Temer)', '2016\n(Dilma/Temer)') for r in DR], fontsize=7.5)
ax.set_ylabel('R$ bi de 2025 por ano'); ax.yaxis.set_major_formatter(lambda x, _: br(x)); ax.grid(axis='x', visible=False)
ax.legend(fontsize=7, frameon=False, loc='upper left', ncol=3)
ax.set_ylim(min(neg) - 60, max(pos) + 150)
fig.tight_layout(); fig.savefig(f'{G}/6c-divida-fatores-reais.svg'); plt.close(fig)

# 8b. Renuncias e subsidios da Uniao em 2024, Orcamento de Subsidios da Uniao (E-renuncias-e-subsidios.csv)
ER = [r for r in le('E-renuncias-e-subsidios.csv') if r['ano'] == '2024' and r['estagio'].startswith('realizado (OSU)')]
er_t = sorted([r for r in ER if r['categoria'].startswith('Subsidio tributario')], key=lambda r: float(r['valor_brl']))
er_f = [r for r in ER if r['categoria'].startswith(('Subsidio financeiro', 'Subsidio crediticio'))]
fig, ax = plt.subplots(figsize=(LARG, 4.0))
ax.barh(range(len(er_t)), [float(r['valor_brl']) / 1e9 for r in er_t], color=CINZA, height=0.65)
ax.set_yticks(range(len(er_t)), [r['subcategoria'].replace(' - IRPF', ', IRPF').replace('Poupança e Títulos de Crédito - Setor Imobiliário e do Agronegócio', 'Poupança e títulos imobiliários e do agro').replace('SIMPLES Nacional', 'Simples Nacional').replace('PERSE - Programa Emergencial de Retomada do Setor de Eventos', 'Perse (setor de eventos)').replace('Medicamentos, Produtos Farmacêuticos e Equipamentos Médicos', 'Medicamentos e equipamentos médicos').replace('Entidades Sem Fins Lucrativos - Imunes / Isentas', 'Entidades sem fins lucrativos').replace('Zona Franca de Manaus e Áreas de Livre Comércio', 'Zona Franca de Manaus e livre comércio') for r in er_t], fontsize=8)
for i, r in enumerate(er_t): ax.text(float(r['valor_brl']) / 1e9 + 1, i, br(float(r['valor_brl']) / 1e9, 1), va='center', fontsize=7.5)
ax.grid(axis='y', visible=False); ax.tick_params(axis='y', length=0); ax.set_xlabel('subsídios tributários (renúncias), R$ bi, 2024 (Lula 3)')
fig.tight_layout(); fig.savefig(f'{G}/8b-renuncias.svg'); plt.close(fig)

# 10b. Custo medio da DPF por indexador, contribuicao em pp, com IPCA e custo total (brutos/O/build_O.py)
OI = {}
for r in le('O-custo-divida-indexador.csv'): OI.setdefault(r['indexador'], {})[int(r['ano'])] = r
OD = {int(r['ano']): r for r in le('O-custo-divida-decomposicao.csv')}
xo_ = sorted(OD)
fig, ax = plt.subplots(figsize=(LARG, 3.8))
faixas(ax, ini=2008, fs=8)
IDX = [('prefixado', 'prefixado', '#8a8a8a'), ('selic_flutuante', 'Selic', AZUL), ('indice_precos', 'índice de preços', '#5b8a5b'), ('cambio', 'câmbio', '#c9a227')]
pos = {a: 0.0 for a in xo_}; neg = {a: 0.0 for a in xo_}
for k, rot, cor in IDX:
  v = [float(OI[k][a]['contribuicao_pp']) for a in xo_]
  ax.bar(xo_, v, bottom=[pos[a] if x >= 0 else neg[a] for a, x in zip(xo_, v)], color=cor, width=0.7, label=rot, zorder=2)
  for a, x in zip(xo_, v):
    if x >= 0: pos[a] += x
    else: neg[a] += x
ax.plot(xo_, [float(OD[a]['custo_medio_total_pct']) for a in xo_], 'o-', color=ESCURO, ms=2.5, lw=1.2, zorder=3, label='custo médio total')
ax.plot(xo_, [float(OD[a]['ipca_pct']) for a in xo_], '--', color=ESCURO, lw=1.2, zorder=3, label='IPCA do ano')
ax.axhline(0, color=ESCURO, lw=0.6); ax.set_ylabel('% ao ano, barras em pontos'); ax.set_xlim(2007.4, 2025.6); ax.set_ylim(-2, 18)
ax.set_xticks(range(2008, 2026, 2))
ax.legend(fontsize=7, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.09), ncol=6)
fig.tight_layout(); fig.savefig(f'{G}/10b-custo-indexador.svg'); plt.close(fig)

# 12. Distribuicao: Gini e pobreza com e sem programas (IBGE SIS), IRPF por faixa (RFB) (brutos/P/build_P.py)
PD = {}
for f in ('P-desigualdade-pobreza', 'P-irpf-faixas', 'P-previdencia-regimes', 'P-carga-por-base'):
  for r in le(f + '.csv'):
    if r['valor'] not in ('', None): PD[(r['serie'], r['recorte'], r['ano'])] = r
pv = lambda se, rc, a: float(PD[(se, rc, str(a))]['valor'])
xg = [a for a in range(2012, 2025) if ('gini_rdpc', 'Brasil', str(a)) in PD]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(LARG, 3.0))
for ax in (a1, a2): faixas(ax, ini=2012, fs=6, sigla=True)
a1.plot(xg, [pv('gini_rdpc_sem_programas_sociais', 'Brasil', a) for a in xg], '--', color=CINZA, lw=1.4, label='sem programas sociais')
a1.plot(xg, [pv('gini_rdpc', 'Brasil', a) for a in xg], 'o-', color=AZUL, ms=2.5, lw=1.6, label='observado')
a1.set_title('Gini do rendimento domiciliar per capita', fontsize=8.5, loc='left', pad=11); a1.set_ylim(0.48, 0.60); a1.legend(fontsize=6.5, frameon=False, loc='lower left')
a2.plot(xg, [pv('pobreza_us2_15_ppc2017_sem_programas_sociais', 'Brasil', a) for a in xg], '--', color=CINZA, lw=1.4, label='sem programas sociais')
a2.plot(xg, [pv('pobreza_us2_15_ppc2017', 'Brasil', a) for a in xg], 'o-', color=AZUL, ms=2.5, lw=1.6, label='observado')
a2.set_title('Pessoas abaixo de US$ 2,15 por dia, %', fontsize=8.5, loc='left', pad=11); a2.set_ylim(0, 15)
for ax in (a1, a2): ax.set_xlim(2011.5, 2024.5); ax.set_xticks([2012, 2016, 2020, 2024]); ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(f'{G}/12a-desigualdade.svg'); plt.close(fig)
# 12. Poder de compra e renda por faixa (brutos/PC/build_PC.py)
PCR = json.load(open(os.path.join(RAIZ, 'PC-referencias.json'), encoding='utf-8'))
PSM = le('PC-salario-minimo.csv'); PCS = le('PC-cesta-sp.csv'); PRT = le('PC-renda-trabalho.csv'); PRD = le('PC-renda-domiciliar-faixas.csv')
PMD = {(r['presidente'], r['indicador']): float(r['valor']) for r in le('PC-por-mandato.csv')}
PMP = {(r['presidente'], r['indicador']): r['periodo'] for r in le('PC-por-mandato.csv')}
PRDv = {(int(r['ano']), r['classe']): float(r['rendimento_domiciliar_per_capita_real_rs']) for r in PRD}
C40 = '40% mais pobres (media das classes ate o P40)'
fig, ((b1, b2), (b3, b4)) = plt.subplots(2, 2, figsize=(LARG, 5.4))
for ax, ini in ((b1, 1995), (b2, 1995)):
  faixas(ax, ini=1997, fs=6.5, sigla=True); ax.axvspan(1994.5, 1996.5, color='#ececec', lw=0, zorder=0)  # FHC desde 1995, rotulo ja vem das faixas
xs_ = [int(r['ano']) for r in PSM]
b1.plot(xs_, [float(r['salario_minimo_real_medio_rs']) for r in PSM], 'o-', color=AZUL, ms=2, lw=1.5)
b1.set_title(f'Salário mínimo real, média do ano, R$ de {PCR["ult_preco"]}', fontsize=8, loc='left', pad=11); b1.set_ylim(0, 1800)
b2.plot(xs_, [float(r['horas_de_trabalho_media']) for r in PCS], 'o-', color=ESCURO, ms=2, lw=1.5)
b2.set_title('Cesta de São Paulo, horas de salário mínimo', fontsize=8, loc='left', pad=11); b2.set_ylim(0, 240)
for ax in (b1, b2): ax.set_xlim(1994.5, 2026.5); ax.set_xticks([1995, 2002, 2010, 2016, 2022, 2026]); ax.tick_params(labelsize=7)
# renda do trabalho por trimestre movel: eixo em anos fracionarios
xt = [int(r['mes_final'][:4]) + (int(r['mes_final'][5:]) - 1.5) / 12 for r in PRT]
for ax in (b3, b4): faixas(ax, ini=2012, fs=6.5, sigla=True)
b3.plot(xt, [float(r['rendimento_medio_real_rs']) for r in PRT], '-', color=AZUL, lw=1.5)
b3.set_title(f'Renda média real do trabalho, R$ de {PCR["ult_trab"]}', fontsize=8, loc='left', pad=11); b3.set_ylim(0, 4000); b3.set_xlim(2011.5, 2026.9)
xd = sorted({int(r['ano']) for r in PRD})
for c, rot, cor, est in ((C40, '40% mais pobres', AZUL, 'o-'), ('Total', 'média', ESCURO, 's-'), ('Maior que o P90', '10% mais ricos', CINZA, '^--')):
  b4.plot(xd, [100 * PRDv[(a, c)] / PRDv[(2012, c)] for a in xd], est, color=cor, ms=2.2, lw=1.4, label=rot)
b4.set_title('Renda domiciliar por pessoa, real, 2012 = 100', fontsize=8, loc='left', pad=11); b4.set_ylim(80, 150); b4.set_xlim(2011.5, 2025.5)
b4.legend(fontsize=6.5, frameon=False, loc='upper left')
for ax in (b3, b4): ax.set_xticks([2012, 2016, 2020, 2024]); ax.tick_params(labelsize=7)
fig.tight_layout(h_pad=2.2); fig.savefig(f'{G}/12e-poder-de-compra.svg'); plt.close(fig)
# inflacao por faixa de renda, media ao ano por mandato (Ipea)
MI = [('Lula 1 e 2', 'Lula 2'), ('Dilma', 'Dilma'), ('Temer', 'Temer'), ('Bolsonaro', 'Bolsonaro'), ('Lula 3', 'Lula 3')]
fig, ax = plt.subplots(figsize=(LARG, 2.7))
xi = range(len(MI))
mb = [PMD[(k, 'inflacao Ipea, renda muito baixa, media ao ano')] for k, _ in MI]; al = [PMD[(k, 'inflacao Ipea, renda alta, media ao ano')] for k, _ in MI]
ax.bar([x - 0.19 for x in xi], mb, width=0.36, color=AZUL, label=f'renda muito baixa (domicílio com menos de R$ {PCR["lim_renda_muito_baixa"]} por mês)')
ax.bar([x + 0.19 for x in xi], al, width=0.36, color=CINZA, label=f'renda alta (mais de R$ {PCR["lim_renda_alta"]})')
for x, a_, b_ in zip(xi, mb, al):
  ax.text(x - 0.19, a_ + 0.12, br(a_, 1), ha='center', fontsize=7, color=ESCURO); ax.text(x + 0.19, b_ + 0.12, br(b_, 1), ha='center', fontsize=7, color=ESCURO)
ax.set_xticks(list(xi), [r for _, r in MI]); ax.set_ylabel('% ao ano'); ax.set_ylim(0, 9.5); ax.tick_params(axis='x', length=0)
ax.legend(fontsize=6.8, frameon=False, loc='upper left', ncol=2)
fig.tight_layout(); fig.savefig(f'{G}/12f-inflacao-por-faixa.svg'); plt.close(fig)
# Cultura na Uniao, 2015 a 2025 (brutos/CU/build_CU.py)
JUR_PAIS = float(next(r['valor_rs_bi'] for r in le('RAZAO-per-capita.csv') if r['tabela'] == 'pais-2024' and r['bloco'].startswith('Juros')))
CUS = le('CU-cultura-uniao.csv'); CUR = {r['serie']: r for r in le('CU-cultura-resumo.csv')}
cu = lambda a, k: float(next(r[k] for r in CUS if r['ano'] == str(a)))
cur = lambda s: float(CUR[s]['valor_rs_bi'])
fig, ax = plt.subplots(figsize=(LARG, 2.6))
faixas(ax, ini=2015, fs=7)
xa = [int(r['ano']) for r in CUS]; ya = [float(r['liquidado_rs_bi_2025']) for r in CUS]
ax.bar(xa, ya, width=0.62, color=CINZA, zorder=2)
for x, y in zip(xa, ya): ax.text(x, y + 0.05, br(y, 1), ha='center', fontsize=7, color=ESCURO)
ax.set_xlim(2014.4, 2025.6); ax.set_xticks(xa); ax.set_ylim(0, 3.0); ax.set_ylabel('R$ bi de 2025'); ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(f'{G}/7c-cultura.svg'); plt.close(fig)
# Agro, meio ambiente e cultura por governo, 2000 a 2025 (brutos/FL/build_FL.py e brutos/FN/build_FN.py)
FLD = le('FL-desmatamento.csv'); FLM = {r['presidente']: r for r in le('FL-desmatamento-por-mandato.csv')}
FNF = le('FN-funcoes-uniao.csv'); FNM = {r['presidente']: r for r in le('FN-por-mandato.csv')}
fl = lambda a, c: float(next(r[c] for r in FLD if r['ano_prodes'] == str(a)))
flm = lambda m, c: float(FLM[m][c])
fnf = lambda a, ln, c='despesa_rs_bi_2025': float(next(r[c] for r in FNF if r['ano'] == str(a) and r['linha'] == ln))
fnm = lambda m, c: float(FNM[m][c])
fig, ax = plt.subplots(figsize=(LARG, 2.8))
faixas(ax, ini=2000, fs=7)
xa = [int(r['ano_prodes']) for r in FLD]
ax.bar([x - 0.2 for x in xa], [fl(x, 'amazonia_legal_km2') / 1000 for x in xa], width=0.4, color=AZUL, zorder=2, label='Amazônia Legal')
xc = [x for x in xa if next(r['cerrado_km2'] for r in FLD if r['ano_prodes'] == str(x))]
ax.bar([x + 0.2 for x in xc], [fl(x, 'cerrado_km2') / 1000 for x in xc], width=0.4, color=CINZA, zorder=2, label='Cerrado')
ax.set_xlim(1999.4, xa[-1] + 0.6); ax.set_ylabel('mil km² por ano'); ax.tick_params(labelsize=7)
ax.legend(fontsize=7, frameon=False, loc='upper right')
fig.tight_layout(); fig.savefig(f'{G}/3b-desmatamento.svg'); plt.close(fig)
fig, axs = plt.subplots(1, 3, figsize=(LARG, 2.4))
xfn = list(range(2000, 2026))
for ax, (ln, tit, inv) in zip(axs, [('Agricultura', 'Agricultura, sem inversões', False), ('Organização Agrária', 'Organização Agrária, com inversões', True), ('Gestão Ambiental, sem recursos hídricos', 'Gestão Ambiental, sem recursos hídricos', False)]):
  faixas(ax, ini=2000, fs=6.5, sigla=True)
  ys = [fnf(a, ln) + (fnf(a, ln, 'inversoes_financeiras_rs_bi_2025') if inv else 0) for a in xfn]
  ax.bar(xfn, ys, width=0.7, color=CINZA, zorder=2)
  ax.set_title(tit, fontsize=7, loc='left', pad=12); ax.set_xlim(1999.4, 2025.6); ax.set_ylim(0, max(ys) * 1.12)
  ax.set_xticks([2000, 2010, 2020]); ax.tick_params(labelsize=6.5)
axs[0].set_ylabel('R$ bi de 2025')
fig.tight_layout(); fig.savefig(f'{G}/3c-funcoes-agro-ambiente.svg'); plt.close(fig)
# Cultura por governo (frentes FN e CV): despesa direta, FSA, transferencias por lei e captacao da Rouanet
FNSC = le('FN-subsidios-agro-cultura.csv')
defl25 = lambda a: fnf(a, 'Agricultura') / float(next(r['despesa_rs_bi'] for r in FNF if r['ano'] == str(a) and r['linha'] == 'Agricultura'))  # deflator do ano para R$ de 2025
CVT = le('CV-transferencias-cultura.csv')
cvt = lambda a, c='liquidado_rs_bi': sum(float(r[c]) for r in CVT if r['ano'] == str(a))
CVS = {int(r['ano']): r for r in le('CV-salic-por-ano.csv')}; cvs = lambda a, c: float(CVS[a][c]) if CVS[a][c] != '' else None
CVE = {int(r['ano']): r for r in le('CV-estrutura-cultura.csv')}
CVA = {int(r['ano']): r for r in le('CV-atencao.csv')}
CVM = le('CV-ministerios.csv')
fig, ax = plt.subplots(figsize=(LARG, 2.7))
faixas(ax, ini=2000, fs=7)
c1 = [fnf(a, 'Cultura') for a in xfn]; c2 = [fnf(a, 'Cultura', 'inversoes_financeiras_rs_bi_2025') for a in xfn]; c3 = [cvt(a) * defl25(a) for a in xfn]
ax.bar(xfn, c1, width=0.7, color=CINZA, zorder=2, label='função Cultura, sem o FSA')
ax.bar(xfn, c2, width=0.7, bottom=c1, color='#c9c9c9', zorder=2, label='Fundo Setorial do Audiovisual')
ax.bar(xfn, c3, width=0.7, bottom=[x + y for x, y in zip(c1, c2)], color=AZUL, zorder=2, label='transferências por lei (liquidado no ano)')
ax.plot(xfn, [float(next(r['rs_bi_2025'] for r in FNSC if r['ano'] == str(a) and r['serie'] == 'rouanet_captado')) for a in xfn], color=ESCURO, lw=1.4, marker='o', ms=2.3, zorder=3, label='Lei Rouanet, captado')
ax.set_xlim(1999.4, 2025.6); ax.set_ylim(0, 7.6); ax.set_ylabel('R$ bi de 2025'); ax.tick_params(labelsize=7)
ax.legend(fontsize=6.6, frameon=False, loc='upper left', ncol=2, bbox_to_anchor=(0, 0.97))
fig.tight_layout(); fig.savefig(f'{G}/3d-cultura-despesa-e-rouanet.svg'); plt.close(fig)
fig, axs = plt.subplots(1, 2, figsize=(LARG, 2.6))
xs = list(range(2009, 2026))
for ax in axs: faixas(ax, ini=2009, fs=6.5, sigla=True)
axs[0].bar(xs, [cvs(a, 'projetos_novos') / 1000 for a in xs], width=0.7, color=CINZA, zorder=2, label='projetos novos')
axs[0].plot([a for a in xs if cvs(a, 'cnic_projetos_avaliados')], [cvs(a, 'cnic_projetos_avaliados') / 1000 for a in xs if cvs(a, 'cnic_projetos_avaliados')], color=AZUL, lw=1.5, marker='o', ms=2.3, zorder=3, label='avaliados pela CNIC')
axs[0].set_title('Lei Rouanet, mil projetos por ano', fontsize=7, loc='left', pad=12); axs[0].legend(fontsize=6.5, frameon=False, loc='upper left')
for k, rot, cor, ls in [('negra_quilombola', 'negro, negra, afro, quilombola', AZUL, '-'), ('indigena', 'indígena', '#5b8a5b', '-'), ('lgbt', 'LGBT, queer, drag', '#c9a227', '-'), ('gospel_controle', 'gospel (controle)', CINZA, '-'), ('orquestra_controle', 'orquestra (controle)', CINZA, '--')]:
  axs[1].plot(xs, [cvs(a, 'pct_' + k) for a in xs], color=cor, lw=1.5, ls=ls, marker='o', ms=2.3, zorder=3, label=rot)
axs[1].set_title('% dos projetos novos com o tema no nome', fontsize=7, loc='left', pad=12); axs[1].legend(fontsize=6.5, frameon=False, loc='upper left')
for ax in axs: ax.set_xlim(2008.4, 2025.6); ax.set_xticks([2010, 2015, 2020, 2025]); ax.tick_params(labelsize=6.5)
axs[0].set_ylim(0, 17); axs[1].set_ylim(0, 2.9)
fig.tight_layout(); fig.savefig(f'{G}/3e-rouanet-fluxo-e-temas.svg'); plt.close(fig)
fig, ax = plt.subplots(figsize=(LARG, 2.5))
xt = list(range(2004, 2026)); faixas(ax, ini=2003, fs=7)
for c, rot, cor, ls in [('trends_lei_rouanet', 'Lei Rouanet', AZUL, '-'), ('trends_zona_franca_de_manaus', 'Zona Franca de Manaus', CINZA, '-'), ('trends_plano_safra', 'Plano Safra', '#5b8a5b', '-'), ('trends_fundo_partidário', 'Fundo Partidário', '#c9a227', '-'), ('trends_fundo_eleitoral', 'Fundo Eleitoral', '#c9a227', '--')]:
  ax.plot(xt, [float(CVA[a][c]) for a in xt], color=cor, lw=1.5, ls=ls, marker='o', ms=2.3, zorder=3, label=rot)
ax.set_xlim(2003.4, 2025.6); ax.set_xticks([2005, 2010, 2015, 2020, 2025]); ax.set_ylim(0, 26); ax.set_ylabel('índice do Google Trends, média do ano'); ax.tick_params(labelsize=7)
ax.legend(fontsize=6.8, frameon=False, loc='upper left', ncol=2)
fig.tight_layout(); fig.savefig(f'{G}/3f-atencao-busca.svg'); plt.close(fig)
FX = ['ate 1/2', '1/2 a 1', '1 a 2', '2 a 3', '3 a 5', '5 a 10', '10 a 20', '20 a 40', '40 a 80', '80 a 160', 'mais de 160']
fig, ax = plt.subplots(figsize=(LARG, 3.0))
ax.bar(range(len(FX)), [pv('aliquota_efetiva_sobre_rendimento_total', 'harmonizada: ' + f, 2024) for f in FX], color=AZUL, width=0.65, label='alíquota efetiva, % do rendimento total')
ax2 = ax.twinx()
ax2.plot(range(len(FX)), [pv('pct_isento_no_rendimento_total', 'harmonizada: ' + f, 2024) for f in FX], 'o-', color='#c9a227', ms=3, lw=1.3, label='parte isenta do rendimento, %')
ax2.set_ylim(0, 100); ax2.spines['right'].set_visible(True); ax2.grid(False); ax2.tick_params(labelsize=7)
for i, f in enumerate(FX): ax.text(i, pv('aliquota_efetiva_sobre_rendimento_total', 'harmonizada: ' + f, 2024) + 0.25, br(pv('aliquota_efetiva_sobre_rendimento_total', 'harmonizada: ' + f, 2024), 1), ha='center', fontsize=6.5)
ax.set_xticks(range(len(FX)), [f.replace('ate', 'até') for f in FX], fontsize=7); ax.set_xlabel('rendimento total mensal, em salários mínimos (declarações de 2024, Lula 3)', fontsize=7.5)
ax.set_ylim(0, 12); ax.set_ylabel('% do rendimento total', fontsize=7.5); ax.grid(axis='x', visible=False)
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels(); ax.legend(h1 + h2, l1 + l2, fontsize=7, frameon=False, loc='upper left')
fig.tight_layout(); fig.savefig(f'{G}/12b-irpf.svg'); plt.close(fig)
# 12c. Incidencia total por decimo de renda, POF 2017-18 (brutos/T/build_T.py)
TT = le('T-incidencia-tributaria.csv')
tv = lambda se, fx, an=None: float(next(r['valor'] for r in TT if r['serie'] == se and r['faixa'] == fx and (an is None or r['ano'] == an)))
dec = [f'decimo {k}' for k in range(1, 11)]
fig, ax = plt.subplots(figsize=(LARG, 3.0))
di = [tv('pof_tributos_diretos_pct_renda_total', d) for d in dec]; ind = [tv('pof_tributos_indiretos_pct_renda_total', d) for d in dec]
ax.bar(range(1, 11), ind, color=CINZA, width=0.65, label='indiretos (consumo)')
ax.bar(range(1, 11), di, bottom=ind, color=AZUL, width=0.65, label='diretos (IRPF, contribuição do trabalhador, IPTU, IPVA)')
for k in range(10): ax.text(k + 1, ind[k] + di[k] + 0.5, br(ind[k] + di[k], 1), ha='center', fontsize=6.5)
ax.set_xticks(range(1, 11)); ax.set_xticklabels([f'{k}º' for k in range(1, 11)], fontsize=7); ax.set_xlabel('décimo de renda familiar per capita, do mais pobre ao mais rico', fontsize=7)
ax.set_ylabel('% da renda total'); ax.set_ylim(0, 30); ax.tick_params(labelsize=7); ax.legend(fontsize=6.5, frameon=False, loc='upper right')
ax.set_title('Tributos pagos pelas famílias, POF 2017-2018 (Temer)', fontsize=8.5, loc='left')
fig.tight_layout(); fig.savefig(f'{G}/12c-incidencia.svg'); plt.close(fig)
VV = le('V-reforma-consumo.csv')
KPREC = next({'valor_rs_bi': float(r['valor_rs_bi']), 'pct_pib': float(r['pct_pib']), 'url': r['fonte_url']} for r in le('K-eventos-nao-recorrentes.csv') if r['ano'] == '2023' and r['evento'].startswith('Precatórios: pagamento do estoque'))
SC = le('S-cenarios-divida.csv')
nota_s = dict(x.split('=') for x in SC[0]['nota'].split('; ') if '=' in x)
vv = lambda it, an: float(next(r['valor'] for r in VV if it in r['item'] and r['ano'] == an and r['valor']))
# 12d. Resultado da previdencia por regime (brutos/U/build_U.py)
UR = le('U-previdencia-resultado.csv'); UA = le('U-previdencia-atuarial.csv')
uv = lambda rg, se, a: float(next(r['valor'] for r in UR if r['regime'] == rg and r['serie'] == se and r['ano'] == str(a)))
ua = lambda rg, se: float(next(r['valor'] for r in UA if r['regime'] == rg and r['serie'] == se))
fig, ax = plt.subplots(figsize=(LARG, 3.2)); faixas(ax, ini=2008, fs=6.5)
for rg, cor, nome in (('RGPS rural', CINZA, 'INSS rural'), ('RGPS urbano', ESCURO, 'INSS urbano'), ('RPPS civil Uniao', AZUL, 'servidores civis da União'), ('militares (SPSMFA)', '#5b8a5b', 'militares')):
  pts = sorted((int(r['ano']), float(r['valor'])) for r in UR if r['regime'] == rg and r['serie'] == 'resultado_pct_pib')
  ax.plot([x for x, _ in pts], [y for _, y in pts], 'o-', ms=2.3, lw=1.4, color=cor, label=nome)
ax.axhline(0, color=CINZA, lw=0.6); ax.set_ylabel('resultado, % do PIB'); ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: br(v, 1))); ax.set_xlim(2007.5, 2025.5); ax.tick_params(labelsize=7)
ax.legend(fontsize=6.5, frameon=False, loc='lower left', ncol=2)
fig.tight_layout(); fig.savefig(f'{G}/12d-previdencia-resultado.svg'); plt.close(fig)

# 13. Resultados: educacao e saude (brutos/Q/build_Q.py)
QQ = {}
for f in ('Q-educacao', 'Q-saude', 'Q-internacional'):
  for r in le(f + '.csv'):
    if r['valor'] not in ('', None): QQ[(f[2:], r['indicador'], r['recorte'], int(r['ano']))] = float(r['valor'])
qs = lambda f, ind, rc: sorted((a, v) for (f_, i_, r_, a), v in QQ.items() if f_ == f and i_ == ind and r_ == rc)
fig, axs = plt.subplots(2, 2, figsize=(LARG, 5.0))
def proj(a, d, ini=2023):  # IBGE: 2023 em diante e projecao da revisao 2024, tracejada
  ob = [(x, y) for x, y in d if x < ini]; pj = [(x, y) for x, y in d if x >= ini - 1]
  a.plot([x for x, _ in ob], [y for _, y in ob], 'o-', ms=2.5, color=AZUL, lw=1.4, label='estimativa')
  a.plot([x for x, _ in pj], [y for _, y in pj], 'o--', ms=2.5, color=AZUL, lw=1.1, mfc='white', label='projeção')
  a.legend(fontsize=6.5, frameon=False, loc='lower left')
for ax in axs.flat: faixas(ax, ini=2008, fs=6, sigla=True)
a = axs[0][0]
for ind, cor, rot in (('IDEB - Anos iniciais EF (5o ano)', AZUL, 'anos iniciais'), ('IDEB - Anos finais EF (9o ano)', ESCURO, 'anos finais'), ('IDEB - Ensino medio (3a serie)', CINZA, 'ensino médio')):
  d = qs('educacao', ind, 'Brasil, rede Pública'); a.plot([x for x, _ in d], [y for _, y in d], 'o-', ms=2.5, color=cor, lw=1.4, label=rot)
a.set_title('Ideb, rede pública', fontsize=8.5, loc='left', pad=11); a.set_ylim(0, 7); a.legend(fontsize=6.5, frameon=False, loc='lower right')
a = axs[0][1]
for rc, cor, rot in (('Brasil', AZUL, 'Brasil'), ('Media OCDE-35 (mesmos 35 paises nos ciclos)', CINZA, 'OCDE, mesmos 35 países')):
  d = qs('internacional', 'PISA matematica', rc); a.plot([x for x, _ in d], [y for _, y in d], 'o-', ms=2.5, color=cor, lw=1.4, label=rot)
a.set_title('PISA, matemática', fontsize=8.5, loc='left', pad=11); a.set_ylim(300, 520); a.legend(fontsize=6.5, frameon=False, loc='lower right')
a = axs[1][0]
d = qs('saude', 'Taxa de mortalidade infantil (IBGE, estimada)', 'Brasil'); proj(a, d)
a.set_title('Mortalidade infantil, por mil nascidos vivos', fontsize=8.5, loc='left', pad=11); a.set_ylim(0, 20)
a = axs[1][1]
d = qs('saude', 'Esperanca de vida ao nascer', 'Brasil'); proj(a, d)
a.set_title('Esperança de vida ao nascer, anos', fontsize=8.5, loc='left', pad=11); a.set_ylim(70, 80)
for ax in axs.flat: ax.set_xlim(2007.5, 2025.8); ax.set_xticks([2010, 2015, 2020, 2025]); ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(f'{G}/13-resultados.svg'); plt.close(fig)

# ---------- v6: receita e carga (frente L), primario recorrente (K), emergentes (M), juro real e eventos (N)
LS = {}
for r in le('L-receita-carga.csv'):
  if r['valor']: LS.setdefault(r['serie'], {})[int(r['ano'])] = (float(r['valor']), r['nota'])
lv = lambda s: {a: v for a, (v, _) in LS[s].items()}
fig, (a1, a2, a3) = plt.subplots(3, 1, figsize=(LARG, 6.6), sharex=True, gridspec_kw={'height_ratios': [3, 2, 2]})
for ax in (a1, a2, a3): faixas(ax, rotulo=ax is a1, fs=8)
for s, cor, nome in (('carga_tributaria_bruta_receita', ESCURO, 'carga tributária bruta, Receita Federal'),
                     ('carga_tributaria_bruta_tesouro', AZUL, 'carga tributária bruta, Tesouro'),
                     ('receita_liquida_gc', CINZA, 'receita líquida do Governo Central')):
  d = lv(s); xs = sorted(d)
  a1.plot(xs, [d[a] for a in xs], color=cor, lw=1.7, label=nome)
a1.set_ylim(10, 36); a1.set_ylabel('% do PIB'); a1.legend(fontsize=7, frameon=False, loc='lower right')
gt = LS['gasto_tributario_pct_pib']; xe = sorted(a for a in gt if 'proje' not in gt[a][1].lower()); xp = sorted(a for a in gt if 'proje' in gt[a][1].lower())
a2.plot(xe, [gt[a][0] for a in xe], color=ESCURO, lw=1.7)
if xp: a2.plot([xe[-1]] + xp, [gt[xe[-1]][0]] + [gt[a][0] for a in xp], color=ESCURO, lw=1.2, ls='--')
a2.set_ylim(0, 6); a2.set_ylabel('gasto tributário\n% do PIB')
po = lv('pct_obrigatoria'); xo = sorted(po)
a3.plot(xo, [po[a] for a in xo], color=AZUL, lw=1.7); a3.set_ylim(80, 100); a3.set_ylabel('obrigatória\n% da despesa')
a3.set_xlim(1996.5, 2026.5)
fig.tight_layout(); fig.savefig(f'{G}/8-receita-carga.svg'); plt.close(fig)

KR = {int(r['ano']): r for r in le('K-primario-recorrente.csv')}
xk = sorted(KR)
fig, ax = plt.subplots(figsize=(LARG, 3.4))
faixas(ax, fs=8)
ax.bar(xk, [float(KR[a]['primario_cheio_pct_pib']) for a in xk], color='#c9c9c9', width=0.72, label='primário cheio', zorder=2)
ax.plot(xk, [float(KR[a]['primario_recorrente_pct_pib']) for a in xk], 'o-', color=AZUL, ms=3, lw=1.3, label='primário recorrente (sem eventos não recorrentes)', zorder=3)
ax.axhline(0, color=ESCURO, lw=0.6); ax.set_ylabel('% do PIB'); ax.set_ylim(-10.5, 3.5)
ax.legend(fontsize=7, frameon=False, loc='lower left')
fig.tight_layout(); fig.savefig(f'{G}/9-primario-recorrente.svg'); plt.close(fig)

MR = le('M-resumo-2025.csv')
NOME_M = {'Mexico': 'México', 'Colombia': 'Colômbia', 'Africa do Sul': 'África do Sul', 'India': 'Índia', 'Indonesia': 'Indonésia', 'Polonia': 'Polônia',
          'Estados Unidos': 'EUA (referência, economia avançada)', 'Grupo FMI: Emerging Market and Developing Economies': 'Emergentes e em desenvolvimento (FMI)',
          'Grupo FMI: Advanced Economies': 'Economias avançadas (FMI)', 'Grupo FMI (FM): Emerging Market and Middle-Income Economies': 'Emergentes e renda média (FMI)'}
nm = lambda p: NOME_M.get(p, p)
mr = sorted([r for r in MR if r['juros_liquidos_pct_pib']], key=lambda r: float(r['juros_liquidos_pct_pib']))
fig, ax = plt.subplots(figsize=(LARG, 4.0))
ys = range(len(mr))
ax.barh(ys, [float(r['juros_liquidos_pct_pib']) for r in mr], color=[AZUL if r['iso3'] == 'BRA' else ('#c9a227' if r['iso3'] == 'USA' else ESCURO if r['iso3'].startswith(('G', 'FM')) else CINZA) for r in mr], height=0.65)
ax.set_yticks(list(ys), [f"{nm(r['pais'])} ({r['ano']})" for r in mr]); ax.grid(axis='y', visible=False); ax.tick_params(axis='y', length=0)
for y, r in zip(ys, mr): ax.text(float(r['juros_liquidos_pct_pib']) + 0.08, y, br(float(r['juros_liquidos_pct_pib']), 1), va='center', fontsize=7.5)
ax.set_xlabel('juros líquidos do governo geral, % do PIB (FMI, WEO out/2026)')
fig.tight_layout(); fig.savefig(f'{G}/10-emergentes.svg'); plt.close(fig)

NM = le('N-juro-real-mensal.csv')
import datetime as dt
fx = lambda m: int(m[:4]) + (int(m[5:7]) - 0.5) / 12
FAIXA_D = [(2008.0, 2011.0, 'Lula 2', 0), (2011.0, 2016 + 132 / 366, 'Dilma', 1), (2016 + 132 / 366, 2019.0, 'Temer', 0), (2019.0, 2023.0, 'Bolsonaro', 1), (2023.0, 2026.85, 'Lula 3', 0)]
def faixas_d(ax, rotulo=True):
  for a, b, nome, tom in FAIXA_D:
    if tom: ax.axvspan(a, b, color='#ececec', lw=0, zorder=0)
    if rotulo: ax.text((a + b) / 2, 1.0, nome, ha='center', va='bottom', fontsize=8, color=CINZA, transform=ax.get_xaxis_transform(), clip_on=False)
fig, (a1, a2) = plt.subplots(2, 1, figsize=(LARG, 5.0), sharex=True, gridspec_kw={'height_ratios': [3, 2]})
faixas_d(a1); faixas_d(a2, rotulo=False)
for c, cor, nome in (('juro_real_10a', AZUL, 'juro real, NTN-B 10 anos'), ('inflacao_implicita_10a', ESCURO, 'inflação implícita, 10 anos')):
  pts = [(fx(r['mes']), float(r[c])) for r in NM if r[c]]
  a1.plot([p[0] for p in pts], [p[1] for p in pts], color=cor, lw=1.4, label=nome)
a1.set_ylabel('% ao ano'); a1.legend(fontsize=7, frameon=False, loc='upper center', ncol=2, bbox_to_anchor=(0.5, -0.02)); a1.set_ylim(0, 10)
EV = le('N-eventos-fiscais.csv')
for i, e in enumerate(EV):
  x = int(e['data'][:4]) + (dt.date.fromisoformat(e['data']).timetuple().tm_yday - 0.5) / 366
  a1.axvline(x, color='#c9a227', lw=0.6, zorder=1); a1.text(x, 0.4 + (i % 3) * 0.7, str(i + 1), fontsize=6, color='#8a6d00', ha='center')
pts = [(fx(r['mes']), float(r['selic_meta_fim_mes'])) for r in NM if r['selic_meta_fim_mes']]
a2.step([p[0] for p in pts], [p[1] for p in pts], where='post', color=ESCURO, lw=1.3); a2.set_ylabel('meta Selic, % ao ano'); a2.set_ylim(0, 16)
a2.set_xlim(2008, 2027); a2.set_xticks(range(2008, 2027, 2))
fig.tight_layout(); fig.savefig(f'{G}/11-juro-real.svg'); plt.close(fig)
print('graficos v6 ok')


MANDATO_RE = re.compile(r'Lula|Dilma|Temer|Bolsonaro|FHC|>(?:L2|L3|D|T|B|D/T)<')
MANDATO_LINHA = '<div class=mand>Os nomes e as faixas de governo datam os valores e não atribuem a causa a cada governo.</div>'
svg = lambda n: (lambda s: s + (MANDATO_LINHA if MANDATO_RE.search(s) else ''))(open(f'{G}/{n}.svg', encoding='utf-8').read().split('?>', 1)[-1])
# ---------- fatos: todo numero do texto sai daqui, lido dos arquivos de fonte, com a nota [n] da fonte
FONTES = {
  'rtn': 'Tesouro Nacional, Resultado do Tesouro Nacional, séries históricas de ago/2026 (tabelas 2.1-A e 2.5-A em % do PIB; tabela 2.5 em R$, valor pago, inclusive o memorando de créditos extraordinários). https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326',
  'bcb': 'Banco Central, estatísticas fiscais, NFSP, juros nominais apropriados (competência) por esfera. https://www.bcb.gov.br/ftp/notaecon/Nfspp.zip (2008 a 2017), https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/202101_Tabelas_de_estatisticas_fiscais.xlsx (Tabela 2, 2018 a 2020) e 202601_Tabelas_de_estatisticas_fiscais.xlsx (Tabela 2, 2021 a 2025); 12 meses até ago/2026 pelas séries SGS 4607 e 4616 (https://api.bcb.gov.br/dados/serie/bcdata.sgs.4607/dados?formato=json)',
  'bcbdiv': 'Banco Central, dívida bruta do governo geral (critério Bacen) e dívida líquida do setor público, % do PIB, e fatores condicionantes da dívida líquida. Até 2017: https://www.bcb.gov.br/ftp/notaecon/Divggnp.zip, https://www.bcb.gov.br/ftp/notaecon/Dlspp.zip e Tabelas de estatísticas fiscais (https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/, vale a edição mais nova de cada ano). De dez/2018 em diante: SGS 13762 e 4513 (https://api.bcb.gov.br/dados/serie/bcdata.sgs.13762/dados?formato=json). Critério FMI: edição 202609, Tabela 17',
  'rmd': 'Tesouro Nacional, Relatório Mensal da Dívida de ago/2026 (anexos 2, 3.1, 3.7, 4.2, 4.3). https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29322',
  'cofog': 'Tesouro Nacional, Despesas por função do Governo Geral (COFOG) 2024. https://thot-arquivos.tesouro.gov.br/publicacao-anexo/27169',
  'focus_hist': 'Banco Central, Focus, API Olinda, ExpectativasMercadoAnuais (baseCalculo 0), mediana de IPCA, PIB Total, Selic, Câmbio e Resultado primário, datas de setembro e outubro de 2000 a 2024. https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais',
  'sgs_fb': 'Banco Central, SGS, séries 432 (meta da Selic), 1 (PTAX venda) e 5793 (NFSP sem desvalorização cambial, primário do setor público consolidado em 12 meses), e IBGE, SIDRA 1737 (IPCA) e 5932 (PIB). https://api.bcb.gov.br/dados/serie/bcdata.sgs.{série}/dados',
  'tse_turnos': 'TSE, dados abertos de resultados, detalhe da votação por município e zona de 2002 a 2022 (só turno, data e cargo), e Constituição Federal, art. 77, para as datas de 2026. https://dadosabertos.tse.jus.br',
  'ploa27': 'PLOA 2027, Mensagem Presidencial (Tabelas 9, 10 e 11) e Volume IV, inciso XI (grade de parâmetros da SPE). https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/ploa-2027',
  'copom281': 'Banco Central, histórico das taxas de juros fixadas pelo Copom, reunião 281 (Selic de 13,75% desde 17/09/2026). https://www.bcb.gov.br/controleinflacao/historicotaxasjuros',
  'dou_oi': 'Diário Oficial da União, portarias SEST/MGI do 6º bimestre (nº 16 de 27/01/2023, nº 479 de 29/01/2024, nº 709 de 29/01/2025 e nº 630 de 26/01/2026), anexo, Orçamento de Investimento executado em 2022 a 2025 por grupo, fonte e empresa. https://www.in.gov.br/web/dou/-/portaria-sest/mgi-n-630-de-26-de-janeiro-de-2026-683359728',
  'sest_oi': 'Ministério da Gestão, SEST, Orçamento de Investimento das empresas estatais federais executado, tabelas consolidadas de 2009 a 2021. https://www.gov.br/gestao/pt-br/assuntos/estatais/central-de-conteudo/guias-e-manuais/dados-e-estatisticas/orcamento-de-investimento',
  'ocde_cofog': 'OCDE, National Accounts, Table 11, General government expenditure by function (COFOG), e Table 1, PIB, consulta de 24/10/2026. OECD Data Explorer, https://data-explorer.oecd.org (DSD_NASEC10@DF_TABLE11 e DF_TABLE1). Uso livre com citação.',
  'statcan': 'Source: Statistics Canada, Table 10-10-0005-01, Canadian classification of functions of government, e Table 36-10-0222-01, PIB, 2024. Adapted from Statistics Canada, reproduced and distributed on an as is basis. https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1010000501',
  'wdi_ppc': 'Banco Mundial, World Development Indicators, NY.GDP.PCAP.PP.CD, PIB por habitante em PPC, atualização de 08/10/2026, CC BY 4.0. https://data.worldbank.org/indicator/NY.GDP.PCAP.PP.CD',
  'fmi': 'FMI, Public Finances in Modern History / DataMapper, juros em % do PIB, OCDE média simples. https://www.imf.org/external/datamapper/api/v1/ie',
  'oecd_saude': 'OCDE, Government expenditure by function (COFOG), saúde em % do PIB. https://sdmx.oecd.org/public/rest/data/OECD.GOV.GIP,DSD_GOV_COFOG@DF_GOV_COFOG_YU,1.0/all',
  'ibge': 'IBGE, Projeções da População, revisão 2024 (ajustada ao Censo 2022). https://ftp.ibge.gov.br/Projecao_da_Populacao/Projecao_da_Populacao_2024/',
  'ipca': 'IBGE, SIDRA tabela 1737, IPCA, número-índice mensal (dezembro de cada ano; no último dado, o mês). https://apisidra.ibge.gov.br/values/t/1737',
  'benef': 'Beneficiados: INSS e BPC, média mensal do Boletim Estatístico da Previdência Social de dez/2025, quadro 14 (https://www.gov.br/previdencia/pt-br/assuntos/previdencia-social/Dados-estatisticos-previdencia-social-e-inss/boletins-da-previdencia-social/2025/beps122025_final.xls); Bolsa Família, média mensal do MI Social do MDS (https://aplicacoes.mds.gov.br/sagi/servicos/misocial); referência de dezembro: INSS (BEPS dez/2024 e dez/2025, AEPS Suplemento Histórico 2023, benefícios previdenciários com acidentários), MDS (MI Social), PLDO 2027 anexos IV.11, IV.12 e IV.14, INEP (Censo Escolar e da Educação Superior), ANS (TabNet), CJF, CNJ, Senappen, servidores pelo Painel Estatístico de Pessoal e pela Defesa. Cada número com sua URL em G-beneficiarios.csv e brutos/H/.',
  'ec95': 'Emenda Constitucional nº 95, de 15/12/2016, art. 106 do ADCT: "Novo Regime Fiscal", limites para as despesas primárias "por vinte exercícios financeiros". https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc95.htm',
  'ec103': 'Emenda Constitucional nº 103, de 12/11/2019, "altera o sistema de previdência social". https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc103.htm',
  'lc173': 'Lei Complementar nº 173, de 27/05/2020, art. 8º: proíbe até 31/12/2021 "aumento, reajuste ou adequação de remuneração" de servidores e militares, "exceto quando derivado de sentença judicial transitada em julgado ou de determinação legal anterior à calamidade pública". https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp173.htm',
  'lc179': 'Lei Complementar nº 179, de 24/02/2021: autonomia do Banco Central; art. 4º, § 1º, mandato do presidente do BC de 4 anos "com início no dia 1º de janeiro do terceiro ano de mandato do Presidente da República". https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp179.htm',
  'ec114': 'Emenda Constitucional nº 114, de 16/12/2021, art. 107-A do ADCT: limite anual para pagamento de precatórios até o fim de 2026. https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc114.htm',
  'ec123': 'Emenda Constitucional nº 123, de 14/07/2022, art. 120 do ADCT: estado de emergência em 2022 e acréscimo de R$ 200,00 ao Auxílio Brasil de agosto a dezembro de 2022. https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc123.htm',
  'ec126': 'Emenda Constitucional nº 126, de 21/12/2022, art. 3º: limite de gastos de 2023 "acrescido em R$ 145.000.000.000,00". https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc126.htm',
  'lc200': 'Lei Complementar nº 200, de 30/08/2023: "regime fiscal sustentável", com fundamento no art. 6º da EC 126. https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp200.htm',
  'rfb': 'Receita Federal, Carga Tributária no Brasil 2024 (relatório e tabelas; série recalculada 2002 a 2024 pela metodologia nova). https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/estudos/carga-tributaria',
  'tcarga': 'Tesouro Nacional, Estimativa da Carga Tributária Bruta do Governo Geral 2025. https://www.tesourotransparente.gov.br/publicacoes/carga-tributaria-do-governo-geral/2025/114',
  'dgt': 'Receita Federal, Demonstrativo dos Gastos Tributários, bases efetivas 2008 a 2023 e previsões PLOA 2024 a 2026 (Quadro VI). https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/relatorios/renuncia/gastos-tributarios-bases-efetivas',
  'ocde': 'OCDE, Revenue Statistics e Revenue Statistics in Latin America and the Caribbean, tributos do governo geral em % do PIB. https://sdmx.oecd.org/public/rest/data/OECD.CTP.TPS,DSD_REV_COMP_OECD@DF_RSOECD,/.TAX_REV.S13._T._T.PT_B1GQ.A',
  'spe': 'Ministério da Fazenda, SPE, Boletim Resultado Fiscal Estrutural 2024 e 1º semestre de 2025, Apêndice A, tabelas A.1 e A.2 (eventos não recorrentes desde 1997). https://www.gov.br/fazenda/pt-br/central-de-conteudo/publicacoes/transparencia-fiscal/boletim-resultado-fiscal-estrutural/2025/boletim-rfe-24-semestre-1-25.pdf (lido na cópia do Internet Archive de 20/03/2026, porque a página oficial pede login)',
  'weo': 'FMI, World Economic Outlook de outubro de 2026 (publicado em 13/10/2026) e Fiscal Monitor, via SDMX. https://api.imf.org/external/sdmx/3.0/data/dataflow/IMF.RES/WEO/',
  'bis': 'BIS, Central bank policy rates (WS_CBPOL) e Consumer prices (WS_LONG_CPI). https://stats.bis.org/api/v2/data/dataflow/BIS/WS_CBPOL/1.0/',
  'td': 'Tesouro Nacional, Taxas dos Títulos Ofertados pelo Tesouro Direto (CSV histórico, taxa de compra da manhã), consultado em 18/10/2026. https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv',
  'fred': 'Federal Reserve Bank of St. Louis, FRED, séries DFII10 (juro real do título do Tesouro americano indexado à inflação, 10 anos), FEDFUNDS, DGS10, VIXCLS (VIX), DTWEXBGS (dólar amplo) e BAMLEMCBPIOAS (spread ICE BofA de corporativos de emergentes, histórico pelo Internet Archive, não redistribuído), consultadas em 18 e 19/10/2026. https://fred.stlouisfed.org/series/DFII10',
  'pip': 'Banco Mundial, Poverty and Inequality Platform, Brasil, linhas de US$ 3,00 e US$ 8,30 por dia em PPC 2021 (atualização de junho de 2025), consultado em 19/10/2026. https://www.worldbank.org/en/news/factsheet/2025/06/05/june-2025-update-to-global-poverty-lines ; https://api.worldbank.org/pip/v1/pip?country=BRA&year=all&povline=3&ppp_version=2021&format=json',
  'focus': 'Banco Central, Focus, Relatório de Mercado de 09/10/2026 (medianas anuais de Selic, IPCA e PIB, API Olinda ExpectativasMercadoAnuais). https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/ExpectativasMercadoAnuais',
  'pldo27': 'Projeto de LDO 2027, Anexo IV.2, Metas Fiscais Anuais, p. 6 e 7 (metas de primário de 2027 a 2030 e projeção da DBGG). https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/pldo/anexo-iv-02-metas-fiscais.pdf/@@display-file/file',
  'ipea_td': 'Ipea, Texto para Discussão 2823, Tributação indireta: alíquotas efetivas e incidência sobre as famílias (POF 2017-2018), p. 25, gráfico 3; hospedado pelo Ministério da Fazenda nos estudos da reforma tributária. https://www.gov.br/fazenda/pt-br/acesso-a-informacao/acoes-e-programas/reforma-tributaria/estudos/tributacao-indireta-aliquotas-efetivas-e-incidencia-sobre-as-familias',
  'rfb_centis': 'Receita Federal, Distribuição da renda por centis, anos-calendário 2023 e 2024, aba BRV (imposto devido sobre a renda bruta). https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/estudos/distribuicao-da-renda/distribuicao-de-renda-por-centis-estudo-ampliado-2017-a-2023/2024/centis-br-ac2024.xlsx',
  'spe_dist': 'Ministério da Fazenda, SPE, Relatório da Distribuição Pessoal da Renda e da Riqueza, dados do IRPF 2023, p. 9 (dez/2025), e SPE/SPF, Impactos da reforma do IRPF proposta no PL 1.087/2025, p. 15; lidos na cópia do Internet Archive de 19/10/2026, com hash igual ao do original. https://www.gov.br/fazenda/pt-br/central-de-conteudo/publicacoes/conjuntura-economica/estudos-economicos/2025/relatorio-distribuicao-renda-2025.pdf',
  'ipea_cc': 'Ipea, Carta de Conjuntura 65, nota 8 (29/10/2024), p. 6, gráfico 2: IRPF mais IRPJ e CSLL atribuídos aos sócios, 2022. https://repositorio.ipea.gov.br/server/api/core/bitstreams/b6ed30d2-f78a-4c78-912c-ec3c49bdb91a/content',
  'siconfi': 'Tesouro Nacional, Siconfi, RREO da União, anexo 4 (receitas e despesas previdenciárias), dezembro de cada ano; RREO de dez/2025 republicado para o FCDF. https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo',
  'rpps_mps': 'Ministério da Previdência, estatísticas dos RPPS, União (arquivo 2-uniao.zip de 2025). https://www.gov.br/previdencia/pt-br/assuntos/rpps/estatisticas-e-informacoes-dos-rpps-1/arquivos/2025/2-uniao.zip',
  'pldo27_atu': 'Projeto de LDO 2027, anexos IV.10 (projeção do RGPS), IV.11 (avaliação atuarial do RPPS civil da União) e IV.12 (militares e FCDF), data focal 31/12/2025. https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/pldo/anexo-iv-11-avaliacao-atuarial-rpps.pdf',
  'ec132': 'Emenda Constitucional nº 132, de 20/12/2023 (reforma tributária do consumo), ADCT arts. 125 a 133 e 159-A a 159-B (fundos). https://www.planalto.gov.br/ccivil_03/constituicao/emendas/emc/emc132.htm',
  'lc214': 'Lei Complementar nº 214, de 16/01/2025 (IBS, CBS e Imposto Seletivo), redação vigente; arts. 31 a 35 (split payment), 112 a 124 (cashback), anexos I, VII e XV (alimentos), art. 475 (trava de referência). https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp214.htm',
  'sert': 'Ministério da Fazenda, SERT, notas técnicas sobre a alíquota de referência (ago/2023, jul/2024 e ago/2024), lidas na cópia do Internet Archive com hash igual ao original. https://www.gov.br/fazenda/pt-br/acesso-a-informacao/acoes-e-programas/reforma-tributaria/regulamentacao-da-reforma-tributaria/lei-geral-do-ibs-da-cbs-e-do-imposto-seletivo',
  'cgibs': 'Comitê Gestor do IBS, Resolução CGIBS nº 14, de 29/07/2026 (parâmetro de alíquota e arrecadação de 2027). https://www.in.gov.br/en/web/dou/-/resolucao-cgibs-n-14-de-29-de-julho-de-2026-722519981',
  'd12955': 'Decreto nº 12.955/2026, regulamento da CBS, art. 33 (primeira etapa do split payment). https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2026/decreto/D12955.htm',
  'oecd': 'OCDE, Main Economic Indicators, juros de longo prazo de títulos de governo (México, África do Sul, Colômbia, Chile, Índia, Polônia, Hungria), via FRED; definições nacionais. https://fred.stlouisfed.org/series/IRLTLT01MXM156N',
  'embi': 'Ipeadata, EMBI+ Brasil (JPM366_EMBI366, J.P. Morgan), série descontinuada em 30/07/2024. http://www.ipeadata.gov.br/api/odata4/ValoresSerie(SERCODIGO=%27JPM366_EMBI366%27)',
  'lit': 'Revisão de 25 estudos (BCB, Ipea, FMI, BIS, Banco Mundial e periódicos), com link, página e magnitude em Y-literatura.csv; faixa do simulador em brutos/Y/LEIAME.md.',
  'olinda_ipca': 'Banco Central, Focus, API Olinda, ExpectativasMercadoInflacao12Meses (IPCA esperado para 12 meses, mediana suavizada) e ExpectativasMercadoSelic (Selic por reunião), consultadas em 19/10/2026. https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata/',
  'ipea_selic': 'Ipeadata, Selic over (BCB), conferida mês a mês com a série 4189 do BCB. http://www.ipeadata.gov.br/api/odata4/',
  'tse': 'TSE, propostas de governo 2026 (dados abertos), arquivos dos dois candidatos do 2º turno, lidos em 18/10/2026: nenhum traz trajetória numérica de primário para 2027-2030. https://cdn.tse.jus.br/estatistica/sead/odsele/proposta_governo/proposta_governo_2026_BR.zip',
  'k_prec': 'Tesouro Nacional, apresentação do resultado do Tesouro de dez/2023, pagamento do estoque de precatórios após a ADI 7064 (via K-eventos-nao-recorrentes.csv). https://cdn.tesouro.gov.br/sistemas-internos/apex/producao/sistemas/thot/arquivos/publicacoes/48787_1551088/anexos/22120_1455608/apresentacao_dez23.pdf',
  'emendas': 'Tesouro Nacional, Despesas e Transferências Totais da União, bases anuais de 2014 a 2026, por identificador de resultado primário (RP6 a RP9), com restos a pagar pagos; conferido contra o SIOP e o Portal da Transparência (via Z-emendas.csv). https://www.tesourotransparente.gov.br/ckan/dataset/despesas-e-transferencias-totais',
  'emendas_marcos': 'Textos oficiais em Z-marcos.csv: ECs 86/2015, 100/2019 e 105/2019 e Lei 13.957/2019 (planalto.gov.br); STF, ADPFs 850, 851, 854 e 1.014, julgamento de 19/12/2022 (portal.stf.jus.br); LC 210/2024. https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp210.htm',
  'y2': 'Inventário de medidas fiscais de 2015 a 2026: exposições de motivos, notas da Fazenda e do Planejamento, relatórios da IFI, RTN e PLDO, com URL, página e trecho conferido por medida em Y2-medidas.csv e brutos/Y2/downloads.tsv.',
  'n2': 'Estudo de eventos fiscais de 2015 a 2026: protocolo em BRIEF-v11.md; datas e impactos de Câmara, Senado, Planalto e Fazenda conferidos por trecho literal (brutos/N2/confere.py); taxas do Tesouro Direto e controles do FRED.',
  'copom': 'Banco Central, histórico das taxas de juros fixadas pelo Copom. https://www.bcb.gov.br/controleinflacao/historicotaxasjuros',
  'camara_eventos': 'Câmara dos Deputados, dados abertos das proposições (PEC 241/2016, PEC 6/2019, PLP 93/2023, PLP 210/2024), Agência Câmara e Agência Senado para as datas de anúncio. https://dadosabertos.camara.leg.br/api/v2/proposicoes/',
  'j_bcb': 'Banco Central, Tabelas de estatísticas fiscais (edições de 2009 a 2026: composição e fatores condicionantes da dívida bruta, composição da dívida líquida, ajustes por tipo) e ftp/notaecon de 26/12/2018. https://www.bcb.gov.br/content/estatisticas/hist_estatisticasfiscais/',
  'bndes': 'BNDES, Transparência, Recursos do Tesouro Nacional (devoluções ordinárias e antecipadas, atualização de 14/10/2026). https://www.bndes.gov.br/wps/portal/site/home/transparencia/recursos-do-tesouro-nacional',
  'rad': 'Tesouro Nacional, Relatório Anual da Dívida 2017 a 2025 (uso do resultado do BC, Lei 13.820/2019) e Avaliação da Dívida 2019. https://cdn.tesouro.gov.br/sistemas-internos/apex/producao/sistemas/thot/arquivos/publicacoes/37047_1249118/RAD%202020%20_2021_01_27-17h.pdf',
  'siop': 'Sistema Integrado de Planejamento e Orçamento (SIOP), execução da despesa da União em 2025, liquidado, grupos de natureza de despesa 2 (juros e encargos) e 6 (amortização), com e sem refinanciamento. https://www1.siop.planejamento.gov.br/sparql/',
  'stnbc': 'Tesouro Nacional, Relacionamento entre o Tesouro Nacional e o Banco Central, Relatório Especial 2019 (Tabela 1, p. 11 e 12; p. 19, 21 e 27), e Banco Central, demonstrações financeiras anuais de 2019 a 2025 (operações com o Governo Federal, resultado a transferir ou a cobrir). https://cdn.tesouro.gov.br/sistemas-internos/apex/producao/sistemas/thot/arquivos/publicacoes/29828_926299/RelatorioTesouroBC.pdf',
  'osu': 'Ministério do Planejamento e Orçamento, Orçamento de Subsídios da União, 9ª edição (ago/2025), anexos, Tabela 3 e detalhamento por benefício, ano 2024. https://www.gov.br/planejamento/pt-br/assuntos/avaliacao-de-politicas-publicas/arquivos/orcamento-de-subsidios-da-uniao/osu_2025-anexos-publicacao.xlsx',
  'sis': 'IBGE, Síntese de Indicadores Sociais 2025, tabelas de distribuição de renda e pobreza (Gini e pobreza com e sem programas sociais), e SIDRA 7435. https://ftp.ibge.gov.br/Indicadores_Sociais/Sintese_de_Indicadores_Sociais/Sintese_de_Indicadores_Sociais_2025/Tabelas/',
  'irpf': 'Receita Federal, Grandes Números do IRPF, anos-calendário 2007 a 2024, distribuição por faixa de rendimento total. https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/estudos/imposto-de-renda/estudos-por-ano/grandes-numeros-do-IRPF-2008-a-2025',
  'beps': 'Ministério da Previdência, Boletim Estatístico da Previdência Social, dez/2025, quadro 14. https://www.gov.br/previdencia/pt-br/assuntos/previdencia-social/arquivos/beps122025_final.pdf',
  'aeps': 'Ministério da Previdência, Estatísticas dos RPPS, União, civis (segurados e proventos médios por poder, 2013 a 2024). https://www.gov.br/previdencia/pt-br/assuntos/rpps/estatisticas-e-informacoes-dos-rpps-1/arquivos/2025/2-uniao.zip',
  'pldo': 'PLDO 2027, Anexo IV.12, avaliação atuarial do Sistema de Proteção Social dos Militares (proventos médios, mai/2025). https://www.gov.br/planejamento/pt-br/assuntos/orcamento/orcamentos-anuais/2027/pldo/anexo-iv-12-avaliacao-atuarial-pensoes-militares-2013-volume-1.pdf',
  'inep': 'INEP, Ideb, resultados por rede e etapa, 2005 a 2025 (Ideb, nota padronizada do Saeb e indicador de rendimento). https://www.gov.br/inep/pt-br/areas-de-atuacao/pesquisas-estatisticas-e-indicadores/ideb/resultados',
  'pisa': 'OCDE, PISA 2025 Results, Volume I, Annex B1, tabelas de tendência I.B1.2a.36 a 38 (lido na cópia do Internet Archive de 04/10/2026; arquivos em stat.link). http://web.archive.org/web/20261004142322/https://www.oecd.org/en/publications/pisa-2025-results-volume-i_73451bc5-en/full-report/results-for-countries-and-economies_33854635.html',
  'wdi': 'Banco Mundial, World Development Indicators (repassa ONU WPP, UN IGME, OMS GHED e UNESCO UIS). https://api.worldbank.org/v2/',
  'l14663': 'Lei nº 14.663, de 28/08/2023: "política de valorização permanente do salário mínimo", reajuste pelo INPC mais o crescimento real do PIB de dois anos antes. https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/l14663.htm',
  'pof': 'IBGE, Pesquisa de Orçamentos Familiares 2017-2018, SIDRA tabela 6715, distribuição da despesa monetária e não monetária média mensal familiar por classe de rendimento e tipo de despesa. https://apisidra.ibge.gov.br/values/t/6715/n1/all/v/1204/p/all/c339/all/c12190/all',
  'salmin': 'Salário mínimo vigente por mês, Ministério do Trabalho, série MTE12_SALMIN12 do Ipeadata. http://www.ipeadata.gov.br/api/odata4/ValoresSerie(SERCODIGO=%27MTE12_SALMIN12%27)',
  'd12797': 'Decreto nº 12.797/2025, salário mínimo de R$ 1.621,00 a partir de 1º/01/2026. https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/D12797.htm',
  'inpc': 'IBGE, SIDRA tabela 1736, INPC, número-índice mensal. https://apisidra.ibge.gov.br/values/t/1736/n1/all/v/2289/p/all',
  'dieese': 'DIEESE, Pesquisa Nacional da Cesta Básica de Alimentos, banco de dados, São Paulo, total da cesta, tempo de trabalho e gasto mensal, jan/1995 a set/2026. https://www.dieese.org.br/cesta/',
  'pnad_trab': 'IBGE, PNAD Contínua, SIDRA tabelas 6390 e 6392, rendimento médio e massa de rendimento mensal real habitual de todos os trabalhos, trimestre móvel. https://apisidra.ibge.gov.br/values/t/6390/n1/all/v/5933/p/all',
  'pnad_dom': 'IBGE, PNAD Contínua anual, SIDRA tabela 7533, rendimento médio mensal real domiciliar per capita a preços médios do último ano, por classe de percentil das pessoas. https://apisidra.ibge.gov.br/values/t/7533/n1/all/v/10816/p/all/c1019/all',
  'ipea_ifr': 'Ipea, Indicador Ipea de Inflação por Faixa de Renda, nota de agosto de 2026 (Carta de Conjuntura 72, nota 13) e planilha de dados. https://www.ipea.gov.br/cartadeconjuntura/index.php/2026/09/inflacao-por-faixa-de-renda-agosto2026/',
  'tse_pt': 'TSE, plano de governo de Lula (PT, coligação Brasil Pronto pra Mais), registrado para o 2º turno de 2026, 84 páginas. https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt',
  'tse_pl': 'TSE, plano de governo de Flávio Bolsonaro (PL), "Diretrizes do Plano de Governo 2027-2030", registrado para o 2º turno de 2026, 76 páginas. https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pl',
  'l15077': 'Lei nº 15.077, de 27/12/2024, art. 4º, ganho real do salário mínimo de 2025 a 2030 limitado pelo crescimento da despesa do arcabouço. https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/l15077.htm',
  'l8213': 'Lei nº 8.213, de 24/07/1991, art. 41-A, reajuste anual dos benefícios do INSS pelo INPC. https://www.planalto.gov.br/ccivil_03/leis/l8213cons.htm',
  'cf': 'Constituição Federal, art. 201 (nenhum benefício que substitua o rendimento do trabalho abaixo do salário mínimo) e art. 203, V (BPC de um salário mínimo). https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm',
  'l15270': 'Lei nº 15.270, de 26/11/2025, redução do IRPF mensal até R$ 7.350 (imposto zero até R$ 5.000) e tributação mínima acima de R$ 600 mil por ano. https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/lei/l15270.htm',
  'pib_ibge': 'IBGE, Contas Nacionais Trimestrais, SIDRA tabela 5932, taxa acumulada no ano do PIB. https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/6563/p/all/c11255/all',
  'prodes': 'INPE, PRODES (TerraBrasilis), taxa anual de desmatamento da Amazônia Legal de 1988 a 2026 e incremento anual de desmatamento do Cerrado de 2000 a 2026, km², soma das UFs. Ano PRODES de agosto a julho. Painel atualizado em 16/10/2026. https://terrabrasilis.dpi.inpe.br/app/dashboard/deforestation/biomes/legal_amazon/rates',
  'siop_fun': 'SIOP, execução da despesa da União de 2000 a 2025 nas funções Agricultura, Organização Agrária, Gestão Ambiental e Cultura, liquidado, sem a modalidade 91 (intra-orçamentária), por subfunção e grupo de natureza de despesa, e ações de inversão financeira de 2023 a 2025. https://www1.siop.planejamento.gov.br/sparql/',
  'osu_serie': 'Ministério do Planejamento e Orçamento, Orçamento de Subsídios da União, 9ª edição (ago/2025), anexos, Tabela 1, subsídios por benefício de 2003 a 2024, R$ correntes. https://www.gov.br/planejamento/pt-br/assuntos/avaliacao-de-politicas-publicas/arquivos/orcamento-de-subsidios-da-uniao/osu_2025-anexos-publicacao.xlsx',
  'salic': 'Ministério da Cultura, painel Salic Comparar, captação de recursos da Lei Rouanet por ano, 1993 a 2026, lido em 18/10/2026. https://aplicacoes.cultura.gov.br/comparar/salicnet/',
  'pib_agro': 'IBGE, Contas Nacionais Trimestrais, SIDRA tabela 5932, taxa acumulada no ano do valor adicionado da agropecuária, 4º trimestre. https://apisidra.ibge.gov.br/values/t/5932/n1/all/v/6563/p/all/c11255/all',
  'cf41': 'Constituição Federal, art. 41, § 3º, extinto o cargo, o servidor estável fica em disponibilidade com remuneração proporcional ao tempo de serviço. https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm',
  'cv_atos': 'Atos oficiais da frente CV, conferidos por trecho literal: Lei 13.502/2017, MP 870/2019, Lei 13.844/2019, MP 1.154/2023 e Lei 14.600/2023 (Planalto), Lei 14.017/2020, LC 195/2022, Lei 14.399/2022 e MP 1.135/2022 (Planalto), IN Ministério da Cidadania 2/2019, Portaria Ministério da Cidadania 1.576/2019, IN Secult/MTur 1/2022 e IN MinC 1/2023 (DOU). Lista com trechos e endereços em CV-atos.csv. https://www.planalto.gov.br/ccivil_03/ e https://www.in.gov.br/',
  'jfrj_1576': 'Justiça Federal, 11ª Vara Federal do Rio de Janeiro, Ação Civil Pública 5067900-76.2019.4.02.5101 (MPF contra Ancine, União e o ministro da Cidadania), decisão de tutela de urgência de 07/10/2019, juíza federal substituta Laura Bastos Carvalho. Impressão do documento público do eproc (evento 4) hospedada pelo Poder360, autenticidade conferível no eproc com o código 510001689943v32. Não foram achados a petição do MPF, a decisão de mérito nem o acórdão do TRF2. https://static.poder360.com.br/2019/10/DECISAO-OSMAR-TERRA.pdf',
  'siop_cv': 'SIOP, ações de transferência da cultura por lei (Lei Aldir Blanc, Lei Paulo Gustavo, Política Nacional Aldir Blanc), dotação, empenhado e liquidado de 2020 a 2025. https://www1.siop.planejamento.gov.br/sparql/',
  'salic_painel': 'Ministério da Cultura, painel Salic Comparar, relatórios de propostas transformadas em projeto por ano, projetos avaliados pela CNIC por ano, tempo médio da admissibilidade à publicação e lista de projetos do incentivo fiscal federal com busca pelo nome, lidos em 20/10/2026. https://aplicacoes.cultura.gov.br/comparar/salicnet/',
  'trends': 'Google Trends, Brasil, de 01/2004 a 09/2026, termos Lei Rouanet, Plano Safra, Zona Franca de Manaus e Fundo Partidário no mesmo pedido, lido em 20/10/2026. https://trends.google.com/trends/explore?date=2004-01-01%202026-09-30&geo=BR',
  'camara': 'Câmara dos Deputados, API de dados abertos, proposições por ano de apresentação com o termo, de 2003 a 2025, lida em 20/10/2026. https://dadosabertos.camara.leg.br/api/v2/proposicoes',
  'horas': 'IBGE, PNAD Contínua, SIDRA tabela 6372, média de horas habitualmente trabalhadas no trabalho principal. https://apisidra.ibge.gov.br/values/t/6372/n1/all/v/8186/p/all/c58/95253',
  'rreo_funcao': 'Tesouro Nacional, Siconfi, RREO da União, Anexo 2 (despesa por função e subfunção), 6º bimestre de 2015 a 2025, despesas liquidadas, exceto intra-orçamentárias. https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio=2025&nr_periodo=6&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%2002&id_ente=1',
  'anbima': 'ANBIMA, estrutura a termo das taxas de juros estimada, vértices da curva prefixada, da curva em IPCA e da inflação implícita de 19/10/2026 (página pública, direitos reservados, fora do pacote). https://www.anbima.com.br/informacoes/est-termo/CZ.asp',
}
ORDEM = list(FONTES)
n = lambda k: f'<sup>[{ORDEM.index(k) + 1}]</sup>'

def rtn_linha(tab, prefixo):
  rows = list(wb[tab].iter_rows(values_only=True))
  h = next(r for r in rows if r[0] and 'Discrimina' in str(r[0]))
  r = next(r for r in rows if r[0] and str(r[0]).strip().startswith(prefixo))
  return {int(a): float(v) for a, v in zip(h[1:], r[1:]) if isinstance(a, (int, float)) and v is not None}
pib_pct = lambda d: {a: v * 100 if abs(v) < 1 else v for a, v in d.items()}
desp_pib = pib_pct(rtn_linha('2.1-A', '4. DESPESA TOTAL')); res_pib = pib_pct(rtn_linha('2.1-A', '8. RESULTADO PRIM'))
transf_pib = pib_pct(rtn_linha('2.1-A', '2. TRANSF'))
pes_pib = pib_pct(rtn_linha('2.5-A', '2.2  Pessoal'))
d21 = rtn_linha('2.1', '4. DESPESA TOTAL')
disc = rtn_linha('2.5', '2.4.2 Discricion'); dtot = rtn_linha('2.5', '2. DESPESA TOTAL')
ae = rtn_linha('2.5', 'm.2.8 ')  # creditos extraordinarios discricionarios de assistencia social (Auxilio Emergencial)
pct_obrig = 100 * (1 - disc[2025] / dtot[2025])
hist = {(r['bloco_id'], int(r['ano'])): float(r['valor_rs_bi_correntes']) for r in le('H-gasto-uniao-historico.csv')}
F = [r for r in le('F-divida.csv')]
fd = lambda est, cat, sub, ano='2026': next(r for r in F if r['ano'] == ano and r['estagio'] == est and r['categoria'] == cat and r['subcategoria'].startswith(sub))
valor_nota = lambda r: float(r['nota'].split('VALOR=')[1].split()[0])
dpf = float(fd('estoque_ago', 'DPF ESTOQUE (RMD)', 'DPF em poder')['valor_brl']) / 1e12
idx = {k: float(fd('estoque_ago', 'DPF COMPOSICAO POR INDEXADOR (RMD)', k)['pct_total']) for k in ('Taxa flutuante', 'Indice de precos', 'Prefixado', 'Cambio')}
selic_rs = float(fd('estoque_ago', 'DPF COMPOSICAO POR INDEXADOR (RMD)', 'Taxa flutuante')['valor_brl']) / 1e9
venc = fd('estoque_ago', 'DPF PERFIL E CUSTO (RMD)', 'vincendo')
prazo = valor_nota(fd('estoque_ago', 'DPF PERFIL E CUSTO (RMD)', 'prazo medio'))
custo = valor_nota(fd('estoque_ago', 'DPF PERFIL E CUSTO (RMD)', 'custo medio do estoque DPF'))
emis = valor_nota(fd('estoque_ago', 'DPF PERFIL E CUSTO (RMD)', 'custo medio das emissoes'))
det = {k: float(fd('estoque_ago', 'DPMFi DETENTORES (RMD)', k)['pct_total']) for k in ('Instituicoes', 'Previdencia', 'Fundos', 'Nao residentes', 'Tesouro Direto')}
j12 = fd('competencia_12m_ate_ago', 'JUROS NOMINAIS APROPRIADOS (BCB NFSP)', 'Governo Federal (sem BCB')
jsp = fd('competencia_12m_ate_ago', 'JUROS NOMINAIS APROPRIADOS (BCB NFSP)', 'Setor publico consolidado')
C_ = le('C-governo-geral-cofog.csv')
cof = lambda cat, pais: float(next(r for r in C_ if r['categoria'] == f'COMPARACAO: {cat}' and r['subcategoria'].startswith(pais))['pct_pib'])
j_br, j_oc, s_br, s_oc = cof('Juros', 'Brasil [STN'), cof('Juros', 'OCDE (media simples 38 membros) [FMI]'), cof('Saude', 'Brasil'), cof('Saude', 'OCDE (pais medio')
Gb = le('G-beneficiarios.csv')
inss_pessoas = int(next(r for r in Gb if r['tabela'] == 'uniao-2025' and r['bloco'].startswith('Aposentadorias e pensoes do INSS') and r['unidade'] == 'pessoas')['beneficiarios'])
AB = le('ABSOLUTO-uniao-2025.csv')
uj = next(r for r in u if 'Juros' in r['bloco']); ui = next(r for r in u if r['bloco'].startswith('Aposentadorias'))
ur = next(r for r in u if r['bloco'].startswith('Repasses'))
tot = next(r for r in AB if r['bloco'].startswith('TOTAL'))
jcaixa = float(next(r for r in AB if r['bloco'].startswith('Referencia: juros pagos em dinheiro'))['valor_rs_bi'])
jur, ins, rep, total, pct_tot = float(uj['valor_rs_bi']), float(ui['valor_rs_bi']), float(ur['valor_rs_bi']), float(tot['valor_rs_bi']), float(tot['pct_pib'])
prim = total - jur - rep
refv = lambda pref: float(next(r for r in AB if r['bloco'].startswith(pref))['valor_rs_bi'])
amort, rolag = refv('Referencia: amortizacao paga sem rolar'), refv('Referencia: rolagem')
raz = {r['bloco']: r for r in le('RAZAO-per-capita.csv') if r['tabela'] == 'uniao-2025'}
hh = {r['ano']: r for r in le('H-largo-por-habitante.csv')}
hb = {r['ano']: r for r in le('H-largo-por-beneficiado.csv')}
sel = ['2008', '2014', '2019', '2022', '2025']
mx = lambda d, a0, a1, fora=(): (min(v for a, v in d.items() if a0 <= a <= a1 and a not in fora), max(v for a, v in d.items() if a0 <= a <= a1 and a not in fora))
dmin, dmax = mx(desp_pib, 2015, 2025, fora=(2020,))
# divida bruta no criterio FMI, ultima leitura da edicao mais nova (Tabela 17)
wbf = openpyxl.load_workbook(os.path.join(RAIZ, 'brutos', 'I', 'bcb-202609_Tabelas_de_estatisticas_fiscais.xlsx'), read_only=True, data_only=True)
t17 = [list(r) for r in wbf['Tabela 17'].iter_rows(values_only=True)]
ult = lambda rot: [c for c in next(r for r in t17 if r and isinstance(r[0], str) and rot in r[0]) if isinstance(c, (int, float))][-1]
dbgg_fmi, dbgg_bacen = ult('Conceito FMI (A'), ult('Conceito Bacen (B')

# coerencia interna: o mesmo numero de 2025 tem de ser igual na tabela 1 e na serie historica
uben = lambda pref: int(next(r for r in u if r['bloco'].startswith(pref))['rs_por_beneficiado_ano'])
cb = {c.split(' (')[0]: c for c in hb['2025'] if c != 'ano'}
for pref, c in (('Aposentadorias e pensoes do INSS', 'INSS'), ('Bolsa Familia', 'Bolsa Familia'), ('Servidores e militares', 'Servidores ativos')):
  assert abs(uben(pref) - float(hb['2025'][cb[c]])) <= 1, (pref, uben(pref), hb['2025'][cb[c]])
assert abs(int(raz[ui['bloco']]['rs_por_habitante_ano']) - float(hh['2025']['INSS'])) <= 1

linhas_u = ''
for r in u:
  z = raz.get(r['bloco'], {})
  un = r['beneficiados_unidade'].split(' (')[0]
  for a_, b_ in (('beneficios', 'benefícios'), ('familias', 'famílias'), ('matriculas', 'matrículas'), ('pessoas', 'pessoas')): un = un.replace(a_, b_)
  if r['bloco'].startswith('Servidores e militares'): un = 'postos (custo total por posto)'
  sem_div = r['bloco'].startswith(('Saude', 'Educacao'))  # denominador nao mede atendidos pela despesa federal
  benef = f"{br(int(r['beneficiados']))} {un}" if r['rs_por_beneficiado_ano'] and not sem_div else ''
  linhas_u += (f"<tr><td>{curto(r['bloco'])}</td><td class=n>{br(float(r['valor_rs_bi']), 1)}</td><td class=n>{br(float(r['pct_pib']), 1)}</td>"
               f"<td class=n>{br(int(z.get('rs_por_habitante_ano') or 0))}</td><td>{benef}</td>"
               f"<td class=n>{br(int(r['rs_por_beneficiado_ano'])) if r['rs_por_beneficiado_ano'] and not sem_div else ''}</td></tr>")
hab_tot = next(r for r in le('RAZAO-per-capita.csv') if r['tabela'] == 'uniao-2025' and r['bloco'] == 'TOTAL')
linhas_u += f"<tr class=t><td>Soma das três medidas (não é um total de orçamento)</td><td class=n>{br(total, 1)}</td><td class=n>{br(pct_tot, 1)}</td><td class=n>{br(int(hab_tot['rs_por_habitante_ano']))}</td><td>{br(int(hab_tot['beneficiados']))} habitantes</td><td></td></tr>"
p = [r for r in le('ABSOLUTO-pais-2024.csv') if r['soma'] == 'sim']
tp = next(r for r in le('ABSOLUTO-pais-2024.csv') if r['bloco'].startswith('TOTAL'))
COFOG_PT = {'pensoes': 'pensões', 'divida': 'dívida', 'Educacao': 'Educação', 'Saude': 'Saúde', 'Maquina publica': 'Máquina pública', 'economicos': 'econômicos',
            'Familia, criancas': 'Família, crianças', 'Auxilio-doenca, invalidez': 'Auxílio-doença, invalidez', 'deficiencia': 'deficiência', 'Justica': 'Justiça',
            'prisoes': 'prisões', 'Habitacao, agua, iluminacao': 'Habitação, água, iluminação', 'protecao': 'proteção', 'Radio': 'Rádio', 'Policia': 'Polícia', 'publicacao publicas': 'publicação públicas'}
def pt(c):
  for k, v in COFOG_PT.items(): c = c.replace(k, v)
  return c
linhas_p = ''.join(f"<tr><td>{pt(r['bloco'].split(' (')[0])}</td><td class=n>{br(float(r['valor_rs_bi']), 1)}</td><td class=n>{br(float(r['pct_pib']), 1)}</td></tr>" for r in p)
linhas_p += f"<tr class=t><td>Total</td><td class=n>{br(float(tp['valor_rs_bi']), 1)}</td><td class=n>{br(float(tp['pct_pib']), 1)}</td></tr>"
COLS_H = ['INSS', 'Juros', 'Repasses a estados e municipios', 'Saude', 'Servidores ativos', 'Aposentados da Uniao', 'Bolsa Familia', 'BPC', 'Educacao', 'Seguro-desemprego e abono']
linhas_h = ''.join(f"<tr><td>{acento(c)}</td>" + ''.join(f"<td class=n>{br(float(hh[a][c]))}</td>" for a in sel) +
                   f"<td class=n>{br(float(hh['2025'][c]) / float(hh['2008'][c]), 1)}x</td></tr>" for c in COLS_H)
hj, hi = (float(hh['2025'][c]) for c in ('Juros', 'INSS'))
hj24, hj08 = float(hh['2024']['Juros']), float(hh['2008']['Juros'])
hs19, hs22 = float(hh['2019']['Servidores ativos']), float(hh['2022']['Servidores ativos'])

M = le('I-divida-por-mandato.csv')
fm = lambda v, d=1: br(float(v), d) if v not in ('', None) else 'n/d'
seta = lambda a, b: f"{fm(a)} → {fm(b)}" if a and b else (f"n/d → {fm(b)}" if b else 'n/d')
linhas_m = ''.join(f"<tr><td>{m['mandato'].replace('ate', 'até')}</td><td class=n>{fm(m['primario_gov_central_medio_pct_pib'], 2)}</td><td class=n>{seta(m['dbgg_inicio'], m['dbgg_fim'])}</td>"
                   f"<td class=n>{seta(m['dlsp_inicio'], m['dlsp_fim'])}</td>" + ''.join(f"<td class=n>{fm(m[c]) if m[c] else ''}</td>" for c in ('ano_primario', 'ano_juros', 'ano_cambio', 'ano_pib', 'ano_outros'))
                   + f"<td class=n><b>{fm(m['ano_juros_mais_pib']) if m['ano_juros_mais_pib'] else ''}</b></td></tr>" for m in M)
mm = {m['mandato'].split(' (')[0]: m for m in M}
com = [m for m in M if m['ano_juros_mais_pib'] and int(m['n_anos']) > 1]  # 2016, um ano so, fica fora do intervalo
jp_min = min(com, key=lambda m: float(m['ano_juros_mais_pib'])); jp_max = max(com, key=lambda m: float(m['ano_juros_mais_pib']))
BO, L3 = mm['Bolsonaro'], mm['Lula 3']
FT20 = FT['primario'][2020]
bo_sem20 = sum(FT['primario'][a] for a in (2019, 2021, 2022))
nome_m = lambda m: m['mandato'].split(' (')[0]
texto_div = (f"A decomposição é contábil e não identifica causas. Juros nominais e crescimento nominal do PIB carregam a mesma inflação, então a soma dos dois (o efeito bola de neve, a diferença entre juro e crescimento) é a medida comparável entre mandatos. "
             f"Por ano, ela foi de {fm(jp_min['ano_juros_mais_pib'])} ponto do PIB ({nome_m(jp_min)}) a {fm(jp_max['ano_juros_mais_pib'])} pontos ({nome_m(jp_max)}). No Lula 3, {fm(L3['ano_juros_mais_pib'])} pontos por ano, contra {fm(L3['ano_primario'])} do primário. "
             f"O primário de Bolsonaro somou {fm(BO['fator_primario'])} pontos à dívida líquida, com {fm(FT20)} só em 2020. Os outros três anos somaram {fm(bo_sem20)}. "
             f"No mesmo mandato a dívida bruta caiu ({fm(BO['dbgg_inicio'])}% para {fm(BO['dbgg_fim'])}%) e a líquida subiu ({fm(BO['dlsp_inicio'])}% para {fm(BO['dlsp_fim'])}%). A ponte entre as duas, com as vendas de ativos, vem logo abaixo. "
             f"A taxa de juros responde à inflação e ao risco fiscal percebido, de modo que primário e juros não são fatores independentes{n('bcbdiv')}.")

# ---------- v6: tabelas e numeros das frentes K, L, M, N
MANDS = [('FHC', 1997, 2002), ('Lula 1', 2003, 2006), ('Lula 2', 2007, 2010), ('Dilma', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016),
         ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2025)]
def media(d, a, b):
  v = [d[x] for x in range(a, b + 1) if x in d]
  return (sum(v) / len(v), len(v)) if v else (None, 0)
fm2 = lambda t, d=1: '' if t[0] is None else br(t[0], d) + ('' if t[1] else '')
gte = {a: v for a, (v, nt) in LS['gasto_tributario_pct_pib'].items() if 'proje' not in nt.lower()}
cr, ct, rl, po = lv('carga_tributaria_bruta_receita'), lv('carga_tributaria_bruta_tesouro'), lv('receita_liquida_gc'), lv('pct_obrigatoria')
linhas_rec = ''
for nome, a, b in MANDS:
  cel = [media(rl, a, b), media(cr, a, b), media(ct, a, b), media(gte, a, b), media(po, a, b)]
  linhas_rec += f"<tr><td>{nome if a == b else f'{nome} ({a}-{str(b)[2:]})'}</td>" + ''.join(f"<td class=n>{fm2(c)}</td>" for c in cel) + '</tr>'
ult_cr = max(cr); ult_ct = max(ct); ult_gt = max(gte)
LI = {r['pais_ou_grupo']: r for r in le('L-carga-internacional.csv')}
ci = lambda k: float(LI[k]['carga_pct_pib'])
br_oc, oc_m, alc_m = ci('Brasil (OCDE/RS LAC)'), ci('Media OCDE'), ci('Media America Latina e Caribe (RS LAC)')
PAIS_PT = {'Franca': 'França', 'Italia': 'Itália', 'Canada': 'Canadá', 'Japao': 'Japão', 'Colombia': 'Colômbia', 'Mexico': 'México',
           'Media OCDE': 'Média OCDE', 'Media America Latina e Caribe (RS LAC)': 'Média América Latina e Caribe', 'Brasil (OCDE/RS LAC)': 'Brasil (base OCDE)'}
linhas_ci = ''.join(f"<tr{' class=t' if r['pais_ou_grupo'].startswith('Brasil (OCDE') else ''}><td>{PAIS_PT.get(r['pais_ou_grupo'], r['pais_ou_grupo'])}</td><td class=n>{r['ano']}</td><td class=n>{br(float(r['carga_pct_pib']), 1)}</td></tr>"
                    for r in le('L-carga-internacional.csv') if r['carga_pct_pib'] and not r['pais_ou_grupo'].startswith(('Brasil (RFB', 'Brasil (Tesouro')))

KM = le('K-por-mandato.csv')
linhas_k = ''.join(f"<tr><td>{r['mandato']}</td><td class=n>{br(float(r['primario_cheio_media_pct_pib']), 2)}</td><td class=n>{br(float(r['primario_recorrente_media_pct_pib']), 2)}</td>"
                   f"<td class=n>{br(float(r['diferenca_pp']), 2)}</td><td class=n>{br(float(r['estrutural_spe_media_pct_pib_potencial']), 2) + ' (' + r['anos_com_estrutural_spe'] + ')' if r['estrutural_spe_media_pct_pib_potencial'] else ''}</td></tr>" for r in KM)
km = {r['mandato'].split(' (')[0]: r for r in KM}
def jan(a, b):
  # medias do Governo Central nos mesmos anos para as tres medidas; estrutural so onde a SPE publicou
  c = [float(KR[x]['primario_cheio_pct_pib']) for x in range(a, b + 1)]
  r = [float(KR[x]['primario_recorrente_pct_pib']) for x in range(a, b + 1)]
  e = [float(KR[x]['primario_estrutural_spe_pct_pib_potencial']) for x in range(a, b + 1) if KR[x]['primario_estrutural_spe_pct_pib_potencial']]
  return sum(c) / len(c), sum(r) / len(r), (sum(e) / len(e) if len(e) == b - a + 1 else None)
JAN = [('Temer, 2018', 2018, 2018), ('Bolsonaro, 2019-22', 2019, 2022), ('Bolsonaro sem 2020', None, None), ('Lula 3, 2023-24', 2023, 2024), ('Lula 3, 2023-25 (2025 estimado)', 2023, 2025)]
def jan_bo_sem20():
  anos = (2019, 2021, 2022)
  m = lambda col: sum(float(KR[x][col]) for x in anos) / 3
  return m('primario_cheio_pct_pib'), m('primario_recorrente_pct_pib'), m('primario_estrutural_spe_pct_pib_potencial')
JV = {nm: (jan_bo_sem20() if a is None else jan(a, b)) for nm, a, b in JAN}
f2 = lambda v: '' if v is None else br(v, 2)
linhas_jan = ''.join(f"<tr><td>{nm}</td>" + ''.join(f"<td class=n>{f2(v)}</td>" for v in JV[nm]) + '</tr>' for nm, _, _ in JAN)
bo_j, l3_j = JV['Bolsonaro, 2019-22'], JV['Lula 3, 2023-24']
KE = le('K-eventos-nao-recorrentes.csv')
k20 = KR[2020]

MD = le('M-decomposicao-juros.csv')  # brutos/M/build_M_decomp.py
dmed = next(r for r in MD if r['iso3'] == 'MED'); dbra = next(r for r in MD if r['iso3'] == 'BRA')
linhas_md = ''.join(f"<tr{' class=t' if r['iso3'] == 'MED' else ''}><td>{nm(r['comparador']) if r['iso3'] != 'MED' else 'Emergente mediano'}</td><td class=n>{br(float(r['juros_pct_pib']), 1)}</td><td class=n>{br(float(r['juro_implicito_pct']), 1)}</td>"
                    f"<td class=n>{br(float(r['base_divida_pct_pib']), 0)}</td><td class=n>{br(float(r['brasil_menos_comparador_pp']), 1)}</td><td class=n>{br(float(r['efeito_taxa_pp']), 1)}</td><td class=n>{br(float(r['efeito_estoque_pp']), 1)}</td></tr>"
                    for r in MD if r['iso3'] != 'BRA')
lista = lambda xs: ', '.join(xs[:-1]) + ' e ' + xs[-1] if len(xs) > 1 else ''.join(xs)
md_c = [r for r in MD if r['iso3'] not in ('BRA', 'MED')]
md_taxa = [nm(r['comparador']) for r in md_c if float(r['efeito_taxa_pp']) > float(r['efeito_estoque_pp'])]
md_est = [nm(r['comparador']) for r in md_c if float(r['efeito_taxa_pp']) <= float(r['efeito_estoque_pp'])]
mb = next(r for r in MR if r['iso3'] == 'BRA'); memg = next(r for r in MR if r['iso3'] == 'G200')
paises = [r for r in MR if not r['iso3'].startswith(('G', 'FM'))]
rank_j = 1 + sum(float(r['juros_liquidos_pct_pib']) > float(mb['juros_liquidos_pct_pib']) for r in paises)
rank_tb = 1 + sum(r['taxa_basica_real_dez2025_pct'] and float(r['taxa_basica_real_dez2025_pct']) > float(mb['taxa_basica_real_dez2025_pct']) for r in paises)
seg_tb = sorted((r for r in paises if r['iso3'] != 'BRA' and r['taxa_basica_real_dez2025_pct']), key=lambda r: -float(r['taxa_basica_real_dez2025_pct']))[0]
cel_m = lambda r, c, d=1: br(float(r[c]), d) if r[c] else ''
linhas_mm = ''.join(f"<tr{' class=t' if r['iso3'] == 'BRA' else ''}><td>{nm(r['pais'])} ({r['ano']})</td>" + ''.join(f"<td class=n>{cel_m(r, c)}</td>" for c in
                    ('juros_liquidos_pct_pib', 'juros_brutos_fpp_2024_pct_pib', 'primario_pct_pib', 'divida_bruta_pct_pib', 'juro_implicito_pct', 'juro_menos_cresc_nominal_pp', 'taxa_basica_real_dez2025_pct')) + '</tr>'
                    for r in sorted(MR, key=lambda r: -float(r['juros_liquidos_pct_pib'] or 0)))
MJ = [r for r in le('M-juros-emergentes.csv') if r['iso3'] == 'BRA' and r['indicador'].startswith('juros') and r['projecao'] == 'sim']

NMA = le(os.path.join('brutos', 'N', 'medias_mandato.csv'))
selic_m = lambda m: float(next(r for r in NMA if r['mandato'] == m)['selic_meta_media_dias_td'])
JF = {(r['serie'], int(r['ano'])): float(r['valor_rs_mi']) for r in le('J-dbgg-fatores.csv') if r['valor_rs_mi']}
PIBK = {int(r['ano']): float(r['pib_rs_mi']) for r in le('K-primario-recorrente.csv')}
i_est = JF[('dbgg_fat_juros_nominais', 2025)] / JF[('dbgg_fat_saldo', 2024)]
g_est = PIBK[2025] / PIBK[2024] - 1
d_est = DV['dbgg'][2025]
p_est = lambda i: 100 * (i - g_est) / (1 + g_est) * d_est / 100
RS = {(r['periodo'], r['presidente']): r for r in le('R-juro-real-br-eua.csv')}
rsm = lambda m, c: float(RS[('mandato', m)][c])
linhas_rs = ''.join(f"<tr><td>{m}</td>" + ''.join(f"<td class=n>{br(rsm(m, c), 2)}</td>" for c in ('juro_real_10a_br', 'juro_real_10a_eua', 'diferenca_pp')) + "</tr>"
                    for m in ('Lula 2', 'Dilma', 'Temer', 'Bolsonaro', 'Lula 3'))
rs_ano = {r['periodo']: float(r['diferenca_pp']) for r in le('R-juro-real-br-eua.csv') if r['periodo'].isdigit()}
rs_n = {r['periodo']: int(r['n_meses']) for r in le('R-juro-real-br-eua.csv') if r['periodo'].isdigit()}
rs_m = lambda a0, a1: sum(rs_ano[str(a)] * rs_n[str(a)] for a in range(a0, a1 + 1)) / sum(rs_n[str(a)] for a in range(a0, a1 + 1))
d_br = rsm('Lula 3', 'juro_real_10a_br') - rsm('Bolsonaro', 'juro_real_10a_br')
d_us = rsm('Lula 3', 'juro_real_10a_eua') - rsm('Bolsonaro', 'juro_real_10a_eua')
linhas_n = ''.join(f"<tr><td>{r['mandato']}</td>" + ''.join(f"<td class=n>{br(float(r[c]), 2) if r[c] else ''}</td>" for c in
                   ('juro_real_10a', 'inflacao_implicita_10a', 'selic_meta_media_dias_td', 'juro_real_implicito_dpf_media')) + '</tr>' for r in NMA)
ref = EV[0]
p90_r, p90_i = float(ref['ref_p90_abs_var_10d_juro_real_10a_pb']), float(ref['ref_p90_abs_var_10d_infl_impl_10a_pb'])
med_r, med_i = float(ref['ref_mediana_abs_var_10d_juro_real_10a_pb']), float(ref['ref_mediana_abs_var_10d_infl_impl_10a_pb'])
EV_PT = {'Camara': 'Câmara', 'Promulgacao': 'Promulgação', 'Previdencia': 'Previdência', 'transicao': 'transição', 'Anuncio': 'Anúncio',
         'arcabouco': 'arcabouço', 'Sancao': 'Sanção'}
def evp(t):
  for k, v in EV_PT.items(): t = t.replace(k, v)
  return t
dmy = lambda d: f'{d[8:10]}/{d[5:7]}/{d[:4]}'
sinal = lambda v: ('+' if float(v) > 0 else '') + br(float(v), 0)
forte = lambda v, p: f"<b>{sinal(v)}</b>" if abs(float(v)) > p else sinal(v)
linhas_ev = ''.join(f"<tr><td class=n>{i + 1}</td><td class=n>{dmy(e['data'])}</td><td>{evp(e['evento'])}</td><td>{e['presidente']}</td><td class=n>{forte(e['var_juro_real_10a_pb'], p90_r)}</td><td class=n>{forte(e['var_inflacao_implicita_10a_pb'], p90_i)}</td></tr>"
                    for i, e in enumerate(EV))
ev = lambda k: next(e for e in EV if k in e['evento'])
NA = {int(r['ano']): r for r in le('N-juro-real-anual.csv')}


wbd = openpyxl.load_workbook(os.path.join(RAIZ, 'brutos', 'E', 'dgt-previsao-ploa-2026-quadros.xlsx'), read_only=True, data_only=True)
Q3 = [[c for c in r if c is not None] for r in wbd['Q III'].iter_rows(values_only=True)]
q3 = lambda pref: next(float(t[1]) for t in Q3 if t and isinstance(t[0], str) and t[0].startswith(pref)) / 1e9
mod = {r['subcategoria'].split(' (')[0]: r for r in ER if r['categoria'] in ('TOTAL subsidios da Uniao', 'Modalidade')}
mv = lambda k: float(mod[k]['valor_brl']) / 1e9; mp = lambda k: float(mod[k]['pct_pib'])
ER23 = {r['subcategoria']: float(r['valor_brl']) / 1e9 for r in le('E-renuncias-e-subsidios.csv') if r['ano'] == '2023' and r['estagio'].startswith('realizado (bases')}
ER26 = {r['subcategoria']: float(r['valor_brl']) / 1e9 for r in le('E-renuncias-e-subsidios.csv') if r['ano'] == '2026' and r['estagio'] == 'projecao PLOA'}
linhas_ef = ''.join(f"<tr><td>{r['subcategoria']}</td><td>{'financeiro' if 'financeiro' in r['categoria'] else 'creditício'}</td><td class=n>{br(float(r['valor_brl']) / 1e9, 1)}</td></tr>"
                    for r in sorted(er_f, key=lambda r: -float(r['valor_brl']))[:8])
top3 = sorted(er_t, key=lambda r: -float(r['valor_brl']))[:3]
# 4c. Emendas parlamentares por tipo (brutos/Z/build_Z.py)
ZE = [r for r in le('Z-emendas.csv') if r['medida'] == 'pago_total' and r['fonte'] == 'Tesouro']
ZP = {int(r['ano']): r for r in le('Z-emendas-participacao.csv')}
ZM = le('Z-marcos.csv')
TIPOS_Z = [('individuais (RP6)', 'individuais', AZUL), ('bancada estadual (RP7)', 'bancada', '#8fa7c4'), ('comissao (RP8)', 'comissão', CINZA), ('relator-geral (RP9)', 'relator-geral ("orçamento secreto")', ESCURO)]
zv = lambda tp, a: next((float(r['valor_rs_dez2025']) / 1e9 for r in ZE if r['tipo'] == tp and r['ano'] == str(a)), 0.0)
anos_z = sorted({int(r['ano']) for r in ZE})
fig, ax = plt.subplots(figsize=(LARG, 3.4)); faixas(ax, ini=anos_z[0], fs=6.5)
base_z = [0.0] * len(anos_z)
for tp, nome, cor in TIPOS_Z:
  v = [zv(tp, a) for a in anos_z]
  ax.bar(anos_z, v, bottom=base_z, color=cor, width=0.7, label=nome, zorder=2, hatch=None)
  base_z = [b + x for b, x in zip(base_z, v)]
ax.bar([anos_z[-1]], [base_z[-1]], color='none', width=0.7, hatch='////', edgecolor='#cfcfcf', lw=0, zorder=3)
ax.text(anos_z[-1], base_z[-1] + 1, 'jan-ago', ha='center', fontsize=6.5, color=CINZA)
ax.axvline(2019.5, color=CINZA, lw=0.6, ls=':'); ax.text(2019.4, ax.get_ylim()[1] * 0.97, 'até 2019, só individuais e bancada identificadas', ha='right', va='top', fontsize=6.5, color=CINZA)
ax.set_ylabel('R$ bi de dez/2025, pago no ano e restos a pagar'); ax.legend(frameon=False, loc='upper left', fontsize=7)
ax.set_xticks(anos_z[::2]); ax.set_xlim(anos_z[0] - 0.6, anos_z[-1] + 0.6)
fig.tight_layout(); fig.savefig(f'{G}/4c-emendas.svg'); plt.close(fig)
zt = lambda a: sum(zv(tp, a) for tp, _, _ in TIPOS_Z)
zpct = lambda a: float(ZP[a]['emendas_pct_discricionarias_rtn'])
zmarco = lambda trecho: next(r for r in ZM if trecho in r['ato'])
Z_EC126 = re.search(r'R\$ ?([\d,]+) bi', zmarco('126/2022')['o_que_mudou']).group(1)
sec_emendas = f"""<p><b>Emendas parlamentares e "orçamento secreto".</b> As emendas fazem parte da despesa já contada nas linhas da seção 1. Com elas, quem decide a destinação é o Congresso, e por isso medem a divisão do poder sobre o orçamento. A série só é homogênea desde 2020, quando os quatro tipos passaram a ter identificador próprio. De 2022 para 2025, as emendas pagas (no ano e de restos a pagar) foram de R$ {br(zt(2022), 1)} bi para R$ {br(zt(2025), 1)} bi, em R$ de 2025, alta real de {br(100 * (zt(2025) / zt(2022) - 1), 0)}%{n('emendas')}. Antes de 2020 só as individuais (e as de bancada, desde 2017) eram identificadas, e os R$ {br(zt(2019), 1)} bi de 2019 não são comparáveis ao total de anos posteriores. Como parte da despesa discricionária do Executivo (linha 4.4.2 do RTN, pagamento efetivo, que inclui restos a pagar e as emendas de execução obrigatória, classificadas como discricionárias), as emendas foram {br(zpct(2022), 1)}% em 2022 e {br(zpct(2025), 1)}% em 2025{n('emendas')}{n('rtn')}. O "orçamento secreto" foi o uso das emendas de relator-geral (RP9) para incluir ou ampliar programações a pedido de parlamentares que não eram identificados, sem critérios nem rastreabilidade. O STF declarou essas práticas incompatíveis com a Constituição em 19/12/2022 (ADPFs 850, 851, 854 e 1.014){n('emendas_marcos')}. O RP9 pagou R$ {br(zv('relator-geral (RP9)', 2021), 1)} bi em 2021 e R$ {br(zv('relator-geral (RP9)', 2022), 1)} bi em 2022. Depois da decisão cresceram as emendas de comissão (R$ {br(zv('comissao (RP8)', 2022), 1)} bi em 2022, R$ {br(zv('comissao (RP8)', 2025), 1)} bi em 2025) e as individuais (de R$ {br(zv('individuais (RP6)', 2022), 1)} bi para R$ {br(zv('individuais (RP6)', 2025), 1)} bi). Em 2023, R$ {Z_EC126} bi do antigo RP9 foram para despesa discricionária comum por autorização da EC 126/2022 e não aparecem como emenda. O STF voltou a cobrar transparência e rastreabilidade das emendas de comissão e das transferências especiais em 2024 e 2025. O volume das emendas não diz se houve desperdício, e os critérios de transparência e rastreabilidade valem para todos os tipos e governos.</p>
<figure>{svg('4c-emendas')}</figure>
<p class=nota>Tesouro, Despesas e Transferências Totais da União, por identificador de resultado primário (RP6 a RP9), conferido contra o SIOP e o Portal da Transparência{n('emendas')}, deflator IPCA{n('ipca')}. 2026 até agosto. Antes de 2017, emendas de bancada iam em outro identificador. Antes de 2020, as de comissão e de relator também, por isso a série de 2014 a 2019 é só de individuais (e de bancada desde 2017). Marcos. Emendas individuais impositivas pela EC 86/2015, de bancada pela EC 100/2019, transferências especiais ("emendas Pix") pela EC 105/2019, relator-geral criado pela Lei 13.957/2019 e regras de transparência e rastreabilidade pela LC 210/2024 e por decisões do STF de 2024 e 2025{n('emendas_marcos')}. A fonte não permite saber quem indicou cada emenda de relator.</p>
"""
sec_ren = f"""<p><b>Renúncias e subsídios.</b> Em 2024 (Lula 3) os subsídios da União somaram R$ {br(mv('tributarios + financeiros + crediticios'), 1)} bi ({br(mp('tributarios + financeiros + crediticios'), 1)}% do PIB). R$ {br(mv('Subsidios tributarios'), 1)} bi de renúncias tributárias, R$ {br(mv('Subsidios financeiros'), 1)} bi de subsídios financeiros (equalizações e subvenções pagas pelo orçamento) e R$ {br(mv('Subsidios crediticios'), 1)} bi de subsídios creditícios (custo implícito de crédito a juro abaixo do custo do Tesouro){n('osu')}. A projeção do PLOA para os gastos tributários de 2026 é de R$ {br(ER26['todos'], 1)} bi{n('dgt')}.</p>
<figure>{svg('8b-renuncias')}</figure>
<table style="break-inside:avoid"><thead><tr><th>Maiores subsídios financeiros e creditícios, 2024</th><th>Tipo</th><th class=n>R$ bi</th></tr></thead><tbody>{linhas_ef}</tbody></table>
<p class=nota>Orçamento de Subsídios da União, 9ª edição{n('osu')}, renúncias pela Receita Federal{n('dgt')}. Renúncia é a receita que deixa de entrar pela regra especial, medida contra uma regra geral escolhida pela Receita. O fim da regra não traria esse valor de volta, porque pessoas e empresas mudariam de comportamento. As categorias são da fonte e misturam naturezas diferentes. O Simples é regime de empresas pequenas, e entre os itens isentos do IRPF estão a parcela de aposentadoria de quem tem 65 anos ou mais, a aposentadoria por moléstia grave e as indenizações por rescisão (R$ {br(q3('Aposentadoria de Declarante com 65'), 1)} bi, R$ {br(q3('Aposentadoria por Moléstia'), 1)} bi e R$ {br(q3('Indenizações por Rescisão'), 1)} bi projetados para 2026, Quadro III){n('dgt')}. A fonte não abre a renúncia por renda de quem recebe. O IRPF por faixa de renda está no anexo T3.</p>
<p>As três maiores renúncias são {top3[0]['subcategoria'].replace('SIMPLES', 'Simples')} (R$ {br(float(top3[0]['valor_brl']) / 1e9, 1)} bi), {top3[1]['subcategoria'].lower()} (R$ {br(float(top3[1]['valor_brl']) / 1e9, 1)} bi) e {top3[2]['subcategoria'].replace(' - IRPF', ' do IRPF').lower()} (R$ {br(float(top3[2]['valor_brl']) / 1e9, 1)} bi). Entre 2023 e 2024 os rendimentos isentos do IRPF passaram de R$ {br(ER23['Rendimentos Isentos e Não Tributáveis - IRPF'], 1)} bi para R$ {br(float(next(r for r in er_t if r['subcategoria'].startswith('Rendimentos Isentos'))['valor_brl']) / 1e9, 1)} bi, mas os dois números vêm de documentos diferentes (bases efetivas da Receita e Orçamento de Subsídios){n('dgt')}{n('osu')}. Na cultura, a previsão de 2026 é de R$ {br(cur('renuncia_cultura_e_audiovisual'), 2)} bi na categoria que a Receita chama de cultura e audiovisual, a soma da Lei Rouanet (R$ {br(cur('renuncia_lei_rouanet'), 2)} bi) com a dedução pela atividade audiovisual (R$ {br(cur('renuncia_atividade_audiovisual'), 2)} bi). Condecine, Recine e indústria cinematográfica têm categorias próprias no mesmo quadro (R$ {br(cur('renuncia_audiovisual_fora_da_categoria'), 2)} bi), e com eles o audiovisual chega a R$ {br(cur('renuncia_audiovisual'), 2)} bi. Somados todos os gastos tributários que a Receita classifica na função Cultura, inclusive os livros (R$ {br(cur('renuncia_livros'), 2)} bi) e as entidades culturais sem fins lucrativos (R$ {br(cur('renuncia_entidades_culturais'), 2)} bi), são R$ {br(cur('renuncia_funcao_cultura'), 2)} bi, mais que o dobro do que a União liquidou na função em 2025{n('dgt')}</p>"""
# Agro, meio ambiente e cultura por governo (secao 3), frentes FL, FN e CV
MA = ['FHC', 'Lula 1', 'Lula 2', 'Dilma', '2016 (Dilma/Temer)', 'Temer', 'Bolsonaro', 'Lula 3']
MA_ROT = {'FHC': 'FHC (2000 a 2002)', 'Dilma': 'Dilma (2011 a 2015)', '2016 (Dilma/Temer)': '2016 (Dilma e Temer)', 'Lula 3': 'Lula 3 (até 2025, desmatamento até 2026)'}
MA_ANOS = {'FHC': (2000, 2002), 'Lula 1': (2003, 2006), 'Lula 2': (2007, 2010), 'Dilma': (2011, 2015), '2016 (Dilma/Temer)': (2016, 2016), 'Temer': (2017, 2018), 'Bolsonaro': (2019, 2022), 'Lula 3': (2023, 2025)}
FNS = le('FN-subsidios-agro-cultura.csv'); fns = lambda a, sr, c='rs_bi': float(next(r[c] for r in FNS if r['ano'] == str(a) and r['serie'] == sr))
FNA = le('FN-inversoes-acoes.csv'); fna = lambda a, ini: float(next(r['liquidado_rs_bi'] for r in FNA if r['ano'] == str(a) and r['acao'].startswith(ini)))
FC24, FC25 = fna(2024, 'Apoio Financeiro Reembolsável'), fna(2025, 'Apoio Financeiro Reembolsável')
DIV25 = fna(2025, 'Financiamento Destinado à Liquidação')
AGP = {int(r['ano']): float(r['pib_agropecuaria_cresc_pct']) for r in le('FN-pib-agro.csv')}
AM_MIN = min(int(r['amazonia_legal_km2']) for r in FLD); assert AM_MIN == fl(2026, 'amazonia_legal_km2') and AM_MIN < 4571  # menor da serie desde 1988 (2012, 4.571 km2)
GA_MAND = {m: fnm(m, 'gestao_ambiental_sem_recursos_hidricos_rs_bi_2025_ano') for m in MA}
OA_MAND = {m: fnm(m, 'organizacao_agraria_com_inversoes_rs_bi_2025_ano') for m in MA}
OA13 = float(next(r['liquidado_rs_bi'] for r in le('FN-ordenamento-territorial.csv') if r['ano'] == '2013'))
assert min(GA_MAND, key=GA_MAND.get) == 'Bolsonaro' and min(OA_MAND, key=OA_MAND.get) == 'Bolsonaro' and max(OA_MAND, key=OA_MAND.get) == 'Lula 2'
assert max(MA, key=lambda m: fnm(m, 'agricultura_rs_bi_2025_ano')) == 'Dilma'
INV_ANT = [fnm(m, 'inversoes_agro_ambiente_rs_bi_2025_ano') for m in MA[:-1]]
kmd = lambda m, c: br(flm(m, c), 0)
fbi = lambda m, c, d=1: br(fnm(m, c), d)
ftc = lambda m, c, d=1: f'<td class=n>{br(fnm(m, c), d)}</td>' if FNM[m][c] != '' else '<td class=n>sem dado</td>'
lin_agro = ''.join(f"<tr><td>{MA_ROT.get(m, m)}</td><td class=n>{kmd(m, 'amazonia_media_km2_ano')}</td><td class=n>{kmd(m, 'cerrado_media_km2_ano')}</td>{ftc(m, 'pib_agropecuaria_cresc_medio_pct_ano')}{ftc(m, 'agricultura_rs_bi_2025_ano')}{ftc(m, 'organizacao_agraria_com_inversoes_rs_bi_2025_ano')}{ftc(m, 'gestao_ambiental_sem_recursos_hidricos_rs_bi_2025_ano')}{ftc(m, 'agro_subsidio_financeiro_rs_bi_2025_ano')}</tr>" for m in MA)
# cultura por mandato, num perimetro so: funcao Cultura sem inversoes, FSA a parte, transferencias por lei a parte (liquidado no ano)
mm = lambda m, f_: (lambda xs: sum(xs) / len(xs))([f_(a) for a in range(MA_ANOS[m][0], MA_ANOS[m][1] + 1)])
CU_F = {m: mm(m, lambda a: fnf(a, 'Cultura')) for m in MA}
CU_FSA = {m: mm(m, lambda a: fnf(a, 'Cultura', 'inversoes_financeiras_rs_bi_2025')) for m in MA}
CU_TR = {m: mm(m, lambda a: cvt(a) * defl25(a)) for m in MA}
CU_TRE = {m: mm(m, lambda a: cvt(a, 'empenhado_rs_bi') * defl25(a)) for m in MA}  # pelo empenho do ano
CU_TOT = {m: CU_F[m] + CU_TR[m] for m in MA}  # sem o FSA, que e inversao financeira, como no agro
CU_TOTE = {m: CU_F[m] + CU_TRE[m] for m in MA}
RO = {m: fnm(m, 'rouanet_captado_rs_bi_2025_ano') for m in MA}
assert min(CU_F, key=CU_F.get) == 'Bolsonaro' and CU_TOT['Bolsonaro'] > CU_TOT['Temer'] and CU_FSA['Bolsonaro'] < 0.01 and CU_TR['Bolsonaro'] > CU_TOT['Bolsonaro'] / 2 and RO['Temer'] < RO['Bolsonaro'] < RO['Dilma']
assert abs(CU_TOTE['Bolsonaro'] - CU_TOTE['Lula 3']) < 0.3 and CU_F['Lula 3'] < CU_F['Temer'] and max(fnf(a, 'Cultura', 'inversoes_financeiras_rs_bi_2025') for a in range(2015, 2023)) < 0.11
lin_cult = ''.join(f"<tr><td>{MA_ROT.get(m, m).replace(', desmatamento até 2026', '')}</td><td class=n>{br(CU_F[m], 2)}</td><td class=n>{br(CU_TR[m], 2)}</td><td class=n>{br(CU_TRE[m], 2)}</td><td class=n>{br(CU_TOT[m], 2)}</td><td class=n>{br(CU_TOTE[m], 2)}</td><td class=n>{br(CU_FSA[m], 2)}</td><td class=n>{br(RO[m], 2)}</td></tr>" for m in MA)
# fluxo da Rouanet por mandato (painel Salic, 2009 a 2025)
MS = [('Lula 2', 2009, 2010), ('Dilma', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016), ('Temer', 2017, 2018), ('Bolsonaro', 2019, 2022), ('Lula 3', 2023, 2025)]
sm = lambda c, i, f, red=lambda xs: sum(xs) / len(xs): (lambda xs: red(xs) if xs else None)([cvs(a, c) for a in range(i, f + 1) if cvs(a, c) is not None])
pct_t = lambda k, i, f: 100 * sum(cvs(a, 'projetos_' + k) for a in range(i, f + 1)) / sum(cvs(a, 'projetos_novos') for a in range(i, f + 1))
cel = lambda v, d=0: f'<td class=n>{br(v, d)}</td>' if v is not None else '<td class=n>sem dado</td>'
lin_salic = ''.join(f"<tr><td>{MA_ROT.get(m, m).replace(', desmatamento até 2026', '').replace('Lula 2', 'Lula 2 (2009 e 2010)')}</td>{cel(sm('projetos_novos', i, f))}{cel(sm('cnic_projetos_avaliados', i, f))}{cel(sm('dias_admissibilidade', i, f))}{cel(pct_t('lgbt', i, f), 2)}{cel(pct_t('negra_quilombola', i, f), 2)}{cel(pct_t('indigena', i, f), 2)}{cel(pct_t('gospel_controle', i, f), 2)}{cel(pct_t('orquestra_controle', i, f), 2)}</tr>" for m, i, f in MS)
ST = lambda a, b, c: sum(cvs(y, c) for y in range(a, b + 1))
apr_t = lambda k, i, f: 100 * ST(i, f, 'com_aprovado_' + k) / ST(i, f, 'projetos_' + k)
cap_t = lambda k, i, f: 100 * ST(i, f, 'com_captado_' + k) / ST(i, f, 'projetos_' + k)
assert all(apr_t(k, i, f) >= 90 for k in ('negra_quilombola', 'indigena') for _, i, f in MS[1:]) and all(cap_t(k, 2019, 2022) > max(cap_t(k, 2011, 2015), cap_t(k, 2023, 2025)) for k in ('negra_quilombola', 'indigena'))
assert all(0.005 <= pct_t('lgbt', i, f) < 0.05 for _, i, f in MS[:-1]) and pct_t('negra_quilombola', 2019, 2022) > pct_t('negra_quilombola', 2017, 2018)
assert pct_t('orquestra_controle', 2023, 2025) < pct_t('orquestra_controle', 2019, 2022)
# auditoria manual dos temas (brutos/CV/audita_temas.py): com os falsos negativos estimados, o Lula 3 fica acima de todos e Bolsonaro nao abaixo de Temer
CVTA = le('CV-temas-auditoria.csv'); cvta = lambda k, m, c: float(next(r[c] for r in CVTA if r['tema'] == k and r['presidente'] == m))
fxa = lambda k, m: f"{br(cvta(k, m, 'pct_com_falsos_negativos_min'), 2)}% e {br(cvta(k, m, 'pct_com_falsos_negativos_max'), 2)}%"
for _k in ('negra_quilombola', 'indigena', 'lgbt'):
  assert cvta(_k, 'Lula 3', 'pct_com_falsos_negativos_min') > max(cvta(_k, m, 'pct_com_falsos_negativos_max') for m in ('Lula 2', 'Dilma', 'Temer', 'Bolsonaro'))
for _k in ('negra_quilombola', 'indigena'):
  assert cvta(_k, 'Bolsonaro', 'pct_com_falsos_negativos_max') >= cvta(_k, 'Temer', 'pct_com_falsos_negativos_min')
ZFM26 = float(next(r['valor_brl'] for r in le('E-renuncias-e-subsidios.csv') if r['ano'] == '2026' and r['subcategoria'] == 'Zona Franca de Manaus e Áreas de Livre Comércio')) / 1e9
tr_m = lambda c, a, b: sum(float(CVA[y][c]) for y in range(a, b + 1)) / (b - a + 1)
cam_m = lambda c, a, b: sum(int(CVA[y][c]) for y in range(a, b + 1)) / (b - a + 1)
TR_PICO = max(range(2004, 2026), key=lambda y: float(CVA[y]['trends_lei_rouanet'])); assert TR_PICO == 2018
ESTRC = lambda a, b: sum(float(CVE[y]['pessoal_ativo_e_administracao_rs_bi_2025']) for y in range(a, b + 1)) / (b - a + 1)
MIN_N = {r['quando'][:4]: int(r['ministerios']) for r in CVM}
CAP_TEMA = max(sum(float(CVS[a][f'captado_{k}_rs_mi']) for k in ('lgbt', 'negra_quilombola', 'indigena')) for a in range(2009, 2026))
# Frente CI: gasto publico com cultura, Brasil, Canada e OCDE (COFOG 708x), 2024
CIR = {(r['subgrupo'], r['indicador']): r for r in le('CI-resumo.csv')}
C708 = {(r['ano'], r['subcategoria'][:18]): float(r['valor_brl']) / 1e9 for r in le('C-governo-geral-cofog.csv') if r['estagio'] == 'despesa_competencia_cofog' and r['categoria'].startswith('708')}
CI24 = [r for r in le('CI-cultura-internacional.csv') if r['ano'] == '2024' and r['subgrupo'] == '7082' and r['pais'] != 'OCDE_MEDIANA']
CIN = {'BRA': 'Brasil', 'CAN': 'Canadá', 'GBR': 'Reino Unido', 'JPN': 'Japão', 'COL': 'Colômbia', 'IRL': 'Irlanda', 'GRC': 'Grécia', 'ISL': 'Islândia', 'EST': 'Estônia',
       'HUN': 'Hungria', 'FRA': 'França', 'DEU': 'Alemanha', 'ESP': 'Espanha', 'ITA': 'Itália', 'PRT': 'Portugal', 'AUS': 'Austrália', 'POL': 'Polônia'}
ci = lambda sg, ind, c: CIR[(sg, ind)][c]
CI24.sort(key=lambda r: float(r['pct_pib']))
fig, ax = plt.subplots(figsize=(LARG, 2.5))
med = float(ci('7082', 'pct_pib', 'mediana_ocde'))
for k, r in enumerate(CI24):
  v = float(r['pct_pib']); cor = AZUL if r['pais'] == 'BRA' else (ESCURO if r['pais'] == 'CAN' else '#c6c6c6')
  ax.scatter([k], [v], s=22 if r['pais'] in ('BRA', 'CAN') else 14, color=cor, zorder=3)
  if r['pais'] in ('BRA', 'CAN', 'ISL', 'IRL'):  # Reino Unido sem rotulo, cairia sobre o do Brasil
    ax.text(k, v + 0.04, CIN[r['pais']], ha='center', va='bottom', fontsize=7, color=AZUL if r['pais'] == 'BRA' else ESCURO, fontweight='semibold' if r['pais'] == 'BRA' else 'normal')
ax.axhline(med, color=ESCURO, lw=0.6, ls='--'); ax.text(len(CI24) - 0.5, med + 0.03, f'mediana OCDE {br(med, 2)}', ha='right', va='bottom', fontsize=7, color=ESCURO)
ax.set_xticks([]); ax.spines['bottom'].set_visible(False); ax.set_ylim(0, 1.15); ax.set_ylabel('% do PIB')
fig.tight_layout(); fig.savefig(f'{G}/t1-cultura-ocde.svg'); plt.close(fig)
sec_cultura_ocde = f"""<h3>O Brasil na OCDE, 2024</h3>
<p>Na classificação internacional por função (COFOG), o gasto do governo geral com serviços culturais (grupo 7082, que tira esporte, rádio e TV e religião) foi de {br(float(ci('7082', 'pct_pib', 'brasil')), 2)}% do PIB no Brasil em 2024, contra {br(float(ci('7082', 'pct_pib', 'canada')), 2)}% no Canadá e mediana de {br(med, 2)}% em {ci('7082', 'pct_pib', 'n_paises_ocde_tabela11')} membros da OCDE com dado. O Brasil fica em {ci('7082', 'pct_pib', 'posicao_brasil')}. Por habitante, em dólares de paridade de poder de compra, são {br(float(ci('7082', 'usd_ppc_por_habitante', 'brasil')), 1)} no Brasil, {br(float(ci('7082', 'usd_ppc_por_habitante', 'canada')), 1)} no Canadá e {br(float(ci('7082', 'usd_ppc_por_habitante', 'mediana_ocde')), 1)} na mediana, e só a Colômbia gasta menos. Somando rádio e TV públicas (7083), o Brasil vai a {br(float(ci('7082_7083', 'pct_pib', 'brasil')), 2)}% do PIB e a mediana a {br(float(ci('7082_7083', 'pct_pib', 'mediana_ocde')), 2)}%. No grupo inteiro de lazer, cultura e religião (708), o Brasil tem {br(float(ci('708', 'pct_pib', 'brasil')), 2)}% e fica em {ci('708', 'pct_pib', 'posicao_brasil')}, acima só de EUA, Chile e Japão{n('cofog')}{n('ocde_cofog')}{n('statcan')}{n('wdi_ppc')}.</p>
<figure>{svg('t1-cultura-ocde')}</figure>
<p class=nota>Serviços culturais (COFOG 7082), governo geral, % do PIB, 2024, um ponto por país. Brasil pela STN, membros da OCDE pela Tabela 11 da OCDE sobre o PIB da Tabela 1, Canadá pela StatCan, que não reporta COFOG à OCDE e usa outro conceito (exclui investimento e consumo de capital e usa o exercício de abril a março), por isso fica fora da mediana. México, Nova Zelândia e Turquia não reportam. Chile, EUA e Coreia não separam os grupos. Mede despesa, não resultado, e a renúncia (Rouanet, audiovisual) fica fora em todos os países{n('cofog')}{n('ocde_cofog')}{n('statcan')}.</p>
<p><b>Leitura.</b> A comparação mede gasto e é classe A. Ela não diz quanto o país deveria gastar nem o que o gasto produz, e a renúncia fiscal, que é a maior parte do fomento da União à cultura (seção 4), não entra na COFOG de nenhum país. A alta do Brasil de {br(float(next(r['pct_pib'] for r in le('CI-cultura-internacional.csv') if r['pais'] == 'BRA' and r['ano'] == '2021' and r['subgrupo'] == '7082')), 3)}% em 2021 para {br(float(ci('7082', 'pct_pib', 'brasil')), 3)}% em 2024 é medida. A alta veio sobretudo dos municípios, que no grupo 708 foram de R$ {br(C708[('2021', 'Governos Municipai')], 1)} bi em 2021 para R$ {br(C708[('2024', 'Governos Municipai')], 1)} bi em 2024, contra R$ {br(C708[('2021', 'Governos Estaduais')], 1)} bi e R$ {br(C708[('2024', 'Governos Estaduais')], 1)} bi nos estados e R$ {br(C708[('2021', 'Governo Central (U')], 1)} bi e R$ {br(C708[('2024', 'Governo Central (U')], 1)} bi no Governo Central, em valores correntes{n('cofog')}. Não foi testado se parte da alta é mudança de classificação. A causa não está demonstrada (classe C).</p>"""
sec_agro_hist = f"""<h2>Anexo T2. Agro e meio ambiente por governo, 2000 a 2025</h2>
<p>Na Amazônia Legal, o desmatamento medido pelo INPE foi de {kmd('FHC', 'amazonia_media_km2_ano')} km² por ano de 2000 a 2002, no fim do governo FHC, e de {kmd('Lula 1', 'amazonia_media_km2_ano')} km² no Lula 1, com o pico de {br(fl(2004, 'amazonia_legal_km2'), 0)} km² em 2004. Caiu a {kmd('Lula 2', 'amazonia_media_km2_ano')} km² no Lula 2 e a {kmd('Dilma', 'amazonia_media_km2_ano')} km² no governo Dilma, com {br(fl(2012, 'amazonia_legal_km2'), 0)} km² em 2012. Ficou em {kmd('Temer', 'amazonia_media_km2_ano')} km² com Temer, subiu a {kmd('Bolsonaro', 'amazonia_media_km2_ano')} km² com Bolsonaro, com {br(fl(2021, 'amazonia_legal_km2'), 0)} km² em 2021, e caiu a {kmd('Lula 3', 'amazonia_media_km2_ano')} km² nos quatro anos PRODES do Lula 3. O ano encerrado em julho de 2026 teve {br(fl(2026, 'amazonia_legal_km2'), 0)} km² pelo dado de outubro de 2026, sujeito a revisão, o menor valor desde o início da série, em 1988{n('prodes')}. No Cerrado, a média caiu de {kmd('Lula 1', 'cerrado_media_km2_ano')} km² por ano no Lula 1 para {kmd('Temer', 'cerrado_media_km2_ano')} km² com Temer e ficou parecida com Bolsonaro ({kmd('Bolsonaro', 'cerrado_media_km2_ano')} km²) e no Lula 3 ({kmd('Lula 3', 'cerrado_media_km2_ano')} km²). Subiu de {br(fl(2019, 'cerrado_km2'), 0)} km² em 2019 para {br(fl(2023, 'cerrado_km2'), 0)} km² em 2023, primeiro ano do Lula 3 e o maior desde 2015, e caiu a {br(fl(2026, 'cerrado_km2'), 0)} km² em 2026.</p>
<figure>{svg('3b-desmatamento')}</figure>
<p>Na despesa da União, a função Agricultura, sem as inversões financeiras, foi de R$ {fbi('FHC', 'agricultura_rs_bi_2025_ano')} bi por ano de 2000 a 2002, chegou a R$ {fbi('Dilma', 'agricultura_rs_bi_2025_ano')} bi no governo Dilma, o maior valor entre os mandatos, caiu a R$ {fbi('Bolsonaro', 'agricultura_rs_bi_2025_ano')} bi com Bolsonaro e está em R$ {fbi('Lula 3', 'agricultura_rs_bi_2025_ano')} bi no Lula 3, em reais de 2025{n('siop_fun')}{n('ipca')}. As equalizações de juros e as subvenções do crédito rural e do seguro estão, na maior parte, dentro dessa função. O Orçamento de Subsídios as mede por outro critério, e em alguns anos o valor dele passa o liquidado da função, por isso as duas colunas não se somam nem se subtraem. Ele registra R$ {fbi('Lula 1', 'agro_subsidio_financeiro_rs_bi_2025_ano')} bi por ano no Lula 1, R$ {fbi('Bolsonaro', 'agro_subsidio_financeiro_rs_bi_2025_ano')} bi com Bolsonaro e R$ {fbi('Lula 3', 'agro_subsidio_financeiro_rs_bi_2025_ano')} bi em 2023 e 2024, e o valor de cada ano segue o juro e o calendário de pagamento, com R$ {br(fns(2015, 'agro_subsidio_financeiro'), 1)} bi correntes em 2015 depois de R$ {br(fns(2014, 'agro_subsidio_financeiro'), 1)} bi em 2014{n('osu_serie')}. A Organização Agrária, contada com as inversões, que nela são sobretudo obtenção de terras e crédito a assentados, foi de R$ {fbi('Lula 2', 'organizacao_agraria_com_inversoes_rs_bi_2025_ano')} bi por ano no Lula 2, a maior média, a R$ {fbi('Bolsonaro', 'organizacao_agraria_com_inversoes_rs_bi_2025_ano')} bi com Bolsonaro, a menor, e R$ {fbi('Lula 3', 'organizacao_agraria_com_inversoes_rs_bi_2025_ano')} bi no Lula 3. A Gestão Ambiental, sem a subfunção Recursos Hídricos, ficou entre R$ {br(min(GA_MAND.values()), 1)} bi e R$ {br(max(GA_MAND.values()), 1)} bi por ano em todos os mandatos, com o menor valor no governo Bolsonaro, também quando se somam os recursos hídricos e as inversões, e R$ {fbi('Lula 3', 'gestao_ambiental_sem_recursos_hidricos_rs_bi_2025_ano')} bi no Lula 3, abaixo de FHC, Lula 2 e Dilma.</p>
<figure>{svg('3c-funcoes-agro-ambiente')}</figure>
<p class=nota>Despesa liquidada da União, sem a modalidade intra-orçamentária. Agricultura e Gestão Ambiental sem as inversões financeiras, Organização Agrária com elas{n('siop_fun')}. R$ de 2025 pelo IPCA de dezembro a dezembro{n('ipca')}.</p>
<p>Fora da Agricultura e da Gestão Ambiental ficam as inversões financeiras, na maior parte empréstimos (Funcafé, Pronaf, Fundo Clima, refinanciamento de dívidas rurais) e também compra de estoques. Somadas nas duas funções, ficaram entre R$ {br(min(INV_ANT), 1)} bi e R$ {br(max(INV_ANT), 1)} bi por ano nos mandatos de 2000 a 2022 e subiram a R$ {fbi('Lula 3', 'inversoes_agro_ambiente_rs_bi_2025_ano')} bi por ano no Lula 3. A União liberou ao Fundo Clima R$ {br(FC24, 1)} bi em 2024 e R$ {br(FC25, 1)} bi em 2025, como empréstimo, e em 2025 financiou R$ {br(DIV25, 1)} bi para liquidar dívidas de produtores rurais atingidos por eventos climáticos, em valores correntes{n('siop_fun')}. A renúncia que o Orçamento de Subsídios chama de agricultura e agroindústria é a desoneração da cesta básica, como o próprio arquivo a rotula, e reduz o imposto sobre os alimentos da cesta{n('osu_serie')}. Por isso ela fica fora da leitura do agro. O valor adicionado da agropecuária cresceu {fbi('FHC', 'pib_agropecuaria_cresc_medio_pct_ano')}% ao ano de 2000 a 2002, {fbi('Lula 1', 'pib_agropecuaria_cresc_medio_pct_ano')}% no Lula 1, {fbi('Lula 2', 'pib_agropecuaria_cresc_medio_pct_ano')}% no Lula 2, {fbi('Dilma', 'pib_agropecuaria_cresc_medio_pct_ano')}% com Dilma, {fbi('Temer', 'pib_agropecuaria_cresc_medio_pct_ano')}% com Temer, {fbi('Bolsonaro', 'pib_agropecuaria_cresc_medio_pct_ano')}% com Bolsonaro e {fbi('Lula 3', 'pib_agropecuaria_cresc_medio_pct_ano')}% no Lula 3. A série segue a safra e o clima, com queda de {br(-AGP[2016], 1)}% em 2016 e de {br(-AGP[2024], 1)}% em 2024{n('pib_agro')}.</p>
<table><thead><tr><th></th><th class=n colspan=3>Resultado medido</th><th class=n colspan=4>Orçamento federal, R$ bi de 2025 por ano</th></tr><tr><th>Mandato</th><th class=n>Desmatamento na Amazônia, km² por ano</th><th class=n>Desmatamento no Cerrado, km² por ano</th><th class=n>PIB da agropecuária, % ao ano</th><th class=n>Agricultura, sem inversões</th><th class=n>Organização Agrária, com inversões</th><th class=n>Gestão Ambiental, sem recursos hídricos</th><th class=n>Equalizações e subvenções agrícolas (OSU)</th></tr></thead><tbody>{lin_agro}</tbody></table>
<p class=nota>Despesa e subsídios em R$ bi de 2025 por ano, média do mandato{n('siop_fun')}{n('osu_serie')}{n('ipca')}. Desmatamento pelo PRODES{n('prodes')}, PIB da agropecuária pela taxa acumulada no ano, média geométrica{n('pib_agro')}. As duas partes da tabela medem coisas diferentes. O valor liquidado de uma função mostra quanto se gastou e não mede a efetividade da política, e o desmatamento não é resultado só do orçamento. Mandato data o valor e não atribui causa. O desmatamento responde a política federal e estadual, preço de commodity, câmbio, clima e crédito, e o dado não separa esses efeitos. O ano PRODES vai de agosto a julho e conta para quem governou de janeiro a julho, então o de 2019 tem cinco meses de Temer e o de 2023, cinco meses de Bolsonaro. O Cerrado é medido a cada dois anos até 2012, e o valor do biênio foi dividido entre os dois anos. Lula 3 tem quatro anos PRODES (2023 a 2026), três de despesa (2023 a 2025) e dois de subsídios (2023 e 2024), e os subsídios do OSU começam em 2003. A média do governo Dilma na Organização Agrária inclui R$ {br(OA13, 2)} bi correntes de 2013 na subfunção Ordenamento Territorial. Os empréstimos estão em FN-funcoes-uniao.csv e FN-inversoes-acoes.csv, no pacote.</p>
"""
sec_cultura_hist = f"""<h2>Anexo T1. Cultura, por governo e na OCDE</h2>
<h3>Por governo, 2000 a 2025</h3>
<p><b>Despesa.</b> A função Cultura da União, sem o Fundo Setorial do Audiovisual, caiu de R$ {br(fnf(2014, 'Cultura'), 2)} bi em 2014 para R$ {br(fnf(2015, 'Cultura'), 2)} bi em 2015, ainda no governo Dilma, ficou perto disso com Temer, desceu a R$ {br(CU_F['Bolsonaro'], 2)} bi por ano com Bolsonaro, a menor média entre os mandatos, e foi a R$ {br(CU_F['Lula 3'], 2)} bi no Lula 3, abaixo de Temer, em reais de 2025{n('siop_fun')}. O fundo, que investe e empresta ao audiovisual e por isso é inversão financeira, ficou perto de zero de 2015 a 2022 e somou R$ {br(CU_FSA['Lula 3'], 2)} bi por ano no Lula 3. Ele fica à parte, como as inversões do agro. Fora da função ficam as transferências da cultura a estados e municípios criadas por lei do Congresso. A Lei Aldir Blanc de 2020 foi sancionada com vetos parciais e teve R$ {br(cvt(2020), 1)} bi liquidados naquele ano. A Lei Paulo Gustavo e a Política Nacional Aldir Blanc, ambas de julho de 2022, tiveram veto total do presidente e foram promulgadas depois que o Congresso derrubou os vetos. As duas mandavam a União entregar R$ 3,862 bi e R$ 3 bi por ano. Em agosto de 2022, a MP 1.135 trocou a obrigação por uma autorização com valor máximo, adiou os prazos para 2023 e 2024, fez o mesmo com o Perse, programa do setor de eventos, e depois perdeu a vigência{n('cv_atos')}. A Lei Paulo Gustavo teve R$ {br(cvt(2022, 'empenhado_rs_bi'), 3)} bi empenhados em 2022 e nada liquidado no ano. A Política Nacional Aldir Blanc teve R$ {br(cvt(2023, 'empenhado_rs_bi'), 1)} bi empenhados e R$ {br(cvt(2023), 2)} bi liquidados em 2023. Em 2024, quando a lei mandava entregar R$ 3 bi, a ação teve dotação de R$ {br(cvt(2024, 'dotacao_rs_bi'), 2)} bi, e em novembro a MP 1.274 trocou os R$ 3 bi por ano por um valor total de R$ 15 bi a partir de 2023 e depois perdeu a vigência. Em 2025, foram R$ {br(cvt(2025, 'empenhado_rs_bi'), 2)} bi empenhados e R$ {br(cvt(2025), 2)} bi liquidados{n('siop_cv')}{n('cv_atos')}.</p>
<p>O critério decide a comparação. Pelo liquidado do ano, a despesa com cultura sem o FSA foi de R$ {br(CU_TOT['Temer'], 2)} bi por ano com Temer, R$ {br(CU_TOT['Bolsonaro'], 2)} bi com Bolsonaro, mais da metade disso da Lei Aldir Blanc de 2020, e R$ {br(CU_TOT['Lula 3'], 2)} bi no Lula 3. Pelo empenho, R$ {br(CU_TOTE['Bolsonaro'], 2)} bi com Bolsonaro e R$ {br(CU_TOTE['Lula 3'], 2)} bi no Lula 3, perto uma da outra, porque a Lei Paulo Gustavo, empenhada em 2022, entra no período Bolsonaro. O pagamento dela e o saldo da Política Nacional Aldir Blanc saíram em restos a pagar, que os dados baixados não mostram.</p>
<figure>{svg('3d-cultura-despesa-e-rouanet')}</figure>
<table><thead><tr><th>Mandato</th><th class=n>Função Cultura, sem o FSA</th><th class=n>Transferências por lei, liquidado</th><th class=n>Transferências por lei, empenhado</th><th class=n>Total sem o FSA, liquidado</th><th class=n>Total sem o FSA, empenhado</th><th class=n>Fundo Setorial do Audiovisual</th><th class=n>Lei Rouanet, captado</th></tr></thead><tbody>{lin_cult}</tbody></table>
<p class=nota>R$ bi de 2025 por ano, média do mandato{n('siop_fun')}{n('siop_cv')}{n('salic')}{n('ipca')}. A série do RREO da seção 7 soma o FSA na função. A renúncia da cultura e do audiovisual está na seção 4.</p>
<p><b>Ministério e regras.</b> A MP 726, de 12 de maio de 2016, no governo Temer, extinguiu o Ministério da Cultura, e a MP 728, de 23 de maio, o recriou. No fim de 2018 havia {MIN_N['fim ']} ministérios. A MP 870, de 1º de janeiro de 2019, deixou {MIN_N['2019']}. Saíram da lista, por fusão, a Cultura, o Esporte e o Desenvolvimento Social, que foram para o Ministério da Cidadania, e também Fazenda, Planejamento, Trabalho e Cidades, entre outros. Em novembro de 2019, a cultura passou ao Ministério do Turismo. A MP 1.154, de 1º de janeiro de 2023, criou {MIN_N['2023']} ministérios, com o da Cultura{n('cv_atos')}. Nas regras da Lei Rouanet, o teto por projeto comum foi de R$ 1 milhão em abril de 2019, R$ 500 mil em fevereiro de 2022 e R$ 1 milhão em abril de 2023. O cachê por apresentação de artista solo pago com recurso incentivado foi de R$ 45 mil, R$ 3 mil e R$ 25 mil nas mesmas datas, e a regra de 2023 ficou abaixo da de 2019. Em agosto de 2019, uma portaria do Ministério da Cidadania suspendeu por 180 dias o edital do Fundo Setorial do Audiovisual para TVs públicas, para recompor o comitê gestor do fundo, e mandou revisar os critérios de seleção e os limites de valor{n('cv_atos')}. Em outubro de 2019, a 11ª Vara Federal do Rio de Janeiro suspendeu a portaria em decisão liminar, numa ação civil pública do Ministério Público Federal. A juíza viu, em análise preliminar, “descompasso entre o motivo alegado para a elaboração do ato impugnado e a realidade dos fatos”, porque o comitê gestor do fundo não avaliava os projetos do edital. A ação sustenta que a portaria foi motivada por discriminação por orientação sexual e identidade de gênero, depois de críticas do presidente a projetos selecionados no concurso. A decisão registra essa alegação sem dá-la por provada, e a decisão de mérito não foi achada. O descompasso entre motivo e edital é descrição de documento, a motivação é hipótese não estabelecida{n('jfrj_1576')}.</p>
<p><b>Fluxo da Lei Rouanet.</b> Pelo painel do Ministério da Cultura, os projetos novos foram {br(sm('projetos_novos', 2011, 2015), 0)} por ano no governo Dilma, caíram a {br(cvs(2016, 'projetos_novos'), 0)} em 2016, foram {br(sm('projetos_novos', 2017, 2018), 0)} com Temer, {br(sm('projetos_novos', 2019, 2022), 0)} com Bolsonaro, a menor média desde 2009, com {br(cvs(2021, 'projetos_novos'), 0)} em 2021, e {br(sm('projetos_novos', 2023, 2025), 0)} no Lula 3. As avaliações da Comissão Nacional de Incentivo à Cultura caem desde 2012, de {br(cvs(2011, 'cnic_projetos_avaliados'), 0)} em 2011 para {br(cvs(2015, 'cnic_projetos_avaliados'), 0)} em 2015. Tiveram {br(cvs(2018, 'cnic_projetos_avaliados'), 0)} em 2018, com Temer, média de {br(sm('cnic_projetos_avaliados', 2019, 2022), 0)} por ano com Bolsonaro e {br(sm('cnic_projetos_avaliados', 2023, 2025), 0)} no Lula 3. A admissibilidade levou {br(sm('dias_admissibilidade', 2017, 2018), 0)} dias em média com Temer, {br(sm('dias_admissibilidade', 2019, 2022), 0)} com Bolsonaro, com {br(cvs(2021, 'dias_admissibilidade'), 0)} em 2021 e {br(cvs(2022, 'dias_admissibilidade'), 0)} em 2022, e {br(sm('dias_admissibilidade', 2023, 2025), 0)} no Lula 3, e passou de 50 dias também em 2016, 2017 e 2023{n('salic_painel')}. A captação, que depende de quem patrocina, foi de R$ {br(RO['Dilma'], 2)} bi por ano no governo Dilma, R$ {br(RO['Temer'], 2)} bi com Temer, R$ {br(RO['Bolsonaro'], 2)} bi com Bolsonaro e R$ {br(RO['Lula 3'], 2)} bi no Lula 3, em reais de 2025{n('salic')}.</p>
<p><b>Temas dos projetos.</b> Entre os projetos novos, a parte com negro, negra, afro ou quilombola no nome foi de {br(pct_t('negra_quilombola', 2011, 2015), 2)}% no governo Dilma, {br(pct_t('negra_quilombola', 2017, 2018), 2)}% com Temer, {br(pct_t('negra_quilombola', 2019, 2022), 2)}% com Bolsonaro e {br(pct_t('negra_quilombola', 2023, 2025), 2)}% no Lula 3. Com indígena, {br(pct_t('indigena', 2011, 2015), 2)}%, {br(pct_t('indigena', 2017, 2018), 2)}%, {br(pct_t('indigena', 2019, 2022), 2)}% e {br(pct_t('indigena', 2023, 2025), 2)}%. Com LGBT, queer ou drag, foram {ST(2011, 2015, 'projetos_lgbt'):.0f} projetos no governo Dilma, {ST(2016, 2018, 'projetos_lgbt'):.0f} de 2016 a 2018, {ST(2019, 2022, 'projetos_lgbt'):.0f} com Bolsonaro e {ST(2023, 2025, 'projetos_lgbt'):.0f} no Lula 3. Até 2022 a parte fica entre 0,01% e 0,05% em todos os mandatos, e com números tão pequenos a diferença entre eles não se distingue do acaso. Nos temas negro e indígena, 90% ou mais dos projetos tiveram valor aprovado em todos os mandatos, e os de 2019 a 2022 captaram em proporção maior que os do governo Dilma e os do Lula 3, que ainda captam ({br(cap_t('negra_quilombola', 2019, 2022), 0)}% dos de tema negro, contra {br(cap_t('negra_quilombola', 2011, 2015), 0)}% e {br(cap_t('negra_quilombola', 2023, 2025), 0)}%). O dado mostra queda dos temas negro e indígena desde 2016, sem queda própria de 2019 a 2022, e uma alta forte no Lula 3. Dois controles ajudam a ler a alta. A parte com gospel no nome ficou entre {br(min(pct_t('gospel_controle', i, f) for _, i, f in MS[1:]), 2)}% e {br(max(pct_t('gospel_controle', i, f) for _, i, f in MS[1:]), 2)}%, e a com orquestra foi de {br(pct_t('orquestra_controle', 2011, 2015), 2)}% no governo Dilma, {br(pct_t('orquestra_controle', 2019, 2022), 2)}% com Bolsonaro e {br(pct_t('orquestra_controle', 2023, 2025), 2)}% no Lula 3, então a alta dos três temas no Lula 3 não é só de volume{n('salic_painel')}. Uma leitura manual conferiu a busca. Numa amostra de {sum(int(r['amostra_lida']) for r in CVTA)} títulos, até 12 por tema e governo, os falsos positivos claros foram {sum(int(r['amostra_nao']) for r in CVTA)}, quase todos nome de lugar ou cores de clube, e viraram filtro. Sinônimos que o radical não pega, como candomblé, terreiro, orixá, preta, aldeia, guarani, povos originários e gay, somam projetos em todos os governos, mais no tema indígena, e não mudam a ordem. Com eles, o tema negro fica entre {fxa('negra_quilombola', 'Temer')} dos projetos novos de 2016 a 2018, entre {fxa('negra_quilombola', 'Bolsonaro')} com Bolsonaro e entre {fxa('negra_quilombola', 'Lula 3')} no Lula 3. O indígena fica entre {fxa('indigena', 'Temer')} de 2016 a 2018, entre {fxa('indigena', 'Bolsonaro')} com Bolsonaro e entre {fxa('indigena', 'Lula 3')} no Lula 3. A lista de sinônimos não é completa, e o número verdadeiro pode ser maior em todos os governos (CV-temas-auditoria.csv). Decolonial aparece em {ST(2009, 2025, 'projetos_decolonial'):.0f} projetos, todos de 2023 a 2025, e não permite comparar mandatos. A busca olha só o nome do projeto e não mede o que não chegou a virar projeto nem a razão de nenhuma decisão. O valor captado pelos projetos dos três temas, contado uma vez por projeto, pelo ano do projeto e em reais correntes, foi no máximo de R$ {br(max(float(CVS[a]['captado_tres_temas_sem_dupla_rs_mi']) for a in range(2009, 2026)), 1)} mi por ano, e os projetos de 2024 e 2025 ainda captam.</p>
<figure>{svg('3e-rouanet-fluxo-e-temas')}</figure>
<table><thead><tr><th>Mandato</th><th class=n>Projetos novos por ano</th><th class=n>Avaliados pela CNIC por ano</th><th class=n>Dias de admissibilidade</th><th class=n>% LGBT, queer, drag</th><th class=n>% negro, negra, afro, quilombola</th><th class=n>% indígena</th><th class=n>% gospel (controle)</th><th class=n>% orquestra (controle)</th></tr></thead><tbody>{lin_salic}</tbody></table>
<p class=nota>Painel Salic Comparar do Ministério da Cultura, relatórios de propostas transformadas em projeto, projetos avaliados pela CNIC (desde 2011) e tempo médio, e busca na lista de projetos do incentivo fiscal federal pelo nome do projeto, com o ano dado pelos dois primeiros dígitos do Pronac{n('salic_painel')}. Os filtros tiram os falsos positivos mais comuns da busca por radical, como Dragão, Rio Negro, Cisne Negro, Ouro Negro e Afrodite, e restam casos ambíguos, como Pérola Negra. A coluna de proponente não é guardada no pacote.</p>
<figure>{svg('3f-atencao-busca')}</figure>
<p><b>Atenção pública.</b> Busca no Google não é opinião, e o índice do Trends é relativo e amostral, mas ele mostra onde o assunto aparece. Num mesmo pedido de cinco termos, de 2011 a 2025, a busca por Lei Rouanet teve média de {br(tr_m('trends_lei_rouanet', 2011, 2025), 1)} no índice, contra {br(tr_m('trends_zona_franca_de_manaus', 2011, 2025), 1)} para Zona Franca de Manaus, {br(tr_m('trends_fundo_eleitoral', 2011, 2025), 1)} para Fundo Eleitoral, {br(tr_m('trends_plano_safra', 2011, 2025), 1)} para Plano Safra e {br(tr_m('trends_fundo_partidário', 2011, 2025), 1)} para Fundo Partidário. O maior valor anual da Lei Rouanet foi em {TR_PICO}, ano de eleição presidencial ({br(float(CVA[2018]['trends_lei_rouanet']), 1)}), seguido de 2016 ({br(float(CVA[2016]['trends_lei_rouanet']), 1)}), 2022 e 2023 ({br(float(CVA[2022]['trends_lei_rouanet']), 1)} nos dois), e a atenção não se concentra num governo{n('trends')}. Na Câmara, as proposições que citam a Lei Rouanet foram {br(cam_m('camara_rouanet', 2004, 2018), 1)} por ano de 2004 a 2018, {br(cam_m('camara_rouanet', 2019, 2022), 1)} com Bolsonaro e {br(cam_m('camara_rouanet', 2023, 2025), 1)} no Lula 3. As que citam a Zona Franca foram {br(cam_m('camara_zona_franca', 2004, 2018), 1)}, {br(cam_m('camara_zona_franca', 2019, 2022), 1)} e {br(cam_m('camara_zona_franca', 2023, 2025), 1)}, e as do Plano Safra, {br(cam_m('camara_plano_safra', 2004, 2018), 1)}, {br(cam_m('camara_plano_safra', 2019, 2022), 1)} e {br(cam_m('camara_plano_safra', 2023, 2025), 1)}{n('camara')}. A renúncia da Lei Rouanet prevista para 2026 é de R$ {br(cur('renuncia_lei_rouanet'), 2)} bi, a da Zona Franca, de R$ {br(ZFM26, 1)} bi{n('dgt')}, e as equalizações e subvenções agrícolas custaram R$ {br(fns(2024, 'agro_subsidio_financeiro'), 1)} bi em 2024{n('osu_serie')}.</p>
<p class=nota>Google Trends, Brasil, de janeiro de 2004 a setembro de 2026, cinco termos no mesmo pedido, média anual do índice mensal. A média de 2004 a 2010 da Zona Franca é mais alta, com amostra menor nos primeiros anos{n('trends')}. Câmara dos Deputados, proposições por ano de apresentação com o termo na ementa ou na indexação{n('camara')}.</p>"""
sec_receita = f"""<h2>4. Receita, carga tributária e rigidez da despesa</h2>
<p>A carga tributária bruta foi de {br(cr[ult_cr], 1)}% do PIB em {ult_cr} pela Receita, o maior valor da série recalculada, e de {br(ct[ult_ct], 1)}% em {ult_ct} pela estimativa do Tesouro. Na base comparável da OCDE, o Brasil tem {br(br_oc, 1)}% ({LI['Brasil (OCDE/RS LAC)']['ano']}), perto da média da OCDE ({br(oc_m, 1)}%) e bem acima da média da América Latina ({br(alc_m, 1)}%){n('ocde')}. O gasto tributário passou de {br(gte[min(gte)], 1)}% do PIB em {min(gte)} para {br(gte[ult_gt], 1)}% em {ult_gt}{n('dgt')}.</p>
<table><thead><tr><th>Governo, média dos anos</th><th class=n>Receita líquida GC</th><th class=n>Carga, Receita</th><th class=n>Carga, Tesouro</th><th class=n>Gasto tributário</th><th class=n>Obrigatória, % da despesa</th></tr></thead><tbody>{linhas_rec}</tbody></table>
<p class=nota>% do PIB, exceto a última coluna. Médias só dos anos com dado. Carga da Receita desde 2002, do Tesouro desde 2010, gasto tributário de bases efetivas de 2008 a {ult_gt}, despesa obrigatória desde 2008.</p>
<figure>{svg('8-receita-carga')}</figure>
<p class=nota>Carga tributária bruta do governo geral pela Receita Federal (metodologia de 2024, sem FGTS e Sistema S, série recalculada desde 2002){n('rfb')} e pela estimativa do Tesouro (desde 2010){n('tcarga')}. Receita líquida do Governo Central e despesa obrigatória{n('rtn')}. Gasto tributário (renúncias federais) pelas bases efetivas, e em tracejado a projeção do PLOA{n('dgt')}.</p>
<table><thead><tr><th>Carga tributária, governo geral</th><th class=n>Ano</th><th class=n>% do PIB</th></tr></thead><tbody>{linhas_ci}</tbody></table>
<p class=nota>OCDE, Revenue Statistics e Revenue Statistics in Latin America and the Caribbean{n('ocde')}. O número da OCDE para o Brasil ainda segue a metodologia anterior da Receita.</p>
{sec_ren}
{sec_emendas}"""

sec_recorrente = f"""<h2>5. Primário cheio, recorrente e estrutural</h2>
<figure>{svg('9-primario-recorrente')}</figure>
<table><thead><tr><th>Governo</th><th class=n>Primário cheio</th><th class=n>Recorrente</th><th class=n>Diferença</th><th class=n>Estrutural (SPE)</th></tr></thead><tbody>{linhas_k}</tbody></table>
<p class=nota>Governo Central, % do PIB, média simples dos anos, positivo é superávit{n('rtn')}. Recorrente. O cheio menos as receitas não recorrentes e mais as despesas não recorrentes listadas pela Secretaria de Política Econômica{n('spe')}. Estrutural. SPE, % do PIB potencial, só nos anos indicados. 2025 é estimativa parcial com as linhas do RTN, porque a SPE publicou só o primeiro semestre. Dividendos extraordinários de 2025 entram como zero.</p>
<p>Tirados os eventos não recorrentes, a média de Bolsonaro passa de {br(float(km['Bolsonaro']['primario_cheio_media_pct_pib']), 2)}% para {br(float(km['Bolsonaro']['primario_recorrente_media_pct_pib']), 2)}% do PIB (em 2020, de {br(float(k20['primario_cheio_pct_pib']), 1)}% para {br(float(k20['primario_recorrente_pct_pib']), 1)}%). A de Lula 2 passa de {br(float(km['Lula 2']['primario_cheio_media_pct_pib']), 2)}% para {br(float(km['Lula 2']['primario_recorrente_media_pct_pib']), 2)}%, sem a receita da cessão onerosa de 2010. A de Lula 3 fica em {br(float(km['Lula 3']['primario_recorrente_media_pct_pib']), 2)}%. A lista da SPE inclui itens menores todo ano (desoneração da folha, receitas atípicas), e o arquivo K-primario-recorrente.csv traz cada item em coluna própria{n('spe')}.</p>
<p><b>A ordem entre governos depende da medida.</b> Nos mesmos anos, as três medidas não apontam para o mesmo lado. O estrutural da SPE desconta, além dos eventos não recorrentes, o efeito do ciclo econômico e dos preços do petróleo e do minério de ferro, e é medido sobre o PIB potencial. O recorrente desconta só a lista de eventos{n('spe')}.</p>
<table><thead><tr><th>Mesmos anos, % do PIB</th><th class=n>Cheio</th><th class=n>Recorrente</th><th class=n>Estrutural (SPE)</th></tr></thead><tbody>{linhas_jan}</tbody></table>
<p class=nota>Médias simples dos anos indicados{n('rtn')}{n('spe')}. Estrutural só onde a SPE publicou o ano (2018 a 2024). 2025 é estimativa parcial, sem estrutural.</p>
<p>Em 2019-22 e 2023-24, o cheio favorece Lula 3 ({f2(l3_j[0])}% contra {f2(bo_j[0])}%), o recorrente empata ({f2(l3_j[1])}% e {f2(bo_j[1])}%) e o estrutural favorece Bolsonaro ({f2(bo_j[2])}% contra {f2(l3_j[2])}%). A diferença no recorrente entre as médias dos mandatos inteiros vem de 2025, ano estimado. Nenhuma das três medidas, sozinha, ordena os dois governos.</p>"""


MO = [('Lula 2 (2008-10)', 2008, 2010), ('Dilma (2011-15)', 2011, 2015), ('2016 (Dilma/Temer)', 2016, 2016), ('Temer (2017-18)', 2017, 2018), ('Bolsonaro (2019-22)', 2019, 2022), ('Lula 3 (2023-25)', 2023, 2025)]
mo = lambda f, a0, a1: sum(f(a) for a in range(a0, a1 + 1)) / (a1 - a0 + 1)
od = lambda c: (lambda a: float(OD[a][c])); oi = lambda k, c: (lambda a: float(OI[k][a][c]))
linhas_o = ''.join(f"<tr><td>{nm}</td><td class=n>{br(mo(od('custo_medio_total_pct'), a0, a1), 1)}</td><td class=n>{br(mo(od('ipca_pct'), a0, a1), 1)}</td><td class=n>{br(mo(od('juro_real_fisher_pct'), a0, a1), 1)}</td>"
                   + ''.join(f"<td class=n>{br(mo(oi(k, 'contribuicao_pp'), a0, a1), 1)}</td>" for k, _, _ in IDX)
                   + f"<td class=n>{br(mo(oi('selic_flutuante', 'pct_estoque_dez'), a0, a1), 0)}%</td></tr>" for nm, a0, a1 in MO)
lfts = {a: float(OI['selic_flutuante'][a]['pct_estoque_dez']) for a in xo_}
lft_min = min(lfts, key=lfts.get)
neg_real = [a for a in xo_ if float(OD[a]['juro_real_fisher_pct']) < 0]
sec_custo = f"""<p><b>De que é feita a taxa.</b> O custo médio da dívida federal em 12 meses se divide em inflação e juro real, e também pelo que indexa cada título{n('rmd')}{n('ipca')}.</p>
<figure>{svg('10b-custo-indexador')}</figure>
<table style="break-inside:avoid"><thead><tr><th>Média dos anos, % e pontos</th><th class=n>Custo</th><th class=n>IPCA</th><th class=n>Juro real</th><th class=n>Prefixado</th><th class=n>Selic</th><th class=n>Preços</th><th class=n>Câmbio</th><th class=n>Selic, % do estoque</th></tr></thead><tbody>{linhas_o}</tbody></table>
<p class=nota>Custo médio acumulado em 12 meses da dívida pública federal em dezembro, por título, e composição por indexador, Relatório Mensal da Dívida de ago/2026, anexos 2.1, 2.4 e 4.2{n('rmd')}. Juro real pela fórmula de Fisher com o IPCA do ano{n('ipca')}. O custo de cada indexador é a média dos títulos ponderada pelo estoque (conta deste relatório, o Tesouro publica por título) e a contribuição é a participação média no estoque vezes esse custo. As quatro contribuições somam o custo total com diferença de até 0,4 ponto. Câmbio inclui a dívida externa em reais, com a variação cambial. Lula 2 desde 2008. Selic média. BCB, série 4189, lida na cópia do Internet Archive porque a API recusou a consulta.</p>
<p>O juro real da dívida ficou acima de 3,5% ao ano em todos os anos, menos {', '.join(map(str, neg_real))}, quando o IPCA passou o custo. A parte que segue a Selic foi de {br(lfts[lft_min], 0)}% do estoque em {lft_min} para {br(lfts[2025], 0)}% em 2025, e a contribuição da Selic ao custo subiu de {br(mo(oi('selic_flutuante', 'contribuicao_pp'), 2019, 2022), 1)} pontos por ano no governo Bolsonaro para {br(mo(oi('selic_flutuante', 'contribuicao_pp'), 2023, 2025), 1)} no Lula 3. Com metade da dívida na Selic, a decisão do Copom passa ao custo da dívida em poucos meses.</p>"""

g24, gs24 = pv('gini_rdpc', 'Brasil', 2024), pv('gini_rdpc_sem_programas_sociais', 'Brasil', 2024)
g12, gs12 = pv('gini_rdpc', 'Brasil', 2012), pv('gini_rdpc_sem_programas_sociais', 'Brasil', 2012)
g20, gs20 = pv('gini_rdpc', 'Brasil', 2020), pv('gini_rdpc_sem_programas_sociais', 'Brasil', 2020)
pe24, pes24 = pv('pobreza_us2_15_ppc2017', 'Brasil', 2024), pv('pobreza_us2_15_ppc2017_sem_programas_sociais', 'Brasil', 2024)
top = lambda se: pv(se, 'publicada: mais de 320', 2024)
t160 = lambda se: pv(se, 'harmonizada: mais de 160', 2024)
ali = lambda f, a: pv('aliquota_efetiva_sobre_rendimento_total', 'harmonizada: ' + f, a)
linhas_ali = ''.join(f"<tr><td>{f.replace('ate', 'até')} SM</td>" + ''.join(f"<td class=n>{br(ali(f, a), 1)}</td>" for a in (2010, 2014, 2018, 2022, 2024)) + '</tr>' for f in ('3 a 5', '10 a 20', '20 a 40', '40 a 80', 'mais de 160'))
linhas_ali += "<tr class=t><td>Total</td>" + ''.join(f"<td class=n>{br(pv('aliquota_efetiva_sobre_rendimento_total', 'Total', a), 1)}</td>" for a in (2010, 2014, 2018, 2022, 2024)) + '</tr>'
pr = lambda se, rc, a: pv(se, rc, a)
PREV = [('INSS (RGPS), benefício médio, dez/2025', pr('valor_medio_beneficio_dez', 'RGPS (INSS)', 2025), 'beps'),
        ('BPC e RMV, benefício médio, dez/2025', pr('valor_medio_beneficio_dez', 'Assistencial (BPC/LOAS e RMV)', 2025), 'beps'),
        ('Aposentado civil da União, provento médio, 2024', pr('provento_medio_rpps_civil_uniao', 'aposentados: todos os poderes', 2024), 'aeps'),
        ('   Executivo', pr('provento_medio_rpps_civil_uniao', 'aposentados: executivo', 2024), 'aeps'),
        ('   Judiciário', pr('provento_medio_rpps_civil_uniao', 'aposentados: judiciário', 2024), 'aeps'),
        ('   Ministério Público', pr('provento_medio_rpps_civil_uniao', 'aposentados: ministério público', 2024), 'aeps'),
        ('   Legislativo', pr('provento_medio_rpps_civil_uniao', 'aposentados: legislativo', 2024), 'aeps'),
        ('Pensionista civil da União, valor médio, 2024', pr('provento_medio_rpps_civil_uniao', 'pensionistas: todos os poderes', 2024), 'aeps')]
mil = [r for k, r in PD.items() if k[0] == 'provento_medio_militares']
ROT_MIL = {'inativos: todos': 'Militar inativo, provento médio, mai/2025', 'inativos: oficiais': '   oficiais', 'inativos: pracas': '   praças',
           'pensionistas: todos': 'Pensionista militar, valor médio por pessoa, mai/2025', 'pensionistas: de oficiais': '   de oficiais', 'pensionistas: de pracas': '   de praças'}
mil_d = {r['recorte']: float(r['valor']) for r in mil}
PREV += [(ROT_MIL[k], mil_d[k], 'pldo') for k in ROT_MIL]
linhas_prev = ''.join(f"<tr><td>{a.replace('   ', '&emsp;')}</td><td class=n>{br(v, 0)}</td><td class=n>{br(v / PREV[0][1], 1)}x</td><td class=n>{n(k)}</td></tr>" for a, v, k in PREV)
CBP = {(r['recorte'].split(' ')[0], r['ano']): float(r['valor']) for r in le('P-carga-por-base.csv') if r['serie'] == 'rfb_receita_por_base' and r['unidade'] == '% da receita tributaria total' and r['valor']}
cb = lambda cod, a: CBP[(cod, str(a))]
BASES = [('Bens e serviços', '4000'), ('Renda', '1000'), ('   da qual pessoa física', '1100'), ('Folha de salários', '2000'), ('Propriedade', '3000'), ('Transações financeiras', '5000')]
AC = (2002, 2010, 2014, 2018, 2022, 2024)
linhas_cb = ''.join(f"<tr><td>{nm.replace('   ', '&emsp;')}</td>" + ''.join(f"<td class=n>{br(cb(c, a), 1)}</td>" for a in AC) + '</tr>' for nm, c in BASES)
PIP = {(float(r['linha_us_dia_ppc2021']), int(r['ano'])): float(r['pobreza_pct']) for r in le('P-pobreza-banco-mundial-ppc2021.csv')}
pip = lambda l, a: PIP[(float(l), a)]
# 12, renda e poder de compra por faixa (frente PC)
POF = {(r['classe_de_rendimento_familiar'], r['tipo_de_despesa']): float(r['pct_da_despesa_total']) for r in le('PC-pof-orcamento.csv')}
POF_C = [('Até 1.908 Reais', 'Até R$ 1.908'), ('Total', 'Todas as famílias'), ('Mais de 23.850 Reais', 'Mais de R$ 23.850')]
POF_T = [('2.1.1 Alimentação', 'Alimentação'), ('2.1.2 Habitação', 'Habitação'), ('2.1.4 Transporte', 'Transporte'), ('2.1.6 Assistência à saude', 'Saúde'), ('2.1.7 Educação', 'Educação'), ('2.1.8 Recreação e cultura', 'Recreação e cultura'), ('2.1 Despesas de consumo', 'Todo o consumo')]
linhas_pof = ''.join(f"<tr><td>{nm}</td>" + ''.join(f"<td class=n>{br(POF[(c, k)], 1)}</td>" for c, _ in POF_C) + '</tr>' for k, nm in POF_T)
pm = lambda p, ind: PMD[(p, ind)]
sn = lambda x, d=1: ('+' if x > 0 else '') + br(x, d)
MAND_PC = [('FHC', 'FHC'), ('Lula 1 e 2', 'Lula 1 e 2'), ('Dilma', 'Dilma'), ('Temer', 'Temer'), ('Bolsonaro', 'Bolsonaro'), ('Lula 3', 'Lula 3')]
def cel_pc(p, ind, d=1, var=True):
  if (p, ind) not in PMD: return 'n/d'
  v = sn(PMD[(p, ind)], d) if var else br(PMD[(p, ind)], d)
  alt = (p, ind + ' (aba de 12 meses)')
  return v + (f' a {br(PMD[alt], d)}' if alt in PMD else '')
IND_PC = [('IPCA, média ao ano, %', 'IPCA medio ao ano', 1, False), ('Salário mínimo real, variação no mandato, %', 'salario minimo real, variacao', 1, True),
          ('Cesta de São Paulo, horas de trabalho com salário mínimo, média do mandato', 'cesta basica de Sao Paulo, horas de trabalho com salario minimo, media do periodo', 0, False),
          ('Inflação Ipea, renda muito baixa, % ao ano', 'inflacao Ipea, renda muito baixa, media ao ano', 1, False), ('Inflação Ipea, renda alta, % ao ano', 'inflacao Ipea, renda alta, media ao ano', 1, False),
          ('Renda média real do trabalho, variação, %', 'renda media real do trabalho, variacao', 1, True),
          ('Renda domiciliar por pessoa, 40% mais pobres, variação, %', 'renda domiciliar per capita real, 40% mais pobres, variacao', 1, True),
          ('Renda domiciliar por pessoa, média, variação, %', 'renda domiciliar per capita real, media, variacao', 1, True),
          ('Renda domiciliar por pessoa, 10% mais ricos, variação, %', 'renda domiciliar per capita real, 10% mais ricos, variacao', 1, True)]
linhas_pc = ''.join(f"<tr><td>{nm}</td>" + ''.join(f"<td class=n>{cel_pc(p, ind, d, var)}</td>" for p, _ in MAND_PC) + '</tr>' for nm, ind, d, var in IND_PC)
PER_D = [('Dilma', '2012 a 2015'), ('Temer', '2015 a 2018'), ('Bolsonaro', '2018 a 2022'), ('Lula 3', f'2022 a {PCR["ult_dom"]}')]
d40 = lambda p: pm(p, 'renda domiciliar per capita real, 40% mais pobres, variacao'); d90 = lambda p: pm(p, 'renda domiciliar per capita real, 10% mais ricos, variacao')
n_acima = sum(1 for p, _ in PER_D if d40(p) > d90(p))
ifr = lambda p, fx: pm(p, f'inflacao Ipea, renda {fx}, media ao ano')
ifr_alt = lambda p: PMD.get((p, 'inflacao Ipea, renda alta, media ao ano (aba de 12 meses)'), ifr(p, 'alta'))
MI_ = [p for p, _ in MI]
pobres_mais = [r for p, r in MI if ifr(p, 'muito baixa') > max(ifr(p, 'alta'), ifr_alt(p))]
pobres_menos = [r for p, r in MI if ifr(p, 'muito baixa') < min(ifr(p, 'alta'), ifr_alt(p))]
lista = lambda xs: ', '.join(xs[:-1]) + ' e ' + xs[-1] if len(xs) > 1 else xs[0]
csv_ = lambda a: next(float(r['horas_de_trabalho_media']) for r in PCS if r['ano'] == str(a))
smr = lambda p: pm(p, 'salario minimo real, variacao')
sec_pc = f"""<p><b>Renda e poder de compra por faixa.</b> As contas públicas mostram quanto o governo arrecada e gasta. Como cada família sentiu a economia depende da sua renda e dos preços que ela paga. A mesma inflação pesa de modo diferente em cada orçamento. Na POF 2017-2018, as famílias com renda de até R$ 1.908 por mês destinavam {br(POF[('Até 1.908 Reais', '2.1.1 Alimentação')], 1)}% da despesa total à alimentação e {br(POF[('Até 1.908 Reais', '2.1.2 Habitação')], 1)}% à habitação. Nas famílias com mais de R$ 23.850 por mês, as parcelas eram {br(POF[('Mais de 23.850 Reais', '2.1.1 Alimentação')], 1)}% e {br(POF[('Mais de 23.850 Reais', '2.1.2 Habitação')], 1)}%{n('pof')}.</p>
<table style="break-inside:avoid"><thead><tr><th>Parcela da despesa total da família, %, POF 2017-2018</th>{''.join(f'<th class=n>{r}</th>' for _, r in POF_C)}</tr></thead><tbody>{linhas_pof}</tbody></table>
<p class=nota>IBGE, POF 2017-2018, classes pela renda total e variação patrimonial mensal da família{n('pof')}. A despesa total inclui também impostos, contribuições, serviços bancários, compra e reforma de imóvel e pagamento de dívidas, por isso o consumo não chega a 100%. Habitação inclui o aluguel monetário e o não monetário, energia, água, gás e telefone.</p>
<figure>{svg('12e-poder-de-compra')}</figure>
<p class=nota>Salário mínimo vigente em cada mês, do Ministério do Trabalho, compilado pelo Ipea{n('salmin')}, com o valor de 2026 conferido no decreto{n('d12797')}, corrigido pelo INPC{n('inpc')}. Horas de trabalho é a conta do DIEESE, o preço da cesta dividido pelo salário mínimo por hora numa jornada de 220 horas por mês. Só São Paulo, a série mais longa da pesquisa{n('dieese')}. Renda do trabalho é o rendimento habitual de todos os trabalhos das pessoas ocupadas, em trimestres móveis, a série começa em 2012{n('pnad_trab')}. A média conta só quem está ocupado, e por isso pode subir quando muita gente perde o trabalho, como em 2020. A renda domiciliar por pessoa inclui aposentadorias, pensões e programas sociais, a preços médios de {PCR['ult_dom']}. Os 40% mais pobres são a média das quatro classes de 10% das pessoas até o percentil 40, que têm o mesmo número de pessoas{n('pnad_dom')}. De 2020 a 2022, o Auxílio Emergencial e o Auxílio Brasil mudaram sobretudo a renda dos mais pobres.</p>
<p>O salário mínimo real subiu {br(smr('FHC'), 0)}% no governo FHC e {br(smr('Lula 1 e 2'), 0)}% nos dois primeiros mandatos de Lula. Subiu {br(smr('Dilma'), 1)}% com Dilma, ficou estável com Temer ({sn(smr('Temer'))}%) e com Bolsonaro ({sn(smr('Bolsonaro'))}%) e subiu {br(smr('Lula 3'), 1)}% no Lula 3 até {PCR['ult_preco']}{n('salmin')}{n('inpc')}. As horas de trabalho com salário mínimo para comprar a cesta de São Paulo caíram de {br(csv_(1995), 0)} em 1995 para {br(csv_(2017), 0)} em 2017, subiram a {br(csv_(2022), 0)} em 2022, com a alta dos alimentos, e estão em {br(csv_(int(PCR['ult_preco'][3:])), 0)} em {PCR['ult_preco'][3:]}{n('dieese')}.</p>
<p>A renda domiciliar por pessoa dos 40% mais pobres variou {sn(d40('Dilma'))}% de 2012 a 2015, {sn(d40('Temer'))}% de 2015 a 2018, {sn(d40('Bolsonaro'))}% de 2018 a 2022 e {sn(d40('Lula 3'))}% de 2022 a {PCR['ult_dom']}, já descontada a inflação. A dos 10% mais ricos variou {sn(d90('Dilma'))}%, {sn(d90('Temer'))}%, {sn(d90('Bolsonaro'))}% e {sn(d90('Lula 3'))}% nos mesmos períodos. Os mais pobres ganharam mais que os mais ricos em {['nenhum', 'um', 'dois', 'três', 'quatro'][n_acima]} dos quatro períodos{n('pnad_dom')}. Em {PCR['ult_dom']}, a renda média por pessoa era de R$ {br(PRDv[(PCR['ult_dom'], 'Até o P10')], 0)} por mês entre os 10% mais pobres e de R$ {br(PRDv[(PCR['ult_dom'], 'Maior que o P90')], 0)} entre os 10% mais ricos.</p>
<figure>{svg('12f-inflacao-por-faixa')}</figure>
<p class=nota>Ipea, Indicador de Inflação por Faixa de Renda, com faixas pela renda domiciliar mensal em reais de janeiro de 2026{n('ipea_ifr')}. O indicador começa em julho de 2006, por isso a barra de Lula cobre só o segundo mandato, de 2007 a 2010. Na faixa de renda alta, de 2007 a 2012, a aba de 12 meses da própria planilha do Ipea diverge da aba mensal. O gráfico usa a mensal. Pela aba de 12 meses, a renda alta fica em {br(ifr_alt('Lula 1 e 2'), 1)}% ao ano no Lula 2 e {br(ifr_alt('Dilma'), 1)}% com Dilma. Lula 3 vai até {PCR['ult_ifr']}.</p>
<p>A inflação das famílias de renda muito baixa ficou acima da inflação das de renda alta em {lista(pobres_mais)} e abaixo em {lista(pobres_menos)}{n('ipea_ifr')}. Na nota de agosto de 2026, o Ipea explica a deflação maior da faixa de renda muito baixa pela queda da energia elétrica e dos alimentos no domicílio, itens que pesam mais na cesta dessas famílias{n('ipea_ifr')}.</p>
<table style="break-inside:avoid"><thead><tr><th>Por mandato</th>{''.join(f'<th class=n>{r}</th>' for _, r in MAND_PC)}</tr></thead><tbody>{linhas_pc}</tbody></table>
<p class=nota>Mandatos por mês, com Dilma até abril de 2016 e Temer a partir de maio de 2016. A renda domiciliar é anual, e o período de 2015 a 2018 fica com Temer, incluindo 2016, o ano da troca. Lula 3 vai até o último dado de cada série ({PCR['ult_preco']} nos preços e no salário mínimo, {PCR['ult_trab']} na renda do trabalho e {PCR['ult_dom']} na renda domiciliar). Na renda alta do Ipea, o intervalo mostra a aba mensal e a de 12 meses. Os números medem quanto cada faixa ganhou ou perdeu em cada período. Eles não separam o efeito da política de cada governo do efeito dos preços externos, da pandemia e do ciclo econômico{n('ipca')}{n('salmin')}{n('dieese')}{n('ipea_ifr')}{n('pnad_trab')}{n('pnad_dom')}.</p>"""
sec_dist = f"""<h2>Anexo T3. Quem paga e quem recebe</h2>
<figure>{svg('12a-desigualdade')}</figure>
<p class=nota>IBGE, Síntese de Indicadores Sociais 2025, PNAD Contínua{n('sis')}. "Sem programas sociais" é a mesma renda declarada, tirados os valores de programas sociais. A conta não simula o que as famílias fariam sem eles. 2020 e 2021 usam a quinta visita da PNAD, os outros anos a primeira. Linhas de pobreza em dólar PPC de 2017, as que o IBGE publica. Em junho de 2025 o Banco Mundial trocou a linha de extrema pobreza de US$ 2,15 (PPC 2017) por US$ 3,00 (PPC 2021) e atualizou a de países de renda média-alta, como o Brasil, de US$ 6,85 para US$ 8,30{n('pip')}. A linha nova é maior em dólar, mas o fator PPC de 2021 também mudou, por isso a taxa pode cair. Nas linhas novas, o Brasil teve {br(pip(3, 2024), 1)}% de extrema pobreza e {br(pip(8.3, 2024), 1)}% de pobreza em 2024, contra {br(pip(3, 2019), 1)}% e {br(pip(8.3, 2019), 1)}% em 2019. O Banco Mundial não publica a conta sem programas sociais.</p>
<p>Em 2024 (Lula 3) o Gini foi {br(g24, 3)} e seria {br(gs24, 3)} sem os programas sociais. Em 2012 a distância era {br(gs12 - g12, 3)} e em 2024, {br(gs24 - g24, 3)}. Em 2020, com o Auxílio Emergencial, a distância chegou a {br(gs20 - g20, 3)}. A extrema pobreza (US$ 2,15 por dia) foi de {br(pe24, 1)}% em 2024 e seria {br(pes24, 1)}% sem os programas{n('sis')}. É o efeito contábil da renda transferida, sem estimativa causal.</p>
{sec_pc}
<figure>{svg('12b-irpf')}</figure>
<table style="break-inside:avoid"><thead><tr><th>Alíquota efetiva do IRPF, % do rendimento total</th><th class=n>2010 (Lula 2)</th><th class=n>2014 (Dilma)</th><th class=n>2018 (Temer)</th><th class=n>2022 (Bolsonaro)</th><th class=n>2024 (Lula 3)</th></tr></thead><tbody>{linhas_ali}</tbody></table>
<p class=nota>Receita Federal, Grandes Números do IRPF, ano-calendário{n('irpf')}. Alíquota efetiva. Imposto devido na declaração dividido pelo rendimento total (tributável, exclusivo e isento). Faixas em salários mínimos de cada ano. Não inclui o imposto retido em definitivo na fonte (13º, aplicações, PLR), nem o IRPJ e a CSLL pagos pela empresa antes de distribuir lucros, então não mede a carga total sobre cada faixa. Entre 2020 e 2022 o número de declarantes passou de 31,6 para 40,6 milhões.</p>
<p>O imposto da declaração sobe com a renda até a faixa de 10 a 40 salários mínimos e cai acima dela, porque a parte isenta do rendimento cresce. Ela é {br(pv('pct_isento_no_rendimento_total', 'harmonizada: 3 a 5', 2024), 0)}% na faixa de 3 a 5 salários mínimos e {br(t160('pct_isento_no_rendimento_total'), 0)}% acima de 160. Em 2024, os {br(top('declarantes'), 0)} declarantes acima de 320 salários mínimos ({br(top('pct_dos_declarantes'), 2)}% do total) tiveram {br(top('pct_do_rendimento_total'), 1)}% do rendimento declarado, {br(top('pct_isento_no_rendimento_total'), 1)}% dele isento, e alíquota efetiva de {br(top('aliquota_efetiva_sobre_rendimento_total'), 1)}%{n('irpf')}.</p>
<p><b>Todos os tributos, por renda.</b> A única base que soma consumo, renda e patrimônio na mesma população é a POF 2017-2018. Nela, as famílias do décimo mais pobre pagaram {br(tv('pof_tributos_total_pct_renda_total', 'decimo 1'), 1)}% da renda total em tributos, {br(tv('pof_tributos_indiretos_pct_renda_total', 'decimo 1'), 1)} pontos em consumo. As do décimo mais rico, {br(tv('pof_tributos_total_pct_renda_total', 'decimo 10'), 1)}%, com {br(tv('pof_tributos_diretos_pct_renda_total', 'decimo 10'), 1)} pontos de tributos diretos{n('ipea_td')}. A carga cai do 1º ao 6º décimo e fica perto de 18% a 20% daí para cima.</p>
<figure>{svg('12c-incidencia')}</figure>
<p class=nota>Ipea, TD 2823, com a POF 2017-2018 do IBGE{n('ipea_td')}, fonte oficial secundária. Tributos indiretos supostos pagos todos pelo consumidor. Não inclui IRPJ, CSLL nem a contribuição patronal. Sobre a renda monetária, sem a renda não monetária, os indiretos do 1º décimo passam de {br(tv('pof_tributos_indiretos_pct_renda_total', 'decimo 1'), 1)}% para {br(next(float(r['valor']) for r in TT if r['serie'] == 'pof_tributos_indiretos_sensibilidade_denominador' and r['faixa'] == 'decimo 1' and 'monetaria' in r['unidade']), 1)}%. A POF subdeclara as rendas do topo.</p>
<table style="break-inside:avoid"><thead><tr><th>Topo dos declarantes do IRPF, imposto sobre a renda bruta</th><th class=n>Ano</th><th class=n>1% mais rico</th><th class=n>0,1% mais rico</th><th>Fonte</th></tr></thead><tbody>
<tr><td>Só IRPF devido no ajuste anual (sem o imposto exclusivo na fonte, como o de aplicações)</td><td class=n>2024</td><td class=n>{br(tv('rfb_irpf_ajuste_pct_rb4', '1% mais rico dos declarantes (centil 100)', '2024'), 1)}</td><td class=n>{br(tv('rfb_irpf_ajuste_pct_rb4', '0,1% mais rico dos declarantes (milesimo 1000)', '2024'), 1)}</td><td>Receita{n('rfb_centis')}</td></tr>
<tr><td colspan=4>IRPF com o imposto exclusivo imputado, 2023. Pico de {br(tv('spe_irpf_aliquota_efetiva', 'centil 93 dos declarantes (pico)', '2023'), 1)}% no centil 93 e {br(tv('spe_irpf_aliquota_efetiva', '0,01% mais rico dos declarantes', '2023'), 1)}% no 0,01% mais rico (a Fazenda não publica o número do 1% e do 0,1%)</td><td>Fazenda, SPE{n('spe_dist')}</td></tr>
<tr><td>IRPF mais IRPJ e CSLL atribuídos aos sócios, metade do imposto da empresa</td><td class=n>2022</td><td class=n>{br(tv('ipea_irpf_irpj_imputado_cenario_intermediario', '1% mais rico dos declarantes (ultimo percentil)'), 1)}</td><td class=n>{br(tv('ipea_irpf_irpj_imputado_cenario_intermediario', '0,1% mais rico dos declarantes (milesimo do topo)'), 1)}</td><td>Ipea{n('ipea_cc')}</td></tr>
<tr><td>O mesmo, todo o imposto da empresa atribuído ao sócio</td><td class=n>2022</td><td class=n>{br(tv('ipea_irpf_irpj_imputado_cenario_maximo', '1% mais rico dos declarantes (ultimo percentil)'), 1)}</td><td class=n></td><td>Ipea{n('ipea_cc')}</td></tr>
</tbody></table>
<p class=nota>% da renda bruta declarada. Bases, anos e conceitos diferentes. As linhas não se somam e não se somam à POF. Nenhuma fonte oficial soma consumo, renda, patrimônio e imposto da empresa para o 1% ou o 0,1% mais rico. Quanto do IRPJ recai sobre o sócio, e não sobre trabalhadores ou consumidores, é suposição. O Ipea testa 0%, 50% e 100%. A Lei 15.270/2025 cria imposto mínimo de até 10% acima de R$ 600 mil por ano a partir de 2026. Na simulação da Fazenda do projeto original com a renda de 2022, o IRPF do topo, que caía de {br(tv('spe_irpf_aliquota_efetiva', '0,7% mais rico dos declarantes', '2022'), 1)}% no 0,7% mais rico para {br(tv('spe_irpf_aliquota_efetiva', '0,01% mais rico dos declarantes', '2022'), 1)}% no 0,01%, ficaria entre {br(tv('spe_irpf_aliquota_efetiva_com_lei_15270', 'milesimos do 0,7% mais rico, minimo', '2022 (simulado)'), 1)}% e {br(tv('spe_irpf_aliquota_efetiva_com_lei_15270', 'milesimos do 0,7% mais rico, maximo', '2022 (simulado)'), 1)}% em todo esse grupo. A lei aprovada mudou detalhes, como excluir dividendos apurados até 2025{n('spe_dist')}.</p>
<p><b>A reforma do consumo.</b> A EC 132 e a LC 214 trocam PIS, Cofins, IPI, ICMS e ISS por CBS (União), IBS (estados e municípios) e Imposto Seletivo{n('ec132')}{n('lc214')}. Em 2026 há só teste (CBS de {br(vv('CBS, aliquota de teste', '2026'), 1)}% e IBS de {br(vv('IBS, aliquota de teste', '2026'), 1)}%, compensáveis). Em 2027 a CBS entra inteira, PIS e Cofins acabam e o IPI vai a zero, salvo produtos da Zona Franca. De 2029 a 2032 ICMS e ISS caem a {', '.join(br(100 * vv('ICMS e ISS: fracao', str(a)), 0) + '%' for a in range(2029, 2032))} e {br(100 * vv('ICMS e ISS: fracao', '2032'), 0)}% da alíquota atual, e acabam em 2033. O desenho é de carga neutra. A alíquota de referência é calibrada para repor a arrecadação dos tributos extintos. A Fazenda estimou {br(vv('PLP 68 completo com cashback', '2024'), 2)}% (IBS mais CBS) em jul/2024, {br(vv('cenario-base sem favorecimentos', '2024'), 2)}% sem os tratamentos favorecidos, e mais {br(vv('acrescimo pelas mudancas da Camara', '2024'), 2)} ponto pelas mudanças da Câmara{n('sert')}. O Comitê Gestor usa {br(vv('adotada pelo CGIBS como parametro', '2026'), 2)}% como parâmetro{n('cgibs')}. Se a alíquota passar de {br(vv('Trava de referencia', '2033'), 1)}%, a lei manda o Executivo propor corte de benefícios, e a alíquota pode ficar acima desse número{n('lc214')}.</p>
<p>Para quem paga, a reforma mexe justamente no consumo, onde o décimo mais pobre gasta {br(tv('pof_tributos_indiretos_pct_renda_total', 'decimo 1'), 1)}% da renda. Famílias do CadÚnico com renda de até meio salário mínimo por pessoa recebem de volta {br(vv('Devolucao da CBS: gas de botijao', ''), 0)}% da CBS e {br(vv('Devolucao do IBS: gas de botijao', ''), 0)}% do IBS sobre gás, energia, água, esgoto e telecomunicações e {br(vv('Devolucao da CBS: demais', ''), 0)}% dos dois nos demais bens, a partir de 2027 na CBS e de 2029 no IBS{n('lc214')}. A cesta básica nacional ({br(vv('Cesta Basica Nacional de Alimentos', '2027'), 0)} itens) tem alíquota zero. Pela estimativa da Fazenda, a carga sobre os alimentos da cesta e da cesta estendida cai de {br(vv('Carga media sobre alimentos da cesta e da cesta estendida, hoje', '2024'), 1)}% para {br(vv('Carga media sobre alimentos da cesta e da cesta estendida, com a refor', '2024'), 1)}% do preço, e para {br(vv('Carga media sobre alimentos para a baixa renda', '2024'), 1)}% na baixa renda com o cashback{n('sert')}. A Fazenda não publica o efeito da reforma por décimo de renda, só há estudos não oficiais.</p>
<p>Para as contas da União, a reforma cria despesa. A União banca o Fundo de Compensação de Benefícios Fiscais (R$ {br(vv('Fundo de Compensacao de Beneficios Fiscais: total', '2025-2032'), 0)} bi de 2023 entre 2025 e 2032, com pico de R$ {br(vv('Fundo de Compensacao de Beneficios Fiscais do ICMS: aporte', '2028'), 0)} bi em 2028 e 2029) e o Fundo Nacional de Desenvolvimento Regional (R$ {br(vv('Fundo Nacional de Desenvolvimento Regional: aporte', '2029'), 0)} bi em 2029, subindo até R$ {br(vv('Fundo Nacional de Desenvolvimento Regional: aporte', '2043 em diante (por ano)'), 0)} bi por ano a partir de 2043), valores corrigidos pelo IPCA e fora do limite de despesas do arcabouço{n('ec132')}. Em 2030 os dois somam cerca de {br(float(nota_s['fundos_2030_pct_pib']), 1)}% do PIB. Na transição, os gastos tributários federais em PIS, Cofins e IPI, R$ {br(vv('nos tributos que a reforma extingue', '2026'), 1)} bi na previsão de 2026, mudam de forma. A desoneração da cesta (R$ {br(vv('Desoneracao da cesta basica', '2026'), 1)} bi) vira alíquota zero, e o Simples (R$ {br(vv('Simples Nacional: gasto em PIS', '2026'), 1)} bi) e a Zona Franca (R$ {br(vv('Zona Franca de Manaus e Areas', '2026'), 1)} bi) continuam em outra forma{n('dgt')}. O split payment, recolhimento do tributo no momento do pagamento, começa por etapas, a primeira para operações entre empresas e facultativa{n('d12955')}. Não há data de obrigatoriedade nem estimativa oficial de quanto reduz a sonegação. Os cenários da seção 12 não incluem esses fundos à parte nem ganho de arrecadação do split payment.</p>
<p>Somando o que se pode somar. Na base da população, quem está embaixo paga mais em proporção da renda, pelo consumo. No topo dos declarantes, o imposto sobre a renda pessoal cai, e mesmo atribuindo aos sócios todo o imposto da empresa o 1% mais rico fica em {br(tv('ipea_irpf_irpj_imputado_cenario_maximo', '1% mais rico dos declarantes (ultimo percentil)'), 1)}% da renda, abaixo do pico de {br(tv('ipea_irpf_irpj_imputado_cenario_maximo', 'percentil 98 dos declarantes (pico)'), 1)}% no percentil 98{n('ipea_cc')}.</p>
<table style="break-inside:avoid"><thead><tr><th>Previdência, R$ por mês</th><th class=n>Valor</th><th class=n>Vezes o INSS</th><th class=n>Fonte</th></tr></thead><tbody>{linhas_prev}</tbody></table>
<p class=nota>Valores médios por benefício ou por pessoa, de fontes e datas diferentes. Servidores e militares contribuíram sobre salários maiores, sem teto até 2013 para os civis, e o INSS conta benefícios, e uma pessoa pode ter mais de um. Os números não comparam mérito nem déficit{n('beps')}{n('aeps')}{n('pldo')}.</p>
<p><b>Quanto cada regime custa ao Tesouro.</b> O resultado é contribuição menos benefício. O que falta sai do orçamento.</p>
<figure>{svg('12d-previdencia-resultado')}</figure>
<table style="break-inside:avoid"><thead><tr><th>2025 (Lula 3), R$ bi</th><th class=n>Contribuições</th><th class=n>Benefícios</th><th class=n>Resultado</th><th class=n>% PIB</th><th class=n>Beneficiários</th><th class=n>Resultado por beneficiário, R$ por ano</th></tr></thead><tbody>
{''.join(f"<tr><td>{nm}</td><td class=n>{br(uv(rg, 'receita_contribuicoes', 2025) / 1000, 1)}</td><td class=n>{br(uv(rg, 'despesa_beneficios', 2025) / 1000, 1)}</td><td class=n>{br(uv(rg, 'resultado', 2025) / 1000, 1)}</td><td class=n>{br(uv(rg, 'resultado_pct_pib', 2025), 2)}</td><td class=n>{br(uv(rg, 'beneficiarios', 2025), 0)}</td><td class=n>{br(uv(rg, 'resultado_por_beneficiario', 2025), 0) if rg != 'FCDF' else 'n/d'}</td></tr>" for rg, nm in (('RGPS urbano', 'INSS urbano'), ('RGPS rural', 'INSS rural'), ('RPPS civil Uniao', 'Servidores civis da União, com a patronal da União como receita'), ('militares (SPSMFA)', 'Militares (inativos e pensões)'), ('FCDF', 'FCDF (polícias e bombeiros do DF)')))}
</tbody></table>
<p class=nota>INSS. RTN do Tesouro{n('rtn')} e benefícios emitidos em dezembro, que contam benefícios e não pessoas{n('beps')}. Servidores civis, militares e FCDF. RREO da União, anexo 4{n('siconfi')}, e contagens das avaliações atuariais{n('pldo27_atu')}. A contribuição dos servidores inclui a parte patronal paga pela própria União, que é transferência dentro do orçamento. Sem ela, o resultado dos civis seria R$ {br(uv('RPPS civil Uniao', 'resultado_sem_patronal', 2025) / 1000, 1)} bi ({br(uv('RPPS civil Uniao', 'resultado_sem_patronal_por_beneficiario', 2025), 0)} por beneficiário){n('siconfi')}. Militares não têm contribuição patronal. O Tesouro paga os inativos. O FCDF de 2025 foi transcrito da versão republicada do RREO, cujo texto não é legível por máquina. A republicação dobrou a despesa (de R$ 5,1 bi para R$ 10,4 bi) e a contagem de beneficiários do PLDO não acompanha essa mudança, por isso o valor por beneficiário não é mostrado. No INSS os valores são de caixa (pago), e nos regimes próprios, despesa do RREO. De 2012 a 2022 a receita do INSS urbano inclui a compensação do Tesouro pela desoneração da folha, o que melhora o resultado desses anos. Até 2014 a série dos civis cobre só aposentadorias e pensões (AEPS). O degrau de 2015 vem da mudança de definição.</p>
<p class=nota>Resultado por beneficiário não mede eficiência. Os regimes têm regras de acesso, histórico de contribuição e funções diferentes, e o INSS rural é em boa parte transferência assistencial, com contribuição baixa por desenho. Quanto uma reforma mudaria a necessidade de financiamento depende das regras de transição e dos direitos já adquiridos, que estes números de um ano não medem.</p>
<p>O INSS tem o maior déficit em reais (R$ {br(-uv('RGPS', 'resultado', 2025) / 1000, 0)} bi), quase dois terços no rural, que arrecada pouco por desenho. Por beneficiário, o desequilíbrio é outro. R$ {br(-uv('RGPS', 'resultado_por_beneficiario', 2025), 0)} por benefício por ano no INSS ({br(-uv('RGPS urbano', 'resultado_por_beneficiario', 2025), 0)} no urbano), R$ {br(-uv('RPPS civil Uniao', 'resultado_sem_patronal_por_beneficiario', 2025), 0)} nos servidores civis, contando só a contribuição dos próprios servidores, que é o custo para o Tesouro e R$ {br(-uv('militares (SPSMFA)', 'resultado_por_beneficiario', 2025), 0)} nos militares. Para o futuro, a avaliação atuarial do PLDO 2027 calcula, a valor presente, um déficit de R$ {br(ua('RPPS civil Uniao', 'deficit_atuarial') / 1e6, 2)} tri nos servidores civis ({br(ua('RPPS civil Uniao', 'deficit_atuarial_pct_pib'), 1)}% do PIB) e de R$ {br(ua('militares (SPSMFA)', 'deficit_atuarial') / 1e3, 0)} bi nos militares ({br(ua('militares (SPSMFA)', 'deficit_atuarial_pct_pib'), 1)}% do PIB), em grupo fechado e com a taxa real de desconto do próprio anexo. Para o INSS, o anexo não traz valor presente e projeta a necessidade de financiamento de {br(next(float(r['valor']) for r in UA if r['regime'] == 'RGPS' and r['serie'] == 'necessidade_financiamento_projetada_pct_pib' and r['ano'] == '2026'), 1)}% do PIB em 2026 para {br(next(float(r['valor']) for r in UA if r['regime'] == 'RGPS' and r['serie'] == 'necessidade_financiamento_projetada_pct_pib' and r['ano'] == '2100'), 1)}% em 2100{n('pldo27_atu')}.</p>
<table style="break-inside:avoid"><thead><tr><th>Arrecadação por base, % da receita tributária</th>{''.join(f'<th class=n>{a}</th>' for a in AC)}</tr></thead><tbody>{linhas_cb}</tbody></table>
<p class=nota>Receita Federal, Carga Tributária no Brasil 2024, metodologia nova, governo geral{n('rfb')}. 2002 FHC, 2010 Lula 2, 2014 Dilma, 2018 Temer, 2022 Bolsonaro, 2024 Lula 3. O consumo continua a maior base, e a renda ganhou peso a partir de 2022.</p>"""

qv = lambda f, ind, rc, a: QQ[(f, ind, rc, a)]
ultimo = lambda f, ind, rc: max(a for (f_, i_, r_, a) in QQ if f_ == f and i_ == ind and r_ == rc)
PAISES_Q = ['Brasil', 'Mexico', 'Chile', 'Colombia', 'Argentina', 'Indonesia']
IND_Q = [('PISA matemática', 'PISA matematica', 2025, 0, 'Media OCDE-35 (mesmos 35 paises nos ciclos)'), ('Esperança de vida, anos', 'Esperanca de vida ao nascer', 2024, 1, 'OCDE (membros, agregado Banco Mundial)'),
         ('Mortalidade infantil, por mil', 'Taxa de mortalidade infantil', 2024, 1, 'OCDE (membros, agregado Banco Mundial)'),
         ('Gasto público em saúde, % PIB', 'Gasto publico domestico em saude (governo geral)', 2023, 1, 'OCDE (membros, agregado Banco Mundial)'),
         ('Gasto público em educação, % PIB', 'Gasto publico em educacao', 2022, 1, 'OCDE (membros, agregado Banco Mundial)')]
cel_q = lambda ind, rc, a, d: br(QQ[('internacional', ind, rc, a)], d) if ('internacional', ind, rc, a) in QQ else 'n/d'
linhas_qi = ''.join(f"<tr><td>{nm} ({a})</td>" + ''.join(f"<td class=n>{cel_q(ind, p_, a, d)}</td>" for p_ in PAISES_Q + [oc]) + '</tr>' for nm, ind, a, d, oc in IND_Q)
IP = lambda et: 'IDEB - ' + et; NP = lambda et: 'Saeb nota media padronizada (N) - ' + et; PP = lambda et: 'Indicador de rendimento (P, aprovacao) - ' + et
EM = 'Ensino medio (3a serie)'; RP = 'Brasil, rede Pública'
tmi = lambda a: qv('saude', 'Taxa de mortalidade infantil (IBGE, estimada)', 'Brasil', a)
sec_res = f"""<h2>Anexo T4. O que se obtém. Educação e saúde</h2>
<figure>{svg('13-resultados')}</figure>
<p class=nota>Ideb, Saeb e aprovação. INEP, rede pública{n('inep')}. PISA. OCDE, tabelas de tendência do PISA 2025. A média dos mesmos 35 países da OCDE evita a troca de composição entre ciclos{n('pisa')}. Mortalidade infantil e esperança de vida. IBGE, projeções da população revisão 2024, que refizeram a série depois do Censo 2022. De 2023 em diante é projeção (tracejado){n('ibge')}. 2020 e 2021 são anos de pandemia.</p>
<table style="break-inside:avoid"><thead><tr><th>Último ano com dado</th><th class=n>Brasil</th><th class=n>México</th><th class=n>Chile</th><th class=n>Colômbia</th><th class=n>Argentina</th><th class=n>Indonésia</th><th class=n>OCDE</th></tr></thead><tbody>{linhas_qi}</tbody></table>
<p class=nota>Banco Mundial, WDI, que repassa ONU (esperança de vida), UN IGME (mortalidade infantil), OMS (gasto em saúde) e UNESCO (gasto em educação){n('wdi')}, PISA pela OCDE{n('pisa')}. OCDE. Agregado do Banco Mundial (média ponderada em saúde, mediana em educação) e, no PISA, a média dos 35 países. A série de educação da Indonésia tem quebra de fonte em 2019.</p>
<p>No ensino médio da rede pública, o Ideb passou de {br(qv('educacao', IP(EM), RP, 2009), 1)} em 2009 para {br(qv('educacao', IP(EM), RP, 2025), 1)} em 2025. A aprovação subiu de {br(qv('educacao', PP(EM), RP, 2009), 2)} para {br(qv('educacao', PP(EM), RP, 2025), 2)} e a nota padronizada do Saeb, de {br(qv('educacao', NP(EM), RP, 2009), 2)} para {br(qv('educacao', NP(EM), RP, 2025), 2)}. A melhora veio sobretudo da aprovação{n('inep')}. No PISA, o Brasil fez {br(qv('internacional', 'PISA matematica', 'Brasil', 2009), 0)} pontos em matemática em 2009 e {br(qv('internacional', 'PISA matematica', 'Brasil', 2025), 0)} em 2025{n('pisa')}. A mortalidade infantil caiu de {br(tmi(2008), 1)} por mil em 2008 para {br(tmi(2015), 1)} em 2015 e ficou perto de 12 desde então{n('ibge')}. O gasto público em saúde do Brasil, {br(qv('internacional', 'Gasto publico domestico em saude (governo geral)', 'Brasil', 2023), 1)}% do PIB em 2023, é menor que o de Chile, Colômbia e Argentina{n('wdi')}.</p>
<p class=nota>Gasto e resultado andarem juntos não mostra que um causa o outro. Renda, demografia, saneamento e mudanças de registro andam junto, e o efeito do gasto chega com defasagem (o PISA de 2025 mede alunos escolarizados ao longo de vários mandatos). A educação básica é paga sobretudo por estados e municípios, então o gasto da União (seção 7) não é o denominador certo para esses resultados. O do governo geral está na seção 2.</p>"""
SC = le('S-cenarios-divida.csv')
_SM = [r for r in le('S-multiplicador.csv') if r['ano'] == '2030']
SMU = {}
for _p in ('4. ', '4b.'):
  _rr = sorted((float(r['multiplicador']), float(r['divida_pct_pib'])) for r in _SM if r['cenario'].startswith(_p))
  SMU[(_p, 'min')], SMU[(_p, 'max')] = _rr[0], _rr[-1]
REN_PIB = next(float(r['pct_pib']) for r in le('E-renuncias-e-subsidios.csv') if r['ano'] == '2024' and r['subcategoria'] == 'Subsidios tributarios (renuncias)')
SCN = list(dict.fromkeys(r['cenario'] for r in SC))
sc = lambda c, a, k: float(next(r[k] for r in SC if r['cenario'] == c and r['ano'] == str(a)))
nota_s = dict(x.split('=') for x in SC[0]['nota'].split('; ') if '=' in x)
fig, ax = plt.subplots(figsize=(LARG, 3.8))
# gramatica do simulado: tudo depois do ultimo dado observado sai tracejado; cor so distingue o cenario central, a inercia e a grade do PLDO
ax.text(2025.5, 1.0, 'Lula 3', ha='center', va='bottom', fontsize=7, color=CINZA, transform=ax.get_xaxis_transform(), clip_on=False)
ax.text(2028.5, 1.0, 'próximo mandato (2027-2030), simulado', ha='center', va='bottom', fontsize=7, color=CINZA, transform=ax.get_xaxis_transform(), clip_on=False)
MCN = next(r['n_sorteios'] for r in le('S-montecarlo.csv') if r['cenario'].startswith('2.'))
MCD = {(r['ano'], k): float(r[k]) for r in le('S-montecarlo.csv') if r['cenario'].startswith('2.') and r['variavel'] == 'divida_pct_pib' for k in ('p5', 'p25', 'p75', 'p95')}
anos_mc = [2025] + list(range(2026, 2031)); d25 = float(nota_s['d_2025'])
mc = lambda k: [d25] + [MCD[(str(a), k)] for a in range(2026, 2031)]
ax.fill_between(anos_mc, mc('p5'), mc('p95'), color='#8fa7c4', alpha=0.28, lw=0, zorder=1)
ax.fill_between(anos_mc, mc('p25'), mc('p75'), color='#8fa7c4', alpha=0.45, lw=0, zorder=1)
EST = {'1': (ESCURO, 1.4), '1b': (CINZA, 0.8), '2': (AZUL, 1.8), '2b': (CINZA, 0.8), '3': (CINZA, 1.2), '4': (CINZA, 1.2), '4b': (CINZA, 1.2), '5': (CINZA, 1.2), '6': ('#a8841f', 1.4)}
ROT = {'1b': None, '2b': None}
for c in SCN:
  k = c.split('.')[0]
  if k not in EST: continue
  cor, lw = EST[k]
  ys = [d25] + [sc(c, a, 'divida_pct_pib') for a in range(2026, 2031)]
  ax.plot(range(2025, 2031), ys, '--', color=cor, lw=lw, zorder=3, dashes=(4, 2))
  if ROT.get(k, 1) is not None:
    ax.text(2030.12, ys[-1] + (-1.1 if c.startswith('4b') else 1.1 if c.startswith('4.') else 0), c, fontsize=6.5, va='center', color=cor)
x_obs = 2026 + (8 - 0.5) / 12  # agosto de 2026, ultimo dado do BCB
ax.plot([2025, x_obs], [d25, dbgg_bacen], '-', color=ESCURO, lw=1.6, zorder=4)
ax.plot([2025, x_obs], [d25, dbgg_bacen], 'o', color=ESCURO, ms=3.5, zorder=5)
ax.text(x_obs + 0.08, dbgg_bacen - 1.6, f'{br(dbgg_bacen, 1)}% em ago/2026, observado', fontsize=6.5, ha='left', va='top', color=ESCURO)
ax.plot([2029, 2030], [float(nota_s['pldo_dbgg_2029']), float(nota_s['pldo_dbgg_2030'])], 'D', color=ESCURO, ms=3.5, ls='none', zorder=5)
ax.text(2029, float(nota_s['pldo_dbgg_2029']) - 3.4, 'projeção do Tesouro no PLDO', fontsize=6.5, ha='center')
ax.set_xlim(2024.6, 2032.6); ax.set_xticks(range(2025, 2031)); ax.set_ylabel('dívida bruta, % do PIB'); ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(f'{G}/14-cenarios.svg'); plt.close(fig)
linhas_sc = ''.join(f"<tr><td>{c}</td><td>{next(r['descricao'] for r in SC if r['cenario'] == c)}</td>" + ''.join(f"<td class=n>{br(sc(c, 2030, k), 1)}</td>" for k in ('selic_media', 'cresc_nominal', 'primario_pct_pib', 'juros_pct_pib', 'divida_pct_pib', 'primario_estabiliza')) + "</tr>" for c in SCN)
C = {c.split('.')[0]: c for c in SCN}
pico = lambda c: max(range(2026, 2031), key=lambda a: sc(c, a, 'divida_pct_pib'))
# Secao 12: PLOA 2027 (frente PO), Selic parada (S2) e sensibilidade de 2030 contra uma base so (S2, leitura de design por agente de IA, recomendacao 3)
PO = {r['item']: r for r in le('PO-ponte-receita-2027.csv')}
po = lambda it, c: float(PO[it][c])
POT = PO['Receita primária líquida do Governo Central']
PO_TRANSF = sum(float(r['alem_do_pib_rs_bi']) for r in le('PO-ponte-receita-2027.csv') if r['bloco'].startswith('5.') and r['alem_do_pib_rs_bi'])
PO_BRUTA = sum(float(r['alem_do_pib_rs_bi']) for r in le('PO-ponte-receita-2027.csv') if r['bloco'][:2] in ('2.', '3.', '4.') and not r['bloco'].endswith('detalhe') and r['alem_do_pib_rs_bi'])
assert abs(PO_TRANSF + PO_BRUTA - float(POT['alem_do_pib_rs_bi'])) < 0.05, (PO_TRANSF, PO_BRUTA)
S2 = {(r['cenario'], r['ano']): r for r in le('S2-divida-sem-queda-juros.csv')}
s2 = lambda c, k: float(S2[(c, '2030')][k])
SEN = le('S2-sensibilidade-2030.csv'); SEN = [r for r in SEN if r['efeito_pp']]
SEN.sort(key=lambda r: abs(float(r['efeito_pp'])))
fig, ax = plt.subplots(figsize=(LARG, 3.2))
for k, r in enumerate(SEN):
  v = float(r['efeito_pp']); ax.barh(k, v, height=0.62, color='#4d4d4d' if v < 0 else '#8a8a8a')
  ax.text(v + (0.15 if v >= 0 else -0.15), k, br(v, 1), va='center', ha='left' if v >= 0 else 'right', fontsize=7)
ROT_SEN = {'macro do PLDO': 'Macro do PLDO (Selic, IPCA e PIB)', 'prêmio -1,5': 'Selic e mercado -1,5 (cenário 3)'}
ax.set_yticks(range(len(SEN)), [ROT_SEN.get(r['alavanca'], r['alavanca'][0].upper() + r['alavanca'][1:]) for r in SEN], fontsize=7.2)
ax.axvline(0, color=ESCURO, lw=0.6); ax.grid(axis='y', visible=False); ax.grid(axis='x', visible=True); ax.set_xlim(-13.5, 6)
ax.set_xlabel(f"pontos do PIB na dívida bruta de 2030, contra o cenário 2 ({br(float(SEN[0]['divida_2030_base']), 1)}%)")
fig.tight_layout(); fig.savefig(f'{G}/12a-sensibilidade-2030.svg'); plt.close(fig)
sec_ploa = f"""<h3>O que move a dívida de 2030</h3>
<p class="cl cl-a">Contra uma base só, o cenário 2 (primário do PLDO, macro do Focus, dívida de {br(float(SEN[0]['divida_2030_base']), 1)}% do PIB em 2030), cada alavanca foi mudada sozinha no mesmo simulador, e o efeito de cada uma é aritmética condicional. A troca da macro do Focus pela do PLDO move {br(-float(next(r['efeito_pp'] for r in SEN if r['alavanca'] == 'macro do PLDO')), 1)} pontos. Um ponto a mais de crescimento real move {br(-float(next(r['efeito_pp'] for r in SEN if r['alavanca'] == 'crescimento real +1')), 1)}, e o ajuste pela receita ou pela despesa, sem queda de juros, uns {br(-float(next(r['efeito_pp'] for r in SEN if r['alavanca'] == 'ajuste pela receita')), 1)}. O canal fiscal estimado pela literatura move {br(-float(next(r['efeito_pp'] for r in SEN if r['alavanca'] == 'canal fiscal central')), 2)} ponto. Com os tamanhos de choque escolhidos aqui, a macro move mais que juros e ajuste, e o canal fiscal menos que todos. A ordem entre juros e ajuste depende do tamanho de cada choque, e não é achado.</p>
<figure>{svg('12a-sensibilidade-2030')}</figure>
<p class=nota>Cada barra muda uma alavanca a partir de 2027 (a macro do PLDO troca Selic, IPCA e PIB juntos) e mantém as outras do cenário 2. Deflator 1 ponto acima e crescimento real 1 ponto acima dão o mesmo número porque entram no simulador só pelo crescimento nominal. O multiplicador de 1,2 fica fora porque só age sobre o ajuste extra dos cenários 4 e 4b. Simulação condicional, não previsão{n('focus')}{n('pldo27')}.</p>
<h3>Se a Selic não cair</h3>
<p class="cl cl-a">Os cenários acima usam a Selic do Focus, que cai a {br(sc(C['2'], 2030, 'selic_media'), 1)}% em 2030. Com a Selic parada nos {br(s2('S2a. Selic parada, primário do PLDO', 'selic_media'), 2)}% de hoje até 2030 e o primário do PLDO, a dívida bruta chega a {br(s2('S2a. Selic parada, primário do PLDO', 'divida_pct_pib'), 1)}% do PIB em 2030, {br(s2('S2a. Selic parada, primário do PLDO', 'divida_pct_pib') - sc(C['2'], 2030, 'divida_pct_pib'), 1)} pontos acima do cenário 2. Com o juro real da Selic parado, {br(s2('S2b. Selic real parada, primário do PLDO', 'divida_pct_pib'), 1)}%. Com a Selic parada e o primário de 2025 em todos os anos, {br(s2('S2c. Selic parada, primário de 2025', 'divida_pct_pib'), 1)}%. A Selic é decisão do Copom, e o cenário vale para qualquer governo{n('copom281')}{n('focus')}{n('pldo27')}.</p>
<h3>A receita do PLOA 2027</h3>
<p class="cl cl-a">O projeto de orçamento de 2027, enviado em agosto, prevê receita primária líquida de R$ {br(po('Receita primária líquida do Governo Central', 'valor_2027_rs_bi'), 1)} bi, R$ {br(po('Receita primária líquida do Governo Central', 'efeito_na_receita_liquida_rs_bi'), 1)} bi acima da reprogramação de 2026. Desse aumento, R$ {br(po('Receita primária líquida do Governo Central', 'efeito_pib_nominal_rs_bi'), 1)} bi acompanham o PIB nominal ({br(po('dos quais, crescimento real do PIB', 'efeito_pib_nominal_rs_bi'), 1)} do crescimento real e {br(po('dos quais, preços (deflator do PIB)', 'efeito_pib_nominal_rs_bi'), 1)} dos preços) e R$ {br(po('Receita primária líquida do Governo Central', 'alem_do_pib_rs_bi'), 1)} bi, {br(po('Receita primária líquida do Governo Central', 'alem_do_pib_pct_pib_2027'), 2)} ponto do PIB, vão além dele. A troca de PIS, Cofins e IPI pela CBS e pelo Imposto Seletivo soma R$ {br(po('PIS, Cofins e IPI (2026) contra CBS, Imposto Seletivo e residuais (2027)', 'alem_do_pib_rs_bi'), 1)} bi além do PIB, com R$ {br(po('Imposto Seletivo, tributo novo da LC 214/2025, depende de lei ordinária com as alíquotas', 'valor_2027_rs_bi'), 1)} bi de Imposto Seletivo, que depende de lei ordinária com as alíquotas. Como o IPI era repartido com estados e municípios e a CBS não é, as transferências ficam R$ {br(PO_TRANSF, 1)} bi abaixo do que o PIB daria, e é daí que vem o ganho líquido. Sem as transferências, a receita fica R$ {br(-PO_BRUTA, 1)} bi abaixo do que o PIB daria, com o Imposto de Renda ({br(po('Imposto de Renda', 'alem_do_pib_rs_bi'), 1)}) e os dividendos ({br(po('Dividendos e participações', 'alem_do_pib_rs_bi'), 1)}) puxando para baixo. Na despesa, o mesmo projeto cria um fundo de compensação aos estados pela troca do IPI. Além do PIB não quer dizer medida nova, e soma medida, premissa da reforma, petróleo, dividendos e elasticidade. As renúncias novas com valor somam R$ {br(-po('Total das renúncias novas (Tabela 11)', 'efeito_na_receita_liquida_rs_bi'), 2)} bi. O PLOA projeta primário de 0,13% do PIB em 2027, e os cenários desta seção usam o 0,05% do PLDO{n('ploa27')}.</p>
<p class=nota>Mensagem Presidencial do PLOA 2027, Tabela 9, contra a reprogramação de 2026 que o próprio projeto usa como base, e PIB da grade da SPE{n('ploa27')}. A parte que acompanha o PIB é a receita de 2026 vezes o crescimento nominal de 2027. Medidas citadas sem valor (reoneração da folha, LC 224/2025, Pilar 2, IOF) ficam fora da conta, classe C quanto ao efeito. A tabela por item está no pacote (PO-ponte-receita-2027.csv).</p>"""
sec_cen = f"""<h2>12. Cenários da dívida até 2030</h2>
<p>Os cenários são condicionais. Cada um muda uma premissa e mostra o que acontece com a dívida bruta e com os juros, pela mesma identidade da seção 9. O ponto de partida é dez/2025, com dívida de {br(float(nota_s['d_2025']), 1)}% do PIB e juro implícito de {br(float(nota_s['i_2025']), 2)}%{n('j_bcb')}. Selic, IPCA e PIB vêm do Focus de 09/10/2026{n('focus')}. O primário, da projeção do PLDO 2027 para o Governo Central{n('pldo27')}.</p>
<figure>{svg('14-cenarios')}</figure>
<p class=nota>Tracejado é simulado, linha cheia é observado. A faixa azul clara vai do percentil 5 ao 95 do cenário 2, e a mais escura, do 25 ao 75, em {br(float(MCN), 0)} sorteios que variam o canal fiscal (11 a 47 pb, centro em 26), o deflator (IPCA menos 1 a mais 1 ponto) e a âncora de mercado (setembro ou outubro de 2026). Em 2030 ela vai de {br(MCD[('2030', 'p5')], 1)}% a {br(MCD[('2030', 'p95')], 1)}% do PIB. 1b e 2b aparecem em linha fina cinza, e o ponto cheio é o último dado do BCB{n('bcbdiv')}.</p>
<table style="break-inside:avoid"><thead><tr><th>Cenário</th><th>Premissa</th><th class=n>Selic média 2030</th><th class=n>Crescimento nominal 2030</th><th class=n>Primário 2030</th><th class=n>Juros 2030, % PIB</th><th class=n>Dívida 2030</th><th class=n>Primário que estabiliza em 2030</th></tr></thead><tbody>{linhas_sc}</tbody></table>
<p class=nota>Dívida bruta do governo geral, critério Bacen. O juro implícito é montado por indexador com os pesos de dez/2025 e calibrado para dar o de 2025. Títulos que seguem a Selic e compromissadas do BC ({br(100 * float(nota_s['peso_selic']), 0)}%) pagam a Selic média do ano. Prefixados ({br(100 * float(nota_s['peso_prefixado']), 0)}%) e indexados a preços ({br(100 * float(nota_s['peso_precos']), 0)}%) saem do custo médio de 2025 e vão às taxas de mercado de 10 anos na fração do estoque que vence a cada ano, pelo perfil de vencimentos de dez/2025, e na emissão líquida nova, de {nota_s['mes_mercado'][5:]}/{nota_s['mes_mercado'][:4]}, dado mais recente com {nota_s['dias_mes_mercado']} pregões ({br(float(nota_s['prefixado_10a_mercado']), 1)}% no prefixado e {br(float(nota_s['juro_real_10a_mercado']), 1)}% de juro real){n('rmd')}{n('td')}. Crescimento nominal = PIB real com o IPCA no lugar do deflator. O cenário 2b mostra a sensibilidade a 1 ponto a mais de deflator. Sem ajustes entre fluxo e estoque. O primário é o do Governo Central, aplicado à dívida do governo geral. A meta do PLDO ({br(float(nota_s['meta_2030']), 2)}% em 2030) é aferida depois de exclusões, como precatórios. O primário projetado antes delas é {br(float(nota_s['proj_2030']), 2)}%, e é ele que entra na dívida. O cenário 4 supõe que 1/5 dos gastos tributários de 2024 ({br(REN_PIB / 5, 2)}% do PIB) vire arrecadação integral da União e cresça com o PIB, R$ {br(float(nota_s['ren_rs_2028']), 0)} bi em 2028 e R$ {br(float(nota_s['ren_rs_2030']), 0)} bi em 2030. É um teto, porque quem perde o benefício muda de comportamento e parte da receita de IR e IPI vai a estados e municípios{n('osu')}. O cenário 4b supõe que a projeção do PLDO tenha a despesa crescendo no teto do arcabouço todo ano (o PLDO dá {br(float(nota_s['teto']), 1)}% para 2027) e a troca pelo piso de {br(float(nota_s['piso']), 1)}%{n('lc200')}. Sobre a despesa de {br(float(nota_s['desp_2025_pct_pib']), 1)}% do PIB de 2025{n('rtn')}, isso dá {br(float(nota_s['desp_extra_2030']), 2)} ponto a mais de primário em 2030. Com {br(pct_obrig, 1)}% da despesa obrigatória, segurar o piso exige mudar regras de previdência, pisos de saúde e educação e vinculações ao salário mínimo. O simulador não modela de forma endógena os efeitos de receita e de despesa sobre crescimento, arrecadação e inflação. Como sensibilidade, com multiplicador fiscal de {br(SMU[('4. ', 'max')][0], 1)} (topo da faixa da literatura para o Brasil, de {br(SMU[('4. ', 'min')][0], 1)} a {br(SMU[('4. ', 'max')][0], 1)}){n('lit')}, o ajuste reduz o crescimento no ano em que é feito e a dívida de 2030 sobe de {br(SMU[('4. ', 'min')][1], 1)}% para {br(SMU[('4. ', 'max')][1], 1)}% no ajuste pela receita e de {br(SMU[('4b.', 'min')][1], 1)}% para {br(SMU[('4b.', 'max')][1], 1)}% no ajuste pela despesa, sem contar a perda de arrecadação que viria junto (S-multiplicador.csv). É um estresse parcial. Não há receita endógena, e um só multiplicador vale para qualquer composição do ajuste, quando tributos, custeio e investimento público têm multiplicadores diferentes. Para a América Latina, a estimativa por identificação narrativa é de cerca de 0,9 após dois anos{n('lit')}. As taxas 1,5 ponto abaixo ou 2 acima são premissas, sem estimar o efeito do ajuste, e o estresse muda só as taxas, sem mexer em crescimento ou inflação. O primário do Focus (cenário 1b) é o do setor público consolidado.</p>
<p>Com a macro do Focus, nenhum cenário estabiliza a dívida até 2030. Na inércia, ela chega a {br(sc(C['1'], 2030, 'divida_pct_pib'), 0)}% do PIB, com o primário que o próprio PLDO projeta, a {br(sc(C['2'], 2030, 'divida_pct_pib'), 0)}%, ou {br(sc(C['2b'], 2030, 'divida_pct_pib'), 0)}% se o deflator do PIB ficar 1 ponto acima do IPCA (cenário 2b), o que mostra o peso dessa premissa. Com prêmio menor, {br(sc(C['3'], 2030, 'divida_pct_pib'), 0)}%. Somando ao prêmio menor um ajuste de receita ou de despesa, ela chega a {br(sc(C['4'], 2030, 'divida_pct_pib'), 1)}% ou {br(sc(C['4b'], 2030, 'divida_pct_pib'), 1)}%, ainda subindo. O primário de {br(sc(C['4'], 2030, 'primario_pct_pib'), 1)}% ou {br(sc(C['4b'], 2030, 'primario_pct_pib'), 1)}% fica abaixo dos cerca de {br(sc(C['4'], 2030, 'primario_estabiliza'), 1)}% que a estabilizariam. No estresse, {br(sc(C['5'], 2030, 'divida_pct_pib'), 0)}%. O primário que estabiliza sobe de {br(p_est(i_est), 1)}% do PIB nas condições de 2025 (seção 9) para {br(sc(C['2'], 2030, 'primario_estabiliza'), 1)}% em 2030 no cenário 2, porque a dívida de partida é maior ({br(sc(C['2'], 2029, 'divida_pct_pib'), 0)}% contra {br(float(nota_s['d_2025']), 0)}%) e o crescimento nominal do Focus é menor ({br(sc(C['2'], 2030, 'cresc_nominal'), 1)}% contra {br(100 * g_est, 1)}%), mesmo com juro implícito menor ({br(sc(C['2'], 2030, 'juro_implicito'), 1)}% contra {br(100 * i_est, 1)}%). Os juros ficam entre {br(min(sc(c, 2030, 'juros_pct_pib') for c in SCN), 1)}% e {br(max(sc(c, 2030, 'juros_pct_pib') for c in SCN), 1)}% do PIB em 2030. A queda da taxa é em parte compensada pelo estoque maior.</p>
<p>O Tesouro projeta no PLDO a dívida parando em {br(float(nota_s['pldo_dbgg_2029']), 1)}% em 2029. Com a grade do próprio PLDO (cenário 6), o simulador dá {br(sc(C['6'], 2029, 'divida_pct_pib'), 1)}% em 2029, com pico em {pico(C['6'])}. A conta é a mesma, e a diferença está na macro. A grade de março de 2026 supõe Selic de {br(float(nota_s['pldo_selic_2030']), 1)}% e crescimento nominal de {br(float(nota_s['pldo_cresc_nominal_2030']), 1)}% em 2030, e o Focus de outubro, {br(sc(C['2'], 2030, 'selic_media'), 1)}% e {br(sc(C['2'], 2030, 'cresc_nominal'), 1)}%. Um ponto a mais de deflator, sozinho, tira {br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['2b'], 2030, 'divida_pct_pib'), 1)} pontos da dívida de 2030. Trocar a macro do Focus pela do PLDO muda a dívida de 2030 em {br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['6'], 2030, 'divida_pct_pib'), 1)} pontos. O ajuste pela receita, com taxas menores, em {br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['4'], 2030, 'divida_pct_pib'), 1)}. Para 2026, o simulador dá {br(sc(C['2'], 2026, 'divida_pct_pib'), 1)}% no fim do ano. O último dado publicado, de {nota_s['obs_mes']}, é {br(float(nota_s['obs_dbgg']), 1)}%{n('bcbdiv')}. Os fundos da reforma do consumo (anexo T3) somam cerca de {br(float(nota_s['fundos_2030_pct_pib']), 1)}% do PIB em 2030. O PLDO não informa se a projeção do primário já os inclui. O consenso do mercado (cenário 1b, com o primário do Focus) fica perto da inércia.</p>"""
sec_emerg = f"""<h2>10. Juros. O Brasil entre os emergentes</h2>
<figure>{svg('10-emergentes')}</figure>
<table><thead><tr><th>País, último ano observado</th><th class=n>Juros líquidos</th><th class=n>Juros brutos 2024</th><th class=n>Primário</th><th class=n>Dívida bruta</th><th class=n>Juros líquidos sobre dívida bruta</th><th class=n>Juro menos crescimento</th><th class=n>Juro básico real dez/25</th></tr></thead><tbody>{linhas_mm}</tbody></table>
<p class=nota>FMI, World Economic Outlook de outubro de 2026, governo geral. Juros líquidos = primário menos resultado nominal. Juros brutos do Fiscal Monitor. Juros líquidos sobre dívida bruta = juros líquidos do ano sobre a dívida bruta do ano anterior. Não é a taxa que o governo paga, porque o numerador desconta o que ele recebe pelos ativos e o denominador não desconta os ativos. Mede o peso líquido dos juros por real de dívida bruta, e a coluna seguinte usa a mesma razão. Juro menos crescimento nominal em pontos percentuais{n('weo')}. Juro básico real ex-post. Taxa de política de dez/2025 menos a inflação dos 12 meses anteriores, que difere do juro real esperado{n('bis')}. A dívida bruta do Brasil no FMI inclui todos os títulos na carteira do BC ({br(float(mb['divida_bruta_pct_pib']), 1)}%, contra {br(DV['dbgg'][2025], 1)}% no critério Bacen). No México, o governo geral inclui Pemex e CFE e exclui estados. Na África do Sul, só o governo central.</p>
<p>Entre os {len(paises) - 1} emergentes comparados e os EUA, o Brasil tem os maiores juros ({br(float(mb['juros_liquidos_pct_pib']), 1)}% do PIB em {mb['ano']}, contra {br(float(memg['juros_liquidos_pct_pib']), 1)}% no grupo de emergentes do FMI) com primário perto de zero ({br(float(mb['primario_pct_pib']), 1)}%), e o maior juro básico real ex-post ({br(float(mb['taxa_basica_real_dez2025_pct']), 1)}%, contra {br(float(seg_tb['taxa_basica_real_dez2025_pct']), 1)}% em {nm(seg_tb['pais'])}, o segundo){n('weo')}{n('bis')}.</p>
<p><b>Taxa ou tamanho da dívida.</b> Os juros do ano são a taxa implícita vezes a dívida do ano anterior. O Brasil paga {br(float(dbra['juro_implicito_pct']), 1)}% sobre uma base de {br(float(dbra['base_divida_pct_pib']), 0)}% do PIB. A tabela separa quanto da diferença para cada país vem da taxa e quanto do tamanho da dívida{n('weo')}.</p>
<table><thead><tr><th>Comparado com</th><th class=n>Juros, % PIB</th><th class=n>Juros líquidos sobre dívida bruta</th><th class=n>Base da dívida, % PIB</th><th class=n>Diferença do Brasil</th><th class=n>Pela taxa</th><th class=n>Pelo tamanho</th></tr></thead><tbody>{linhas_md}</tbody></table>
<p class=nota>FMI, WEO de outubro de 2026, governo geral, último ano observado{n('weo')}. Base = dívida bruta do ano anterior medida sobre o PIB do ano (juros líquidos divididos pela razão entre juros líquidos e dívida bruta). A razão não é a taxa paga, porque mistura juros líquidos com dívida bruta, e por isso a parte atribuída à taxa é uma aproximação. A diferença é repartida pela média dos dois caminhos possíveis, e as duas partes somam a diferença. Emergente mediano. Taxa mediana vezes base mediana dos dez emergentes, sem os EUA. A dívida do Brasil no FMI inclui os títulos na carteira do BC, o que aumenta a base e reduz a taxa. No México, a conta inclui Pemex e CFE. A conta separa taxa de estoque, mas não explica a taxa. Inflação, prêmio de risco, prazo e indexação da dívida e política monetária ficam juntos no mesmo número.</p>
<p>Contra o emergente mediano, {br(float(dmed['efeito_taxa_pp']), 1)} dos {br(float(dmed['brasil_menos_comparador_pp']), 1)} pontos do PIB de diferença vêm da taxa e {br(float(dmed['efeito_estoque_pp']), 1)} do tamanho da dívida. A taxa pesa mais que o tamanho contra {lista(md_taxa)}. O tamanho pesa mais contra {lista(md_est)}.</p>
{sec_custo}"""

sec_juro = f"""<h2>11. Juro real de longo prazo, inflação implícita e eventos fiscais</h2>
<figure>{svg('11-juro-real')}</figure>
<p class=nota>Taxas de compra do Tesouro Direto, vértice de 10 anos interpolado nas NTN-B e NTN-F, inflação implícita pela fórmula de Fisher, média mensal, até 15/10/2026{n('td')}. Meta Selic por reunião do Copom{n('copom')}. As linhas verticais marcam os eventos da tabela abaixo.</p>
<p><b>Quanto veio do mundo.</b> O juro real de 10 anos também sobe e cai fora do Brasil. Descontando o juro real do título americano de 10 anos indexado à inflação{n('fred')}, sobra a diferença entre os dois.</p>
<table style="break-inside:avoid"><thead><tr><th>Governo, média mensal</th><th class=n>Juro real 10 anos, Brasil</th><th class=n>Juro real 10 anos, EUA</th><th class=n>Diferença, pontos</th></tr></thead><tbody>{linhas_rs}</tbody></table>
<p class=nota>% ao ano. Brasil pela NTN-B interpolada em 10 anos{n('td')}, EUA pela média mensal da série DFII10{n('fred')}, nos mesmos meses de cada mandato. A taxa de compra do Tesouro Direto fica alguns pontos-base abaixo da taxa de mercado, e o desvio é quase constante e não muda as diferenças entre governos.</p>
<p>Do governo Bolsonaro para o Lula 3, o juro real brasileiro de 10 anos subiu {br(d_br, 2)} pontos e o americano, {br(d_us, 2)}. Sobram {br(d_br - d_us, 2)} ponto que não acompanharam os EUA. Esse resto inclui fatores domésticos, mas também o prêmio cobrado de emergentes, a liquidez dos títulos e o apetite global por risco. A subtração não isola o efeito de um governo. O resultado depende da janela. Só com anos completos do Lula 3 (2023 a 2025), a diferença média foi {br(rs_m(2023, 2025), 2)}, {br(rs_m(2023, 2025) - rs_m(2019, 2022), 2)} ponto acima da de 2019 a 2022. Por ano, a diferença para os EUA foi {', '.join(br(rs_ano[str(a)], 2) for a in range(2019, 2023))} de 2019 a 2022 e {', '.join(br(rs_ano[str(a)], 2) for a in range(2023, 2027))} de 2023 a 2026. Foi a menor da série em 2019, subiu no fim do governo Bolsonaro e de novo em 2025 e 2026.</p>
<table><thead><tr><th>Governo</th><th class=n>Juro real 10 anos</th><th class=n>Inflação implícita 10 anos</th><th class=n>Selic meta média</th><th class=n>Juro real implícito da dívida</th></tr></thead><tbody>{linhas_n}</tbody></table>
<p class=nota>% ao ano. Médias dos dias úteis pela data exata do mandato (Dilma até 12/05/2016), Lula 2 desde jan/2008. Juro real implícito da dívida. Custo médio da dívida federal em 12 meses até dezembro{n('rmd')}, descontado o IPCA do ano{n('ipca')}.</p>
<table><thead><tr><th class=n>#</th><th class=n>Data</th><th>Evento</th><th>Governo</th><th class=n>Juro real 10a, pb</th><th class=n>Inflação implícita 10a, pb</th></tr></thead><tbody>{linhas_ev}</tbody></table>
<p class=nota>Variação entre o 5º dia útil antes e o 5º depois, em pontos-base, sem controle de outros fatores{n('td')}. Datas de votação e promulgação na Câmara e no Planalto{n('camara_eventos')}. Para comparar. Em qualquer janela de 10 dias desde 2008, a variação absoluta tem mediana de {br(med_r, 1)} pb no juro real e {br(med_i, 1)} pb na inflação implícita, e o percentil 90 é {br(p90_r, 0)} pb e {br(p90_i, 0)} pb. Em negrito, o que passa do percentil 90. A janela capta tudo o que ocorreu no período, além do evento.</p>
<p>As maiores variações na janela de eventos fiscais foram a alta de {sinal(ev('Pacote')['var_inflacao_implicita_10a_pb'])} pb na inflação implícita após o pacote de novembro de 2024 e de {sinal(ev('PLP 210')['var_juro_real_10a_pb'])} pb no juro real após a votação do PLP 210, e a queda de {sinal(ev('Anuncio')['var_inflacao_implicita_10a_pb'])} pb na inflação implícita após o anúncio do arcabouço. São variações no tempo, e a janela não separa decisões do Copom, surpresas de inflação, câmbio e mercado externo, e parte dos eventos já era esperada antes da data. Os números são compatíveis com um prêmio de risco fiscal no juro longo, mas não bastam para medi-lo.</p>"""

# ---------- v6: ponte entre divida bruta e liquida e vendas de ativos (frente J)
JP = {}
for r in le('J-ponte-por-mandato.csv'): JP.setdefault(r['serie'], {})[r['ano']] = r
JM = [('Lula 2', '2007-2010'), ('Dilma', '2011-2015'), ('2016', '2016-2016'), ('Temer', '2017-2018'), ('Bolsonaro', '2019-2022'), ('Lula 3', '2023-2025')]
jp = lambda k, m: float(JP[k][m]['valor_pct_pib']) if JP[k][m]['valor_pct_pib'] else None
jr = lambda k, m: float(JP[k][m]['valor_rs_mi']) / 1000 if JP[k][m]['valor_rs_mi'] else None
BCB_COB = {'2019-2022': ' (só 2020 e 2022)', '2023-2025': ' (só 2025)'}
LJ = [('Dívida bruta, variação (pontos do PIB)', lambda m: br(jp('dbgg_variacao', m), 1)),
      ('Dívida líquida, variação (pontos do PIB)', lambda m: br(jp('dlsp_variacao', m), 1)),
      ('Dívida bruta, variação (R$ bi)', lambda m: br(jr('dbgg_variacao', m), 0)),
      ('Dívida líquida, variação (R$ bi)', lambda m: br(jr('dlsp_variacao', m), 0)),
      ('Diferença líquida menos bruta só pelo crescimento do PIB (pontos)', lambda m: br(jp('dlsp_menos_dbgg_efeito_denominador_pib', m), 1)),
      ('Devoluções antecipadas do BNDES ao Tesouro (R$ bi)', lambda m: br(jr('soma_bndes_liquidacao_antecipada', m), 1)),
      ('Resultado do BC recebido, pelo relatório da dívida (R$ bi)', lambda m: (br(jr('soma_bcb_resultado_recebido_pelo_tesouro', m), 1) + BCB_COB[m]) if m in BCB_COB else 'não separado'),
      ('Privatizações, efeito na dívida líquida (pontos)', lambda m: br(jp('dlsp_ajuste_privatizacoes', m), 2)),
      ('Concessões no primário (R$ bi)', lambda m: br(jr('soma_rtn_1_4_1_concessoes_e_permissoes', m), 1)),
      ('Dividendos no primário (R$ bi)', lambda m: br(jr('soma_rtn_1_4_2_dividendos_e_participacoes', m), 1)),
      ('<b>Dívida bruta sem as devoluções do BNDES</b> (pontos)', lambda m: '<b>' + br(jp('dbgg_variacao_sem_bndes_antecipado', m), 1) + '</b>'),
      ('<b>Idem, sem BNDES e sem o resultado do BC</b> (pontos)', lambda m: '<b>' + br(jp('dbgg_variacao_sem_bndes_antecipado_e_sem_resultado_bcb', m), 1) + '</b>' + (' parcial' if m in BCB_COB else ''))]
# fluxos BC e Tesouro por exercicio (STN Relatorio Especial 2019, Tabela 1; DF do BCB), brutos/J/build_bcb_tesouro.py
BT = le(os.path.join('brutos', 'J', 'bcb-tesouro-transferencias.csv'))
def bt(m, sentido):
  a0, a1 = map(int, m.split('-'))
  return sum(float(r['valor_rs_mi']) for r in BT if r['valor_rs_mi'] and r['sentido'] == sentido and r['tipo'] != 'uso_na_dpmf'
             and r['forma'] in ('dinheiro', 'titulos') and a0 <= int(r['ano']) <= a1) / 1000
LJ.insert(7, ('Do BC ao Tesouro, em dinheiro (R$ bi)', lambda m: br(bt(m, 'bc_para_tn'), 1)))
LJ.insert(8, ('Do Tesouro ao BC, em títulos (R$ bi)', lambda m: br(bt(m, 'tn_para_bc'), 1)))
LJ = [x for x in LJ if not x[0].startswith('<b>Idem, sem BNDES e sem o resultado do BC')]
bt_0818 = sum(float(r['valor_rs_mi']) for r in BT if r['valor_rs_mi'] and r['sentido'] == 'bc_para_tn' and r['tipo'] in ('resultado_operacional', 'equalizacao_cambial') and 2008 <= int(r['ano']) <= 2018) / 1000
tb_0818 = sum(float(r['valor_rs_mi']) for r in BT if r['valor_rs_mi'] and r['sentido'] == 'tn_para_bc' and 2008 <= int(r['ano']) <= 2018) / 1000
assert abs(bt_0818 - 1015.5) < 0.1, bt_0818  # STN Relatorio Especial 2019, p. 27: R$ 1.015,5 bi
linhas_j = ''.join(f"<tr><td>{rot}</td>" + ''.join(f"<td class=n>{f(m)}</td>" for _, m in JM) + '</tr>' for rot, f in LJ)
BJ = '2019-2022'
al0, al1 = JP['ativos_liquidos_inicio'][BJ], JP['ativos_liquidos_fim'][BJ]
pib0, pib1 = float(JP['pib_12m_inicio'][BJ]['valor_rs_mi']), float(JP['pib_12m_fim'][BJ]['valor_rs_mi'])
# divida bruta ano a ano, com presidente: % do PIB, R$ correntes e R$ de dez/2025 (brutos/I/build_dbgg_anual.py)
for r in DA:
  if r['periodo'].isdigit(): assert abs(float(r['dbgg_pct_pib']) - DV['dbgg'][int(r['periodo'])]) < 0.005, r['periodo']
da = {r['periodo']: r for r in DA}
ult_da = DA[-1]
sg = lambda v, d=1: ('+' if v > 0 else '') + br(v, d)
MDA = [('Lula 2 (2007-10)', '2006', '2010'), ('Dilma (2011-15)', '2010', '2015'), ('2016 (Dilma/Temer)', '2015', '2016'),
       ('Temer (2017-18)', '2016', '2018'), ('Bolsonaro (2019-22)', '2018', '2022'), (f"Lula 3 (até {ult_da['rotulo']})", '2022', ult_da['periodo'])]
dif = lambda c, a, b: float(da[b][c]) - float(da[a][c])
linhas_mda = ''.join(f"<tr><td>{nm}</td><td class=n>{sg(dif('dbgg_pct_pib', a, b))}</td><td class=n>{sg(dif('dbgg_rs_bi_correntes', a, b), 0)}</td>"
                     f"<td class=n>{sg(dif('dbgg_rs_bi_dez2025_ipca', a, b), 0)}</td></tr>" for nm, a, b in MDA)

DRA = {r['periodo'].split(' (')[0]: r for r in DR}
fa = lambda m, c: float(DRA[m][c + '_rs_bi_2025_por_ano'])
fs = lambda m, c: float(DRA[m][c + '_rs_bi'])
linhas_dr = ''.join(f"<tr><td>{r['periodo']}</td>" + ''.join(f"<td class=n>{br(float(r[c + '_rs_bi']), 0)}</td>" for c in ('variacao', 'juros_nominais', 'reposicao_inflacao', 'juro_real', 'emissoes_liquidas', 'cambio', 'outros', 'variacao_real'))
                    + f"<td class=n>{br(float(r['ipca_periodo_pct']), 1)}%</td></tr>" for r in DR)
sec_dreal = f"""<p><b>Por que a bruta subiu em reais.</b> O BCB decompõe a variação da dívida bruta em juros nominais, emissões líquidas (o que se emitiu além dos juros, menos o que se resgatou), câmbio e ajustes{n('j_bcb')}. Separando dos juros a parte que só repõe a inflação sobre o saldo, sobra o juro real. A variação real do estoque é o juro real mais as emissões, o câmbio e os ajustes{n('ipca')}.</p>
<figure>{svg('6c-divida-fatores-reais')}</figure>
<table style="break-inside:avoid"><thead><tr><th>R$ bi correntes, soma do mandato</th><th class=n>Variação</th><th class=n>Juros nominais</th><th class=n>Repõe inflação</th><th class=n>Juro real</th><th class=n>Emissões líquidas</th><th class=n>Câmbio</th><th class=n>Outros</th><th class=n>Variação real</th><th class=n>IPCA</th></tr></thead><tbody>{linhas_dr}</tbody></table>
<p class=nota>Fatores condicionantes da dívida bruta, BCB, ano fechado{n('j_bcb')}. Reposição da inflação. IPCA do ano vezes o saldo de dezembro anterior, uma aproximação que ignora o fluxo dentro do ano{n('ipca')}. Gráfico. Média por ano do mandato, cada fluxo anual em R$ de dez/2025. A variação real é a variação nominal menos a reposição da inflação, e a soma dos fatores reais é igual a ela por construção. A reposição usa o saldo de dezembro anterior e ignora os fluxos dentro do ano. Os juros incluem os das operações compromissadas do BC, que seguem a Selic. Emissões líquidas pequenas convivem com déficit primário, porque o déficit também é pago com o caixa da Conta Única, alimentado por resultado do BC e devoluções do BNDES (tabela abaixo).</p>
<p>Em todos os governos o aumento da bruta em reais correntes ficou perto dos juros nominais, e as emissões líquidas foram pequenas ou negativas fora do governo Dilma (R$ {br(fs('Dilma', 'emissoes_liquidas'), 0)} bi). A diferença entre governos está em quanto dos juros foi juro real. No governo Bolsonaro, com o IPCA de {br(float(DRA['Bolsonaro']['ipca_periodo_pct']), 1)}% no mandato, R$ {br(fs('Bolsonaro', 'reposicao_inflacao'), 0)} bi dos R$ {br(fs('Bolsonaro', 'juros_nominais'), 0)} bi de juros só repuseram a inflação, e o estoque cresceu R$ {br(fa('Bolsonaro', 'variacao_real'), 0)} bi por ano em termos reais. No Lula 3, com IPCA de {br(float(DRA['Lula 3']['ipca_periodo_pct']), 1)}% em três anos, o juro real foi de R$ {br(fa('Lula 3', 'juro_real'), 0)} bi por ano, e o estoque real cresceu R$ {br(fa('Lula 3', 'variacao_real'), 0)} bi por ano. É uma decomposição contábil. Inflação alta corrói a dívida, e juro real alto depende da Selic, do prêmio de risco e do saldo herdado. A meta Selic média foi de {br(selic_m('Bolsonaro'), 1)}% no governo Bolsonaro e {br(selic_m('Lula 3'), 1)}% no Lula 3 (seção 11). A relação entre fiscal, expectativas e Selic está na seção 13.</p>
<p><b>Que primário estabiliza a bruta.</b> A razão dívida/PIB fica parada quando o primário é igual a (i - g) / (1 + g) vezes a dívida, com i o juro nominal implícito e g o crescimento nominal do PIB. Em 2025, i foi {br(100 * i_est, 2)}% (juros nominais sobre o saldo de dez/2024){n('j_bcb')}, g foi {br(100 * g_est, 2)}%{n('rtn')} e a dívida bruta fechou em {br(d_est, 1)}% do PIB{n('bcbdiv')}. O primário que a estabiliza é {br(p_est(i_est), 1)}% do PIB, pela aritmética do estoque, qualquer que seja o governo. Com juro implícito de 11% e o mesmo crescimento, seria {br(p_est(0.11), 1)}%, e com 10%, {br(p_est(0.10), 1)}%. O primário do Governo Central em 2025 foi de {br(res_pib[2025], 1)}% do PIB{n('rtn')}. A conta parte da dívida de dez/2025 porque olha para frente, supõe g fixo (se o juro cai porque a inflação cai, o crescimento nominal também cai e a exigência diminui menos), ignora os ajustes entre fluxo e estoque (câmbio, reconhecimento de dívidas) e compara o primário do Governo Central com a dívida do governo geral, perímetros diferentes.</p>"""
# Grafico da regra (leitura de design por agente de IA, recomendacao 7): primario observado contra o primario que estabiliza a bruta, 2007 a 2030.
# Observado: Governo Central (RTN). Que estabiliza: (i - g)/(1 + g) vezes a divida do ano, i = juros nominais do ano sobre o saldo de
# dezembro anterior (BCB, fatores da DBGG), g = crescimento do PIB nominal. De 2026 a 2030, cenario 2 do S-cenarios-divida.csv.
RA = [a for a in range(2007, 2026) if ('dbgg_fat_juros_nominais', a) in JF and ('dbgg_fat_saldo', a - 1) in JF and a in PIBK and a - 1 in PIBK]
def p_est_ano(a):
  i_ = JF[('dbgg_fat_juros_nominais', a)] / JF[('dbgg_fat_saldo', a - 1)]; g_ = PIBK[a] / PIBK[a - 1] - 1
  return 100 * (i_ - g_) / (1 + g_) * DV['dbgg'][a - 1] / 100  # divida do ano anterior, como no simulador (auditoria v13, E4)
REGRA = {a: (res_pib[a], p_est_ano(a)) for a in RA if a - 1 in DV['dbgg']}
RSIM = {a: (sc(C['2'], a, 'primario_pct_pib'), sc(C['2'], a, 'primario_estabiliza')) for a in range(2026, 2031)}
fig, ax = plt.subplots(figsize=(LARG, 2.9))
faixas(ax, ini=2007); ax.axvspan(2025.5, 2030.5, color='white', lw=0, zorder=0)
xo = sorted(REGRA); xs = [2025] + sorted(RSIM)
ob = [REGRA[a][0] for a in xo]; es = [REGRA[a][1] for a in xo]
sob = [REGRA[2025][0]] + [RSIM[a][0] for a in xs[1:]]; ses = [REGRA[2025][1]] + [RSIM[a][1] for a in xs[1:]]
ax.fill_between(xo, ob, es, color='#e2e2e2', lw=0, zorder=1); ax.fill_between(xs, sob, ses, color='#efefef', lw=0, zorder=1)
ax.plot(xo, es, color=AZUL, lw=1.5, zorder=3); ax.plot(xs, ses, color=AZUL, lw=1.5, ls='--', zorder=3)
ax.plot(xo, ob, color=ESCURO, lw=1.5, zorder=3); ax.plot(xs, sob, color=ESCURO, lw=1.5, ls='--', zorder=3)
ax.axhline(0, color=ESCURO, lw=0.6)
ax.text(2030.6, RSIM[2030][1], 'primário que\nestabiliza', fontsize=7.2, va='center', color=ESCURO)
ax.text(2030.6, RSIM[2030][0], 'primário', fontsize=7.2, va='center', color=ESCURO)
ax.text(2028, 1.0, 'cenário 2, simulado', transform=ax.get_xaxis_transform(), ha='center', va='bottom', fontsize=6.5, color=CINZA)
ax.set_xlim(2006.5, 2033); ax.set_ylim(-11, 7); ax.set_ylabel('% do PIB')
fig.tight_layout(); fig.savefig(f'{G}/9a-regra-primario.svg'); plt.close(fig)
GAP_ANOS = [a for a in xo if REGRA[a][0] >= REGRA[a][1]]
GAP_ULT = max(GAP_ANOS)
sec_regra = f"""<p><b>A regra, ano a ano.</b> O gráfico põe lado a lado o primário do Governo Central e o primário que pararia a dívida bruta naquele ano, pela identidade com a dívida de dezembro do ano anterior, a mesma dos cenários. Por isso o valor de 2025 no gráfico difere um pouco da conta do parágrafo acima, que olha para frente com a dívida de dez/2025. De {xo[0]} a {xo[-1]}, o primário ficou acima do que estabilizaria em {len(GAP_ANOS)} dos {len(xo)} anos, o último em {GAP_ULT}. Em 2021 e 2022 isso veio do crescimento nominal alto, com a inflação, e não de superávit grande (primário de {br(res_pib[2021], 1)}% e {br(res_pib[2022], 1)}% do PIB). Em {xo[-1]} a distância foi de {br(REGRA[xo[-1]][1] - REGRA[xo[-1]][0], 1)} pontos do PIB. No cenário 2 da seção 12 (primário do PLDO, macro do Focus), ela é de {br(RSIM[2030][1] - RSIM[2030][0], 1)} pontos em 2030. A conta é a mesma para qualquer governo e só depende de juro, crescimento e tamanho da dívida.</p>
<figure>{svg('9a-regra-primario')}</figure>
<p class=nota>Primário do Governo Central, % do PIB{n('rtn')}. Primário que estabiliza a dívida bruta do governo geral, (i - g)/(1 + g) vezes a dívida de dezembro do ano anterior, com i os juros nominais do ano sobre o saldo de dezembro anterior{n('j_bcb')}, g o crescimento do PIB nominal{n('rtn')} e a dívida{n('bcbdiv')}. Perímetros diferentes (Governo Central no primário, governo geral na dívida), como na seção 12. De 2026 a 2030, cenário 2, simulado e tracejado.</p>"""

sec_dbgg = f"""<p><b>Dívida bruta em reais.</b> Dezembro de cada ano e o último mês publicado (barra clara), critério Bacen{n('bcbdiv')}. Barras em reais de dez/2025, deflacionadas pelo IPCA do mês{n('ipca')}, a linha é o valor corrente. O % do PIB de cada ano está no gráfico acima.</p>
<figure>{svg('6b-divida-reais')}</figure>
<table style="break-inside:avoid"><thead><tr><th>Mandato, dezembro anterior ao último dado</th><th class=n>Pontos do PIB</th><th class=n>R$ bi correntes</th><th class=n>R$ bi de dez/2025</th></tr></thead><tbody>{linhas_mda}</tbody></table>
<p class=nota>A série nesse critério começa em dez/2006 (BCB, histórico refeito em 2018 sem Petrobras e Eletrobras), por isso não há Lula 1 inteiro nem FHC. Até 2017 vale a edição mais nova de cada ano, dez/2017 é 74,07% na edição de jan/2019 e 73,74% com o PIB revisado depois. De dez/2018 em diante, uma só safra (SGS 13761 e 13762). No critério FMI, que conta todos os títulos na carteira do BC, a dívida é maior ({br(dbgg_fmi, 1)}% em {ult_da['rotulo']}). O ano de {ult_da['rotulo'][-4:]} está incompleto.</p>"""
sec_ponte = f"""<p><b>Bruta, líquida e venda de ativos.</b> A dívida líquida desconta os ativos do setor público (créditos ao BNDES, reservas, depósitos no BC), a bruta não. Vender ativo ou receber de volta um empréstimo reduz a bruta sem mudar a líquida, e dividendos e concessões entram como receita no primário. A tabela mostra isso para cada governo{n('j_bcb')}{n('bndes')}{n('rad')}.</p>
<table><thead><tr><th>Dezembro a dezembro</th>{''.join(f'<th class=n>{g}</th>' for g, _ in JM)}</tr></thead><tbody>{linhas_j}</tbody></table>
<p class=nota>Dívida e ajustes. BCB, tabelas de estatísticas fiscais (dívida bruta, composição da dívida líquida, fatores e ajustes){n('j_bcb')}. Devoluções do BNDES. Página de transparência do BNDES, atualizada em 14/10/2026{n('bndes')}. Resultado do BC recebido. Relatórios Anuais da Dívida, onde o relatório separa a origem{n('rad')}. Fluxos entre BC e Tesouro. Equalização cambial e resultado do BC por exercício do balanço, em dinheiro para o Tesouro e em títulos para o BC, desde 2008 (Lula 2 sem 2007){n('stnbc')}. Concessões e dividendos. RTN{n('rtn')}. Vendas de BR Distribuidora, TAG e NTS foram da Petrobras, que fica fora das duas dívidas.</p>
<p>No governo Bolsonaro, em reais, a bruta e a líquida subiram quase o mesmo (R$ {br(jr('dbgg_variacao', BJ) / 1000, 2)} tri e R$ {br(jr('dlsp_variacao', BJ) / 1000, 2)} tri). Os ativos líquidos ficaram parados (R$ {br(float(al0['valor_rs_mi']) / 1e6, 2)} tri para R$ {br(float(al1['valor_rs_mi']) / 1e6, 2)} tri) enquanto o PIB nominal cresceu {br(100 * (pib1 / pib0 - 1), 0)}%, e por isso caíram de {br(float(al0['valor_pct_pib']), 1)}% para {br(float(al1['valor_pct_pib']), 1)}% do PIB. A bruta foi reduzida por R$ {br(jr('soma_bndes_liquidacao_antecipada', BJ), 1)} bi de devoluções antecipadas do BNDES. Sem elas, cairia {br(abs(jp('dbgg_variacao_sem_bndes_antecipado', BJ)), 1)} ponto em vez de {br(abs(jp('dbgg_variacao', BJ)), 1)}{n('bndes')}. O resultado do BC passado ao Tesouro não entra nessa conta. De 2008 a 2018 o BC transferiu R$ {br(bt_0818, 1)} bi em dinheiro e recebeu R$ {br(tb_0818, 1)} bi em títulos, quase tudo resultado cambial das reservas, e esses fluxos aparecem em todos os governos. O próprio Tesouro escreve que eles não afetam a dívida líquida e que pagar dívida com esse caixa, quando o BC enxuga a liquidez com compromissadas, só muda a composição da bruta, sem reduzir o estoque{n('stnbc')}. Por isso o efeito do BC sobre a bruta não é somado. As devoluções começaram em 2015 e somaram R$ {br(jr('soma_bndes_liquidacao_antecipada', '2016-2016'), 1)} bi em 2016 e R$ {br(jr('soma_bndes_liquidacao_antecipada', '2017-2018'), 1)} bi no governo Temer. As privatizações pesaram pouco na dívida líquida em todos os governos (no máximo {br(abs(min(jp('dlsp_ajuste_privatizacoes', m) for _, m in JM)), 2)} ponto do PIB).</p>"""


# ---------- anexo: series ano a ano e arquivos de dados (pacote gastos-publicos-brasil-dados.zip, relatorio/monta_pacote.py)
import re
PRES_A = [(1995, 2002, 'FHC'), (2003, 2006, 'Lula 1'), (2007, 2010, 'Lula 2'), (2011, 2015, 'Dilma'), (2016, 2016, 'Dilma/Temer'), (2017, 2018, 'Temer'),
          (2019, 2022, 'Bolsonaro'), (2023, 2026, 'Lula 3')]
pres_a = lambda a: next(nm for i, f, nm in PRES_A if i <= a <= f)
anexo_div = ''.join(f"<tr><td>{r['rotulo']}</td><td>{r['presidente']}</td><td class=n>{br(float(r['dbgg_pct_pib']), 2)}</td><td class=n>{br(float(r['dbgg_rs_bi_correntes']), 1)}</td><td class=n>{br(float(r['dbgg_rs_bi_dez2025_ipca']), 1)}</td></tr>" for r in DA)
anexo_prim = ''.join(f"<tr><td>{a}</td><td>{pres_a(a)}</td><td class=n>{br(float(KR[a]['primario_cheio_pct_pib']), 2)}</td><td class=n>{br(float(KR[a]['primario_recorrente_pct_pib']), 2)}</td>"
                     f"<td class=n>{br(float(KR[a]['primario_estrutural_spe_pct_pib_potencial']), 2) if KR[a]['primario_estrutural_spe_pct_pib_potencial'] else ''}</td>"
                     f"<td class=n>{br(DV['dbgg'][a], 1) if a in DV['dbgg'] else ''}</td><td class=n>{br(dl[a], 1) if a in dl else ''}</td></tr>" for a in xk)
HJ = {int(r['ano']): r for r in le('H-por-cabeca-historico.csv') if r['bloco_id'] == 'juros'}
anexo_jur = ''.join(f"<tr><td>{a}</td><td>{pres_a(a)}</td><td class=n>{br(float(HJ[a]['valor_rs_bi_correntes']), 1)}</td><td class=n>{br(float(HJ[a]['valor_rs_bi_2025']), 1)}</td><td class=n>{br(int(HJ[a]['rs_2025_por_habitante']))}</td></tr>" for a in sorted(HJ))
PIB25K = next(float(r['pib_rs_mi']) for r in le('K-primario-recorrente.csv') if r['ano'] == '2025')
# ---------- v10: quanto a politica fiscal pode reduzir os juros (frentes W, X, Y e extensao de S)
WS = le('W-selic-real.csv'); WC = le('W-curva-mensal.csv'); WD = le('W-dpf-estrutura.csv'); WP = le('W-juros-perimetros.csv')
XR = le('X-regressoes.csv'); XE = le('X-comparacao-emergentes.csv'); YL = le('Y-literatura.csv')
SS = le('S-sensibilidade-juros.csv'); SCF = le('S-canal-fiscal.csv')
wsm = lambda m, c: float(next(r[c] for r in WS if r['tipo'] == 'media_mandato' and r['mes_ou_mandato'] == m))
DSR = [wsm('Lula 3', c) - wsm('Bolsonaro', c) for c in ('selic_real_ex_ante_meta', 'selic_real_ex_ante_selic_esperada', 'selic_real_ex_post_12m_seguintes')]
wd25 = next(r for r in WD if r['periodo'] == '2025-12')
wdf = lambda c: float(wd25[c])
wp = lambda se, k='pct_pib': float(next(r[k] for r in WP if r['ano'] == '2025' and r['serie'] == se))
def xf(dep, esp):
  return float(next(r['fracao_do_delta'] for r in XR if r['tipo'] == 'decomposicao' and r['dependente'] == dep and r['especificacao'] == esp and r['variavel'] == 'TOTAL fatores externos'))
def xc(dep, esp, var):
  r = next(r for r in XR if r['tipo'] == 'coeficiente' and r['dependente'] == dep and r['especificacao'] == esp and r['variavel'] == var)
  return float(r['coef']), float(r['ep_hac']), r
ss = lambda tipo, x, c: float(next(r[c] for r in SS if r['choque'] == tipo and float(r['reducao_pp']) == x))
cf = lambda nome, a, c: float(next(r[c] for r in SCF if r['cenario'].startswith(nome) and r['ano'] == str(a)))
ESP_J = ['a_niveis', 'b_niveis', 'a_c_dif', 'a_c_2016_2026', 'a_c_sem_2020', 'a_c_em10', 'a_c_dgs10', 'j2019_niveis', 'j2019_dif', 'j2019_niveis_focus', 'j2019_dif_focus']
fr_j = [xf('juro_real_10a_br', e) for e in ESP_J]
fr_e = [xf('embi_br_pb', e) for e in ('a_niveis', 'b_niveis', 'a_c_dif', 'a_c_sem_2020', 'a_c_em10')]
XEM, XEF = {}, {}
for r in XE:
  if r['pais'].startswith('Mediana dos emergentes') and r['periodo'] == r['presidente']: XEM.setdefault(r['presidente'], float(r['diferenca_brasil_menos_pais_pp']))
  if r['pais'].startswith('Mediana fixa') and r['periodo'] == r['presidente']: XEF.setdefault(r['presidente'], float(r['diferenca_brasil_menos_pais_pp']))
XV = {('BR' if r['serie'].startswith('juro real 10 anos Brasil') else 'US' if r['serie'].startswith('DFII10') else 'DIF', r['presidente']): float(r['variacao_pontos']) for r in le('X-variacoes.csv')}

# grafico 15a: Selic meta, Selic real ex-ante e NTN-B 10 anos, mensal, com mandatos
fig, ax = plt.subplots(figsize=(LARG, 3.3)); faixas_d(ax)
ms = [r for r in WS if r['tipo'] == 'mensal']
for c, cor, nm, ls in (('selic_meta_media_mes', ESCURO, 'Selic meta', '-'), ('selic_real_ex_ante_meta', AZUL, 'Selic real ex-ante (meta menos IPCA esperado 12 meses, Focus)', '-')):
  pts = [(fx(r['mes_ou_mandato']), float(r[c])) for r in ms if r[c]]
  ax.plot([p[0] for p in pts], [p[1] for p in pts], ls, color=cor, lw=1.3, label=nm)
pts = [(fx(r['mes']), float(r['juro_real_ntnb_10a'])) for r in WC if r['juro_real_ntnb_10a']]
ax.plot([p[0] for p in pts], [p[1] for p in pts], '--', color='#5b8a5b', lw=1.2, label='juro real NTN-B 10 anos')
ax.axhline(0, color=CINZA, lw=0.6); ax.set_ylabel('% ao ano'); ax.tick_params(labelsize=7); ax.set_xlim(2008, 2026.85)
ax.set_xticks(range(2008, 2027, 2)); ax.set_yticks(range(-4, 17, 4))
ax.legend(fontsize=6.5, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.08), ncol=3)
fig.tight_layout(); fig.savefig(f'{G}/15a-selic-real.svg'); plt.close(fig)
# grafico 15b: economia acumulada 2027-2030 por tipo de reducao
fig, ax = plt.subplots(figsize=(LARG, 2.9))
XS = [0.5, 1.0, 1.5, 2.0, 3.0]
for j, (tipo, cor, nm) in enumerate((('selic', ESCURO, 'só Selic'), ('curva', AZUL, 'Selic e taxas de mercado'), ('premio', '#5b8a5b', 'só taxas de mercado (prêmio)'))):
  ax.bar([i + (j - 1) * 0.27 for i in range(5)], [ss(tipo, x, 'economia_acum_2027_2030_rs_bi') for x in XS], width=0.26, color=cor, label=nm)
ax.set_xticks(range(5)); ax.set_xticklabels([f'-{br(x, 1)} ponto' for x in XS], fontsize=7); ax.tick_params(labelsize=7)
ax.set_ylabel('R$ bi, 2027 a 2030'); ax.legend(fontsize=6.5, frameon=False, loc='upper left')
ax.set_title('Economia de juros da dívida bruta, próximo mandato (2027-2030), sobre o cenário 2', fontsize=8.5, loc='left')
fig.tight_layout(); fig.savefig(f'{G}/15b-sensibilidade.svg'); plt.close(fig)

lin_sens = ''.join(f"<tr><td>{nm}</td>" + ''.join(f"<td class=n>{br(ss(t, x, c), d)}</td>" for x in (0.5, 1.0, 3.0) for c, d in (('economia_2027_rs_bi', 0), ('economia_acum_2027_2030_rs_bi', 0), ('reducao_divida_2030_pp', 1))) + "</tr>"
                   for t, nm in (('selic', 'Só Selic'), ('curva', 'Selic e taxas de mercado'), ('premio', 'Só taxas de mercado')))
dg_m, dg_p = (float(next(r['reducao_divida_2030_pp'] for r in SS if r['choque'] == 'crescimento real' and float(r['reducao_pp']) == v)) for v in (-1.0, 1.0))
lin_canal = ''.join(f"<tr><td>{c}</td>" + ''.join(f"<td class=n>{br(cf(c + ' | canal fiscal ' + nv, 2030, 'divida_pct_pib'), 1)}</td>" for nv in ('baixo', 'central', 'alto'))
                    + f"<td class=n>{br(sc(c, 2030, 'divida_pct_pib') if not c.startswith('2.') else sc(c, 2030, 'divida_pct_pib'), 1)}</td></tr>"
                    for c in ('2. Primário do PLDO', '4. Ajuste pela receita', '4b. Ajuste pela despesa'))
Y05 = next(r for r in YL if r['id'] == 'Y05')
_m = re.findall(r'IC95 aproximado (\d+) a (\d+) pb \(todos\) e (\d+) a (\d+) pb \(grandes emissores\)', Y05['ic_ou_erro_padrao'])[0]
Y05IC = (float(_m[0]), float(_m[1])); Y05G = (float(re.search(r'(\d+) pb \(36 grandes emissores\)', Y05['magnitude']).group(1)), float(_m[2]), float(_m[3]))
FAIXA = {nv: float(re.search(r'\| ' + nv + r' \| (\d+) \|', open(os.path.join(RAIZ, 'brutos', 'Y', 'LEIAME.md'), encoding='utf-8').read()).group(1)) for nv in ('Baixo', 'Central', 'Alto')}
D_EST = sc(C['2'], 2030, 'primario_estabiliza') - float(nota_s['focus_primario'].split('/')[-1])
canal_c = -min(cf('4. Ajuste pela receita | canal fiscal central', a, 'choque_mercado_pp') for a in range(2027, 2031))
dfii = xc('juro_real_10a_br', 'a_niveis', 'dfii10'); dfii_d = xc('juro_real_10a_br', 'a_c_dif', 'dfii10')
nlit = len(YL); ncausal = sum(1 for r in YL if r['classe_evidencia'].startswith('causal'))
def clausula(t, lim=170):  # corta so em fim de clausula (ponto e virgula), nunca no meio de palavra
  t = t.strip()
  if len(t) <= lim: return t
  partes, out = t.split('; '), ''
  for pt in partes:
    if out and len(out) + len(pt) + 2 > lim: break
    out = pt if not out else out + '; ' + pt
  return out + ' (íntegra em Y-literatura.csv)'
_aut = lambda r: r['autores'].split(';')[0].split(' (')[0] + (' e outros' if ';' in r['autores'] else '')
lin_lit = ''.join(f"<tr><td>{_aut(r)} ({r['ano'][:4]}), {r['amostra_texto']}</td><td>{r['identificacao_texto']}</td><td>{r['resultado_texto']}</td><td>{r['limitacao_texto']}</td></tr>" for r in YL)

WCL = [r for r in WC if r['prefixado_1a'] and r['prefixado_3a'] and r['prefixado_5a']][-1]
_r1, _r3, _r5, _r10 = (float(WCL[c]) / 100 for c in ('prefixado_1a', 'prefixado_3a', 'prefixado_5a', 'prefixado_10a'))
FWD = {'0-1': 100 * _r1, '1-3': 100 * (((1 + _r3) ** 3 / (1 + _r1)) ** 0.5 - 1), '3-5': 100 * (((1 + _r5) ** 5 / (1 + _r3) ** 3) ** 0.5 - 1)}
# Selic do Focus mes a mes nas mesmas janelas da curva: meta do mes da curva, depois interpolacao linear ate a mediana de
# dezembro de cada ano (Focus de 09/10/2026); depois de dez/2030, mantida no ultimo valor
_fo = {int(r['DataReferencia']): r['Mediana'] for r in json.load(open(os.path.join(RAIZ, 'brutos', 'S', 'bcb-focus-olinda-anuais-out2026.json')))['value']
       if r['Data'] == '2026-10-09' and r['Indicador'] == 'Selic' and r['baseCalculo'] == 0 and r['IndicadorDetalhe'] is None}
_y0, _m0 = int(WCL['mes'][:4]), int(WCL['mes'][5:7])
_nos = [(0, float(next(r['selic_meta_fim_mes'] for r in NM if r['mes'] == WCL['mes'])))] + [((a - _y0) * 12 + 12 - _m0, v) for a, v in sorted(_fo.items())]
def _sel(k):
  for (k0, v0), (k1, v1) in zip(_nos, _nos[1:]):
    if k0 <= k <= k1: return v0 + (v1 - v0) * (k - k0) / (k1 - k0)
  return _nos[-1][1]
_med = lambda a, b: sum(_sel(k) for k in range(a + 1, b + 1)) / (b - a)
FOC = {'0-1': _med(0, 12), '1-3': _med(12, 36), '3-5': _med(36, 60)}
TP = re.search(r'mediana do prêmio de 10 anos de ([\d,]+)% ao ano', open(os.path.join(RAIZ, 'brutos', 'Y', 'LEIAME.md'), encoding='utf-8').read()).group(1)
lin_fwd = ''.join(f"<tr><td>{h} anos</td><td class=n>{br(FWD[h], 1)}</td><td class=n>{br(FOC[h], 1)}</td><td class=n>{br(FWD[h] - FOC[h], 1)}</td></tr>" for h in ('0-1', '1-3', '3-5'))
N2R = le('N2-resumo.csv'); N2E = le('N2-eventos.csv'); N2T = le('N2-retornos.csv'); Y2M = le('Y2-medidas.csv'); MC = le('S-montecarlo.csv')
n2 = lambda g, ind, jan, c: float(next(r[c] for r in N2R if r['grupo'] == g and r['indicador'] == ind and r['janela_dias'] == str(jan)))
lin_n2 = ''.join(f"<tr><td>{rot}</td>" + ''.join(f"<td class=n>{br(n2(g, ind, 1, 'media'), 1)} [{br(n2(g, ind, 1, 'ic_p2_5'), 1)}; {br(n2(g, ind, 1, 'ic_p97_5'), 1)}]</td>" for ind in ('juro_real_10a', 'inflacao_implicita_10a')) + "</tr>"
                 for g, rot in (('anuncio', 'Anúncios'), ('votacao', 'Votações'), ('promulgacao', 'Promulgações'), ('melhora', 'Melhora fiscal'), ('piora', 'Piora fiscal')))
n2_fam = [r for r in N2T if r['familia_1d'].startswith('principal') and not r['mesmo_t0_que'] and r['passa_p95_1d'] in ('sim', 'nao')]  # um teste por data: eventos no mesmo dia contam uma vez
n2_pass = sum(1 for r in n2_fam if r['passa_p95_1d'] == 'sim')
n2_bh = min(float(r['bh_1d']) for r in n2_fam if r['bh_1d'])
_mid = lambda r: re.sub(r'[a-z]$', '', r['id'])  # M07a e M07b sao a mesma medida
y2_cons = [r for r in Y2M if r['motivacao_classe'].startswith('consolida')]
y2_nmed, y2_ncons = len({_mid(r) for r in Y2M}), len({_mid(r) for r in y2_cons})
y2_m13 = next(float(r['razao_realizado_sobre_anunciado']) for r in Y2M if r['id'] == 'M13')
y2_3 = sum(1 for r in y2_cons if r['etapas_medidas'] == '3')
y2_r = lambda dire: sorted(float(r['razao_realizado_sobre_anunciado']) for r in Y2M if r['razao_realizado_sobre_anunciado'] and (float(r['anunciado_pct_pib']) > 0) == (dire == 'melhora'))  # positivo melhora o primario (LEIAME de Y2)
_md = lambda xs: (xs[len(xs) // 2] if len(xs) % 2 else (xs[len(xs) // 2 - 1] + xs[len(xs) // 2]) / 2) if xs else float('nan')
mc = lambda c, k: float(next(r[k] for r in MC if r['cenario'] == c and r['ano'] == '2030' and r['variavel'] == 'divida_pct_pib'))
sec_fiscal = f"""<h2>13. Quanto a política fiscal pode efetivamente reduzir os juros da dívida brasileira?</h2>
<p>A seção separa três afirmações. A primeira, reformas fiscais podem reduzir o custo de financiamento do Estado. A segunda, uma agenda específica conseguirá aprová-las. A terceira, as reformas reduzirão os juros na magnitude e no prazo anunciados. Os dados tratam da primeira e da terceira. Sobre a segunda, nenhum dos dois programas do 2º turno registrados no TSE traz trajetória numérica de primário para 2027-2030{n('tse')}. Cada conclusão leva uma classe. <b>A</b> é demonstrado pelos dados, <b>B</b> é compatível com os dados sem identificação causal e <b>C</b> não está demonstrado. Metodologia, regressões e a lista de estudos estão no Anexo C.</p>
<p><b>Três medidas de juros que não se somam.</b> Em 2025 os juros nominais foram {br(wp('nfsp_juros_nominais_consolidado'), 2)}% do PIB no setor público consolidado (custo fiscal agregado, líquido de ativos){n('bcb')}, {br(100 * wp('dpf_juros_apropriados_total', 'valor_rs_bi') / (PIB25K / 1000), 2)}% na dívida pública federal (o que o Tesouro paga sobre os títulos) e {br(wp('dbgg_juros_nominais_total'), 2)}% na dívida bruta do governo geral, que inclui as compromissadas do BC ({br(wp('c2a_juros_compromissadas_bcb'), 2)} ponto){n('bcbdiv')}{n('rmd')}. A bruta passa a consolidada pelos juros recebidos sobre créditos do governo, pelo rendimento das reservas e pelo resultado dos swaps cambiais. Custo e transmissão usam a dívida federal, a sustentabilidade usa a bruta e o custo agregado usa a consolidada.</p>
<p><b>Como a Selic chega ao custo.</b> Em dez/2025, {br(wdf('pct_taxa_flutuante'), 0)}% da dívida federal seguia a Selic, {br(wdf('pct_indice_precos'), 0)}% a inflação e {br(wdf('pct_prefixado'), 0)}% era prefixada. O prazo médio era de {br(wdf('prazo_medio_dpf_anos'), 1)} anos e {br(wdf('vincendo_12m_dpf_pct'), 1)}% vencia em 12 meses{n('rmd')}. O estoque custou {br(wdf('custo_medio_dpf_12m'), 2)}% em 12 meses e as emissões, {br(wdf('custo_emissoes_dpmfi_12m'), 2)}%. O prefixado de 10 anos estava no mercado a {br(wdf('mercado_prefixado_10a_media_12m'), 2)}%{n('rmd')}{n('td')}. O custo médio fica abaixo do mercado porque o estoque guarda papéis antigos. A parte que segue a Selic muda no mês seguinte. Nas NTN-B, a inflação entra todo mês pelo principal corrigido, mas a taxa real contratada só muda quando o título vence e é rolado. Nos prefixados, a taxa nominal também só muda na rolagem. <b>Classe A.</b></p>
<figure>{svg('15a-selic-real')}</figure>
<p class=nota>Selic meta média do mês{n('copom')}, Selic real ex-ante = meta menos a mediana do IPCA esperado para 12 meses no Focus{n('olinda_ipca')}, NTN-B de 10 anos interpolada{n('td')}. Médias por mandato no Anexo C.</p>
<p><b>A Selic foi o principal canal imediato de transmissão para o custo.</b> A Selic real ex-ante teve média de {br(wsm('Bolsonaro', 'selic_real_ex_ante_meta'), 1)}% no governo Bolsonaro e {br(wsm('Lula 3', 'selic_real_ex_ante_meta'), 1)}% no Lula 3{n('olinda_ipca')}. Conforme a medida (com a meta, com a Selic esperada ou ex-post), a diferença vai de {br(min(DSR), 1)} a {br(max(DSR), 1)} pontos (Anexo C). Na dívida federal, a contribuição da Selic ao custo foi a que mais subiu entre os dois períodos (seção 10). Na dívida bruta, {br(100 * float(nota_s['peso_selic']), 0)}% do estoque paga a Selic, somando títulos e compromissadas do BC. A Selic é decisão do Copom, com autonomia desde 2021{n('lc179')}, e responde a inflação, expectativas, atividade e condições fiscais. Sem estimar a função de reação do Banco Central, não se separa quanto de cada determinante está na Selic. <b>Classe A</b> para a contribuição contábil, <b>C</b> para a causa econômica da diferença.</p>
<p><b>O circuito completo.</b> Resultado fiscal e trajetória da dívida afetam as expectativas de inflação e o prêmio de risco. O Copom fixa a Selic olhando inflação esperada, atividade e condições financeiras. Selic e taxas de mercado definem o custo da dívida, que volta ao resultado nominal e à própria dívida. Juros externos e câmbio entram nas taxas de mercado. Os efeitos são interdependentes e correm nos dois sentidos. O que os dados identificam bem é o último elo, o mecânico, que diz quanto uma mudança de Selic ou de taxas custa ou economiza. Os primeiros elos, do fiscal para as expectativas, para o prêmio e para a Selic, não estão identificados para o Brasil de hoje.</p>
<p><b>O que vem de fora.</b> Entre 2019-2022 e 2023-2026, o juro real brasileiro de 10 anos subiu {br(float(next(r['delta_pos_menos_pre'] for r in XR if r['tipo'] == 'decomposicao' and r['dependente'] == 'juro_real_10a_br' and r['especificacao'] == 'a_niveis' and r['variavel'] == 'TOTAL fatores externos')), 2)} pontos. Regressões de associação com o juro real americano, o VIX, o dólar e o spread de emergentes atribuem aos fatores externos de {br(100 * min(fr_j), 0)}% a {br(100 * max(fr_j), 0)}% dessa alta, conforme a especificação e a janela, perto de {br(100 * xf('juro_real_10a_br', 'a_niveis'), 0)}% em níveis de 2008 a 2026 e {br(100 * xf('juro_real_10a_br', 'a_c_dif'), 0)}% em primeiras diferenças. Restritas a 2019-2026, {br(100 * xf('juro_real_10a_br', 'j2019_niveis'), 0)}% em níveis e {br(100 * xf('juro_real_10a_br', 'j2019_dif'), 0)}% em diferenças{n('fred')}{n('td')}. Em níveis os resíduos são muito persistentes (autocorrelação perto de 0,95), sinal de tendência comum e risco de relação espúria. Em diferenças a persistência cai, mas a atribuição muda. Com a expectativa fiscal do Focus, a partilha muda de novo, porque os regressores andam juntos. O resultado informativo é a instabilidade, e estes modelos não identificam a contribuição externa. A descrição sem modelo também não é de mão única. De dez/2018 a dez/2022 o juro real brasileiro subiu {br(XV[('BR', 'Bolsonaro')], 2)} ponto e o americano {br(XV[('US', 'Bolsonaro')], 2)}. De dez/2022 a out/2026, o brasileiro subiu {br(XV[('BR', 'Lula 3')], 2)} e o americano {br(XV[('US', 'Lula 3')], 2)}. Contra a mediana fixa de cinco emergentes (África do Sul, Colômbia, Chile, Polônia e Hungria), o juro nominal de 10 anos do Brasil ficou {br(XEF['Bolsonaro'], 1)} pontos acima no governo Bolsonaro e {br(XEF['Lula 3'], 1)} no Lula 3. Com a mediana de composição variável, {br(XEM['Bolsonaro'], 1)} e {br(XEM['Lula 3'], 1)}{n('oecd')}. <b>Classe A</b> para as variações descritas, <b>C</b> para dizer quanto da alta veio de fora. A fração não é estável entre especificações, e o que sobra é um resíduo, sem medida de prêmio fiscal.</p>
<p><b>O que a curva já precifica.</b> Preços de mercado, projeções e simulações são coisas diferentes. A curva prefixada de {WCL['mes'][5:]}/{WCL['mes'][:4]} dá taxas a termo {('perto de ' + br(min(FWD.values()), 0) + '%') if round(min(FWD.values())) == round(max(FWD.values())) else ('de ' + br(min(FWD.values()), 1) + '% a ' + br(max(FWD.values()), 1) + '%')} ao ano para os próximos cinco anos{n('td')}. O Focus espera Selic média bem menor a partir do segundo ano{n('focus')}, e é essa Selic que o simulador usa.</p>
<table style="break-inside:avoid"><thead><tr><th>Prazo à frente</th><th class=n>Taxa a termo da curva prefixada, % a.a.</th><th class=n>Selic média do Focus no período, % a.a.</th><th class=n>Diferença, pontos</th></tr></thead><tbody>{lin_fwd}</tbody></table>
<p class=nota>Taxas a termo calculadas das taxas de 1, 3 e 5 anos do Tesouro Direto (média do mês, {WCL['dias_td']} pregões){n('td')}. Selic do Focus de 09/10/2026 nas mesmas janelas, mês a mês. A meta de {WCL['mes'][5:]}/{WCL['mes'][:4]}, interpolada até a mediana de dezembro de cada ano e mantida depois de 2030, último ano pesquisado{n('focus')}. As taxas do Tesouro Direto são de títulos, sem curva zero-cupom estimada (como a estrutura a termo da ANBIMA), e a média mensal mistura dias. Por isso as diferenças entre mercado e consenso são aproximações. A diferença inclui, além da expectativa, prêmio de prazo e de risco. O Banco Central estima mediana de {TP}% ao ano para o prêmio de prazo de 10 anos, de 2007 a abr/2025{n('lit')}. Por isso a curva serve mal como previsão da Selic, e o simulador com a Selic do Focus é mais favorável ao custo da dívida do que as taxas que o Tesouro paga hoje para emitir.</p>
<p><b>O que a literatura estabelece.</b> Dos {nlit} estudos revisados, {ncausal} têm identificação causal, mas nenhum deles mede o efeito do primário esperado sobre o juro longo. A faixa sai de estudos de associação{n('lit')}. No estudo que usa a mesma variável e a mesma taxa (primário esperado e juro nominal de 10 anos, emergentes com o Brasil), 1 ponto do PIB de melhora crível e persistente está associado a juros longos {br(FAIXA['Central'], 0)} pb menores após dois anos, com intervalo de confiança aproximado de {br(Y05IC[0], 0)} a {br(Y05IC[1], 0)} pb na amostra ampla. Na de grandes emissores, {br(Y05G[0], 0)} pb, com intervalo de {br(Y05G[1], 0)} a {br(Y05G[2], 0)} pb. O pico, perto de 31 a 36 pb, vem depois de dois anos e meio a três. O simulador usa {br(FAIXA['Baixo'], 0)}, {br(FAIXA['Central'], 0)} e {br(FAIXA['Alto'], 0)} pb como faixa de sensibilidade, que junta limites de duas amostras. A faixa não forma um intervalo de confiança único nem estima efeito causal para o Brasil. O efeito é maior com dívida alta e bancos muito expostos ao soberano. Estudos com outras variáveis fiscais dão ordens de grandeza parecidas e não entram no parâmetro. Para o Brasil, as regressões do Banco Central não encontram efeito estável do nível fiscal no nível do juro longo. Estudos de choque e de evento encontram efeitos maiores, mas transitórios. Regras fiscais têm associação com spreads menores, com identificação fraca. Nenhum estudo acha consolidação fiscal expansionista no curto prazo. O multiplicador estimado para a América Latina vai de perto de zero a cerca de 1. <b>Classe B</b> para a faixa, <b>C</b> para um coeficiente causal do Brasil de hoje.</p>
<figure>{svg('15b-sensibilidade')}</figure>
<table style="break-inside:avoid"><thead><tr><th rowspan=2>Redução desde 2027</th><th colspan=3 class=n>0,5 ponto</th><th colspan=3 class=n>1 ponto</th><th colspan=3 class=n>3 pontos</th></tr><tr>{'<th class=n>2027, R$ bi</th><th class=n>2027-30, R$ bi</th><th class=n>Dívida 2030, pontos</th>' * 3}</tr></thead><tbody>{lin_sens}</tbody></table>
<p class=nota>Sobre o cenário 2 da seção 12 (primário do PLDO, macro do Focus). Na linha só Selic, as taxas de mercado ficam paradas. Na linha só taxas de mercado, mudam o prefixado e a NTN-B novos, com a Selic parada, e a conta reprecifica pelo perfil de vencimentos de dez/2025 e pela emissão líquida nova, que sai à taxa de mercado{n('rmd')}. Economia acumulada pela trajetória do estoque, em R$ correntes. Taxas de mercado de {nota_s['mes_mercado'][5:]}/{nota_s['mes_mercado'][:4]} ({nota_s['dias_mes_mercado']} pregões até a consulta), o dado mais recente. Com {nota_s['ancora_alt_mes'][5:]}/{nota_s['ancora_alt_mes'][:4]}, último mês completo, a dívida de 2030 do cenário 2 seria {br(float(nota_s['ancora_alt_divida_2030_cenario2']), 1)}%, em vez de {br(sc(C['2'], 2030, 'divida_pct_pib'), 1)}%. Um ponto a mais ou a menos de crescimento real por ano muda a dívida de 2030 em {br(dg_p, 1)} e {br(dg_m, 1)} pontos.</p>
<p><b>Sensibilidade mecânica.</b> Um ponto a menos só na Selic economiza R$ {br(ss('selic', 1.0, 'economia_2027_rs_bi'), 0)} bi em 2027 e R$ {br(ss('selic', 1.0, 'economia_acum_2027_2030_rs_bi'), 0)} bi de 2027 a 2030. A mesma queda só nas taxas longas, R$ {br(ss('premio', 1.0, 'economia_2027_rs_bi'), 0)} bi e R$ {br(ss('premio', 1.0, 'economia_acum_2027_2030_rs_bi'), 0)} bi, porque chega ao custo só na rolagem. A economia acumulada cresce mais que proporcionalmente ao prazo porque o estoque menor também paga menos juros. <b>Classe A</b> como aritmética condicional, sobre reduções supostas.</p>
<table style="break-inside:avoid"><thead><tr><th>Dívida bruta em 2030, % do PIB</th><th class=n>Canal fiscal baixo ({br(FAIXA['Baixo'], 0)} pb)</th><th class=n>Central ({br(FAIXA['Central'], 0)} pb)</th><th class=n>Alto ({br(FAIXA['Alto'], 0)} pb)</th><th class=n>Seção 12, taxas 1,5 ponto menores (cenários 4 e 4b) ou sem canal (cenário 2)</th></tr></thead><tbody>{lin_canal}</tbody></table>
<p class=nota>Ilustrativo. No canal fiscal, a melhora da expectativa de primário de médio prazo reduz só as taxas de mercado (prefixado e NTN-B novos), pela faixa de sensibilidade da literatura, metade em 2027 e o efeito pleno desde 2028. A Selic segue o Focus. A expectativa é medida no mesmo perímetro dos dois lados, o setor público consolidado, como a média de 2027 a 2029 do primário projetado no PLDO{n('pldo27')} menos a do Focus{n('focus')} ({br(float(next(r['delta_expectativa_medio_prazo'] for r in SCF if r['cenario'].startswith('2. '))), 2)} ponto do PIB no cenário 2), mais a média das medidas extras dos cenários 4 e 4b, que são da União. O estudo de origem usa projeção de quatro anos, e aqui o horizonte comum disponível é de três. O estudo mede juro nominal e não separa juro real de inflação implícita. Aplicar o mesmo efeito à taxa real das NTN-B é premissa. Só nos prefixados, a dívida de 2030 no ajuste pela receita fica em {br(cf('4. Ajuste pela receita | canal fiscal central (26 pb) | so prefixados', 2030, 'divida_pct_pib'), 1)}%, contra {br(cf('4. Ajuste pela receita | canal fiscal central', 2030, 'divida_pct_pib'), 1)}% nas duas taxas. O canal entra uma vez, numa taxa. Não se soma ao choque de prêmio da seção 12, que é premissa direta.</p>
<p><b>Ajuste fiscal com transmissão associada à melhora do primário na literatura.</b> Aplicando a faixa da literatura ao ajuste pela receita, as taxas longas caem no máximo {br(100 * canal_c, 0)} pb no centro da faixa, e a dívida de 2030 fica em {br(cf('4. Ajuste pela receita | canal fiscal central', 2030, 'divida_pct_pib'), 1)}% do PIB, contra {br(sc(C['4'], 2030, 'divida_pct_pib'), 1)}% quando a seção 12 supõe todas as taxas 1,5 ponto menores. Os dois números impõem choques diferentes em taxas diferentes. Um corta Selic e taxas de mercado por premissa, o outro move só as taxas de mercado pela associação estimada em emergentes, que não é efeito causal identificado para o Brasil de 2027. A distância mostra quanto o resultado depende da premissa de juros. O ganho de juros grande depende de a Selic cair, o que pede inflação e expectativas na meta. A literatura não dá um coeficiente confiável do fiscal sobre a Selic. <b>Classe B</b>, e os números com o canal são ilustrativos. Dependem de como se mede a expectativa fiscal e de transplantar para o Brasil um coeficiente estimado para emergentes.</p>
<p><b>Choques fiscais. O que os eventos e as medidas mostram.</b> Com protocolo fixado antes dos resultados, o dossiê mediu a reação dos juros em {len(N2E)} eventos fiscais{n('n2')} de 2015 a 2026 (anúncios, votações e promulgações de medidas com impacto estimado de pelo menos 0,1% do PIB), descontando juro americano, VIX e dólar e comparando com 1.000 datas sorteadas sem evento{n('td')}{n('fred')}. Na janela de um dia, o juro real e a inflação implícita de 10 anos se mexem mais em datas fiscais do que por acaso ({n2_pass} de {len(n2_fam)} testes passam do percentil 95 do sorteio), mas não no sentido do conteúdo. Melhora e piora dão resultados parecidos, e nenhum resultado sobrevive à correção para testes múltiplos (menor q de {br(n2_bh, 2)}). Com o sorteio casado por trimestre, para descontar que os eventos se concentram em épocas voláteis, esse excesso fica menor e só aparece no juro real. Onde a expectativa de primário no Focus mudou de forma mensurável, a razão entre o movimento dos juros e a surpresa tem sinal instável entre versões do protocolo e intervalo que cruza o zero{n('focus')}. Nas janelas de 5 e 20 dias, melhoras e pioras sobem os juros juntas, sem assimetria detectável. Os poucos intervalos da tabela que excluem o zero (anúncios no juro real, votações na inflação implícita) não sobrevivem à correção.</p>
<table style="break-inside:avoid"><thead><tr><th>Janela de 1 dia, pb, média e intervalo de 95% pelo sorteio</th><th class=n>Juro real 10 anos</th><th class=n>Inflação implícita 10 anos</th></tr></thead><tbody>{lin_n2}</tbody></table>
<p>O inventário de {y2_nmed} medidas fiscais de 2015 a 2026, com fonte oficial para o que foi anunciado, aprovado e realizado, mostra o limite dos dados{n('y2')}. Das {y2_ncons} medidas classificadas como consolidação, nenhuma tem o efeito realizado isolado em fonte oficial, porque Receita, Tesouro e IFI não publicam o efeito de uma medida depois que ela entra na base. A classificação por motivação é discutível nas medidas de receita, e a única com efeito isolado, a tributação de fundos e offshores, entregou {br(100 * y2_m13, 0)}% do anunciado. Nas {len(y2_r('piora'))} pioras com par comparável, heterogêneas, o custo realizado teve mediana de {br(100 * _md(y2_r('piora')), 0)}% do anunciado. Com tão poucos choques exógenos, uma estimativa narrativa para o Brasil não teria poder estatístico, e não foi feita. Propagando as faixas de incerteza do canal fiscal, do multiplicador, do deflator e da âncora de mercado em 2.000 sorteios, a dívida de 2030 no ajuste pela receita tem mediana de {br(mc('4. Ajuste pela receita', 'p50'), 1)}% e 90% dos resultados entre {br(mc('4. Ajuste pela receita', 'p5'), 1)}% e {br(mc('4. Ajuste pela receita', 'p95'), 1)}%, ela ainda sobe em 2030 em {br(100 * float(next(r['prob_divida_subindo_2030'] for r in MC if r['cenario'] == '4. Ajuste pela receita' and r['ano'] == '2030' and r['variavel'] == 'divida_pct_pib')), 0)}% dos sorteios. Com faixas um pouco mais largas ou crescimento 1 ponto maior, alguns sorteios param de subir, e com a macro do PLDO a dívida cai em 2030 (S-montecarlo.csv). <b>Classe C</b> para um efeito causal do conteúdo fiscal sobre os juros com os dados brasileiros, <b>A</b> para o inventário. <b>B</b>, ilustrativo, para a distribuição, que propaga o canal fiscal da literatura.</p>
<div class=conclusoes><p><b>Conclusões.</b></p>
<ol>
<li><b>A.</b> O custo dos juros é sobretudo Selic vezes o tamanho da parte pós-fixada. {br(100 * float(nota_s['peso_selic']), 0)}% da dívida bruta reage à Selic em meses. A parte indexada ao IPCA acompanha a inflação todo mês. As taxas contratadas dos prefixados e a taxa real das NTN-B só mudam na rolagem, ao longo de {br(wdf('prazo_medio_dpf_anos'), 0)} anos em média.</li>
<li><b>A.</b> A diferença de custo entre 2019-2022 e 2023-2026 vem sobretudo da Selic, cuja contribuição ao custo da dívida federal mais que dobrou (seção 10), com Selic real ex-ante de {br(wsm('Bolsonaro', 'selic_real_ex_ante_meta'), 1)}% contra {br(wsm('Lula 3', 'selic_real_ex_ante_meta'), 1)}%, e da inflação de 2021, que corroeu a dívida (seção 9).</li>
<li><b>A.</b> Desde dez/2022 o juro real americano de 10 anos subiu mais que o brasileiro ({br(XV[('US', 'Lula 3')], 2)} contra {br(XV[('BR', 'Lula 3')], 2)} ponto). <b>C.</b> Quanto da alta do juro real brasileiro entre os dois períodos veio de fora. Os modelos não separam as contribuições domésticas e externas de forma estável, e a atribuição muda de quase nada a quase tudo conforme a especificação.</li>
<li><b>B.</b> Uma melhora crível de 1 ponto do PIB no primário esperado está associada a juros longos {br(FAIXA['Central'], 0)} pb menores em emergentes após dois anos (intervalo aproximado de {br(Y05IC[0], 0)} a {br(Y05IC[1], 0)} pb). Com dados brasileiros, as regressões do Banco Central não acham efeito estável.</li>
<li><b>C.</b> Que um governo de orientação específica reduza o prêmio de risco numa magnitude dada. Nenhum estudo identifica isso, e os programas não trazem meta numérica.</li>
<li><b>C.</b> Que o ajuste fiscal, por si, derrube a Selic numa magnitude dada. A única estimativa causal brasileira é transitória.</li>
<li><b>C.</b> Que anúncios e aprovações fiscais movam os juros no sentido do seu conteúdo. O estudo de eventos não mostra isso com os dados diários disponíveis.</li>
</ol></div>
<p>Condições para uma queda sustentada do custo, pelo que os dados permitem dizer. Selic real menor, o que depende de inflação e expectativas e é decisão do Copom. Juros globais menores, fora do controle do país. E um primário crível que estabilize a dívida (seção 12), que é a parte que cabe ao governo. Pela evidência disponível, o efeito direto nas taxas longas é de {br(FAIXA['Baixo'], 0)} a {br(FAIXA['Alto'], 0)} pb por ponto do PIB de primário esperado. Um ajuste do tamanho que estabilizaria a dívida em 2030, cerca de {br(D_EST, 1)} pontos do PIB acima do que o Focus espera, equivaleria nessa faixa a {br(FAIXA['Baixo'] * D_EST, 0)} a {br(FAIXA['Alto'] * D_EST, 0)} pb, com centro perto de {br(FAIXA['Central'] * D_EST / 100, 1)} ponto percentual. Nenhum estudo mostra que o coeficiente se mantém linear para um ajuste desse tamanho (classe C).</p>"""

# 16. Propostas 2027 a 2030 (frente PR): trechos dos planos do TSE conferidos por script, e a base da lei atual (PLDO, Focus, IBGE)
PRP = le('PR-propostas.csv'); PRA = {(r['partido'], r['termo']): int(r['ocorrencias']) for r in le('PR-ausencias.csv')}
PRAT = list(dict.fromkeys((r['parte'], r['termo']) for r in le('PR-ausencias.csv'))); PRAT_SM = next(tm for _, tm in PRAT if tm.startswith('salário mínimo')); PRAT_CU = next(tm for pa, tm in PRAT if pa == 'cultura'); PRPG = {r['partido']: r['paginas'] for r in le('PR-ausencias.csv')}
PRB = {(r['serie'], r['ano']): float(r['valor']) for r in le('PR-base.csv')}
pb = lambda s, a: PRB[(s, str(a))]
CAND = [('PT', 'Lula (PT)'), ('PL', 'Flávio Bolsonaro (PL)')]
def cel_prop(parte, tema, pt):  # uma citacao por celula, as outras ficam no PR-propostas.csv
  xs = [f"“{r['trecho']}” (p. {r['pagina']})" for r in PRP if r['parte'] == parte and r['tema'] == tema and r['partido'] == pt]
  if not xs: return '<span class=aus>Sem trecho sobre o tema</span>'
  return xs[0] + (f' <span class=mais>mais {len(xs) - 1} {"trecho" if len(xs) == 2 else "trechos"} no pacote</span>' if len(xs) > 1 else '')
SEM = {('familia', 'salário mínimo', 'PL'): f"<span class=aus>Sem proposta sobre o salário mínimo (o termo aparece {PRA[('PL', PRAT_SM)]} vez, como unidade de renda)</span>"}
def cel_aus(pt, termo):
  v = PRA[(pt, termo)]
  return f"<td class=n>{v}</td>" if v else f"<td class=n><span class=aus>ausente</span></td>"
PARTE_NOME = {'contas': 'Contas públicas', 'economia': 'Economia nacional', 'familia': 'Orçamento familiar', 'cultura': 'Cultura', 'agro': 'Agro e meio ambiente'}
PRAG = le('PR-agro-ambiente.csv'); prag = lambda pt: [r for r in PRAG if r['partido'] == pt]
prag_pct = lambda pt, c='palavras_do_capitulo': 100 * sum(float(r[c]) for r in prag(pt)) / float(prag(pt)[0]['palavras_do_plano'])
PRAT_AG = {tm.split(' (')[0]: tm for pa, tm in PRAT if pa == 'agro'}
PRAT_MC = next(tm for pa, tm in PRAT if tm.startswith('Ministério da Cultura'))
AGEQ24, PSR24 = fns(2024, 'agro_subsidio_financeiro'), fns(2024, 'agro_seguro_rural_psr')
PRC = {r['partido']: r for r in le('PR-cultura.csv')}
linhas_aus = ''.join(f"<tr><td>{PARTE_NOME[pa] if i == 0 or PRAT[i - 1][0] != pa else ''}</td><td>{tm}</td>{cel_aus('PT', tm)}{cel_aus('PL', tm)}</tr>" for i, (pa, tm) in enumerate(PRAT))
def tab_prop(parte):
  temas = list(dict.fromkeys(r['tema'] for r in PRP if r['parte'] == parte))
  ln = ''.join(f"<tr><td>{tm[0].upper() + tm[1:]}</td>" + ''.join(f"<td>{SEM.get((parte, tm, pt)) or cel_prop(parte, tm, pt)}</td>" for pt, _ in CAND) + '</tr>' for tm in temas)
  return f'<table class=prop><thead><tr><th>Tema</th>' + ''.join(f'<th>{c}</th>' for _, c in CAND) + f'</tr></thead><tbody>{ln}</tbody></table>'
linhas_base = ''.join(f"<tr><td>{a}</td><td class=n>{br(pb('pib_real_pct', a), 1)}</td><td class=n>{br(pb('focus_pib_pct', a), 1)}</td><td class=n>{br(pb('ipca_pct', a), 1)}</td><td class=n>{br(pb('focus_ipca_pct', a), 1)}</td><td class=n>{br(pb('focus_selic_fim_pct', a), 1)}</td><td class=n>{br(pb('salario_minimo_rs', a), 0)}</td><td class=n>{br(pb('salario_minimo_lei_atual_focus_rs', a), 0)}</td><td class=n>{br(pb('meta_primario_pct_pib', a), 2)}</td></tr>" for a in range(2027, 2031))
g_pldo, g_focus = pb('ganho_real_acumulado_2027_2030_pct', 'PLDO'), pb('ganho_real_acumulado_2027_2030_pct', 'Focus')
POB = lambda tp: POF[('Até 1.908 Reais', tp)]; RIC = lambda tp: POF[('Mais de 23.850 Reais', tp)]
MKI = {r['serie']: float(r['valor']) for r in le('MK-iva-ponto.csv')}  # custo do ponto de IVA (frente MK), usado na secao 16 e na nota de mercado
MKP = {(r['serie'], r['ano']): r for r in le('MK-pldo-execucao.csv')}; mkp = lambda s, a, c='pct_pib': float(MKP[(s, str(a))][c])
PL_META_PIB = 4.0  # plano do PL, p. 49, "crescimento sustentado de 4% ao ano ao longo da próxima década" (trecho em PR-propostas.csv)
IVA_RS = MKI['arrecadacao_por_ponto_rs_bi_2027']
PERG = [
  ('Uma família com renda de dois salários mínimos teria mais renda disponível?',
   'O PT diz que continua a valorização do salário mínimo. O PL não trata do salário mínimo e propõe menos imposto sobre o consumo, a energia e o combustível.',
   f'Pela lei em vigor, o salário mínimo sobe de {br(g_focus, 1)}% a {br(g_pldo, 1)}% acima da inflação de 2027 a 2030, e a parte da renda presa a ele acompanha esse ganho. Um corte de imposto sobre o consumo ajuda se chegar ao preço, e custa cerca de R$ {br(IVA_RS, 0)} bi por ponto de IVA ao Tesouro.',
   'Quanto da renda de cada família segue o salário mínimo e quanto de um corte de imposto chegaria ao preço final.'),
  ('Uma pessoa aposentada manteria o poder de compra?',
   'Nenhum dos planos propõe mudar o reajuste dos benefícios. O PT propõe diversificar as fontes de custeio da Previdência, e o PL, um pacote antifraude. Nenhum dos dois traz números.',
   'Quem recebe o piso acompanha o salário mínimo. Quem recebe acima do piso é corrigido pelo INPC e mantém o poder de compra medido por esse índice, sem ganho real.',
   'A inflação de cada aposentado, que pode diferir do INPC, como mostra a inflação por faixa de renda do anexo T3.'),
  ('Uma família que usa o SUS e a escola pública veria mudança nos serviços?',
   'O PT mantém a Farmácia Popular gratuita, a compra de exames e cirurgias em hospitais privados, o Pé-de-Meia e a meta de 80% das crianças alfabetizadas na idade certa. O PL propõe corrigir a tabela SUS, contratar exames na rede privada em horário ocioso, repassar recursos da educação por metas de aprendizagem e dar voucher onde faltar vaga.',
   'Mudam a forma de compra e o critério de repasse. O efeito sobre a oferta depende do orçamento de cada área.',
   'O orçamento de saúde e de educação de 2027 a 2030 em cada plano. Nenhum dos dois diz o que acontece com os pisos constitucionais dessas áreas.'),
  ('Uma família de renda alta pagaria mais ou menos impostos?',
   'O PT não propõe mudança no Imposto de Renda nem no IVA, e propõe usar o Imposto Seletivo contra produtos nocivos à saúde. O PL propõe revisar a reforma tributária e as majorações de impostos do governo atual e reduzir o IVA, sem dizer se a revisão alcança a tributação mínima de altas rendas.',
   'Pela lei em vigor, quem recebe mais de R$ 600 mil por ano paga tributação mínima de até 10% desde 2026. Um IVA menor reduz o imposto de todas as faixas sobre o consumo.',
   f"A alíquota do IVA que o PL proporia, sabendo que cada ponto vale cerca de {br(MKI['arrecadacao_por_ponto'], 2)}% do PIB, as alíquotas do Imposto Seletivo e qualquer mudança no Imposto de Renda, que nenhum dos planos detalha."),
  ('Uma pequena empresa teria custo diferente para contratar e para pagar imposto?',
   'O PT propõe tratamento tributário justo na reforma, mais acesso às compras públicas e a jornada de 40 horas sem redução de salário. O PL propõe reduzir o custo do trabalho e criar o Minha Primeira Empresa.',
   'A jornada de 40 horas aumenta o custo por hora de quem trabalha mais que isso, e não tem custo fiscal direto. Um custo do trabalho menor reduz o gasto por empregado e a receita da Previdência, e o plano não diz como compensar.',
   'O tamanho da redução de encargos que o PL proporia e quantos empregados de pequenas empresas trabalham mais de 40 horas.'),
]
PERG.append(('Um artista ou um produtor cultural teria mais ou menos fomento?',
  'O PT propõe manter e ampliar o investimento na rede de equipamentos culturais, consolidar os Pontos de Cultura, desconcentrar o fomento e apoiar os games como economia criativa. O PL propõe aperfeiçoar as leis de incentivo, favorecendo outros polos regionais e artistas de pouca projeção, preservar o patrimônio e separar cultura de entretenimento comercial.',
  f"A proposta do PT mexe na despesa direta, que foi de R$ {br(cu(2025, 'liquidado_rs_bi'), 1)} bi na função Cultura em 2025. A do PL mexe na renúncia, que é de R$ {br(cur('renuncia_lei_rouanet'), 1)} bi na Lei Rouanet em 2026, e pode mudar quem capta e onde.",
  'Quanto cada plano destinaria à cultura e que regra nova teria a Lei Rouanet. Nenhum dos dois traz valor.'))
PERG.append(('Um produtor rural teria mais crédito e seguro subsidiados?',
  'O PT propõe ampliar os recursos do Plano Safra, com juros compatíveis com a atividade, e fortalecer o seguro rural. O PL propõe ampliar o seguro rural e securitizar e reorganizar as dívidas do setor.',
  f"Mais equalização e mais subvenção ao seguro aumentam a despesa, que foi de R$ {br(AGEQ24, 1)} bi em 2024, R$ {br(PSR24, 2)} bi deles no seguro rural. Em 2025, a União financiou R$ {br(DIV25, 1)} bi para liquidar dívidas de produtores atingidos por eventos climáticos, como empréstimo.",
  'Quanto cada plano destinaria ao Plano Safra e ao seguro rural, e o juro da economia em 2027 a 2030, que muda o custo da equalização.'))
linhas_perg = ''.join(f'<tr><td><b>{p}</b></td><td>{a}</td><td>{b}</td><td>{c}</td></tr>' for p, a, b, c in PERG)
FX16 = [
  ('Renda baixa', f'O salário mínimo e os benefícios do piso ganham de {br(g_focus, 1)}% a {br(g_pldo, 1)}% acima da inflação até 2030. O consumo leva {br(POB("2.1 Despesas de consumo"), 1)}% da despesa total, e alimentação e habitação, {br(POB("2.1.1 Alimentação") + POB("2.1.2 Habitação"), 1)}%.',
   'A mesma regra do salário mínimo. Programas mantidos e ampliados, sem valores. Imposto Seletivo sobre produtos nocivos, que pesa no consumo, sem alíquota. Jornada de 40 horas para quem trabalha mais, com efeito sobre o emprego que estes dados não medem.',
   f'A lei do salário mínimo continua valendo se não for mudada. Menos imposto sobre o consumo, a energia e o combustível, que ajuda esta faixa no que paga alíquota cheia, já que a cesta básica tem alíquota zero e há cashback. Custo fiscal de cerca de R$ {br(IVA_RS, 0)} bi por ponto de IVA, sem compensação dita. Programas mantidos, com regras novas de saída e de retorno ao benefício.'),
  ('Renda média', 'Imposto de Renda zero até R$ 5.000 por mês e reduzido até R$ 7.350, pela lei de 2025.',
   'Sem mudança no Imposto de Renda nem no IVA. Jornada de 40 horas para quem trabalha mais.',
   'Menos imposto sobre o consumo, com o mesmo custo fiscal sem compensação dita. Contratos de menor custo para jovens e para quem tem 50 anos ou mais e está desempregado.'),
  ('Renda alta', f'Tributação mínima de até 10% para quem recebe mais de R$ 600 mil por ano. Alimentação e habitação levam {br(RIC("2.1.1 Alimentação") + RIC("2.1.2 Habitação"), 1)}% da despesa.',
   'Sem mudança no Imposto de Renda. Justiça tributária e combate a privilégios anunciados, sem medida.',
   'Menos imposto sobre o consumo. Revisão das majorações do governo atual, sem dizer se alcança a tributação mínima de altas rendas.'),
]
linhas_fx16 = ''.join(f'<tr><td><b>{a}</b></td><td>{b}</td><td>{c}</td><td>{d}</td></tr>' for a, b, c, d in FX16)
sec_prop = f"""<h2>Anexo T5. 2027 a 2030. Propostas econômicas, cenários e possíveis efeitos sobre as famílias</h2>
<p><b>Como ler este anexo.</b> As seções 1 a 11 e os anexos T1 a T4 mostram dados observados, e as seções 12 e 13, simulações. Este anexo reúne o que as duas candidaturas do segundo turno de 2026 registraram no TSE como plano de governo, ao lado das projeções do governo e do mercado para 2027 a 2030{n('tse_pt')}{n('tse_pl')}. Nada aqui é resultado medido. Os trechos dos planos aparecem entre aspas, com a página, e um script confere cada um contra o PDF do TSE. A escolha dos trechos é editorial. Os planos também trazem diagnósticos do passado, que esta seção não reproduz, porque as seções anteriores tratam o passado pelos dados. As candidaturas seguem a ordem do número na urna, Lula (13) e Flávio Bolsonaro (22).</p>
<p><b>As mesmas palavras nos dois planos.</b> A tabela conta quantas vezes cada assunto aparece em cada plano. Cada linha junta as palavras que os dois planos usam para o mesmo assunto, porque um plano diz Bolsa Família onde o outro diz programas sociais. Ela mostra quais palavras cada plano usa. Ausência de palavra não é ausência de tema.</p>
<table class=curta style="break-inside:avoid"><thead><tr><th>Parte</th><th>Assunto e palavras contadas</th><th class=n>Lula (PT), {PRPG['PT']} páginas</th><th class=n>Flávio Bolsonaro (PL), {PRPG['PL']} páginas</th></tr></thead><tbody>{linhas_aus}</tbody></table>
<p class=nota>Contagem em todas as páginas dos PDFs do TSE, sem distinguir maiúsculas, com plural e com a hifenização de fim de linha juntada{n('tse_pt')}{n('tse_pl')}. A versão anterior da tabela usava, em vários assuntos, a palavra de um plano só. Uma auditoria independente apontou isso e a lista foi refeita. Nas tabelas seguintes, cada célula traz uma citação, e as demais estão em PR-propostas.csv, no pacote.</p>
<h3>Contas públicas. Dívida, impostos, gastos e juros</h3>
{tab_prop('contas')}
<p>Pela regra em vigor, o PLDO 2027 fixa meta de resultado primário do Governo Central de {br(pb('meta_primario_pct_pib', 2027), 2)}% do PIB em 2027 e indica {br(pb('meta_primario_pct_pib', 2028), 2)}%, {br(pb('meta_primario_pct_pib', 2029), 2)}% e {br(pb('meta_primario_pct_pib', 2030), 2)}% para 2028, 2029 e 2030{n('pldo27')}. Antes das deduções que a Constituição e as leis complementares permitem, o Tesouro projeta {br(pb('primario_projetado_pct_pib', 2027), 2)}% em 2027 e {br(pb('primario_projetado_pct_pib', 2030), 2)}% em 2030. Na seção 12, com o primário do PLDO e a macro do Focus, a dívida bruta chega a {br(sc(C['2'], 2030, 'divida_pct_pib'), 0)}% do PIB em 2030 (cenário 2).</p>
<p>Nenhum dos dois planos traz meta numérica de primário, de dívida ou de carga tributária para 2027 a 2030, e nenhum usa a expressão meta fiscal{n('tse_pt')}{n('tse_pl')}. O do PT liga o resultado fiscal ao crescimento, ao controle do gasto primário e ao combate a privilégios tributários, e propõe usar o Imposto Seletivo contra produtos nocivos à saúde. O do PL fala em superávits primários e em queda da dívida no menor prazo possível, e ao mesmo tempo propõe reduzir o IVA, a soma de CBS e IBS, e os impostos sobre energia e combustíveis, o que reduz o primário se não houver compensação. Pela base da Fazenda, cada ponto a menos na alíquota total vale cerca de {br(MKI['arrecadacao_por_ponto'], 2)}% do PIB, uns R$ {br(IVA_RS, 0)} bi a preços de 2027{n('sert')}{n('cgibs')}. Se o ponto sair da CBS, a perda é toda da União e equivale a {br(100 * IVA_RS / mkp('discricionarias_livres', 2027, 'valor_rs_bi'), 0)}% das despesas discricionárias que sobram em 2027 depois das emendas e dos mínimos de saúde e educação{n('pldo27')}. O cenário 2 é a lei em vigor com a macro do Focus. Os cenários 4 e 4b, que chegam a {br(sc(C['4'], 2030, 'divida_pct_pib'), 1)}% e {br(sc(C['4b'], 2030, 'divida_pct_pib'), 1)}% do PIB, ilustram ajustes que nenhum dos planos quantifica, e nenhum dos dois permite situá-lo num cenário.</p>
<h3>Economia nacional. Crescimento, emprego, inflação e investimento</h3>
{tab_prop('economia')}
<table style="break-inside:avoid"><thead><tr><th>Ano</th><th class=n>PIB real, PLDO</th><th class=n>PIB real, Focus</th><th class=n>IPCA, PLDO</th><th class=n>IPCA, Focus</th><th class=n>Selic no fim do ano, Focus</th><th class=n>Salário mínimo, R$, PLDO</th><th class=n>Salário mínimo, R$, regra com Focus</th><th class=n>Meta de primário, % PIB</th></tr></thead><tbody>{linhas_base}</tbody></table>
<p class=nota>PLDO 2027, grade de parâmetros de março de 2026 e metas fiscais{n('pldo27')}. Focus, medianas de 09/10/2026{n('focus')}. PIB e IPCA em % ao ano. A coluna "regra com Focus" aplica a lei do salário mínimo à inflação e ao PIB do Focus, com o IPCA no lugar do INPC, que o Focus não projeta, e o PIB de 2025 do IBGE ({br(pb('pib_real_ibge_pct', 2025), 1)}%){n('pib_ibge')}. Supõe que o limite do arcabouço de cada ano não fique abaixo do PIB. As projeções foram feitas antes da eleição e não dependem de quem vence.</p>
<p>O plano do PL traz meta de crescimento de {br(PL_META_PIB, 0)}% ao ano na próxima década e investimento de R$ 900 bi em quatro anos em rodovias, hidrovias, portos, aeroportos e ferrovias, com fundo lastreado na securitização de ativos da União, PPPs, concessões e BNDES, sem dizer quanto é dinheiro público{n('tse_pl')}. A meta fica {br(PL_META_PIB - pb('pib_real_pct', 2027), 1)} ponto acima do PLDO e {br(PL_META_PIB - pb('focus_pib_pct', 2027), 1)} pontos acima do Focus para 2027. O plano do PT não traz número de crescimento nem de investimento e fala em sustentar taxas robustas de crescimento e elevar a taxa de investimento{n('tse_pt')}. Para 2027, o PLDO supõe crescimento de {br(pb('pib_real_pct', 2027), 1)}% e IPCA de {br(pb('ipca_pct', 2027), 1)}%, e o Focus espera {br(pb('focus_pib_pct', 2027), 1)}% e {br(pb('focus_ipca_pct', 2027), 1)}%. Nos juros, o PT liga juros menores à inflação controlada e à manutenção do arcabouço, e o PL liga juros na média internacional e inflação no centro da meta à queda da dívida, sem prazo.</p>
<h3>Orçamento familiar. Salários, alimentação, moradia, transporte e benefícios</h3>
{tab_prop('familia')}
<p>O salário mínimo de 2027 a 2030 já tem regra em lei. Ele sobe pelo INPC de 12 meses até novembro mais o crescimento real do PIB de dois anos antes{n('l14663')}, e de 2025 a 2030 esse ganho real fica limitado pelo crescimento da despesa do arcabouço, entre 0,6% e 2,5% ao ano{n('l15077')}{n('lc200')}. O plano do PT diz que vai continuar a política, e o do PL não trata do tema. O termo aparece nele uma vez, como unidade de renda{n('tse_pt')}{n('tse_pl')}. Se a lei continuar, o PLDO projeta R$ {br(pb('salario_minimo_rs', 2027), 0)} em 2027 e R$ {br(pb('salario_minimo_rs', 2030), 0)} em 2030{n('pldo27')}. Com a inflação e o PIB do Focus, a mesma regra dá R$ {br(pb('salario_minimo_lei_atual_focus_rs', 2027), 0)} e R$ {br(pb('salario_minimo_lei_atual_focus_rs', 2030), 0)}, com ganho real acumulado de {br(g_focus, 1)}% de 2027 a 2030, contra {br(g_pldo, 1)}% com a grade do PLDO{n('focus')}. Nenhum dos planos propõe mudar a Lei 14.663. O teto do ganho real, porém, está ligado ao arcabouço, que o plano do PL propõe reformular sem dizer como.</p>
<p>Nenhum benefício que substitua o rendimento do trabalho pode ficar abaixo do salário mínimo, e o BPC é de um salário mínimo{n('cf')}. Por isso o piso do INSS e o BPC acompanham a regra. As aposentadorias acima do piso são corrigidas só pelo INPC{n('l8213')}. Elas mantêm o poder de compra medido por esse índice e não ganham aumento real pela regra. Na Previdência, o PT propõe diversificar as fontes de custeio e o PL, um pacote antifraude, sem números.</p>
<p>A jornada de 40 horas sem redução de salário, que o plano do PT diz defender no Senado, muda o custo da hora para quem trabalha mais de 40 horas e não tem custo fiscal direto{n('tse_pt')}. A média habitual no trabalho principal foi de {br(pb('horas_habituais_trabalho_principal', '2º trimestre 2026'), 1)} horas por semana no 2º trimestre de 2026{n('horas')}. O SIDRA só publica médias, e a conta de quantos trabalham acima de 40 horas pede os microdados da PNAD Contínua, que este dossiê não processou. O PT também propõe rever regras que induzem a precarização e combater a pejotização. O PL propõe reduzir o custo do trabalho com um contrato de menor custo na folha para jovens de 18 a 24 anos e um contrato mais atrativo para quem tem 50 anos ou mais e está desempregado há pelo menos 12 meses, sem dizer em quanto, e defende o negociado sobre o legislado. A redução de encargos diminui também a receita da Previdência, e o plano não diz como compensar{n('tse_pl')}.</p>
<p>Nos programas sociais, nenhum dos dois traz valor de benefício ou número de famílias para 2027 a 2030. O do PL propõe regras de saída e de retorno ao benefício e a proibição do uso dos recursos em apostas. O do PT propõe manter, aperfeiçoar e ampliar a proteção social, sem dizer como{n('tse_pt')}{n('tse_pl')}.</p>
<p>Nos impostos, os planos mexem em lugares diferentes. O do PL propõe reduzir o IVA e os impostos sobre energia elétrica e combustíveis. O do PT não propõe mudança no Imposto de Renda nem no IVA, e propõe usar o Imposto Seletivo contra produtos nocivos à saúde, cujas alíquotas dependem de lei. Na POF, as famílias de menor renda destinam {br(POB('2.1.1 Alimentação'), 1)}% da despesa total à alimentação e {br(POB('2.1.2 Habitação'), 1)}% à habitação, que inclui a energia, contra {br(RIC('2.1.1 Alimentação'), 1)}% e {br(RIC('2.1.2 Habitação'), 1)}% nas de maior renda{n('pof')}. A POF sozinha não diz quem ganha mais com um corte de IVA. A cesta básica nacional já tem alíquota zero, muitos alimentos têm redução de 60% e a baixa renda tem cashback, então o efeito por faixa depende de quanto do consumo de cada uma paga a alíquota cheia{n('lc214')}. A lei em vigor, a 15.270/2025, zera o Imposto de Renda mensal até R$ 5.000, reduz o imposto até R$ 7.350 e cria tributação mínima para rendas acima de R$ 600 mil por ano{n('l15270')}.</p>
<h3>Cultura. Investimento, fomento e mercado cultural</h3>
{tab_prop('cultura')}
<p>Na cultura, os dois planos se diferenciam pelo espaço e pelo instrumento, e não pelos valores. Medido pelo mesmo critério nos dois planos, só o trecho de cultura, do título ao título seguinte e sem cabeçalho de página, o plano do PT dedica à cultura {br(float(PRC['PT']['palavras_so_cultura']), 0)} palavras, {br(float(PRC['PT']['pct_so_cultura']), 1)}% do texto, dentro de um capítulo de cultura e esporte de {br(float(PRC['PT']['palavras_do_capitulo']), 0)} palavras, e o do PL, {br(float(PRC['PL']['palavras_so_cultura']), 0)} palavras, {br(float(PRC['PL']['pct_so_cultura']), 1)}% do texto. O vocabulário da cultura aparece {PRA[('PT', PRAT_CU)]} vezes no plano do PT e {PRA[('PL', PRAT_CU)]} no do PL, {br(float(PRC['PT']['vocabulario_cultura_por_10_mil_palavras']), 1)} e {br(float(PRC['PL']['vocabulario_cultura_por_10_mil_palavras']), 1)} vezes por 10 mil palavras{n('tse_pt')}{n('tse_pl')}. O PT fala em investimento direto na rede de equipamentos, Pontos de Cultura, desconcentração e economia criativa, com os games tratados como setor estratégico. O PL fala em aperfeiçoar as leis de incentivo, patrimônio histórico, artistas de pouca projeção e na distinção entre cultura e entretenimento comercial. Nenhum dos dois traz valor de orçamento, de renúncia ou de meta para a cultura em 2027 a 2030.</p>
<p>Para a conta pública, os instrumentos são diferentes. A União liquidou R$ {br(cu(2025, 'liquidado_rs_bi'), 2)} bi na função Cultura em 2025{n('rreo_funcao')}, e a renúncia prevista para 2026 é de R$ {br(cur('renuncia_cultura_e_audiovisual'), 2)} bi em cultura e audiovisual, R$ {br(cur('renuncia_lei_rouanet'), 2)} bi dela na Lei Rouanet{n('dgt')}. A proposta do PT passa pela despesa, que está dentro do limite do arcabouço. A do PL passa pela renúncia, que fica fora da despesa e reduz a receita. Mudar as leis de incentivo pode mudar quem capta e onde sem mudar o total, e o plano não diz para que lado.</p>
<p>O plano do PL não cita o Ministério da Cultura nem a Lei Rouanet, e o do PT cita o ministério {PRA[('PT', PRAT_MC)]} vezes, sempre ao falar do passado{n('tse_pt')}{n('tse_pl')}. O PL propõe o corte de no mínimo 10 ministérios sem dizer quais (p. 69). Em 2019, a redução de {MIN_N['fim ']} para {MIN_N['2019']} ministérios incluiu o da Cultura, com o Esporte, o Desenvolvimento Social e outros (anexo T1){n('cv_atos')}. O custo da estrutura dá a escala do que um corte de ministério poderia economizar. O pessoal ativo e a administração da função Cultura custaram R$ {br(float(CVE[2025]['pessoal_ativo_e_administracao_rs_bi_2025']), 2)} bi em 2025, {br(float(CVE[2025]['estrutura_pct_despesa_primaria']), 2)}% da despesa primária, e a função inteira, sem o FSA, {br(float(CVE[2025]['funcao_pct_despesa_primaria']), 2)}%{n('siop_fun')}{n('rtn')}. O número dá a ordem de grandeza, sem demonstrar um teto. A função orçamentária e o órgão não têm o mesmo perímetro, e a conta exata pediria a despesa administrativa por órgão e unidade, separando o que outra estrutura continuaria a executar. Parte dela não sairia, porque o servidor estável cujo cargo é extinto fica em disponibilidade com remuneração proporcional{n('cf41')}. De 2015 a 2018 para 2019 a 2022, o custo da estrutura caiu de R$ {br(ESTRC(2015, 2018), 2)} bi para R$ {br(ESTRC(2019, 2022), 2)} bi por ano, cerca de {br(100 * (ESTRC(2015, 2018) - ESTRC(2019, 2022)) / (float(next(r['valor_brl'] for r in le('D-rtn-despesa-primaria.csv') if r['ano'] == '2022' and r['estagio'] == 'RTN pago' and r['categoria'].startswith('4. DESPESA TOTAL') and r['subcategoria'] == 'total')) * defl25(2022) / 1e9), 3)}% da despesa primária de 2022, sem separar corte de mudança de classificação. Com a recriação do ministério, subiu a R$ {br(ESTRC(2023, 2025), 2)} bi por ano no Lula 3, abaixo do nível de 2015 a 2018. A captação da Lei Rouanet, que é renúncia prevista em lei, continuou nos anos sem ministério (anexo T1).</p>
<h3>Agro e meio ambiente. Crédito rural, terra, desmatamento e clima</h3>
{tab_prop('agro')}
<p>No agro e no meio ambiente, os dois planos tratam dos mesmos assuntos com pesos diferentes. O do PT dedica {br(float(prag('PT')[0]['palavras_do_capitulo']), 0)} palavras ao item de segurança alimentar e produção agrícola e {br(float(prag('PT')[1]['palavras_do_capitulo']), 0)} ao de sustentabilidade ambiental e climática, {br(prag_pct('PT'), 1)}% do texto somados. Sem os blocos de fome e alimentação escolar, proteção animal e segurança hídrica, que o PL trata em outros capítulos, ficam {br(prag_pct('PT', 'palavras_nucleo'), 1)}%. O do PL dedica {br(float(prag('PL')[0]['palavras_do_capitulo']), 0)} palavras ao agronegócio e ao campo e {br(float(prag('PL')[1]['palavras_do_capitulo']), 0)} ao meio ambiente, {br(prag_pct('PL'), 1)}% do texto. Desmatamento e queimadas aparecem {PRA[('PT', PRAT_AG['desmatamento e queimadas'])]} vezes no plano do PT e {PRA[('PL', PRAT_AG['desmatamento e queimadas'])]} no do PL. Fiscalização e crime ambiental, {PRA[('PT', PRAT_AG['fiscalização e crime ambiental'])]} e {PRA[('PL', PRAT_AG['fiscalização e crime ambiental'])]}, e clima e floresta, {PRA[('PT', PRAT_AG['clima e floresta'])]} e {PRA[('PL', PRAT_AG['clima e floresta'])]}{n('tse_pt')}{n('tse_pl')}. Nenhum dos dois traz valor de orçamento para o Plano Safra, o seguro rural, a fiscalização ou o Fundo Clima em 2027 a 2030.</p>
<p>As metas de desmatamento medem coisas diferentes. O PT reafirma o desmatamento líquido zero até 2030, que compensa a perda com vegetação recuperada. O PL propõe zerar o desmatamento ilegal até 2029. O PRODES mede o corte raso da vegetação nativa, legal ou ilegal, e não desconta a regeneração, e nenhuma das duas metas se lê direto nele. Os dois planos citam o passado, e o dossiê confere uma frase de cada um. O PL diz retomar o compromisso assumido no governo Bolsonaro, e pelo PRODES a Amazônia perdeu {kmd('Bolsonaro', 'amazonia_media_km2_ano')} km² por ano nos quatro anos daquele governo e {kmd('Lula 3', 'amazonia_media_km2_ano')} km² por ano nos quatro anos do Lula 3{n('prodes')}. O PT diz que o Fundo Clima mobilizou R$ 34,6 bi em 2025, e no orçamento da União o empréstimo ao fundo foi de R$ {br(FC25, 1)} bi liquidados naquele ano. O plano não diz de onde vem o resto{n('siop_fun')}.</p>
<p>No crédito rural, o PT propõe ampliar os recursos do Plano Safra, e o PL, ampliar o seguro rural e securitizar e reorganizar as dívidas do setor. As equalizações e subvenções agrícolas custaram R$ {br(AGEQ24, 1)} bi em 2024, R$ {br(PSR24, 2)} bi deles no seguro rural{n('osu_serie')}, e entram na despesa sujeita ao limite do arcabouço. Na terra, o PT fala em reforma agrária, assentamentos e regularização fundiária, e o PL, em titulação do pequeno proprietário e em segurança jurídica do direito de propriedade. A Organização Agrária, com a obtenção de terras, foi de R$ {fbi('Bolsonaro', 'organizacao_agraria_com_inversoes_rs_bi_2025_ano')} bi por ano com Bolsonaro e de R$ {fbi('Lula 3', 'organizacao_agraria_com_inversoes_rs_bi_2025_ano')} bi no Lula 3, em reais de 2025{n('siop_fun')}. No licenciamento ambiental, o PL propõe prazo definido para o órgão analisar e que, sem decisão no prazo, a licença seja concedida (p. 50), e o plano do PT não trata de licenciamento ({PRA[('PT', PRAT_AG['licenciamento ambiental'])]} ocorrências, contra {PRA[('PL', PRAT_AG['licenciamento ambiental'])]} no do PL){n('tse_pt')}{n('tse_pl')}. No clima, o PT mantém o Fundo Clima e o PL propõe consolidar o mercado regulado de carbono. Os dois prometem fortalecer a fiscalização, e o PL propõe também eliminar superposições entre Ibama, Funai e ICMBio. Nenhum diz o orçamento.</p>
<h3>Perguntas concretas</h3>
<table class="prop q"><thead><tr><th>Pergunta</th><th>O que os planos dizem</th><th>Efeito possível</th><th>O que não dá para calcular</th></tr></thead><tbody>{linhas_perg}</tbody></table>
<h3>Efeitos possíveis por faixa de renda, condicionais</h3>
<table class="prop q"><thead><tr><th>Faixa</th><th>Se a lei em vigor continuar</th><th>Com as propostas do PT</th><th>Com as propostas do PL</th></tr></thead><tbody>{linhas_fx16}</tbody></table>
<p class=nota>As faixas são indicativas e seguem a POF 2017-2018 (famílias até R$ 1.908 e acima de R$ 23.850 por mês) e as faixas da Lei 15.270{n('pof')}{n('l15270')}. Cada célula é condicional. Ela vale se a proposta for aprovada como está escrita e se o efeito chegar à família, e não estima probabilidade de aprovação.</p>
<p>As propostas indicam para onde cada candidatura quer ir. O efeito sobre cada família depende de números que os planos não trazem, como a alíquota do IVA, o tamanho do ajuste fiscal e o valor dos benefícios.</p>"""
sec_anexo_c = f"""<h2>Anexo C. Método da seção 13</h2>
<p class=nota>Regressões mensais de 2008 a 2026, OLS com erro padrão de Newey-West (4 defasagens, conferência com 12), sem pretensão causal{n('fred')}. Dependentes. Juro real NTN-B 10 anos e EMBI+ Brasil, que é spread soberano em dólar e termina em jul/2024 no Ipeadata, por isso não mede o prêmio dos títulos em reais{n('embi')}. Especificações. (a) externos (juro real americano de 10 anos, VIX, dólar amplo, spread de corporativos de emergentes). (b) mais dívida e primário esperados no Focus. Robustez em primeiras diferenças, por regime monetário (2008-2012, 2013-2016, 2017-2020, 2021-2026), sem 2020, com juros de emergentes ou o nominal americano no lugar do real, teste de quebra e janela móvel de 36 meses. Em nível, os resíduos são muito persistentes, o que pode indicar tendência comum. Níveis e diferenças são especificações alternativas com vieses potencialmente diferentes, e nenhuma delas funciona como limite. O spread de emergentes (ICE BofA) não pode ser redistribuído e não está no pacote, baixe pelo FRED.</p>
<p class=nota><b>Estudo de eventos (N2).</b> Protocolo fixado antes dos resultados (BRIEF-v11.md). Anúncios do Executivo, votações de mérito e promulgações de medidas com impacto estimado de pelo menos 0,1% do PIB, de 2015 a 2026, com direção (melhora ou piora) decidida pelo conteúdo antes de ver o retorno. Retorno anormal = variação em 1 dia útil (5, 20 e 60 como robustez) menos a prevista por juro real americano, VIX e dólar, com coeficientes estimados fora das janelas, inferência pela posição na distribuição de 1.000 datas sorteadas sem evento, correção de Holm e de Benjamini-Hochberg. Surpresa pela variação da mediana do primário esperado no Focus. Dois desvios declarados (exclusão de 10 para 5 dias em torno dos eventos e mínimo de 100 para 60 observações na estimação) não mudam a classe. O inventário inclui a varredura das votações do Plenário da Câmara de 2017 a 2019 e de 2023, e um corte por julgamento (o Repetro, cuja renúncia é em grande parte de uma vez só) está declarado{n('n2')}. <b>Inventário (Y2).</b> Medidas com fonte oficial para anunciado, aprovado e realizado, motivação pelo texto da exposição de motivos. Sem estimativa por projeções locais, porque com oito anos utilizáveis o efeito mínimo detectável seria cerca de quatro vezes o multiplicador que se quer medir{n('y2')}. <b>Incerteza (S2).</b> 2.000 sorteios com semente fixa. Canal fiscal triangular de 11 a 47 pb com moda em 26, só nas taxas de mercado. Multiplicador uniforme de 0 a 1,2 nos ajustes, deflator de 1 ponto abaixo a 1 acima do IPCA. Âncora de mercado entre o último mês completo e o dado mais recente, sem a premissa de taxas 1,5 ponto menores.</p>
<table><thead><tr><th>Mandato</th><th class=n>Selic real ex-post (12 meses seguintes)</th><th class=n>Meta menos IPCA passado</th><th class=n>Ex-ante, meta e Focus</th><th class=n>Ex-ante, Selic esperada</th></tr></thead><tbody>{''.join(f"<tr><td>{m}</td>" + ''.join(f"<td class=n>{br(wsm(m, c), 2)}</td>" for c in ('selic_real_ex_post_12m_seguintes', 'selic_real_bis_meta_menos_ipca_passado', 'selic_real_ex_ante_meta', 'selic_real_ex_ante_selic_esperada')) + "</tr>" for m in ('Lula 2', 'Dilma', 'Temer', 'Bolsonaro', 'Lula 3'))}</tbody></table>
<p class=nota>% ao ano, médias mensais por mandato{n('copom')}{n('focus')}{n('ipca')}.</p>
<table><thead><tr><th>Estudo e amostra</th><th>Identificação</th><th>Resultado relevante</th><th>Principal limitação para o Brasil de hoje</th></tr></thead><tbody>{lin_lit}</tbody></table>
<p class=nota>Y-literatura.csv traz, para cada estudo, link, página da magnitude, intervalo, taxa afetada e limitações para o Brasil{n('lit')}. Estimativas com variáveis fiscais diferentes (dívida, primário corrente, primário esperado, choques identificados) não foram combinadas. A faixa do simulador usa só Y05, o estudo com primário esperado e juro longo nominal de 10 anos (revisão pela auditoria v10).</p>"""

ARQ = [('I-divida-bruta-anual.csv', 'Dívida bruta ano a ano, % do PIB, R$ correntes e R$ de 2025, com presidente', 'bcbdiv'),
       ('I-divida-historico.csv, I-divida-por-mandato.csv, I-divida-fatores.csv', 'Dívida bruta e líquida em dezembro, fatores da dívida líquida por ano e por mandato', 'bcbdiv'),
       ('J-*.csv', 'Composição da dívida bruta, ativos da dívida líquida, ajustes, BNDES, resultado do BC, ponte por mandato', 'j_bcb'),
       ('K-primario-recorrente.csv, K-por-mandato.csv, K-eventos-nao-recorrentes.csv', 'Primário cheio, recorrente e estrutural por ano, com cada evento não recorrente', 'spe'),
       ('L-receita-carga.csv, L-carga-internacional.csv', 'Carga tributária, receita líquida, gasto tributário, despesa obrigatória, comparação OCDE', 'rfb'),
       ('M-resumo-2025.csv, M-juros-emergentes.csv, M-decomposicao-juros.csv', 'Juros, dívida e taxa implícita de emergentes, decomposição taxa e tamanho', 'weo'),
       ('T-incidencia-tributaria.csv', 'Tributos por décimo de renda (POF 2017-2018) e alíquota do topo dos declarantes', 'ipea_td'),
       ('U-previdencia-resultado.csv, U-previdencia-atuarial.csv', 'Contribuições, benefícios, resultado e passivo atuarial por regime de previdência', 'siconfi'),
       ('V-reforma-consumo.csv', 'Reforma do consumo. Transição, alíquota de referência, cashback, cesta, fundos e gastos tributários', 'lc214'),
       ('W-curva-mensal.csv, W-selic-real.csv, W-dpf-estrutura.csv, W-juros-perimetros.csv, W-transmissao.csv', 'Curva, Selic real, estrutura e custo da dívida federal, três perímetros de juros, transmissão', 'rmd'),
       ('X-fatores-mensal.csv, X-regressoes.csv, X-janela-movel-36m.csv, X-comparacao-emergentes.csv', 'Fatores externos, risco-país, regressões de associação e comparação com emergentes', 'fred'),
       ('Y-literatura.csv', 'Revisão de 25 estudos sobre política fiscal e juros', 'lit'),
       ('S-sensibilidade-juros.csv, S-canal-fiscal.csv, S-multiplicador.csv', 'Reduções de 0,5 a 3 pontos, canal fiscal e multiplicador com as faixas da literatura', 'focus'),
       ('N2-eventos.csv, N2-retornos.csv, N2-surpresa.csv, N2-resumo.csv', 'Estudo de eventos fiscais 2015 a 2026, protocolo em BRIEF-v11.md', 'n2'),
       ('Y2-medidas.csv', 'Medidas fiscais. Anunciado, aprovado e realizado, com fontes por medida', 'y2'),
       ('S-montecarlo.csv', 'Distribuição da dívida e dos juros até 2030 em 2.000 sorteios das faixas de incerteza', 'focus'),
       ('Z-emendas.csv, Z-emendas-participacao.csv, Z-marcos.csv', 'Emendas parlamentares por tipo, participação na despesa discricionária e marcos institucionais', 'emendas'),
       ('S-cenarios-divida.csv', 'Cenários condicionais da dívida bruta até 2030', 'focus'),
       ('P-pobreza-banco-mundial-ppc2021.csv', 'Pobreza do Brasil nas linhas do Banco Mundial de 2025 (US$ 3,00 e US$ 8,30, PPC 2021)', 'pip'),
       ('R-juro-real-br-eua.csv', 'Juro real de 10 anos do Brasil menos o dos EUA, por governo e por ano', 'fred'),
       ('N-juro-real-mensal.csv, N-juro-real-anual.csv, N-eventos-fiscais.csv', 'Juro real e inflação implícita de 10 anos, Selic, eventos fiscais', 'td'),
       ('H-*.csv, G-beneficiarios.csv, RAZAO-per-capita.csv', 'Despesa por bloco 2008 a 2025, por habitante e por beneficiado, beneficiados com URL', 'benef'),
       ('J-dbgg-fatores-reais.csv', 'Fatores da dívida bruta por ano e mandato, juros nominais separados em reposição da inflação e juro real', 'j_bcb'),
       ('O-custo-divida-indexador.csv, O-custo-divida-decomposicao.csv', 'Custo médio da dívida federal por indexador, IPCA, juro real e Selic', 'rmd'),
       ('E-renuncias-e-subsidios.csv', 'Renúncias e subsídios da União (Orçamento de Subsídios e gasto tributário)', 'osu'),
       ('P-desigualdade-pobreza.csv, P-irpf-faixas.csv, P-previdencia-regimes.csv, P-carga-por-base.csv', 'Gini e pobreza com e sem programas, IRPF por faixa, previdência por regime, carga por base', 'sis'),
       ('PC-renda-trabalho.csv, PC-renda-domiciliar-faixas.csv', 'Renda real do trabalho por trimestre móvel e renda domiciliar por pessoa por faixa, com presidente', 'pnad_dom'),
       ('PC-salario-minimo.csv, PC-cesta-sp.csv', 'Salário mínimo real pelo INPC e horas de trabalho para a cesta de São Paulo, por ano, com presidente', 'dieese'),
       ('PR-propostas.csv, PR-ausencias.csv, PR-cultura.csv, PR-agro-ambiente.csv, PR-base.csv', 'Trechos dos planos de governo com página, contagem de termos, espaço da cultura, do agro e do meio ambiente em cada plano, e base da lei atual (PLDO, Focus, IBGE)', 'tse_pt'),
       ('CV-atos.csv, CV-ministerios.csv, CV-salic-por-ano.csv, CV-transferencias-cultura.csv, CV-estrutura-cultura.csv, CV-atencao.csv, CV-temas-auditoria.csv', 'Cultura e governo. Atos oficiais com trecho conferido, ministérios por lei, fluxo e temas da Lei Rouanet por ano, auditoria manual dos temas, transferências por lei, custo da estrutura e atenção pública', 'cv_atos'),
       ('FL-desmatamento.csv, FL-desmatamento-por-mandato.csv', 'Desmatamento na Amazônia Legal e no Cerrado por ano PRODES de 2000 a 2026 e por mandato, com presidente', 'prodes'),
       ('FN-funcoes-uniao.csv, FN-subsidios-agro-cultura.csv, FN-por-mandato.csv, FN-inversoes-acoes.csv, FN-pib-agro.csv, FN-ordenamento-territorial.csv', 'Agricultura, Organização Agrária, Gestão Ambiental e Cultura da União de 2000 a 2025, empréstimos, subsídios do agro e da cultura, Rouanet captado, PIB da agropecuária e Ordenamento Territorial, por ano e por mandato', 'siop_fun'),
       ('PC-inflacao-faixa.csv, PC-pof-orcamento.csv, PC-por-mandato.csv', 'Inflação mensal por faixa de renda, orçamento das famílias por classe e resumo por mandato', 'ipea_ifr'),
       ('Q-educacao.csv, Q-saude.csv, Q-internacional.csv', 'Ideb, Saeb, PISA, mortalidade infantil, esperança de vida, vacinação, comparação internacional', 'inep'),
       ('ABSOLUTO-uniao-2025.csv, ABSOLUTO-pais-2024.csv, C-governo-geral-cofog.csv, F-divida.csv', 'Tabelas 1, 2 e 8. União 2025, país 2024 (COFOG), juros e dívida federal', 'rtn')]
anexo_arq = ''.join(f"<tr><td>{a}</td><td>{d}</td><td class=n>{n(k)}</td></tr>" for a, d, k in ARQ)
lk = lambda t: re.sub(r'(https?://[^\s,;)]+[^\s,;).])', r'<a href="\1">\1</a>', t)
sec_anexo = f"""
<h2>Anexo A. Séries ano a ano</h2>
<p class=nota>Os mesmos números dos gráficos, para conferência. Arquivo e fonte de cada série no Anexo B.</p>
<table><thead><tr><th>Ano</th><th>Presidente</th><th class=n>Primário cheio</th><th class=n>Recorrente</th><th class=n>Estrutural (SPE)</th><th class=n>Dívida bruta</th><th class=n>Dívida líquida</th></tr></thead><tbody>{anexo_prim}</tbody></table>
<p class=nota>Governo Central, % do PIB (estrutural sobre o PIB potencial). Dívidas do governo geral e do setor público, % do PIB em dezembro{n('rtn')}{n('spe')}{n('bcbdiv')}. 2025. Recorrente estimado.</p>
<table style="break-inside:avoid"><thead><tr><th>Mês</th><th>Presidente</th><th class=n>Dívida bruta, % do PIB</th><th class=n>R$ bi correntes</th><th class=n>R$ bi de dez/2025</th></tr></thead><tbody>{anexo_div}</tbody></table>
<p class=nota>Critério Bacen{n('bcbdiv')}, deflator IPCA do mês{n('ipca')}.</p>
<table style="break-inside:avoid"><thead><tr><th>Ano</th><th>Presidente</th><th class=n>Juros nominais, R$ bi correntes</th><th class=n>R$ bi de 2025</th><th class=n>R$ de 2025 por habitante</th></tr></thead><tbody>{anexo_jur}</tbody></table>
<p class=nota>Governo Federal sem o BCB, competência{n('bcb')}, IPCA dezembro a dezembro{n('ipca')}, população{n('ibge')}.</p>
<h2>Anexo B. Dados e reprodução</h2>
<p class=nota>O pacote gastos-publicos-brasil-dados.zip acompanha este documento. Traz cada arquivo de dados em CSV, os scripts que os montam a partir dos downloads e este relatório a partir dos CSV, e um LEIAME por frente com a URL e a data de consulta de cada arquivo baixado. Os arquivos brutos baixados ficam fora do pacote, e cada um tem a sua URL. Vão só as três planilhas oficiais que o relatório lê direto (RTN do Tesouro, Tabelas de estatísticas fiscais do BCB e quadros do gasto tributário da Receita). Cada número do texto é lido pelo script de um desses arquivos. Planilhas, APIs e CSV oficiais são lidos direto. O que só existe em PDF (relatórios anuais da dívida, relatório do Tesouro sobre a relação com o BC, devoluções do BNDES por parcela, parte da série de carga tributária da Receita, lida dos rótulos de um gráfico) é transcrito no script da frente, com a página de origem, e conferido contra o total publicado quando o documento traz um.</p>
<table><thead><tr><th>Arquivo</th><th>Conteúdo</th><th class=n>Fonte</th></tr></thead><tbody>{anexo_arq}</tbody></table>
"""

# Nota para quem aloca capital (frente MK): curva a termo, execucao do PLDO, custo do ponto de IVA e calendario
MKC = le('MK-curva-termo.csv'); MKP = {(r['serie'], r['ano']): r for r in le('MK-pldo-execucao.csv')}
MKK = le('MK-calendario.csv')
mkp = lambda s, a, c='pct_pib': float(MKP[(s, str(a))][c])
linhas_mkc = ''.join(f"<tr><td>{r['janela']}</td><td class=n>{br(float(r['taxa_a_termo_prefixada_pct']), 2)}</td><td class=n>{br(float(r['selic_media_focus_pct']), 2)}</td><td class=n>{sn(float(r['diferenca_pb']), 0)}</td><td class=n>{br(float(r['juro_real_a_termo_pct']), 2)}</td><td class=n>{br(float(r['inflacao_implicita_a_termo_pct']), 2)}</td></tr>" for r in MKC)
linhas_mkk = ''.join(f"<tr><td>{r['data']}</td><td>{r['evento']}</td><td>{r['valor']}</td><td>{r['fonte']}</td></tr>" for r in MKK)
dif2, dif5 = float(MKC[1]['diferenca_pb']), float(MKC[-1]['diferenca_pb'])
# Curva desenhada na nota de mercado (leitura de design por agente de IA, recomendacao 8): taxa a termo da ANBIMA contra a Selic media esperada pelo Focus
fig, ax = plt.subplots(figsize=(LARG, 2.4))
xk = [int(r['ano_a_frente']) for r in MKC]
for col, cor, rot in (('taxa_a_termo_prefixada_pct', ESCURO, 'taxa a termo prefixada, ANBIMA'), ('selic_media_focus_pct', AZUL, 'Selic média esperada, Focus')):
  yk = [float(r[col]) for r in MKC]
  ax.plot(xk, yk, color=cor, lw=1.5, marker='o', markersize=4); ax.text(xk[-1] + 0.12, yk[-1], rot, fontsize=7.2, va='center', color=ESCURO)
ax.set_xticks(xk, [r['janela'] for r in MKC], fontsize=7); ax.set_xlim(0.7, 7.2); ax.set_ylabel('% ao ano')
ax.text(1, 1.02, 'a primeira janela começa no Lula 3, as outras caem no próximo mandato', transform=ax.get_xaxis_transform(), fontsize=6.5, color=CINZA, va='bottom')
fig.tight_layout(); fig.savefig(f'{G}/0a-curva-focus.svg'); plt.close(fig)
# Anexo T6: expectativas contra resultados (frente FB, protocolo BRIEF-v13) e reacao de mercado aos turnos (frente EL, BRIEF-v14)
FBR = le('FB-resumo.csv'); ELR = le('EL-resumo.csv')
FBNOME = {'ipca': 'IPCA, pontos', 'pib': 'PIB, pontos', 'selic': 'Selic de fim de ano, pontos', 'cambio': 'Câmbio de fim de ano, R$ por US$', 'primario': 'Primário, pontos do PIB'}
def fb_lin(v, h):
  d = next(r for r in FBR if r['tipo'] == 'distribuicao' and r['variavel'] == v and r['horizonte'] == h)
  el = [r for r in FBR if r['tipo'] == 'eleicao' and r['variavel'] == v and r['horizonte'] == h]
  pos = ', '.join(f"{r['ano_origem'][2:]}: {r['posicao_erro_abs']}º" for r in el)
  dd = 2 if v == 'cambio' else 1
  return (f"<tr><td>{FBNOME[v]}, {'ano seguinte' if h == 'h1' else 'dois anos à frente'}</td><td class=n>{d['n']}</td><td class=n>{br(float(d['mediana_erro']), dd)}</td>"
          f"<td class=n>{br(float(d['mediana_erro_abs']), dd)}</td><td class=n>{br(float(d['p10_erro']), dd)} a {br(float(d['p90_erro']), dd)}</td><td>{pos}</td></tr>")
lin_fb = ''.join(fb_lin(v, h) for v in FBNOME for h in ('h1', 'h2'))
fbd = lambda v, h, c: float(next(r[c] for r in FBR if r['tipo'] == 'distribuicao' and r['variavel'] == v and r['horizonte'] == h))
FBC = next(r for r in FBR if r['variavel'] == 'curva_pre1a_vs_selic')
ELN = {'cambio': ('Câmbio, PTAX', '%'), 'prefixado_1a': ('Prefixado de 1 ano', 'pb'), 'prefixado_10a': ('Prefixado de 10 anos', 'pb'),
       'juro_real_10a': ('Juro real de 10 anos', 'pb'), 'inflacao_implicita_10a': ('Inflação implícita de 10 anos', 'pb')}
def el_hist(turno, v):
  return next(r for r in ELR if r['tipo'].startswith('turnos') and r['turno'] == turno and r['variavel'] == v and r['janela_dias'] == '1')
def el_lin(v):
  h1, h2 = el_hist('1', v), el_hist('2', v)
  a = next(r for r in ELR if r['tipo'] == '2026' and r['turno'] == '1' and r['variavel'] == v and r['janela_dias'] == '1')
  d = 2 if v == 'cambio' else 0
  return (f"<tr><td>{ELN[v][0]}, {ELN[v][1]}</td><td class=n>{br(float(h1['mediana_abs_variacao']), d)} ({h1['n_percentil_95_ou_mais']} de {h1['n_com_posicao']})</td>"
          f"<td class=n>{br(float(h2['mediana_abs_variacao']), d)} ({h2['n_percentil_95_ou_mais']} de {h2['n_com_posicao']})</td><td class=n>{br(float(h1['mediana_das_medianas_abs_referencia']), d)}</td>"
          f"<td class=n>{br(float(a['variacao_2026']), d)}</td></tr>")
lin_el = ''.join(el_lin(v) for v in ELN)
ELC = next(r for r in ELR if r['tipo'] == '2026' and r['turno'] == '1' and r['variavel'] == 'cambio' and r['janela_dias'] == '1')
ELV = next(r for r in le('EL-variacoes.csv') if r['ano'] == '2026' and r['turno'] == '1' and r['variavel'] == 'cambio' and r['janela_dias'] == '1')
EL_PCT = 100 * (1 - float(ELV['valor_fim']) / float(ELV['valor_t_menos_1']))
sec_fb = f"""<h2>Anexo T6. Expectativas contra resultados, e o mercado nos turnos da eleição</h2>
<p><b>Por que está aqui.</b> A nota para quem aloca capital e a seção 12 usam o Focus como cenário. Este anexo mede quanto o Focus de outubro errou o ano seguinte e o outro, de 2000 a 2024, com o protocolo fixado antes de baixar os dados (BRIEF-v13.md, no pacote). A pergunta é sobre erro de previsão. Não mede qual governo causou qual resultado.</p>
<p class="cl cl-a">O erro mediano do IPCA do ano seguinte foi de {br(fbd('ipca', 'h1', 'mediana_erro'), 1)} ponto para cima (inflação acima da esperada), e o da Selic de fim de ano, de {br(fbd('selic', 'h1', 'mediana_erro'), 1)} ponto para cima, com erro absoluto mediano de {br(fbd('selic', 'h1', 'mediana_erro_abs'), 1)} pontos. O primário saiu pior que o esperado na mediana, {br(fbd('primario', 'h1', 'mediana_erro'), 2)} ponto do PIB no ano seguinte e {br(fbd('primario', 'h2', 'mediana_erro'), 2)} dois anos à frente. No PIB o erro mediano é pequeno ({br(fbd('pib', 'h1', 'mediana_erro'), 1)}), mas a faixa entre os percentis 10 e 90 vai de {br(fbd('pib', 'h1', 'p10_erro'), 1)} a {br(fbd('pib', 'h1', 'p90_erro'), 1)} pontos{n('focus_hist')}{n('sgs_fb')}.</p>
<div class=tn>Erro do Focus de outubro, realizado menos esperado</div>
<table><thead><tr><th>Variável e horizonte</th><th class=n>Anos</th><th class=n>Erro mediano</th><th class=n>Erro absoluto mediano</th><th class=n>Percentis 10 a 90</th><th>Posição do erro absoluto nos anos de eleição (1º = maior)</th></tr></thead><tbody>{lin_fb}</tbody></table>
<p class=nota>Origem na última data do Focus até o sábado antes do primeiro domingo de outubro de cada ano (nos anos de eleição, o do 1º turno). IPCA de dezembro a dezembro, PIB da série atual do IBGE, meta da Selic em 31/12, PTAX do último dia útil, primário do setor público consolidado em 12 meses com sinal de superávit positivo. Sete casos sem dado saíram, listados no pacote{n('focus_hist')}{n('sgs_fb')}.</p>
<p class="cl cl-a">Nos seis anos de eleição presidencial, os erros ficam espalhados pela distribuição. A origem de 2014 tem o maior erro de câmbio do ano seguinte e o segundo maior de PIB. A de 2018 tem o maior erro de primário dois anos à frente, que é 2020, o ano da pandemia. Com seis casos não há teste, e nenhuma diferença entre anos de eleição e os demais é afirmada. O cenário 2 da seção 12 usa o Focus. Se o padrão de 2000 a 2024 se repetir, com Selic acima e primário abaixo do esperado, a dívida de 2030 fica acima do cenário 2 (associação histórica, classe B, e não previsão). Na curva, de 2008 a 2025, o prefixado de 1 ano de setembro errou a Selic média dos 12 meses seguintes em {br(float(FBC['mediana_erro']), 2)} ponto na mediana, com erro absoluto mediano de {br(float(FBC['mediana_erro_abs']), 2)}{n('td')}.</p>
<h3>O mercado nos dias seguintes a cada turno</h3>
<p>O protocolo deste trecho foi fixado em 24/10/2026, na véspera do 2º turno (BRIEF-v14.md, no pacote), quando o resultado do 1º turno de 2026 já era conhecido. Os níveis de juros de outubro de 2026 já apareciam na seção 11 e na Figura 1, e dois ajustes de execução registrados no pacote foram feitos depois de uma primeira rodada que já mostrava variações. Por isso a linha de 2026 é descrição feita depois do fato, e não teste fixado antes. Os anos de 2002 a 2022 são o teste. A variação vai do último pregão antes do domingo da votação ao primeiro depois, e cada uma é comparada com as variações de fins de semana comuns dos 12 meses anteriores.</p>
<p class="cl cl-a">De 2002 a 2022, a mediana do câmbio no pregão seguinte ao 1º turno foi de {br(float(next(r for r in ELR if r['tipo'].startswith('turnos') and r['turno'] == '1' and r['variavel'] == 'cambio' and r['janela_dias'] == '1')['mediana_abs_variacao']), 2)}% em módulo, contra {br(float(next(r for r in ELR if r['tipo'].startswith('turnos') and r['turno'] == '1' and r['variavel'] == 'cambio' and r['janela_dias'] == '1')['mediana_das_medianas_abs_referencia']), 2)}% num fim de semana comum. Em três dos seis 1º turnos o câmbio ficou no percentil 95 ou mais dos fins de semana comuns, contra 0,3 esperado por acaso, e no 2º turno em um de seis. O pregão seguinte a um turno costuma mexer mais que um fim de semana comum. A tabela traz também o 1º turno de 2026, de 02/10 para 05/10, em que o dólar caiu {br(EL_PCT, 2)}% ({br(-float(ELC['variacao_2026']), 2)} em logaritmo){n('sgs_fb')}{n('td')}{n('tse_turnos')}.</p>
<div class=tn>Pregão seguinte a cada turno, variação de um dia</div>
<table><thead><tr><th>Variável</th><th class=n>1º turno, mediana do módulo, 2002 a 2022 (no percentil 95 ou mais)</th><th class=n>2º turno, mediana do módulo, 2002 a 2022 (no percentil 95 ou mais)</th><th class=n>Fim de semana comum, mediana do módulo</th><th class=n>1º turno de 2026, variação</th></tr></thead><tbody>{lin_el}</tbody></table>
<p class=nota>Câmbio em 100 vezes o logaritmo da razão (aproximadamente %), juros em pontos-base. Tesouro Direto, taxa de compra da manhã, vértices pelo mesmo método das seções 11 e 13. Datas de 2002 a 2022 pelos arquivos do TSE, de 2026 pelo art. 77 da Constituição{n('tse_turnos')}{n('td')}{n('sgs_fb')}.</p>
<p class="cl cl-c">A variação é medida. O que a causou não está demonstrado. A direção do movimento não indica qual resultado o mercado preferia nem o que espera do 2º turno, e o cálculo não lê voto, candidato nem resultado. Num pregão, juros e câmbio também reagem a dados e notícias de fora e ao que o mercado esperava antes do domingo. O 2º turno de 25/10/2026 entra pela mesma regra quando houver os pregões de 26 a 30/10. Pelo protocolo, a linha fica vazia até lá.</p>"""
# Anexo T7: investimento das estatais federais (frente EE), Orcamento de Investimento executado, 2009 a 2025 (SEST ate 2021, DOU de 2022 a 2025)
EE = {(r['ano'], r['item']): r for r in le('EE-investimento-estatais.csv')}
ee = lambda a, it, c='pct_pib': float(EE[(str(a), it)][c])
EEA = sorted({int(r['ano']) for r in le('EE-investimento-estatais.csv') if r['ano'].isdigit()})
EEB = next(k for (_, k) in EE if k.startswith('Instituições financeiras'))
fig, ax = plt.subplots(figsize=(LARG, 2.6))
faixas(ax, ini=EEA[0]); ax.axvspan(EEA[-1] + 0.5, EEA[-1] + 3, color='white', lw=0, zorder=0)
ax.plot(EEA, [ee(a, 'Total do OI') for a in EEA], color=ESCURO, lw=1.5); ax.plot(EEA, [ee(a, 'Grupo Petrobras') for a in EEA], color=AZUL, lw=1.5)
ax.text(EEA[-1] + 0.3, ee(EEA[-1], 'Total do OI') + 0.08, f"total {br(ee(EEA[-1], 'Total do OI'), 2)}", fontsize=7.2, va='bottom', color=ESCURO)
ax.text(EEA[-1] + 0.3, ee(EEA[-1], 'Grupo Petrobras') - 0.08, f"Petrobras {br(ee(EEA[-1], 'Grupo Petrobras'), 2)}", fontsize=7.2, va='top', color=ESCURO)
ax.set_xlim(EEA[0] - 0.5, EEA[-1] + 2.5); ax.set_ylim(0, 2.6); ax.set_ylabel('% do PIB')
ax.set_xticks(list(range(2010, EEA[-1] + 1, 3))); ax.set_xticklabels([str(a) for a in range(2010, EEA[-1] + 1, 3)])
fig.tight_layout(); fig.savefig(f'{G}/t7-estatais.svg'); plt.close(fig)
PB = [ee(a, 'Grupo Petrobras', 'participacao_no_total_pct') for a in EEA]
BB = [ee(a, EEB, 'valor_rs_mi_dez2025') / 1000 for a in EEA]
EEMIN = min(EEA, key=lambda a: ee(a, 'Total do OI'))
BCX = [100 * (ee(a, 'Banco do Brasil', 'valor_rs_mi_correntes') + ee(a, 'Caixa', 'valor_rs_mi_correntes')) / ee(a, EEB, 'valor_rs_mi_correntes') for a in EEA if (str(a), 'Caixa') in EE]
sec_ee = f"""<h2>Anexo T7. Investimento das estatais federais, 2009 a 2025</h2>
<p class="cl cl-a">As estatais federais que não dependem do Tesouro para custeio investem pelo Orçamento de Investimento, fora da despesa primária e da conta das seções 1 a 13. O investimento executado foi de {br(ee(2009, 'Total do OI'), 2)}% do PIB em 2009 e {br(ee(2013, 'Total do OI'), 2)}% em 2013, R$ {br(ee(2013, 'Total do OI', 'valor_rs_mi_dez2025') / 1000, 1)} bi de dez/2025, caiu a {br(ee(2016, 'Total do OI'), 2)}% em 2016, oscilou entre {br(min(ee(a, 'Total do OI') for a in range(2017, 2021)), 2)}% e {br(max(ee(a, 'Total do OI') for a in range(2017, 2021)), 2)}% de 2017 a 2020 e chegou ao mínimo da série em {EEMIN}, {br(ee(EEMIN, 'Total do OI'), 2)}%. Depois subiu a {br(ee(EEA[-1], 'Total do OI'), 2)}% em {EEA[-1]}, R$ {br(ee(EEA[-1], 'Total do OI', 'valor_rs_mi_dez2025') / 1000, 1)} bi, quase todo da Petrobras. Em 2022 a Eletrobras deixou de ser estatal, e a parte nuclear e binacional que ficou com a União passou à ENBPar (Empresa Brasileira de Participações em Energia Nuclear e Binacional), que investiu R$ {br(ee(EEA[-1], 'Grupo ENBPar', 'valor_rs_mi_dez2025') / 1000, 1)} bi em {EEA[-1]}. O grupo Petrobras fez de {br(min(PB), 0)}% a {br(max(PB), 0)}% do total em todos os anos. Os bancos federais investiram de R$ {br(min(BB), 1)} bi a R$ {br(max(BB), 1)} bi de dez/2025 por ano, e de 2022 a {EEA[-1]}, anos com dado por banco, Banco do Brasil e Caixa fizeram de {br(min(BCX), 0)}% a {br(max(BCX), 0)}% disso{n('sest_oi')}{n('dou_oi')}{n('ipca')}.</p>
<figure>{svg('t7-estatais')}</figure>
<p class=nota>Orçamento de Investimento executado, tabela consolidada da SEST de 2009 a 2021{n('sest_oi')} e portarias do 6º bimestre no Diário Oficial de 2022 a 2025{n('dou_oi')}, PIB do RTN{n('rtn')}. Na portaria de 2022 a SEST deixa Eletronuclear e INB fora dos grupos do setor produtivo, mas dentro do total. O valor por banco e por empresa está nos dados, de 2022 a 2025.</p>"""
sec_mk = f"""<h2>Para quem aloca capital</h2>
<p class=nota>Duas páginas com o que mexe em preço, para ler antes do resto. Cada item remete à seção de origem. Não é recomendação de investimento.</p>
<ul class=r>
<li><b>Dívida em 2030.</b> Com o primário do PLDO e a macro do Focus, a dívida bruta chega a {br(sc(C['2'], 2030, 'divida_pct_pib'), 0)}% do PIB. Com deflator 1 ponto acima do IPCA, a {br(sc(C['2b'], 2030, 'divida_pct_pib'), 0)}%, e com a macro do próprio PLDO, a {br(sc(C['6'], 2030, 'divida_pct_pib'), 0)}%. Nenhum cenário com a macro do Focus a estabiliza até 2030 (seção 12){n('focus')}{n('pldo27')}.</li>
<li><b>A meta de 2027 depende de exclusões.</b> O Tesouro projeta primário de {br(mkp('primario_projetado', 2027), 2)}% do PIB em 2027. A meta de {br(mkp('meta', 2027), 2)}% é cumprida com R$ {br(mkp('exclusoes_da_meta', 2027, 'valor_rs_bi'), 2)} bi ({br(mkp('exclusoes_da_meta', 2027), 2)}% do PIB) de despesas que a Constituição e as Leis Complementares 221 e 223 permitem tirar da verificação, como precatórios, projetos estratégicos de defesa e saúde e educação pagas com o Fundo Social. A arrecadação projetada inclui o efeito de medidas tributárias ainda em estudo no Executivo. A despesa primária cai de {br(mkp('despesa_primaria_total', 2027), 2)}% para {br(mkp('despesa_primaria_total', 2030), 2)}% do PIB até 2030, e as despesas discricionárias que sobram depois das emendas e dos mínimos de saúde e educação, de R$ {br(mkp('discricionarias_livres', 2027, 'valor_rs_bi'), 1)} bi para R$ {br(mkp('discricionarias_livres', 2030, 'valor_rs_bi'), 1)} bi, em valores correntes. O PLDO diz não haver previsão de pagamento de destaque de dividendos de 2027 a 2030, e a nota técnica dos dividendos tem acesso restrito. Nas concessões, considera só os contratos vigentes{n('pldo27')}.</li>
<li><b>O que a curva já precifica.</b> Na curva da ANBIMA de {MKC[0]['data_curva']}, a taxa a termo do primeiro ano ({br(float(MKC[0]['taxa_a_termo_prefixada_pct']), 2)}%) fica perto da Selic média que o Focus espera ({br(float(MKC[0]['selic_media_focus_pct']), 2)}%), com diferença de {br(float(MKC[0]['diferenca_pb']), 0)} pb. Do segundo ano em diante, a curva pede de {br(dif2 / 100, 1)} a {br(dif5 / 100, 1)} pontos acima. A maior parte dessa distância está na inflação implícita, de {br(float(MKC[1]['inflacao_implicita_a_termo_pct']), 1)}% a {br(float(MKC[-1]['inflacao_implicita_a_termo_pct']), 1)}% ao ano do segundo ao quinto ano, contra {br(float(MKC[1]['ipca_focus_janela_pct']), 1)}% a {br(float(MKC[-1]['ipca_focus_janela_pct']), 1)}% no Focus, o que responde por {br(float(MKC[1]['diferenca_inflacao_pb']), 0)} a {br(float(MKC[-1]['diferenca_inflacao_pb']), 0)} pb, e não no juro real. Essa parte soma inflação esperada acima do Focus e prêmio de risco de inflação e de liquidez, e a curva sozinha não separa os dois. O cenário 3 da seção 12 supõe Selic e taxas de mercado 1,5 ponto abaixo do caminho atual e não supõe que essa distância se feche. O Focus usado é de 09/10/2026, dez dias antes da curva{n('anbima')}{n('focus')}.</li>
<li><b>Onde está o dinheiro.</b> Um ponto a menos de Selic economiza cerca de R$ {br(ss('selic', 1.0, 'economia_2027_rs_bi'), 0)} bi no primeiro ano, e isso é aritmética (classe A). Um ponto do PIB de primário esperado está associado a juros longos {br(FAIXA['Central'], 0)} pb menores em emergentes, numa faixa de sensibilidade de {br(FAIXA['Baixo'], 0)} a {br(FAIXA['Alto'], 0)} pb que junta duas amostras e não é intervalo de confiança (classe B). Nenhum estudo identifica esse efeito de forma causal para o Brasil de hoje (seção 13).</li>
<li><b>PLDO contra Focus.</b> O PLDO, de abril de 2026, com grade de março, supõe PIB de {br(pb('pib_real_pct', 2027), 1)}% e IPCA de {br(pb('ipca_pct', 2027), 1)}% em 2027, e o Focus de outubro espera {br(pb('focus_pib_pct', 2027), 1)}% e {br(pb('focus_ipca_pct', 2027), 1)}%. Se a macro realizada ficar perto do Focus, a receita fica abaixo da projetada. O PLOA 2027, de agosto, usa grade própria e prevê receita líquida {br(po('Receita primária líquida do Governo Central', 'alem_do_pib_pct_pib_2027'), 2)} ponto do PIB acima do que o crescimento do PIB daria, quase toda pela queda das transferências que acompanha a reforma do consumo, com R$ {br(po('Imposto Seletivo, tributo novo da LC 214/2025, depende de lei ordinária com as alíquotas', 'valor_2027_rs_bi'), 0)} bi de Imposto Seletivo que ainda depende de lei (seção 12){n('pldo27')}{n('focus')}{n('ploa27')}.</li>
<li><b>Os planos em ordem de grandeza.</b> Nenhum dos dois planos do segundo turno traz meta numérica de primário, dívida, carga ou valor de benefício para 2027 a 2030. O do PL traz meta de crescimento de {br(PL_META_PIB, 0)}% ao ano na próxima década e R$ 900 bi em quatro anos em transportes, com fundo lastreado na securitização de ativos da União, PPPs e BNDES, e propõe retomar o Programa Nacional de Desestatização. O do PT propõe a volta da Petrobras à distribuição de combustíveis, uma política de preços que evite expor o consumidor à volatilidade externa e a continuidade das concessões. Cada ponto a menos na alíquota total de IBS e CBS vale cerca de {br(MKI['arrecadacao_por_ponto'], 2)}% do PIB de arrecadação, uns R$ {br(MKI['arrecadacao_por_ponto_rs_bi_2027'], 0)} bi a preços de 2027, pela meta de arrecadação de {br(MKI['meta_de_arrecadacao_ibs_cbs'], 2)}% do PIB da Fazenda e pelo parâmetro de {br(MKI['aliquota_total_cgibs'], 2)}% que o Comitê Gestor usa para estimar o IBS de 2027, que não é alíquota oficial. É quase o tamanho das exclusões da meta de 2027. A conta é estática, sem efeito de comportamento, e a mesma nota da Fazenda cita um padrão internacional de 1% do PIB a cada 2 pontos. Na cultura, o plano do PT fala em investimento direto e economia criativa, e o do PL em rever as leis de incentivo, cuja renúncia é de R$ {br(cur('renuncia_cultura_e_audiovisual'), 1)} bi em 2026. O plano do PL parte de um IVA projetado em torno de 30% (anexo T5){n('tse_pt')}{n('tse_pl')}{n('sert')}{n('cgibs')}.</li>
</ul>
<figure>{svg('0a-curva-focus')}</figure>
<table style="break-inside:avoid"><thead><tr><th>Janela a partir de {MKC[0]['data_curva']}</th><th class=n>Taxa a termo prefixada, %</th><th class=n>Selic média esperada pelo Focus, %</th><th class=n>Diferença, pb</th><th class=n>Juro real a termo, %</th><th class=n>Inflação implícita a termo, %</th></tr></thead><tbody>{linhas_mkc}</tbody></table>
<p class=nota>Taxas a termo de 252 dias úteis tiradas dos vértices da ANBIMA{n('anbima')}. A Selic esperada interpola por mês a média de outubro de 2026 e as medianas de fim de ano do Focus{n('focus')}, e fica plana depois de dez/2030, último ano do Focus. A curva prefixada acompanha o CDI, que fica cerca de 0,1 ponto abaixo da Selic, então a diferença mede um pouco a menos do que o prêmio total.</p>
<table style="break-inside:avoid"><thead><tr><th>Quando</th><th>O quê</th><th>Valor</th><th>Fonte</th></tr></thead><tbody>{linhas_mkk}</tbody></table>
<p class=nota>Datas de 2026 a 2029 que já estão em lei, no PLDO ou em resolução do Comitê Gestor{n('l14663')}{n('l15077')}{n('l8213')}{n('lc214')}{n('cf')}{n('l15270')}{n('pldo27')}. Não inclui datas que dependem do resultado da eleição.</p>"""
CSS = css(os.path.join(AQUI, 'gastos-publicos-brasil.html')) + open(os.path.join(AQUI, 'estilo.css'), encoding='utf-8').read()  # folha comum + a deste volume
HTML = f'''<!doctype html><html lang=pt-br><head><meta charset=utf-8><title>Gastos públicos do Brasil</title><style>
{CSS}
</style></head><body>
<h1>Gastos públicos do Brasil</h1>
<div class=edicao>Volume 1 do dossiê economia-brasil · versão 13 · dados até agosto de 2026</div>
<div class=sub>Despesa da União por linha em 2025, custo por habitante e por beneficiado de 2008 a 2025, juros e dívida por governo, renúncias, quem paga e quem recebe, renda e poder de compra por faixa, resultados em educação e saúde, e as propostas registradas para 2027 a 2030. Dados até agosto de 2026, consultados em 18/10/2026. Cada número traz a fonte primária numerada no fim do documento. As séries e os dados para reproduzir estão nos anexos.</div>
<h2>Sumário</h2>
<!--SUMARIO-->
<h2>Como ler este dossiê</h2>
<ul class=r>
<li><b>Natureza.</b> Investigação independente, aberta a críticas, sem tese eleitoral, elaborada com assistência de ferramentas de IA. Passou por leituras críticas sucessivas feitas com ferramentas de IA de uso geral a pedido do autor, e por cinco auditorias de agentes de IA que não construíram as partes auditadas e refizeram as contas a partir dos dados (v10, v11, v12.3 e duas da v12.5). Os pareceres das cinco estão no pacote, na pasta relatorio. Nenhuma é auditoria de terceiros identificados. Não é recomendação de investimento.</li>
<li><b>Estrutura.</b> A partir da versão 13 o volume tem três partes. A Parte I é o núcleo fiscal, seções 1 a 13. A Parte II traz os anexos temáticos, cultura (T1), agro e meio ambiente (T2), quem paga e quem recebe (T3), educação e saúde (T4), as propostas para 2027 a 2030 (T5), expectativas contra resultados (T6) e investimento das estatais (T7). A Parte III tem método, dados, limites e fontes. Renda por habitante, produtividade, investimento e indicadores sociais estão no volume 2, Desenvolvimento do Brasil.</li>
<li><b>Observado, simulado, não identificado.</b> As seções 1 a 11 e os anexos T1 a T4, T6 e T7 usam dados publicados e indicadores construídos a partir deles (deflações, médias, valores por beneficiado, medidas estimadas como o primário estrutural e a pobreza sem programas). As seções 12 e 13 trazem simulações condicionais, e mostram o que acontece se uma premissa valer. A seção 12 traz também a ponte da receita do PLOA 2027, que decompõe a projeção do governo. As conclusões da seção 13 levam uma de três classes. A é demonstrado, B é compatível com os dados sem identificação causal e C não está demonstrado. O anexo T5 reúne propostas dos planos de governo registrados no TSE e projeções, sem resultado garantido.</li>
<li><b>Juros.</b> {br(100 * float(nota_s['peso_selic']), 0)}% da dívida bruta paga a Selic e muda em meses. Nos títulos indexados ao IPCA, o principal é corrigido pela inflação todo mês, e só a taxa real fica fixa até o vencimento. Nos prefixados, fica fixa a taxa nominal. Uma mudança nas taxas de mercado chega a esses dois grupos só na rolagem, com prazo médio de {br(wdf('prazo_medio_dpf_anos'), 1)} anos na dívida federal (seção 13). Uma queda da Selic tem efeito mecânico bem medido. O efeito de uma reforma fiscal sobre as próprias taxas é muito mais incerto.</li>
<li><b>Dispersão dos cenários de 2030.</b> Vem sobretudo de três premissas. Selic e crescimento (macro do Focus contra a do PLDO, {br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['6'], 2030, 'divida_pct_pib'), 1)} pontos de dívida), deflator do PIB ({br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['2b'], 2030, 'divida_pct_pib'), 1)} pontos por ponto de deflator) e taxas de mercado (seção 12). O ajuste pela receita ou pela despesa move {br(-float(next(r['efeito_pp'] for r in SEN if r['alavanca'] == 'ajuste pela receita')), 1)} a {br(-float(next(r['efeito_pp'] for r in SEN if r['alavanca'] == 'ajuste pela despesa')), 1)} pontos sozinho, e {br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['4'], 2030, 'divida_pct_pib'), 1)} a {br(sc(C['2'], 2030, 'divida_pct_pib') - sc(C['4b'], 2030, 'divida_pct_pib'), 1)} com taxas 1,5 ponto menores, que são premissa.</li>
<li><b>Dados e testes.</b> Cada número tem fonte numerada, o Anexo B lista os arquivos. O pacote traz scripts, testes automáticos e a cobertura da reprodução em pasta limpa. Traz também um simulador da seção 12 para abrir no navegador (relatorio/simulador/simulador.html), que parte dos cenários publicados e é conferido contra eles por um teste de paridade.</li>
</ul>
<h2>O essencial</h2>
<ul class=big>
<li><b>Tamanho e rigidez.</b> Em 2025 (Lula 3) a União teve despesa primária de R$ {br(prim, 1)} bi ({br(desp_pib[2025], 1)}% do PIB){n('rtn')}, {br(pct_obrig, 1)}% dela obrigatória, e juros nominais de R$ {br(jur, 1)} bi ({br(float(uj['pct_pib']), 1)}% do PIB, competência){n('bcb')}. A despesa primária está entre {br(dmin, 1)}% e {br(dmax, 1)}% do PIB desde 2015, fora 2020.</li>
<li><b>Dívida e juros.</b> A dívida bruta estava em {br(dbgg_bacen, 1)}% do PIB em agosto de 2026{n('bcbdiv')}. Entre os emergentes, o Brasil tem os maiores juros ({br(float(mb['juros_liquidos_pct_pib']), 1)}% do PIB, contra {br(float(memg['juros_liquidos_pct_pib']), 1)}% no grupo){n('weo')}, e {br(100 * float(nota_s['peso_selic']), 0)}% da dívida bruta paga a Selic. No Lula 3, juros menos crescimento somaram {fm(L3['ano_juros_mais_pib'])} pontos do PIB por ano à dívida líquida, e o primário, {fm(L3['ano_primario'])}{n('bcbdiv')}.</li>
<li><b>Comparar governos depende da medida.</b> Em 2019-22 e 2023-24, o primário cheio favorece o Lula 3, o recorrente empata e o estrutural favorece o governo Bolsonaro{n('rtn')}{n('spe')}. Cada período tem uma ressalva de peso. Devoluções antecipadas do BNDES de R$ {br(jr('soma_bndes_liquidacao_antecipada', BJ), 1)} bi no governo Bolsonaro{n('bndes')} e o pagamento de R$ {br(KPREC['valor_rs_bi'], 1)} bi de precatórios atrasados em 2023{n('k_prec')}. O juro real da dívida foi de R$ {br(fa('Bolsonaro', 'juro_real'), 0)} bi por ano no governo Bolsonaro, com a inflação de 2021, e R$ {br(fa('Lula 3', 'juro_real'), 0)} bi no Lula 3, com Selic real ex-ante de {br(wsm('Bolsonaro', 'selic_real_ex_ante_meta'), 1)}% contra {br(wsm('Lula 3', 'selic_real_ex_ante_meta'), 1)}%{n('j_bcb')}{n('olinda_ipca')}.</li>
<li><b>Cenários de 2030.</b> Com a macro do Focus e o primário que o PLDO 2027 projeta, a dívida bruta chega a {br(sc(C['2'], 2030, 'divida_pct_pib'), 0)}% do PIB ({br(sc(C['2b'], 2030, 'divida_pct_pib'), 0)}% com deflator 1 ponto acima do IPCA). Com a grade do próprio PLDO, chega a {br(sc(C['6'], 2030, 'divida_pct_pib'), 0)}%{n('focus')}{n('pldo27')}. Nenhum cenário com a macro do Focus a estabiliza até 2030. Os números valem só sob as premissas de cada cenário.</li>
<li><b>Renda e preços por faixa.</b> A renda domiciliar por pessoa dos 40% mais pobres variou {sn(d40('Dilma'))}% de 2012 a 2015, {sn(d40('Temer'))}% de 2015 a 2018, {sn(d40('Bolsonaro'))}% de 2018 a 2022 e {sn(d40('Lula 3'))}% de 2022 a {PCR['ult_dom']}, acima da renda dos 10% mais ricos em {['nenhum', 'um', 'dois', 'três', 'quatro'][n_acima]} dos quatro períodos{n('pnad_dom')}. Alimentação e habitação levam {br(POF[('Até 1.908 Reais', '2.1.1 Alimentação')] + POF[('Até 1.908 Reais', '2.1.2 Habitação')], 0)}% da despesa das famílias de menor renda e {br(POF[('Mais de 23.850 Reais', '2.1.1 Alimentação')] + POF[('Mais de 23.850 Reais', '2.1.2 Habitação')], 0)}% das de maior renda{n('pof')}, e a inflação das mais pobres ficou acima da inflação das mais ricas em {lista(pobres_mais)}{n('ipea_ifr')}. Anexo T3.</li>
<li><b>Cultura.</b> A função Cultura teve a menor média com Bolsonaro, R$ {br(CU_F['Bolsonaro'], 2)} bi por ano, e com a Lei Aldir Blanc de 2020 ficou acima de Temer. Os projetos novos da Lei Rouanet caíram desde 2016 e tiveram a menor média de 2019 a 2022, e a captação ficou entre a de Temer e a de Dilma{n('siop_fun')}{n('salic_painel')}{n('salic')}. O plano do PL não cita o Ministério da Cultura e propõe cortar 10 ministérios. O pessoal e a administração da função Cultura custam {br(float(CVE[2025]['estrutura_pct_despesa_primaria']), 2)}% da despesa primária. Seção 7 e anexos T1 e T5.</li>
<li><b>Agro e meio ambiente.</b> O desmatamento da Amazônia foi de {kmd('Bolsonaro', 'amazonia_media_km2_ano')} km² por ano com Bolsonaro e {kmd('Lula 3', 'amazonia_media_km2_ano')} no Lula 3, e o do Cerrado ficou parecido nos dois, com o maior ano desde 2015 em 2023{n('prodes')}. Gestão Ambiental e Organização Agrária tiveram a menor despesa média com Bolsonaro, com ou sem inversões{n('siop_fun')}. Anexos T2 e T5.</li>
<li><b>Propostas para 2027 a 2030.</b> Os planos registrados no TSE pelas duas candidaturas do segundo turno não trazem meta numérica de primário, dívida, carga tributária ou valor de benefício para 2027 a 2030{n('tse_pt')}{n('tse_pl')}. O do PL traz meta de crescimento de {br(PL_META_PIB, 0)}% ao ano, e o do PT, de 80% das crianças alfabetizadas na idade certa. Pela lei em vigor, o salário mínimo ganha de {br(g_focus, 1)}% a {br(g_pldo, 1)}% acima da inflação de 2027 a 2030{n('l15077')}{n('pldo27')}. Anexo T5.</li>
<li><b>O que a política fiscal pode fazer pelos juros.</b> Um ponto a menos de Selic economiza cerca de R$ {br(ss('selic', 1.0, 'economia_2027_rs_bi'), 0)} bi no primeiro ano. É aritmética, classe A. Um ponto do PIB de primário esperado está associado a juros longos {br(FAIXA['Central'], 0)} pb menores em emergentes (classe B). Não estão demonstrados um efeito causal para o Brasil de hoje nem quanto da alta recente dos juros veio de fora (classe C). Seção 13.</li>
</ul>
<p class=nota><b>Onde está o resto.</b> Despesa da União e do país por linha nas seções 1 e 2, por habitante e por beneficiado na seção 7. Juros por competência e por caixa na seção 1. Despesa e resultado por governo nas seções 3 e 5. Carga tributária, renúncias, emendas parlamentares e rigidez da despesa na seção 4. Estoque e composição da dívida na seção 8. Dívida bruta, líquida e fatores por governo na seção 9. Emergentes e custo por indexador na seção 10. Juro real longo e eventos fiscais na seção 11. Pobreza, Gini, renda e poder de compra por faixa, inflação por faixa de renda, imposto por faixa de renda, previdência por regime e reforma do consumo no anexo T3. Educação e saúde no anexo T4. Cultura no anexo T1 e agro e meio ambiente no anexo T2. Propostas dos dois planos do segundo turno para 2027 a 2030 no anexo T5.</p>
{sec_mk}
<h1 class="parte parte-inicio" id=parte-i>Parte I. Núcleo fiscal</h1>
<h2>1. União, 2025 (Lula 3), por linha</h2>
<figure>{svg('1-uniao-2025')}</figure>
<p class=nota>Juros por competência e despesa primária por caixa aparecem lado a lado, mas são contas diferentes (ver "Como ler a soma"). Uma queda dos juros não abre, sozinha, espaço igual para saúde ou outra despesa, porque o limite do arcabouço vale para a despesa primária, e a meta, para o resultado primário{n('lc200')}.</p>
<table><thead><tr><th>Linha</th><th class=n>R$ bi</th><th class=n>% PIB</th><th class=n>R$ por habitante</th><th>Beneficiados</th><th class=n>R$ por beneficiado/ano</th></tr></thead><tbody>{linhas_u}</tbody></table>
<p><b>Como ler a soma.</b> As linhas acima misturam três medidas que não formam um orçamento único, e os juros têm duas contas diferentes.</p>
<table><thead><tr><th>Medida, 2025</th><th class=n>R$ bi</th><th>Registro</th><th>Entra na soma de {br(pct_tot, 1)}% do PIB?</th></tr></thead><tbody>
<tr><td>Despesa primária</td><td class=n>{br(prim, 1)}</td><td>caixa, critério de valor pago (RTN tabela 2.5), pelo pagamento efetivo na Conta Única (tabela 2.1) são R$ {br(d21[2025] / 1000, 1)} bi{n('rtn')}</td><td>sim</td></tr>
<tr><td>Repasses a estados e municípios</td><td class=n>{br(rep, 1)}</td><td>caixa, receita federal repartida{n('rtn')}</td><td>sim</td></tr>
<tr><td>Juros nominais apropriados</td><td class=n>{br(jur, 1)}</td><td>competência. O juro de cada título no ano em que corre, inclusive a correção monetária do principal dos títulos indexados{n('bcb')}</td><td>sim</td></tr>
<tr><td>Juros pagos pelo orçamento</td><td class=n>{br(jcaixa, 1)}</td><td>caixa, grupo de despesa 2{n('siop')}</td><td>não, os juros contados quando pagos, inclusive os que correram em anos anteriores</td></tr>
<tr><td>Amortização paga sem refinanciamento</td><td class=n>{br(amort, 1)}</td><td>caixa, grupo de despesa 6{n('siop')}</td><td>não, principal da dívida</td></tr>
<tr><td>Refinanciamento (rolagem)</td><td class=n>{br(rolag, 1)}</td><td>caixa, grupo de despesa 6, pago com emissão de títulos{n('siop')}</td><td>não</td></tr>
</tbody></table>
<p class=nota>Os juros por competência são maiores que os pagos porque o título prefixado só paga no vencimento e a correção monetária dos títulos indexados à inflação se incorpora ao principal e, quando paga, sai como amortização. A diferença entre as duas contas não mede, sozinha, dívida nova. A seção 2 usa outro perímetro (União, estados e municípios, 2024) e não se compara com esta soma.</p>
<p class=nota>Despesa pelo RTN, tabela 2.5, valor pago{n('rtn')}. Os créditos extraordinários de Bolsa Família, saúde e educação voltam para a sua linha. Juros nominais apropriados no ano, Governo Federal sem o BCB{n('bcb')}. A rolagem da dívida fica fora. Os juros não têm divisão por beneficiado. Os detentores da dívida estão na seção 8, e o Tesouro Direto tem {br(det['Tesouro Direto'], 1)}% dela{n('rmd')}. Saúde e educação ficam sem divisão por beneficiado. A despesa é federal sem pessoal e a rede atendida é sobretudo de estados e municípios, então a conta não mede custo por atendido. A conta é por benefício, e uma pessoa pode ter mais de um. Em dez/2024 eram {br(inss_pessoas)} pessoas com benefício do INSS{n('benef')}. INSS, BPC e Bolsa Família. Média dos 12 meses de 2025{n('benef')}. Servidores. Despesa total de pessoal ativo dividida pelos postos, que difere da renda de cada servidor. Repasses sem divisão por beneficiado. População{n('ibge')}.</p>
<h2>2. País inteiro, 2024 (Lula 3, União, estados e municípios)</h2>
<table><thead><tr><th>Função</th><th class=n>R$ bi</th><th class=n>% PIB</th></tr></thead><tbody>{linhas_p}</tbody></table>
<p class=nota>COFOG do Tesouro, governo geral consolidado{n('cofog')}. Juros nominais de {br(j_br, 1)}% do PIB no Brasil contra {br(j_oc, 1)}% na média simples da OCDE, países com inflação e juro básico menores{n('fmi')}, saúde {br(s_br, 1)}% contra {br(s_oc, 1)}%{n('oecd_saude')}. Cultura, esporte e lazer são gasto direto das três esferas. As renúncias fiscais, como a Lei Rouanet, ficam fora porque entram como receita que deixa de existir. O país gastou R$ {br(cur('pais_cultura_tres_esferas'), 1)} bi com cultura em 2024, R$ {br(cur('pais_cultura_por_habitante'), 0)} por habitante, e {br(JUR_PAIS / cur('pais_cultura_tres_esferas'), 0)} vezes isso com juros{n('cofog')}.</p>
<h2>3. Despesa e resultado por governo, 1997 a 2025</h2>
<figure>{svg('2-primario-governos')}</figure>
<p class=nota>Governo Central, % do PIB{n('rtn')}. A faixa hachurada é 2016, ano da troca de governo.</p>
<p><b>Regras e eventos que mudam a leitura</b></p>
<ul class=r>
<li>2016, Temer. EC 95, teto para a despesa primária por vinte exercícios{n('ec95')}.</li>
<li>2019, Bolsonaro. EC 103, reforma da Previdência{n('ec103')}.</li>
<li>2020 e 2021. LC 173 proíbe reajuste de servidores e militares até o fim de 2021, salvo decisão judicial ou lei anterior{n('lc173')}. A despesa com servidores ativos por habitante caiu de R$ {br(hs19)} (2019) para R$ {br(hs22)} (2022), em R$ de 2025. O pessoal total foi de {br(pes_pib[2019], 1)}% para {br(pes_pib[2022], 1)}% do PIB{n('rtn')}.</li>
<li>2021. A LC 179 dá autonomia ao Banco Central, e o mandato do presidente do BC começa no terceiro ano do mandato presidencial{n('lc179')}. EC 114 limita o pagamento anual de precatórios até 2026{n('ec114')}.</li>
<li>2022. EC 123, adicional de R$ 200 no Auxílio Brasil de agosto a dezembro{n('ec123')}.</li>
<li>2023, Lula 3. A EC 126 amplia o limite de 2023 em R$ 145 bi{n('ec126')}, a LC 200 cria o novo regime fiscal{n('lc200')} e a Lei 14.663 institui o aumento real do salário mínimo{n('l14663')}. Precatórios fora de benefícios e pessoal. R$ {br(hist[('precatorios', 2022)], 1)} bi em 2022 e R$ {br(hist[('precatorios', 2023)], 1)} bi em 2023{n('rtn')}.</li>
<li>2020 e 2021. O Auxílio Emergencial custou R$ {br(ae[2020] / 1000, 1)} bi e R$ {br(ae[2021] / 1000, 1)} bi em créditos extraordinários{n('rtn')}.</li>
</ul>
{sec_receita}
{sec_recorrente}
<h2>6. Trajetória das maiores linhas, R$ bi de 2025</h2>
<figure>{svg('5-rs-bi')}</figure>
<p class=nota>Despesa{n('rtn')}, juros nominais{n('bcb')}, deflator IPCA dezembro a dezembro{n('ipca')}.</p>
<h2>7. Por habitante e por beneficiado, 2008 a 2025</h2>
<table><thead><tr><th>R$ de 2025 por habitante</th>{''.join(f'<th class=n>{a}</th>' for a in sel)}<th class=n>2025/2008</th></tr></thead><tbody>{linhas_h}</tbody></table>
<p class=nota>2008 Lula 2, 2014 Dilma, 2019 e 2022 Bolsonaro, 2025 Lula 3. Despesa{n('rtn')}, juros{n('bcb')}, população{n('ibge')}, IPCA{n('ipca')}.</p>
<figure>{svg('3-por-habitante')}</figure>
<figure>{svg('4-por-beneficiado')}</figure>
<p class=nota>Beneficiados{n('benef')}. INSS por benefício (com acidentários), Bolsa Família por família, servidores por posto. INSS, BPC e Bolsa Família divididos pela média dos 12 meses do ano (Boletim Estatístico da Previdência, quadro 14, e MI Social do MDS){n('benef')}, servidores pelo número de referência. Bolsa Família em 2020 e 2021. Só famílias pagas pelo próprio programa, sem o Auxílio Emergencial, que tem despesa em outra linha. Em 2022 e jan-fev/2023 (Auxílio Brasil) a fonte só traz famílias beneficiárias. Saúde e educação aparecem só por habitante, acima.</p>
<p><b>Cultura.</b> A função Cultura da União liquidou R$ {br(cu(2025, 'liquidado_rs_bi'), 2)} bi em 2025, {br(cu(2025, 'pct_pib'), 3)}% do PIB e R$ {br(cu(2025, 'rs_2025_por_habitante'), 2)} por habitante{n('rreo_funcao')}. O Ministério da Cultura teve dotação de R$ {br(cur('minc_dotacao_atualizada'), 2)} bi e liquidou R$ {br(cur('minc_liquidado'), 2)} bi no mesmo ano, numa conta por órgão que não coincide com a da função{n('siop')}. Em reais de 2025, a função ficou perto de R$ {br(cu(2015, 'liquidado_rs_bi_2025'), 1)} bi por ano de 2015 a 2018, caiu a R$ {br(cu(2022, 'liquidado_rs_bi_2025'), 2)} bi em 2022 e voltou a R$ {br(cu(2023, 'liquidado_rs_bi_2025'), 1)} bi em 2023. Por habitante, foi de R$ {br(cu(2015, 'rs_2025_por_habitante'), 2)} em 2015 a R$ {br(cu(2022, 'rs_2025_por_habitante'), 2)} em 2022 e a R$ {br(cu(2025, 'rs_2025_por_habitante'), 2)} em 2025. Os juros nominais da União em 2025 equivalem a cerca de {br(jur / cu(2025, 'liquidado_rs_bi'), 0)} vezes o que ela liquidou em cultura{n('bcb')}.</p>
<figure>{svg('7c-cultura')}</figure>
<p class=nota>Função Cultura da União, despesas liquidadas, exceto intra-orçamentárias, RREO do 6º bimestre{n('rreo_funcao')}. R$ de 2025 pelo IPCA de dezembro a dezembro{n('ipca')}, população pela projeção do IBGE{n('ibge')}. Não inclui as renúncias da cultura (seção 4), que em 2026 somam mais que a despesa direta. A série mostra o gasto e não mede o resultado cultural, que nenhuma fonte consolidada mede por ano.</p>
<h2>8. A dívida que gera os juros (agosto de 2026, Lula 3)</h2>
<table><tbody>
<tr><td>Dívida pública federal</td><td class=n>R$ {br(dpf, 2)} tri</td></tr>
<tr><td>Selic / inflação / prefixada / câmbio</td><td class=n>{br(idx['Taxa flutuante'], 1)}% / {br(idx['Indice de precos'], 1)}% / {br(idx['Prefixado'], 1)}% / {br(idx['Cambio'], 1)}%</td></tr>
<tr><td>Vence em 12 meses</td><td class=n>R$ {br(float(venc['valor_brl']) / 1e12, 2)} tri ({br(float(venc['pct_total']), 1)}%)</td></tr>
<tr><td>Prazo médio</td><td class=n>{br(prazo, 2)} anos</td></tr>
<tr><td>Custo médio do estoque / das emissões novas, 12 meses</td><td class=n>{br(custo, 2)}% / {br(emis, 2)}% ao ano</td></tr>
<tr><td>Detentores. Bancos / previdência / fundos / estrangeiros / Tesouro Direto</td><td class=n>{br(det['Instituicoes'], 1)}% / {br(det['Previdencia'], 1)}% / {br(det['Fundos'], 1)}% / {br(det['Nao residentes'], 1)}% / {br(det['Tesouro Direto'], 1)}%</td></tr>
<tr><td>Dívida bruta do governo geral, Bacen / FMI</td><td class=n>{br(dbgg_bacen, 1)}% / {br(dbgg_fmi, 1)}% do PIB</td></tr>
<tr><td>Juros nominais, 12 meses até ago/2026, Governo Federal</td><td class=n>R$ {br(float(j12['valor_brl']) / 1e9, 1)} bi</td></tr>
<tr><td>Juros nominais, setor público consolidado, 12 meses até ago/2026</td><td class=n>R$ {br(float(jsp['valor_brl']) / 1e9, 1)} bi ({br(float(jsp['pct_pib']), 2)}% do PIB)</td></tr>
</tbody></table>
<p class=nota>Dívida federal{n('rmd')}, dívida bruta{n('bcbdiv')}, juros{n('bcb')}. Conta feita com esses dados. A parcela em Selic é R$ {br(selic_rs / 1000, 2)} tri, então 1 ponto a mais de Selic custa cerca de R$ {br(selic_rs / 100)} bi por ano. É um piso. Não conta as operações compromissadas do BC nem a reprecificação dos títulos que vencem em 12 meses.</p>
<h2>9. Superávit e evolução da dívida, por governo</h2>
<figure>{svg('6-divida')}</figure>
<p class=nota>Dívida bruta do governo geral (critério Bacen) e dívida líquida do setor público, % do PIB em dezembro{n('bcbdiv')}. De 2018 em diante, uma só safra do BCB. Antes, vale a edição mais nova de cada ano (o PIB é revisado depois).</p>
{sec_dbgg}
{sec_dreal}
{sec_regra}
<table><thead><tr><th rowspan=2>Governo</th><th class=n rowspan=2>Primário médio</th><th class=n rowspan=2>Dívida bruta</th><th class=n rowspan=2>Dívida líquida</th><th class=n colspan=6>Fatores da dívida líquida, pontos do PIB por ano</th></tr>
<tr><th class=n>Primário</th><th class=n>Juros</th><th class=n>Câmbio</th><th class=n>PIB</th><th class=n>Outros</th><th class=n>Juros + PIB</th></tr></thead><tbody>{linhas_m}</tbody></table>
<p class=nota>Primário médio. Governo Central, % do PIB por ano, positivo é superávit{n('rtn')}. Dívida. Dezembro anterior ao início e dezembro do fim{n('bcbdiv')}. Fatores. Setor público consolidado, média por ano do mandato. Positivo aumenta a dívida, e no primário positivo é déficit. Outros. Variação observada menos os quatro fatores (reconhecimento de dívidas, privatizações, ajustes de método e de safra do PIB){n('bcbdiv')}. Fatores só a partir de 2006. Lula 3 está incompleto.</p>
<figure>{svg('7-fatores')}</figure>
<p>{texto_div}</p>
{sec_ponte}
{sec_emerg}
{sec_juro}
<div class=parte>Simulações condicionais, seções 12 e 13</div>
{sec_cen}
{sec_ploa}
{sec_fiscal}
<h1 class="parte parte-inicio" id=parte-ii>Parte II. Anexos temáticos</h1>
{sec_cultura_hist}
{sec_cultura_ocde}
{sec_agro_hist}
{sec_dist}
{sec_res}
{sec_prop}
{sec_fb}
{sec_ee}
<h1 class="parte parte-inicio" id=parte-iii>Parte III. Método e dados</h1>
{sec_anexo}
{sec_anexo_c}
<h2>Limites dos dados</h2>
<ul class=nota>
<li>Valores reais pelo IPCA de dezembro a dezembro{n('ipca')}. População pela projeção do IBGE revisada pelo Censo 2022{n('ibge')}. Mandatos por ano civil, 2016 aparece separado.</li>
<li>O primário aparece em três medidas (cheio, recorrente e estrutural) e a ordem entre governos muda conforme a medida (seção 5).</li>
<li>Os juros do Governo Federal (sem BCB) somam-se ao primário do Governo Central (com BCB), a diferença é pequena e está declarada. Os fatores da dívida são do setor público consolidado.</li>
<li>Servidores. Sem dado de 2015 a 2019, em 2008 os militares vêm de outra fonte (SIAFI) que nos anos seguintes (Defesa), o que infla o número de 2008{n('benef')}.</li>
<li>Bolsa Família inclui os créditos extraordinários do programa (o adicional de 2022). O Auxílio Emergencial de 2020 e 2021 fica fora, em "Demais obrigatórias". INSS, BPC e Bolsa Família divididos pela média mensal do ano. No Bolsa Família faltam meses em 2010 (8 com dado), 2011 (10), 2014 e 2021 (11), e 2022 conta famílias beneficiárias, não pagas{n('benef')}</li>
<li>Primário recorrente de 2025 é estimativa parcial (a SPE publicou só o 1º semestre). Fluxos entre BC e Tesouro levantados de 2008 a 2025. O uso desse dinheiro na dívida só é declarado pelo Tesouro em 2020 (parcial) e 2022, e o de 2020 é conta a partir do relatório da dívida{n('stnbc')}{n('rad')}.</li>
<li>FMI. Juros líquidos do governo geral, a dívida bruta do Brasil no FMI inclui os títulos na carteira do BC. A comparação com outros países usa o conceito de cada um, descrito na seção 10.</li>
<li>Poder de compra. A cesta do DIEESE é só de São Paulo. A renda do trabalho e a renda domiciliar da PNAD Contínua começam em 2012. A inflação por faixa do Ipea começa em julho de 2006, e na renda alta de 2007 a 2012 as duas abas da planilha divergem{n('dieese')}{n('pnad_dom')}{n('ipea_ifr')}.</li>
<li>Cultura. A série da função Cultura começa em 2015 no formato atual do RREO e em 2000 no SIOP (anexo T1), e mede gasto, não resultado. Não há indicador anual consolidado de acesso ou de produção cultural nas fontes usadas. Estados e municípios só entram no total de 2024 da seção 2{n('rreo_funcao')}{n('cofog')}.</li>
<li>Agro e meio ambiente. O PRODES mede o corte raso da vegetação nativa e não mede degradação, queimada sem corte nem regeneração, e o dado de 2026 pode ser revisado{n('prodes')}. A função Gestão Ambiental mistura órgãos e programas, e o dossiê tira dela só a subfunção Recursos Hídricos. As equalizações do Orçamento de Subsídios e o liquidado da função Agricultura usam critérios diferentes e não se somam{n('osu_serie')}. Mandato data o valor e não atribui causa ao desmatamento nem à safra.</li>
<li>Cultura e governo. A busca de temas olha só o nome do projeto no painel do Ministério da Cultura e não separa procura de decisão. Mede a frequência de palavras no nome, e não o conteúdo do projeto. A leitura manual de uma amostra e dos sinônimos dá a ordem de grandeza do erro, com amostras pequenas por governo. O liquidado das transferências por lei não inclui os restos a pagar, e por isso a Lei Paulo Gustavo não aparece como despesa em nenhum ano. A comparação muda com o critério, liquidado ou empenho{n('siop_cv')}. O Google Trends é índice relativo e amostral, e busca não é opinião{n('trends')}. Os ministérios são contados pelos incisos do artigo que os lista em cada lei, e o plano do PL não diz em que base conta os 10. O vínculo entre a portaria de 2019 e algum tema do edital não está em documento primário baixado e fica fora.</li>
<li>Propostas. O anexo T5 cita os planos de governo como estavam no TSE em 20/10/2026 e não acompanha declarações de campanha feitas fora deles. As projeções do PLDO são de março de 2026 e as do Focus, de outubro{n('tse_pt')}{n('tse_pl')}{n('pldo27')}{n('focus')}.</li>
<li>Seguro-desemprego e abono arredondados a 100 mil pela fonte. Matrículas de 2025 usam o ensino superior federal de 2024, ANS conta vínculos, não pessoas{n('benef')}.</li>
</ul>
<h2>Fontes</h2>
<ol class=f>{''.join(f'<li>{lk(FONTES[k])}</li>' for k in ORDEM)}</ol>
</body></html>'''
# Receita de pontuação adotada no texto (sem dois-pontos e sem ponto-e-vírgula), aplicada ao HTML final.
# Dois-pontos vira ponto e maiúscula. Ponto-e-vírgula vira vírgula dentro de parênteses e entre itens curtos de lista, e ponto
# e maiúscula quando junta duas frases inteiras (a vírgula ali emendaria frases e confundiria a leitura, regra de clareza).
# Não toca tags, SVG, CSS, URLs, entidades nem os títulos de obras citadas, que ficam como a fonte os escreve.
TITULOS = ['Tributação indireta: alíquotas efetivas e incidência sobre as famílias']
HTML = endereca(glifos(_voz(HTML, TITULOS)))
ARQ_HTML = os.path.join(AQUI, 'gastos-publicos-brasil.html'); pdf = os.path.join(AQUI, 'gastos-publicos-brasil.pdf')
def imprime(h):
  open(ARQ_HTML, 'w', encoding='utf-8').write(h)
  imprime_pdf(ARQ_HTML, pdf)  # WeasyPrint; MOTOR_PDF=chrome volta ao Chrome
# duas passadas: a primeira da a pagina de cada titulo pelo outline do PDF, a segunda imprime o sumario com elas
import fitz
IGN = ('Gastos públicos do Brasil', 'Sumário')
imprime(HTML.replace('<!--SUMARIO-->', sumario([], HTML, IGN)))
for _ in range(3):
  toc = fitz.open(pdf).get_toc()
  imprime(HTML.replace('<!--SUMARIO-->', sumario(toc, HTML, IGN)))
  if fitz.open(pdf).get_toc() == toc: break
print(pdf)
# separatas temáticas, recortadas do HTML final (monta_tematicos.py)
import monta_tematicos; monta_tematicos.roda()

# Auditoria da seção 16 e da frente MK, versão v12.2

Cópia que acompanha o pacote, sem mudança de redação. As correções que ela pediu entraram na v12.3, descrita no CHANGELOG.md da raiz do pacote.

Esta é uma auditoria feita por um agente de IA (Claude, Anthropic), a pedido do autor, sem participação na construção do dossiê. Não é parecer de auditor humano identificado. O agente só leu os arquivos do dossiê e não editou nenhum deles. Data da leitura 20/10/2026.

## Escopo e método

Objeto. Seção 16 (páginas 41 a 46 do PDF) e nota "Para quem aloca capital" (páginas 3 e 4) de "Gastos públicos do Brasil", v12.2, com os arquivos PR-propostas.csv, PR-ausencias.csv, PR-base.csv, MK-*.csv, build_PR.py, build_MK.py e as fontes primárias no pacote.

O que foi feito.

1. Leitura integral, no texto extraído por PyMuPDF, de todas as páginas que sustentam as 37 citações (PT páginas 18, 32, 37, 45, 48, 49, 53, 57, 66, 74 e 75, PL páginas 31, 33, 35, 36, 37, 42, 43, 44, 45, 47, 69, 70, 71 e 72), mais as seções econômicas inteiras dos dois planos (PT páginas 10 a 20, 31 a 37, 44 a 59, 63 a 67 e 73 a 77, PL páginas 29 a 53 e 68 a 73). A amostra pedida era de 20 citações. Foram lidas as 37.
2. Recontagem independente dos 17 termos da matriz nos dois PDFs, com a mesma normalização do script, e contagem de 40 termos alternativos para testar se a lista favorece um lado por construção. Consulta ao histórico do git para saber quando cada termo entrou na lista.
3. Releitura do texto da seção 16, da tabela "Perguntas concretas" e da tabela "Efeitos possíveis por faixa de renda" contra os planos e as leis citadas.
4. Recálculo da frente MK a partir dos vértices da ANBIMA de 19/10/2026, do Focus de 09/10/2026, das tabelas 1, 3, 5 e 8 do PLDO 2027, da nota SERT/MF de 01/07/2024 e de V-reforma-consumo.csv, e conferência do calendário contra o texto das leis baixadas.
5. Busca, nos dois PDFs, de todos os números de primário, dívida, carga e benefício, e de toda frase com número e verbo no futuro.

Classes. ERRO é número, fonte ou citação errada, ou afirmação factual desmentida pela fonte. VIES é assimetria editorial entre as candidaturas. EXCESSO é afirmação além do dado. NOTA é melhoria.

## O que foi conferido e está certo

- As 37 citações são literais e estão na página indicada. Nenhuma foi tirada de contexto a ponto de inverter o sentido. Os recortes que mudam a leitura estão listados como VIES abaixo.
- As 17 contagens da matriz se reproduzem exatamente (tabela no Anexo 1).
- PLDO 2027, tabela 3. Primário projetado de R$ 7,99 bi (0,05% do PIB) em 2027, exclusões de R$ 65,66 bi (0,45%), meta de R$ 73,22 bi (0,50%), e 0,62%, 0,93% e 1,26% de 2028 a 2030. Conferido na página 16 do anexo. A soma com exclusões dá R$ 73,65 bi, e o próprio PLDO registra a sobra de R$ 0,43 bi.
- PLDO 2027, tabela 5. Despesa primária de 18,85% do PIB em 2027 e 17,98% em 2030, receita líquida de 18,90%. Conferido no texto da página 20 do anexo.
- PLDO 2027, tabela 8. Discricionárias líquidas de emendas e mínimos de R$ 142.990,35 mi, R$ 118.263,65 mi, R$ 119.073,72 mi e R$ 108.024,33 mi de 2027 a 2030. Conferido.
- Ponto de IVA. 12,30 dividido por 27,91 dá 0,4407% do PIB, e sobre o PIB nominal de 2027 do PLDO (R$ 14.643,2 bi) dá R$ 64,53 bi. A nota SERT diz 12,30% na página 5 e o padrão de 1% do PIB a cada 2 pontos na página 14. Conferido.
- Curva a termo. As cinco taxas a termo prefixadas (12,89, 12,66, 13,05, 13,34 e 13,43), as reais (6,33, 7,36, 7,06, 6,90 e 6,86), as implícitas e as Selic médias do Focus (12,92, 11,56, 10,38, 10,01 e 10,00) se reproduzem com a fórmula do script.
- Salário mínimo. R$ 1.745 em 2027 com o Focus (1.621 vezes 1,052245 vezes 1,023, arredondado para cima) e ganho real acumulado de 7,6% (Focus) e 10,0% (PLDO, com o teto de 2,5% aplicado em 2029 e 2030). Conferido.
- Calendário. ADCT art. 35, § 2º, III, CF art. 82 (posse em 5 de janeiro), Lei 14.663 (INPC até novembro e PIB de dois anos antes), Lei 15.077 art. 4º (0,6% a 2,5%), Lei 8.213 art. 41-A, Lei 15.270 art. 16-A (exercício de 2027, ano-calendário de 2026, alíquota de 0 a 10% entre R$ 600 mil e R$ 1,2 mi) e o ICMS e ISS a 90% em 2029. Conferido.
- A nota MK não chama o diferencial da curva de prêmio fiscal e diz que a curva sozinha não separa prêmio de prazo de trajetória da Selic. Isso está correto.

## Resumo

| Classe | Quantidade | Itens |
|---|---|---|
| ERRO | 7 | E1 a E7 |
| VIES | 7 | V1 a V7 |
| EXCESSO | 7 | X1 a X7 |
| NOTA | 10 | N1 a N10 |

Os dois achados de maior peso, a cinco dias do segundo turno, são o E1 (o texto diz que nenhum plano traz meta de crescimento ou investimento, e o do PL traz as duas) e o par E2 com V1 (a matriz de termos é apresentada como fixada antes da contagem, mas 9 das 10 células "ausente" vêm de termos escolhidos na v12 justamente por estarem ausentes num plano). Os vieses não correm todos para o mesmo lado. V1, V4 e V6 fazem o PL parecer mais vago do que é em economia e orçamento familiar, ou o PT mais vago em contas públicas. V2, V3 e V5 favorecem o PL na leitura fiscal.

## ERRO

### E1. "Nenhum dos planos traz meta de crescimento, emprego, inflação ou investimento"

**Onde.** Página 43, parágrafo depois da tabela de base. Repete-se em "Os dois indicam a direção e não trazem números" e em "A distância entre o governo e o mercado é maior que qualquer número dos planos".

**Evidência.** Plano do PL, página 49, "Nossa meta é dobrar esse ritmo e alcançar um crescimento sustentado de 4% ao ano ao longo da próxima década". Página 51, "Vamos investir R$ 900 bilhões em quatro anos em rodovias, hidrovias, portos, aeroportos e ferrovias". A meta de 4% contra o Focus de 1,4% para 2027 é uma distância de 2,6 pontos, maior que a distância entre PLDO e Focus (1,2 ponto). A terceira frase também fica falsa. O plano do PT não traz número de crescimento ("sustentar taxas robustas de crescimento", página 48).

**Correção.** Dizer que o plano do PL traz meta de crescimento de 4% ao ano na próxima década e investimento de R$ 900 bi em quatro anos em transportes, sem dizer quanto é dinheiro público, e que o do PT não traz número. Pôr a meta de 4% ao lado do PLDO e do Focus. Incluir o trecho da página 49 ou 51 na tabela "Economia nacional", na linha de investimento ou numa linha de crescimento, e rever a frase sobre a distância entre governo e mercado.

### E2. "com a mesma lista para os dois, fixada antes da contagem"

**Onde.** Página 42, primeiro parágrafo de "Os mesmos termos nos dois planos".

**Evidência.** O próprio build_PR.py diz que a lista foi fixada "antes da contagem dos termos novos (os oito primeiros vinham da v12, contados so num plano)". O PR-ausencias.csv do commit 8a8724e8 (v12) mostra que esses oito termos eram salário mínimo, Imposto de Renda, Bolsa Família e BPC no PL, superávit, dívida pública e meta fiscal no PT, e 40 horas, escolhidos como ausências depois da leitura. Das 10 células "ausente" da matriz atual, 9 vêm desses termos. Só "privatização ou desestatização" no PT vem dos nove termos novos.

**Correção.** Trocar por "nove dos 17 termos foram fixados antes da contagem. Os outros oito vieram da v12, onde tinham sido escolhidos como ausências num dos planos". Melhor ainda, refazer a matriz com uma lista fechada antes de qualquer leitura (ver V1).

### E3. "O plano do PT não traz mudança tributária nova"

**Onde.** Página 44, parágrafo de impostos. Repete-se em "Sem mudança tributária nova" (tabela por faixa, renda média), "Justiça tributária anunciada, sem medida nova" (renda alta) e "O PT fala em justiça tributária, sem medida nova" (Perguntas concretas).

**Evidência.** Plano do PT, página 59, "Ao regulamentar a reforma tributária, vamos, por meio do Imposto Seletivo, desestimular produtos nocivos à saúde". As alíquotas do Imposto Seletivo dependem de lei ordinária (LC 214, art. 422, já registrado em V-reforma-consumo.csv), então é medida tributária nova, e pesa sobre consumo de bebidas açucaradas e alcoólicas, o que importa para a faixa de renda baixa. Página 77, "buscar reestruturar a base de financiamento da Previdência, buscando a diversidade das fontes de custeio", e "inserir na regulação do trabalho mediado por plataforma o financiamento da previdência social". Página 49, o resultado fiscal virá também "do combate aos privilégios e às distorções", que é a via da receita.

**Correção.** Dizer que o plano do PT não propõe mudança no Imposto de Renda nem no IVA, e propõe usar o Imposto Seletivo contra produtos nocivos à saúde e diversificar as fontes de custeio da Previdência, sem números. Levar isso à tabela por faixa.

### E4. "Fechar parte dela é o que o cenário 3 da seção 14 supõe"

**Onde.** Página 3, item "O que a curva já precifica".

**Evidência.** S-cenarios-divida.csv descreve o cenário 3 como "como o 2, com Selic e taxas de mercado 1,5 ponto abaixo desde 2027". A Selic do cenário fica 1,5 ponto abaixo do Focus (11,12% em 2027) e as taxas de mercado caem os mesmos 1,5 ponto. A distância entre a curva e a Selic do Focus, que é o que o item mede, não é fechada. As duas pontas descem juntas, e a Selic desce abaixo do que o Focus espera.

**Correção.** "O cenário 3 da seção 14 supõe Selic e taxas de mercado 1,5 ponto abaixo do caminho atual. Ele não supõe que a distância entre a curva e o Focus se feche."

### E5. "uns R$ 64 bi a preços de 2027"

**Onde.** Página 3 e página 43.

**Evidência.** 0,4407% vezes R$ 14.643,2 bi dá R$ 64,53 bi. O script grava 64,5 no CSV e o relatório arredonda 64,5 para 64 (arredondamento do Python para o par mais próximo, aplicado a um valor já arredondado). O valor certo com zero casas é R$ 65 bi.

**Correção.** Arredondar a partir do valor não arredondado, ou gravar o CSV com duas casas. Escrever R$ 65 bi.

### E6. Célula "Termo ausente, 0 em 76 páginas" para salário mínimo no PL

**Onde.** Página 43, tabela "Orçamento familiar", e matriz da página 42.

**Evidência.** A expressão regular "salário mínimo|salário-mínimo" não conta o plural. O plano do PL, página 29, diz "85% das que ganham até três salários mínimos estão endividadas". O termo aparece, como unidade de renda e não como política. Em sentido contrário, a normalização do script junta quebras de linha com espaço, e o plano do PT, página 58, tem "salário-" no fim de uma linha e "mínimo" na seguinte. A contagem do PT fica em 6 quando seriam 7. A conclusão de que o PL não tem proposta para o salário mínimo continua certa.

**Correção.** Contar o plural, juntar hifenização de fim de linha antes de contar, e trocar "Termo ausente" por "Sem proposta sobre o salário mínimo (o termo aparece uma vez, como unidade de renda)".

### E7. "Nenhum dos dois planos traz número para o resultado primário, para a dívida ou para a carga tributária"

**Onde.** Página 43, e na nota MK, página 3, "Nenhum dos dois planos do segundo turno traz número para primário, dívida, carga ou benefício". Também no Essencial.

**Evidência.** Lidos ao pé da letra, os dois planos trazem esses números, sempre sobre o passado ou o presente. PT, página 11, "o déficit primário encerrará 2026 próximo de 0,4% do PIB" e "esforço fiscal, de aproximadamente 2% do PIB, R$ 240 bilhões". PT, página 15, emendas de R$ 50 bi em 2026. PL, páginas 29 e 68, dívida bruta "13 pontos percentuais" maior em quatro anos e "reduzimos em 4 pontos percentuais". PL, página 30, IVA "projetado em torno de 30%, contra uma média de 19% nos países da OCDE". PL, página 29, "30 aumentos de tributos". Nenhum desses números é meta para 2027 a 2030. A busca de toda frase com número e verbo no futuro não achou meta de primário, dívida, carga ou valor de benefício em nenhum dos dois.

**Correção.** "Nenhum dos dois planos traz meta numérica de primário, dívida, carga ou valor de benefício para 2027 a 2030." O resto da afirmação se sustenta.

## VIES

### V1. A lista de termos favorece a ausência de um lado por vocabulário

**Onde.** Matriz da página 42.

**Evidência.** Vários termos são o vocabulário de um dos planos para o mesmo assunto. Em contas públicas, "superávit" é a palavra do PL (PT 0, PL 1), enquanto o PT fala em déficit primário. A raiz "primári" dá PT 4 e PL 1, e "responsabilidade fiscal" dá PT 3 e PL 1. Em orçamento familiar, "Bolsa Família" é o nome do programa do governo atual (PT 5, PL 0), enquanto o PL fala em "programas sociais" (PT 0, PL 12) e compromete-se a mantê-los (página 42). "Moradia ou habitação" dá PT 10 e PL 5, mas "casa própria" dá PT 0 e PL 12. "40 horas ou 6x1" dá PL 0, mas o PL toma posição sobre a jornada na página 45 ("onde o governo deseja ignorar a prevalência do negociado sobre o legislado") e propõe "jornada flexível" na página 44. Em sentido contrário, "aposentado" favorece o PL (PT 3, PL 12), enquanto "previdên" dá PT 5 e PL 2. O resultado visual é o PL ausente em 5 das 8 linhas de orçamento familiar, onde ele tem dois capítulos inteiros ("Brasil Mais Barato" e "Brasil que Prospera"), e o PT ausente em 3 das 5 linhas de contas públicas, onde ele fala em déficit primário, arcabouço e responsabilidade fiscal. Os termos que dariam ausência no outro lado ficaram de fora nos dois sentidos, por exemplo "IVA" (PT 0, PL 3), "voucher" (PT 0, PL 8), "Pé-de-Meia" (PT 5, PL 0), "PAC" (PT 30, PL 0).

**Correção.** Para cada tema, contar o vocabulário dos dois planos (por exemplo "superávit ou déficit primário", "Bolsa Família ou programas sociais ou transferência de renda", "moradia ou habitação ou casa própria", "jornada"), ou separar na tabela "termo de proposta" de "nome de programa". Manter a nota de que a matriz conta palavra e não proposta, e tirar "mostra de uma vez o que cada plano trata e o que não trata" (X1).

### V2. Cada plano é associado a um cenário de dívida de forma assimétrica

**Onde.** Página 43, fim do parágrafo de contas. "Manter o arcabouço corresponde ao cenário 2 da seção 14. Um primário maior que o do PLDO, que o plano do PL descreve sem número, aparece nos cenários 4 e 4b."

**Evidência.** O PT fica ligado ao cenário 2 (dívida de 98% do PIB em 2030) e o PL aos cenários 4 e 4b (90,5% e 90,4%), que também supõem Selic e taxas de mercado 1,5 ponto menores. O cenário 4 é ajuste pela receita, com 1/5 dos gastos tributários virando arrecadação. A via declarada pelo PT para o resultado fiscal inclui "o combate aos privilégios e às distorções" (página 49), que é a via da receita, e o PL propõe ao mesmo tempo reduzir o IVA, os impostos sobre energia e combustíveis e o custo do trabalho, o que vai no sentido oposto ao do cenário 4. O texto credita ao PL a intenção declarada de superávit sem descontar os cortes de tributo que ele também propõe, e não credita ao PT a via de receita que ele declara. O cenário 2 é a projeção do PLDO, que também tem superávits crescentes até 1,26% do PIB.

**Correção.** "O cenário 2 é a lei em vigor com a macro do Focus. Os cenários 4 e 4b ilustram ajustes que nenhum dos planos quantifica. O do PL fala em superávits e também propõe cortes de tributos que reduzem o primário, e o do PT fala em controle do gasto e em combate a privilégios tributários. Nenhum dos dois permite situá-lo num cenário."

### V3. O mecanismo dos juros aparece só para o PL

**Onde.** Página 43, "O do PT promete elevar a taxa de investimento e criar condições para juros menores com inflação controlada. O do PL promete juros na média internacional e inflação no centro da meta a partir da queda da dívida."

**Evidência.** O trecho do PT na página 49 continua "e assegurando uma política fiscal responsável. Para isso, manteremos o novo arcabouço fiscal". O PT liga os juros à política fiscal da mesma forma que o PL liga à dívida (página 33 e página 71). O texto dá o mecanismo fiscal só para o PL, e o recorte da tabela corta a mesma informação do trecho do PT.

**Correção.** "O do PT liga juros menores à inflação controlada e à manutenção do arcabouço. O do PL liga juros na média internacional e inflação no centro da meta à queda da dívida." Estender o trecho da tabela até "política fiscal responsável".

### V4. Seleção de trechos menos representativos do PT em três temas

**Onde.** Tabelas das páginas 42 a 44 e PR-propostas.csv.

**Evidência.** São 15 trechos do PT e 22 do PL. A diferença em parte reflete o PL ser mais específico em alguns temas, mas em três temas o trecho do PT escolhido é periférico e havia trecho mais representativo.
- Moradia. O escolhido é "Daremos sequência também à iniciativa, que se mostrou bem-sucedida, de utilizar áreas da União" (página 45). A frase central da mesma página é "O MCMV será mantido e ampliado no próximo mandato, para todas as faixas de renda e preservando seu foco nas famílias de mais baixa renda". Ao lado da meta de 2,5 milhões de residências do PL, a escolha faz o PT parecer sem programa habitacional.
- Aposentadoria. A célula do PT diz "Sem trecho sobre o reajuste dos benefícios", enquanto o PL ganha citação. O PT tem proposta previdenciária na página 77, "buscar reestruturar a base de financiamento da Previdência, buscando a diversidade das fontes de custeio", e "mecanismos contributivos mais flexíveis". A pergunta "Uma pessoa aposentada manteria o poder de compra?" cita só o pacote antifraude do PL.
- Trabalho. PT tem um trecho, PL tem três. Ficaram de fora do PT, na página 74 e 75, o combate à "pejotização espúria", a regulação do trabalho por plataformas e "aprimorar a legislação trabalhista, alterando regras que induzem a precarização", que são o par do "negociado sobre o legislado" do PL.

**Correção.** Trocar o trecho de moradia do PT pelo do MCMV, pôr o trecho da página 77 na linha de aposentadoria (mantendo a nota de que nenhum dos dois muda o reajuste), e acrescentar um trecho do PT sobre legislação trabalhista. Equilibrar o número de trechos por tema ou explicar por que um lado tem mais.

### V5. Ressalvas de tipo diferente para cada lado

**Onde.** Tabela "Efeitos possíveis por faixa de renda" e "Perguntas concretas", página 45, e parágrafo da jornada, página 44.

**Evidência.** A proposta do PT recebe ressalva de efeito real adverso ("Jornada de 40 horas para quem trabalha mais, com efeito sobre o emprego que estes dados não medem", e no texto "o efeito sobre o emprego e os preços não pode ser calculado"). As propostas do PL recebem só ressalva de repasse ("se chegar ao preço"). Os cortes de tributo do PL (IVA, energia, combustível, custo do trabalho) têm custo fiscal e precisam de compensação, que o próprio dossiê mede em R$ 65 bi por ponto de IVA, e isso não aparece nas linhas do PL da tabela por faixa nem na pergunta da pequena empresa. Na pergunta 5, a proposta do PT aparece como custo para a empresa e a do PL como economia para a empresa, sem o custo do PL para o Tesouro ou para a Previdência.

**Correção.** Dar a cada proposta as duas ressalvas que cabem. Para o PL, "custo fiscal não estimado no plano, cada ponto de IVA vale cerca de R$ 65 bi, e a redução de encargos reduz a receita da Previdência". Para o PT, manter a ressalva de emprego e acrescentar que a jornada não tem custo fiscal direto.

### V6. O PL aparece menos concreto do que é em programas sociais

**Onde.** Página 44, "Nenhum dos dois diz o que muda", e tabela por faixa, "Programas mantidos, com revisão de distorções não detalhada".

**Evidência.** O plano do PL, páginas 42 e 43, diz o que muda. Prioridade do beneficiário em primeiro emprego e qualificação, trilha de qualificação para quem recebe o benefício, "retorno imediato e sem fila ao benefício após o seguro-desemprego", e na página 33 "proibir o uso dos recursos dos programas sociais para apostas". Nada disso é valor de benefício, mas é mudança de regra.

**Correção.** "Nenhum dos dois traz valor de benefício ou número de famílias. O do PL propõe regras de saída e de retorno ao benefício e a proibição do uso em apostas. O do PT propõe ampliar, sem dizer como."

### V7. Itens do PT relevantes para mercado ficaram de fora da nota MK, e itens do PL também

**Onde.** Página 3, "Os planos em ordem de grandeza".

**Evidência.** A nota só dá ordem de grandeza ao IVA, que é proposta do PL. Ficaram de fora, do PT, "A Petrobras deverá retornar ao segmento de distribuição de combustíveis" (página 67), a política de preços da Petrobras "combinada com a ação de subvenções governamentais" para não repassar preços internacionais (página 66), conteúdo local e segunda edição do Novo PAC. Do PL ficaram de fora a meta de 4% de crescimento, os R$ 900 bi em transportes com "fundo lastreado na securitização de ativos e imóveis da União" e BNDES (páginas 50 e 51), e a retomada do Programa Nacional de Desestatização. A omissão é dos dois lados, mas dar número só à proposta tributária do PL faz da nota de mercado uma nota sobre o custo do PL.

**Correção.** Acrescentar uma linha por plano com os itens que mexem em preço de ativo (Petrobras e subsídio a combustível no PT, desestatização, securitização de ativos e meta de crescimento no PL), sem número quando o plano não traz.

## EXCESSO

### X1. A matriz "mostra de uma vez o que cada plano trata e o que não trata"

**Onde.** Página 42.

**Evidência.** A mesma frase diz que a matriz "conta palavra e não proposta". O V1 mostra que o PL trata programas sociais, moradia e jornada sem as palavras escolhidas, e o PT trata resultado primário sem a palavra superávit.

**Correção.** "Mostra quais palavras cada plano usa. Ausência de palavra não é ausência de tema."

### X2. "Um corte de imposto sobre o consumo reduz a carga proporcionalmente mais embaixo"

**Onde.** Página 44 e tabela por faixa (renda baixa e média).

**Evidência.** O argumento usa a parcela de alimentação e habitação na despesa da POF 2017-2018 (22,0% e 39,0% na renda baixa). No IVA da reforma, a cesta básica nacional tem alíquota zero, muitos alimentos têm redução de 60%, a locação residencial tem redutor de base, e as famílias do CadÚnico recebem cashback, como o próprio dossiê registra em V-reforma-consumo.csv e na seção 12. Um corte na alíquota de referência chega menos aos itens já desonerados, que pesam mais embaixo. O efeito distributivo de um ponto a menos de IVA não decorre da POF sozinha e pode ser menos progressivo do que o texto diz.

**Correção.** "O efeito por faixa depende de quanto do consumo de cada faixa paga a alíquota cheia. A cesta básica já tem alíquota zero e há cashback para a baixa renda, então a POF sozinha não mede quem ganha mais com um corte."

### X3. "O orçamento de 2027 é feito com a primeira macro e cobrado pela segunda"

**Onde.** Página 3, item "Governo contra mercado".

**Evidência.** A grade do PLDO é de março de 2026. O orçamento que o Congresso vota até dezembro é o PLOA 2027, enviado em agosto com grade própria, que o pacote não usa (não há PLOA 2027 em brutos). E o Focus não cobra o orçamento. Quem cobra é a macro realizada.

**Correção.** Usar a grade do PLOA 2027 ou dizer "o PLDO, de março de 2026, supõe PIB de 2,6% e IPCA de 3,0%, e o Focus de outubro espera 1,4% e 4,3%. Se a macro realizada ficar perto do Focus, a receita fica abaixo da projetada".

### X4. A leitura do diferencial da curva omite o componente que domina

**Onde.** Página 3, item "O que a curva já precifica".

**Evidência.** A própria tabela permite separar o diferencial. Com o IPCA do Focus interpolado na janela, o juro real a termo fica perto da Selic real do Focus no segundo ano (1 pb) e 49 a 61 pb acima do terceiro ao quinto ano, enquanto a inflação implícita a termo fica 101, 202, 252 e 264 pb acima do IPCA do Focus. Três quartos ou mais do diferencial nominal estão na compensação de inflação (inflação esperada acima do Focus mais prêmio de risco de inflação e de liquidez da NTN-B), e não no juro real. O texto fala em prêmio de prazo e trajetória da Selic, o que não está errado, mas não diz isso. Também, no primeiro ano, "coincide" depende da janela. A média usa outubro de 2026 a setembro de 2027, e a curva começa em 19/10. Com novembro a outubro, o diferencial do primeiro ano vai de menos 3 para mais 10 pb e o do segundo de 110 para 122 pb.

| Ano à frente | Diferença nominal, pb | Parte real, pb | Parte da inflação implícita, pb |
|---|---|---|---|
| 2 | 110 | 1 | 101 |
| 3 | 267 | 49 | 202 |
| 4 | 333 | 61 | 252 |
| 5 | 343 | 58 | 264 |

**Correção.** Acrescentar "a maior parte da distância está na inflação implícita, de 5,6% a 6,1% ao ano do terceiro ao quinto ano, contra 3,5% no Focus" e dizer que o primeiro ano coincide dentro de uns 10 pb conforme a janela.

### X5. "a alíquota de 27,91% do Comitê Gestor"

**Onde.** Página 3 e nota de MK-iva-ponto.csv.

**Evidência.** V-reforma-consumo.csv registra que 27,91% é "PARAMETRO METODOLOGICO, nao aliquota oficial", usado pelo CGIBS para estimar o IBS de 2027, obtido escalando a estimativa de 26,50% da SERT, e que o documento da SERT com cerca de 28% não foi achado. A alíquota de referência oficial ainda não foi fixada pelo Senado em 19/10/2026.

**Correção.** "o parâmetro de 27,91% que o Comitê Gestor usa para estimar o IBS de 2027, que não é alíquota oficial". A conta de 0,44% do PIB por ponto continua válida como ordem de grandeza.

### X6. "Nenhum dos planos traz meta de ... inflação"

**Onde.** Página 43.

**Evidência.** O PL compromete-se com "a inflação volte ao centro da meta" (página 33) e com juros "em linha com a média internacional". O centro da meta é um número (3%). O PT fala em "inflação controlada" e "sob controle de forma duradoura" (página 49). A afirmação vale para o PT e não exatamente para o PL.

**Correção.** "O do PL adota como alvo o centro da meta de inflação, sem prazo. O do PT fala em inflação controlada."

### X7. "Mudar a regra exige lei, e nenhum dos planos propõe mudá-la"

**Onde.** Página 44, sobre o salário mínimo.

**Evidência.** É verdade que nenhum plano propõe mudar a Lei 14.663. Mas o ganho real até 2030 está limitado pela Lei 15.077 ao crescimento da despesa do arcabouço, e o plano do PL propõe "uma reformulação nas atuais regras fiscais" (página 71). Uma regra fiscal nova muda o teto do ganho real sem tocar na lei do salário mínimo, se a Lei 15.077 não for ajustada junto.

**Correção.** Acrescentar "o teto do ganho real está ligado ao arcabouço, que o plano do PL propõe reformular, sem dizer como".

## NOTA

**N1. Datas do Focus e da curva.** A curva é de 19/10/2026 e o Focus é de 09/10/2026, o último no arquivo. O Focus de 16/10 já estava publicado em 19/10. Para uma comparação de mercado, usar o Focus mais próximo da data da curva, ou dizer a defasagem.

**N2. Risco de execução do PLDO.** O PLDO diz, na página 20 do anexo, "Foram trazidos para as projeções de arrecadação o efeito de medidas tributárias em estudo, no âmbito do Poder Executivo". Para quem aloca capital, isso é risco de execução mais direto que as exclusões. Vale dizer também que, mesmo com a banda de tolerância de menos 0,25 ponto (limite inferior de R$ 36,61 bi), o primário de 0,05% não cumpriria a meta sem as exclusões.

**N3. Calendário.** Faltam o início do Imposto Seletivo em 2027 (ADCT art. 126, I, b, já em V-reforma-consumo.csv) e a fixação da alíquota de referência da CBS de 2027 pelo Senado, com o cálculo do TCU previsto para 30/10/2026 segundo o CGIBS, data que cai junto do segundo turno e mexe no debate do IVA. "CBS cheia" em 2027 é a alíquota de referência menos 0,1 ponto (LC 214, art. 347). O título "Calendário de 2027" inclui um item de 2026 e um de 2029.

**N4. Emendas parlamentares.** Os dois planos tratam emendas (PT, páginas 15 e 16, "enfrentar uma grave distorção", PL, página 69, "mais transparência, controle e rastreabilidade"). A nota MK usa as discricionárias líquidas de emendas, e a seção 16 não tem linha de emendas. É tema fiscal com proposta nos dois lados.

**N5. Faixa do canal fiscal.** A nota MK escreve "numa faixa de 11 a 47 pb" como texto fixo no código, enquanto a conclusão 4 da seção 15 dá "intervalo aproximado de 11 a 40 pb". A seção 15 explica que 11 a 47 junta limites de duas amostras e não é intervalo de confiança. A nota MK deveria ler o valor de FAIXA e dizer que não é intervalo de confiança.

**N6. Horas acima de 40.** "A tabela pública do IBGE não traz quantos trabalham acima de 40 horas" vale para o SIDRA da PNAD Contínua, que só publica médias. Os microdados da PNAD Contínua (horas habituais no trabalho principal) e as tabelas do Censo por grupos de horas permitem a conta. A frase poderia dizer isso.

**N7. Normalização do script.** build_PR.py deveria juntar hifenização de fim de linha ("salário- mínimo" vira "salário-mínimo") e contar plurais antes de contar termos (E6). O assert do script confere presença literal, não representatividade, e o LEIAME poderia dizer isso.

**N8. Diagnóstico do IVA no plano do PL.** O PL fala em IVA "projetado em torno de 30%" (página 30). Pôr esse número ao lado do parâmetro de 27,91% ajuda o leitor a ver de que base o plano parte, sem atribuir meta.

**N9. Dividendos.** "O PLDO não prevê dividendo extraordinário" é leitura de "não há previsão de pagamento de destaque". A frase literal é mais segura.

**N10. Previdência e Imposto de Renda na renda alta.** O PL propõe "a revisão e o redimensionamento ... da majoração de impostos efetuada pelo atual governo" (página 71), com o objetivo declarado de reduzir a carga "sobre a produção e o consumo". Não diz se isso alcança a tributação mínima de altas rendas. A célula de renda alta do PL poderia registrar que a revisão das majorações não é especificada.

## Anexo 1. Recontagem da matriz

Mesma normalização do script (espaços colapsados, sem distinguir maiúsculas), PDFs do TSE no pacote.

| Termo | Expressão | PT, dossiê | PT, recontagem | PL, dossiê | PL, recontagem |
|---|---|---|---|---|---|
| superávit | superávit | 0 | 0 | 1 | 1 |
| dívida pública | dívida pública | 0 | 0 | 5 | 5 |
| meta fiscal | meta fiscal ou meta de resultado primário | 0 | 0 | 0 | 0 |
| arcabouço ou regra fiscal | arcabouço, regra fiscal, regras fiscais | 3 | 3 | 2 | 2 |
| reforma tributária | reforma tributária | 6 | 6 | 8 | 8 |
| juros | juros | 8 | 8 | 19 | 19 |
| inflação | inflação | 8 | 8 | 7 | 7 |
| privatização ou desestatização | privatiza, desestatiza | 0 | 0 | 2 | 2 |
| investimento | investimento e plural | 82 | 82 | 28 | 28 |
| salário mínimo | salário mínimo, salário-mínimo | 6 | 6 (7 com hifenização) | 0 | 0 (1 com plural) |
| Imposto de Renda | Imposto de Renda | 3 | 3 | 0 | 0 |
| Bolsa Família | Bolsa Família | 5 | 5 | 0 | 0 |
| BPC | BPC | 2 | 2 | 0 | 0 |
| aposentado ou aposentadoria | aposentad | 3 | 3 | 12 | 12 |
| SUS | SUS | 14 | 14 | 6 | 6 |
| jornada de 40 horas ou 6x1 | 40 horas, 6x1 | 2 | 2 | 0 | 0 |
| moradia ou habitação | moradia, habitaç | 10 | 10 | 5 | 5 |

Termos alternativos para o teste de construção (V1).

| Termo | PT | PL | Observação |
|---|---|---|---|
| primári (raiz) | 4 | 1 | PT fala em déficit e gasto primário |
| responsabilidade fiscal | 3 | 1 | |
| equilíbrio fiscal | 1 | 4 | |
| dívida, qualquer uso | 4 | 19 | as 4 do PT são dívida de famílias, FIES e hospitais |
| programas sociais | 0 | 12 | |
| Auxílio Brasil | 0 | 1 | |
| casa própria | 0 | 12 | |
| jornada, qualquer uso | 3 | 17 | no PL, a maioria é "jornada do cidadão", mas páginas 44 e 45 tratam a jornada de trabalho |
| previdên | 5 | 2 | |
| INSS | 1 | 12 | |
| IVA | 0 | 3 | |
| voucher | 0 | 8 | |
| concessões (concess) | 10 | 2 | |
| estatais | 3 | 15 | |
| PAC | 30 | 0 | |
| Pé-de-Meia | 5 | 0 | |
| tamanho do texto, palavras | 24.727 | 23.296 | os dois planos têm tamanho parecido |

## Anexo 2. As 37 citações

Todas estão literais na página citada. A coluna "Leitura" diz se o trecho, lido na página inteira, diz o que a tabela sugere.

| Tema | Lado | Página | Leitura |
|---|---|---|---|
| Regra fiscal | PT | 49 | Fiel. A frase continua "e permitiu uma redução significativa do déficit primário" |
| Regra fiscal | PL | 71 | Fiel. Omite "conforme determina a Constituição" |
| Resultado primário | PT | 49 | Fiel |
| Resultado primário | PL | 71 | Fiel. A página traz também "estabilidade e depois a queda da relação Dívida/PIB" no menor prazo possível |
| Despesa | PT | 49 | Fiel, é fragmento da mesma frase do resultado |
| Despesa | PL | 71 | Fiel |
| Despesa | PL | 69 | Fiel. A frase continua com "penduricalhos e supersalários" |
| Impostos | PT | 49 | Fiel, mas o sentido na página é fonte de resultado fiscal pela receita (V2, E3) |
| Impostos | PL | 71 | Fiel. A frase continua "com o objetivo de reduzir efetivamente a carga sobre a produção e o consumo" |
| Impostos | PL | 72 | Fiel. O mesmo texto está na página 30, com o diagnóstico de IVA de 30% |
| Juros e inflação | PT | 49 | Recorte omite "e assegurando uma política fiscal responsável" (V3) |
| Juros e inflação | PL | 33 | Fiel. A frase começa "Ao estabilizar e reduzir a dívida pública" |
| Investimento | PT | 48 | Fiel |
| Investimento | PT | 53 | Fiel |
| Investimento | PL | 70 | Fiel, mas a página 51 tem o trecho mais representativo, R$ 900 bi (E1) |
| Investimento | PL | 31 | Fiel. A página 51 repete os corredores ao lado dos R$ 900 bi |
| Salário mínimo | PT | 74 | Fiel |
| Trabalho | PT | 75 | Fiel. Continua "nos termos aprovados na Câmara dos Deputados" |
| Trabalho | PL | 43 | Fiel |
| Trabalho | PL | 44 | Fiel |
| Trabalho | PL | 44 | Fiel. A página 45 liga o negociado sobre o legislado ao debate da jornada |
| Aposentadoria | PL | 72 | Fiel. O PT tem trecho sobre Previdência na página 77 que ficou de fora (V4) |
| Programas sociais | PT | 18 | Fiel |
| Programas sociais | PL | 42 | Fiel. A página 43 traz as regras novas (V6) |
| Energia e combustível | PT | 66 | Fiel. O contexto é a política de preços da Petrobras com subvenções |
| Energia e combustível | PL | 31 | Fiel |
| Energia e combustível | PL | 31 | Fiel |
| Saúde | PT | 37 | Fiel. A página 36 tem o Farmácia Popular "100% gratuito", com exames, que pesa mais no orçamento familiar |
| Saúde | PL | 37 | Fiel |
| Saúde | PL | 37 | Fiel |
| Educação | PT | 32 | Fiel. A página 31 tem a meta de 80% de crianças alfabetizadas |
| Educação | PL | 35 | Fiel |
| Educação | PL | 36 | Fiel |
| Moradia | PT | 45 | Literal, mas pouco representativo. A frase central é a do MCMV mantido e ampliado (V4) |
| Moradia | PL | 47 | Fiel |
| Pequena empresa | PT | 57 | Fiel |
| Pequena empresa | PL | 45 | Fiel |

## Anexo 3. Números do PDF que desmentem a leitura literal de "nenhum número"

| Plano | Página | Número | Tipo |
|---|---|---|---|
| PT | 11 | déficit primário de 2026 perto de 0,4% do PIB, esforço fiscal de 2% do PIB (R$ 240 bi) | passado e 2026 |
| PT | 15 | emendas de R$ 50 bi no orçamento de 2026 | presente |
| PT | 31 | meta de 80% das crianças alfabetizadas na idade certa | meta futura, não fiscal |
| PT | 36 | Farmácia Popular mantido 100% gratuito | compromisso futuro sem valor em reais |
| PL | 29 e 68 | dívida bruta 13 pontos do PIB maior em quatro anos, 4 pontos menor no governo anterior | passado |
| PL | 30 | IVA projetado em torno de 30%, contra 19% na OCDE | diagnóstico de carga |
| PL | 47 | Casa Verde e Amarela com meta de 2,5 milhões de residências | meta futura, com custo fiscal não dito |
| PL | 49 | crescimento de 4% ao ano na próxima década | meta futura (E1) |
| PL | 51 | R$ 900 bi em quatro anos em transportes | meta futura (E1) |
| PL | 69 | corte de no mínimo 10 ministérios | meta futura de despesa, sem valor |

Nenhum dos números acima é meta de primário, dívida, carga ou valor de benefício para 2027 a 2030. A afirmação do dossiê se sustenta nessa forma restrita e precisa ser escrita assim (E7).

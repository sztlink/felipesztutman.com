# Auditoria independente da v10: seção 15, Anexo C, item do Essencial e rolagem da seção 14

Auditor externo à construção dos modelos. Data: 19/10/2026. Base auditada: commit 1639c91e (HTML de 19/10 13:46).
Nenhum arquivo do dossiê foi alterado; tudo o que foi rodado está em cópias no scratchpad
(pasta de trabalho do auditor, fora do pacote).

Classes: **ERRO** (número, fonte ou classe errados), **FRÁGIL** (premissa ou leitura discutível, com a alternativa testada e o
resultado), **NOTA** (ajuste de redação ou de documentação). Cada achado traz a correção sugerida.

## Resumo

| id | classe | onde | achado | correção |
|---|---|---|---|---|
| E1 | ERRO | seção 15, fecho | "dezenas de pontos-base, não pontos percentuais" não se sustenta com os números do próprio dossiê | dar a faixa: 20 a 220 pb para o primário que estabiliza, cerca de 110 pb no centro |
| E2 | ERRO | Anexo C, Essencial, LEIAME Y | a faixa de 5 a 50 pb não usa "só primário esperado sobre juro longo nominal": o piso vem de saldo global previsto a 12 meses e de juro de 5 anos | redescrever a variável ou refazer o piso só com Y05 |
| E3 | ERRO | notas [29], [27], [3][4] | séries usadas na seção 15 sem entrada na lista de fontes ou com a nota errada | criar as entradas e trocar as chamadas |
| E4 | ERRO | seção 15, 1º parágrafo | "nenhum dos programas registrados no TSE traz meta numérica de primário" não tem fonte, bruto nem URL | documentar a busca em brutos/ ou retirar a frase |
| F1 | FRÁGIL | conclusão B, Essencial | "a maior parte da alta" acompanha os externos: o piso declarado é 25% e, na própria janela comparada, cai a 4% a 27% | "entre um quarto e quase toda, conforme a especificação" |
| F2 | FRÁGIL | seção 15, "O que vem de fora" | a distância para os emergentes (2,9 para 5,8 pontos) depende da composição variável da mediana; com os 5 fixos, 4,6 para 6,0 | usar a mediana fixa de 5 ou dar as duas |
| F3 | FRÁGIL | seção 15, "A política monetária..." | 6,3 pontos é a maior das medidas ex-ante; a conclusão resiste a três decomposições, mas o "53%" mistura perímetros | dar a faixa de 5,2 a 6,3 e o número em pontos de custo |
| F4 | FRÁGIL | seção 15, "O que a literatura estabelece" | "9 têm identificação causal" vem colado à faixa; nenhum dos 9 entra na faixa, e só 3 tratam de fiscal e juros | dizer isso na mesma frase |
| F5 | FRÁGIL | seções 14 e 15 (simulador) | a rolagem reprecifica só o estoque de dez/2025; a emissão líquida, que faz o estoque nominal crescer cerca de dois terços até 2030, fica no custo antigo | levar ao S a variante de estoque crescendo de W |
| F6 | FRÁGIL | seções 14 e 15 | a âncora de mercado é out/2026 parcial (10 pregões), depois de uma queda de 117 pb num dia (05/10/2026); com set/2026, todas as dívidas de 2030 sobem 0,75 a 0,8 ponto | declarar a data e mostrar a sensibilidade |
| N1 a N15 | NOTA | vários | ver seção 5 | |

O que resistiu: a conta de transmissão (W e S reproduzem byte a byte), a separação Selic contra rolagem, a ausência de dupla
contagem entre o canal fiscal e o choque de prêmio, o perímetro do primário do Focus (efeito de 2 a 8 pb) e a conclusão de que a
Selic domina a diferença de custo entre os dois períodos.

## 1. Conferência

### 1.1 Reprodução
- `build_W.py`, `build_X.py` e `build_S.py` rodados em cópias que gravam no scratchpad. Os 5 CSV de W, o perfil de vencimentos, os
  4 CSV de X e os 3 CSV de S saem **idênticos** aos do dossiê (cmp byte a byte).
- `python3 -P relatorio/testes.py`: 13 de 13 ok (ver seção 4).

### 1.2 Números da seção 15 refeitos a partir dos CSV
| número no texto | CSV | refeito |
|---|---|---|
| 7,91 / 6,91 / 8,86% do PIB; compromissadas 1,34 | W-juros-perimetros 2025 | 7,913 / 6,911 / 8,857; 1,338 |
| 48% Selic, 26% inflação, 22% prefixada; prazo 4,0; 17,5% em 12 meses | W-dpf-estrutura dez/2025 | 48,25 / 25,93 / 22,05; 4,00; 17,46 |
| estoque 11,85%, emissões 13,81%, prefixado 10a 14,14% | W-dpf-estrutura | 11,85 / 13,81 / 14,14 |
| Selic real ex-ante 2,2% e 8,5%; diferença 6,3 | W-selic-real, média dos meses | 2,1882 (48 meses) e 8,5115 (45); 6,32 |
| 84% em níveis, 25% em diferenças; DFII10 1,09 e 0,39 | X-regressoes | 0,8397 e 0,2541; 1,0918 e 0,3938 (replicado em numpy) |
| 2,9 e 5,8 pontos contra emergentes | X-fatores-mensal, mediana disponível | 2,89 e 5,80 |
| tabela de sensibilidade (30 a 1.340 R$ bi) | S-sensibilidade-juros | todas as 27 células batem |
| tabela do canal (98,0 a 93,8) e 55 pb | S-canal-fiscal 2030 | todas batem; choque central receita 2030 = -0,551 |
| crescimento real ±1: 3,9 e -4,1 | S-sensibilidade-juros | 3,92 e -4,12 |
| Anexo C, Selic real por mandato | W-selic-real `media_mandato` | todas batem |

Curiosidade conferida: no Lula 3, a média do ex-ante com Selic esperada (7,9594) é igual, até a 4ª casa, à do juro realizado
nos 12 meses passados. As séries mensais são diferentes; é coincidência, não erro de coluna.

### 1.3 Fontes originais abertas (19/10/2026)
**W**
- RMD de ago/2026 baixado de `thot-arquivos.tesouro.gov.br/publicacao-anexo/29322`: o xlsx de dentro tem o mesmo md5 do bruto
  (01c26550...). Anexo 4.2 dez/25: DPF 11,85, DPMFi 12,65, LFT 14,51. Anexo 3.2 dez/25: prefixado 613,7 / 424,4 / 116,3 / 384,0 /
  88,2 / 272,3 de 1.898,95 bi (32,3% / 22,4% / 6,1% / 20,2% / 4,6% / 14,3%), igual ao `perfil_vencimentos_dez2025.csv`; NTN-B idem.
- Olinda, `ExpectativasMercadoInflacao12Meses`, IPCA suavizada, base 0: média das medianas de dez/2025 = 4,0392 (22 pesquisas) e
  de jun/2020 = 3,2038 (21), iguais a W.
- Ipeadata `BM12_TJOVER12`: Selic over acumulada de out/2025 a set/2026 = 14,4688%, igual a W.

**X**
- FRED DFII10 e VIXCLS (fredgraph.csv): médias de jan/2019, dez/2022, jun/2024, set/2026 e out/2026 iguais a X-fatores-mensal;
  médias dos períodos -0,17 e 1,93 (DFII10) e 22,45 e 17,30 (VIX) reproduzidas.
- Olinda `ExpectativasMercadoAnuais`, resultado primário para 2025, base 0, jun/2024: -0,6338, igual a X.
- Ipeadata `JPM366_EMBI366`: último dado em 30/07/2024 (228 pb), confirmando a descontinuidade.

**Y** (sorteio com semente 20261019: Y04, Y07, Y11, Y19, Y24; mais Y05 e Y06, que ancoram centro e piso)
| estudo | página citada | conferido no PDF |
|---|---|---|
| Y04 Jaramillo e Weber | Tab. 2 p. 15, Tab. 3 p. 16 | saldo esperado -0,13 e -0,15 (ep 0,09, \*p<0,15); VIX alto -0,31 (0,09), baixo -0,04 (0,11); dívida 0,04 e 0,06. Ok. A variável é o **saldo global** esperado, não o primário |
| Y07 BCB WP 629 | Tab. 1 p. 13, Tab. 3 p. 15 | inclinação -0,245 (primário) e -0,279 (Focus), \*\*\*; Δ5 anos -0,018\* e -0,015. Ok |
| Y11 Banco Mundial | p. 14 | -0,775 a -1,029; 54% a 64%; 319 a 378 pb; 36 a 67 pb em 2008. Ok |
| Y19 BCB TD 238 | Tab. 5 p. 23 | S1 0,80 (2m), 0,47 (9 e 12m), 0,69 (18m), 0,93 (24m). Ok |
| Y24 Ferreira e Bertussi | p. 24 a 25 | -5,2 p.p., p-valor 4/12 = 0,33; pesos Rússia 81%, México 13%. Ok |
| Y05 Nose e Menkulasi | p. 15, p. 32 | 6 a 10 pb no impacto, 26 pb em 2 anos (10 anos), pico 36. Ok. O "cerca de 50 pb" do teto está nas p. 24 e 28, não nas citadas (N13) |
| Y06 BIS WP 474 | p. 14 a 16 | -0,060 a -0,065 em variação mensal do juro de **5 anos**, "fiscal balance forecast" 12 meses à frente. Ok |

**S**: Olinda Focus de 09/10/2026, base 0: Selic, IPCA e PIB de 2026 a 2030 iguais ao json local; primário 2026 a 2029
(-0,41 / -0,40 / -0,27 / -0,15) igual ao lido do PDF. O Olinda tem também 2030 (0,00, 49 respondentes), que o S não usa (N3).

## 2. Refutação, conclusão por conclusão

### 2.1 A. "O custo dos juros é sobretudo Selic vezes o tamanho da parte pós-fixada"
Resiste. O argumento mais forte nem está no texto: na NFSP de 2025, os juros indexados à Selic somam 6,14% do PIB de 7,91%
(78%, W-juros-perimetros). Sugestão: citar esse número. Ver N4 sobre "ao longo de 4 anos em média".

### 2.2 A. "A diferença de custo entre 2019-2022 e 2023-2026 vem sobretudo da Selic" (e o parágrafo "A política monetária pesou mais...")
Três decomposições alternativas, todas a favor do texto:
| decomposição | variação total | parte da Selic |
|---|---|---|
| custo nominal da DPF por indexador (O-custo-divida-indexador, médias 2019-22 contra 2023-25) | +2,33 p.p. | LFT +3,19 (taxa +2,59; peso +0,60); prefixado -0,06; preços -0,58; câmbio -0,22 |
| juros da NFSP, % do PIB (W-juros-perimetros) | +2,55 | indexados à Selic +2,98 |
| custo real da DPF (Fisher) | 2,76% para 6,52%, +3,76 | peso médio da LFT (0,40) × Selic real realizada da LFT (0,3% para 8,0%) = 3,07; com o ex-ante de W, 2,53 |

**F3 (FRÁGIL), medida e perímetro.** O texto usa "53% da dívida bruta" (DBGG, dez/2025, com compromissadas) contra a diferença de
custo da dívida federal, e o produto implícito 0,53 × 6,3 = 3,35 pontos usa o peso do fim do período (a LFT era 37% da DPF em média
no governo Bolsonaro). Além disso, 6,3 pontos é a maior das medidas ex-ante: com a Selic esperada do Focus, 2,64% contra 7,96%
(5,3 pontos); com o prefixado de 1 ano deflacionado pelo Focus, a medida que o mercado usa, 2,79% contra 8,00% (5,2 pontos).
A meta corrente pesa 2020 e 2021, quando a meta de 2% convivia com altas já esperadas. Resultado: a conclusão não muda; a
magnitude cai cerca de 1 ponto. Correção: "Selic real ex-ante de 2,2% a 2,8% no governo Bolsonaro e de 8,0% a 8,5% no Lula 3,
conforme a medida; com o peso médio da LFT, isso responde por cerca de 2,5 dos 3,8 pontos de alta do custo real da dívida
federal". E trocar o título "A política monetária pesou mais que qualquer outra variável" por "A Selic responde pela maior parte
da diferença contábil", porque a classe A só cobre a conta, não a atribuição a "política monetária".

### 2.3 B. "A maior parte da alta do juro real longo entre os dois períodos acompanha fatores externos (25% a 90%)"
**F1 (FRÁGIL).** A frase se contradiz: com piso de 25%, "a maior parte" não está demonstrada. No próprio X, 4 das 18 especificações
do juro real ficam abaixo de 50% (diferenças a e b: 25% e 26%; mediana de emergentes a e b: 43% e 45%). Testes adicionais
(`aud/x_alt.py`, `aud/x_hac.py`), todos com a mesma decomposição de X:

| especificação | fração externa | observação |
|---|---|---|
| amostra inteira, níveis (réplica) | 84% | |
| amostra inteira, diferenças (réplica) | 25% | |
| só a janela comparada, 2019-2026, níveis | 94% | DFII10 0,45 com t 1,9; quase tudo vem de VIX, dólar e OAS com sinais instáveis (OAS -1,16) |
| 2019-2026, primeiras diferenças | **4%** | DFII10 0,10, t 0,6 |
| 2019-2026, níveis, com Focus | **21%** | DFII10 0,03 (t 0,1); DLSP esperada +0,20 (t 5,8) |
| regime 2021-2026, níveis, sem e com Focus | 71% e **27%** | |
| diferenças de 12 meses, amostra inteira | 61% | |
| só DFII10, desde 2008 ou desde 2019 | 90% e 88% | |

Na janela de interesse, o juro americano deixa de ser significante, e a DLSP esperada do Focus entra com o sinal esperado e
significante também em diferenças (+0,046 por ponto, t 2,5). Isso não prova prêmio fiscal (a DLSP esperada sobe mecanicamente com
o juro, como o LEIAME de X reconhece), mas tira a base de "a maior parte". Outro ângulo: ponto a ponto, de dez/2022 a out/2026, o
juro real brasileiro de 10 anos subiu 0,77 ponto e o DFII10, 1,53. A maior parte da alta das médias aconteceu dentro do período
Bolsonaro (2021-2022), e a comparação de médias mistura as duas coisas.

A faixa "25% a 90%" também não é a faixa inteira: X tem 100% (DGS10 com Focus) e 117% (coeficientes de 2008-2015 fora da
amostra). O texto não escolheu o lado alto do intervalo; escolheu o lado alto na conclusão e no Essencial ("em boa parte").
Correção: "Entre os dois períodos, os fatores externos acompanham de um quarto a quase toda a alta do juro real longo, conforme a
especificação; na janela 2019-2026 e com a expectativa fiscal no modelo, a fração cai abaixo de 30%." Classe B mantida.

**F2 (FRÁGIL), comparação com emergentes.** "Contra a mediana de cinco a sete emergentes, 2,9 pontos no governo Bolsonaro e 5,8 no
Lula 3." A mediana muda de composição: o México falta em 11 meses do governo Bolsonaro, e Índia e México puxam a mediana para
cima. Com a mediana fixa de 5 países (a mesma da regressão), a distância é 4,65 e 6,04: o aumento entre governos cai de 2,9 para
1,4 ponto. Correção: usar `em10_mediana_5` ou dar as duas.

### 2.4 B. "1 ponto do PIB de primário esperado associado a juros longos 5 a 50 pb menores" e C. "coeficiente causal do Brasil de hoje"
Classes corretas. Mas:

**E2 (ERRO), variável fiscal da faixa.** O Anexo C diz que "a faixa do simulador usa só primário esperado sobre juro longo
nominal". A tabela da faixa no LEIAME de Y mostra outra coisa:
- **Baixo (5):** Y06 é previsão de **saldo fiscal** (global) a 12 meses e juro de **5 anos** em variação mensal; Y04 com VIX baixo é
  **saldo global** esperado em t+1.
- **Central (25):** além de Y05, cita Y01 (déficit total projetado nos EUA, juro **real forward**) e Y02 (saldo esperado, com o
  juro curto como regressor).
- **Alto (50):** Y04 com VIX alto (saldo global) e Y02 (déficit e dívida **iniciais** como limiares).

Só Y05 (déficit primário esperado 4 anos à frente, juro nominal de 10 anos, emergentes com o Brasil) casa com a definição do
parâmetro. Num país com juros de 7% a 9% do PIB, o saldo global esperado melhora quando se espera juro menor, o que é exatamente a
causalidade reversa que a faixa quer evitar. Isso fere o critério Y do brief ("não combinar estimativas com variáveis fiscais
diferentes"). Teste: só com Y05, a faixa fica em 6 a 10 pb no impacto, 11 a 40 pb (IC95%, todos) ou 12 a 47 pb (grandes
emissores) em 2 anos, centro 26 a 30 e cerca de 50 pb com nexo bancário alto. Muda o piso (de 5 para cerca de 11 em 2 anos), não
o centro nem o teto. Correção: ou reescrever o parâmetro como "saldo esperado, primário ou global, 1 a 4 anos à frente, juro
nominal de 5 ou 10 anos" e trocar o "só primário esperado" do Anexo C, ou refazer a faixa só com Y05 e deixar Y04 e Y06 como
corroboração. O Essencial herda o problema.

**F4 (FRÁGIL), "Dos 25 estudos revisados, 9 têm identificação causal".** A frase vem logo antes da faixa e sugere que a faixa tem
base causal. Dos 9: Y19, Y20 e Y21 não são fiscais; Y13, Y14 e Y15 medem produto, não juros; restam Y09 (VAR recursivo, 5 anos,
transitório), Y12 (EMBI) e Y16 (probabilidade de default em 2002 e 2003). Nenhum entra na faixa, que é inteira de "associação
robusta". Três dos 9 são VAR com ordenamento de Cholesky, que só a planilha qualifica. Correção: "9 têm identificação causal, mas
só 3 tratam de fiscal e juros, e nenhum entra na faixa".

**N11 (NOTA), Brasil.** "As regressões do Banco Central não encontram efeito estável do nível fiscal no nível do juro longo" está
certo, mas omite que Y07 acha -27,9 pb na inclinação de 5 anos menos 1 ano por ponto de primário esperado no Focus, significante a
1%, com o juro de 1 ano pouco sensível ao fiscal (Tab. 2). É a mesma ordem do centro da faixa e favorece o texto. Vale uma frase.

### 2.5 Canal fiscal no simulador: dupla contagem e perímetro
- **Choque de prêmio mais canal:** não há soma. Nos cenários com canal, `roda(..., ds=0.0, ds_m=0.0, dm_fun=canal)`: a Selic e as
  taxas de mercado ficam no Focus e só o canal move as taxas de mercado. O teste "canal fiscal não mexe na Selic" confirma a
  Selic. Ok.
- **Selic mais curva:** no choque "Selic e taxas de mercado" as duas se movem por hipótese, cada uma no seu instrumento (LFT e
  compromissadas contra rolagem de prefixados e NTN-B). A soma "só Selic" (326) mais "só mercado" (133) dá 459, contra 456 da
  curva: é aditivo, não há sobreposição. Ok.
- **N1 (NOTA), duas taxas.** O canal entra no prefixado **e** no juro real das NTN-B novas, com a inflação implícita parada. O brief
  pede "uma única taxa". Teste com o canal só no prefixado: dívida de 2030 no ajuste pela receita, centro, 94,32% em vez de 94,19%.
  Irrelevante para as conclusões, mas a frase "o canal entra uma vez, numa taxa" deveria dizer "nas taxas de mercado (prefixado e,
  por premissa, juro real das NTN-B)".
- **N2 (NOTA), perímetro do primário esperado.** O canal mede a diferença entre o primário do Governo Central (PLDO) e o primário
  esperado do Focus, que é do setor público consolidado. O próprio PLDO (Anexo IV.2, p. 16) projeta estatais em -0,03 a -0,05 e
  regionais em +0,01 a +0,02 do PIB: o consolidado fica cerca de 0,03 abaixo do central. O consolidado menos o central observado foi
  +0,05 em média de 2023 a 2025 e cerca de +0,3 de 2015 a 2025, com +1,1 em 2021 e +0,7 em 2022 (J-dlsp-fatores-ajustes contra
  K-primario-recorrente). Teste: supondo que o mercado espere o central 0,1 abaixo do consolidado, o choque central de 2030 passa
  de 55 para 58 pb; com 0,3, para 63 pb; a dívida de 2030 muda no máximo 0,05 ponto. Não muda nada; vale uma linha na nota.
- **N3 (NOTA), Focus de 2030.** O S repete 2029 (-0,15) em 2030; o Olinda de 09/10 tem 0,00 para 2030. Com o dado real, o canal
  central de 2030 cai de 55,1 para 53,2 pb e o cenário 1b sobe cerca de 0,15 ponto de primário em 2030.
- **N14 (NOTA), defasagem.** "Metade no ano e pleno no seguinte" está implementado como média da diferença do ano e do ano
  anterior. Sem defasagem, 59 pb. Ok como aproximação.

### 2.6 F5 e F6: a rolagem da seção 14 (o que mudou)
A troca de "1/3 ao ano" pelo perfil do RMD 3.2 está bem feita e confere com o anexo. Dois pontos:

**F5 (FRÁGIL), estoque crescendo.** `frac()` reprecifica só a parte do estoque de dez/2025 que venceu. A dívida bruta nominal
cresce cerca de dois terços até 2030 no cenário 2 (de 78,6% para 98,1% do PIB, com PIB nominal 33% maior), e a emissão líquida também sai a taxa de mercado. W tem essa variante
(`estoque_crescendo_2023_2025`); S não tem. Teste (`aud/variantes.py`, parcela nova do estoque a taxa de mercado):
| | dossiê | com emissão líquida a mercado |
|---|---|---|
| cenário 2, dívida de 2030 | 98,07 | 98,31 |
| só taxas de mercado, 1 ponto, economia 2027-30 | 133 | 163 (+23%) |
| Selic e taxas, 1 ponto | 456 | 488 |
| canal central, ajuste pela receita | 94,19 | 94,35 |
Correção: aplicar a fração ao estoque corrente (1 - (1 - frac) × estoque inicial / estoque do ano) ou declarar que a
sensibilidade "só taxas de mercado" é piso.

**F6 (FRÁGIL), âncora de mercado.** As taxas de destino são as de out/2026 até 15/10 (13,05% prefixado e 6,95% real, 10 pregões).
No TD, a NTN-F 2037 caiu de 14,17% em 02/10 para 13,00% em 05/10/2026, 117 pb num dia. Com set/2026 (14,24% e 7,55%), todas as
dívidas de 2030 sobem 0,75 a 0,8 ponto (cenário 2: 98,9; ajuste pela receita: 91,3; canal central: 94,96). O brief manda usar o
último dado, e o dossiê usa; o que falta é dizer a data e a sensibilidade. O mesmo episódio é relevante para E1: no próprio bruto,
a parte longa da curva se moveu mais de 1 ponto num dia por mudança de expectativa, sem que seja preciso atribuir a causa.
A frase da seção 14 "pelo perfil de vencimentos de dez/2025, de 10/2026 (13,1% no prefixado e 7,0% de juro real)" ficou truncada
(N9): "às taxas de mercado da primeira quinzena de out/2026 (13,1% e 7,0%)".

### 2.7 E1. "Da ordem de dezenas de pontos-base, não de pontos percentuais"
**ERRO.** A frase fala do "primário crível que estabilize a dívida (seção 14)". Com a macro do Focus, esse primário é de 4,3% do
PIB no cenário 2 (3,0% se as taxas caírem 1,5 ponto), contra -0,15% esperado pelo Focus. Pela faixa do próprio dossiê, aplicada
linearmente:
| caso | diferença de primário | baixo (5) | central (25) | alto (50) |
|---|---|---|---|---|
| ajuste pela receita (S-canal-fiscal, 2030) | 2,4 | 11 pb | 55 pb | **110 pb** |
| ajuste pela despesa (S-canal-fiscal, 2030) | 2,8 | 12 pb | 62 pb | **123 pb** |
| primário de 4,3% desde 2028 (simulador rodado) | 4,45 | 22 pb | **111 pb** | **222 pb** |
No centro, o primário que estabiliza dá cerca de 1 ponto percentual; no teto, mais de 2. Só o piso fica em "dezenas de pb".
Além disso, a linearidade a 4 pontos do PIB está fora da amostra dos estudos, e Y05 mostra decaimento depois de 3 anos se a
projeção não se confirma: a ressalva certa é de incerteza, não de ordem de grandeza. Correção sugerida: "...cujo efeito direto nas
taxas longas, pela evidência disponível, vai de cerca de 20 pb a 2 pontos para um ajuste do tamanho que estabiliza a dívida, com
centro perto de 1 ponto; no custo médio da dívida, chega devagar, porque só a rolagem o transmite." Se a intenção era falar do
**custo** (e não das taxas), a frase precisa dizer isso, e então vale: no ajuste pela receita, o canal reduz o juro implícito
de 2030 de 10,38% para 10,22% no centro e 10,06% no teto (0,16 e 0,32 ponto), porque só a parte que rolou é reprecificada.

### 2.8 C. "Que o ajuste fiscal, por si, derrube a Selic numa magnitude dada"
Classe C correta. **N6:** a justificativa ("a única estimativa causal brasileira é transitória") cita Y09, que mede o vértice de 5
anos, não a Selic. A evidência sobre a Selic é Y24 (controle sintético, p = 0,33) e a queda transitória de inflação em Y09.

### 2.9 C. "Que um governo de orientação específica reduza o prêmio de risco numa magnitude dada"
Classe C correta, mas apoiada em E4 (TSE sem fonte).

## 3. Critérios do brief

| critério | situação |
|---|---|
| W: Selic mecânica separada das novas emissões; acumulado pela trajetória | **Cumprido.** Linhas separadas; acumulado de 326 contra 4 × 61 = 242. N5: a explicação do texto ("o estoque menor também paga menos juros") cobre metade do excesso; a outra metade (+42 de +84 R$ bi) é o crescimento nominal do estoque base |
| X: EMBI como spread em dólar; estabilidade por regime | **Cumprido** no Anexo C e em X; a seção 15 não traz o resultado do regime 2021-2026 para a fração externa, que é o que enfraquece F1 |
| Y: não combinar variáveis fiscais; faixa por tipo; taxa de cada faixa | **Parcial.** Blocos por tipo e taxa estão no LEIAME, mas o bloco A e a faixa do simulador misturam saldo primário e global, horizontes de 1 e 4 anos e juros de 5 e 10 anos (E2) |
| Integração Y e S: canal uma vez, numa taxa | **Cumprido no essencial**: sem soma com o choque de prêmio, Selic fixa. Entra em duas taxas de mercado por premissa declarada (N1) |
| Auditoria: refutar com especificações alternativas | este parecer |
| Presidente nos gráficos temporais | **Cumprido** no gráfico da seção 15 (Lula 2 a Lula 3) e no da seção 14 ("Lula 3", "próximo mandato") |
| Todo número rastreável | **Não cumprido** em E3 e E4 |
| Sem travessão | **Cumprido** (0 travessão e 0 meia-risca no HTML; os hífens com espaço que aparecem são de seções antigas, em nomes de fundos) |
| Essencial não cresce | **Cumprido** (858 para 854 palavras) |
| Sem ampliar escopo, sem atribuir a candidatos | **Cumprido** |
| Pacote reproduzível | **Pendente** (N8) |

**E3 (ERRO), fontes da seção 15 e do Essencial.**
1. A Selic real ex-ante (seção 15 e Essencial) cita [29], que descreve o "Relatório de Mercado de 09/10/2026 (medianas anuais...
   ExpectativasMercadoAnuais)". A série usada é outra: Olinda `ExpectativasMercadoInflacao12Meses` e `ExpectativasMercadoSelic`,
   diária desde 2008, sem entrada na lista. Criar a entrada e trocar a chamada.
2. A Selic over do Ipeadata (`BM12_TJOVER12`, ex-post do Anexo C) não tem entrada; a nota 43 é só do EMBI.
3. [27] lista só DFII10 e FEDFUNDS; a seção 15 usa também VIXCLS, DTWEXBGS, BAMLEMCBPIOAS e DGS10 (as séries da OCDE estão em [7]).
4. "7,91% do PIB no setor público consolidado ... [3][4]": a NFSP é a nota [2]; os juros da DBGG vêm das tabelas de estatísticas
   fiscais da nota [47].

**E4 (ERRO).** "Sobre (2), nenhum dos programas registrados no TSE traz meta numérica de primário": não há bruto, URL, nota nem
registro da busca em brutos/ (grep em .md, .py, .csv e .tsv). É afirmação verificável e verificável deve ficar. Correção: salvar
os programas (ou a lista consultada no DivulgaCandContas, com data) e citar; ou retirar a frase.

## 4. Testes

`python3 -P relatorio/testes.py`: 13 ok, 0 falhas. O que eles **não** cobrem:
1. **Texto contra CSV.** Nenhum teste confere os números do HTML (2,2 e 8,5; 25% e 90%; 55 pb; as tabelas da seção 15). E1, F1 e
   F2 passariam de qualquer jeito.
2. **Conciliação tautológica.** Os resíduos c1e e c2c são calculados por diferença; o teste de que a ponte fecha não pode falhar.
3. **Canal contra choque de prêmio.** O teste olha só a Selic. Não confere que, nos cenários com canal, a variação das taxas de
   mercado é igual ao canal (sem os -1,5 do cenário 4).
4. **Aditividade e linearidade.** Não testa curva ≈ Selic + prêmio nem a linearidade em 0,5 a 3 pontos que W declara.
5. **Rolagem.** Não testa que `frac()` reproduz o RMD 3.2 nem que a fração não passa de 1.
6. **Fontes.** Não testa que cada chamada [n] aponta para uma entrada que descreve a série usada (E3).
7. **Gráficos.** "Presidente" é testado no cabeçalho dos CSV, não nos SVG.
8. **Travessão.** Só o travessão (U+2014); a meia-risca (U+2013) não é testada (hoje está em zero).
9. **Licença.** Não testa que `em_oas` sai em branco no pacote nem que BAMLEMCBPIOAS fica fora dos zips.
10. **Reprodução.** Os testes leem os CSV prontos; não rodam os build_*. `verifica_reproducao.py` existe à parte e não foi chamado
    por eles.
11. **Classes A, B, C.** Nenhum teste liga a classe de cada conclusão ao tipo de evidência (por exemplo, que nenhuma conclusão A
    depende de regressão).

Sugestão mínima: um teste que extraia do HTML os números da seção 15 e os compare aos CSV, e um teste do canal com a variação
das taxas de mercado.

## 5. Notas

- **N1** canal em duas taxas (2.5).
- **N2** perímetro do Focus (2.5).
- **N3** Focus de 2030 (2.5).
- **N4** "o resto só na rolagem, ao longo de 4 anos em média": 4,0 anos é o prazo médio da DPF inteira, com a LFT. Fora da Selic, o
  prefixado tem 2,23 anos e o índice de preços 7,11 (ponderado, cerca de 4,9). Trocar por "cerca de 2 anos nos prefixados e 7 nas
  NTN-B".
- **N5** explicação do acúmulo (seção 3, critério W).
- **N6** justificativa da conclusão C sobre a Selic (2.8).
- **N7** A tabela de estudos do Anexo C corta os textos em 90 caracteres no meio da palavra ("pa", "faix", "Brasi") e sai sem
  acentos, porque lê o CSV em ASCII. Para o leitor de mercado, abreviar à mão ou mostrar a magnitude inteira.
- **N8** Os pacotes `relatorio/gastos-publicos-brasil-dados.zip` (12:58) e `brutos/gastos-publicos-brasil-brutos.zip` (12:54) são
  de antes da v10: não têm W, X, Y, S-canal-fiscal nem S-sensibilidade-juros. A lógica que tira `em_oas` e BAMLEMCBPIOAS está em
  `monta_pacote.py` e `monta_pacote_brutos.py`, mas ainda não foi aplicada. Regerar antes de publicar.
- **N9** frase truncada na seção 14 (2.6).
- **N10** "O nível é teto da fração externa, as diferenças são piso" é heurística, não limite: diferenças mensais atenuam por
  defasagem e ruído, e as diferenças de 12 meses dão 61%. Escrever "tende a superestimar" e "tende a subestimar".
- **N11** inclinação em Y07 (2.4).
- **N12** Y09, Y13 e Y14 (VAR recursivo) aparecem como "causal identificada"; a ressalva do ordenamento está só no CSV. No texto,
  usar "identificação por ordenamento" para esses.
- **N13** Y05: a página citada (Tab. AIII.1 p. 32, texto p. 15) não traz o "cerca de 50 pb" do teto; ele está nas p. 24 e 28 do
  PDF. Acrescentar à coluna `pagina_ou_tabela`.
- **N14** defasagem do canal (2.5).
- **N15** Três números parecidos para a parte na Selic: 48% (DPF, dez/2025, seção 15), 52,7% (DPF, ago/2026, Essencial) e 53%
  (DBGG com compromissadas, dez/2025, seção 15 e conclusão A). Dizer o perímetro e a data em cada um.

## 6. O que foi rodado

Scripts e saídas no scratchpad, fora do dossiê:
- `aud/s_base.py`, `aud/variantes.py`, `aud/variantes2.py`: cópia de `build_S.py` e as variantes (mercado de set/2026, estoque
  crescendo, Focus 2030, perímetro, sem defasagem, canal só no prefixado, primário que estabiliza).
- `aud/x_copy.py`, `aud/w_copy.py`: cópias de `build_X.py` e `build_W.py` gravando em `aud/outX` e `aud/outW`.
- `aud/x_alt.py`, `aud/x_hac.py`: decomposições alternativas da fração externa, com Newey-West de 3 defasagens na janela 2019-2026.
- `aud/pg.py`: extração das páginas dos PDFs de Y.
- `dl/`: arquivos baixados na origem (FRED, Olinda, Ipeadata, RMD).

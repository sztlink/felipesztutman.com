# Auditoria adversarial, agro e meio ambiente, v12.5

Cópia que acompanha o pacote. O texto é o do parecer, sem mudança de redação. O caminho do rascunho do auditor foi trocado pela limpeza do pacote.

Feita em 20/10/2026 por auditor que não construiu a parte. Só leitura e cálculo, nenhum arquivo do dossiê foi editado.
Escopo: seção 3 (subseção "Agro, meio ambiente e cultura por governo, 2000 a 2025", gráficos 3b, 3c, 3d e as duas tabelas),
seção 16 (parte "Agro e meio ambiente", tabela tab_prop('agro'), três parágrafos, pergunta concreta do produtor rural, quatro
linhas da matriz de termos), item "Agro e meio ambiente por governo" do Essencial e item de agro em "Limites dos dados".

Abreviações: R = a raiz do pacote. Valores "reais" são R$ de 2025 como no dossiê.

Consultas externas feitas nesta tarefa, uma por vez, com pausa (2 de 3 permitidas):
1. SIOP SPARQL, grafo 2024, ações com rótulo de equalização, subvenção, seguro rural, sustentação de preços, securitização,
   saneamento de ativos e lavoura cacaueira, por função e GND, liquidado e pago. Salvo em
   `<pasta temporaria do auditor>/siop/subv2024.csv`.
2. SIOP SPARQL, grafos 2020, 2021, 2023 e 2024, ações com rótulo Aldir, Paulo Gustavo, Setor Cultural ou Audiovisual, por
   função. Salvo em `.../scratchpad/siop/cult.csv`.

---

## 1. Erros (fato ou número errado)

### E1. "Dentro dela estão as equalizações", e "As equalizações do Orçamento de Subsídios já estão dentro da função Agricultura e não se somam a ela" (seção 3, texto e nota da tabela; LEIAME de FN)
**Problema.** O valor do OSU não cabe dentro do liquidado da função Agricultura. Em vários anos ele é maior que todo o GND 3
da função, e em 2015 é maior que a função inteira.
**Evidência.** Recalculado de `R/brutos/FN/fontes/siop_funcoes_sf_*.csv` (sem modalidade 91) contra `FN-subsidios-agro-cultura.csv`,
R$ bi correntes:

| ano | Agricultura GND 3 | Agricultura GND 1+3+4 | OSU, equalizações e subvenções agrícolas |
|---|---|---|---|
| 2003 | 1,94 | 3,31 | 4,08 |
| 2005 | 3,11 | 4,99 | 5,33 |
| 2015 | 10,17 | 14,23 | 19,34 |
| 2016 | 10,59 | 15,01 | 11,73 |
| 2017 | 5,86 | 10,51 | 9,30 |
| 2019 | 5,64 | 10,34 | 7,15 |
| 2021 | 6,91 | 11,39 | 7,92 |
| 2024 | 10,40 | 14,77 | 10,66 |

Na própria tabela da seção 3, a linha "2016 (Dilma e Temer)" mostra Agricultura 23,3 e equalizações 18,2. Sobrariam 5,1 bi para
o resto da função, e só o pessoal (GND 1) de 2016 foi R$ 4,27 bi correntes, cerca de 6,6 bi reais.
A consulta 1 ao SIOP mostra que em 2024 as ações de subvenção agrícola da função Agricultura somam R$ 8,27 bi liquidados
(7,91 pagos), contra R$ 10,66 bi no OSU. O seguro rural é R$ 1,00 bi liquidado e 0,64 pago no SIOP, contra 0,73 no OSU.
Parte pequena está em Encargos Especiais (lavoura cacaueira 0,077, déficit do seguro rural 0,017). Ou seja, as ações são as
mesmas, mas o OSU mede outra coisa (provavelmente pagamento com restos a pagar ou competência, não verificado) e os números
não se aninham.
**Correção.** Trocar por algo como "As mesmas ações de equalização e subvenção estão, na maior parte, dentro da função
Agricultura. O Orçamento de Subsídios as mede por outro critério, e em alguns anos o valor dele supera o liquidado da função,
por isso as duas colunas não se somam nem se subtraem". Na tabela, tirar a leitura implícita de que a coluna de equalizações
é parte da coluna Agricultura, ou trocar a coluna do OSU pela soma das ações de subvenção no SIOP (liquidado), que aí sim
estaria dentro da função.

### E2. "Fora dessa conta ficam as inversões financeiras, que são empréstimos" (seção 3), e a regra do LEIAME de FN
**Problema.** Inversão financeira (GND 5) não é só empréstimo. Na Organização Agrária, o GND 5 é sobretudo obtenção de terras
para reforma agrária e crédito a assentados. Na Agricultura, parte é compra de estoques (AGF, subfunção Abastecimento).
E o GND 5 da Organização Agrária some do texto, porque não está na despesa da linha nem na soma de inversões "em Agricultura
e Gestão Ambiental".
**Evidência.** `siop_funcoes_sf_2005.csv`: Organização Agrária, subfunção Reforma Agrária GND 5 R$ 1,33 bi e Outros Encargos
Especiais GND 5 R$ 1,02 bi, contra R$ 1,24 bi de despesa sem GND 5. Agricultura, Abastecimento GND 5 R$ 1,14 bi.
`FN-funcoes-uniao.csv`, Organização Agrária, inversões reais: Lula 1 de 3,1 a 7,8 bi por ano, Lula 2 de 4,0 a 7,8. Em 2025, ações
"Concessão de Crédito-Instalação às Famílias Assentadas" 0,67, "Fundo de Terras" 0,41 e "Reforma Agrária e Governança
Fundiária" 0,21 (`FN-inversoes-acoes.csv`).
Somando o GND 5, a Organização Agrária por mandato fica em FHC 5,1, Lula 1 8,8, Lula 2 11,4, Dilma 9,1, Temer 2,4,
Bolsonaro 1,6 e Lula 3 3,2 (reais por ano). O maior mandato passa de Dilma para Lula 2. Bolsonaro continua o menor.
Que aquisição de imóveis e de produtos para revenda são inversão financeira é classificação do Manual Técnico de Orçamento,
conhecimento geral não verificado em arquivo nesta tarefa. Os valores acima são dos arquivos.
**Correção.** "Fora dessa conta ficam as inversões financeiras, na maior parte empréstimos (Funcafé, Pronaf, Fundo Clima,
refinanciamento de dívidas rurais), mas também compra de terras para reforma agrária e de estoques". Mostrar a Organização
Agrária com e sem GND 5, ou ao menos dizer que a linha exclui a obtenção de terras.

### E3. "5,7% do texto" do PL (seção 16, primeiro parágrafo)
**Problema.** Arredondamento da soma de parcelas arredondadas.
**Evidência.** `PR-agro-ambiente.csv`: (546 + 795) / 23.282 = 5,76%. O PT está certo, (1.666 + 1.384) / 24.724 = 12,34%.
**Correção.** "5,8% do texto".

### E4. Arredondamento de meio inteiro nas médias por mandato (FL)
**Problema.** `build_FL.py` usa `round()` do Python, que arredonda .5 para o par. Pequeno, mas o texto mostra o dígito.
**Evidência.** Lula 2 Amazônia 39.026/4 = 9.756,5, publicado 9.756. Cerrado Bolsonaro 33.442/4 = 8.360,5 (publicado 8.360),
Lula 3 31.938/4 = 7.984,5 (7.984), Temer 14.377/2 = 7.188,5 (7.188), Lula 1 22.823,5 (22.824, por acaso igual).
**Correção.** Arredondar meio para cima (9.757, 8.361, 7.985, 7.189), ou declarar o critério. Não muda leitura.

---

## 2. Vieses (escolha que favorece um lado)

### V1. Cultura entra com o FSA, que é investimento retornável, e o resto sai sem o GND 5; e a função Cultura omite as maiores transferências da cultura dos dois governos
**Problema.** Duas escolhas de perímetro mexem na leitura "Cultura, menor média com Bolsonaro, voltou a R$ 2,31 bi no Lula 3".
(a) O FSA (GND 5, "Investimentos Retornáveis ... mediante Participação em Empresas" e "Financiamento ao Setor Audiovisual") soma
R$ 1,10 bi por ano no Lula 3 e zero com Bolsonaro, enquanto o Fundo Clima, também reembolsável, sai da Gestão Ambiental. Metade
da alta da Cultura de Bolsonaro para o Lula 3 é o FSA (sem ele, 0,79 para 1,21).
(b) A Lei Aldir Blanc de 2020 e a Política Nacional Aldir Blanc de 2023 foram executadas na função Encargos Especiais e não
aparecem em nenhuma linha.
**Evidência.** Consulta 2 ao SIOP. 2020, Encargos Especiais, "Auxílio Financeiro aos Estados, ao Distrito Federal e aos
Municípios relacionado ao Apoio Emergencial do Setor [Cultural]", GND 3, R$ 3,0 bi liquidados. 2023, Encargos Especiais,
"Implementação da Política Nacional Aldir Blanc de Fomento à Cultura", R$ 2,26 bi. Em 2024 a busca não achou a PNAB por esses
rótulos, e a Lei Paulo Gustavo não apareceu com esse nome (não verificado onde estão). `grep` de "Aldir" no
`monta_relatorio.py` e nos CSV de CU não acha nada.
Conta com o deflator do próprio `FN-funcoes-uniao.csv` (2020, fator 0,774/0,581): a Aldir Blanc vale cerca de R$ 4,0 bi reais
e levaria a média Bolsonaro de 0,79 para cerca de 1,79, acima de Temer (1,41), 2016 (1,37), Lula 1 (1,19) e FHC (1,02). A PNAB
de 2023 sozinha leva o Lula 3 de 2,31 para pelo menos 3,13.
**Efeito.** A frase "Cultura tiveram a menor despesa média com Bolsonaro" do Essencial e "Com Bolsonaro, a despesa direta caiu
e o incentivo fiscal se manteve" dependem do perímetro "função Cultura". A transferência de 2020 é emergencial e de iniciativa
do Congresso, o que pesa contra contá-la como política do governo, mas a de 2023 também é lei e também fica fora. As duas
ficam fora por igual, só que a de 2020 é o que separa Bolsonaro do último lugar.
**Correção.** Tratar a cultura por um perímetro só. Ou função Cultura sem FSA (e aí dizer que FSA, Aldir Blanc e PNAB ficam
fora), ou função Cultura mais FSA mais as transferências federativas da cultura em Encargos Especiais. Em qualquer caso, nomear
a Aldir Blanc de 2020 e a PNAB no texto e tirar "a menor média entre os mandatos" do Essencial, ou qualificá-la.

### V2. Essencial escolhe só achados desfavoráveis a um lado
**Problema.** O item cita a queda do desmatamento na Amazônia e "Gestão Ambiental, Organização Agrária e Cultura tiveram a
menor despesa média com Bolsonaro". Não cita nada que pese contra o Lula 3 ou a favor de Bolsonaro, embora os dados tenham.
**Evidência.** `FL-desmatamento.csv`: Cerrado 11.012 km² em 2023, o maior valor desde 2015 (11.132), no primeiro ano PRODES do
Lula 3 (com cinco meses de Bolsonaro). Média do Cerrado Bolsonaro 8.360 contra Lula 3 7.984, quase iguais.
`FN-por-mandato.csv`: Gestão Ambiental sem recursos hídricos no Lula 3 (2,52) abaixo de FHC (3,24), Lula 2 (3,44) e Dilma (3,29).
Equalizações e subvenções agrícolas em nível parecido, 10,4 com Bolsonaro e 12,4 no Lula 3.
**Correção.** Pôr no mesmo item o Cerrado (pico em 2023, médias parecidas) e qualificar as três "menores médias" com o
perímetro (sem recursos hídricos, sem inversões, função Cultura sem Aldir Blanc).

### V3. Seção 16, segundo parágrafo, confere a fala do PL com dado e não confere as do PT
**Problema.** Logo depois de "diz retomar o compromisso assumido no governo Bolsonaro", o texto põe "Pelo PRODES, a Amazônia
perdeu 11.403 km² por ano ... Bolsonaro e 6.162 ... Lula 3". A justaposição funciona como checagem de uma alegação do PL. As
alegações retrospectivas do PT nas mesmas páginas não são checadas.
**Evidência.** PT p. 61, "foram batidos recordes de produção de grãos, graças a uma oferta crescente de crédito rural" (atribuição
causal). PT p. 59, Pronaf "ano após ano, recorde". PT p. 70, Fundo Clima "saiu de uma média anual de R$ 400 milhões até 2022,
mobilizou R$ 52,4 bilhões desde 2023 e R$ 34,6 bilhões apenas em 2025". PL p. 54, "mais de 450 mil documentos de titulação
de imóveis rurais, mais do que nos dez anos anteriores somados". O dossiê tem dado para checar ao menos o Fundo Clima
(inversões da Gestão Ambiental sem recursos hídricos, 2019 a 2022, de R$ 0,03 a 0,44 bi correntes, e R$ 15,6 bi liquidados em
2025 contra R$ 34,6 bi "mobilizados" que o PT cita).
**Correção.** Ou tirar a justaposição e deixar o número do PRODES na seção 3, ou checar com o mesmo rigor uma alegação de cada
lado (Fundo Clima liquidado contra mobilizado no PT, titulação no PL, que exigiria dado do Incra não presente no pacote).

### V4. Seção 16, terceiro parágrafo, "sem dizer o orçamento da fiscalização" pregado só no PL
**Problema.** A frase final "o PL propõe consolidar o mercado regulado de carbono e eliminar superposições entre Ibama, Funai
e ICMBio, sem dizer o orçamento da fiscalização" atribui a ausência só ao PL. O PT também não diz, como o primeiro parágrafo
reconhece. E do PL a prosa escolhe "eliminar superposições", que lê como enxugamento, e não "Vamos fortalecer a fiscalização
ambiental, com prioridade para as áreas de maior pressão" (p. 58), enquanto do PT fica o Fundo Clima com o valor de R$ 15,6 bi.
**Evidência.** PDF do PL, pp. 58 e 59. PDF do PT, p. 72 ("Seguiremos fortalecendo e aprimorando as ações de fiscalização", sem valor).
**Correção.** "No clima, o PT mantém o Fundo Clima e o PL propõe consolidar o mercado regulado de carbono. Os dois prometem
fortalecer a fiscalização, e o PL propõe também eliminar superposições entre Ibama, Funai e ICMBio. Nenhum diz o orçamento".

### V5. Matriz de termos, linha "agro e crédito rural" com vocabulário do PT, linha "desmatamento e fiscalização" inflada para o PL
**Problema.** A auditoria anterior apontou listas com a palavra de um plano só. Duas das quatro linhas novas repetem o defeito,
em sentidos opostos.
**Evidência.** Recontagem nos PDFs com a mesma normalização do `build_PR.py` (as quatro linhas reproduzem 29/15, 12/6, 12/16 e
56/25). "agricultura familiar" é PT 10, PL 0 e entra na lista. "produtor" é PT 5, PL 16 e não entra. Com "produtor rural" e
"pequeno produtor" a linha vai a 30/19. Na outra linha, "desmatamento" sozinho é PT 10, PL 5. O PL passa à frente (16 a 12) por
"queimadas" (0/3), "crimes ambientais" (2/4) e "Ibama, ICMBio" (0/2), e as duas menções a Ibama e ICMBio do PL estão na frase
sobre eliminar superposições. A prosa da seção 16 repete "o vocabulário de desmatamento e fiscalização aparece 16 vezes no
plano do PL e 12 no do PT", o que sugere mais atenção do PL ao desmatamento.
**Correção.** Pôr "produtor rural" na primeira linha. Separar "desmatamento" de "fiscalização e crime ambiental", ou tirar a
frase da prosa.

### V6. Peso dos capítulos, PT conta fome, proteção animal e segurança hídrica como agro e meio ambiente
**Problema.** "12,3% contra 5,7%" compara o item 9 do PT, que abre com fome, Bolsa Família e alimentação escolar, e o item 11, que
tem dois blocos de proteção animal e um de segurança hídrica, com capítulos do PL que são só agro e só meio ambiente.
**Evidência.** Contagem de palavras nos PDFs, PT: do título do item 9 até "A agricultura familiar contou", 337 palavras. Blocos
de proteção animal (ProPatinhas, SinPatinhas, Lei AMAR, maus-tratos), 122 + 106. Segurança hídrica (transposição, cisternas,
barragens), 83. Somam cerca de 650 das 3.050 palavras. Sem eles o PT fica perto de 9,7%. A diferença com o PL existe, mas é menor.
**Correção.** Dizer o que entra em cada capítulo, ou contar só os parágrafos de agro e meio ambiente nos dois planos.

### V7. Renúncia "da agricultura e agroindústria" é quase toda cesta básica
**Problema.** O texto diz que a renúncia "inclui a desoneração da cesta básica". Pelo próprio OSU, ela é a maior parte da linha.
Pôr "R$ 8,4 bi no Lula 1, R$ 63,1 bi com Bolsonaro e R$ 78,9 bi em 2023 e 2024" num parágrafo de agro faz a série ler como
subsídio ao produtor que cresce por governo.
**Evidência.** `R/brutos/E/osu_2025-anexos-publicacao.xlsx`, Tabela 15 (R$ bi de 2016): setor Agricultura 10,65 em 2006 e 24,94
em 2016, dos quais "Desoneração Cesta Básica" 8,11 e 22,51 (76% e 90%). A Tabela 6 rotula a linha inteira como
"Agricultura e Agroindústria, Desoneração da Cesta Básica".
**Correção.** "A renúncia que o Orçamento de Subsídios chama de agricultura e agroindústria é, em 2016, 90% desoneração da cesta
básica". Tirar a comparação por mandato ou deixá-la só para a parte que não é cesta, se houver dado. "que beneficia quem compra"
é afirmação de incidência que o dado não sustenta (ver X4).

---

## 3. Excessos (afirmação mais forte do que o dado permite)

### X1. "3.335 km² ... o menor valor desde o início da série" (seção 3, seção 16 e Essencial) sem dizer no lugar que o dado é recente
**Problema.** O valor de 2026 está no painel de 16/10/2026 e o próprio "Limites" diz que pode ser revisado. Na seção 3, na 16 e no
Essencial a frase vem sem qualificador. Não verifiquei se o número do painel é estimativa preliminar ou taxa consolidada, o JSON
não traz marca.
**Evidência.** `prodes_amazonia_legal_rates2026.json`, período 2025-08 a 2026-07, soma das UFs 3.335. O mínimo anterior da série
é 4.571 (2012), então "menor desde 1988" confere com o arquivo. A queda é de 42% sobre 2025 (5.731).
**Correção.** "3.335 km² no ano encerrado em julho de 2026, pelo dado de outubro de 2026, sujeito a revisão".

### X2. "O desmatamento responde também a preço de commodity, câmbio, clima, crédito e fiscalização dos estados" (nota da tabela)
**Problema.** O "também" pressupõe que o desmatamento responde à ação do governo federal e põe o resto como fator adicional. É
atribuição causal implícita, logo depois de "Mandato data o valor e não atribui causa".
**Correção.** "O desmatamento responde a política federal e estadual, preço de commodity, câmbio, clima e crédito, e o dado não
separa esses efeitos".

### X3. "o custo da equalização sobe e desce com o juro da economia" e as médias do OSU por mandato
**Problema.** Conceitualmente certo, mas a série do OSU também sobe e desce com o calendário de pagamento, o que o texto não diz.
**Evidência.** `FN-subsidios-agro-cultura.csv`, correntes: 3,07 bi em 2013, 2,81 em 2014, 19,34 em 2015, 11,73 em 2016. A média de
Dilma (12,3) e a linha de 2016 (18,2) carregam pagamentos de anos anteriores. Parte da série de Lula 1 é custo de renegociações
antigas (Securitização Agrícola 1,93 bi e PESA 0,18 bi em 2003, de 4,08 bi no total). O nexo da quitação de 2015 com atrasos de
2013 e 2014 é conhecimento geral, não verificado em arquivo. O salto em si está no arquivo.
**Correção.** "O valor do ano segue o juro e também o calendário de pagamento, e o salto de 2015 e 2016 inclui pagamentos
atrasados". Considerar médias de 2003 a 2014 e de 2015 em diante separadas, ou não comparar mandatos com essa série.

### X4. "Ela inclui a desoneração da cesta básica, que beneficia quem compra"
**Problema.** Quem fica com a desoneração (consumidor, varejo, produtor) é questão de incidência. Nenhum arquivo do pacote mede
isso.
**Correção.** "que reduz o imposto sobre alimentos da cesta".

### X5. "Gestão Ambiental, Organização Agrária e Cultura tiveram a menor despesa média com Bolsonaro" (Essencial)
**Problema.** No Essencial o resultado aparece sem os perímetros que o sustentam.
**Evidência.** Testei: Gestão Ambiental continua menor com Bolsonaro somando recursos hídricos (3,62 contra 3,95 no Lula 3 e 4,39
com Temer) e somando o GND 5 (3,93). Organização Agrária continua menor somando o GND 5 (1,60 contra 2,45 com Temer). A Cultura
não se sustenta com a Aldir Blanc de 2020 (V1).
**Correção.** "Gestão Ambiental e Organização Agrária tiveram a menor despesa média com Bolsonaro, também quando se somam os
recursos hídricos e as inversões. Na Cultura, depende de contar ou não a Lei Aldir Blanc de 2020, executada fora da função".

### X6. "O PRODES mede todo o corte raso, legal ou ilegal, sem descontar a regeneração" (seção 16)
**Problema.** "todo" é forte demais. O PRODES Amazônia mapeia a supressão de vegetação primária acima de uma área mínima e não
remapeia área já desmatada, então corte de vegetação secundária fica fora. É conhecimento geral sobre o método, não verificado em
arquivo do pacote. "legal ou ilegal" e "sem descontar a regeneração" estão certos pelo mesmo conhecimento geral.
**Correção.** "O PRODES mede o corte raso da vegetação nativa, legal ou ilegal, e não desconta a regeneração".

### X7. "Organização Agrária ... de R$ 6,7 bi por ano no governo Dilma"
**Problema.** A média de Dilma é puxada por um ano.
**Evidência.** `FN-funcoes-uniao.csv`, 2013, 12,89 bi reais. `siop_funcoes_sf_2013.csv`: subfunção Ordenamento Territorial,
GND 4, R$ 3,77 bi correntes num ano só. Sem 2013 a média de Dilma é 5,19. Não verifiquei qual ação é.
**Correção.** Nomear o pico de 2013 ou dar a mediana.

### X8. "O Fundo Clima emprestou R$ 10,5 bi em 2024 e R$ 15,6 bi em 2025"
**Problema.** O número é o liquidado pela União ao agente financeiro (BNDES), não o que chegou aos tomadores. E o PT cita
R$ 34,6 bi "mobilizados" em 2025 para o mesmo fundo. O leitor que tiver o plano verá dois números sem explicação.
**Correção.** "A União liberou R$ 15,6 bi ao Fundo Clima em 2025, como empréstimo. O plano do PT cita R$ 34,6 bi mobilizados, que
incluem outras fontes".

### X9. Menor, "Gestão Ambiental, sem as obras de recursos hídricos"
A subfunção Recursos Hídricos também tem custeio (GND 3, R$ 0,25 bi em 2024, `siop_funcoes_sf_2024.csv`). "sem a subfunção
Recursos Hídricos" é mais exato. A exclusão não muda a ordem dos mandatos (X5).

---

## 4. Conferido e certo

- PRODES Amazônia, todas as médias por mandato refeitas da soma das UFs no JSON (19.347, 21.617, 9.756,5, 5.620, 7.893, 7.241,5,
  11.403, 6.162). Pico de 27.772 em 2004, 4.571 em 2012, 13.038 em 2021, 3.335 em 2026. Taxa de 1988 21.050, como o LEIAME diz.
- 3.335 é o menor valor de 1988 a 2026 no arquivo.
- Cerrado, somas por período do JSON batem com o CSV (por exemplo 53.866 no biênio 2000 a 2002, 26.933 por ano). A divisão dos
  biênios cai inteira dentro de cada mandato (2001-02 FHC, 2003-06 Lula 1, 2007-10 Lula 2, 2011-12 Dilma), então não há biênio
  partido entre presidentes. 6.319 em 2019, 11.012 em 2023, 5.517 em 2026, 22.824 Lula 1 e 7.188 Temer conferem.
- Atribuição do ano PRODES (agosto de t-1 a julho de t ao presidente de janeiro a julho de t) é simétrica (2003, 2019 e 2023 todos
  com cinco meses do antecessor) e robusta. Com a regra alternativa (ano t ao presidente de agosto de t-1) a Amazônia fica em
  11.137 com Bolsonaro (2020 a 2023) e 5.195 no Lula 3 (2024 a 2026), e o Cerrado em 9.534 e 6.975. A ordem não muda.
- SIOP, médias por mandato de Agricultura (13,2, 25,8, 14,5, 17,9), Organização Agrária (6,7, 1,35, 2,6), Gestão Ambiental sem
  recursos hídricos (de 1,93 a 3,44, menor com Bolsonaro, 2,5 no Lula 3), inversões de Agricultura e Gestão Ambiental (5,9 a 10,0
  até 2022, 19,4 no Lula 3, refeito ano a ano: 6,71, 16,72 e 34,91). Ações de 2024 e 2025: Fundo Clima 10,456 e 15,585, dívidas
  rurais 12,0, Funcafé 5,4 a 6,9.
- OSU Tabela 1: a soma das dez linhas da lista dá 10,655 bi em 2024. Seguro rural 0,733. Médias de equalização 12,0, 10,4 e 12,4.
  Renúncia agro 8,4, 63,1 e 78,9. Cultura e audiovisual 2,46 e 2,65.
- "Equalizações e subvenções entram na despesa sujeita ao limite do arcabouço". Confere. `R/brutos/D/nt_lc200_ago2026.pdf`, p. 15,
  item III ("Despesas orçamentárias primárias sujeitas aos limites da LC 200/2023"), subitem III.14 "Subsídios, Subvenções e Proagro".
  As inversões (Fundo Clima, dívidas rurais) são financeiras e ficam fora do limite, e o texto não diz o contrário.
- PIB da agropecuária, SIDRA 5932 v6563 no 4º trimestre, médias geométricas refeitas: 5,28, 3,96, 2,92, 3,33, -5,2, 7,56, 0,86,
  7,75. Quedas de 5,2% em 2016 e 3,7% em 2024 conferem.
- Cultura por mandato (1,02, 3,18, 1,41, 0,79, 2,31) e Rouanet (2,57, 1,84, 2,28, 3,06) conferem com `FN-por-mandato.csv`.
- As 21 citações agro do `build_PR.py` estão literalmente nas páginas indicadas dos dois PDFs (li PT pp. 58 a 63 e 69 a 73, PL
  pp. 53 a 59). "diz retomar o compromisso assumido no governo Bolsonaro" confere com o PL, p. 58. Ibama, Funai e ICMBio, p. 59.
- As quatro linhas da matriz reproduzem (29/15, 12/6, 12/16, 56/25). Palavras por capítulo reproduzem (1.666, 1.384, 546, 795).
- "Nenhum dos dois traz valor de orçamento para o Plano Safra, o seguro rural, a fiscalização ou o Fundo Clima em 2027 a 2030".
  Confere nas páginas lidas. Os valores em reais que aparecem são do passado.
- "desmatamento líquido zero compensa a perda com vegetação recuperada" é a definição usual. Conhecimento geral, o plano do PT
  não define o termo.
- Equilíbrio das citações na tabela: oito temas, uma célula por lado em todos, trechos do mesmo tipo (promessa no futuro).
  Faltam dos dois lados coisas que pesam, e sem favorecer um. PT, crédito fundiário e regularização fundiária no Norte (p. 60),
  Garantia-Safra (p. 60), instrumento para perdas sistêmicas de safra (p. 62), resiliência climática e irrigação (p. 61). PL,
  "segurança jurídica sólida, irreversível ... do direito de propriedade" (p. 54), irrigação e Matopiba (pp. 54 e 55), armazenagem
  de safras (p. 54), "sem criar novas obrigações ou custos desnecessários para o produtor rural" na fiscalização (p. 58). Na prosa,
  "na terra, o PT fala em reforma agrária, o PL em titulação" deixa de fora que o PT também fala em regularização fundiária e
  titulação (de territórios quilombolas), e que o PL fala em direito de propriedade.
- Regra de voz: na parte nova (texto, tabelas, notas, Essencial, Limites, rótulos dos SVG) não há dois-pontos, ponto-e-vírgula,
  travessão nem "não é X, é Y". Os únicos dois-pontos são metadados do matplotlib dentro do SVG, que o leitor não vê. Nos
  trechos dos planos não há construção proibida citada.
- Linguagem causal. Fora de X2 e de "A série segue a safra e o clima" (pouco controverso), o texto data e não atribui. "Com
  Bolsonaro" e "no Lula 3" são usados de forma consistente.
- Deflator. IPCA de dezembro a dezembro aplicado a fluxo do ano rebaixa um pouco os anos de inflação alta (2002, 2003, 2015,
  2021), sem favorecer um lado de forma clara. É o mesmo da frente N. Fica como nota de método, não como erro.

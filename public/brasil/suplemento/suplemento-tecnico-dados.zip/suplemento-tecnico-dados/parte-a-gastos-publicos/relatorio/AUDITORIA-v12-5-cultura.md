# Auditoria adversarial, cultura e governo, v12.5

Cópia que acompanha o pacote. O texto é o do parecer, com três trocas de redação, duas para que as hipóteses testadas apareçam de forma impessoal e uma que tira um termo interno de trabalho.

Feita em 20/10/2026 por auditor que não construiu a parte. Só leitura e cálculo, nenhum arquivo do dossiê foi editado.

Abreviação. R = a raiz do pacote. "Real" = R$ de 2025, deflator do próprio `FN-funcoes-uniao.csv`.

Escopo. Seção 3, "Cultura por governo, 2000 a 2025" (Despesa, Ministério e regras, Fluxo da Lei Rouanet, Temas dos projetos,
Atenção pública, duas tabelas, gráficos 3d, 3e, 3f). Seção 16, parágrafo "O plano do PL não cita o Ministério da Cultura".
Essencial, item "Cultura.". Limites, itens "Cultura." e "Cultura e governo.". Resolução do parecer de agro.

**Aviso de versão.** O HTML e o PDF são de 14:34:00. O `monta_relatorio.py` foi gravado às 14:35:55 e os `CV-*.csv` às 14:35:01,
por outra sessão de trabalho em atividade. O item "Cultura e governo." dos Limites existe só no script e **não está no HTML nem no PDF**, e o
item de agro dos Limites também difere entre os dois. Auditei o texto do script. Nas partes da seção 3 e da seção 16 o texto do
script e o do HTML coincidem. Remontar antes de circular.

Consultas externas (2 de 3, uma por vez).
1. Busca web sobre a PNAB em 2024. Resultado. O Guia do MinC diz que o Ciclo 1 foi de 2023 a 2024 e o Ciclo 2 começou em 2025
   (Portaria MinC 243, de 9/10/2025). Uma MP 1.274/2024, de 22/11/2024, alterou a política. Não li o texto da MP, então o
   conteúdo dela fica **não verificado**.
   Fontes: https://www.gov.br/cultura/pt-br/assuntos/acoes-programas-e-politicas/politica-nacional-aldir-blanc-de-fomento-a-cultura/arquivos/guia-pratico-monitoramento-e-avaliacao-ciclo-1 ,
   https://brasil61.com/n/minc-conclui-repasses-do-ciclo-2-da-politica-nacional-aldir-blanc-cult260278 ,
   https://www.conjur.com.br/?p=832041
2. Busca web sobre a execução da Lei Paulo Gustavo. Resultado. O TCU respondeu que os entes podiam usar o recurso mesmo sem
   empenho ou inscrição em restos a pagar em 2022. O STF, na ADI 7232, autorizou a execução até 31/12/2023. O valor e o ano do
   pagamento federal não apareceram na busca e ficam **não verificados**.
   Fontes: https://portal.tcu.gov.br/imprensa/noticias/recursos-da-lei-paulo-gustavo-para-a-cultura-podem-ser-usados-pelos-entes-federados-ate-31-de-dezembro-de-2023 ,
   https://informativos.trilhante.com.br/julgados/stf-adi-7232-tpi-ref-df

---

## 1. Erros

### E1. "A queda começou em 2016, ano da troca de governo, seguiu com Temer e foi mais funda de 2019 a 2022" (Fluxo)
**Problema.** A frase vale para os projetos novos e não vale para a CNIC, que está na mesma frase anterior.
**Evidência.** `CV-salic-por-ano.csv` e `fontes/salic/grid_Avaliacao_Cnic_Ano.txt`. A CNIC avaliou 8.573 projetos em 2011, 6.582 em 2012,
6.698 em 2013, 6.234 em 2014 e 5.531 em 2015. A queda foi de 35% dentro do governo Dilma. 2018 (Temer) teve 1.539, menos que
2019 (1.707), 2021 (1.691) e 2022 (1.814). Só 2020 (1.370) foi menor. A média de Bolsonaro (1.646) é 18% menor que a de Temer
(2.019), e a CNIC subiu de 2020 a 2022.
**Correção.** "Os projetos novos caíram em 2016 e de novo de 2019 a 2022. As avaliações da CNIC caíram desde 2012, tiveram o menor
ano de Temer em 2018 (1.539) e ficaram perto disso com Bolsonaro".

### E2. Total da cultura por mandato soma o FSA, que o próprio texto chama de inversão financeira (tabela e frase "Somadas as três partes")
**Problema.** Investimento retornável e empréstimo entram no "Total" junto com despesa. Na parte de agro, as inversões de
Agricultura e Gestão Ambiental ficam fora e não se somam a nada. O perímetro das duas partes não é o mesmo.
**Evidência.** `FN-funcoes-uniao.csv`, GND 5 da Cultura, 1,339, 1,043 e 0,911 bi reais de 2023 a 2025. No arquivo de ações de 2023,
R$ 1,075 bi é "Investimentos Retornáveis ... mediante Participação em Empresas". O Total do Lula 3 de 3,72 tem 1,10 de FSA. Sem
ele fica 2,63, contra 1,79 com Bolsonaro.
**Correção.** Na tabela, mostrar "Total sem o FSA" (Lula 3 2,63) e deixar o FSA em coluna à parte, como na parte de agro. Na prosa,
dar os dois totais.

### E3. "a estrutura do ministério custa 0,03% da despesa primária" (Essencial)
**Problema.** A medida é o pessoal ativo e a administração da **função** Cultura, não do ministério. O dossiê mostra na seção 7 que
órgão e função dão contas diferentes. A função inclui autarquias (Iphan, Ancine, Funarte e outras, conhecimento geral não
verificado no pacote) que não somem quando o ministério é extinto. O item também não cita fonte.
**Evidência.** `build_CV.py`, regex ESTR, ações "Ativos Civis da União", "Pagamento de Pessoal Ativo" e "Administração da Unidade"
dentro de `siop_acoes_cultura_funcao_*.csv`. A seção 16 diz certo ("da função Cultura"), o Essencial diz "do ministério".
**Correção.** "o pessoal ativo e a administração da função Cultura custam 0,03% da despesa primária[86][1]".

### E4. "A política nacional de cultura passou ao Ministério da Cidadania e, em 2021, ao do Turismo" (Ministério e regras)
**Problema.** Provável erro de data. A ida da Secretaria Especial da Cultura ao Ministério do Turismo foi em novembro de 2019,
por decreto (Decreto 10.107/2019, conhecimento geral, **não verificado**). O que o arquivo baixado mostra é só quando a lista de
competências da Lei 13.844 foi reescrita, pela MP 1.058/2021.
**Evidência.** `fontes/planalto_l13844.htm`. O inciso "IX - política nacional de cultura" do Turismo aparece "(Incluído pela Medida
Provisória nº 1.058, de 2021)". O arquivo não cita nenhum ato de 2019 sobre a mudança.
**Correção.** Baixar o Decreto 10.107/2019 do Planalto e datar pela estrutura. Se não baixar, escrever "e, pela lei, em 2021, ao do
Turismo".

### E5. "Os filtros tiram falsos positivos da busca por radical, como Dragão, Rio Negro e Afrodite" (nota da tabela)
**Problema.** Os filtros tiram esses e deixam outros. A regex `\bnegr[oa]s?\b` pega nomes que não falam de população negra.
**Evidência.** Varredura dos `projetos_nome_Afro/Negr/Quilomb.json` com a regex do `build_CV.py`. No período de 2009 a 2025 passam,
entre outros, "Cisne Negro Cia. de Dança" (2010, 2013 três vezes, 2015, 2016, 2018, 2019, 2023), "Ouro Negro" (petróleo, 2010, e
café conilon, 2025), "Buraco Negro" (2015), "A Ovelha Negra" (2010, 2020 duas vezes, 2023), "Rosa Negra" (2013), "A negra tirania na
inquisição" (2010), "pedra negra" (Itaúna, 2025). Com Bolsonaro são 3 de 62 (5%). Em Dilma ao menos 6 de 218 (3%), sem contar
"Pérola Negra" (escola de samba e companhia, ambíguo). O efeito nas parcelas é pequeno e não muda a ordem, mas a frase promete
mais do que o filtro faz.
**Correção.** "Os filtros tiram os falsos positivos mais comuns (Dragão, Rio Negro, Afrodite). Restam alguns, como Cisne Negro e Ouro
Negro, cerca de 3% a 5% dos projetos do tema". Ou acrescentar à regex as exclusões listadas.

### E6. Fonte errada no Essencial
**Problema.** "sem queda na captação[86][92]". A captação é a fonte [88] (Salic, captação por ano). [92] é o painel de propostas e
temas.
**Correção.** Acrescentar [88]. Nota menor. [88] diz "lido em 18/10/2026", e `downloads.tsv` registra o grid de captação em 20/10.
Os valores de 2025 diferem em R$ 1.200 entre `E-renuncias-e-subsidios.csv` (leitura de 18/10) e o grid novo. Não muda nada no texto.

---

## 2. Vieses

### V1. A Lei Paulo Gustavo fica fora dos dois governos, e o texto não mostra a conta que ela muda
**Problema.** O texto diz "R$ 3,862 bi empenhados em 2022 e nada liquidado no ano" e avisa que os restos a pagar não foram
baixados. Mas a média "R$ 1,79 bi com Bolsonaro ... e R$ 3,72 bi no Lula 3" é a única conta que o leitor vê. O valor que falta é
maior que qualquer média de mandato da função Cultura. Ele pesa de um lado ou do outro conforme o critério.
**Evidência.** `CV-transferencias-cultura.csv` e deflatores do FN (2020 1,331, 2022 1,144, 2023 1,093, 2024 1,043).
Pelo empenho, as transferências de Bolsonaro vão de 1,00 para 2,10 bi por ano, e o total sem FSA vai a 2,89 bi. O Lula 3, pelo
empenho (PNAB 3,0 em 2023, 0,011 em 2024 e 2,282 em 2025), vai a 3,07 bi sem FSA. **Os dois ficam parecidos.**
Pelo pagamento, se a LPG foi paga em 2023 (não verificado), o Lula 3 sem FSA vai a cerca de 4,04 e Bolsonaro fica em 1,79.
O liquidado do ano esconde também os restos a pagar da PNAB, 0,74 bi de 2023 e 0,52 bi de 2025, todos do Lula 3.
**Correção.** Pôr na tabela, ou numa frase, o total pelo empenho ao lado do total pelo liquidado. Dizer que a escolha do critério
decide se a distância entre Bolsonaro e Lula 3 é pequena (empenho) ou grande (pagamento, se a LPG saiu em 2023).

### V2. A MP 1.135/2022 é descrita em detalhe, e o 2024 do Lula 3 aparece só como número
**Problema.** O texto mostra que a MP de Bolsonaro trocou a obrigação por autorização. Na mesma frase em que aparece a "dotação de
R$ 0,01 bi em 2024", não diz que a Lei 14.399 mandava entregar R$ 3 bi por ano de 2023 a 2027, e que em 2024, sob o Lula 3, o
orçamento da ação foi de R$ 0,011 bi.
**Evidência.** `CV-atos.csv`, Lei 14.399, art. 6, redação original, "a cada ano ... R$ 3.000.000.000,00 ... no primeiro exercício
subsequente ... e nos 4 (quatro) anos seguintes". `fontes/siop_transferencias_cultura_2024.csv`, dotação 10.804.000, liquidado
692.683. A MP 1.135 perdeu a vigência, então em 2024 valia a redação original (inferência minha, não verificado se outra norma
mudou o prazo). A busca 1 achou uma MP 1.274/2024 que alterou a política, de novembro de 2024, conteúdo não verificado.
**Correção.** "Em 2024, quando a lei mandava entregar R$ 3 bi, a ação teve dotação de R$ 0,01 bi". Baixar a MP 1.274/2024 e tratá-la
com o mesmo detalhe da MP 1.135, ou dizer que ela existe e não foi lida.

### V3. A MP 1.135 é apresentada como medida da cultura, mas o mesmo ato adiou o Perse
**Problema.** O leitor lê a MP como gesto contra a cultura. O texto baixado mostra que ela fez o mesmo com o Perse, programa do setor
de eventos.
**Evidência.** `fontes/planalto_mpv1135.htm`, art. 3, "A Lei nº 14.148, de 3 de maio de 2021, passa a vigorar ... Fica a União
autorizada a destinar, no exercício de 2023, o valor global máximo de R$ 2.500.000.000,00 ... aos beneficiários do Perse".
**Correção.** "a MP 1.135, que fez o mesmo com o Perse, programa do setor de eventos, trocou a obrigação ...".

### V4. Escolha de pontos na admissibilidade
**Problema.** "34 dias em 2018, de 51 a 100 dias de 2019 a 2022 e 31 dias em 2025". O texto compara o melhor ano de Temer e o
melhor ano do Lula 3. 2016 e 2017 tiveram 53 e 52 dias, no nível de 2019 e 2020. 2023, primeiro ano do Lula 3, teve 59, mais que
2019 (54) e 2020 (51).
**Evidência.** `fontes/salic/grid_TempoMedio_Da_Admissibilidade_Ate_Publicacao.txt` e `CV-salic-por-ano.csv`.
**Correção.** Usar as médias da tabela (Temer 43, Bolsonaro 75, Lula 3 41) e dizer que 2016, 2017 e 2023 ficaram acima de 50 dias.
O pico de 2021 e 2022 (100 e 94) continua sendo o dado mais forte e não precisa da escolha.

### V5. LGBT comparado com 2016 a 2018 e não com Dilma
**Problema.** "2 projetos de 2019 a 2022, 5 de 2016 a 2018". Em Dilma foram 5 em cinco anos, e a parte foi a mesma de Bolsonaro.
**Evidência.** Dilma 5 de 33.466 (0,015%), Bolsonaro 2 de 13.791 (0,015%), Lula 2 0,01%. Teste binomial condicional (conta minha),
Bolsonaro contra 2016 a 2018, P(X ≤ 2 | 7) = 0,25. Contra Dilma, 0,67. Com contagens assim, a diferença não se separa do acaso.
**Correção.** "Com LGBT, queer ou drag, foram 5 projetos em Dilma, 5 de 2016 a 2018, 2 com Bolsonaro e 55 no Lula 3. Até 2022 a parte
fica entre 0,01% e 0,03% em todos os mandatos, e com números tão pequenos a diferença entre eles não se distingue do acaso".

### V6. O controle gospel não diz o que controla
**Problema.** O texto põe "gospel, usado como controle" e dá dois números, sem dizer o que o controle mostra. São 10 projetos com
Bolsonaro, então ele não detecta mudança pequena. Gospel também tem carga política e não é tema neutro.
**Evidência.** Gospel 0,09% em Dilma, 0,07% com Bolsonaro, 0,08% no Lula 3. Não subiu com Bolsonaro. No Lula 3 ficou parado
enquanto negra/afro (de 0,45% para 1,21%), indígena (de 0,08% para 0,28%) e LGBT subiram. Isso indica que a alta do Lula 3 é do tema e
não só do volume. Para 2019 a 2022 o controle não acrescenta nada.
**Correção.** Dizer o que ele mostra (sem alta com Bolsonaro, sem alta no Lula 3) e o limite (10 e 33 projetos). Melhor ainda, baixar
um termo neutro e frequente (por exemplo "carnaval", "festival" ou "orquestra") como controle de volume.

### V7. A parte de "Ministério e regras" cita só a Cultura entre os ministérios que saíram em 2019
**Problema.** A seção 3 e a seção 16 dizem que a redução de 2019 "tirou o da Cultura da lista". O mesmo ato tirou outros onze nomes.
Citar só a Cultura sugere que ela foi o alvo da redução.
**Evidência.** Comparação entre o art. 21 da Lei 13.502 e o art. 19 da MP 870 (`fontes/planalto_l13502.htm`, `planalto_mpv870.htm`).
Saíram da lista, por fusão, Cidades, Cultura, Desenvolvimento Social, Esporte, Fazenda, Indústria e Comércio, Integração Nacional,
Planejamento, Segurança Pública, Trabalho, Transportes. Cultura, Esporte e Desenvolvimento Social foram para a Cidadania.
**Correção.** "A MP 870 deixou 16, sem o da Cultura, que foi para a Cidadania com o Esporte e o Desenvolvimento Social. Trabalho,
Fazenda, Planejamento e Cidades também saíram da lista".

### V8. Seção 16 encadeia uma frase sobre fraude no INSS para sugerir o fim do MinC
**Problema.** A frase da p. 72 trata da MP Antifraudes. O dossiê pega a oração "logo após a redução dos ministérios" e liga a ela a
saída da Cultura em 2019. Cada passo é verdadeiro. A cadeia, posta no parágrafo de cultura, faz o leitor inferir o que o plano não
diz. É inferência por encadeamento, montada pelo próprio dossiê.
**Evidência.** `tse_proposta_pl_2026_2t.pdf`, p. 72, "a primeira medida do nosso governo, logo após a redução dos ministérios, foi a
MP Antifraudes (MP nº 871/2019)". p. 69, "corte de no mínimo 10 ministérios, a redução de cargos comissionados e de despesas
administrativas". O plano tem trecho de cultura (p. 41) e não diz nada sobre a estrutura dela.
**Correção.** Manter "o plano não cita o MinC" e "propõe cortar no mínimo 10 ministérios sem dizer quais (p. 69)". Tirar a citação
da p. 72 do parágrafo de cultura, ou dizer o assunto dela ("ao falar da MP Antifraudes, o plano lembra a redução de 2019"). Dizer
quantos ministérios saíram em 2019, não só a Cultura (V7).

### V9. Câmara agrupada de 2019 a 2025
**Problema.** "4,4 por ano de 2004 a 2018 e 13,4 de 2019 a 2025" põe a quebra em 2019. Separado, o Lula 3 tem média maior que a de
Bolsonaro. A Zona Franca só aparece para 2019 a 2025, sem a base anterior.
**Evidência.** `CV-atencao.csv`. Rouanet, Bolsonaro (15, 10, 24, 3) 13,0. Lula 3 (8, 20, 14) 14,0. 2015 a 2017 já tinham 10, 9 e 10.
Zona Franca, 7,7 por ano de 2004 a 2018 e 9,6 de 2019 a 2025.
**Correção.** Dar Bolsonaro e Lula 3 em separado e a Zona Franca nos dois períodos.

---

## 3. Excessos

### X1. "Ministério e regras" inclui a Portaria 1.576/2019 com "sem citar tema"
**Problema.** A portaria só entra porque a imprensa a ligou a temas do edital. O próprio LEIAME e o item "Cultura e governo." dos
Limites dizem que esse vínculo não está em documento baixado e fica fora. "sem citar tema" faz o leitor procurar o tema. O texto
afirma uma ausência para insinuar uma presença.
**Evidência.** `fontes/dou_portaria_1576_2019_mcidadania.html`, art. 1 e art. 2. O art. 2 manda revisar "os critérios e diretrizes
para a aplicação dos recursos do FSA" e "os critérios de apresentação de propostas", o que o texto não cita.
**Correção.** Baixar o edital de 13/03/2018 (documento primário do próprio FSA) e dizer quais categorias foram suspensas. Sem isso,
tirar "sem citar tema" e citar também o art. 2, ou tirar a portaria.

### X2. "A captação ... não caiu com Bolsonaro" e "sem queda na captação" (Essencial)
**Problema.** A comparação é contra Temer. Contra Dilma (2,48) e Lula 2 (2,57), a média de Bolsonaro (2,28) é menor. A captação
caiu 8% em relação a Dilma. A frase do Essencial não diz a base.
**Evidência.** `FN-por-mandato.csv`, `rouanet_captado_rs_bi_2025_ano`.
**Correção.** "sem queda na captação em relação a Temer (de 1,84 para 2,28 bi por ano), abaixo de Dilma (2,48)".

### X3. "os projetos novos da Lei Rouanet foram os menores de 2019 a 2022" (Essencial)
**Problema.** Vale para a média. Ano a ano, 2020 (4.684) passou 2016 (4.361) e quase igualou 2017 (4.976). A série do painel começa em
2009. O Essencial não diz que a queda começou em 2016, o que o dado mostra contra a leitura de ruptura em 2019.
**Correção.** "os projetos novos caíram em 2016 e tiveram a menor média de 2019 a 2022 na série do painel, desde 2009".

### X4. "O que um corte de ministério economiza se mede pelo que a estrutura custa" (seção 16)
**Problema.** A medida (pessoal ativo e administração da função) superestima a economia de extinguir um ministério, porque o
servidor estável continua pago em outro órgão e as autarquias continuam (conhecimento geral, não verificado). Ela subestima só se a
extinção vier com corte de programas, que não é estrutura. A conclusão "quase não gera economia" sai mais forte, não mais fraca,
então o sentido da conclusão está certo. O que falta é dizer que a medida é um teto.
Falta também o melhor dado do próprio pacote. A recriação do MinC em 2023 levou o custo de estrutura de 0,55 (média Bolsonaro)
para 0,70 (média Lula 3), abaixo de 2015 a 2018 (0,90). A diferença de cerca de 0,15 bi por ano é uma estimativa direta do custo
da camada de ministério, perto de 0,007% da despesa primária (conta minha com o deflator do pacote, ordem de grandeza).
**Evidência.** `CV-estrutura-cultura.csv`, 0,711, 0,666 e 0,726 em 2023 a 2025. A queda de 2015 para 2022 continua em 2022 (0,47), longe
da extinção, o que sugere também perda de quadro e não só extinção.
**Correção.** "Essa conta é um teto. Servidores estáveis e autarquias continuam. Quando o MinC foi recriado em 2023, o custo de estrutura
subiu de R$ 0,55 bi para R$ 0,70 bi por ano, e ficou abaixo dos R$ 0,90 bi de 2015 a 2018".

### X5. "Decolonial aparece em 4 projetos de 2009 a 2025"
**Problema.** Os quatro são de 2023 a 2025. O termo não estava em uso nos nomes antes. Ele não serve para testar nada sobre 2019 a 2022,
e a frase o põe na lista como se servisse.
**Evidência.** `CV-salic-por-ano.csv`, projetos_decolonial 1 em 2023, 2 em 2024 e 1 em 2025, zero antes.
**Correção.** "Decolonial aparece em 4 projetos, todos de 2023 a 2025, e não permite comparar mandatos", ou tirar.

### X6. "no máximo R$ 30,1 mi por ano somados os três temas"
**Problema.** O captado é do projeto pelo ano do Pronac, não do ano da captação. Está em R$ correntes, ao lado de valores reais. Soma
duas vezes o projeto que tem dois temas (exemplo, "AFRO QUEER", 2024, R$ 2,0 mi entra em LGBT e em negra). Os projetos de 2024 e 2025
ainda captam.
**Correção.** Dizer "pelo ano do projeto, em R$ correntes", tirar a dupla contagem e avisar que os anos recentes estão incompletos.

### X7. Atenção pública, escolha dos termos
**Problema.** "Fundo Partidário" é termo de baixa busca desde que o Fundo Eleitoral virou o assunto (conhecimento geral, não verificado).
"Zona Franca de Manaus" tem a média puxada por 2004 a 2006 (13,1, 11,6 e 8,4), anos de amostra pequena no Trends (não verificado). De
2011 a 2025 ela fica entre 2,0 e 3,7. O Trends compara frases exatas, e quem busca "Rouanet" sem "Lei" fica fora. A média "7,9 contra
4,3" depende desses recortes. O texto diz "busca não é opinião", e isso basta para a hipótese testada só até "o assunto aparece mais".
Ele não pode dizer "peso na opinião pública", e não diz. Pode dizer que a busca por Lei Rouanet é maior que a de três temas fiscais
maiores, nos termos escolhidos.
**Evidência.** `CV-atencao.csv`. Médias que refiz. Rouanet 7,87, Zona Franca 4,27, de 2004 a 2025.
**Correção.** Trocar "Fundo Partidário" por "Fundo Eleitoral" ou pôr os dois. Dar a média de 2011 a 2025 ao lado da de 2004 a 2025. Dizer
que 2023 (12,2) empatou com 2022, então a atenção não é só do período Bolsonaro.

### X8. Limites, "e por isso a Lei Paulo Gustavo não aparece como despesa de 2023" (só no script)
**Problema.** O dossiê não baixou os restos a pagar e não tem o ano do pagamento. O LEIAME diz só "paga como restos a pagar".
**Correção.** "não aparece como despesa em nenhum ano".

### X9. Contagem de ministérios
**Problema.** 23, 16 e 31 contam os incisos numerados do artigo. A contagem usual inclui órgãos com status de ministério e dá outros
números (conhecimento geral, não verificado). O "corte de no mínimo 10" do PL pode estar em outra base. Não é erro, mas o leitor
compara o 10 do plano com o 31 do dossiê.
**Correção.** Nos Limites, dizer como se contou e que o plano não diz a base.

---

## 4. O que o dado mostra contra a hipótese e o texto não diz

1. **A queda da função Cultura começou em 2015, no governo Dilma.** `FN-funcoes-uniao.csv`, real, 2,456 bi em 2014 e 1,359 em 2015
   (−45%). O FSA foi de 0,755 para zero no mesmo ano. A média "Dilma 2,49" esconde isso na seção 3 (a seção 7 diz "perto de R$ 1,4 bi
   de 2015 a 2018", mas não diz que a queda foi em 2015).
2. **O FSA ficou perto de zero de 2015 a 2022, não só com Bolsonaro.** 2015 0,0, 2016 0,0, 2017 0,1, 2018 0,001, 2019 a 2022 de 0 a 0,003.
   "menos de R$ 0,01 bi com Bolsonaro" é verdade e incompleto. É possível que parte disso seja de medida (execução por restos a pagar ou
   fora do GND 5), não verificado.
3. **A função Cultura sem FSA do Lula 3 (1,22) fica abaixo de Temer (1,36) e de 2015 a 2018.** O dado está na tabela, a prosa não diz.
4. **Com a Lei Aldir Blanc, Bolsonaro (1,79) passa Temer (1,41), 2016 (1,37), Lula 1 (1,19) e FHC (1,02).** O texto da seção 3 dá o
   número de Temer. O Essencial diz "a menor média com Bolsonaro, R$ 0,79 bi, ou R$ 1,79 bi com a Lei Aldir Blanc", e a frase deixa o
   leitor achar que o segundo número também é o menor.
5. **Pelo empenho, Bolsonaro e Lula 3 sem FSA ficam parecidos (2,89 e 3,07).** Ver V1. O governo Bolsonaro empenhou os R$ 3,862 bi da
   LPG em 2022, depois de vetá-la e de editar a MP 1.135.
6. **A CNIC aprovou mais valor no primeiro ano de Bolsonaro que nos dois de Temer.** `grid_Avaliacao_Cnic_Ano.txt`, R$ 2,858 bi em 2019,
   2,670 em 2017 e 2,457 em 2018, correntes.
7. **Os projetos com tema negro e indígena, quando viraram projeto com Bolsonaro, foram aprovados e captaram em taxa maior que nos outros
   mandatos.** Conta minha sobre os JSON de tema, parte com valor aprovado maior que zero e com captado maior que zero.
   Negro, afro, quilombola. Dilma 93% e 21%, Temer 97% e 32%, Bolsonaro 98% e 40%, Lula 3 100% e 17%.
   Indígena. Dilma 95% e 22%, Temer 100% e 62%, Bolsonaro 91% e 45%, Lula 3 98% e 20%.
   Os projetos do Lula 3 ainda captam, então a taxa deles vai subir. O dado não sustenta filtro nas etapas de aprovação e captação para
   esses temas de 2019 a 2022. Não diz nada sobre o que não chegou a virar projeto.
8. **A parte de projetos com tema negro foi maior com Bolsonaro (0,45%) que com Temer (0,37%) e 2016 (0,41%).** A queda contra Dilma
   (0,65%) é estatisticamente clara (binomial, p ≈ 0,005, conta minha), mas começou em 2016. Indígena, Bolsonaro igual a Temer (0,08%).
   LGBT, Bolsonaro igual a Dilma (V5). O que os temas mostram com força é a **alta do Lula 3**, não uma queda própria de 2019 a 2022.
9. **O valor real captado pelos projetos de tema negro foi o mesmo com Temer e Bolsonaro** (5,94 e 5,84 mi por ano, R$ de 2025, conta
   minha), abaixo de Dilma (7,10).
10. **Lula 3 manteve o teto de R$ 1 milhão por projeto de 2019 e pôs o cachê solo abaixo do de 2019** (R$ 25 mil contra R$ 45 mil).
    `CV-atos.csv`. O texto dá os números sem dizer que a regra de 2023 é mais restrita no cachê que a de 2019.
11. **A atenção à Lei Rouanet não é só do período Bolsonaro.** Trends 2016 12,7 e 2018 23,1 (antes do governo), 2023 12,2 (igual a 2022).
    Câmara, Lula 3 14,0 por ano contra 13,0 com Bolsonaro.
12. **Fora dos dados do pacote, não verificado.** A primeira extinção do MinC foi de Temer, em maio de 2016, revertida dias depois
    (MP 726 e MP 728/2016). O caso Queermuseu, fechamento da mostra em 2017, também é do governo Temer, e o projeto está no arquivo
    (Pronac de 2016, "Queermuseu - Cartografias da Diferença na Arte Brasileira", R$ 800 mil captados). Se o dossiê quer o fato,
    baixar as duas MPs do Planalto.

---

## 5. Conferido e certo

- Função Cultura sem FSA por mandato, refeita ano a ano de `FN-funcoes-uniao.csv`. Dilma 2,4946, Temer 1,361, Bolsonaro 0,7875, Lula 3
  1,2153. FSA Lula 3 1,0977. FHC 1,02, Lula 1 1,19, Lula 2 2,34 conferem.
- Transferências. Aldir Blanc 3,0 bi em 2020 (dotação = empenho = liquidado). LPG 3,862 empenhado e 0 liquidado em 2022. PNAB 2,257
  em 2023, dotação 0,011 em 2024, 1,761 em 2025. Batem com `fontes/siop_transferencias_cultura_*.csv`. Média das transferências Lula 3
  1,41 e Bolsonaro 1,00 conferem. "mais da metade" confere (1,00 de 1,79).
- Painel Salic, todos os números do texto contra os grids brutos. Projetos novos 6.693, 5.180 (5.180,5), 3.448, 2.645, 13.454. CNIC 6.724,
  2.019, 1.646 (1.645,5), 3.678. Admissibilidade 34, 51 a 100, 31. Captação real 1,84, 2,28, 2,60 em 2021, 3,06.
- Parcelas de tema, refeitas pela soma dos anos sobre a soma dos projetos novos. Negra 0,65, 0,37, 0,45, 1,21. Indígena 0,12, 0,08, 0,08,
  0,28. LGBT 2, 5 e 55 projetos, 0,01% a 0,14%. Gospel 0,07 e 0,08. Decolonial 4. Captado máximo 30,09 mi em 2023.
- A base de comparação (propostas transformadas em projeto, que recebem Pronac) é a mesma do numerador (Pronac pelo ano dos dois
  primeiros dígitos). Pronacs de 95 a 99 viram "2095" no script, mas ficam fora da janela 2009 a 2025, sem efeito.
- Os JSON de tema trazem só Pronac, nome, área, segmento, datas e valores. Não há coluna de proponente. Dado pessoal ausente, como
  prometido.
- Atos oficiais. Todos os trechos de `CV-atos.csv` estão literalmente nos HTML baixados (o `build_CV.py` faz `assert`, e conferi à mão
  IN 2/2019 art. 4 I d e art. 12, IN 1/2022 arts. 5 e 17, IN 1/2023 art. 7 § 1º e art. 14, Portaria 1.576 art. 1, MP 1.135 arts. 1 e 2,
  Lei 14.017 com § 2º vetado). Listas de ministérios 23, 16 e 31 conferem pela regra dos incisos numerados.
  Nota. O texto cita "IN MinC 1/2023, art. 4, par. 1" e o trecho está no art. 7, § 1º do HTML. Corrigir a referência no CSV.
- Teto e cachê. R$ 1 milhão, R$ 500 mil (tipicidade normal, com tetos de 4 e 6 milhões para outras tipicidades) e R$ 1 milhão. Cachê R$ 45
  mil, R$ 3 mil e R$ 25 mil. A comparação 2019 com 2022 é de projeto comum com projeto comum, as duas com exceções.
- Estrutura. 0,726 bi em 2025, 0,0303% e função 0,0595%. Médias 0,904 e 0,553, diferença 0,35. 0,017% da despesa primária de 2022.
- Trends. Médias 7,87, 4,27, 1,1 e 0,4. Pico 2018 23,08, depois 2016, 2022 e 2023. Câmara 4,4, 13,4, 9,6 e 1,6. Renúncia Rouanet 2026
  3,088 bi, Zona Franca 35,99 bi. Equalizações 2024 10,7.
- Seção 16. PL sem "Ministério da Cultura", "MinC" ou "Rouanet" no PDF inteiro. PT 5 ocorrências (3 de "Ministério da Cultura" e 2 de
  "MinC"). Citações das pp. 69 e 72 literais. O parágrafo anterior da seção 16 trata o trecho de cultura do PL (p. 41, "aperfeiçoaremos
  as leis de incentivo"), então o leitor sabe que o PL fala de cultura.
- Regra de voz. Nas partes auditadas do HTML e no item novo do script, nenhum dois-pontos, ponto-e-vírgula, travessão ou "não é X, é Y".
- Linguagem causal. As frases dizem "com Bolsonaro" e "no Lula 3", e todo gráfico leva "datam os valores e não atribuem a causa". A
  única frase com juízo implícito é "sem citar tema" (X1). "A captação, que depende de quem patrocina" é descrição do mecanismo,
  correta.
- O texto não afirma intenção em nenhum ponto. O excesso está na montagem (V8, X1), não em verbo.

---

## 6. Resolução do parecer de agro (`auditoria-agro-ambiente-v12-5.md`), contra o texto atual

| Item | Situação | Onde |
|---|---|---|
| E1 equalizações "dentro" da função | Resolvido | Seção 3, "estão, na maior parte, dentro dessa função ... não se somam nem se subtraem" |
| E2 inversões não são só empréstimo, GND 5 da Organização Agrária | Resolvido | "na maior parte empréstimos ... e também compra de estoques". Organização Agrária com inversões, Lula 2 maior |
| E3 5,7% do PL | Resolvido | Seção 16, "5,8% do texto" |
| E4 arredondamento de meio inteiro | Resolvido | 9.757, 8.361, 7.985, 7.189 no texto |
| V1 perímetro da cultura | Parcial | Perímetro único com FSA e transferências nomeados, e o Essencial de agro já não fala de cultura. O Total da tabela ainda soma o FSA (E2 acima), e a LPG fica fora dos dois lados (V1 acima) |
| V2 Essencial só com achados de um lado | Parcial | Cerrado parecido entrou. O pico de 2023 no Cerrado e a Gestão Ambiental do Lula 3 abaixo de FHC, Lula 2 e Dilma estão só na seção 3 |
| V3 checar uma frase de cada plano | Resolvido | Seção 16, PRODES para o PL e Fundo Clima 34,6 contra 15,6 para o PT |
| V4 "sem dizer o orçamento" só no PL | Resolvido | "Os dois prometem fortalecer a fiscalização ... Nenhum diz o orçamento" |
| V5 matriz de termos | Resolvido | "produtor rural, pequeno produtor" na linha (30/19). Desmatamento e queimadas (10/8) separado de fiscalização (2/8) |
| V6 peso dos capítulos do PT | Resolvido | "Sem os blocos de fome ..., ficam 9,7%" |
| V7 renúncia agro é cesta básica | Resolvido | "é a desoneração da cesta básica, como o próprio arquivo a rotula ... fica fora da leitura do agro". Ressalva, a Tabela 15 dava 76% a 90%, não 100% |
| X1 3.335 km² sem qualificador | Resolvido | "pelo dado de outubro de 2026, sujeito a revisão". O número saiu do Essencial |
| X2 "responde também a" | Resolvido | "responde a política federal e estadual, ... e o dado não separa esses efeitos" |
| X3 calendário de pagamento do OSU | Resolvido | "segue o juro e o calendário de pagamento, com R$ 19,3 bi em 2015 depois de R$ 2,8 bi em 2014". As médias por mandato continuam, com a ressalva |
| X4 "beneficia quem compra" | Resolvido | "reduz o imposto sobre os alimentos da cesta" |
| X5 perímetro no Essencial | Parcial | Cultura saiu do item. "também quando se somam os recursos hídricos e as inversões" está na seção 3, não no Essencial |
| X6 "todo o corte raso" | Resolvido | "mede o corte raso da vegetação nativa, legal ou ilegal, e não desconta a regeneração" |
| X7 Organização Agrária de Dilma puxada por 2013 | Parcial | O texto deixou de citar a média de Dilma. O pico de 2013 continua na média da tabela (9,1) sem nota |
| X8 Fundo Clima "emprestou" | Resolvido | "A União liberou ao Fundo Clima ... como empréstimo", e a seção 16 confronta com os 34,6 bi do PT |
| X9 "sem a subfunção Recursos Hídricos" | Resolvido | Texto da seção 3 |

Nota de versão. O item de agro dos Limites no HTML ("inclui a cesta básica e mudou de método") é anterior ao do script ("usam critérios
diferentes e não se somam"). A resolução acima vale para o script. O PDF publicado ainda não tem o texto novo dos Limites.

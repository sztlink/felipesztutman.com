# Auditoria independente da v11: choques fiscais (N2, Y2, S2) e conclusão C da seção 15

Auditor externo à construção. Data: 19/10/2026. Base auditada: commit 71519e5f (HTML, CSV e brutos como estão no repositório).
Nenhum arquivo do dossiê foi alterado. Tudo o que foi rodado está em cópias no scratchpad do auditor, fora do pacote
(`<pasta temporaria do auditor>/code/`: `variante.py`, `epoca*.py`,
`patch_mc.py`), com as saídas gravadas em pastas do mesmo scratchpad.

Classes: **ERRO** (número, fonte, classe ou registro errados), **FRÁGIL** (premissa ou leitura discutível, com a alternativa
testada e o resultado), **NOTA** (ajuste de redação ou de documentação). Cada achado traz a correção sugerida.

## Resumo

| id | classe | onde | achado | correção |
|---|---|---|---|---|
| E1 | ERRO | seção 15, "Choques fiscais", última frase | "as pioras sobem os juros mais do que as melhoras os reduzem" é falso nos dois horizontes: as melhoras também sobem o juro (+2,4 pb em 5 dias, +7,6 pb em 20 dias, mais que as pioras em 20). A "assimetria" mede a deriva comum das datas de evento, e não resiste ao placebo por época nem aos episódios | trocar pela frase de E1 ou retirar |
| E2 | ERRO | Y2-medidas.csv, M17b | `etapa_realizado = sim` com valor 0 "por definição (não medido)". A MP vigorou de junho a outubro de 2025 e a receita não foi medida | marcar "nao"; M17b sai das razões e da contagem de três etapas |
| E3 | ERRO | seção 15, "72%" | a mediana das melhoras junta um zero não medido (M17b), dois realizados não isolados (M02 limite superior, M17a revisão de projeção) e um isolado (M13, 102%). O número exato é 71%, e não 72% | não dar mediana; dar os valores e dizer que a única melhora com efeito isolado entregou 102% |
| E4 | ERRO | seção 15, Y2 | "19 medidas" são 19 linhas de 17 medidas; "11 medidas de consolidação" são 11 linhas de 10 medidas | corrigir as contagens |
| E5 | ERRO | seção 15, fecho do parágrafo Y2/S2 | "A para ... a aritmética" vem logo depois do Monte Carlo, que propaga o canal fiscal e o multiplicador. O parágrafo anterior classifica os números com canal como B e ilustrativos | classe B (ilustrativo) para o Monte Carlo; A só para a aritmética sem canal |
| E6 | ERRO | Anexo C e Anexo B | o brief manda "método no Anexo C", mas o Anexo C não tem uma linha sobre N2, Y2 ou o Monte Carlo. No Anexo B, Y2-medidas.csv cita [44] (revisão de literatura) e S-montecarlo.csv cita [29] (Focus) | escrever o método no Anexo C e corrigir as chamadas |
| E7 | ERRO | LEIAME N2 e excluidos.tsv | o LEIAME diz que o build leu o P5 "às 19h50", depois do commit (18:49) e do relógio desta auditoria (19:05). O motivo da linha pec287_emenda_aglutinativa diz que dez/2016 está "fora do período" | corrigir a hora; corrigir o motivo |
| F1 | FRÁGIL | seção 15 e LEIAME N2 §3 | a classe B vem só do binomial das passagens. Com placebo casado por trimestre o excesso cai de 14 para 11 passagens e ainda passa (p de 0,006 a 0,07, conforme o desenho), mas só no juro real (p = 0,025). Na implícita não passa (p = 0,17) | "sobretudo o juro real"; dizer que o protocolo deu B no limite de C |
| F2 | FRÁGIL | seção 15, razão RA/surpresa | "sinal contrário ao esperado" não resiste ao protocolo original (exclusão de 10 dias, mínimo de 100 observações): a razão fica com o sinal esperado (-7,1 e -6,6), também com intervalo que cruza o zero | "sem sinal definido e com intervalo que cruza o zero" |
| F3 | FRÁGIL | tabela e N2-resumo | os intervalos dos grupos e o binomial tratam as datas como independentes. A tabela mostra um intervalo que exclui o zero (votações, implícita) sem comentário no texto. Esse resultado e o dos anúncios no juro real resistem ao placebo por trimestre | comentar no texto como efeito do tipo de ato, não do conteúdo, e sem correção |
| F4 | FRÁGIL | inventário N2 | a regra não foi aplicada com o mesmo padrão de evidência: declarações de ministro ou líder valem para PEC 133, PEC 188 e LC 194, enquanto PEC 287 e Perse caem por "não localizado". A Lei 14.973 sai por efeito líquido ambíguo, mas o IR entra como "neutra" pelo bruto. O anúncio do IR de 18/03/2025 usa o número de 2024 (35 bi, neutra), e a EM do PL 1.087 (Y2, M16) dá +8,3 bi líquidos | dizer no texto que o inventário é incompleto; alinhar IR e Lei 14.973 |
| F5 | FRÁGIL | Y2, classificação | M13 (Lei 14.754) é "outra" e M17b é "consolidação" com motivação quase igual (compensar perda de receita). Com M13 como consolidação, "nenhuma tem as três etapas" fica falso. A Receita publica efeito isolado de M13 (fatores não recorrentes), o que contradiz a explicação do texto. M09 "eleitoral" é leitura do construtor: o motivo declarado é a alta dos combustíveis | regra única de classificação; "Receita e IFI em geral não publicam" |
| F6 | FRÁGIL | seção 15, "115%" | com n = 6 e conceitos diferentes (M05 compara a proposta do Executivo com o benefício triplicado pelo Congresso, M10 compara a dotação proposta com a dedução legal), a mediana não descreve "custo" | dar n e faixa: 6 pares, de 0,83 a 8,1 |
| F7 | FRÁGIL | seção 15, "em nenhum sorteio ela para de subir" | só vale nas faixas estreitas e com a macro do Focus fixa. Com faixas um pouco mais largas, de 2% a 5% dos sorteios dos ajustes 4 e 4b param de subir; somando crescimento de ±1 ponto e Selic de ±1 ponto, de 8% a 9%. Com a grade do PLDO (cenário 6), a dívida cai em 2030 | "em todos os sorteios nas faixas declaradas, com Selic, PIB e IPCA do Focus fixos" |
| F8 | FRÁGIL | build_S.py, faixas | o deflator de ±1 ponto não tem fonte (o cenário 2b usa só +1). A âncora é interpolação entre dois meses. As formas (triangular, uniforme) e a independência entre parâmetros não são justificadas | declarar como escolha do autor, ou ancorar o deflator na série histórica |
| N1 a N12 | NOTA | vários | ver seção 6 | |

**O que resistiu.**
- N2 e S reproduzem byte a byte, e a semente reproduz.
- Os dois desvios declarados não mudam a classe (B nas quatro combinações).
- Nenhum par evento-indicador sobrevive à correção em nenhuma versão.
- O teste de direção é nulo em todas as versões.
- As 10 datas e os 10 impactos sorteados conferem com as fontes.
- Os números de Y2 conferem nas 5 medidas checadas.
- Não há dupla contagem entre o canal fiscal e o choque de taxas no Monte Carlo.
- A conclusão C ("anúncios e aprovações não movem os juros no sentido do conteúdo") se sustenta.

## 1. Reprodução

- `build_N2.py`, rodado com `N2_SAIDA_TESTE` apontando para o scratchpad: os quatro CSV N2, `excluidos.tsv` e `placebo_datas.csv`
  saem com o mesmo md5 do repositório. O `eventos_P5.tsv` tem mtime de 18:52, depois do build (18:48), mas a rodada desta
  auditoria leu o arquivo atual e deu o mesmo md5: a reescrita não mudou o conteúdo.
- `build_S.py`, rodado num espelho do dossiê em que os S-*.csv são arquivos novos e não links: os 5 CSV de S, entre eles o
  S-montecarlo.csv, saem idênticos. A semente 20261019 (`random.Random`) reproduz. Com outra semente, o ajuste pela receita
  dá p5, p50 e p95 de 91,8, 95,4 e 99,1, a mesma faixa.
- `build_Y2.py` não foi rodado, porque grava direto em Y2-medidas.csv. As medianas foram refeitas a partir do CSV.

## 2. Protocolo

### 2.1 Os dois desvios (`variante.py`, que muda só EXCL e MIN_OBS e chama o `main()` do build)

| versão | eventos com RA (datas) | placebos válidos | passagens P95, família | p binomial | menor q BH | anúncio, juro real, 1 dia | razão agregada, juro real e implícita | classe |
|---|---|---|---|---|---|---|---|---|
| publicada (5 dias, 60 obs.) | 174 | 993 | 33 de 348 | 0,0004 | 0,35 | +3,4 [0,0; 6,2] | +1,4 e +15,1 | B |
| protocolo (10 dias, 100 obs.) | 81 | 523 | 25 de 162 | < 0,0001 | 0,15 | +6,9 [2,8; 11,1] | **-7,1 e -6,6** | B |
| 10 dias, 60 obs. | 135 | 869 | 31 de 270 | < 0,0001 | 0,22 | +4,0 [1,1; 7,4] | +2,5 e +14,6 | B |
| 5 dias, 100 obs. | 143 | 834 | 29 de 286 | 0,0003 | 0,34 | +4,2 [-0,2; 7,1] | -0,6 e +13,5 | B |

- Os desvios não mudam a conclusão: B em todas, nenhum sobrevivente da correção, direção nula, razão com intervalo que cruza o zero.
- O que muda é o **sinal da razão**, ponto de F2.
- O LEIAME diz que, quando o desvio foi decidido, "do resultado só se via a linha de diagnóstico da classe". Como a classe é B nas
  duas versões, essa espiada não decidiu nada. Fica a falha de processo (N1).

### 2.2 Regra de inclusão: 10 eventos sorteados (semente 20261020)

Todos conferem: data no arquivo, valor no trecho, ano de referência e conta do % do PIB.

| evento | data na fonte | impacto na fonte | observação |
|---|---|---|---|
| Senado aprova PL 1.087 (IR), 05/11/2025 | Agência Senado 05/11 ("nesta quarta-feira (5)") | 35 bi, Haddad em 28/11/2024 | número de 2024 para o texto de 2025 (F4) |
| Câmara aprova MP 1.076 (Auxílio 400), 27/04/2022 | Agência Brasil, quarta (27) | 41 bi/ano, Agência Senado | ok |
| MP 1.303, 11/06/2025 | Agência Câmara, quarta (11), edição extra | 20,9 + 10,7 em 2026 | ok, ambígua bem marcada |
| Lei 14.784, 27/12/2023 | Planalto | 12 bi em 2024, EM da MP 1.202 | ok, 0,102% (rente ao corte) |
| MP 936, 01/04/2020 | Planalto | 51,2 bi, EM | ok |
| Câmara vota PLP 257, 20/12/2016 | dadosabertos, 16:32 | 18,9 bi em 2017, EM par. 21 | ok |
| Câmara vota PLP 18 (LC 194), 14/06/2022 | dadosabertos, 20:28 | 65 bi, relator (Rádio Senado) | ok, desvio 4 declarado |
| Lei 13.149, 21/07/2015 | Planalto | 6,458 bi/ano, EM da MP 670 | ok, 0,103% (rente ao corte) |
| Câmara aprova PEC 15/2022, 1º turno, 12/07/2022 | dadosabertos, 20:17 | 41,25 bi, Agência Senado | ok |
| MP 690, 31/08/2015 | Planalto | 6,7 + 0,923 + 0,62 bi, EM | ok |

### 2.3 Regra de exclusão: 10 excluídos sorteados (semente 7)

- **Oito procedem:** PLP 37/2015 (financeiro), LOA 2016, EC 108 Fundeb (primeiro ano cheio abaixo do corte), Relp
  (parcelamento), LC 195 (cerca de 3,9 bi), EC 136 na versão de 2024, PDL do IOF (não é ato da regra 1.1 c) e Perse PL 1.026
  (o limite de 15 bi em 3 anos também ficaria abaixo do corte).
- **Dois procedem só na forma:** PLP 25/2007 Simples e PEC 287/2016. O motivo é "estimativa não baixada" ou "não localizada".
  A EM da PEC 287 de fato não quantifica, conferido em `camara_inteiroteor_1514975.pdf`. Mas a busca por números da Fazenda e da
  Previdência não foi feita com o mesmo empenho que, em outros casos, aceitou declaração de ministro ou líder (F4).
- **Fora do sorteio, duas linhas com problema:**
  - pec287_emenda_aglutinativa: o motivo diz que dez/2016 está fora do período, e não está (E7). A linha também foi preenchida
    "de memória".
  - desoneracao_lei14973: o critério diverge do usado para o IR (F4).

### 2.4 Uniformidade

- As lacunas declaradas são reais: bloqueio da Câmara, sem varredura de PEC e PLP em P2 e P4, e 2017 e 2018 com 8 eventos.
- O texto do relatório não menciona nenhuma delas e diz "com protocolo fixado antes dos resultados", sem os desvios. Ver F4 e N12.

## 3. Inferência

### 3.1 Placebo casado por época (`epoca.py`, `epoca2.py`, `epoca4.py`)

O RA foi calculado em todos os 1.759 dias candidatos, que estão a mais de 5 pregões de qualquer evento. O limiar é o P95 do
placebo publicado (19,1 pb no juro real, 21,7 pb na implícita). Observado: 33 passagens na família principal.

| nula | média de passagens | P95 da nula | p (>= 33) |
|---|---|---|---|
| sorteio uniforme 2015 a 2026, mesmo n (o do protocolo) | 18,6 | 26 | 0,0015 |
| cada evento trocado por um dia sem evento do mesmo trimestre | 22,3 | 31 | 0,030 |
| idem, ±30 pregões em torno do evento | 20,2 | 28 | 0,006 |
| episódios (eventos a até 5 pregões) deslocados juntos dentro do trimestre | 21,3 | 29 | 0,008 |
| p local de cada evento no próprio trimestre (pool ≥ 10): 21 de 294 com p ≤ 0,05 | 14,7 esperados | | 0,066 (binomial) |
| só juro real, trimestre | 11,7 (obs. 19) | | 0,025 |
| só implícita, trimestre | 10,8 (obs. 14) | | 0,17 |

- **Leitura.** A época explica cerca de um terço do excesso. "Se mexem mais em datas fiscais" sobrevive, mais fraco, e só no
  juro real.
- **Concentração.** As passagens se concentram em mar/2020, out e nov de 2021 e dez/2024. Em 2024 foram 8 em 28 testes,
  contra 2,9% dos dias placebo desse ano acima do limiar.
- **Datas coladas.** O desenho por episódios responde à pergunta e não derruba o resultado.

**Efeito por tipo de ato, com nula por trimestre:**
- Anúncios no juro real: +3,4 pb em 1 dia (nula com média -0,4, p = 0,004) e +10,6 pb em 5 dias (p < 0,001).
- Votações na implícita: -3,7 pb em 1 dia (p = 0,001) e -5,5 pb em 5 dias (p < 0,001).
- Esses efeitos do tipo de ato são mais robustos que a contagem de passagens. Não dependem do conteúdo, o que reforça a conclusão C.

### 3.2 Assimetria em 5 e 20 dias (`epoca3.py`)

| juro real | piora | melhora | todos | assimetria (P+M) | p placebo publicado | p nula por trimestre | p por episódios (eventos a até h pregões) | direção (P−M) | p direção, trimestre |
|---|---|---|---|---|---|---|---|---|---|
| 5 dias | +5,8 | +2,4 | +4,1 | +8,2 | 0,006 | 0,070 (nula centrada em +2,5) | 0,15 (60 e 49 episódios) | +3,4 | 0,14 |
| 20 dias | +5,3 | +7,6 | +5,2 | +12,9 | 0,009 | 0,24 (nula centrada em +7,9) | 0,46 (27 e 23 episódios) | -2,3 | sinal oposto |

- A estatística P+M é praticamente o dobro da média de todas as datas. Mede a deriva de alta do juro real depois de datas fiscais,
  não uma resposta assimétrica ao conteúdo.
- Na implícita, a "assimetria" tem sinal oposto (-2,9 e -6,3). No prefixado, não passa.
- **Correção para testes múltiplos** (p do placebo publicado):
  - Holm em 8 testes (2 indicadores e 4 janelas): 5 dias com 0,048, no limite; 20 dias com 0,063.
  - Holm em 16 testes (4 indicadores): 0,096, não passa.
  - BH em 16 testes: q = 0,072 para os dois.
- **Janelas sobrepostas.** Em 20 dias, 105 pioras e 74 melhoras viram 27 e 23 episódios independentes.
- Não resiste. Ver E1.

### 3.3 Outros pontos de método
- O p dos grupos é bilateral em torno de zero, mas a faixa nula não é centrada. Na versão do protocolo, isso dá "fora da faixa"
  com p = 0,235 ("todos", 5 dias) (N4).
- Os placebos ficam a mais de 5 pregões de um evento, mas as janelas de 20 e 60 dias deles contêm eventos. As janelas de
  estimação de h ≥ 5 também se sobrepõem a eventos (N3).

## 4. Y2

### 4.1 Cinco medidas conferidas na fonte

| id | anunciado | aprovado | realizado | motivação |
|---|---|---|---|---|
| M02 | 12.841,48 mi/ano desde 2016 (nota MF, item 4) ✓ | 400 mi em 2015 (MPOG, slide 7) ✓ | queda da renúncia de 24.149 para 14.530 (RFB, p. 35) ✓, não isolado | EM 41/2015 par. 2 ✓ |
| M09 | 38,75 bi (relatório FBC) ✓ | 41.250 (IFI, Tabela 10) ✓ | 36.357,1 (IFI, Tabela 10) ✓ | trecho ✓, mas é sobre a lei eleitoral; motivo declarado: combustíveis (F5) |
| M12 | 35.348 (RARDP 1º bim 2024, p. 42) ✓ | 25.862 (idem) ✓ | sem número ✓ | EM 109/2023 ✓ |
| M13 | 13,28 + 7,05 (EM 104 e 105) ✓ | 13.280 + 5.639 (RARDP p. 42) ✓ | 13.000 + 7.670 (RFB dez/2024, fatores não recorrentes) ✓ | EM 104 par. 39 ✓ (parágrafo de compensação da LDO, F5) |
| M17b | 10,55 bi em 2025 (soma de apostas, CSLL e compensação na tabela da EMI 41, item 44) ✓ | 0, caducou ✓ | **0 "por definição (não medido)" marcado como etapa "sim"** (E2) | EMI 41 item 45 ✓ |

Na tabela da EMI 41, as linhas têm três valores para quatro colunas de ano. A leitura de 2025 (sem TVM e sem JCP) bate com o
total de 2026 (20,87), mas é interpretação (N8).

### 4.2 "Nenhuma tem as três etapas com efeito isolado em fonte oficial"
- Pelas linhas, é verdadeira: as duas de consolidação com três etapas são M11 (regra) e M17b.
- Mas M17b não tem realizado medido (E2), e M13 tem as três etapas isoladas, com classificação "outra" que destoa da de M17b (F5).
- A segunda metade da frase ("porque Receita, Tesouro e IFI não publicam o efeito isolado") é contradita pelo próprio realizado
  de M13, que vem da tabela de fatores da RFB.

### 4.3 Medianas de 72% e 115%
- **Melhoras.** Valores de 0, 0,68, 0,75 e 1,02. A mediana exata é 0,713, portanto 71%, e não 72%. Sem M17b, 0,75.
- **Pioras.** Valores de 0,83, 0,94, 1,00, 1,30, 1,38 e 8,1, mediana de 1,15. Sem M05 e M10, também 1,15.
- Com 4 e 6 pares, a palavra "mediana" sugere um parâmetro. O LEIAME diz o certo ("descrevem o inventário, não são parâmetro"),
  e o texto do relatório não. Ver E3 e F6.

## 5. Monte Carlo

- **Faixas.**
  - Canal triangular de 11, 26 e 47 pb: frente Y, Y05. Justificada.
  - Multiplicador uniforme de 0 a 1,2: LEIAME Y. Justificada.
  - Deflator uniforme de ±1: sem fonte (F8).
  - Âncora: interpolação entre set/2026 (14,24 e 7,55) e out/2026 parcial (13,05 e 6,95). É a sensibilidade da v10 virada
    distribuição. Aceitável se declarada.
- **Dupla contagem.** Não há.
  - O sorteio roda com ds = 0 e ds_m = 0, sem as taxas 1,5 ponto menores.
  - O canal entra uma vez, em `dm_fun`, sobre a diferença entre PLDO (consolidado) e Focus, mais as medidas extras.
  - A âncora é nível de mercado, não canal.
  - O multiplicador mexe só no crescimento e incide só sobre as medidas extras.
  - O canal é aplicado com o mesmo valor em pb ao prefixado e à taxa real da NTN-B: premissa já declarada na v10, não dupla contagem.
- **Semente.** Reproduz (seção 1).
- **"Em nenhum sorteio ela para de subir"** (`patch_mc.py`, mesma máquina de cenários, só as faixas mudam):

| variante | ajuste pela receita: p5, p50, p95 | fração subindo de 2029 para 2030, cenários 2, 4 e 4b |
|---|---|---|
| faixas publicadas | 91,8; 95,5; 99,1 | 1,000; 1,000; 1,000 |
| canal 0-26-70, multiplicador 0-1,5, deflator ±2, âncora ±0,5 | 88,5; 95,9; 103,1 | 1,000; 0,981; 0,952 |
| publicadas mais crescimento real ±1 ponto/ano | 90,0; 95,6; 101,2 | 1,000; 1,000; 0,990 |
| publicadas mais Selic ±1 ponto | 91,2; 95,5; 99,7 | 1,000; 1,000; 1,000 |
| publicadas mais primário ±0,5 ponto | 91,0; 95,3; 99,9 | 1,000; 1,000; 1,000 |
| largas, crescimento e Selic juntos | 87,2; 95,9; 104,8 | 0,999; 0,922; 0,909 |

Com a grade macro do PLDO (cenário 6 da seção 14, mesmo primário), a dívida vai de 86,96 em 2029 para 86,84 em 2030. A frase é
robusta às faixas publicadas e à semente, e frágil a faixas um pouco mais largas e à macro. Ver F7.

## 6. Achados com correção

### ERRO

**E1. Assimetria em 5 e 20 dias.**
- Frase errada: "Nas janelas de 5 e 20 dias, as pioras sobem os juros mais do que as melhoras os reduzem".
- O que os números mostram (N2-resumo, juro real):
  - As melhoras sobem o juro: +2,43 em 5 dias e +7,58 em 20 dias, mais que as pioras (+5,31) em 20.
  - A "assimetria" é a deriva comum (todos: +4,08 e +5,16).
  - A direção (piora menos melhora) não é significativa: +3,35 com p = 0,23, e -2,26.
  - Na implícita, o sinal é o oposto.
  - Não resiste à nula por trimestre (p = 0,07 e 0,24), aos episódios (0,15 e 0,46) nem a Holm em 16 testes.
- Correção sugerida: "Em 5 e 20 dias, o juro real sobe depois das datas fiscais, de melhora e de piora (em média +4 a +5 pb), em
  parte por causa da época. A diferença entre piora e melhora não se distingue de zero."
- Fazer a mesma correção no LEIAME N2 §3 ("A assimetria dá +8,2 pb no juro real").

**E2. M17b, realizado.**
- `etapa_realizado` passa a "nao", `etapas_medidas` passa a 2, e a razão realizado/anunciado fica vazia.
- Contagens a corrigir:
  - três etapas: 8 linhas, e não 9;
  - consolidação com três etapas: só M11;
  - melhoras comparáveis: 3.
- Corrigir o LEIAME Y2 §1 e §2.

**E3. "72%".**
- Trocar por: "Das melhoras, só uma tem efeito isolado medido (a tributação de fundos e offshores, 102% do anunciado). As outras
  duas com número têm só revisão de projeção ou limite superior (68% e 75%)."
- Se ficar a mediana, é 71% e precisa dizer n = 3.

**E4. Contagens.**
- "O inventário de 17 medidas (19 linhas)".
- "das 10 medidas de consolidação (11 linhas)".

**E5. Classe do Monte Carlo.**
- "Classe C para um efeito causal...; A para o inventário e para a aritmética da dívida sem canal; B (ilustrativo) para a
  distribuição do Monte Carlo, que herda o canal e o multiplicador."

**E6. Anexo C.**
- Incluir, em um parágrafo cada:
  - N2: regra de inventário, indicadores, janela, retorno anormal, placebo, correção, regra de parada e os dois desvios;
  - Y2: critério de etapa e de motivação;
  - S2: faixas, formas, independência e semente.
- Corrigir no Anexo B a fonte de Y2-medidas.csv (Y2/LEIAME e downloads, não [44]) e de S-montecarlo.csv.
- Citar as fontes do inventário (Câmara, Senado, Planalto, Fazenda).

**E7. Registro.**
- LEIAME N2, desvio 7: "19h50" não pode estar certo, porque o commit é de 18:49. Corrigir a hora.
- excluidos_P2.tsv, linha pec287_emenda_aglutinativa: retirar "fora do período" (dez/2016 está dentro) e marcar a data como não
  conferida.

### FRÁGIL

**F1. Classe B e "se mexem mais".**
- O resultado se apoia num binomial que supõe independência.
- O placebo casado por trimestre mantém o excesso, menor (33 contra 22 esperados, p = 0,03), e só no juro real (p = 0,025 contra
  0,17 na implícita).
- Texto sugerido: "Na janela de um dia, o juro real de 10 anos se mexe mais em datas fiscais do que por acaso (33 de 348 testes
  passam do percentil 95, contra cerca de 22 esperados mesmo casando a época). A inflação implícita não se distingue."
- Dizer que o protocolo dá B, no limite de C, e que o "C" do fecho se refere ao efeito do conteúdo.

**F2. Sinal da razão.**
- Trocar "tem sinal contrário ao esperado e intervalo que cruza o zero" por "tem intervalo que cruza o zero, e o sinal muda
  conforme a exclusão em torno dos eventos".

**F3. Intervalos dos grupos.**
- Dizer na legenda da tabela que os intervalos supõem datas independentes.
- Comentar votações e implícita (-3,7 [-5,7; -1,1]) e anúncios e juro real como efeitos do tipo de ato, sem correção para testes
  múltiplos. A nula por trimestre os mantém (p = 0,001 e 0,004).
- Opcional: substituir a nula iid por sorteio de episódios.

**F4. Inventário.**
- Acrescentar ao parágrafo: "inventário incompleto (Câmara inacessível na coleta; votações e envios faltantes listados no LEIAME)".
- Recodificar o anúncio do IR de 18/03/2025 pela EM do PL 1.087 (renúncia de 25,84 e compensação de 34,12, melhora de 8,28 bi;
  abaixo do corte de 0,1% do PIB pelo líquido).
- Decidir a Lei 14.973 pelo mesmo critério do IR.
- Para PEC 287 e Perse, procurar a estimativa da Fazenda e da Previdência com o mesmo empenho dado a PEC 133, PEC 188 e LC 194.
  Se não houver, dizer que o padrão de evidência variou.

**F5. Classificação Y2.**
- Fixar uma regra: compensação de renúncia é consolidação ou "outra", para M13 e M17b igualmente.
- Se M13 for consolidação, a frase do relatório passa a "uma das medidas de consolidação tem as três etapas isoladas".
- Trocar "não publicam" por "em geral não publicam (a Receita isola só alguns fatores não recorrentes)".
- M09: usar a motivação declarada (resposta à alta dos combustíveis) e anotar a leitura eleitoral à parte.

**F6. "115%".**
- "Nas pioras, 6 pares de 0,83 a 8,1 vezes o anunciado (o extremo é o auxílio de 2020, que o Congresso triplicou)."

**F7. Monte Carlo.**
- Texto sugerido: "em todos os sorteios, nas faixas declaradas e com Selic, IPCA e PIB do Focus, a dívida ainda sobe em 2030.
  Com faixas um pouco mais largas ou crescimento incerto em 1 ponto, de 1% a 9% dos sorteios estabilizam; com a macro do PLDO,
  ela para de subir."

**F8. Faixas.**
- Declarar no Anexo C que o deflator de ±1, as formas e a independência são escolhas do autor.
- Ou derivar o deflator do desvio histórico entre deflator e IPCA (frente J ou IBGE).

### NOTA

- **N1.** O §1 do LEIAME N2 (17:45) e os desvios não têm commit anterior aos resultados. Só o brief tem (17:40). Daqui em diante,
  commitar o detalhamento operacional antes de rodar, para o pré-registro ser verificável.
- **N2.** Reprodução N2 e S byte a byte. Semente ok.
- **N3.** Placebos de 20 e 60 dias e janelas de estimação de h ≥ 5 contêm eventos. Declarar nas limitações.
- **N4.** `p_placebo` dos grupos é bilateral em torno de zero com nula não centrada. Usar p centrado na média da nula, ou só a
  regra da faixa.
- **N5.** O teste de direção em 1 dia exclui diferenças acima de cerca de 3 pb (IC de -3,1 a 3,2 no juro real). Dá para dizer que
  um efeito médio do conteúdo, se existe, é pequeno, e não só "não mostra".
- **N6.** Os 10 eventos sorteados conferem. Duas linhas usam número de outra etapa (IR 2025 com o anúncio de 2024; MP 1.303 com a
  Agência Senado de outubro).
- **N7.** Dois excluídos (PLP 25/2007 e PEC 287) procedem só por "não baixado/não localizado". Distinguir na coluna `motivo` "não
  existe" de "não achado".
- **N8.** M17b, anunciado de 2025: a leitura da tabela da EMI 41 é plausível, mas o alinhamento das colunas é ambíguo. Anotar.
- **N9.** A chamada [29] na surpresa do Focus aponta para o Relatório de 09/10/2026, mas a série usada é a histórica do Olinda
  (frente X). Ajustar a nota.
- **N10.** O cálculo de poder de Y2 é otimista: escala por país-ano, não pelo número de choques, que seriam de 3 a 4. A conclusão de
  não estimar fica mais forte.
- **N11.** Desvio 7 do LEIAME N2: o P5 foi regravado às 18:52 sem mudar o resultado. Fechar o desvio ("relatório do P5 conferido;
  sem linhas novas") ou rodar de novo quando chegar.
- **N12.** "Com protocolo fixado antes dos resultados" pede o complemento "com dois desvios declarados, que não mudam a classe".

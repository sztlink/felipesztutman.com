# Separatas temáticas do volume 1. Cada uma é um anexo da Parte II impresso à parte, recortado do HTML final do volume
# (gastos-publicos-brasil.html), sem texto próprio além da capa. As notas mantêm a numeração do volume e a base de dados é a
# mesma (gastos-publicos-brasil-dados.zip). Decisão do autor de 27/10/2026, a partir da 15ª leitura crítica (v12.6), que
# propôs o núcleo fiscal como relatório principal e anexos temáticos independentes para agro e meio ambiente, cultura,
# educação, saúde e programas eleitorais.
# Uso: cd /tmp && python3 -I <pacote>/relatorio/monta_tematicos.py   (monta_relatorio.py chama no fim)
import os, re, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from estilo import imprime_pdf

SEPARATAS = [('T1', 'cultura'), ('T2', 'agro-e-meio-ambiente'), ('T4', 'educacao-e-saude'), ('T5', 'propostas-2027-2030')]

def roda():
  h = open(os.path.join(AQUI, 'gastos-publicos-brasil.html'), encoding='utf-8').read()
  cab = h[:h.find('</head>')]
  fontes = dict(re.findall(r'<li id=f-(\d+)>(.*?)</li>', h[h.find('<h2 id=fontes>'):], flags=re.S))
  edicao = re.search(r'<div class=edicao>(.*?)</div>', h, flags=re.S).group(1)
  os.makedirs(os.path.join(AQUI, 'tematicos'), exist_ok=True)
  for anx, nome in SEPARATAS:
    ini = h.find(f'<h2 id=anx-{anx}>')
    fins = [i for i in (h.find('<h2 id=anx-', ini + 10), h.find('<h1 class="parte', ini + 10)) if i > 0]
    corpo = h[ini:min(fins)]
    titulo = re.sub(r'<[^>]+>', '', re.search(r'<h2[^>]*>(.*?)</h2>', corpo, flags=re.S).group(1)).strip()
    ids = set(re.findall(r'\bid=["\']?([\w-]+)', corpo))
    usadas = sorted({int(n) for n in re.findall(r'href="#f-(\d+)"', corpo)})
    ids |= {f'f-{n}' for n in usadas}
    # remissão a parte do volume que não está na separata vira texto, sem link
    corpo = re.sub(r'<a href="#([\w-]+)">(.*?)</a>', lambda m: m.group(0) if m.group(1) in ids else m.group(2), corpo, flags=re.S)
    notas = ''.join(f'<li value={n} id=f-{n}>{fontes[str(n)]}</li>' for n in usadas)
    rodape = f'<style>@page {{ @bottom-left {{ content: "Separata {anx} · Gastos públicos do Brasil · volume 1"; }} }}</style>'
    capa = (f'<h1>{titulo.split(". ", 1)[1] if ". " in titulo else titulo}</h1>'
            f'<div class=edicao>Separata do anexo {anx} · {edicao}</div>'
            f'<div class=sub>Este texto é o anexo {anx} do volume Gastos públicos do Brasil, impresso à parte. As notas mantêm a '
            f'numeração do volume, e as remissões a outras seções ficam sem link. Os dados e os scripts estão no pacote do volume, '
            f'gastos-publicos-brasil-dados.zip.</div>')
    doc = f'{cab}{rodape}</head><body>{capa}{corpo}<h2 id=fontes>Fontes</h2><ol class=f>{notas}</ol></body></html>'
    tmp = os.path.join(AQUI, f'_separata-{anx}.html')
    open(tmp, 'w', encoding='utf-8').write(doc)
    pdf = os.path.join(AQUI, 'tematicos', f'separata-{anx}-{nome}.pdf')
    imprime_pdf(tmp, pdf)
    os.remove(tmp)
    print(pdf)

if __name__ == '__main__':
  roda()

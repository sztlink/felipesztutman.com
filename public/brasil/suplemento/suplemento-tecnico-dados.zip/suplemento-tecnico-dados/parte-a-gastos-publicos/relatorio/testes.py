#!/usr/bin/env python3
# Testes de consistencia do dossie: identidades contabeis, perimetros, simulador, convencoes editoriais.
# Uso: python3 -P relatorio/testes.py  (depois de gerar os CSV e o relatorio). Sai com 1 se algum teste falhar.
import csv, glob, os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
le = lambda f: list(csv.DictReader(open(os.path.join(RAIZ, f), newline='', encoding='utf-8')))
falhas = []
def teste(nome, ok, det=''):
  print('ok  ' if ok else 'FALHA', nome, det if not ok else '')
  if not ok: falhas.append(nome)

# 1. Simulador: d_t = d_{t-1} (1 + i) / (1 + g) - p, em todos os cenarios (erro de arredondamento ate 0,02 ponto)
SC = le('S-cenarios-divida.csv'); d0 = float(dict(x.split('=') for x in SC[0]['nota'].split('; ') if '=' in x)['d_2025'])
erro = 0.0
for c in dict.fromkeys(r['cenario'] for r in SC):
  d = d0
  for r in sorted((r for r in SC if r['cenario'] == c), key=lambda r: r['ano']):
    i, g, p = float(r['juro_implicito']) / 100, float(r['cresc_nominal']) / 100, float(r['primario_pct_pib'])
    dn = d * (1 + i) / (1 + g) - p; erro = max(erro, abs(dn - float(r['divida_pct_pib']))); d = float(r['divida_pct_pib'])
teste('identidade da divida no simulador', erro < 0.02, f'erro maximo {erro:.3f}')
# 2. Sensibilidade: economia cresce com a reducao e curva >= selic >= premio
SS = le('S-sensibilidade-juros.csv')
eco = lambda t, x: float(next(r['economia_acum_2027_2030_rs_bi'] for r in SS if r['choque'] == t and float(r['reducao_pp']) == x))
xs = [0.5, 1.0, 1.5, 2.0, 3.0]
teste('sensibilidade monotona', all(eco(t, a) < eco(t, b) for t in ('selic', 'curva', 'premio') for a, b in zip(xs, xs[1:])))
teste('curva >= selic >= premio', all(eco('curva', x) >= eco('selic', x) >= eco('premio', x) for x in xs))
# 3. Canal fiscal: efeito so nas taxas de mercado e dentro da faixa baixa < central < alta
CF = le('S-canal-fiscal.csv')
dv = lambda c, nv: float(next(r['divida_pct_pib'] for r in CF if r['cenario'].startswith(c + ' | canal fiscal ' + nv) and r['ano'] == '2030'))
teste('canal fiscal ordenado', all(dv(c, 'baixo') >= dv(c, 'central') >= dv(c, 'alto') for c in ('2. Primário do PLDO', '4. Ajuste pela receita', '4b. Ajuste pela despesa')))
base = {r['ano']: r['selic_media'] for r in SC if r['cenario'] == '2. Primário do PLDO'}
teste('canal fiscal nao mexe na Selic', all(r['selic_media'] == base[r['ano']] for r in CF if r['cenario'].startswith('2. ')))
MU = le('S-multiplicador.csv')
dm = lambda c, m: float(next(r['divida_pct_pib'] for r in MU if r['cenario'].startswith(c) and float(r['multiplicador']) == m and r['ano'] == '2030'))
ms = sorted({float(r['multiplicador']) for r in MU})
teste('multiplicador maior, divida maior', all(dm(c, a) <= dm(c, b) for c in ('4. ', '4b.') for a, b in zip(ms, ms[1:])))
MCs = le('S-montecarlo.csv')
teste('monte carlo ordenado (p5 <= p50 <= p95)', all(float(r['p5']) <= float(r['p50']) <= float(r['p95']) for r in MCs))
teste('protocolo N2 registrado antes dos resultados', 'Protocolo N2, fixado antes de olhar resultados' in open(os.path.join(RAIZ, 'BRIEF-v11.md'), encoding='utf-8').read())
# 4. Perimetros de juros: conciliacao fecha (bruta menos consolidada e bruta menos federal)
WP = le('W-juros-perimetros.csv')
v = lambda s: float(next(r['valor_rs_bi'] for r in WP if r['ano'] == '2025' and r['serie'] == s))
c1 = sum(v(s) for s in ('c1b_juros_recebidos_creditos_gf_bndes_e_outros', 'c1c_juros_divida_externa_liquida_bcb_reservas', 'c1d_resultado_swap_e_securitizadas_na_nfsp', 'c1e_residuo_nao_decomposto'))
c2 = v('c2a_juros_compromissadas_bcb') - v('c2b_variacao_cambial_divida_externa_dbgg') + v('c2c_residuo_nao_decomposto')  # ponte P3 = P2 + c2a - c2b + c2c (nota de W)
# os residuos sao calculados por diferenca, entao a soma fecha por construcao; o teste util e o tamanho do residuo
pib25 = v('nfsp_juros_nominais_consolidado') / float(next(r['pct_pib'] for r in WP if r['ano'] == '2025' and r['serie'] == 'nfsp_juros_nominais_consolidado')) * 100
teste('residuo da conciliacao bruta menos consolidada abaixo de 0,5% do PIB', abs(v('c1e_residuo_nao_decomposto')) / pib25 * 100 < 0.5)
teste('residuo da conciliacao bruta menos federal abaixo de 0,5% do PIB', abs(v('c2c_residuo_nao_decomposto')) / pib25 * 100 < 0.5)
# 5. Fatores reais da divida bruta: soma dos fatores = variacao real
for r in le('J-dbgg-fatores-reais.csv'):
  s = sum(float(r[c + '_rs_bi']) for c in ('juro_real', 'emissoes_liquidas', 'cambio', 'outros'))
  if abs(s - float(r['variacao_real_rs_bi'])) > 0.3: teste('fatores reais da divida ' + r['periodo'], False, f'{s} contra {r["variacao_real_rs_bi"]}'); break
else: teste('fatores reais da divida', True)
# 6. Convencoes: sem travessao no relatorio e nos CSV; CSV temporais com coluna de presidente
html = open(os.path.join(AQUI, 'gastos-publicos-brasil.html'), encoding='utf-8').read()
teste('relatorio sem travessao', '—' not in html)
sem_tr = [f for f in glob.glob(os.path.join(RAIZ, '*.csv')) if '—' in open(f, encoding='utf-8').read()]
teste('CSV sem travessao', not sem_tr, ', '.join(os.path.basename(f) for f in sem_tr))
NOVOS = ['Z-emendas.csv', 'Z-emendas-participacao.csv', 'Z-marcos.csv', 'W-curva-mensal.csv', 'W-selic-real.csv', 'W-juros-perimetros.csv', 'X-fatores-mensal.csv', 'X-comparacao-emergentes.csv', 'R-juro-real-br-eua.csv', 'U-previdencia-resultado.csv',
         'PC-renda-trabalho.csv', 'PC-renda-domiciliar-faixas.csv', 'CU-cultura-uniao.csv', 'PC-salario-minimo.csv', 'PC-cesta-sp.csv', 'PC-inflacao-faixa.csv', 'PC-por-mandato.csv', 'FL-desmatamento.csv', 'FL-desmatamento-por-mandato.csv', 'FN-funcoes-uniao.csv', 'FN-subsidios-agro-cultura.csv', 'FN-por-mandato.csv', 'FN-pib-agro.csv', 'FN-ordenamento-territorial.csv', 'CV-atos.csv', 'CV-salic-por-ano.csv', 'CV-transferencias-cultura.csv', 'CV-estrutura-cultura.csv', 'CV-atencao.csv']
sem_p = [f for f in NOVOS if 'presidente' not in open(os.path.join(RAIZ, f), encoding='utf-8').readline()]
teste('series temporais novas com presidente', not sem_p, ', '.join(sem_p))
teste('relatorio sem meia-risca', '\u2013' not in re.sub(r'<[^>]+>', ' ', html))
# receita de pontuacao adotada no texto: texto sem dois-pontos e sem ponto-e-virgula, fora URLs, entidades e
# o titulo de obra citada que a fonte escreve com dois-pontos
_tx = re.sub(r'(?is)<(script|style|svg)[^>]*>.*?</\1>|<[^>]+>|https?://[^\s"\'<]+|&#?\w+;', ' ', html)
_tx = _tx.replace('Tributa\u00e7\u00e3o indireta: al\u00edquotas efetivas', '')
_pt = [m.group(0) for m in re.finditer(r'.{30}[:;].{20}', _tx)]
teste('relatorio sem dois-pontos nem ponto-e-virgula (voz 2047)', not _pt, ' | '.join(_pt[:5]))
_sv = [os.path.basename(f) for f in glob.glob(os.path.join(AQUI, 'graficos', '*.svg')) if re.search(r'<text[^>]*>[^<]*[:;]', open(f, encoding='utf-8').read())]
teste('graficos sem dois-pontos nem ponto-e-virgula', not _sv, ', '.join(_sv))
# numeros no padrao brasileiro nos graficos: nenhum texto de SVG com ponto decimal, nem numero de 4 digitos ou mais sem ponto
# de milhar, fora os anos (1900 a 2100)
_num = []
for f in sorted(glob.glob(os.path.join(AQUI, 'graficos', '*.svg'))):
  for x in re.findall(r'<text[^>]*>([^<]*)</text>', open(f, encoding='utf-8').read()):
    for m in re.finditer(r'(?<![\d.,])[-\u2212]?\d+\.\d+(?![\d.,])|(?<![\d.,])\d{4,}(?![\d.,])', x):
      v = m.group(0)
      if '.' not in v and 1900 <= int(v) <= 2100: continue
      if '.' in v and re.fullmatch(r'\d{1,3}(\.\d{3})+', v): continue
      _num.append(os.path.basename(f) + ' ' + v)
teste('graficos com numero no padrao brasileiro', not _num, ', '.join(_num[:8]))
# presidente ou mandato em todo grafico temporal (SVG com eixo de anos)
import glob as _g
sem_pres = []
for f in sorted(_g.glob(os.path.join(AQUI, 'graficos', '*.svg'))):
  tx = open(f, encoding='utf-8').read()
  anos = len(set(re.findall(r'>(20[0-3]\d)<', tx)) | set(re.findall(r'\b(20[0-3]\d)\b', re.sub(r'<[^>]+>', ' ', tx))))
  if anos >= 4 and not re.search(r'Lula|Dilma|Temer|Bolsonaro|FHC|L2|L3|mandato', tx): sem_pres.append(os.path.basename(f))
teste('graficos temporais com presidente ou mandato', not sem_pres, ', '.join(sem_pres))
# texto contra CSV: numeros-chave da secao 15 aparecem no relatorio como calculados dos CSV
br = lambda x, d: f'{x:,.{d}f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
txt = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', html))
d2 = float(next(r['divida_pct_pib'] for r in SC if r['cenario'] == '2. Primário do PLDO' and r['ano'] == '2030'))
teste('texto contra CSV: divida 2030 do cenario 2', br(d2, 1) + '%' in txt)
teste('texto contra CSV: variacao do juro real brasileiro desde dez/2022', 'o brasileiro subiu ' + br(float(next(r['variacao_pontos'] for r in le('X-variacoes.csv') if r['serie'].startswith('juro real 10 anos Brasil') and r['presidente'] == 'Lula 3')), 2) in txt)
teste('texto contra CSV: economia de 1 ponto so na Selic', 'R$ ' + br(eco('selic', 1.0), 0) + ' bi' in txt)
# licenca: o pacote nao leva a serie ICE e deixa a coluna em branco
import zipfile, io
zp = os.path.join(AQUI, 'gastos-publicos-brasil-dados.zip')
if os.path.exists(zp):
  z = zipfile.ZipFile(zp); nomes = z.namelist()
  xf = [n for n in nomes if n.endswith('/X-fatores-mensal.csv')]
  em = [r['em_oas'] for r in csv.DictReader(io.StringIO(z.read(xf[0]).decode('utf-8')))] if xf else ['x']
  teste('pacote sem a serie ICE', not any('BAMLEMCBPIOAS' in n for n in nomes) and not any(em))
# guarda de layout: o Chrome nao encolhe a pagina, texto no piso de 6,5 pt, sem pagina vazia (relatorio/verifica_layout.py)
import shutil, subprocess as _sp
pdf = os.path.join(AQUI, 'gastos-publicos-brasil.pdf')
if shutil.which('google-chrome') and os.path.exists(pdf):
  r = _sp.run([sys.executable, '-P', os.path.join(AQUI, 'verifica_layout.py'), os.path.join(AQUI, 'gastos-publicos-brasil.html'), pdf],
              capture_output=True, text=True, env={**os.environ, 'PYTHONPATH': os.environ.get('PYTHONPATH', '') + ':' + os.path.expanduser('~/.local/lib/pdftools')})
  teste('layout do PDF (largura, tamanho, paginas)', r.returncode == 0, r.stdout.strip())
# 6b. Secao 16: o trecho mostrado em cada celula aparece literal no relatorio (a passada de voz nao pode mexer em citacao)
PRP = le('PR-propostas.csv')
_prim = {}
for r in PRP: _prim.setdefault((r['parte'], r['tema'], r['partido']), r['trecho'])  # a celula mostra a primeira citacao de cada tema
_fora = [x[:50] for x in _prim.values() if re.sub(r'\s+', ' ', x) not in txt]
teste('citacoes dos planos literais no relatorio', not _fora, ' | '.join(_fora[:3]))
# 7. Regressoes marcadas como associacao (nenhuma linha diz causal)
XR = le('X-regressoes.csv')
teste('regressoes sem afirmacao causal', not any(re.search(r'\bcausa(l|lidade)?\b', r['nota']) and 'nao' not in r['nota'] for r in XR))
# 8. Literatura: todo estudo com link e pagina
YL = le('Y-literatura.csv')
teste('literatura com link e pagina', all(r['link'].startswith('http') and r['pagina_ou_tabela'] for r in YL), str(len(YL)) + ' estudos')
# 9. Renuncias da cultura: a categoria Cultura e Audiovisual do Q X e Rouanet mais atividade audiovisual, e o audiovisual inteiro soma
# tambem Condecine, Recine e industria cinematografica (auditoria externa de 20/10/2026)
CR = {r['serie']: float(r['valor_rs_bi']) for r in le('CU-cultura-resumo.csv')}
teste('ponte das renuncias da cultura', abs(CR['renuncia_lei_rouanet'] + CR['renuncia_atividade_audiovisual'] - CR['renuncia_cultura_e_audiovisual']) < 0.002
      and abs(CR['renuncia_atividade_audiovisual'] + CR['renuncia_audiovisual_fora_da_categoria'] - CR['renuncia_audiovisual']) < 0.002)
# 10. O relatorio so le arquivos que vao no pacote: todo caminho em brutos/ citado no monta_relatorio.py esta no zip
_mr = open(os.path.join(AQUI, 'monta_relatorio.py'), encoding='utf-8').read()
_lidos = sorted(set('brutos/' + '/'.join(re.findall(r"'([^']+)'", m)) for m in re.findall(r"os\.path\.join\((?:RAIZ, )?'brutos', ([^)]*)\)", _mr)))
if os.path.exists(zp):
  _nz = {n.split('/', 1)[1] for n in zipfile.ZipFile(zp).namelist()}
  _fz = [f for f in _lidos if f not in _nz]
  teste('relatorio le so arquivos do pacote', not _fz, ', '.join(_fz))
  _au = sorted(os.path.relpath(f, RAIZ) for f in glob.glob(os.path.join(AQUI, 'AUDITORIA-*.md')))
  teste('pareceres de auditoria no pacote', all(a in _nz for a in _au), ', '.join(a for a in _au if a not in _nz))
# 11. Cultura nos planos pelo mesmo criterio: so o trecho de cultura nos dois, e o capitulo do PT (cultura e esporte) maior que ele
PRC_ = {r['partido']: r for r in le('PR-cultura.csv')}
teste('cultura nos planos com o mesmo criterio', PRC_['PL']['palavras_so_cultura'] == PRC_['PL']['palavras_do_capitulo'] and int(PRC_['PT']['palavras_so_cultura']) < int(PRC_['PT']['palavras_do_capitulo'])
      and br(float(PRC_['PT']['pct_so_cultura']), 1) + '% do texto' in txt)
print(f'{len(falhas)} falha(s)')
sys.exit(1 if falhas else 0)

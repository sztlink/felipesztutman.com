#!/usr/bin/env python3
# Guarda de layout do dossie: falha se o Chrome encolheu a pagina, se ha texto abaixo do piso,
# se sobrou pagina quase vazia (fora o fim de uma parte) ou se apareceu travessao. Uso: verifica_layout.py relatorio.html relatorio.pdf
import re, subprocess, sys, tempfile, os, collections
html, pdf = sys.argv[1], sys.argv[2]
falhas = []
# 1. nenhum elemento mais largo que a coluna (o Chrome encolhe o documento inteiro para caber)
js = """<script>addEventListener('load',()=>{const W=document.documentElement.clientWidth,S=document.documentElement.scrollWidth;
const o=[...document.querySelectorAll('table,figure,pre')].filter(e=>e.getBoundingClientRect().right>W+1).map(e=>(e.innerText||'').slice(0,50).replace(/\\n/g,' '));
document.body.insertAdjacentHTML('afterbegin','<pre id=LARGURA>'+W+'|'+S+'|'+o.join(' || ')+'</pre>')})</script>"""
src = open(html, encoding='utf-8').read()
with tempfile.NamedTemporaryFile('w', suffix='.html', dir=os.path.dirname(os.path.abspath(html)), delete=False, encoding='utf-8') as t:
  t.write(src.replace('</body>', js + '</body>')); tmp = t.name
try:
  dom = subprocess.run(['google-chrome', '--headless=new', '--no-sandbox', '--disable-gpu', '--window-size=680,1000',
                        '--virtual-time-budget=5000', '--dump-dom', 'file://' + tmp], capture_output=True, text=True, timeout=120).stdout
finally:
  os.unlink(tmp)
m = re.search(r'<pre id="LARGURA">(\d+)\|(\d+)\|(.*?)</pre>', dom, re.S)
if m and int(m.group(2)) > int(m.group(1)) + 1:
  falhas.append(f'largura: conteúdo {m.group(2)} px numa coluna de {m.group(1)} px; mais largos: {m.group(3)[:300]}')
# 2. tamanhos reais no PDF
import fitz  # pymupdf; pypdf nao da tamanho de fonte por trecho com a mesma facilidade
d = fitz.open(pdf); tam = collections.Counter(); vazias = []
PARTES = ('Parte I. ', 'Parte II. ', 'Parte III. ', 'Simulações condicionais')  # paginas que abrem uma parte: a anterior pode terminar curta
for i, pg in enumerate(d):
  fundo = max((r[3] for k, r in pg.get_bboxlog() if r[3] < pg.rect.height - 40 and r[3] - r[1] < 0.6 * pg.rect.height), default=0)  # ultima tinta acima do rodape, sem o fundo branco do body
  for b in pg.get_text('dict')['blocks']:
    for l in b.get('lines', []):
      for s in l['spans']: tam[round(s['size'], 1)] += len(s['text'].strip())
  rod = lambda k: (d[k].get_text().split('\n') + ['', ''])[1]  # linha do rodape, que muda na parte de simulacao
  inicio_parte = i < len(d) - 1 and (rod(i) != rod(i + 1) or any(m in d[i + 1].get_text() for m in PARTES))  # a pagina seguinte abre uma parte
  if i < len(d) - 1 and fundo / pg.rect.height < 0.40 and not inicio_parte: vazias.append(i + 1)   # pagina que termina antes de 40% da altura
tot = sum(tam.values())
grandes = [k for k, v in tam.items() if v / tot > 0.15]  # tamanhos com mais de 15% do texto: corpo, tabelas e notas
if max(grandes) < 8.8: falhas.append(f'nenhum tamanho com mais de 15% do texto chega a 8,8 pt ({sorted(grandes)}); o corpo pede 9,2 pt (encolhimento?)')
pequenos = sum(v for k, v in tam.items() if k < 6.5)
if pequenos > 200: falhas.append(f'{pequenos} caracteres abaixo de 6,5 pt')
if vazias: falhas.append(f'páginas que terminam antes de 40% da altura: {vazias}')
if '\u2014' in src: falhas.append('travessão (U+2014) no HTML')
print('\n'.join(falhas) or 'layout ok'); sys.exit(1 if falhas else 0)

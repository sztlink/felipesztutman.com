#!/usr/bin/env python3
# Paridade do simulador navegavel com o dossie. Extrai do simulador.html o json embutido e o script do modelo, roda no node
# cada cenario de S-cenarios-divida.csv e cada choque de S-sensibilidade-juros.csv e compara com os CSV.
# Tolerancia 0,01 ponto do PIB (ou ponto percentual). Rodar de fora da pasta
#   cd /tmp && python3 -P gastos-publicos-brasil-dados/relatorio/simulador/teste_paridade.py
import csv, json, os, re, subprocess, sys, tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..'))
TOL = 0.01
CAMPOS = ['selic_media', 'ipca', 'juro_implicito', 'cresc_nominal', 'primario_pct_pib', 'juros_pct_pib', 'divida_pct_pib', 'primario_estabiliza']

h = open(os.path.join(AQUI, 'simulador.html'), encoding='utf-8').read()
emb = re.findall(r'<script id="parametros" type="application/json">(.*?)</script>', h, re.S)
mod = re.findall(r'<script id="modelo">(.*?)</script>', h, re.S)
assert len(emb) == 1 and len(mod) == 1, 'simulador.html sem o json ou sem o modelo'
P = json.loads(emb[0])
falhas = []
if P != json.load(open(os.path.join(AQUI, 'parametros.json'), encoding='utf-8')):
  falhas.append('json embutido no html difere de parametros.json (rode exporta_parametros.py)')

le = lambda f: list(csv.DictReader(open(os.path.join(RAIZ, f), newline='', encoding='utf-8')))
csv_s = {}
for r in le('S-cenarios-divida.csv'):
  csv_s.setdefault(r['cenario'], {})[int(r['ano'])] = {c: float(r[c]) for c in CAMPOS}
sens = le('S-sensibilidade-juros.csv')
base2 = next(c for c in P['cenarios'] if c['nome'].startswith('2. '))

# configuracoes a rodar no JS
casos = [dict(id=c['nome'], cenario=c['nome']) for c in P['cenarios']]
for r in sens:
  x = float(r['reducao_pp'])
  mapa = {'selic': (-x, 0.0, 0.0), 'curva': (-x, -x, 0.0), 'premio': (0.0, -x, 0.0), 'crescimento real': (0.0, 0.0, x)}
  ds, dsm, dg = mapa[r['choque']]
  casos.append(dict(id=f"sens {r['choque']} {r['reducao_pp']}", cenario=base2['nome'], ds=ds, ds_m=dsm, dg=dg))

runner = mod[0] + '''
const P = JSON.parse(require('fs').readFileSync(process.argv[2], 'utf8'));
const casos = JSON.parse(require('fs').readFileSync(process.argv[3], 'utf8'));
const out = {};
for (const k of casos) {
  const c = P.cenarios.find(x => x.nome === k.cenario);
  const cfg = cfgDoCenario(c);
  for (const f of ['ds', 'ds_m', 'dg']) if (f in k) cfg[f] = k[f];
  out[k.id] = roda(P, cfg);
}
process.stdout.write(JSON.stringify(out));
'''
with tempfile.TemporaryDirectory() as td:
  for nome, txt in (('r.js', runner), ('p.json', json.dumps(P)), ('c.json', json.dumps(casos))):
    open(os.path.join(td, nome), 'w', encoding='utf-8').write(txt)
  pr = subprocess.run(['node', os.path.join(td, 'r.js'), os.path.join(td, 'p.json'), os.path.join(td, 'c.json')], capture_output=True, text=True, cwd=td)
  if pr.returncode:
    sys.exit('node falhou\n' + pr.stderr)
  JS = json.loads(pr.stdout)

print(f'tolerancia {TOL} ponto')
print('cenario                          max_dif  divida_2030 js / csv   resultado')
for c in P['cenarios']:
  nome = c['nome']; js = {l['ano']: l for l in JS[nome]}
  assert sorted(js) == sorted(csv_s[nome]), nome
  difs = [(abs(js[a][k] - csv_s[nome][a][k]), a, k) for a in js for k in CAMPOS]
  m = max(difs)
  ok = m[0] <= TOL
  if not ok: falhas.append(f'{nome} {m[2]} {m[1]} dif {m[0]:.4f}')
  print(f"{nome:32s} {m[0]:7.4f}  {js[2030]['divida_pct_pib']:8.3f} / {csv_s[nome][2030]['divida_pct_pib']:6.2f}   {'ok' if ok else 'FALHA'}")

print('\nsensibilidade sobre o cenario 2 (S-sensibilidade-juros.csv), 2030')
for r in sens:
  k = f"sens {r['choque']} {r['reducao_pp']}"; l = JS[k][-1]
  pares = (('divida_pct_pib', 'divida_2030'), ('juros_pct_pib', 'juros_2030_pct_pib'), ('juro_implicito', 'custo_implicito_2030'))
  m = max(abs(l[a] - float(r[b])) for a, b in pares)
  ok = m <= TOL
  if not ok: falhas.append(f'{k} dif {m:.4f}')
  print(f"{r['choque']:17s} {r['reducao_pp']:>5s}  max_dif {m:.4f}  divida {l['divida_pct_pib']:.3f} / {r['divida_2030']}  {'ok' if ok else 'FALHA'}")

# guardas das faixas: todo cenario do dossie cabe nas faixas dos controles
F = P['faixas']
for c in P['cenarios']:
  for k in ('ds', 'ds_m', 'dg', 'defl'):
    if not F[k]['min'] - 1e-9 <= c[k] <= F[k]['max'] + 1e-9: falhas.append(f"{c['nome']} {k}={c[k]} fora da faixa")
  for a, f in F['primario'].items():
    if not f['min'] - 0.005 <= c['primario'][a] <= f['max'] + 0.005: falhas.append(f"{c['nome']} primario {a} fora da faixa")

# texto visivel sem travessao nem dois-pontos ou ponto e virgula em frase
vis = re.sub(r'<script.*?</script>|<style.*?</style>|<[^>]+>', ' ', h, flags=re.S)
for ch, nm in (('—', 'travessao'), ('–', 'meia-risca'), (';', 'ponto e virgula'), (':', 'dois-pontos')):
  if ch in vis: falhas.append(f'texto visivel com {nm}')
for lit in re.findall(r"'([^'\n]*)'", mod[0] + h.split('<script id="modelo">')[1]):
  if '—' in lit: falhas.append('string do JS com travessao')

print()
if falhas:
  print('FALHOU'); [print(' ', f) for f in falhas]; sys.exit(1)
print(f'PASSOU, {len(P["cenarios"])} cenarios e {len(sens)} choques de sensibilidade dentro de {TOL}')

# Simulador da dívida bruta, 2026 a 2030

Página estática que refaz no navegador o cálculo de `roda()` em `brutos/S/build_S.py` (seção de cenários da dívida,
`S-cenarios-divida.csv`). O leitor parte de um dos nove cenários do dossiê e mexe nas premissas dentro de faixas que o
próprio dossiê testou. Simulação condicional, não previsão.

## Arquivos

| arquivo | o que é |
|---|---|
| `simulador.html` | a página, um arquivo só, JS inline, parâmetros embutidos, gráfico em SVG sem biblioteca |
| `parametros.json` | parâmetros, séries de base, cenários, referência do CSV e faixas, cada parâmetro com fonte e data |
| `exporta_parametros.py` | gera o json e o embute no html |
| `teste_paridade.py` | roda o modelo do html no node e compara com os CSV |

## Abrir

Abrir `simulador.html` direto do disco. As fontes vêm de `../../../estilo/fontes/estaticas/`. Fora desta árvore a
página cai para sans-serif e continua funcionando.

## Regerar

```
cd /tmp && python3 -P gastos-publicos-brasil-dados/relatorio/simulador/exporta_parametros.py
cd /tmp && python3 -P gastos-publicos-brasil-dados/relatorio/simulador/teste_paridade.py
```

O exportador não importa `build_S.py` (importar rodaria o script inteiro e regravaria os CSV da frente S). Ele executa o
trecho de cálculo dos parâmetros, do início até antes da primeira escrita de arquivo, sem alterar nada, e lê os mesmos
objetos que `roda()` usa. Se `build_S.py` mudar e o ponto de corte sumir, o exportador para com erro. Precisa de
pymupdf em `~/.local/lib/pdftools` (o mesmo do build_S) e dos brutos da frente S.

## Controles e faixas

Todos valem desde 2027. 2026 fica como no dossiê.

| controle | faixa | de onde vem |
|---|---|---|
| Selic, desvio do cenário | -3 a +2 pontos | `S-sensibilidade-juros.csv` (redução máxima testada) e cenário 5 (estresse) |
| taxas de mercado de 10 anos (prêmio) | -3 a +2 pontos | idem, choque "premio" |
| crescimento real extra | -1 a +1 ponto | `S-sensibilidade-juros.csv`, choque de crescimento |
| deflator acima do IPCA | -1 a +1 ponto | `S-montecarlo.csv`, faixa sorteada |
| primário 2027 a 2030 | do menor ao maior primário dos cenários no ano, incluída a meta do PLDO | `S-cenarios-divida.csv` e PLDO 2027 |

Saída por ano, dívida bruta em % do PIB, primário que estabiliza, juros em % do PIB, Selic média e juro implícito,
com o cenário escolhido do CSV ao lado como referência fixa.

## Teste de paridade (24/10/2026)

Os nove cenários de `S-cenarios-divida.csv`, nos oito campos numéricos e nos cinco anos, e os 17 choques de
`S-sensibilidade-juros.csv` (dívida, juros e juro implícito de 2030). Tolerância 0,01 ponto. Passou em todos, com
diferença máxima de 0,005, que é o arredondamento do CSV. O teste também confere que o json embutido é igual ao
`parametros.json`, que todo cenário cabe nas faixas e que o texto visível não tem travessão, dois-pontos nem ponto e
vírgula.

## Fora do simulador

Canal fiscal (`S-canal-fiscal.csv`), multiplicador (`S-multiplicador.csv`) e a faixa do Monte Carlo. Os controles mudam
premissas e não modelam reações, o crescimento não responde ao primário e os juros não respondem à trajetória fiscal.

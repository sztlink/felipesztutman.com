#!/usr/bin/env python3
# Exporta os parametros do simulador de divida (secao de cenarios, frente S) para parametros.json e embute o json no
# simulador.html. Nao altera brutos/S/build_S.py e nao o importa como modulo (importar rodaria o script inteiro e
# regravaria os CSV da frente S). Executa so o trecho de calculo dos parametros, ate antes da primeira escrita de
# arquivo, num namespace isolado, e le dele os mesmos objetos que roda() usa. Rodar de fora da pasta
#   cd /tmp && python3 -P gastos-publicos-brasil-dados/relatorio/simulador/exporta_parametros.py
import csv, hashlib, json, os, re, subprocess

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.normpath(os.path.join(AQUI, '..', '..'))
BUILD = os.path.join(RAIZ, 'brutos', 'S', 'build_S.py')
CORTE = "\nwith open(os.path.join(RAIZ, 'S-cenarios-divida.csv'), 'w'"

src = open(BUILD, encoding='utf-8').read()
assert src.count(CORTE) == 1, 'build_S.py mudou, o ponto de corte antes da primeira escrita nao foi achado'
trecho = src[:src.index(CORTE)]
assert "'w'" not in trecho and '.write(' not in trecho, 'o trecho executado nao pode escrever arquivo'
ns = {'__file__': BUILD, '__name__': 'build_S_parametros'}
exec(compile(trecho, BUILD, 'exec'), ns)

ANOS = list(range(2026, 2031))
r4 = lambda v: float(v)  # precisao cheia, para a paridade com o CSV
le = lambda f: list(csv.DictReader(open(os.path.join(RAIZ, f), newline='', encoding='utf-8')))

# cenarios do dossie, com as premissas exatamente como build_S.py as passa a roda()
cen = []
for nome, prim, ds, desc, macro, defl in ns['CEN']:
  cen.append(dict(nome=nome, descricao=desc, primario={a: r4(prim(a)) for a in ANOS}, ds=ds, ds_m=ds, defl=defl, dg=0.0,
                  macro='focus' if macro is ns['macro_focus'] else 'pldo'))
macro = {}
for k, f in (('focus', ns['macro_focus']), ('pldo', ns['macro_pldo'])):
  macro[k] = {a: dict(zip(('selic', 'ipca', 'cresc_nominal'), [r4(x) for x in f(a)])) for a in ANOS}
frac = {ix: {k: r4(ns['frac'](ix, k)) for k in range(1, 6)} for ix in ('prefixado (DPMFi)', 'indice de precos (DPMFi)')}

# referencia fixa: o proprio S-cenarios-divida.csv, sem recalculo
CAMPOS = ['selic_media', 'ipca', 'juro_implicito', 'cresc_nominal', 'primario_pct_pib', 'juros_pct_pib', 'divida_pct_pib', 'primario_estabiliza']
ref = {}
for r in le('S-cenarios-divida.csv'):
  ref.setdefault(r['cenario'], {})[int(r['ano'])] = {c: float(r[c]) for c in CAMPOS}
assert list(ref) == [c['nome'] for c in cen], 'cenarios do CSV e do build_S.py diferem'

# faixas dos controles, lidas dos arquivos do dossie
sens = le('S-sensibilidade-juros.csv')
red = lambda t: max(float(r['reducao_pp']) for r in sens if r['choque'] == t)
cr = [float(r['reducao_pp']) for r in sens if r['choque'] == 'crescimento real']
mc_nota = le('S-montecarlo.csv')[0]['nota']
m = re.search(r'deflator uniforme IPCA (-?[\d.]+) a \+?([\d.]+) ponto', mc_nota)
dfl = (float(m.group(1)), float(m.group(2)))
ds_max = max(c['ds'] for c in cen)
prim_faixa = {}
for a in ANOS[1:]:
  vs = [c['primario'][a] for c in cen] + [ns['META'][a]]
  prim_faixa[a] = dict(min=round(min(vs), 2), max=round(max(vs), 2))
faixas = dict(
  ds=dict(min=-red('selic'), max=ds_max, passo=0.25, fonte='S-sensibilidade-juros.csv (reducoes da Selic ate o maximo testado) e cenario 5 (estresse, maior alta)'),
  ds_m=dict(min=-red('premio'), max=ds_max, passo=0.25, fonte='S-sensibilidade-juros.csv (reducoes do premio ate o maximo testado) e cenario 5 (estresse, maior alta)'),
  dg=dict(min=min(cr), max=max(cr), passo=0.25, fonte='S-sensibilidade-juros.csv, choque de crescimento real'),
  defl=dict(min=dfl[0], max=dfl[1], passo=0.25, fonte='S-montecarlo.csv, faixa sorteada do deflator'),
  primario={a: {**v, 'passo': 0.05} for a, v in prim_faixa.items()},
  primario_fonte='menor e maior primario dos cenarios do dossie no ano, incluida a meta do PLDO 2027')

def sha(p):
  return hashlib.sha256(open(p, 'rb').read()).hexdigest()[:16]
ENTRADAS = ['J-dbgg-fatores.csv', 'J-dbgg-composicao.csv', 'O-custo-divida-indexador.csv', 'K-primario-recorrente.csv', 'N-juro-real-mensal.csv',
            'N-juro-real-anual.csv', 'E-renuncias-e-subsidios.csv', 'D-rtn-despesa-primaria.csv', 'brutos/W/perfil_vencimentos_dez2025.csv',
            'brutos/S/bcb-focus-olinda-anuais-out2026.json', 'brutos/S/bcb-focus-R20261009.pdf', 'brutos/S/pldo2027-anexo-iv-02-metas-fiscais.pdf',
            'brutos/S/planalto-lcp-200-2023.htm', 'S-cenarios-divida.csv', 'S-sensibilidade-juros.csv', 'S-montecarlo.csv']
try:
  commit = subprocess.run(['git', '-C', RAIZ, 'log', '-1', '--format=%h', '--', '.'], capture_output=True, text=True).stdout.strip()
except Exception:
  commit = ''

P = lambda valor, fonte, data: dict(valor=valor, fonte=fonte, data=data)
FO = ns['FO']
par = dict(
  d0=P(r4(ns['d0']), 'J-dbgg-composicao.csv, dbgg_total (BCB estatisticas fiscais)', 'dez/2025'),
  pib_2025_rs_bi=P(r4(ns['PIB25']), 'K-primario-recorrente.csv, pib_rs_mi (RTN)', '2025'),
  juro_implicito_2025=P(r4(100 * ns['i25']), 'J-dbgg-fatores.csv, juros nominais de 2025 sobre o saldo de 2024', '2025'),
  peso_selic=P(r4(ns['w_s']), 'J-dbgg-composicao.csv (compromissadas) e O-custo-divida-indexador.csv (selic_flutuante, % do estoque)', 'dez/2025'),
  peso_prefixado=P(r4(ns['w_f']), 'O-custo-divida-indexador.csv, prefixado, % do estoque', 'dez/2025'),
  peso_precos=P(r4(ns['w_p']), 'O-custo-divida-indexador.csv, indice_precos, % do estoque', 'dez/2025'),
  k_cal=P(r4(ns['K_CAL']), 'residuo que reproduz o juro implicito de 2025 (cambio e demais), constante', '2025'),
  custo_prefixado_2025=P(r4(ns['cf25']), 'O-custo-divida-indexador.csv, custo medio 12 meses do prefixado (RMD)', '2025'),
  juro_real_precos_2025=P(r4(ns['rr25']), 'O-custo-divida-indexador.csv e N-juro-real-anual.csv (IPCA de 2025)', '2025'),
  prefixado_10a=P(r4(ns['pre10']), 'N-juro-real-mensal.csv, prefixado de 10 anos (Tesouro Direto)', ns['mes_mkt']),
  juro_real_10a=P(r4(ns['real10']), 'N-juro-real-mensal.csv, juro real de 10 anos (Tesouro Direto)', ns['mes_mkt']),
  dias_uteis_mes_mercado=P(int(ns['ult']['dias_uteis_td']), 'N-juro-real-mensal.csv, dias uteis do mes de mercado (mes parcial)', ns['mes_mkt']),
  primario_2025=P(r4(ns['p25']), 'K-primario-recorrente.csv, primario cheio (RTN)', '2025'),
  meta_pldo=P({a: ns['META'][a] for a in sorted(ns['META'])}, 'PLDO 2027 Anexo IV.2, metas de primario', 'abr/2026'),
  primario_pldo=P({a: ns['PROJ'][a] for a in sorted(ns['PROJ'])}, 'PLDO 2027 Anexo IV.2 Tabela 3, Governo Central antes das exclusoes', 'abr/2026'),
  primario_focus=P({a: ns['FPRIM'][a] for a in sorted(ns['FPRIM'])}, 'Focus 09/10/2026, resultado primario, setor publico consolidado', '09/10/2026'),
  dbgg_pldo=P({a: ns['PLDO_DBGG'][a] for a in sorted(ns['PLDO_DBGG'])}, 'PLDO 2027 Anexo IV.2 Tabela 4, DBGG', 'abr/2026'),
  focus_selic=P({a: FO[('Selic', a)] for a in ANOS}, 'Focus 09/10/2026 (Olinda, ExpectativasMercadoAnuais), Selic de fim de ano', '09/10/2026'),
  focus_ipca=P({a: FO[('IPCA', a)] for a in ANOS}, 'Focus 09/10/2026 (Olinda), IPCA', '09/10/2026'),
  focus_pib=P({a: FO[('PIB Total', a)] for a in ANOS}, 'Focus 09/10/2026 (Olinda), PIB real', '09/10/2026'),
  pldo_selic=P({a: ns['G_SEL'][a] for a in ANOS}, 'PLDO 2027 Anexo IV.2 Tabela 1, Selic over acumulada no ano', 'mar/2026'),
  pldo_ipca=P({a: ns['G_IPCA'][a] for a in ANOS}, 'PLDO 2027 Anexo IV.2 Tabela 1, IPCA', 'mar/2026'),
  pldo_pib_nominal=P({a: ns['G_PIB'][a] for a in range(2025, 2031)}, 'PLDO 2027 Anexo IV.2 Tabela 1, PIB nominal (R$ bi)', 'mar/2026'),
  renuncias_2024_pct_pib=P(ns['REN_PIB'], 'E-renuncias-e-subsidios.csv, subsidios tributarios (OSU 2024)', '2024'),
  despesa_2025_pct_pib=P(ns['D25'], 'D-rtn-despesa-primaria.csv, despesa total (RTN)', '2025'),
  arcabouco_piso_teto=P([ns['PISO'], ns['TETO']], 'LC 200/2023, crescimento real da despesa', '2023'),
  frac_repreciada=P(frac, 'brutos/W/perfil_vencimentos_dez2025.csv (RMD anexo 3.2), fracao media do estoque repreciada no ano k (k=1 em 2026)', 'dez/2025'),
  macro=P(macro, 'focus = Selic media (meses observados de 2026 em N-juro-real-mensal.csv e Focus), IPCA e PIB do Focus; pldo = grade do PLDO 2027', '09/10/2026 e mar/2026'),
)
saida = dict(
  titulo='Simulador da dívida bruta 2026 a 2030',
  origem=dict(script='brutos/S/build_S.py, trecho de parametros executado sem alteracao', commit_dossie=commit,
              entradas={f: sha(os.path.join(RAIZ, f)) for f in ENTRADAS}),
  identidade='d_t = d_{t-1} (1 + i_t) / (1 + g_t) - p_t, sem ajustes entre fluxo e estoque',
  anos=ANOS, parametros=par, cenarios=cen, referencia=ref, faixas=faixas)

js = json.dumps(saida, ensure_ascii=False, indent=1)
open(os.path.join(AQUI, 'parametros.json'), 'w', encoding='utf-8').write(js + '\n')

html_p = os.path.join(AQUI, 'simulador.html')
if os.path.exists(html_p):
  h = open(html_p, encoding='utf-8').read()
  pat = re.compile(r'(<script id="parametros" type="application/json">)(.*?)(</script>)', re.S)
  assert len(pat.findall(h)) == 1, 'marcador do json nao achado no simulador.html'
  emb = json.dumps(saida, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
  h = pat.sub(lambda mm: mm.group(1) + emb + mm.group(3), h)
  open(html_p, 'w', encoding='utf-8').write(h)
  print('json embutido em simulador.html')
print('parametros.json', len(js), 'bytes', len(cen), 'cenarios', 'mercado', ns['mes_mkt'])

# estilo dos graficos do volume 1 (gastos publicos). Desde 24/10/2026 o sistema e comum aos dois volumes do dossie,
# em economia-brasil/estilo/ (base.py, base.css, DESIGN.md). Aqui fica so a cor semantica deste volume.
import os, sys
_R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
for _d in (os.path.join(_R, 'estilo'), os.path.join(_R, '..', 'estilo')):  # pacote: estilo/ ao lado de relatorio/; repo: economia-brasil/estilo
  if os.path.exists(os.path.join(_d, 'base.py')): sys.path.insert(0, _d); break
from base import *  # noqa: F401,F403

COR = {  # cor semantica: um conceito, uma cor, em todos os graficos
  'juros': AZUL, 'juro_real': AZUL, 'selic': AZUL, 'selic_flutuante': AZUL, 'brasil': AZUL,
  'indice_precos': AZUL_2, 'parcial': AZUL_2, 'projecao': AZUL_2,
  'variacao': TINTA, 'total': TINTA, 'ipca': TINTA,
  'primario': CINZA_1, 'emissoes_liquidas': CINZA_1,
  'cambio': CINZA_2, 'pib': CINZA_3, 'outros': CINZA_3, 'prefixado': CINZA_3,
  'pldo': OCRE,
}
STYLE = dict(STYLE, **{'svg.hashsalt': 'gastos-publicos-brasil'})
mpl.rcParams.update(STYLE)

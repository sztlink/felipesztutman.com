#!/usr/bin/env python3
# Refaz todos os CSV da raiz a partir dos brutos baixados e compara com os que o relatorio usa (hash por arquivo).
# Uso: python3 -P relatorio/verifica_reproducao.py  (precisa dos brutos de cada frente em brutos/<frente>/, ver downloads.tsv)
# Saida: lista de CSV identicos, alterados e scripts que falharam; codigo de saida 1 se algo mudou ou falhou.
import glob, hashlib, os, subprocess, sys, time
AQUI = os.path.dirname(os.path.abspath(__file__)); RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
ORDEM = ['A/build.py', 'B/build.py', 'E/build_E.py', 'E/build_E_linhas.py', 'F/build_F.py', 'H/build_media_mensal.py', 'H/build_historico.py',
         'I/build_divida.py', 'I/build_dbgg_anual.py', 'J/build_J.py', 'J/build_bcb_tesouro.py', 'J/build_dbgg_real.py', 'K/build_K.py',
         'L/build_L.py', 'LISTA/build_lista.py', 'LISTA/build_absoluto.py', 'M/build_M.py', 'M/build_M_decomp.py', 'N/build_N.py',
         'O/build_O.py', 'P/build_P.py', 'Q/build_Q.py', 'R/build_R_spread.py', 'S/build_S.py', 'T/build_T.py', 'U/build_U.py', 'V/build_V.py', 'W/build_W.py', 'X/build_X.py', 'Y/build_Y.py', 'Z/build_Z.py', 'N2/build_N2.py', 'Y2/build_Y2.py', 'PC/build_PC.py', 'PR/build_PR.py', 'MK/build_MK.py', 'CU/build_CU.py', 'FL/build_FL.py', 'FN/build_FN.py', 'CV/build_CV.py', 'CV/audita_temas.py', 'FB/build_FB.py', 'EL/build_EL.py', 'CI/build_CI.py', 'PO/build_PO.py', 'S2/build_S2.py', 'EE/build_EE.py']
# entradas que nao podem ser redistribuidas: sem elas o script e pulado e seus CSV saem da comparacao
REQ = {'MK/build_MK.py': (['MK/fontes/anbima_ettj_cz_20261019.html'], 'MK-curva', 'curva da ANBIMA, direitos reservados: baixe com brutos/MK/baixa_MK.py'),
       'X/build_X.py': (['X/dados/BAMLEMCBPIOAS.csv', 'X/dados/wayback_20241026_BAMLEMCBPIOAS.html'], 'X-',
                        'spread ICE BofA de emergentes, licenca nao permite redistribuir: baixe pelo FRED (BAMLEMCBPIOAS), ver brutos/X/LEIAME.md')}
pulados = []
hs = lambda: {os.path.relpath(f, RAIZ): hashlib.sha256(open(f, 'rb').read()).hexdigest()
              for f in glob.glob(os.path.join(RAIZ, '*.csv')) + glob.glob(os.path.join(RAIZ, 'brutos', '*', '*.csv'))}
antes = hs(); falhas = []
for s in ORDEM:
  p = os.path.join(RAIZ, 'brutos', s)
  if not os.path.exists(p): continue
  if s in REQ and not all(os.path.exists(os.path.join(RAIZ, 'brutos', f)) for f in REQ[s][0]):
    print('pula', s, '(' + REQ[s][2] + ')'); pulados.append(REQ[s][1]); continue
  t0 = time.time()
  r = subprocess.run([sys.executable, '-P', p], cwd=os.path.dirname(p), capture_output=True, text=True, timeout=1800)
  print(f"{'ok ' if r.returncode == 0 else 'ERRO'} {s} {time.time() - t0:.0f}s")
  if r.returncode: falhas.append((s, r.stderr.strip().splitlines()[-1:] if r.stderr else ''))
depois = hs()
mud = sorted(k for k in antes if depois.get(k) != antes[k] and not any(os.path.basename(k).startswith(pf) for pf in pulados)); novos = sorted(set(depois) - set(antes))
print(f'{len(antes) - len(mud)} CSV identicos, {len(mud)} alterados, {len(novos)} novos')
for k in mud: print('  alterado', k)
for s, e in falhas: print('  falhou', s, e)
sys.exit(1 if mud or falhas else 0)

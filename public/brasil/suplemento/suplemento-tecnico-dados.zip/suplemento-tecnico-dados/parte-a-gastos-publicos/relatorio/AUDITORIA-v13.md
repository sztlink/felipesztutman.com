# Auditoria adversarial da versão 13, volume 1, "Gastos públicos do Brasil"

Feita em 24/10/2026, entre 21h50 e 22h30, por agente de IA (Claude) que não construiu nenhuma das partes auditadas. Escopo, as
partes novas da v13. Estrutura e remissões, seção 9 ("A regra, ano a ano"), seção 12 ("O que move a dívida de 2030", "Se a Selic
não cair", "A receita do PLOA 2027"), nota para quem aloca capital (curva e item do PLOA), anexo T1 (OCDE), anexo T6 (Focus e
turnos da eleição), anexo T7 e simulador. Nada do dossiê foi editado. Material lido no estado de 21h51 (PDF e HTML), 21h54 (zip)
e 22h00 (CHANGELOG). Os números foram refeitos a partir dos CSV e, onde deu, dos brutos (Focus da Olinda, SIDRA 1737, PTAX do SGS,
COFOG da STN). O teste de paridade do simulador foi rodado e passou (9 cenários e 17 choques, diferença máxima 0,005).

Resumo. 11 erros, 6 vieses, 5 excessos. Nenhum erro muda um número de manchete, e a aritmética dos CSV fecha em todos os 46 itens
refeitos. Os problemas que pesam são de leitura. A ponte do PLOA esconde que todo o ganho "além do PIB" vem da queda das
transferências a estados e municípios. O trecho dos turnos da eleição, na véspera do 2º turno, destaca o movimento recorde depois do
1º turno de 2026 sem dizer com todas as letras que a direção não indica preferência. A ordem das alavancas da seção 12 sai com classe
A quando depende do tamanho de choque escolhido.

## Erros

**E1. A ponte do PLOA atribui o ganho "além do PIB" à reforma do consumo, e ele vem das transferências. Severidade média-alta.**
Seção 12, "A receita do PLOA 2027", e nota para quem aloca capital ("Governo contra mercado").
O texto diz que R$ 46,6 bi (0,32 ponto do PIB) vão além do PIB, que a troca de PIS, Cofins e IPI soma R$ 69,6 bi além do PIB e
que IR (-48,1) e dividendos (-29,0) puxam para baixo. Pelo próprio PO-ponte-receita-2027.csv, somando os blocos:
- reforma do consumo +69,6, demais receitas da RFB -66,0, receitas não administradas -41,8, transferências a estados e municípios
  (com sinal invertido) +84,8. Total +46,6.
- A receita bruta do Governo Central fica R$ 38,2 bi abaixo do que o PIB daria. Todo o ganho líquido, e mais, vem da queda das
  transferências (FPE e FPM +58,1, royalties +23,3), que é efeito mecânico do IPI zerado, repartido, trocado pela CBS, não repartida.
- Na despesa, o mesmo PLOA cria o fundo de compensação aos estados pela troca do IPI, R$ 33,8 bi, que come boa parte desse ganho.
- O LEIAME da frente PO diz que "além do PIB não é sinônimo de medida nova". O texto do relatório não diz.
- O cenário 2 usa o primário do PLDO para 2027 (0,05% do PIB). O PLOA projeta 0,13%. O texto não registra a diferença.

Correção proposta, no lugar das duas últimas frases do parágrafo: "A troca de PIS, Cofins e IPI pela CBS e pelo Imposto Seletivo
soma R$ 69,6 bi além do PIB, com R$ 42,0 bi de Imposto Seletivo, que depende de lei ordinária com as alíquotas. Como o IPI era
repartido com estados e municípios e a CBS não é, as transferências caem R$ 84,8 bi abaixo do que o PIB daria, e é daí que vem o
ganho líquido. Sem as transferências, a receita fica R$ 38,2 bi abaixo do PIB, com Imposto de Renda (-48,1) e dividendos (-29,0)
puxando para baixo. Na despesa, o PLOA cria um fundo de R$ 33,8 bi para compensar os estados pela troca do IPI. Além do PIB não
quer dizer medida nova, e soma medida, premissa da reforma, petróleo, dividendos e elasticidade. O PLOA projeta primário de 0,13% do
PIB em 2027, e os cenários usam o 0,05% do PLDO." Na nota para quem aloca, trocar "prevê receita 0,32 ponto do PIB acima" por
"prevê receita líquida 0,32 ponto do PIB acima ..., quase toda pela queda das transferências que acompanha a reforma do consumo".

**E2. Remissão velha e anexo no feminino depois da renumeração. Severidade média (o CHANGELOG diz que todas as remissões foram
trocadas).**
- Anexo T5, parágrafo de cultura. "A captação da Lei Rouanet ... continuou nos anos sem ministério (seção 3)". A seção 3 não tem
  mais nada de cultura (a parte saiu para o T1). Trocar por "(anexo T1)".
- Três concordâncias quebradas pela troca automática de "seção" por "anexo". "está na anexo T3" (seção 1, renúncias), "da anexo T3"
  (anexo T5, salário mínimo e INPC) e "A anexo T5 cita os planos" (Limites dos dados). Trocar por "no anexo", "do anexo", "O anexo".
- Anexo T5 abre com "Como ler esta seção". Trocar por "Como ler este anexo".

**E3. Os links da Parte I, II e III no sumário do HTML não funcionam. Severidade baixa.**
O sumário aponta para `#parte-i-nucleo-fiscal`, `#parte-ii-anexos-tematicos` e `#parte-iii-metodo-e-dados`, e os títulos têm
`id=parte-i`, `parte-ii` e `parte-iii`. As outras 1.686 âncoras internas resolvem, e os links "seção N" e "anexo X" apontam para o
título certo no HTML e no PDF. Correção, alinhar os dois nomes no gerador do sumário.

**E4. O "primário que estabiliza" usa duas definições no mesmo gráfico. Severidade média-baixa.**
Na série de 2007 a 2025 (Figura 15, monta_relatorio.py, `p_est_ano`), a conta multiplica (i - g)/(1 + g) pela dívida de dezembro
do próprio ano (d_t). Nos cenários de 2026 a 2030 (build_S.py e simulador), pela dívida do ano anterior (d_t-1), que é a forma
correta da identidade d_t = d_t-1 (1 + i)/(1 + g) - p. O texto diz "pela mesma conta". O próprio parágrafo da seção 12 mostra a
mistura, "dívida de partida maior (95% contra 79%)", com 95,2% de 2029 contra 78,6% de 2025, e não de 2024.
Efeito, refeito a partir de J-dbgg-fatores.csv, K-primario-recorrente.csv e I-divida-historico.csv. A contagem não muda (8 de 19,
o último em 2022). A distância de 2025 passa de 3,7 para 3,6 pontos, e o primário que estabiliza em 2025 de 3,2% para 3,1%. Em
2015 vai de 6,3% para 5,4%, em 2020 de 2,8% para 2,4% e em 2021 de -7,1% para -8,0%. Correção, usar d_t-1 em `p_est_ano` e no
parágrafo "Que primário estabiliza a bruta" (ou dizer que o número de 2025 é uma conta de olhar para frente, com dívida de fim de
ano, e separá-lo da série).

**E5. Número sem fonte na nota para quem aloca. Severidade baixa.**
"com diferença de uns 10 pb conforme a janela" está escrito à mão no gerador (linha 1752). A Tabela 1, logo abaixo, dá -3 pb.
Na mesma frase, "o que responde por 102 a 264 pb" pega o 102 do segundo ano, enquanto o intervalo de inflação implícita citado é do
terceiro ao quinto (202 a 264 pb), e "contra 3,5% no Focus" vale para o quarto e o quinto ano (o terceiro é 3,57%). Correção,
"com diferença de 3 pb" e "de 4,9% a 6,1% ao ano do segundo ao quinto ano, contra 3,9% a 3,5% no Focus, o que responde por 102 a
264 pb".

**E6. Data do PLDO. Severidade baixa.** A nota para quem aloca diz "O PLDO, de março de 2026". O PO-ponte e o MK dizem PLDO de
abril de 2026, com grade de parâmetros de março. Trocar por "O PLDO, de abril de 2026, com grade de março".

**E7. Rótulos da Figura 21 e frase que a acompanha. Severidade baixa a média (ver X1).** "Cada premissa foi mudada sozinha", mas
"Macro do PLDO" troca Selic, IPCA e PIB juntos, e "Prêmio -1,5" baixa a Selic e as taxas de mercado (é o choque "Selic e mercado"
com 1,5 ponto, não prêmio). Renomear para "Macro do PLDO (Selic, IPCA e PIB)" e "Selic e mercado -1,5 (cenário 3)".

**E8. Figura 27, rótulos sobrepostos. Severidade baixa.** "Brasil" e "Reino Unido" ficam um sobre o outro e o do Brasil não se lê
(0,218% e 0,223%). Deslocar o rótulo do Reino Unido ou tirá-lo.

**E9. Simulador, rótulo do controle de juros. Severidade baixa.** "Selic, desvio do cenário" e "Taxas de mercado de 10 anos,
desvio do cenário". O controle é o desvio contra o caminho do Focus (ou da grade do PLDO no cenário 6), e não contra o cenário
escolhido. Partindo do cenário 3, o controle já abre em -1,5. Trocar por "Selic, desvio do Focus" e "Taxas de mercado de 10 anos,
desvio do nível de out/2026".

**E10. "Como ler" não classifica os anexos novos. Severidade baixa.** "As seções 1 a 11 e os anexos T1 a T4 usam dados
publicados ... As seções 12 e 13 trazem simulações". T6 e T7 ficam fora da lista, e a seção 12 agora também traz a ponte do PLOA,
que é decomposição de projeção oficial, não simulação. Acrescentar "e os anexos T6 e T7" e "a seção 12 traz também a ponte da
receita do PLOA 2027, que decompõe a projeção do governo".

**E11. Referências internas e atribuição a pessoa real no pacote. Severidade média-baixa.**
- `relatorio/monta_relatorio.py` (quatro comentários, "leitura Casey Reas, recomendacao 3, 5, 7 e 8") e `estilo/DESIGN.md` ("parecer
  de design e leitura de Casey Reas, aplicados na versão 13") vão no zip sem a ressalva que o CHANGELOG v12.2 traz ("agente de IA com
  a persona ... sem participação do artista Casey Reas"). Para um leitor de fora, parece que o artista leu o dossiê. Trocar por
  "leitura de design por agente de IA, recomendação N".
- CHANGELOG v13 traz "voz 2047" e "pendência da seção 10", termos de trabalho que o leitor não tem como entender.
- A nota da Tabela 49 diz "vértices pelo método das frentes W e N". O Anexo B define frente, mas a nota pode dizer "pelo mesmo
  método das seções 11 e 13".
- O zip (21h54) é anterior ao CHANGELOG com a entrada v13 (22h00) e sai sem ela. Regerar o pacote no fechamento.

## Vieses

**V1. Turnos da eleição. O recorde de 2026 em destaque na véspera do 2º turno, sem a frase que impede a leitura de preferência.
Severidade alta.**
O texto respeita a letra do BRIEF-v14. Não nomeia candidato, resultado nem presidente, a variação é A e a causa é C. Mesmo assim,
três coisas pesam num documento que circula entre leitores de mercado em 24 e 25/10.
1. A frase com classe A termina em "os cinco no maior movimento entre os 1º turnos desde 2002", com dólar e juros caindo. Quem lê
   sabe quem liderou o 1º turno. Dólar e juros em queda forte no dia seguinte é lido, no mercado, como aprovação. O bloco C diz que a
   causa não está demonstrada, mas não diz o que o BRIEF e o LEIAME dizem, que a direção do movimento não mede qual resultado o
   mercado preferia.
2. O caráter post hoc da linha de 2026 está dito pela metade. O texto diz que os preços "já existiam, embora não tivessem sido
   calculados aqui". Os níveis já tinham sido vistos. A série diária do TD até 15/10/2026 alimenta o gráfico de juro real longo da
   seção 11, e a curva da ANBIMA de 19/10 está na Figura 1. O LEIAME da EL registra ainda dois desvios feitos depois de uma primeira
   rodada que "já mostrava variações". Nenhum dos dois muda 2026 (a referência tem 52 janelas), mas o leitor não fica sabendo.
3. O título promete "cada turno" e a tabela só traz o 1º. O histórico do 2º turno existe e é mais calmo (câmbio, mediana de 1,33%
   em módulo contra 0,44% num fim de semana comum, um de seis no percentil 95 ou mais). A janela de 5 dias também saiu do texto.

Correção proposta.
- Acrescentar ao bloco C: "A direção do movimento não indica qual resultado o mercado preferia nem o que espera do 2º turno. O
  cálculo não lê voto, candidato nem resultado."
- No parágrafo do protocolo: "Por isso a linha de 2026 é descrição feita depois do fato, não teste fixado antes. Os níveis de juros
  de outubro de 2026 já estavam nas seções 11 e na Figura 1."
- Pôr na Tabela 49, ou numa irmã, os 2º turnos de 2002 a 2022 e a coluna de 5 dias, e, na frase A, a contagem de 1º turnos
  históricos no percentil 95 ou mais (três de seis, contra 0,3 esperado por acaso), para que 2026 apareça dentro de um padrão já
  conhecido de dia seguinte agitado e não como fato isolado.
- Dizer "o dólar caiu 4,55% (4,66 em logaritmo)". O PTAX foi de R$ 5,2238 para R$ 4,9859.
- Considerar segurar a circulação do trecho de 2026 até a linha do 2º turno sair (26 a 30/10), ou rebaixá-lo do texto para a tabela.

**V2. Anexo T7 termina no ponto mais baixo de um governo e deixa a faixa do seguinte vazia. Severidade média.**
A série vai de 2009 a 2021 porque 2022 a 2025 dependem do DOU, que não respondeu. O gráfico desenha a faixa do Lula 3 sem dado,
e o texto fecha em "estava em 0,64% em 2021", o menor valor da série, depois de "caiu a 0,90% em 2016", pulando as altas de 2018
(1,21%) e 2020 (1,10%). A disponibilidade de dado cria uma comparação de governos assimétrica, que o leitor vai fazer sozinho.
Correção, completar 2022 a 2025 antes de circular (portarias do 6º bimestre, ou, como ponte declarada, o relatório da própria
Petrobras, que responde por 83% a 91% do total) ou tirar a faixa do Lula 3 do gráfico e escrever "oscilou entre 0,70% e 1,21% de
2017 a 2020 e foi a 0,64% em 2021. Sem dado consolidado desde 2022, nenhum governo recente entra na comparação".

**V3. Anexo T1, OCDE. A alta de 2021 a 2024 é sobretudo municipal, e o texto não diz. Severidade média.**
O texto diz que a alta de 0,109% para 0,218% do PIB em 7082 é medida e que a causa é C. O pacote já tem a decomposição
(C-governo-geral-cofog.csv). No grupo 708, os municípios foram de R$ 12,0 bi (2021) para R$ 33,0 bi (2024), os estados de R$ 7,4 bi
para R$ 12,4 bi e o Governo Central de R$ 2,0 bi para R$ 3,9 bi. Sem isso, o leitor tende a creditar a alta à política federal. A
posição de 2024 depende da alta. Com o nível de 2021, o Brasil seria o último dos 32 em 7082. Correção, uma frase: "A alta veio
sobretudo dos municípios (no grupo 708, de R$ 12,0 bi em 2021 para R$ 33,0 bi em 2024), e com o nível de 2021 o Brasil ficaria em
último. Não foi testado se parte da alta é mudança de classificação."

**V4. O backtest do Focus não conversa com o cenário base. Severidade média-baixa.**
O T6 justifica a si mesmo dizendo que a seção 12 usa o Focus, e mede que o Focus de outubro errou a Selic de fim de ano para baixo
(mediana de +1,5 ponto no ano seguinte e +1,75 dois anos à frente) e o primário para cima (-0,49 e -0,87 ponto do PIB). Os dois
erros, se repetidos, põem a dívida acima do cenário 2. Nenhuma frase liga as duas coisas, e o leitor que só vê a seção 12 fica com
o cenário base do Focus sem o histórico de viés dele. Correção, no T6 ou em "Se a Selic não cair": "De 2000 a 2024 o Focus de
outubro subestimou a Selic e superestimou o primário na mediana. Se isso se repetir, a dívida de 2030 fica acima do cenário 2. É
associação histórica (classe B) e não previsão."

**V5. Seção 9. "Acima do que estabilizaria ... o último em 2022" pode ser lido como mérito fiscal. Severidade baixa.**
2021 e 2022 entram na contagem pelo PIB nominal (18,4% e 11,9% de crescimento, inflação alta), com primário de -0,4% e +0,5%. Sem
isso dito, a frase sugere superávit suficiente. Correção, "o último em 2022. Em 2021 e 2022 isso veio do crescimento nominal alto,
com a inflação, e não de superávit grande (primário de -0,4% e 0,5% do PIB)".

**V6. "Governo contra mercado". Severidade baixa.** O título do item opõe dois atores. O conteúdo compara duas grades de premissas.
Trocar por "PLDO contra Focus".

## Excessos

**X1. Ordem das alavancas com classe A. Severidade média.** "Macro antes de prêmio, prêmio antes de ajuste, canal fiscal por
último", ao lado de um A. Cada barra é aritmética condicional (A). A ordem não é, porque depende do tamanho de choque escolhido.
Com 1 ponto, "Selic e mercado" move 2,9, menos que o ajuste (3,6 a 3,7). Só com 1,5 ponto passa à frente (4,3). Crescimento real de
1 ponto (3,9 e 4,1) move mais que juros de 1 ponto. E o ajuste é 1/5 das renúncias, uma escolha de tamanho tão arbitrária quanto as
outras. Correção, "Com os tamanhos de choque escolhidos aqui, a macro move mais que juros e ajuste, e o canal fiscal estimado move
menos que todos. A ordem entre juros e ajuste depende do tamanho de cada choque", com o A na aritmética e sem A na ordem.

**X2. "O essencial", dispersão dos cenários. Severidade baixa.** "O ajuste pela receita ou pela despesa, com taxas menores, muda
7,8 pontos." 4,3 desses pontos são a queda de taxas suposta, e o ajuste sozinho move 3,6 a 3,7. Na despesa são 7,9. Correção, "O
ajuste pela receita ou pela despesa move 3,6 a 3,7 pontos sozinho, e 7,8 a 7,9 com taxas 1,5 ponto menores, que são premissa".

**X3. Figura 1, eixo começando em 10%. Severidade baixa.** Em linhas de taxa é aceitável, mas a página quer mostrar a distância
entre curva e Focus, e o eixo truncado a faz ocupar a altura toda. Pôr os valores de diferença (+110 a +343 pb) no gráfico ou
avisar o corte do eixo. A nota "Os nomes e as faixas de governo datam os valores" aparece num gráfico sem faixas.

**X4. "o dólar caiu 4,66%". Severidade baixa.** É a diferença em logaritmo. A queda percentual é 4,55%. Ver V1.

**X5. Anexo T1, "a renúncia fiscal, que no Brasil é a maior parte do fomento federal à cultura". Severidade baixa.** Vale contra a
despesa federal (R$ 6,54 bi de renúncia na função Cultura contra a função Cultura liquidada), mas na frase vizinha a comparação é
do governo geral, em que estados e municípios gastam R$ 45 bi no grupo 708. Dizer "do fomento da União".

## Conferidos

Refeitos fora do gerador, a partir dos CSV e, quando marcado, dos brutos. "Bate" quer dizer igual depois de arredondar como o
texto.

| # | Onde | Número no texto | Refeito | Fonte da conferência | Resultado |
|---|---|---|---|---|---|
| 1 | Seção 9 | 8 dos 19 anos acima do que estabiliza | 8 de 19 | J-dbgg-fatores, K-primario-recorrente, I-divida-historico | bate |
| 2 | Seção 9 | o último em 2022 | 2022 | idem | bate |
| 3 | Seção 9 | distância de 3,7 pontos em 2025 | 3,67 (3,57 com d_t-1) | idem | bate, ver E4 |
| 4 | Seção 9 | 3,1 pontos em 2030, cenário 2 | 4,40 - 1,26 = 3,14 | S-cenarios-divida | bate |
| 5 | Seção 9 | i 12,55%, g 8,14%, dívida 78,6% | 12,55, 8,14, 78,64 | idem | bate |
| 6 | Seção 9 | primário que estabiliza 3,2% em 2025 | 3,21 (3,11 com d_t-1) | idem | bate, ver E4 |
| 7 | Seção 12 | macro do PLDO -11,5 | -11,47 | S2-sensibilidade-2030 e S-cenarios (98,31 - 86,84) | bate |
| 8 | Seção 12 | deflator +1 e crescimento +1, -3,9 | -3,93 e -3,93 | idem | bate |
| 9 | Seção 12 | crescimento real -1, +4,1 | +4,13 | idem | bate |
| 10 | Seção 12 | Selic -1, -1,9; Selic e mercado -1, -2,9; só mercado -1, -1,0 | -1,93; -2,87; -0,96 | idem, e soma -1,93 - 0,96 = -2,89 | bate |
| 11 | Seção 12 | prêmio -1,5, -4,3 | -4,27 (= cenário 3, 94,04) | idem | bate |
| 12 | Seção 12 | ajuste sem queda de juros, uns 3,6 | -3,58 e -3,67 | idem | bate |
| 13 | Seção 12 | âncora de setembro +0,9; canal fiscal 0,18 | +0,92; -0,18 | idem | bate |
| 14 | Seção 12 | Selic parada 103,7%, 5,4 pontos acima | 103,72; 5,41 | S2-divida-sem-queda-juros | bate |
| 15 | Seção 12 | juro real parado 102,6%; primário de 2025 108,8% | 102,57; 108,77 | idem | bate |
| 16 | Seção 12 | Selic de 13,75% desde 17/09 | 13,75 (Copom 281) | brutos/S2/LEIAME, histórico do BCB | bate |
| 17 | Seção 12 | dívida de partida 95% contra 79% | 95,17 (2029) e 78,64 (2025) | S-cenarios | bate, ver E4 |
| 18 | Seção 12 | PLDO 87,0% em 2029, pico em 2029 | 86,96 e 86,84 em 2030 | S-cenarios, cenário 6 | bate |
| 19 | PLOA | receita líquida R$ 2.848,7 bi, +255,1 | 2.848,68; 255,08 | PO-ponte-receita-2027 | bate |
| 20 | PLOA | 208,5 com o PIB (63,8 real, 144,7 preços) | 208,49 = 63,80 + 144,69 | idem | bate |
| 21 | PLOA | 46,6 além do PIB, 0,32 ponto | 46,59; 46,59 / 14.782,9 = 0,315% | idem, PIB da grade SPE | bate |
| 22 | PLOA | soma dos blocos | 69,59 - 66,01 - 41,77 + 84,77 = 46,58 | idem | bate, ver E1 |
| 23 | PLOA | CBS e IS 69,6; IS 42,0; IR -48,1; dividendos -29,0; renúncias 4,22 | 69,59; 42,0; -48,14; -29,0; -4,222 | idem | bate |
| 24 | Nota de capital | 12,89% contra 12,92% | 12,89; 12,92; -3 pb | MK-curva-termo | bate, "uns 10 pb" não (E5) |
| 25 | Nota de capital | 1,1 a 3,4 pontos do 2º ano em diante | 110 a 343 pb | idem | bate |
| 26 | Nota de capital | implícita 5,6% a 6,1% do 3º ao 5º ano | 5,59 a 6,14 | idem | bate |
| 27 | Nota de capital | 102 a 264 pb | 102 é do 2º ano, 3º a 5º dão 202 a 264 | idem | mistura janelas (E5) |
| 28 | Nota de capital | Focus 2027, PIB 1,4% e IPCA 4,3% | 1,4 e 4,30 em 09/10/2026 | bruto, bcb-focus-olinda-anuais-out2026.json | bate |
| 29 | T1 | 7082 Brasil 0,22%, Canadá 0,27%, mediana 0,52% em 30 | 0,218; 0,272; 0,523; 30 | CI-resumo, CI-cultura-internacional | bate |
| 30 | T1 | 29 de 32 | abaixo do Brasil, Colômbia, Grécia e Irlanda | idem, ordenação de 2024 | bate |
| 31 | T1 | 48,8, 178,1 e 368,4 USD PPC; só a Colômbia abaixo | 48,8; 178,1; 368,4; COL 41,6 | idem | bate |
| 32 | T1 | com 7083, 0,23% e mediana 0,68% | 0,232; 0,680 | idem | bate |
| 33 | T1 | 708, 0,40%, 31 de 34, acima de EUA, Chile e Japão | 0,402; 31 de 34; USA 0,254, CHL 0,324, JPN 0,390 | idem | bate |
| 34 | T1 | alta de 0,109% (2021) para 0,218% (2024) | 0,109; 0,218; municípios 708 de 12,0 para 33,0 bi | CI e C-governo-geral-cofog | bate, ver V3 |
| 35 | T6 | IPCA, ano seguinte, erro 0,5, absoluto 1,0, p10 a p90 -0,5 a 4,1 | 0,47; 0,96; -0,47 a 4,13 | FB-resumo | bate |
| 36 | T6 | posições do IPCA nos anos de eleição 4, 23, 9, 3, 25, 18 | 4, 23, 9, 3, 25, 18 | idem | bate |
| 37 | T6 | Selic 1,5 e 2,8; primário -0,49 e -0,87; PIB -0,3, -3,3 a 2,6 | 1,5 e 2,75; -0,49 e -0,87; -0,3, -3,28 a 2,64 | idem | bate |
| 38 | T6 | 2014, maior erro de câmbio e 2º de PIB; 2018, maior de primário h2 | posições 1, 2 e 1 | idem | bate |
| 39 | T6 | origem 2014: Focus IPCA 2015 6,3, realizado 10,673, erro 4,373 | 6,3 em 03/10/2014; 10,673 pelo número-índice | brutos focus_anuais_2014.json e sidra_1737_v2266.json | bate |
| 40 | T6 | origem 2014: câmbio 2,5 contra 3,9048; PIB 1,0 contra -3,5 | iguais | bruto focus_anuais_2014.json e FB-erros | bate |
| 41 | T6 | curva, erro mediano 0,16, absoluto 0,70 | 0,160; 0,697 | FB-resumo | bate |
| 42 | T6 | 1º turno, câmbio 1,96% contra 0,44%; 2026 -4,66, 1º de 7 | 1,962; 0,442; -4,661; 1 | EL-resumo | bate |
| 43 | T6 | PTAX de 02/10 para 05/10/2026 | 5,2238 para 4,9859, 100 ln = -4,66 (queda de 4,55%) | bruto sgs1_2021_20261024.json | bate, ver X4 |
| 44 | T6 | pré 1 ano 12, 4, -66; pré 10 anos 32, 8, -117; real 15, 4, -66; implícita 12, 4, -44 | 12,4; 3,6; -65,8; 31,8; 7,5; -117,0; 15,0; 3,9; -66,3; 12,1; 4,0; -43,6 | EL-resumo e EL-variacoes | bate |
| 45 | T7 | 2,13% em 2009 e 2013, R$ 220,3 bi; 0,90% em 2016; 0,64% em 2021 | 2,135; 2,13; 220,3; 0,901; 0,638 | EE-investimento-estatais | bate (2010 foi 2,16%, o pico) |
| 46 | T7 | Petrobras 83% a 91%; bancos R$ 3,4 a 7,2 bi | 83,2 a 90,8; 3,42 a 7,24 | idem | bate |
| extra | Simulador | paridade com os CSV | 9 cenários e 17 choques, diferença máxima 0,005 | teste_paridade.py | passou |
| extra | Estrutura | sumário, títulos e páginas | 23 títulos nas páginas do sumário; 1.686 âncoras resolvem, 3 não | PDF (outline) e HTML | ver E3 |
| extra | Voz | travessão, dois-pontos e ponto e vírgula nas partes novas | nenhum no texto corrido | HTML | ok |

## Veredito

A v13 está bem amarrada nos números. Os 46 itens refeitos batem com os CSV, os brutos conferidos (Focus, SIDRA, PTAX, COFOG)
batem com os CSV, o simulador reproduz os cenários publicados, a numeração de figuras e tabelas é contínua e as remissões "seção N" e
"anexo X" apontam para o lugar certo, com uma exceção. A voz está limpa nas partes novas, e nenhum trecho nomeia candidato ou
atribui causa a governo.

Não deve circular antes de quatro correções, nesta ordem.
1. V1, o trecho dos turnos da eleição. Frase explícita de que a direção não mede preferência, o caráter post hoc dito por inteiro, e
   o 2º turno histórico ao lado. É o ponto em que um leitor de mercado tira do documento uma leitura eleitoral que ele não sustenta,
   na véspera da votação.
2. E1, a ponte do PLOA. Hoje o leitor sai achando que o ganho de receita vem da reforma, quando vem da queda das transferências, com
   fundo de compensação do outro lado.
3. X1 e E7, a ordem das alavancas sem classe A e os rótulos certos na Figura 21.
4. E2 e E3, a remissão velha, as concordâncias e os links do sumário. O CHANGELOG afirma que a troca foi completa, e não foi.

O resto (E4 a E6, E8 a E11, V2 a V6, X2 a X5) cabe numa passada só. V2 e V3 mexem em comparação implícita entre governos e merecem
ir junto com as quatro primeiras se der tempo. Depois das correções, regerar o zip para levar o CHANGELOG v13 e trocar as menções a
"leitura Casey Reas" no código e no DESIGN.md.

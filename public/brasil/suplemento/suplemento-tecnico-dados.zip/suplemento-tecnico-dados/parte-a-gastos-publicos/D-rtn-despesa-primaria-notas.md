# Frente D. Despesa primária do Governo Central pelo RTN

Data: 17/10/2026. Arquivo de dados: `D-rtn-despesa-primaria.csv` (1.075 linhas). Brutos: `brutos/D/`.

## O que é esta frente

O Resultado do Tesouro Nacional (RTN) é a régua que o próprio governo usa para medir o gasto federal sob o arcabouço fiscal. Ele cobre o Governo Central, que é Tesouro + Banco Central + Previdência (RGPS). O critério é **pagamento efetivo** (caixa), e inclui restos a pagar pagos no ano. Juros da dívida não entram: aqui só há despesa **primária**.

## Fontes

| Dado | Fonte | Publicado |
|---|---|---|
| RTN série histórica até ago/2026 (tabelas 1.2, 1.2-A, 1.5, 2.2, 2.2-A, 2.5) | Tesouro Nacional, anexo da publicação RTN agosto/2026, https://thot-arquivos.tesouro.gov.br/publicacao-anexo/29326 (`brutos/D/seriehistoricaago26.xlsx`) | 29/09/2026 |
| Sumário executivo RTN ago/2026 | `brutos/D/sumario_executivo_ago26.pdf` | 29/09/2026 |
| PIB anual 2019-2025 | IBGE, Contas Nacionais Trimestrais, SIDRA tabela 1846 (`brutos/D/ibge_sidra1846_pib_trimestral.json`). Bate exatamente com o memorando de PIB da tabela 2.2-A do RTN | consultado 17/10/2026 |
| PIB jan-ago/2026 | BCB SGS 4380, PIB mensal em valores correntes (`brutos/D/bcb_sgs4380_pib_mensal.json`) | consultado 17/10/2026 |
| Piso saúde e educação 2025 | RREO dezembro/2025 (republicado), Anexo 8 (MDE) e Anexo 12 (ASPS) (`brutos/D/RREO_dez2025_republ.pdf`, págs. 27-28 e 39-40) | jan/2026 |
| Piso saúde e educação 2026 | RREO agosto/2026, Anexos 8 e 12 (`brutos/D/RREO_ago2026.pdf`, págs. 29-32) | set/2026 |
| Piso previsto 2026 | PLOA 2026, Agência Gov 29/08/2025 | 29/08/2025 |
| Limite LC 200/2023 em 2025 | PLDO 2027, Anexo IV.1, avaliação do cumprimento das metas de 2025 (`brutos/D/pldo2027_anexo_iv01.pdf`) | abr/2026 |
| Despesa paga sujeita ao limite 2025 e jan-ago/2026 | Tesouro Transparente, dataset "Despesas e Transferências Totais da União", `limite-gastos-lc200dez25.xlsx` e `limite-gastos-lc200ago26.xlsx` | 25/02/2026 e 29/09/2026 |
| Limite e projeção 2026 | Relatório de Avaliação de Receitas e Despesas Primárias do 4º bimestre/2026, apresentação (`brutos/D/rardp_4bim2026_apresentacao.pdf`) | 24/09/2026 |
| Notas técnicas de método LC 200 | `brutos/D/nt_lc200_*.pdf` | dez/2025, mar/2026, ago/2026 |

O RTN de setembro/2026 ainda não saiu (sai no fim de outubro). Por isso 2026 é **jan-ago**.

## Método

- `estagio = "RTN pago"`: linhas da tabela 2.2 (anual, 2019-2025) e soma dos meses jan-ago da tabela 1.2 (2026). Conferi que a soma mensal reproduz o anual.
- `estagio = "RTN valor pago (tab 2.5)"`: só para abrir Pessoal em ativos civis, militares, aposentados civis e pensões militares. O RTN principal não abre esse corte. A tabela 2.5 usa o critério "valor pago" (diferença de 0,2% para o pagamento efetivo).
- `estagio = "RTN pago, R$ de ago/2026 (IPCA)"`: tabela 1.2-A, onde o próprio Tesouro corrige cada mês pelo IPCA até agosto/2026. Somei os meses de cada ano. Não é "R$ médio de 2026", é **R$ de agosto de 2026**. Nessas linhas `pct_pib` fica vazio.
- `estagio = "RTN pago (calculo)"`: somas minhas sobre linhas do RTN (obrigatórias, discricionárias, precatórios totais).
- `pct_total` = % da **Despesa Total** (linha 4) do mesmo ano. `pct_pib` = % do PIB nominal do ano (2026: PIB de jan-ago). Os dois já estão em pontos percentuais (18.795 quer dizer 18,795%).
- `valor_brl` em reais (milhões do RTN x 1.000.000, arredondado).
- Pisos e limite: valores do RREO em R$ milhares convertidos para reais.

## Fato x cálculo

- **Fato publicado**: tudo que tem `estagio` "RTN pago", "RTN valor pago", "RTN pago, R$ de ago/2026", RREO, LC 200 e PIB anual.
- **Cálculo meu**: as linhas "Calculo:", as porcentagens (`pct_total`, `pct_pib`), o PIB jan-ago/2026 (soma de série mensal), a RCL implícita 2025 (mínimo da saúde / 0,15) e as razões "% do mínimo" e "% do limite" nas notas.

## Cuidados de leitura

1. **Linhas "d/q" ("dos quais") não somam.** Os precatórios 4.1.1.1 e 4.1.2.1 já estão dentro de 4.1.1 e 4.1.2. O 4.2.1 está dentro de 4.2. O 4.3.05.1 está dentro do BPC. O 4.3.01.1 e o 4.3.01.2 abrem o 4.3.01. O mesmo vale para o 4.3.15.x e o 4.4.x.x. Some só as linhas `subcategoria = total` dos níveis 4.1, 4.2, 4.3 e 4.4. Essas quatro dão a linha 4.
2. **Transferências a estados e municípios (linha 2) não fazem parte da Despesa Total.** O RTN as deduz da receita. O `pct_total` delas existe só para dar escala.
3. **Obrigatórias x discricionárias**: discricionárias = linha 4.4.2, só do Poder Executivo, e inclui as emendas parlamentares. Todo o resto é obrigatório, incluindo as "obrigatórias com controle de fluxo" (4.4.1: Bolsa Família, saúde obrigatória etc.).
4. **Saúde e educação aparecem picadas**: a parte obrigatória está em 4.4.1.3/4.4.1.4, a discricionária em 4.4.2.1/4.4.2.2, o Fundeb em 4.3.10, e o pessoal da saúde e da educação está dentro de 4.2. O RTN **não é** um corte por função. Para função completa, usar a frente COFOG ou o RREO Anexo 2.
5. **2026 em % do PIB é parcial e sazonal**: 13º do INSS, precatórios (pagos sobretudo no 1º semestre) e o FEFC eleitoral de agosto distorcem a comparação de 8 meses com ano cheio.
6. **2020** está inflado pela pandemia: R$ 429,6 bi de créditos extraordinários, a maior parte em Auxílio Emergencial.
7. **O limite da LC 200 é orçamentário** (incide sobre dotações). A despesa "paga sujeita ao limite" inclui restos a pagar. A razão pago/limite serve só como ordem de grandeza.

## Lacunas

- **RGPS urbano/rural**: a divisão é do Ministério da Previdência, com metodologia própria. Nas tabelas 2.5/1.5 (valor pago) ela só existe até 2021.
- **Pessoal ativos/inativos**: só no critério "valor pago". Não há corte por Poder no RTN, só nos arquivos da LC 200.
- **Piso 2026 anual**: o RREO bimestral traz o mínimo "até o mês", não o anual. Usei o PLOA 2026 (saúde R$ 245,5 bi, educação R$ 133,7 bi) e as dotações atualizadas do RREO (R$ 254,3 bi e R$ 146,0 bi). **Não confirmei o piso da LOA 2026 sancionada.**
- **Limite 2025**: o valor final de R$ 2.261,4 bi vem do PLDO 2027. Não baixei o RARDP extemporâneo de dezembro/2025.
- **Minha Casa Minha Vida**: deixa de ser divulgado separado a partir de 2026 (nota 17 do RTN). Não incluí.
- **Investimento e custeio administrativo** (memorandos do RTN) não foram para o CSV.
- O PDF do RREO tem fonte embutida sem mapeamento de texto. Li os anexos por imagem renderizada, sem extração automática. Os números foram transcritos à mão de 8 linhas: conferir se forem citados.

## 10 linhas-chave para leigo

1. Em 2025 o governo federal gastou **R$ 2,39 trilhões** em despesa primária (sem juros), o que dá **18,8% do PIB**.
2. **Previdência (INSS) é o maior item**: R$ 1,03 tri, 43% de tudo e 8,1% do PIB. São R$ 808 bi de aposentadorias urbanas e R$ 219 bi de rurais.
3. **Servidores federais** custaram R$ 403 bi (3,2% do PIB). Desse total, R$ 218 bi são ativos (civis e militares) e R$ 175 bi são aposentados e pensionistas.
4. **Programas sociais diretos**: Bolsa Família R$ 158 bi, BPC (idoso e deficiente pobre) R$ 127 bi, abono e seguro-desemprego R$ 88 bi. Juntos, R$ 373 bi, 2,9% do PIB.
5. **91,4% do gasto é obrigatório** por lei ou pela Constituição. O que o governo de fato escolhe (discricionárias, com emendas) foi R$ 205 bi, **8,6%** do total e 1,6% do PIB.
6. Dentro das discricionárias, saúde leva R$ 58 bi, educação R$ 33 bi, transporte R$ 15 bi, defesa R$ 14 bi, ciência R$ 10 bi e segurança pública só R$ 4 bi.
7. **Precatórios e sentenças judiciais** (dívida que a Justiça manda pagar) somaram R$ 101 bi em 2025. Em 2023, com a quitação do estoque, foram R$ 152 bi.
8. Além disso, a União **repassou R$ 570 bi** a estados e municípios (FPE, FPM, royalties). Isso não conta como despesa dela, mas é dinheiro que sai do caixa federal.
9. **Pisos constitucionais 2025 cumpridos com pouca folga na saúde**: a lei mandava gastar R$ 227,7 bi (15% da RCL) e foram aplicados R$ 234,5 bi (103%). Na educação o mínimo era R$ 122,1 bi e foram aplicados R$ 129,9 bi (106%).
10. **Arcabouço fiscal**: o limite de 2025 era R$ 2,26 tri e se pagaram R$ 2,23 tri sujeitos a ele. Para 2026 o limite é R$ 2,39 tri, a projeção de setembro estoura em R$ 2,4 bi (o que exige bloqueio), e até agosto já se gastaram 66% do limite. Ficam fora do limite R$ 730 bi (2025), sobretudo transferências constitucionais, Fundeb e precatórios acima do sublimite.

Em valores corrigidos pelo IPCA (R$ de ago/2026), a despesa total foi de R$ 2,11 tri em 2019 para R$ 2,50 tri em 2025: **+18,6% real em seis anos**. Benefícios previdenciários subiram 17% reais no período, e pessoal **caiu** 8% real.

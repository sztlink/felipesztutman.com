# Brief v11: identificação de choques fiscais (protocolo de pré-análise)

Aprovado pelo autor em 19/10/2026, a partir de uma proposta externa de inferência causal. Base: v10.7 (commit 28925634).
Frentes: N2 (estudo de eventos fiscais), Y2 (inventário narrativo de medidas fiscais), S2 (propagação de incerteza no simulador).
X2 (surpresas do Fed) e réplica do BIS WP 1364 ficam fora desta etapa.

## Protocolo N2, fixado antes de olhar resultados
- Inventário de eventos por regra, não por escolha: todo anúncio oficial do Executivo de proposta fiscal com impacto estimado
  de pelo menos 0,1% do PIB, toda votação de mérito na Câmara ou no Senado e toda promulgação ou sanção de medida fiscal com esse
  impacto, de 2015 a 2026. Fontes: Câmara, Senado, Planalto, Fazenda. Datas sem resultado significativo ficam no inventário.
- Indicadores principais, definidos antes: variação do juro real NTN-B de 10 anos e da inflação implícita de 10 anos (Tesouro
  Direto, diário). Secundários: prefixado de 10 anos, câmbio.
- Janelas: 1 dia útil (t-1 a t+1) como principal; 5 dias como robustez; persistência em 20 e 60 dias.
- Controles: juro real americano de 10 anos (DFII10), VIX e dólar amplo, diários (FRED). Retorno anormal = variação menos a
  prevista por regressão em janela de estimação fora dos eventos.
- Placebo: mesma conta em datas sorteadas sem evento (distribuição de 1.000 sorteios); inferência pela posição do evento nessa
  distribuição; correção para testes múltiplos (Holm ou Benjamini-Hochberg) declarada.
- Surpresa: variação da mediana do primário esperado no Focus (anual, t+1) entre a pesquisa anterior e a posterior ao evento;
  escala em pontos do PIB quando houver.
- Assimetria: anúncios de melhora e de piora fiscal estimados em separado.
- Regra de parada: se as surpresas não forem mensuráveis ou os retornos anormais forem indistinguíveis do placebo, o resultado é
  "inconclusivo" (classe C) e não se força coeficiente.

## Y2
Inventário de 10 a 20 medidas fiscais brasileiras de 2015 a 2026 com economia anunciada, aprovada e realizada ou reestimada, por
fonte oficial; motivação (consolidação ou resposta ao ciclo, pelo texto da exposição de motivos); tipo (receita, custeio,
transferências, pessoal, investimento, previdência). Estimativa só se houver poder estatístico; senão, o inventário é o produto.

## S2
Monte Carlo sobre as faixas já existentes (canal fiscal 11 a 47 pb, multiplicador 0 a 1,2, deflator, taxas de mercado),
sem somar canais que se sobrepõem; saída: distribuição da dívida de 2030 por cenário.

## Saída no relatório
Uma página na seção 15, com classes A, B e C; método no Anexo C. Auditoria independente antes da entrega.

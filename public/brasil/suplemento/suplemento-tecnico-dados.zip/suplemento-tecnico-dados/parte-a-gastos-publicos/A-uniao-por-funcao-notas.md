# Frente A, gasto da União por função orçamentária (2019 a 2026)

Feito em 17/10/2026. Arquivo de dados: `A-uniao-por-funcao.csv` (1.721 linhas). Brutos e scripts em `brutos/A/`.

## Fonte e método

**Fonte principal (fato):** RREO da União (Relatório Resumido da Execução Orçamentária, Tesouro Nacional), lido pela API pública do Siconfi:
`https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo?an_exercicio=AAAA&nr_periodo=P&co_tipo_demonstrativo=RREO&no_anexo=RREO-Anexo%20NN&id_ente=1`

- Anexo 02 (despesa por função e subfunção) dá as 28 funções e suas subfunções.
- Anexo 01 (balanço orçamentário) dá a linha XII "Amortização da dívida / refinanciamento", que é a rolagem, e os grupos de natureza (juros, amortização).
- 2019 a 2025: 6º bimestre (ano fechado). 2026: 4º bimestre (jan a ago), o último publicado. O 5º bimestre ainda não está na API (consulta de 17/10/2026).

**Estágio usado: LIQUIDADO.** O Anexo 2 não traz valor pago, então não dá para usar "pago + restos a pagar pagos" por função com esta fonte. Liquidado = despesa reconhecida (bem entregue ou serviço prestado) no próprio ano. Não inclui restos a pagar não processados inscritos no fim do ano (2025: R$ 196,2 bi no total, R$ 78,2 bi em Encargos especiais), nem restos a pagar de anos anteriores pagos no ano.

**Escopo:** Orçamento Fiscal + Seguridade Social, todos os Poderes (Executivo, Legislativo, Judiciário, MPU, DPU), **exceto despesas intra-orçamentárias** (pagamentos de um órgão federal a outro, como a contribuição patronal ao regime próprio, R$ 31,7 bi em 2025). Retirá-las evita dupla contagem. Não inclui estatais independentes (Orçamento de Investimento).

**PIB (fato):** IBGE SIDRA. 2019 a 2023 pela tabela 6784 (PIB anual, valores correntes). 2024 e 2025 pela soma dos 4 trimestres da tabela 1846 (valores correntes, preliminar, sujeito a revisão). 2025 = R$ 12,739 tri. Para a dotação de 2026 usei o PIB dos últimos 4 trimestres disponíveis (2025T3 a 2026T2 = R$ 13,190 tri), que é aproximação minha. A execução parcial de 2026 não tem % do PIB.
- https://apisidra.ibge.gov.br/values/t/6784/n1/all/v/9808/p/2019-2025
- https://apisidra.ibge.gov.br/values/t/1846/n1/all/v/585/p/201901-202602/c11255/90707

**Fonte de apoio:** Portal da Transparência, download "Orçamento da Despesa" (zips de 2019 a 2026 em `brutos/A/orc-AAAA.zip`). Não usei como fonte dos números porque cobre essencialmente o Executivo (Judiciária aparece com R$ 0,1 bi, Legislativa nem aparece). Serviu só para abrir a composição das subfunções 843, 845 e 846 por ação (ver abaixo).

## Como ler o CSV

- `estagio`: `liquidado` (2019 a 2025), e para 2026 `dotacao_inicial`, `dotacao_atualizada` (LOA mais créditos, posição de agosto) e `liquidado_jan_ago`.
- Linhas com `subcategoria` vazia são as funções. Elas somam exatamente o TOTAL "sem refinanciamento da dívida" (conferido para todos os anos e estágios).
- Linhas com `subcategoria` preenchida são aberturas. Fora de Encargos especiais, o Tesouro só abre as subfunções típicas, mais "Administração geral" e "Demais subfunções".
- `pct_total`: sobre o total SEM refinanciamento, exceto nas linhas que contêm rolagem (TOTAL com refinanciamento, Encargos especiais com refinanciamento, 841 e 842), que usam o total COM refinanciamento. A `nota` de cada função traz também o % sobre o total com refinanciamento, então as duas colunas existem para todas as linhas.
- Categoria "Referência: natureza da despesa" (juros GND 2 e amortização GND 6) é outro recorte, não somar com as funções.

## O que é fato e o que é cálculo meu

Fato (valor publicado no RREO ou no SIDRA): todos os valores de função e subfunção, a linha XII, juros e amortização por natureza, o PIB.

Cálculo meu:
1. Total com refinanciamento = linha IX + linha XII do Anexo 1.
2. Encargos especiais com refinanciamento = Encargos especiais (Anexo 2) + linha XII.
3. Todos os percentuais.
4. **2022:** naquele ano o Tesouro publicou o Anexo 2 com o refinanciamento dentro da função (Encargos especiais = R$ 2.455,8 bi). Retirei R$ 1.425,1 bi (linha XII), sendo R$ 1.411,8 bi das subfunções 841/842 e R$ 13,3 bi que estavam na 843. Resultado: Encargos sem rolagem R$ 1.030,7 bi, coerente com a linha IX.
5. 2026 dotação inicial: R$ 9,8 bi aparecem na subfunção "Refinanciamento da dívida interna" dentro do total sem rolagem. Mantive onde o Tesouro pôs, em linha própria.
6. Nomes das subfunções 841 a 847 com código e descrição foram acrescentados por mim (o RREO publica só o nome).

## Encargos especiais aberto, e a questão do "metade do orçamento vai para a dívida"

2025, liquidado, R$ bi:

| Item | R$ bi | % total sem rolagem | % total com rolagem | % PIB |
|---|---|---|---|---|
| 841 Refinanciamento dívida interna (rolagem) | 1.364,1 | (fora) | 26,6 | 10,7 |
| 842 Refinanciamento dívida externa (rolagem) | 53,5 | (fora) | 1,0 | 0,4 |
| 843 Serviço da dívida interna | 573,0 | 15,5 | 11,2 | 4,5 |
| 844 Serviço da dívida externa | 20,4 | 0,6 | 0,4 | 0,2 |
| 845 Outras transferências (FPM, FPE, royalties...) | 469,9 | 12,7 | 9,2 | 3,7 |
| 846 Outros encargos especiais | 345,8 | 9,3 | 6,7 | 2,7 |
| 847 Transferências para a educação básica (Fundeb) | 102,0 | 2,8 | 2,0 | 0,8 |
| **Encargos especiais sem rolagem** | **1.511,1** | **40,8** | 29,5 | 11,9 |
| **Encargos especiais com rolagem** | **2.928,7** | | **57,2** | 23,0 |
| Total União sem rolagem | 3.705,4 | 100 | | 29,1 |
| Total União com rolagem | 5.123,1 | | 100 | 40,2 |

Por natureza (todas as funções): juros e encargos da dívida R$ 363,5 bi (2,85% do PIB), amortização paga sem refinanciamento R$ 354,0 bi.

Composição pelo Portal da Transparência (Executivo, valor "realizado", ordem de grandeza): a 843 em 2025 é cerca de R$ 330 bi de juros e R$ 246 bi de amortização. A 845 é sobretudo FPM (cerca de R$ 192 bi), FPE (R$ 159 bi) e royalties de petróleo (R$ 53 bi), mais o Fundo Constitucional do DF. A 846 junta coisas heterogêneas: cobertura do resultado negativo do Banco Central (cerca de R$ 124 bi), pensões militares, contribuição patronal ao regime dos servidores, fundos constitucionais de financiamento (FNE, FNO, FCO), Minha Casa Minha Vida, FCVS, Proagro, financiamento a exportações.

**Explicação para o gráfico.** O número de "mais da metade do orçamento vai para a dívida" (57% em 2025, 52% a 62% de 2019 a 2025) vem de pegar a função Encargos especiais inteira, com rolagem, sobre o total com rolagem. Ele mistura três coisas:
1. **Rolagem** (R$ 1,42 tri): trocar título que vence por título novo. É fluxo financeiro, não consome recurso de imposto nem tira dinheiro de saúde ou educação. Se o governo rola R$ 100 de dívida, ele emite R$ 100 e paga R$ 100.
2. **Repasses a estados e municípios** (R$ 572 bi entre 845 e 847): é dinheiro que a Constituição manda entregar a governadores e prefeitos, que gastam em saúde, educação, segurança. Não é dívida.
3. **Dívida de verdade**: juros (R$ 363 bi) e amortização não rolada (R$ 354 bi).

Juros sozinhos são cerca de 7% do total com rolagem, 10% do total sem rolagem, 2,9% do PIB. O peso da dívida é real e crescente (o custo de juros nominal do setor público medido pelo Banco Central, em competência, é bem maior que o liquidado no orçamento, mas não medi aqui), só que o gráfico da metade não mede isso.

## Série 2019 a 2025 (liquidado, R$ bi, % do PIB entre parênteses)

| Ano | Total sem rolagem | Total com rolagem | Encargos com rolagem, % do total c/ rolagem | Encargos sem rolagem | Previdência | Assistência | Saúde | Educação | Trabalho | Defesa |
|---|---|---|---|---|---|---|---|---|---|---|
| 2019 | 2.255 | 2.732 | 52,5% | 957 (12,9) | 725 (9,8) | 94 (1,3) | 113 (1,5) | 88 (1,2) | 72 (1,0) | 78 (1,1) |
| 2020 | 2.839 | 3.563 | 52,6% | 1.151 (15,1) | 764 (10,0) | 412 (5,4) | 151 (2,0) | 82 (1,1) | 75 (1,0) | 76 (1,0) |
| 2021 | 2.492 | 3.891 | 61,9% | 1.009 (11,2) | 804 (8,9) | 161 (1,8) | 161 (1,8) | 90 (1,0) | 65 (0,7) | 78 (0,9) |
| 2022 | 2.676 | 4.101 | 59,9% | 1.031 (10,2) | 894 (8,9) | 196 (2,0) | 136 (1,4) | 104 (1,0) | 92 (0,9) | 81 (0,8) |
| 2023 | 2.952 | 4.419 | 57,9% | 1.091 (10,0) | 973 (8,9) | 265 (2,4) | 160 (1,5) | 125 (1,1) | 95 (0,9) | 82 (0,8) |
| 2024 | 3.436 | 4.710 | 56,7% | 1.397 (11,9) | 1.046 (8,9) | 283 (2,4) | 194 (1,6) | 132 (1,1) | 108 (0,9) | 87 (0,7) |
| 2025 | 3.705 | 5.123 | 57,2% | 1.511 (11,9) | 1.101 (8,6) | 289 (2,3) | 217 (1,7) | 157 (1,2) | 116 (0,9) | 92 (0,7) |

2020 é o ano da pandemia (Assistência social saltou para R$ 412 bi com o auxílio emergencial). A rolagem varia muito de ano para ano por causa do perfil de vencimentos e da estratégia do Tesouro (R$ 477 bi em 2019, R$ 1,4 tri em 2021 a 2023 e 2025).

## 2026

Dotação atualizada (LOA mais créditos, posição de agosto): total sem rolagem R$ 4.638,1 bi, com rolagem R$ 6.449,5 bi. Encargos especiais R$ 2.100,3 bi sem rolagem e R$ 3.911,7 bi com rolagem (60,7% do total com rolagem). Previdência R$ 1.192,0 bi, Assistência R$ 292,2 bi, Saúde R$ 253,4 bi, Educação R$ 203,5 bi.

Liquidado jan a ago: total sem rolagem R$ 2.928,5 bi (63% da dotação atualizada), Encargos R$ 1.343,0 bi, Previdência R$ 807,6 bi, Saúde R$ 156,8 bi, Educação R$ 116,4 bi. Juros já liquidados R$ 415,8 bi em oito meses, contra R$ 363,5 bi no ano inteiro de 2025: o custo de juros no orçamento está acelerando com a Selic alta.

Atenção: dotação de serviço da dívida é sempre superestimada (843 tem R$ 1.017 bi de dotação em 2026 contra R$ 573 bi liquidados em 2025). Não comparar dotação de dívida com execução de anos anteriores.

## Lacunas

1. **Pago + restos a pagar pagos por função não foi obtido.** O RREO Anexo 2 só tem empenhado e liquidado. O Anexo 1 tem pago, mas só por natureza. Para pago por função seria preciso o Tesouro Gerencial ou o Siga Brasil (Qlik, sem API simples) ou a API do Portal da Transparência (exige chave, e não achei chave no Vaultwarden).
2. **Liquidado subestima saúde e educação** em anos de muito restos a pagar: em 2025, por exemplo, Saúde empenhou cerca de R$ 240 bi e liquidou R$ 217 bi. O resto vira restos a pagar e é pago no ano seguinte.
3. Subfunções fora de Encargos especiais vêm parcialmente agregadas pelo próprio Tesouro ("Demais subfunções", que em Educação concentra R$ 84 bi e em Assistência R$ 162 bi, onde estão Bolsa Família e outros).
4. PIB de 2024 e 2025 é preliminar (trimestral). PIB de 2026 para a dotação é aproximação de 4 trimestres móveis.
5. Valores nominais, sem correção pela inflação.
6. A classificação funcional põe pessoal e aposentadorias de cada órgão em funções diferentes conforme o órgão (aposentadoria de militar em Defesa ou 846, de servidor civil em Previdência). Comparação com COFOG (padrão internacional) exige outra fonte.
7. 2019 a 2023 vêm da versão do RREO hoje servida pelo Siconfi. Se houve republicação, vale a última.

## As 10 linhas mais importantes para um leigo (2025)

1. A União gastou R$ 3,7 tri em 2025 (29% do PIB), sem contar a troca de dívida velha por dívida nova. Com essa troca, R$ 5,1 tri.
2. A "rolagem" da dívida foi de R$ 1,42 tri. É trocar título vencido por novo. Infla o orçamento mas não tira dinheiro de nenhum serviço.
3. Com a rolagem, a função Encargos especiais é 57% do total, e é daí que sai o gráfico da "metade para a dívida". Sem a rolagem, é 41%.
4. Desse 41%, menos da metade é dívida: juros pagos foram R$ 363 bi (2,9% do PIB, cerca de 10% do gasto sem rolagem).
5. R$ 470 bi de Encargos especiais são repasses obrigatórios a estados e municípios (FPM, FPE, royalties), e outros R$ 102 bi vão para o Fundeb das escolas.
6. Previdência é o maior gasto "de verdade": R$ 1,10 tri (8,6% do PIB), 30% do total sem rolagem. Quase R$ 1 tri é o INSS.
7. Assistência social (BPC, Bolsa Família) levou R$ 289 bi (2,3% do PIB).
8. Saúde federal liquidou R$ 217 bi (1,7% do PIB) e Educação federal R$ 157 bi (1,2% do PIB). Boa parte do gasto de saúde e educação do país é de estados e municípios, que não estão aqui.
9. Trabalho (seguro-desemprego, abono) R$ 116 bi, Defesa R$ 92 bi, Judiciário R$ 45 bi. Ciência e tecnologia R$ 19 bi, Cultura R$ 2,3 bi.
10. Em 2026 os juros já liquidados até agosto (R$ 416 bi) passaram o ano inteiro de 2025: a conta de juros está subindo rápido.

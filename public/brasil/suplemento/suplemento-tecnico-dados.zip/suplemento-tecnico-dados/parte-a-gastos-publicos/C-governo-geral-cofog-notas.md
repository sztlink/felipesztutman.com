# Frente C: Governo Geral consolidado por função (COFOG) e comparação internacional

Levantado em 17/10/2026. Dados em `C-governo-geral-cofog.csv` (1.798 linhas). Brutos em `brutos/C/`.

## 10 linhas para leigo (Brasil, 2024, União + estados + municípios somados sem dupla contagem)

1. O setor público brasileiro gastou R$ 5,38 trilhões em 2024, 45,8% do PIB. A média simples dos países da OCDE fica em 42,6% (FMI).
2. Sem os juros, o Brasil gasta 37,5% do PIB. A média da OCDE sem juros fica em 40,5%. O "Estado caro" brasileiro é, em boa parte, a conta de juros.
3. Juros da dívida: R$ 972 bilhões em 2024, 8,3% do PIB e 18% de tudo que o setor público gasta. A média da OCDE é 2,2% do PIB. Chile 1,2%, Alemanha 1,1%, EUA 4,0%, México 6,5%.
4. Proteção social (aposentadorias, pensões, Bolsa Família, seguro-desemprego) é o maior item: 16,5% do PIB, R$ 1,94 trilhão. Só aposentadorias e benefícios da terceira idade somam 8,9% do PIB.
5. Saúde pública: 5,0% do PIB (R$ 591 bi). A média ponderada da OCDE é 8,5% e o país médio da OCDE gasta 7,0%. O Brasil gasta menos que Colômbia (8,0%) e próximo do Chile (5,3%).
6. Educação pública: 5,1% do PIB (R$ 599 bi). Fica no nível da OCDE (5,0%) e acima de Chile, Portugal e Alemanha.
7. Quem executa a saúde: municípios 54%, estados 30% e União 15%. Boa parte do dinheiro é da União, mas quem paga a ponta são os municípios (transferências SUS fundo a fundo).
8. Quem executa a educação: municípios 52%, estados 35% e União 13%. Olhar só o orçamento federal esconde 87% do gasto em educação.
9. Segurança e justiça custam 3,0% do PIB, acima da OCDE (1,7%). Só os tribunais custam 1,5% do PIB, o equivalente a todo o gasto de segurança de um país OCDE médio.
10. Defesa (0,5% do PIB), cultura (0,4%) e assuntos econômicos (2,3%, inclui transporte e infraestrutura) ficam bem abaixo da OCDE (2,3%, 0,7% e 4,3%).

## Último ano COFOG (2024), Governo Geral consolidado, % do PIB

| Função COFOG | R$ bi | % PIB | % da despesa |
|---|---:|---:|---:|
| 701 Serviços públicos gerais | 1.301,6 | 11,08 | 24,2 |
| . dos quais 7017 juros (transações da dívida) | 972,0 | 8,28 | 18,1 |
| . 701 sem juros | 329,6 | 2,81 | 6,1 |
| 702 Defesa | 59,4 | 0,51 | 1,1 |
| 703 Ordem pública e segurança | 347,0 | 2,95 | 6,5 |
| 704 Assuntos econômicos | 265,6 | 2,26 | 4,9 |
| 705 Proteção ambiental | 65,3 | 0,56 | 1,2 |
| 706 Habitação e serviços comunitários | 159,7 | 1,36 | 3,0 |
| 707 Saúde | 591,0 | 5,03 | 11,0 |
| 708 Lazer, cultura e religião | 47,2 | 0,40 | 0,9 |
| 709 Educação | 599,2 | 5,10 | 11,1 |
| 710 Proteção social | 1.941,6 | 16,53 | 36,1 |
| Total | 5.377,5 | 45,79 | 100 |

Série 2015 a 2024 completa no CSV, por esfera e por grupo (subfunção COFOG).

## Juros: COFOG x BCB x orçamento

| Ano | COFOG 7017 GG (R$ bi / % PIB) | BCB juros nominais SPC (R$ bi / % PIB) |
|---|---|---|
| 2015 | 715,0 / 11,92 | 501,8 / 8,37 |
| 2020 | 440,8 / 5,79 | 312,4 / 4,11 |
| 2023 | 890,4 / 8,14 | 718,3 / 6,56 |
| 2024 | 972,0 / 8,28 | 950,4 / 8,07 |
| 2025 | sem COFOG ainda | 1.007,6 / 7,91 |
| 12 meses até ago/2026 | | 1.182,2 / 8,86 |

Códigos BCB confirmados no catálogo de dados abertos do BCB (dadosabertos.bcb.gov.br):
- **SGS 5760**: NFSP sem desvalorização cambial, % PIB, fluxo acumulado em 12 meses, juros nominais, setor público consolidado.
- **SGS 4616**: o mesmo conceito em fluxo mensal, R$ milhões. O valor anual em R$ é a soma dos 12 meses (cálculo).
- **Atenção: a SGS 5727, citada no pedido, NÃO é juros.** É o resultado nominal (déficit nominal) total em % do PIB, 12 meses (9,48% em ago/2026). Guardei o bruto para conferência.

Três conceitos diferentes:
- **Juros apropriados (BCB, NFSP)**: competência. Mede quanto a dívida líquida do setor público rendeu de juros no período, pago ou não. Entra a correção pela inflação dos títulos indexados e o resultado das operações de swap cambial do BCB. Cobre o setor público consolidado: governo central, BCB, estados, municípios e estatais (exceto Petrobras, Eletrobras e bancos). É o número que entra no déficit nominal.
- **COFOG 7017**: também competência, com fonte BCB segundo a nota 9/ da tabela da STN. Cobertura do Governo Geral, sem BCB e sem estatais. Somado por esfera dá R$ 1.050 bi, e a consolidação tira R$ 78,6 bi de juros entre esferas (principalmente estados pagando à União). A diferença para a série NFSP (2015: 11,9% contra 8,4%; 2024: 8,3% contra 8,1%) vem da cobertura e de swaps e juros líquidos. Em 2015 os swaps cambiais do BCB tiveram perda grande, que entra na NFSP. Minha hipótese, não verificada linha a linha: o 7017 é próximo de juros brutos do governo geral, e a NFSP é líquida dos juros recebidos sobre ativos. A STN não publica uma ponte entre as duas.
- **Juros pagos no orçamento (LOA/SIAFI, GND 2)**: caixa, só a União, e só o que saiu como pagamento. Boa parte dos juros apropriados não é paga em dinheiro: vira principal (títulos prefixados no vencimento, correção de NTN-B) ou é rolada com emissão nova. Os números de "amortização e refinanciamento da dívida" do orçamento federal incluem rolagem de principal e não são gasto no sentido COFOG. Somar isso a saúde e educação infla a "fatia da dívida" no orçamento. O número federal de caixa fica com a frente da União.

## Comparação internacional, 2024, % do PIB

| | Saúde | Educação | Proteção social | Juros | Total | Total sem juros |
|---|---:|---:|---:|---:|---:|---:|
| Brasil (STN COFOG) | 5,03 | 5,10 | 16,53 | 8,28 | 45,79 | 37,51 |
| OCDE agregado ponderado (OCDE) | 8,46 | 5,02 | 13,66 | | | |
| OCDE país médio (OCDE "OECD average country") | 6,99 | 5,19 | 16,41 | | | |
| OCDE média simples 38 (FMI, cálculo) | | | | 2,21 | 42,63 | 40,51 |
| Chile | 5,33 | 4,54 | 8,23 | 1,21 | 26,81 | 25,60 |
| Colômbia | 8,05 | 3,43 | 8,91 | 4,39 | 34,36 | 29,98 |
| México | 2,68* | 4,06* | sem dado | 6,48 | 30,69 | 24,21 |
| Portugal (provisório) | 6,84 | 4,34 | 17,13 | 2,06 | 42,38 | 40,32 |
| Alemanha (provisório) | 7,61 | 4,50 | 20,40 | 1,06 | 48,95 | 47,89 |
| EUA | 10,28 | 5,60 | 7,80 | 3,95 | 37,61 | 33,66 |

Fontes por coluna: saúde, educação e proteção social vêm da OCDE Government at a Glance (atualização anual, COFOG, ano 2024). Juros vêm do FMI Public Finances in Modern History (`ie`, 2024), e o Brasil no FMI dá 8,28, igual ao STN, porque o FMI usa o dado da STN. Total vem do FMI Fiscal Monitor (`G_X_G01_GDP_PT`, 2024). O total sem juros é cálculo: Fiscal Monitor menos FPP.
\* México não reporta COFOG nem à OCDE nem ao FMI GFS (conferido em 17/10/2026; a consulta ao GFS COFOG voltou só células vazias). Os valores com asterisco vêm do Banco Mundial: saúde da OMS GHED 2023, educação da UNESCO 2022. São conceitos diferentes do COFOG. No mesmo conceito o Brasil fica em 4,29 (saúde 2023) e 5,62 (educação 2022), e a OCDE em 7,98 e 5,06.

## Método

- Fonte primária: STN, "COFOG - Despesas por Função do Governo Geral - 2024", publicada em 12/12/2025 (xlsx anexo 27169 e relatório PDF). É a edição mais recente: a de 2025 só sai no fim de 2026, então não existe COFOG de governo geral para 2025.
- Tabelas usadas: 1.1 (R$ milhões, por esfera), 1.1.a (% do PIB, por esfera) e 2.1 a 2.3 (classificação cruzada econômica x funcional, por esfera).
- Esferas: Governo Central (orçamento fiscal e da seguridade, INSS incluso, sem BCB), estados (inclui DF), municípios (FINBRA/Siconfi com imputação para municípios faltantes) e coluna de consolidação. O consolidado elimina transferências e juros entre esferas.
- Despesa = competência (liquidado mais restos a pagar não processados pagos).
- O dataset do CKAN do Tesouro Transparente "despesas-por-funcao-do-governo-central-classificacao-cofog" é só do Governo Central (CSV 2010 a 2024). Não usei, porque a tabela 1.2 da publicação do Governo Geral já traz o mesmo dado.

### Fato x cálculo no CSV
- `estagio=despesa_competencia_cofog`: FATO, transcrito da STN. O R$ foi convertido de milhões para reais. O `pct_pib` é o da STN.
  - `pct_total` é CÁLCULO. Para o Governo Geral consolidado, é a % da despesa total consolidada. Para uma esfera, é a % da despesa total da própria esfera.
  - Os valores de cada esfera incluem o que ela transfere a outras. O Governo Central em Saúde (R$ 247,7 bi) contém cerca de R$ 158 bi repassados ao SUS de estados e municípios.
- `subcategoria` "701 exceto 7017" e "Despesa total exceto juros": CÁLCULO (subtração).
- `estagio=execucao_direta_calculo`: CÁLCULO. É a despesa da esfera na função menos a categoria econômica 26 "Transferências" das tabelas 2.1 a 2.3. No consolidado, a categoria 26 fica perto de zero, então ela é praticamente toda intergovernamental. Aqui o `pct_total` é a % do total consolidado da mesma função. A soma das três esferas bate com o consolidado com diferença abaixo de 1% em saúde, educação e proteção social. O `pct_pib` usa o PIB implícito da STN (R$ / % PIB).
- `estagio=juros_nominais_apropriados_bcb`: o % PIB é FATO (SGS 5760 de dezembro). O R$ é CÁLCULO, a soma da SGS 4616.
- `estagio=comparacao_internacional`: FATO por fonte. As médias simples da OCDE pelo FMI são CÁLCULO (37 ou 38 membros com dado).

## Lacunas e cuidados

- COFOG de governo geral 2025: ainda não publicado (previsão: dez/2026).
- México: sem COFOG. Proteção social do México ficou sem dado.
- Média OCDE: a OCDE publica dois números. "OECD" é o agregado ponderado pelo PIB, dominado pelos EUA (por isso saúde 8,5 e proteção social 13,7). "OECD average country" é o país médio. Para juros e total, a média é simples, calculada a partir do FMI. Não misturar as linhas.
- Alemanha e Portugal 2024 vêm marcados como provisórios pela OCDE.
- EUA em proteção ambiental aparece com 0,00 na OCDE: os EUA não abrem essa função.
- A tabela 11 da OCDE (`oecd_DF_TABLE11_S13_OTE_2022plus.csv`) foi baixada para tentar juros COFOG 01.7 dos outros países. A Colômbia veio inconsistente (juros de 0,36% em 2023 contra 4,4% em 2024), e Chile e EUA não trazem 01.7. Por isso os juros de todos os países vêm do FMI.
- A STN avisa que os dados estão sujeitos a revisão. A série de PIB usada é a da STN/IBGE da época da publicação. O BCB usa a sua própria estimativa de PIB em 12 meses, então os % não batem exatamente.
- O metadado do SGS (www3.bcb.gov.br/sgspub) estava fora do ar em 17/10/2026. A identificação das séries saiu do catálogo CKAN do BCB.

## Brutos (`brutos/C/`)
- `COFOG_GG_2024_stn.xlsx`, `Relatorio_COFOG_GG_2024.pdf`, `stn_pagina_publicacao_cofog_gg_2024.html`
- `bcb_sgs_5760_*.json`, `bcb_sgs_4616_*.json`, `bcb_sgs_5727_*.json` (este é o resultado nominal, guardado como prova da troca de código)
- `oecd_gaag_DF_GOV_COFOG_YU_selecao_pctpib.csv` (filtrado: países selecionados, % PIB, 2015+), `oecd_DF_TABLE11_S13_OTE_2022plus.csv`
- `imf_datamapper_ie.json`, `imf_datamapper_G_X_G01_GDP_PT.json`, `imf_datamapper_exp.json`
- `wb_SH.XPD.GHED.GD.ZS.json`, `wb_SE.XPD.TOTL.GD.ZS.json`

## URLs
- STN publicação: https://www.tesourotransparente.gov.br/publicacoes/cofog-despesas-por-funcao-do-governo-geral/2024/114
- STN xlsx: https://thot-arquivos.tesouro.gov.br/publicacao-anexo/27169
- BCB: https://api.bcb.gov.br/dados/serie/bcdata.sgs.5760/dados?formato=json e https://api.bcb.gov.br/dados/serie/bcdata.sgs.4616/dados?formato=json
- OCDE: https://sdmx.oecd.org/public/rest/data/OECD.GOV.GIP,DSD_GOV_COFOG@DF_GOV_COFOG_YU,1.0/all
- FMI: https://www.imf.org/external/datamapper/api/v1/ie e https://www.imf.org/external/datamapper/api/v1/G_X_G01_GDP_PT
- Banco Mundial: https://api.worldbank.org/v2/country/BRA/indicator/SH.XPD.GHED.GD.ZS

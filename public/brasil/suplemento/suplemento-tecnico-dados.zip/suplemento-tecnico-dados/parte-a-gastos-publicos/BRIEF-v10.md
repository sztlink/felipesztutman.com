# Brief v10: quanto a política fiscal pode reduzir os juros da dívida brasileira

Aprovado pelo autor em 19/10/2026, a partir do handoff dele, com os ajustes e cortes que eu propus. Base: v9.1, commit 17c7d0a3,
com reprodução limpa testada (78 CSV idênticos e PDF regerado com o mesmo texto).

## Pergunta central
Quanto do custo dos juros da dívida brasileira pode ser atribuído a fatores fiscais, monetários, estruturais e internacionais,
e qual a magnitude demonstrável de sua resposta a reformas fiscais?

Três proposições distintas, que exigem evidências diferentes:
1. Determinadas reformas fiscais podem reduzir o custo de financiamento do Estado.
2. Uma agenda específica conseguirá implementar essas reformas.
3. As reformas implementadas produzirão a redução esperada dos juros, na magnitude e no prazo anunciados.
O dossiê trata de 1 e 3 com evidência. Sobre 2, registra só compromissos públicos verificáveis.

## Classificação obrigatória nas conclusões
- A. Demonstrado pelos dados: contas, identidades, séries observadas.
- B. Compatível com os dados, sem identificação causal conclusiva.
- C. Não demonstrado com as evidências disponíveis.

## Escopo
- Sem frente nova de FHC, Guedes ou Milei. Preservar os episódios brasileiros já documentados (seção 11, eventos).
- Preservar as análises sociais, distributivas e institucionais, sem ampliar.
- Nova seção principal "Quanto a política fiscal pode efetivamente reduzir os juros da dívida brasileira?", até 8 páginas;
  metodologia, regressões, tabelas e testes em anexo.
- Resumo executivo não cresce: substituir ou condensar.

## Base existente a estender (não reconstruir)
- O: custo da DPF por indexador (RMD). R: juro real 10 anos Brasil menos EUA. N: curva do Tesouro Direto, Selic, eventos fiscais.
- M: taxa contra tamanho da dívida entre emergentes (FMI). S: simulador da dívida até 2030.

## Três perímetros, sem misturar sem conciliação explícita
1. Juros nominais do setor público consolidado, % do PIB (BCB): custo fiscal agregado.
2. Dívida pública federal por indexador e vencimento (RMD do Tesouro): transmissão da Selic, custo médio, refinanciamento.
3. Dívida bruta do governo geral, critério Bacen: sustentabilidade e projeções.

## Fontes e identificação
- Risco-país: EMBI+ Brasil do Ipeadata; comparação internacional com séries do FRED. Diferenças metodológicas declaradas.
- api.bcb.gov.br recusa consultas: documentar e usar caminhos alternativos (Olinda, xlsx de estatísticas fiscais, Ipeadata, Internet Archive).
- Sem modelo próprio de prêmio de prazo; usar estimativas publicadas.
- Regressões próprias só como associação e robustez (classe B no máximo).
- Afirmação causal só com metodologia que permita (literatura com identificação).
- Literatura: 15 a 25 estudos, prioridade Brasil e emergentes; parar na saturação.

## Simulações
- Estender S preservando indexação, vencimento e rolagem.
- Choques de 0,5 a 3 pontos, separando Selic, curva inteira e prêmio de risco.
- Parâmetros da literatura com faixa de incerteza. Nenhuma reforma produz automaticamente uma taxa específica.
- Sem atribuir efeitos a candidatos ou orientações ideológicas. Ponto de partida atualizado com o último dado observado.

## Público e convenções
Leitor sofisticado de mercado, sem formação acadêmica obrigatória. Técnico, impessoal, sem retórica partidária.
Presidente identificado em todo gráfico temporal, todo número rastreável a fonte, sem travessão.

## Etapas
1. Taxas, curva, Selic real ex-ante, risco-país, comparações internacionais, regressões de robustez, sensibilidade de 0,5 a 3 pontos.
2. Revisão estruturada da literatura.
3. Extensão do simulador e redação da nova seção.
4. Auditoria independente (subagente que não construiu os modelos), testes, CHANGELOG, PDF e pacote reproduzível.
Não interromper para decisões de escopo, salvo impedimento à validade; registrar limitações e seguir.

## Critérios de validação (autor, 19/10/2026)
- W: separar o efeito mecânico da Selic sobre o estoque pós-fixado do efeito hipotético sobre as taxas de novas emissões;
  economia acumulada pela trajetória do estoque, nunca o primeiro ano vezes quatro.
- X: EMBI+ é spread soberano em dólar, não prêmio fiscal dos títulos em reais; testar estabilidade dos coeficientes por regime monetário.
- Y: não combinar estimativas com variáveis fiscais diferentes (dívida/PIB, primário corrente, superávit esperado, choques identificados);
  faixas por tipo de variável ou transformação explícita; dizer a que taxa cada faixa se aplica.
- Integração Y e S: um coeficiente da literatura não pode ser aplicado ao mesmo tempo à curva e a um prêmio que já incorpora o mesmo efeito.
  No simulador, o canal fiscal entra uma única vez, em uma única taxa, e as demais se movem por identidade ou ficam fixas.
- Auditoria final: além de conferir as contas, tentar refutar as conclusões principais com especificações alternativas e casos em que deixam de valer.
- Sem ampliar escopo.
- Licença (decisão minha, 19/10): o spread ICE BofA de emergentes (FRED BAMLEMCBPIOAS) não pode ser redistribuído. Entra nas regressões,
  mas a série bruta sai dos pacotes e da planilha; o LEIAME diz como baixá-la. EMBI+ do Ipeadata termina em 30/07/2024 (descontinuado).

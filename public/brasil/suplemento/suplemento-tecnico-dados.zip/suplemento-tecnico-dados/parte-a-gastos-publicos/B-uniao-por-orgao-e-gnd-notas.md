# Frente B: gasto da União por órgão e por GND (2019 a 2026)

Data de coleta: 17/10/2026. Arquivo de dados: `B-uniao-por-orgao-e-gnd.csv` (1 linha por ano x estágio x categoria x subcategoria). Brutos em `brutos/B/`.

## 10 linhas para leigo (2025, despesa liquidada, R$ correntes)

1. Em 2025 a União liquidou R$ 5,15 trilhões, mas R$ 1,42 tri disso é **rolagem da dívida** (título velho que vence e é pago com título novo). Tirando a rolagem, o gasto foi **R$ 3,74 tri, ou 29,3% do PIB**.
2. Tirando também juros e amortização efetiva, sobra o gasto "com o país": **R$ 3,02 tri, 23,7% do PIB**.
3. **Previdência (INSS) é o maior bloco**: R$ 1,05 tri, 28% do gasto sem rolagem, 8,2% do PIB.
4. **Juros da dívida liquidados**: R$ 363 bi (2,9% do PIB). Isso é só o juro que sai do orçamento. O juro nominal medido pelo Banco Central (competência, inclui atualização monetária) é bem maior e mora em outra estatística.
5. **Transferências constitucionais a estados e municípios** (FPE, FPM, Fundeb etc): R$ 571 bi, 4,5% do PIB. É dinheiro arrecadado pela União que pertence aos entes.
6. **Assistência social (Bolsa Família, BPC)**, via Ministério do Desenvolvimento Social: R$ 295 bi.
7. **Saúde**: R$ 231 bi (1,8% do PIB). **Educação**: R$ 186 bi (1,5% do PIB), sem contar a complementação do Fundeb, que está em Transferências.
8. **Defesa**: R$ 125 bi, quase tudo pessoal e pensões militares. **Trabalho** (seguro-desemprego e abono): R$ 116 bi.
9. **Investimento da União é pequeno**: R$ 38,6 bi liquidados (0,3% do PIB). Pagando também restos a pagar de anos anteriores, o investimento pago cresce bastante, porque obra costuma ser paga em ano seguinte.
10. **Os três Poderes fora do Executivo** somam pouco no total: Judiciário inteiro cerca de R$ 65 bi, Legislativo (Câmara, Senado, TCU) R$ 15,9 bi, MPU R$ 9,8 bi. Emendas parlamentares de 2025: R$ 47 bi empenhados (individuais 24,3, bancada 11,6, comissão 11,2), R$ 31,5 bi pagos no próprio ano.

## Fontes

| Fonte | O que deu | URL |
|---|---|---|
| SIOP, dados abertos do orçamento (SPARQL) | dotação inicial, dotação atualizada (lei + créditos), empenhado, liquidado, pago no exercício, por órgão orçamentário, GND, elemento, modalidade, resultado primário (RP 6/7/8/9 = emendas) e fonte. **Todos os Poderes**, orçamentos fiscal e da seguridade | https://www1.siop.planejamento.gov.br/sparql/ grafos `http://orcamento.dados.gov.br/{ano}/` |
| Siconfi/Tesouro, RREO da União, Anexo 1 e Anexo 7 | conferência dos totais; restos a pagar pagos por Poder e por órgão do Judiciário, Legislativo, MPU, DPU | https://apidatalake.tesouro.gov.br/ords/siconfi/tt/rreo (an_exercicio, nr_periodo=6, id_ente=1) |
| Portal da Transparência, execução da despesa mensal | restos a pagar pagos por unidade orçamentária do Executivo (2025, 2026) e de emendas por tipo de autor | https://portaldatransparencia.gov.br/download-de-dados/despesas-execucao |
| Portal da Transparência, orçamento da despesa anual | conferência; descobri que só cobre o Executivo | https://portaldatransparencia.gov.br/download-de-dados/orcamento-despesa |
| IBGE SIDRA 6784 (v9808) e 1846 (v585) | PIB nominal | https://apisidra.ibge.gov.br/values/t/6784/n1/all/v/9808/p/all e https://apisidra.ibge.gov.br/values/t/1846/n1/all/v/585/p/last%2012/c11255/90707 |

Datas de atualização do SIOP por exercício (campo `loa:dataUltimaAtualizacao`, gravado em `brutos/B/siop/siop_data_atualizacao.txt`): 2019 a 2022 em abr/mai 2023, 2023 em 27/08/2024, 2024 em 11/02/2025, 2025 em 24/01/2026, **2026 em 17/10/2026 02:31** (execução até 16/10/2026).

## Método

- **Unidade de órgão**: órgão orçamentário do SIOP (código de 5 dígitos), não o "órgão superior" do Portal. Isso separa da Fazenda os órgãos de operação especial: 71000 Encargos Financeiros da União, 72000 Encargos Previdenciários da União, 73000 Transferências a Estados, DF e Municípios, 74000 Operações Oficiais de Crédito, 75000 Dívida Pública Federal, 90000 Reserva de Contingência. A coluna `subcategoria` traz `código | poder`.
- **Estágios** (coluna `estagio`):
  - `dotacao_inicial`, `dotacao_atualizada` (LOA + créditos), `empenhado`, `liquidado`, `pago_exercicio` (pago dentro do ano, sem restos a pagar): fato, SIOP.
  - `pago_total_com_rp` (só 2025): **cálculo** = pago no exercício (SIOP) + restos a pagar pagos em 2025. RP do Executivo e das operações especiais por unidade orçamentária vem do Portal mensal (soma Portal R$ 226,31 bi contra R$ 226,34 bi do RREO Anexo 7, diferença de 0,01%); RP dos outros Poderes vem do RREO Anexo 7 por órgão.
  - `rp_pagos_no_ano_executivo` (2026): restos a pagar pagos de jan a out/2026 por órgão do Executivo, Portal; outubro parcial (arquivo gerado em 10/10/2026). Para pago total 2026 somar a `pago_exercicio`.
  - `rp_pagos_no_ano` (emendas): restos a pagar de emendas pagos no ano, Portal, classificados pelo código do autor (71 bancada, 50/60/70 comissão, 81 relator, demais individual).
- **Estágio recomendado para "quanto se gastou"**: `liquidado` (competência, todos os Poderes, bate com o RREO). `pago_total_com_rp` é o caixa do ano.
- **Dívida e refinanciamento**:
  - Juros = GND 2. Amortização/refinanciamento = GND 6.
  - Refinanciamento (rolagem) separado do GND 6 por **elemento** 76 e 77 (principal refinanciado) nos estágios executados, e por **fonte** 1443/3443 (143/343 até 2022, "refinanciamento da dívida") na dotação, porque a dotação não traz elemento. As duas réguas batem nos executados (2025: R$ 1.415,6 bi por elemento no 75000 + 1,9 bi da Defesa = 1.417,6; por fonte = 1.417,6).
  - "Amortização efetiva" = GND 6 menos refinanciamento. Inclui o elemento 26 "obrigações decorrentes de política monetária" (R$ 111,2 bi em 2025, fonte 1444), que é operação Tesouro x Banco Central e não pagamento a credor de mercado. Não reclassifiquei; está declarado na nota da linha.
  - Linhas `ORGAO: DÍVIDA (todos os órgãos)` somam GND 2 e GND 6 de qualquer órgão (quase tudo no 75000; Defesa tem cerca de R$ 2 bi de dívida contratual).
- **pct_total**: sempre sobre o **total do ano e estágio SEM refinanciamento** (linha `total sem refinanciamento (denominador ...)`). Por isso a linha "total com refinanciamento" aparece com cerca de 138% e o órgão 75000 aparece com mais de 50%. Quem quiser a conta "com rolagem" divide pela linha `total geral com refinanciamento`.
- **pct_pib**: 2019 a 2023 SIDRA 6784; 2024 e 2025 soma dos 4 trimestres da 1846 (6784 ainda não traz 2024); **2026 usa PIB de 12 meses do 3T2025 ao 2T2026 (R$ 13,19 tri) como proxy**, enquanto a execução de 2026 vai só até 16/10: o % do PIB de execução 2026 está subestimado para comparação anual; para dotação 2026 ele é razoável.
- **Intraorçamentárias** (modalidade 91, ex. contribuição patronal da União ao próprio RPPS) estão incluídas nos totais, como no RREO; a linha `das quais intraorçamentárias` mostra o tamanho da dupla contagem (R$ 31,7 bi em 2025).
- Valores do SIOP vêm arredondados ao real.

## Fato x cálculo

- Fato (publicado pela fonte): todo valor por órgão, GND, emendas RP 6/7/8 e estágio SIOP; RP pagos do RREO Anexo 7; RP pagos do Portal por unidade orçamentária (somados por mim por mês e por órgão, mas sem transformação).
- Cálculo meu: separação refinanciamento x amortização efetiva; totais "sem refinanciamento" e "sem dívida"; `pago_total_com_rp`; pct_total; pct_pib; classificação do tipo de emenda dos RP pelo código do autor; PIB 2024, 2025 e 2026 a partir de trimestres.

## Conferências feitas

- SIOP 2025 liquidado total (R$ 5.154,74 bi) = RREO 2025 Anexo 1 total das despesas liquidadas (R$ 5.154,74 bi); total sem refinanciamento SIOP (3.737,1) = RREO subtotal (XI) (3.737,1).
- SIOP 2024 pago R$ 4.647,5 bi x RREO R$ 4.634,2 bi (diferença 0,3%, provavelmente atualização posterior do SIOP em 11/02/2025).
- Emendas do ano no Portal x SIOP 2025: individuais pagas 19,93 x 19,9; bancada 6,28 x 6,3; comissão 5,34 x 5,3.
- RP pagos Executivo 2025: Portal 226,31 x RREO 226,34.

## Lacunas

1. **Portal da Transparência só cobre o Executivo** nos downloads de orçamento e execução. Legislativo, Judiciário, MPU e DPU vieram do SIOP e do RREO. Para esses Poderes não há RP pagos de 2026 por órgão (o RREO Anexo 7 de 2026 só sai por bimestre e o 5º bimestre ainda não foi publicado; o 4º, até agosto, existe na API).
2. **RP pagos por GND** não entraram na série 2019 a 2025; a série GND usa dotação, empenhado, liquidado e pago no exercício. O investimento (GND 4) é o grupo mais afetado: muito do investimento é pago como restos a pagar.
3. **2026 é parcial** (execução até 16/10/2026 no SIOP; Portal até 10/10/2026) e o PIB de 2026 é proxy de 12 meses.
4. Orçamento de investimento das estatais (Petrobras, BB etc.) **não está incluído**; tudo aqui é orçamento fiscal e da seguridade.
5. A classificação do elemento 26 (política monetária, R$ 111 bi em 2025) como "amortização efetiva" é contábil, não econômica. Ver nota do Tesouro antes de usar em texto público.
6. Juros do orçamento (GND 2) não são os "juros nominais" do BCB (que incluem atualização monetária e são por competência). Os dois números costumam ser confundidos em debate público.
7. Emendas: as linhas SIOP RP 6/7/8 trazem só a execução do orçamento do próprio ano; os RP pagos de emendas vêm do Portal (só Executivo, que é onde emendas são executadas). RP 9 (relator) existe só como resto a pagar de 2022 e anteriores (pago em 2024: R$ 2,16 bi; 2025: R$ 1,41 bi; 2026 até out: R$ 0,47 bi). Emendas de 2026 parciais.
8. O download anual do Portal ("orçamento da despesa") chama de "realizado" o **pago no exercício**, não o liquidado; não usei para o resultado final, só para conferência.
9. Os downloads do Portal são protegidos por WAF (CloudFront) e bloqueiam rajadas; baixei com 40 s entre arquivos. Os arquivos mensais baixados (2019-01 a 2021-07 e 2024-01 a 2026-10, 65 zips, 434 MB) estão em `brutos/B/exec/`, ignorados no git por `.gitignore` local; 2021-08 a 2023-12 não foram baixados (não eram necessários, a série GND vem do SIOP); o agregado está em `brutos/B/portal_exec_agregado.json`.

## Reprodução

Scripts usados (copiados para `brutos/B/`: `siop.sh`, `rd.py`, `aggm2.py`, `build.py`; caminhos absolutos dentro deles): consulta SPARQL agregada por órgão x GND x RP x elemento x modalidade (`siop_{ano}_org_gnd_rp_el_mod.csv`) e por fonte do GND 6 (`siop_{ano}_gnd6_fonte.csv`); agregação em stream dos zips mensais do Portal; montagem do CSV. As consultas SPARQL estão reproduzíveis a partir do padrão abaixo:

```
PREFIX loa: <http://vocab.e.gov.br/2013/09/loa#>
SELECT ?org ?gnd ?rp ?el ?mod (SUM(?ini) AS ?dot_ini) (SUM(?atu) AS ?dot_atual)
       (SUM(?emp) AS ?empenhado) (SUM(?liq) AS ?liquidado) (SUM(?pag) AS ?pago)
FROM <http://orcamento.dados.gov.br/2025/>
WHERE { ?s a loa:ItemDespesa ; loa:temUnidadeOrcamentaria ?uo ; loa:temGND ?gnd ;
  loa:temResultadoPrimario ?rp ; loa:temElementoDespesa ?el ; loa:temModalidadeAplicacao ?mod ;
  loa:valorDotacaoInicial ?ini ; loa:valorLeiMaisCredito ?atu ; loa:valorEmpenhado ?emp ;
  loa:valorLiquidado ?liq ; loa:valorPago ?pag . ?uo loa:temOrgao ?org }
GROUP BY ?org ?gnd ?rp ?el ?mod
```

# Frente E, mapa de linhas: taxonomia, crosswalk e armadilhas

Feito em 17/10/2026. Arquivos irmãos: `E-linhas.csv` (50 linhas canônicas da aba principal), `E-renuncias-e-subsidios.csv` (116 linhas medidas). Brutos e scripts em `brutos/E/` (`build_E.py` gera o CSV de renúncias a partir das planilhas baixadas, `build_E_linhas.py` gera a taxonomia).

## 1. Como ler a taxonomia

A aba principal deve responder "para onde vai o dinheiro público" em linguagem de leigo. As 50 linhas de `E-linhas.csv` vêm em 12 grupos. Cada linha diz qual classificação oficial a mede melhor e qual frente já trouxe o número. Regra de ouro: **cada linha tem uma régua só**. Para não ficar com quatro números diferentes para "saúde", cada linha usa a régua que responde melhor à pergunta do cidadão:

| Pergunta | Régua que responde |
|---|---|
| Quanto a União gasta com X, comparável ao longo do tempo | RTN (frente D) para despesa primária. Função (frente A) para o resto |
| Quanto custa a instituição Y | Órgão (frente B) |
| Quanto o país inteiro gasta com X, e como fica perto de outros países | COFOG do Governo Geral (frente C) |
| Quanto o governo deixa de arrecadar para favorecer X | DGT/OSU (frente E) |

Linhas que **nenhuma frente cobre** (e que eu não medi, porque pedem corte por ação ou modalidade nos microdados):
1. Transferências fundo a fundo do SUS (modalidade de aplicação 31 e 41 dentro da função 10).
2. Benefícios a servidores fora da folha (auxílio-alimentação, saúde, creche, transporte; ações 2004, 2010, 2011, 2012, GND 3).
3. Investimentos das estatais não dependentes (Orçamento de Investimento da LOA: Petrobras, BB, Caixa, Correios).
4. Parcialmente: Fundo Partidário e FEFC (B tem o órgão 14000, falta abrir a ação). Previdência de estados e municípios separada do RGPS (C dá só COFOG 10.2 misturado).

## 2. Crosswalk: por que o mesmo tema dá números diferentes

Valores de 2024 tirados dos CSVs das frentes A, B, C e D (todos de fonte primária, ver cada CSV). Servem para mostrar a ordem de grandeza da diferença. Não são para somar.

### Saúde (2024)

| Régua | Valor | O que entra e o que fica de fora |
|---|---|---|
| Função 10 (frente A, liquidado, OFSS sem intra) | R$ 194,8 bi | Toda despesa classificada como saúde, de qualquer órgão. Fica de fora: hospitais universitários (função 12), aposentados do Ministério da Saúde (função 09) |
| RTN (frente D, pago) | R$ 203,9 bi | Saúde obrigatória com controle de fluxo (R$ 152,4 bi) + discricionária (R$ 51,4 bi). Pessoal fica na linha Pessoal do RTN |
| Piso ASPS (frente D, RREO Anexo 12) | R$ 234,5 bi em 2025 (aplicado) | Conceito da LC 141/2012: inclui pessoal ativo da saúde e emendas; exclui inativos, saneamento e plano de saúde de servidor. Empenhado, não pago |
| Órgão 36000 Ministério da Saúde (frente B) | ver B | Inclui inativos e pensionistas do ministério e exclui saúde executada por outros órgãos (Defesa, EBSERH no MEC) |
| COFOG 07, Governo Central (frente C) | R$ 247,7 bi | Conceito de competência e de finalidade, independente do órgão; conta a transferência a outra esfera como gasto do Governo Central (detalhe do tratamento a conferir com a frente C) |
| COFOG 07, Governo Geral consolidado (frente C) | R$ 591,0 bi | União 247,7 + estados 232,7 + municípios 325,1 = 805,5; a coluna de consolidação tira R$ 214,4 bi de repasses contados duas vezes |
| Renúncia ligada à saúde (frente E, DGT função Saúde) | R$ 106,7 bi projetados 2026 | Dedução de despesas médicas no IRPF, entidades filantrópicas, remédios. Não é despesa |

### Educação (2024)

| Régua | Valor | Observação |
|---|---|---|
| Função 12 (A) | R$ 132,6 bi | **Não inclui** a complementação do Fundeb, que fica em 28.847 (R$ 93,0 bi em 2024). Função 12 + 847 = R$ 225,6 bi |
| Piso MDE 18% (D, RREO Anexo 8) | R$ 129,9 bi em 2025 (aplicado) | Conceito constitucional (LDB arts. 70 e 71): exclui merenda e inativos; a forma de contar o Fundeb segue regra própria |
| COFOG 09 Governo Central (C) | R$ 250,2 bi | Conta o Fundeb como educação (fica próximo de função 12 + 847) |
| COFOG 09 Governo Geral (C) | R$ 599,2 bi | Soma das esferas R$ 786,2 bi, menos R$ 187,0 bi de consolidação |
| Renúncia ligada à educação (E) | R$ 22,0 bi projetados 2026 | Dedução escolar do IRPF, ProUni, entidades educacionais |

### Previdência (2024)

| Régua | Valor | Observação |
|---|---|---|
| Função 09 (A) | R$ 1.046,8 bi | RGPS + RPPS civil + parte dos militares. Inclui sentenças previdenciárias |
| RTN Benefícios Previdenciários (D) | R$ 938,5 bi | Só RGPS: urbano R$ 741,6 bi, rural R$ 196,9 bi |
| RTN Pessoal inativo (D) | R$ 164,6 bi | Aposentadorias e pensões civis R$ 101,0 bi + reformas e pensões militares R$ 63,6 bi. Ficam dentro de Pessoal, não de Previdência |
| COFOG 710 Proteção social, GC (C) | R$ 1.518,5 bi | Muito mais amplo: velhice (R$ 734,8 bi), doença e invalidez, família, desemprego, assistência. Não é "previdência" |

### Juros (2024)

| Régua | Valor | Observação |
|---|---|---|
| GND 2 Juros e Encargos, pago (B) | R$ 352,0 bi | Caixa, orçamento federal. Sem correção monetária do principal (que vai para amortização, GND 6) |
| Subfunções 843+844 (A) | R$ 682,2 bi | Juros **e** amortização paga com receita, sem rolagem |
| Juros nominais apropriados BCB, setor público consolidado (C) | R$ 950,4 bi | Competência, todo o setor público, inclui correção monetária e swaps cambiais. É o número do déficit nominal |
| COFOG 7017 Governo Central (C) | R$ 937,7 bi | Conceito de estatística fiscal (competência), próximo do BCB |
| Rolagem (841+842, A) | R$ 1.273,8 bi | Troca de título. Não é gasto |

## 3. Regra de não-dupla-contagem

1. **Uma soma, uma régua.** Na aba principal, as linhas que somam até o total vêm de uma única classificação. Para a União: as 28 funções (frente A) sem refinanciamento somam o total exato. Para o país: as 10 divisões COFOG do Governo Geral (frente C). Nunca misturar função com órgão, RTN ou COFOG na mesma soma.
2. **Recortes transversais não somam.** Emendas (RP 6 a 9), órgão, GND, Novo PAC, piso ASPS/MDE e marcadores atravessam as funções: são colunas ou abas de leitura, nunca parcelas do total.
3. **Rolagem fica fora do total.** Mostrar o total "sem refinanciamento" como total; o "com refinanciamento" só como nota, com a rolagem nomeada.
4. **Transferência só no nível de quem gasta.** No consolidado, FPE, FPM, Fundeb, SUS fundo a fundo e salário-educação contam no ente que executa. Somar União + estados + municípios sem a coluna de consolidação infla o total em cerca de R$ 1,29 tri em 2024 (C: soma das esferas R$ 6,67 tri contra R$ 5,38 tri consolidado).
5. **Renúncia é coluna à parte, nunca parcela.** DGT e OSU tributário medem receita não arrecadada. Podem aparecer ao lado de cada função ("saúde gasta R$ X e renuncia R$ Y"), porque o DGT usa as mesmas funções orçamentárias, mas não entram no total da despesa.
6. **Subsídio financeiro do OSU já é despesa.** Equalizações do Plano Safra, MCMV, tarifa social, FCVS (R$ 65,0 bi em 2024) estão no orçamento. Só os subsídios **tributários** (R$ 563,5 bi) e **creditícios** (R$ 49,8 bi) são extras. "Subsídios totais R$ 678 bi" não pode somar com a despesa.
7. **Desoneração da folha conta uma vez.** A renúncia aparece no DGT; a compensação que a União paga ao RGPS aparece como despesa. Na aba de renúncias usar o DGT; na despesa ela já está dentro do RGPS.
8. **Captado não é renúncia.** Rouanet: o MinC divulga captação (R$ 3,41 bi em 2025); a renúncia fiscal estimada pela RFB é outra série (R$ 2,48 bi realizados em 2023, R$ 3,09 bi projetados para 2026). Usar uma das duas por linha e dizer qual.
9. **Estágio único por coluna.** Liquidado (A), pago (B, D), competência (C) e projeção (DGT PLOA) não se misturam numa mesma coluna. O DGT de PLOA é previsão, o Bases Efetivas é realizado com defasagem de 2 a 3 anos.

## 4. Armadilhas de leitura

1. **O gráfico "metade do orçamento vai para a dívida" (Auditoria Cidadã).** Soma rolagem (troca de título que vence por título novo, R$ 1,27 tri em 2024) com juros e amortização. Rolar dívida não tira dinheiro de saúde nem de educação, assim como trocar um empréstimo por outro não é gasto. O número honesto é juros (R$ 352 bi pagos, ou R$ 950 bi apropriados no setor público todo) contra a despesa sem refinanciamento.
2. **Juros nominais incluem correção monetária.** Os R$ 950 bi do BCB incluem a inflação que corrige o principal dos títulos. Parte disso só repõe o valor real da dívida. O orçamento (GND 2, R$ 352 bi) registra a correção como amortização. Os dois números estão certos e respondem perguntas diferentes.
3. **Encargos Especiais (função 28) não é uma área de governo.** É a gaveta de dívida, transferências constitucionais, Fundeb, precatórios e outros encargos (R$ 1,40 tri sem rolagem em 2024). Comparar "saúde" com "encargos especiais" é comparar uma política com uma gaveta contábil.
4. **Dupla contagem no consolidado.** O dinheiro do SUS que a União manda ao município aparece no orçamento federal e de novo no municipal. Sem a coluna de consolidação, saúde do país vira R$ 805 bi em vez de R$ 591 bi.
5. **FPE e FPM não são gasto da União.** Pertencem por Constituição a estados e municípios. O RTN deduz da receita. Em "gasto por função" eles entram em 28.845 e inflam a União.
6. **Função e órgão divergem muito em Defesa e Judiciário.** O órgão Defesa carrega inativos e pensões militares; o órgão dos tribunais carrega os precatórios da União. "O Judiciário custa X" por órgão pode incluir dezenas de bilhões de sentenças pagas a terceiros.
7. **Educação federal sem o Fundeb.** A função 12 não tem os R$ 93 bi da complementação do Fundeb, que ficam em 28.847.
8. **Pessoal subestimado e superestimado.** GND 1 inclui aposentados e pensionistas (superestima "gasto com servidor ativo") e exclui auxílios e plano de saúde, que estão em GND 3 (subestima o custo do servidor).
9. **Gasto tributário não é "dinheiro dado".** É receita que deixaria de existir se a regra mudasse, mas a estimativa supõe comportamento constante. Remover a renúncia não arrecada 100% do valor.
10. **Lucros e dividendos isentos não aparecem no DGT.** A RFB trata a isenção de dividendos como parte do sistema de referência, então ela não é contada como gasto tributário. Quem procurar "quanto custa a isenção de dividendos" não acha no DGT.
11. **Plano Safra anunciado não é gasto.** Os valores de centenas de bilhões são crédito bancário. O gasto público é a equalização de juros e o seguro rural (R$ 10,7 bi de subsídios financeiros agrícolas em 2024, OSU) mais a renúncia do agro (R$ 77,2 bi em 2024).
12. **Novo PAC anunciado não é orçamento.** Soma investimento de estatais, financiamento e setor privado. A parte orçamentária é GND 4 marcada como PAC.
13. **Programas fora do orçamento por fundo.** Pé-de-Meia rodou parte de 2024 por fundo privado (Fipem), e o MCMV mais pesado roda no FGTS. Comparação ano a ano precisa checar onde o programa estava.
14. **Precatórios fora da meta.** Parte dos precatórios foi paga fora da meta fiscal até 2026 (STF, ADI 7064). Despesa total e despesa "para a meta" diferem.
15. **Nominal contra real e contra PIB.** 2019 e 2026 em reais correntes não são comparáveis. Usar % do PIB ou IPCA, e dizer qual.

## 5. Renúncias e subsídios, o que medi

Fontes primárias baixadas em `brutos/E/`:
- `dgt-previsao-ploa-2026-quadros.xlsx`: DGT que acompanha o PLOA 2026 (RFB). Projeção 2026.
- `dgt-bases-efetivas-2023-serie-2021-a-2026-quadros.xlsx`: DGT Bases Efetivas 2023 (realizado 2023, projeções 2024 a 2026).
- `osu_2025-anexos-publicacao.xlsx` e `osu-9a-edicao.pdf`: Orçamento de Subsídios da União, 9ª edição (SMA/MPO, 19/08/2025), ano de referência 2024. É a fonte realizada mais recente e já usa o DGT Bases Efetivas 2024.
- `sp-ldo-2026.pdf`: LDO 2026 de SP, Anexo de Metas Fiscais, estimativa de renúncia.
- `minc-rouanet-2025.html`: página do MinC; em 17/10/2026 ela pede login. Valores de captação (2023 R$ 2,35 bi, 2024 R$ 3,04 bi, 2025 R$ 3,41 bi) conferidos em republicações do texto oficial.

Números principais:
- **Renúncia federal projetada 2026:** R$ 612,8 bi (4,43% do PIB; 20,2% da arrecadação federal).
- **Renúncia federal realizada 2024:** R$ 563,5 bi (4,80% do PIB). Realizada 2023: R$ 534,0 bi (Bases Efetivas) ou R$ 541,1 bi (OSU, edição revista).
- **Subsídios da União 2024 (OSU):** R$ 678,4 bi (5,78% do PIB) = tributários 563,5 + financeiros 65,0 + creditícios 49,8.
- **Top 10 renúncias, PLOA 2026 (R$ bi):** Simples Nacional 134,3; Agricultura e agroindústria 79,3; Rendimentos isentos do IRPF 63,2; Entidades sem fins lucrativos 55,9; Deduções do IRPF 41,7; Poupança e títulos imobiliários/agro (LCI, LCA, CRI, CRA) 36,9; Zona Franca de Manaus 36,0; Desenvolvimento regional (SUDENE/SUDAM) 27,1; Benefícios do trabalhador 24,3; Medicamentos e equipamentos médicos 22,4.
- **Cultura:** Rouanet (PRONAC) R$ 3,09 bi de renúncia projetada 2026; Audiovisual e correlatos R$ 0,55 bi; captação Rouanet 2025 R$ 3,41 bi.
- **Desoneração da folha:** R$ 7,7 bi (17 setores) + R$ 5,5 bi (municípios) projetados 2026, contra R$ 15,8 bi + R$ 10,6 bi realizados em 2024. Queda pela reoneração gradual.
- **Estado de SP (LDO 2026):** R$ 85,6 bi de renúncia prevista (ICMS 78,7; IPVA 6,6; ITCMD 0,3).

Lacunas: o DGT do PLOA 2027 (enviado em agosto de 2026) e o Bases Efetivas 2024 não estão na página da RFB, que foi reorganizada em 21/08/2026. A 10ª edição do OSU (ano 2025) ainda não saiu. O SALIC (API pública do MinC) devolve 404, então não abri a captação por projeto.

## 6. Correções feitas na montagem da LISTA (17/10/2026)

Conferido nos microdados do Portal e no SIOP por ação (detalhe em `RESUMO-metodo.md`):
- **Armadilha 7 e tabela de Educação estão erradas.** A complementação da União ao Fundeb é a ação 00SB e fica **dentro** da função 12 (12.847). Os R$ 93,0 bi (2024) e R$ 102,0 bi (2025) da subfunção 28.847 são a ação 0C33 (parcela de FPE/FPM que vai ao Fundeb, dinheiro dos entes) mais a 0369 (cotas do salário-educação). Função 12 + 28.847 não é "educação federal com Fundeb".
- **Armadilha 6, parte do Judiciário:** em 2024 a 2026 os precatórios não estão nos órgãos dos tribunais; as ações de sentença ficam nos órgãos 71000, 33000 e 55000. A diferença entre função 02 e órgãos 10000 a 17000 vem de aposentados e patronal intra.
- Legislativo por função (R$ 9,1 bi) e por órgão (R$ 15,9 bi) não dão números próximos.
- Ações 2010, 2011 e 2012 estão extintas (consolidadas na 212B); FEFC é a ação 0EB8 no órgão 71000.
